"""Tests for Monolog-compatible JSON logger."""

import json
import logging
import uuid

import pytest

from src.logger import (
    ALERT,
    BUSINESS_CHANNEL,
    EMERGENCY,
    NOTICE,
    FingersBuffer,
    FingersCrossedHandler,
    MonologFilter,
    MonologFormatter,
    authorization_var,
    business,
    debug_enabled_var,
    fingers_crossed_var,
    logger,
    request_id_var,
    with_request_context,
    x_enable_debug_var,
)


def _make_record(level: int, message: str, **attrs: object) -> logging.LogRecord:
    record = logging.LogRecord(
        name="app",
        level=level,
        pathname="",
        lineno=0,
        msg=message,
        args=(),
        exc_info=None,
    )
    for k, v in attrs.items():
        setattr(record, k, v)
    return record


def _format(level: int, message: str, **attrs: object) -> dict:
    return json.loads(MonologFormatter().format(_make_record(level, message, **attrs)))


# --- Структура записи ---


def test_required_fields_present() -> None:
    entry = _format(logging.WARNING, "test")
    assert set(entry) >= {
        "message",
        "level",
        "level_name",
        "channel",
        "datetime",
        "context",
        "extra",
    }


def test_extra_contains_only_allowed_keys() -> None:
    entry = _format(logging.WARNING, "test")
    assert set(entry["extra"].keys()) == {"requestId", "authorization"}


def test_channel_default_is_app() -> None:
    assert _format(logging.WARNING, "test")["channel"] == "app"


def test_context_default_is_empty_dict() -> None:
    assert _format(logging.WARNING, "test")["context"] == {}


def test_log_context_appears_in_context_field() -> None:
    entry = _format(logging.WARNING, "test", log_context={"duration_ms": 42})
    assert entry["context"]["duration_ms"] == 42


# --- Уровни (коды Monolog) ---


def test_monolog_level_codes() -> None:
    cases = [
        (logging.DEBUG, 100, "DEBUG"),
        (logging.INFO, 200, "INFO"),
        (NOTICE, 250, "NOTICE"),
        (logging.WARNING, 300, "WARNING"),
        (logging.ERROR, 400, "ERROR"),
        (logging.CRITICAL, 500, "CRITICAL"),
        (ALERT, 550, "ALERT"),
        (EMERGENCY, 600, "EMERGENCY"),
    ]
    for py_level, expected_code, expected_name in cases:
        entry = _format(py_level, "test")
        assert entry["level"] == expected_code, f"code mismatch for {expected_name}"
        assert entry["level_name"] == expected_name, f"name mismatch for {expected_name}"


# --- Context vars ---


def test_request_id_propagated() -> None:
    rid = str(uuid.uuid4())
    token = request_id_var.set(rid)
    try:
        assert _format(logging.WARNING, "test")["extra"]["requestId"] == rid
    finally:
        request_id_var.reset(token)


def test_request_id_is_valid_uuid_by_default() -> None:
    """Без явно установленного контекста requestId — стабильный startup-UUID."""
    rid = _format(logging.WARNING, "test")["extra"]["requestId"]
    uuid.UUID(rid, version=4)  # raises if invalid


def test_request_id_stable_outside_request_context() -> None:
    """Все логи вне request-контекста имеют одинаковый requestId."""
    rid1 = _format(logging.WARNING, "first")["extra"]["requestId"]
    rid2 = _format(logging.WARNING, "second")["extra"]["requestId"]
    assert rid1 == rid2


def test_authorization_propagated() -> None:
    token = authorization_var.set("Bearer abc123")
    try:
        result = _format(logging.WARNING, "test")["extra"]["authorization"]
        assert result == "Bearer abc123"
    finally:
        authorization_var.reset(token)


def test_authorization_null_by_default() -> None:
    assert _format(logging.WARNING, "test")["extra"]["authorization"] is None


# --- Фильтр уровней ---


def test_debug_suppressed_in_production() -> None:
    token = debug_enabled_var.set(False)
    try:
        f = MonologFilter()
        assert not f.filter(_make_record(logging.DEBUG, "test"))
        assert not f.filter(_make_record(logging.INFO, "test"))
    finally:
        debug_enabled_var.reset(token)


def test_notice_and_above_pass_in_production() -> None:
    token = debug_enabled_var.set(False)
    try:
        f = MonologFilter()
        levels = (
            NOTICE,
            logging.WARNING,
            logging.ERROR,
            logging.CRITICAL,
            ALERT,
            EMERGENCY,
        )
        for level in levels:
            assert f.filter(_make_record(level, "test")), f"level {level} should pass"
    finally:
        debug_enabled_var.reset(token)


def test_all_levels_pass_with_debug_header() -> None:
    token = debug_enabled_var.set(True)
    try:
        f = MonologFilter()
        for level in (logging.DEBUG, logging.INFO, NOTICE, logging.WARNING):
            assert f.filter(_make_record(level, "test")), f"level {level} should pass"
    finally:
        debug_enabled_var.reset(token)


# --- PII санитайзер ---


def test_pii_keys_are_masked() -> None:
    pii = {
        "birthdate": "1990-05-12",
        "dob": "1990-05-12",
        "date_of_birth": "1990-05-12",
        "height": 178,
        "weight": 72,
        "bmi": 22.7,
        "phone": "+79991234567",
        "phone_number": "+79991234567",
        "mobile": "+79991234567",
        "email": "user@example.com",
        "passport": "1234 567890",
        "passport_number": "1234 567890",
        "snils": "123-456-789 01",
        "inn": "771234567890",
        "fio": "Иванов Иван Иванович",
        "full_name": "Иванов Иван",
        "first_name": "Иван",
        "last_name": "Иванов",
        "middle_name": "Иванович",
        "patronymic": "Иванович",
    }
    entry = _format(logging.WARNING, "test", log_context=pii)
    for key in pii:
        assert entry["context"][key] == "***", f"key {key} must be masked"


def test_non_pii_keys_are_not_masked() -> None:
    ctx = {
        "patient_id": "abc-123",
        "parameter_code": "height",
        "duration_ms": 42,
        "status_code": 200,
        "instrument_code": "stai",
    }
    entry = _format(logging.WARNING, "test", log_context=ctx)
    assert entry["context"] == ctx


def test_pii_key_match_is_case_insensitive() -> None:
    entry = _format(logging.WARNING, "test", log_context={"Birthdate": "1990-01-01", "EMAIL": "a@b.c"})
    assert entry["context"]["Birthdate"] == "***"
    assert entry["context"]["EMAIL"] == "***"


def test_pii_sanitizer_handles_empty_context() -> None:
    entry = _format(logging.WARNING, "test")
    assert entry["context"] == {}


def test_pii_sanitizer_keeps_keys_only_masks_values() -> None:
    """Маскируем значения, но ключи оставляем — diagnose-friendly."""
    entry = _format(logging.WARNING, "test", log_context={"birthdate": "1990-05-12", "patient_id": "p-1"})
    assert "birthdate" in entry["context"]
    assert entry["context"]["birthdate"] == "***"
    assert entry["context"]["patient_id"] == "p-1"


# --- Fingers-crossed buffer ---


class _ListSink(logging.Handler):
    """Capture emitted records without writing to stdout."""

    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


def _msgs(sink: _ListSink) -> list[str]:
    return [r.getMessage() for r in sink.records]


def test_info_buffered_and_dropped_without_error() -> None:
    """Штатный запрос без ERROR: INFO в буфере, на выходе только NOTICE+."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    tok = fingers_crossed_var.set(FingersBuffer())
    try:
        fc.emit(_make_record(logging.INFO, "info-1"))
        fc.emit(_make_record(logging.INFO, "info-2"))
        fc.emit(_make_record(NOTICE, "notice-1"))
        fc.emit(_make_record(logging.WARNING, "warn-1"))
        assert _msgs(sink) == ["notice-1", "warn-1"]
    finally:
        fingers_crossed_var.reset(tok)


def test_info_flushed_in_chronological_order_on_error() -> None:
    """ERROR триггерит буфер: накопленные info выводятся ПЕРЕД самой error-записью."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    tok = fingers_crossed_var.set(FingersBuffer())
    try:
        fc.emit(_make_record(logging.INFO, "info-1"))
        fc.emit(_make_record(logging.INFO, "info-2"))
        fc.emit(_make_record(NOTICE, "notice-1"))
        fc.emit(_make_record(logging.ERROR, "boom"))
        assert _msgs(sink) == ["notice-1", "info-1", "info-2", "boom"]
    finally:
        fingers_crossed_var.reset(tok)


def test_post_trigger_info_passes_through() -> None:
    """После триггера буфер пуст и работает passthrough — последующие INFO выводятся сразу."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    tok = fingers_crossed_var.set(FingersBuffer())
    try:
        fc.emit(_make_record(logging.ERROR, "boom"))
        fc.emit(_make_record(logging.INFO, "info-after"))
        assert _msgs(sink) == ["boom", "info-after"]
    finally:
        fingers_crossed_var.reset(tok)


def test_trigger_is_idempotent_across_multiple_errors() -> None:
    """Второй ERROR не сливает буфер повторно — флаг triggered одноразовый."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    buf = FingersBuffer()
    tok = fingers_crossed_var.set(buf)
    try:
        fc.emit(_make_record(logging.INFO, "info-1"))
        fc.emit(_make_record(logging.ERROR, "boom-1"))
        fc.emit(_make_record(logging.ERROR, "boom-2"))
        assert _msgs(sink) == ["info-1", "boom-1", "boom-2"]
        assert buf.records == []
    finally:
        fingers_crossed_var.reset(tok)


def test_outside_request_context_is_passthrough() -> None:
    """Без активного буфера (вне request) FingersCrossedHandler сразу выводит запись."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    fc.emit(_make_record(NOTICE, "notice"))
    fc.emit(_make_record(logging.ERROR, "error"))
    assert _msgs(sink) == ["notice", "error"]


def test_debug_header_bypasses_buffer() -> None:
    """С X-Enable-Debug буферизации нет — всё выводится сразу, независимо от ERROR."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    buf_tok = fingers_crossed_var.set(FingersBuffer())
    dbg_tok = debug_enabled_var.set(True)
    try:
        fc.emit(_make_record(logging.INFO, "info-1"))
        fc.emit(_make_record(NOTICE, "notice-1"))
        assert _msgs(sink) == ["info-1", "notice-1"]
    finally:
        debug_enabled_var.reset(dbg_tok)
        fingers_crossed_var.reset(buf_tok)


def test_buffers_isolated_between_async_tasks() -> None:
    """Параллельные async-задачи имеют независимые буферы (ContextVar copy-on-task)."""
    import asyncio  # noqa: PLC0415

    sink = _ListSink()
    fc = FingersCrossedHandler(sink)

    async def task(error: bool, info_msg: str, error_msg: str) -> None:
        tok = fingers_crossed_var.set(FingersBuffer())
        try:
            fc.emit(_make_record(logging.INFO, info_msg))
            if error:
                fc.emit(_make_record(logging.ERROR, error_msg))
        finally:
            fingers_crossed_var.reset(tok)

    async def main() -> None:
        await asyncio.gather(
            task(error=True, info_msg="info-a", error_msg="err-a"),
            task(error=False, info_msg="info-b", error_msg="err-b-not-emitted"),
        )

    asyncio.run(main())
    msgs = _msgs(sink)
    # Из «упавшего» таска должны быть info-a и err-a; из «успешного» — ничего.
    assert "info-a" in msgs
    assert "err-a" in msgs
    assert "info-b" not in msgs


def test_formatter_uses_record_creation_time_not_format_time() -> None:
    """timestamp в JSON = момент logger.X(), а не форматирования (важно для буферизованных info)."""
    record = _make_record(logging.INFO, "buffered")
    record.created = 1700000000.123456  # фиксированный «прошлый» момент
    entry = json.loads(MonologFormatter().format(record))
    # 1700000000.123456 UTC = 2023-11-14T22:13:20.123456+00:00
    assert entry["datetime"].startswith("2023-11-14T") or "2023-11-15T" in entry["datetime"]
    assert "1234" in entry["datetime"]  # микросекунды сохранились


def test_filter_allows_info_inside_request_context() -> None:
    """MonologFilter внутри request-контекста пропускает INFO+ для handler-решения."""
    f = MonologFilter()
    debug_tok = debug_enabled_var.set(False)
    buf_tok = fingers_crossed_var.set(FingersBuffer())
    try:
        assert f.filter(_make_record(logging.INFO, "info"))
        assert f.filter(_make_record(NOTICE, "notice"))
        # DEBUG всё равно отсекается — гейтится только X-Enable-Debug.
        assert not f.filter(_make_record(logging.DEBUG, "dbg"))
    finally:
        fingers_crossed_var.reset(buf_tok)
        debug_enabled_var.reset(debug_tok)


# --- Business channel ---


def test_filter_passes_business_info_outside_request_context() -> None:
    """Спека стр. 5: INFO+channel="business" выходит всегда, в т.ч. вне request, при threshold=NOTICE."""
    f = MonologFilter()
    debug_tok = debug_enabled_var.set(False)
    try:
        assert f.filter(_make_record(logging.INFO, "biz", channel=BUSINESS_CHANNEL))
        # А обычный INFO без канала вне request отсекается порогом NOTICE.
        assert not f.filter(_make_record(logging.INFO, "regular"))
    finally:
        debug_enabled_var.reset(debug_tok)


def test_filter_still_blocks_business_debug() -> None:
    """Канал business не открывает DEBUG — DEBUG гейтится только X-Enable-Debug."""
    f = MonologFilter()
    debug_tok = debug_enabled_var.set(False)
    try:
        assert not f.filter(_make_record(logging.DEBUG, "biz-debug", channel=BUSINESS_CHANNEL))
    finally:
        debug_enabled_var.reset(debug_tok)


def test_handler_business_bypasses_buffer() -> None:
    """В request-контексте без ERROR обычный INFO буферизуется, но business INFO выходит сразу."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    buf = FingersBuffer()
    tok = fingers_crossed_var.set(buf)
    try:
        fc.emit(_make_record(logging.INFO, "regular-info"))
        fc.emit(_make_record(logging.INFO, "biz", channel=BUSINESS_CHANNEL))
        assert _msgs(sink) == ["biz"]
        # Regular info ушёл в буфер, business — нет.
        assert [r.getMessage() for r in buf.records] == ["regular-info"]
    finally:
        fingers_crossed_var.reset(tok)


def test_handler_business_not_duplicated_on_flush() -> None:
    """При flush буфера на ERROR business-запись не дублируется (она и не была в буфере)."""
    sink = _ListSink()
    fc = FingersCrossedHandler(sink)
    tok = fingers_crossed_var.set(FingersBuffer())
    try:
        fc.emit(_make_record(logging.INFO, "biz", channel=BUSINESS_CHANNEL))
        fc.emit(_make_record(logging.INFO, "regular"))
        fc.emit(_make_record(logging.ERROR, "boom"))
        # business вышел первым (сразу), затем flush regular, затем boom. Каждое — ровно один раз.
        assert _msgs(sink) == ["biz", "regular", "boom"]
    finally:
        fingers_crossed_var.reset(tok)


def test_formatter_emits_business_channel_in_json() -> None:
    """channel="business" попадает в JSON-выхлоп с level=200 / level_name="INFO"."""
    entry = _format(logging.INFO, "kafka.publish succeeded", channel=BUSINESS_CHANNEL)
    assert entry["channel"] == "business"
    assert entry["level"] == 200
    assert entry["level_name"] == "INFO"


def test_business_helper_emits_info_with_channel() -> None:
    """business() делегирует на logger.log с INFO, channel="business" и log_context.

    Проверяем именно сам вызов на logger — а не наблюдаемый emit через addHandler,
    т.к. shared logger в test-suite может иметь чужие handlers / уровни от соседних тестов."""
    from unittest.mock import patch  # noqa: PLC0415

    with patch.object(logger, "log") as mock_log:
        business("questionnaire completed", context={"client_id": "c-1"})

    mock_log.assert_called_once()
    args, kwargs = mock_log.call_args
    assert args[0] == logging.INFO
    assert args[1] == "questionnaire completed"
    assert kwargs["extra"]["channel"] == BUSINESS_CHANNEL
    assert kwargs["extra"]["log_context"] == {"client_id": "c-1"}


def test_business_helper_handles_none_context() -> None:
    """context=None → log_context={} (как в notice/alert/emergency)."""
    from unittest.mock import patch  # noqa: PLC0415

    with patch.object(logger, "log") as mock_log:
        business("event")

    _, kwargs = mock_log.call_args
    assert kwargs["extra"]["log_context"] == {}
    assert kwargs["extra"]["channel"] == BUSINESS_CHANNEL


# --- with_request_context (BG-tasks) ---


async def test_with_request_context_restores_request_id_inside_wrapped_task() -> None:
    """Snapshot захвачен в момент wrap; внутри обёртки request_id_var = тому, что было при wrap'е."""
    captured: dict[str, str] = {}

    async def task() -> None:
        captured["req_id"] = request_id_var.get()

    req_tok = request_id_var.set("REQ-INSIDE-MW")
    try:
        wrapped = with_request_context(task)
    finally:
        request_id_var.reset(req_tok)  # имитируем выход middleware

    # После выхода middleware — снова дефолт-UUID. Но wrapped() должен видеть "REQ-INSIDE-MW".
    assert request_id_var.get() != "REQ-INSIDE-MW"
    await wrapped()
    assert captured["req_id"] == "REQ-INSIDE-MW"


async def test_with_request_context_restores_all_four_vars() -> None:
    """Snapshot покрывает request_id, authorization, debug_enabled, x_enable_debug."""
    captured: dict[str, object] = {}

    async def task() -> None:
        captured["req"] = request_id_var.get()
        captured["auth"] = authorization_var.get()
        captured["debug"] = debug_enabled_var.get()
        captured["x_debug"] = x_enable_debug_var.get()

    t_req = request_id_var.set("r-1")
    t_auth = authorization_var.set("Bearer ***")
    t_dbg = debug_enabled_var.set(True)
    t_x = x_enable_debug_var.set("true")
    try:
        wrapped = with_request_context(task)
    finally:
        x_enable_debug_var.reset(t_x)
        debug_enabled_var.reset(t_dbg)
        authorization_var.reset(t_auth)
        request_id_var.reset(t_req)

    await wrapped()
    assert captured == {"req": "r-1", "auth": "Bearer ***", "debug": True, "x_debug": "true"}


async def test_with_request_context_isolates_fingers_crossed_structurally() -> None:
    """Спека стр. 5 запрещает FC для демонов: wrapper изолирует структурно, не таймингом middleware.

    Тест валился бы без force-set fingers_crossed_var=None внутри wrapped(): вызываем wrapped()
    ПРИ АКТИВНОМ FC-буфере (имитация вложенного таска / некорректного caller'а), задача должна
    всё равно видеть None. И в окружающем контексте FC возвращается на место после reset токена."""
    inside_buf: list[FingersBuffer | None] = []
    outer_buf: list[FingersBuffer | None] = []

    async def task() -> None:
        inside_buf.append(fingers_crossed_var.get())

    fc_tok = fingers_crossed_var.set(FingersBuffer())
    try:
        wrapped = with_request_context(task)
        await wrapped()
        # Окружающий FC-буфер не повреждён token-операциями внутри wrapped().
        outer_buf.append(fingers_crossed_var.get())
    finally:
        fingers_crossed_var.reset(fc_tok)

    assert inside_buf == [None]
    assert outer_buf and outer_buf[0] is not None


async def test_with_request_context_resets_after_task_completes() -> None:
    """После выполнения wrapped() ContextVar'ы возвращаются к тому, что было до вызова — нет утечки."""

    async def task() -> None:
        return None

    # Захват «request-времени».
    req_tok = request_id_var.set("inside")
    wrapped = with_request_context(task)
    request_id_var.reset(req_tok)

    # Теперь в текущем контексте — дефолт. После await вызов ничего не должен поменять.
    before = request_id_var.get()
    await wrapped()
    assert request_id_var.get() == before


# --- Env-конфигурируемое маскирование (RISK_MODEL_LOG_MASK_KEYS) ---


def test_mask_keys_read_from_settings(monkeypatch) -> None:
    """Список ключей берётся из settings.log_mask_keys — подменяется без правки кода."""
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "gender,client_id")
    entry = _format(
        logging.WARNING,
        "test",
        log_context={"gender": "male", "client_id": "p-1", "birthdate": "1990-01-01"},
    )
    assert entry["context"]["gender"] == "***"
    assert entry["context"]["client_id"] == "***"
    # birthdate не в кастомном списке — видим значение.
    assert entry["context"]["birthdate"] == "1990-01-01"


def test_mask_key_normalization_covers_case_and_delimiters(monkeypatch) -> None:
    """ "birthdate" в списке покрывает birthDate / birth_date / Birth-Date (camelCase на проводе)."""
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "birthdate,x-test-api-key")
    entry = _format(
        logging.WARNING,
        "test",
        log_context={"birthDate": "1990-01-01", "birth_date": "1990-01-01", "X-Test-Api-Key": "secret"},
    )
    assert entry["context"]["birthDate"] == "***"
    assert entry["context"]["birth_date"] == "***"
    assert entry["context"]["X-Test-Api-Key"] == "***"


def test_masking_is_recursive_for_nested_bodies(monkeypatch) -> None:
    """Тело запроса кладётся в context вложенным объектом — маскировка достаёт и его."""
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "gender,birthdate,authorization")
    body = {"gender": "male", "heightCm": 178.0, "nested": [{"birthDate": "1990-01-01"}]}
    headers = {"authorization": "Bearer abc", "content-type": "application/json"}
    entry = _format(logging.WARNING, "test", log_context={"request_body": body, "request_headers": headers})
    # blob-поля сериализуются в одну JSON-строку (см. _BLOB_CONTEXT_KEYS) — парсим обратно.
    rb = json.loads(entry["context"]["request_body"])
    rh = json.loads(entry["context"]["request_headers"])
    assert rb["gender"] == "***"
    assert rb["heightCm"] == 178.0
    assert rb["nested"][0]["birthDate"] == "***"
    assert rh["authorization"] == "***"
    assert rh["content-type"] == "application/json"


def test_empty_mask_list_disables_masking(monkeypatch) -> None:
    """Поведение форматтера при пустом списке: ничего не маскировать. На уровне env такого
    не бывает — валидатор Settings принудительно вливает секреты (см. test_config)."""
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "")
    entry = _format(logging.WARNING, "test", log_context={"birthdate": "1990-01-01"})
    assert entry["context"]["birthdate"] == "1990-01-01"


def test_default_mask_keys_cover_transport_secrets() -> None:
    """Секреты заголовков обязаны быть в дефолтном списке — защита от утечки токена в ELK."""
    from src.constants import DEFAULT_LOG_MASK_KEYS, normalize_mask_key

    normalized = {normalize_mask_key(k) for k in DEFAULT_LOG_MASK_KEYS.split(",")}
    for required in ("authorization", "cookie", "setcookie", "xtestapikey"):
        assert required in normalized


def test_mask_keys_fall_back_to_default_when_config_unavailable(monkeypatch, capsys) -> None:
    """Boot-order guard (повторное ревью !99): конфиг не импортируется → маскируем по
    DEFAULT_LOG_MASK_KEYS и один раз пишем маркер в stderr — молча проигнорированный
    кастомный RISK_MODEL_LOG_MASK_KEYS иначе недиагностируем."""
    import sys

    import src.logger as logger_mod

    # None в sys.modules → `from src.config import settings` кидает ImportError.
    monkeypatch.setitem(sys.modules, "src.config", None)
    monkeypatch.setattr(logger_mod, "_mask_keys_cache", None)
    monkeypatch.setattr(logger_mod, "_mask_keys_fallback_reported", False)

    masked = logger_mod._sanitize_context({"birthdate": "1990-01-01", "note": "ok"})
    assert masked["birthdate"] == "***"
    assert masked["note"] == "ok"
    assert "boot-order fallback" in capsys.readouterr().err

    # Маркер одноразовый: повторный вызов не шумит.
    logger_mod._sanitize_context({"birthdate": "1990-01-01"})
    assert capsys.readouterr().err == ""


# --- body_for_log ---


def test_body_for_log_parses_json() -> None:
    from src.logger import body_for_log

    assert body_for_log(b'{"a": 1}', 1024) == {"a": 1}


def test_body_for_log_empty_is_none() -> None:
    from src.logger import body_for_log

    assert body_for_log(b"", 1024) is None


def test_body_for_log_always_returns_dict_or_none() -> None:
    """Контракт типа для ES: body_for_log НИКОГДА не возвращает строку/скаляр/список — только
    dict|None. Иначе context.request_body разъезжается по типам между индексами → Kibana
    помечает поле type=conflict и прячет его (реальная жалоба тестера, 06.2026)."""
    from src.logger import body_for_log

    cases = [
        b'{"a": 1}',  # JSON-объект
        b"snils=123-456",  # не-JSON / form без нужного content-type
        b"[1, 2, 3]",  # JSON-массив
        b'"just a string"',  # JSON-строка
        b"42",  # JSON-число
        b"true",  # JSON-bool
        b"\xff\xfe binary",  # бинарь
    ]
    for raw in cases:
        result = body_for_log(raw, 16, "application/json")
        assert isinstance(result, dict), f"{raw!r} -> {type(result).__name__}, ожидался dict"


def test_body_for_log_non_json_wrapped_in_dict() -> None:
    """Не-JSON тело -> dict-маркер без сырого содержимого (плоская строка не маскируется по ключам)."""
    from src.logger import body_for_log

    result = body_for_log(b"snils=123-456", 1024, "text/plain")
    assert result == {"_omitted": "unstructured 13 bytes, content-type=text/plain"}
    assert "123-456" not in str(result)


def test_body_for_log_json_scalar_wrapped_in_value() -> None:
    """JSON-скаляр/массив (ключей для маскировки нет) оборачивается в {"_value": ...} — поле
    остаётся object-типа, а вложенные dict внутри массива всё равно маскируются по ключам."""
    from src.logger import body_for_log

    assert body_for_log(b"79991234567", 1024, "application/json") == {"_value": 79991234567}
    assert body_for_log(b"true", 1024, "application/json") == {"_value": True}
    assert body_for_log(b'[{"a": 1}]', 1024, "application/json") == {"_value": [{"a": 1}]}


def test_body_for_log_parses_form_urlencoded() -> None:
    """form-urlencoded парсится в dict — маскирование по ключам работает (ревью !99)."""
    from src.logger import body_for_log

    raw = b"birthdate=1990-01-01&note=ok&empty="
    result = body_for_log(raw, 1024, "application/x-www-form-urlencoded; charset=utf-8")
    assert result == {"birthdate": "1990-01-01", "note": "ok", "empty": ""}


def test_body_for_log_oversized_wrapped_in_dict() -> None:
    """Сверхлимитное тело: dict-маркер с размером, без сырого содержимого."""
    from src.logger import body_for_log

    raw = b'{"birthdate": "' + b"x" * 100 + b'"}'
    result = body_for_log(raw, 16)
    assert result == {"_omitted": f"{len(raw)} bytes > 16 cap"}
    assert "x" * 10 not in str(result)


def test_default_list_masks_anthropometry_wire_keys() -> None:
    """Регресс P1 ревью: дефолтный список обязан маскировать РЕАЛЬНЫЕ wire-ключи
    антропометрии (camelCase), а не только исторические snake_case-коды параметров."""
    body = {"heightCm": 178.0, "weightKg": 72.5, "birthDate": "1990-05-12", "gender": "male"}
    entry = _format(logging.WARNING, "test", log_context={"request_body": body})
    rb = json.loads(entry["context"]["request_body"])
    for key in body:
        assert rb[key] == "***", f"wire key {key} must be masked by default"


def test_default_list_masks_cvd_payload() -> None:
    """Регресс P1 ревью: riskFactors (12 биомаркеров) и riskPercentage маскируются дефолтом целиком."""
    request_body = {"period": "Y5", "riskFactors": {"age": 55.0, "systolicBp": 120.0}}
    response_body = {"isSuccess": True, "riskPercentage": 48.5, "score": 52.1}
    entry = _format(logging.WARNING, "test", log_context={"request_body": request_body, "response_body": response_body})
    rb = json.loads(entry["context"]["request_body"])
    resp = json.loads(entry["context"]["response_body"])
    assert rb["riskFactors"] == "***"
    assert rb["period"] == "Y5"
    assert resp["riskPercentage"] == "***"
    assert resp["score"] == "***"


def test_blob_fields_serialized_to_single_string() -> None:
    """Контракт: request_body/response_body/request_headers выходят ОДНОЙ JSON-строкой,
    не объектом — иначе Kibana не выводит их колонкой, плюс ES type=conflict / mapping explosion.
    Скаляры в context (status_code, duration_ms) остаются как есть."""
    entry = _format(
        logging.WARNING,
        "test",
        log_context={
            "request_body": {"a": 1},
            "response_body": {"b": 2},
            "request_headers": {"h": "v"},
            "status_code": 201,
            "path": "/x",
        },
    )
    assert entry["context"]["request_body"] == '{"a": 1}'
    assert entry["context"]["response_body"] == '{"b": 2}'
    assert entry["context"]["request_headers"] == '{"h": "v"}'
    assert entry["context"]["status_code"] == 201
    assert entry["context"]["path"] == "/x"


def test_default_list_masks_biomarker_name_and_value() -> None:
    """Название и значение биомаркера рядом с client_id — медицинские данные, поэтому дефолтный
    список их маскирует. Идентификаторы и единица измерения остаются открытыми: по ним запись
    о пропущенном биомаркере остаётся трассируемой."""
    entry = _format(
        logging.WARNING,
        "emr.biomarkers: biomarker skipped",
        log_context={
            "client_id": "123e4567-e89b-12d3-a456-426614174000",
            "biomarker_id": "845235",
            "biomarker_code": "1746",
            "biomarker_name": "ДНК Chlamydia trachomatis, соскоб урогенитальный качественно",
            # Заполненная единица, а не None: на None утверждение «не замаскировано» прошло бы
            # и в том случае, если бы ключ в маск-лист всё-таки попал.
            "biomarker_unit": "нг/мл",
            "biomarker_unit_code": "12",
            "biomarker_value": "Обнаружен",
        },
    )
    context = entry["context"]
    assert context["biomarker_name"] == "***"
    assert context["biomarker_value"] == "***"
    assert context["biomarker_id"] == "845235"
    assert context["biomarker_code"] == "1746"
    assert context["biomarker_unit"] == "нг/мл"
    assert context["biomarker_unit_code"] == "12"


def test_default_list_masks_examination_event_patient_values() -> None:
    """Группа заболеваний клиента и значение параметра пола рядом с client_id — медицинские данные;
    коды системы и интерпретации и причина ошибки остаются открытыми, по ним запись трассируется."""
    entry = _format(
        logging.WARNING,
        "DISEASE_MAPPING_NOT_FOUND: disease group code is missing from the catalog",
        log_context={
            "client_id": "123e4567-e89b-12d3-a456-426614174000",
            "system_code": "MENTAL",
            "disease_value": "depression",
            "interpretation_id": 42,
            "gender_value": "Иное",
            "reason": "unrecognized",
        },
    )
    context = entry["context"]
    assert context["disease_value"] == "***"
    assert context["gender_value"] == "***"
    assert context["system_code"] == "MENTAL"
    assert context["interpretation_id"] == 42
    assert context["reason"] == "unrecognized"
    assert context["client_id"] == "123e4567-e89b-12d3-a456-426614174000"


def test_default_list_masks_ip_headers() -> None:
    headers = {"x-forwarded-for": "10.0.0.1", "x-real-ip": "10.0.0.2", "host": "api.example"}
    entry = _format(logging.WARNING, "test", log_context={"request_headers": headers})
    rh = json.loads(entry["context"]["request_headers"])
    assert rh["x-forwarded-for"] == "***"
    assert rh["x-real-ip"] == "***"
    assert rh["host"] == "api.example"


def test_mask_list_csv_tolerates_whitespace(monkeypatch) -> None:
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "  gender , , birthdate  ")
    entry = _format(logging.WARNING, "test", log_context={"gender": "male", "birthdate": "x"})
    assert entry["context"]["gender"] == "***"
    assert entry["context"]["birthdate"] == "***"


def test_depth_limit_returns_placeholder_not_raw_subtree() -> None:
    """Глубже лимита рекурсии не отдаём немаскированные данные — только плейсхолдер."""
    from src.logger import _MASK_MAX_DEPTH

    deep: dict = {"birthdate": "1990-01-01"}
    for _ in range(_MASK_MAX_DEPTH + 1):
        deep = {"nested": deep}
    entry = _format(logging.WARNING, "test", log_context={"request_body": deep})
    assert "1990-01-01" not in json.dumps(entry)
    # Плейсхолдер обязан присутствовать: рефакторинг, вернувший None, молча потерял бы диагностику.
    assert "...[depth limit]" in json.dumps(entry)


def test_tuples_are_masked_like_lists(monkeypatch) -> None:
    from src.config import settings

    monkeypatch.setattr(settings, "log_mask_keys", "birthdate")
    entry = _format(logging.WARNING, "test", log_context={"items": ({"birthdate": "1990-01-01"},)})
    assert entry["context"]["items"][0]["birthdate"] == "***"


# --- Дефолтный маск-лист целиком ---


def _wire_forms(key: str) -> list[str]:
    """Формы, в которых ключ реально приходит на проводе: как объявлен, camelCase, через дефис.

    Сравнение нормализованное (`normalize_mask_key`), поэтому все три обязаны маскироваться одним
    и тем же элементом списка. Ключ, объявленный в форме, до которой нормализация не достаёт,
    выглядит в списке рабочим, но не маскирует ничего.
    """
    parts = [part for part in key.replace("-", "_").split("_") if part]
    camel = parts[0] + "".join(part.capitalize() for part in parts[1:])
    return [key, camel, "-".join(parts)]


def _default_mask_keys() -> list[str]:
    from src.constants import DEFAULT_LOG_MASK_KEYS

    return [key.strip() for key in DEFAULT_LOG_MASK_KEYS.split(",") if key.strip()]


@pytest.mark.parametrize("key", _default_mask_keys())
def test_every_declared_mask_key_masks_in_every_position(key: str) -> None:
    """Каждый ключ дефолтного списка маскируется в контексте, во вложенном теле и в списке.

    Раньше список проверялся выборкой из нескольких групп: ключ, добавленный в константу, но
    записанный в форме, до которой нормализация не достаёт, ни одной проверки не ронял.
    """
    secret = "значение-которого-быть-не-должно"
    for form in _wire_forms(key):
        entry = _format(
            logging.WARNING,
            "test",
            log_context={form: secret, "request_body": {form: secret, "items": [{form: secret}]}},
        )
        assert entry["context"][form] == "***", f"{form} (объявлен как {key}) не замаскирован в context"
        assert secret not in json.dumps(entry), f"{form} (объявлен как {key}) утёк во вложенном теле"


def test_default_mask_list_has_no_duplicate_keys() -> None:
    """Дубль в списке — признак того, что ключ добавили дважды в разных формах записи."""
    from src.constants import normalize_mask_key

    normalized = [normalize_mask_key(key) for key in _default_mask_keys()]
    duplicates = {key for key in normalized if normalized.count(key) > 1}
    assert not duplicates, f"дубли в DEFAULT_LOG_MASK_KEYS: {sorted(duplicates)}"


def test_keys_outside_the_default_list_keep_their_values() -> None:
    """Обратная сторона списка: трассировочные поля остаются читаемыми.

    Без этого «замаскировать всё» прошло бы предыдущую проверку и ослепило прод-диагностику.
    """
    entry = _format(
        logging.WARNING,
        "test",
        log_context={"client_id": "p-1", "patient_id": "p-1", "instrument_code": "SCORE2", "status_code": 200},
    )
    assert entry["context"] == {
        "client_id": "p-1",
        "patient_id": "p-1",
        "instrument_code": "SCORE2",
        "status_code": 200,
    }
