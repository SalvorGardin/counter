"""Тесты /proc-коллектора CPU/RAM (risk_profile_core_process_*).

Чистые парсеры /proc проверяем кросс-платформенно, живые значения — только на Linux (в CI);
на macOS убеждаемся, что выдача /metrics не падает и просто не содержит process_*.
"""

import multiprocessing
import multiprocessing.synchronize
import os
import sys

import pytest
from prometheus_client.parser import text_string_to_metric_families

import src.metrics as metrics
from src.metrics import _master_pid, _parse_proc_stat, _parse_proc_statm_rss, _read_proc_stats, init_metrics, render


def _block_until(barrier: "multiprocessing.synchronize.Barrier", stop: "multiprocessing.synchronize.Event") -> None:
    """Ребёнок-«воркер»: сигналит готовность через barrier и виснет до stop (модуль-уровень —
    нужно для spawn/fork target)."""
    barrier.wait()
    stop.wait()


def _sample_value(name: str) -> float | None:
    for family in text_string_to_metric_families(render().decode()):
        for sample in family.samples:
            if sample.name == name:
                return sample.value
    return None


def test_parse_proc_stat_handles_comm_with_spaces_and_parens() -> None:
    """comm может содержать пробелы и ')': парсим после ПОСЛЕДНЕЙ ')', поля не сдвигаются."""
    line = "1234 (weird )name) S 7 1234 1234 0 -1 4194560 100 0 0 0 40 12 0 0 20 0 4 0 999"
    ppid, cpu_ticks = _parse_proc_stat(line)
    assert ppid == 7
    assert cpu_ticks == 52  # utime 40 + stime 12


def test_parse_proc_statm_rss_uses_second_field_times_page_size() -> None:
    assert _parse_proc_statm_rss("4200 512 480 4 0 300 0", 4096) == 512 * 4096


@pytest.mark.skipif(sys.platform != "linux", reason="/proc доступен только на Linux")
def test_proc_stats_present_on_linux() -> None:
    init_metrics("proc-test")
    cpu = _sample_value("risk_profile_core_process_cpu_seconds_total")
    rss = _sample_value("risk_profile_core_process_resident_memory_bytes")
    count = _sample_value("risk_profile_core_process_count")
    assert cpu is not None and cpu >= 0
    assert rss is not None and rss > 0
    assert count is not None and count >= 1


@pytest.mark.skipif(sys.platform == "linux", reason="проверяем тихое отключение вне Linux")
def test_proc_stats_absent_off_linux_but_render_ok() -> None:
    init_metrics("proc-test")
    body = render().decode()
    # Без /proc метрик process_* нет, но выдача валидна и содержит build_info.
    assert "risk_profile_core_process_cpu_seconds_total" not in body
    assert "risk_profile_core_process_resident_memory_bytes" not in body
    assert "risk_profile_core_build_info" in body


def test_master_pid_is_self_when_single_worker(monkeypatch: pytest.MonkeyPatch) -> None:
    """workers=1 → мастер = сам процесс даже при выставленной multiproc-директории (баг #2:
    иначе getppid()=PID 1 контейнера подтянул бы посторонних детей init)."""
    monkeypatch.setattr(metrics, "_MULTIPROC_PATH", "/tmp/prom-multiproc")
    assert _master_pid(1) == os.getpid()
    # А при workers>1 в multiproc-режиме — родитель (uvicorn-мастер).
    assert _master_pid(4) == os.getppid()
    # Без multiproc-режима — всегда сам процесс.
    monkeypatch.setattr(metrics, "_MULTIPROC_PATH", "")
    assert _master_pid(4) == os.getpid()


@pytest.mark.skipif(sys.platform != "linux", reason="/proc доступен только на Linux")
def test_proc_stats_sums_live_worker_processes() -> None:
    """Суммирование по ЖИВЫМ детям: 3 ребёнка блокируются, пока читаем /proc (стенд-релевантно —
    workers=4). В single-process режиме мастер = getpid(), дети с ppid==self попадают в сумму."""
    # spawn — тот же способ, которым uvicorn заводит воркеров (`uvicorn/_subprocess.py`:
    # `get_context("spawn")`), так что модель процессов здесь совпадает со стендовой.
    # fork к тому же небезопасен: к этому моменту в процессе pytest жив тред пула asyncio (его
    # заводит getaddrinfo при первом подключении asyncpg, а петля событий сессионная), а fork из
    # многопоточного процесса ребёнок может пережить зависанием на чужой блокировке — Python
    # 3.12+ помечает это DeprecationWarning.
    # forkserver не подошёл бы: его дети — дети форк-сервера, их ppid не равен нашему pid,
    # и в сумму по /proc они не попадут.
    ctx = multiprocessing.get_context("spawn")
    stop = ctx.Event()
    barrier = ctx.Barrier(4)  # 3 ребёнка + родитель
    children = [ctx.Process(target=_block_until, args=(barrier, stop)) for _ in range(3)]
    for child in children:
        child.start()
    try:
        barrier.wait(timeout=10)  # дожидаемся, пока все дети живы и видны в /proc
        stats = _read_proc_stats(1)  # workers=1 → master=getpid() → +дети
        assert stats is not None
        _cpu, rss, count = stats
        assert count >= 1 + len(children)  # сам процесс + минимум 3 живых ребёнка
        assert rss > 0
    finally:
        stop.set()
        for child in children:
            child.join(timeout=10)
