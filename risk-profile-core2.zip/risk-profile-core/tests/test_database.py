import contextlib
from typing import Any

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import ServiceRuntime, Settings, db_url_env
from src.infra.database import Base, get_primary_runtime, get_session

# Адрес заведомо недостижим и никуда не используется: движок ленивый, соединений не открывает.
_TEST_URL = "postgresql+asyncpg://runtime:runtime@localhost:5432/unused"


def _engine_answering_current_user(login: str, session_user: str | None = None) -> Any:
    """Движок-заглушка: на `SELECT current_user, session_user` отвечает заданными логинами, в БД не ходит."""

    class _Result:
        def one(self) -> tuple[str, str]:
            return login, session_user or login

    class _Connection:
        async def execute(self, _statement: Any) -> _Result:
            return _Result()

    class _Engine:
        @contextlib.asynccontextmanager
        async def connect(self):
            yield _Connection()

    return _Engine()


def test_base_has_metadata():
    assert Base.metadata is not None


def test_engine_driver_is_asyncpg():
    assert get_primary_runtime().engine.url.drivername == "postgresql+asyncpg"


def test_primary_runtime_uses_the_url_of_its_role(no_primary_runtime, monkeypatch):
    """Основной рантайм берёт строку подключения из переменной своей роли, а не из общей."""
    from pydantic import SecretStr

    from src.infra.database import init_primary_runtime

    ehr_url = "postgresql+asyncpg://risk_ehr_app:pw@db:5432/riskdb"
    monkeypatch.setattr("src.config.settings.ehr_db_url", SecretStr(ehr_url))

    runtime = init_primary_runtime(ServiceRuntime.EHR)

    # render_as_string preserves the plaintext password for comparison
    assert runtime.engine.url.render_as_string(hide_password=False) == ehr_url


async def test_get_session_yields_async_session():
    # asyncio_mode=auto (pytest-asyncio) runs this without @pytest.mark.asyncio
    async for session in get_session():
        assert isinstance(session, AsyncSession)
        break


def test_every_model_table_declares_its_owner_schema():
    """Ни одна таблица не остаётся в public: рантайм-карта транслирует только объявленные схемы."""
    import src.models  # noqa: F401 — регистрирует модели в Base.metadata
    from src.infra.db_schemas import (
        CALCULATION_SCHEMA,
        CALCULATION_TABLES,
        CATALOG_SCHEMA,
        CATALOG_TABLES,
        PROFILE_SCHEMA,
        PROFILE_TABLES,
    )

    expected = (
        {name: PROFILE_SCHEMA for name in PROFILE_TABLES}
        | {name: CALCULATION_SCHEMA for name in CALCULATION_TABLES}
        | {name: CATALOG_SCHEMA for name in CATALOG_TABLES}
    )
    actual = {table.name: table.schema for table in Base.metadata.tables.values()}
    assert actual == expected


def test_foreign_keys_target_schema_qualified_tables():
    import src.models  # noqa: F401

    for table in Base.metadata.tables.values():
        for fk in table.foreign_key_constraints:
            assert fk.referred_table.schema, f"{fk.name} ссылается на таблицу без схемы"


def test_alembic_compares_only_application_schemas():
    """include_name отсекает посторонние схемы, иначе автогенерация предложила бы их удалить."""
    from src.infra.db_schemas import APPLICATION_SCHEMAS, is_compared_schema

    for schema in (*APPLICATION_SCHEMAS, "public", None):
        assert is_compared_schema(schema) is True
    assert is_compared_schema("pg_catalog") is False
    assert is_compared_schema("some_tenant") is False


def test_create_database_runtime_pins_its_schema_map():
    """Карта фиксируется на движке: выбрать её из запроса или сообщения нельзя по построению."""
    from pydantic import SecretStr

    from src.infra.database import RUNTIME_IDENTITIES, create_database_runtime
    from src.infra.db_schemas import CALCULATION_SCHEMA, PROFILE_SCHEMA

    runtime = create_database_runtime(RUNTIME_IDENTITIES[ServiceRuntime.EHR], SecretStr(_TEST_URL))

    schema_map = runtime.engine.get_execution_options()["schema_translate_map"]
    assert schema_map[PROFILE_SCHEMA] == "risk_ehr"
    assert schema_map[CALCULATION_SCHEMA] == "risk_ehr"
    assert runtime.session_factory.kw["bind"] is runtime.engine


def test_create_calculation_runtime_uses_the_calculation_map():
    from pydantic import SecretStr

    from src.infra.database import create_calculation_runtime
    from src.infra.db_schemas import CALCULATION_SCHEMA_MAP

    runtime = create_calculation_runtime(SecretStr(_TEST_URL))

    assert runtime.engine.get_execution_options()["schema_translate_map"] == dict(CALCULATION_SCHEMA_MAP)


async def test_calculation_runtime_is_created_once_and_disposed():
    """Один пул на процесс: пересоздание на каждый пересчёт копило бы соединения расчёта."""
    from src.infra import database
    from src.infra.database import init_calculation_runtime, shutdown_calculation_runtime

    await shutdown_calculation_runtime()

    first = init_calculation_runtime()
    assert init_calculation_runtime() is first

    await shutdown_calculation_runtime()
    assert database._calculation_runtime is None


def test_calculation_runtime_singleton_uses_the_calculation_map():
    """Модели профиля в этом рантайме адресуют локальные представления расчёта, а не таблицы профиля."""
    from src.infra.database import init_calculation_runtime
    from src.infra.db_schemas import CALCULATION_SCHEMA, PROFILE_SCHEMA

    schema_map = init_calculation_runtime().engine.get_execution_options()["schema_translate_map"]

    assert schema_map[PROFILE_SCHEMA] == CALCULATION_SCHEMA
    assert schema_map[CALCULATION_SCHEMA] == CALCULATION_SCHEMA


def test_catalog_schema_is_never_translated():
    """Справочники общие: их адрес одинаков во всех рантаймах, поэтому в картах их нет."""
    from src.infra.db_schemas import (
        CALCULATION_SCHEMA_MAP,
        CATALOG_SCHEMA,
        EHR_SCHEMA_MAP,
        PROFILE_SCHEMA_MAP,
    )

    for schema_map in (PROFILE_SCHEMA_MAP, CALCULATION_SCHEMA_MAP, EHR_SCHEMA_MAP):
        assert CATALOG_SCHEMA not in schema_map


def test_primary_runtime_is_reused_for_the_same_role(no_primary_runtime):
    from src.infra.database import init_primary_runtime

    first = init_primary_runtime(ServiceRuntime.CALCULATION)

    assert init_primary_runtime(ServiceRuntime.CALCULATION) is first
    assert get_primary_runtime() is first


def test_primary_runtime_refuses_a_second_role(no_primary_runtime):
    """Двух основных рантаймов в процессе быть не может: вторая роль — ошибка точки входа."""
    from src.infra.database import ServiceRuntimeMismatchError, init_primary_runtime

    init_primary_runtime(ServiceRuntime.CALCULATION)

    with pytest.raises(ServiceRuntimeMismatchError, match="calculation"):
        init_primary_runtime(ServiceRuntime.PROFILE)


def test_primary_runtime_access_before_init_fails(no_primary_runtime):
    """Обращение к БД до старта — ошибка порядка, а не подключение наугад."""
    from src.infra.database import PrimaryRuntimeNotInitializedError

    with pytest.raises(PrimaryRuntimeNotInitializedError, match="init_primary_runtime"):
        get_primary_runtime()


def test_primary_runtime_requires_only_its_own_url(no_primary_runtime, monkeypatch):
    from src.config import DatabaseConfigError
    from src.infra.database import init_primary_runtime

    monkeypatch.setattr("src.config.settings.ehr_db_url", None)

    with pytest.raises(DatabaseConfigError, match="RISK_MODEL_EHR_DB_URL"):
        init_primary_runtime(ServiceRuntime.EHR)


_ALL_DB_URL_ENVS = (*(db_url_env(runtime) for runtime in ServiceRuntime), "RISK_MODEL_MIGRATIONS_DB_URL")


def _load_db_urls(monkeypatch: pytest.MonkeyPatch, env: dict[str, str | None]) -> None:
    """Прогоняет окружение пода через настоящую загрузку `Settings` (`None` — переменной нет) и
    ставит полученные строки подключения в `settings` процесса."""
    for name, value in env.items():
        if value is None:
            monkeypatch.delenv(name, raising=False)
        else:
            monkeypatch.setenv(name, value)
    loaded = Settings()
    for name in env:
        field = name.removeprefix("RISK_MODEL_").lower()
        monkeypatch.setattr(f"src.config.settings.{field}", getattr(loaded, field))


@pytest.mark.parametrize("others", ["", None], ids=["others-empty", "others-absent"])
@pytest.mark.parametrize("runtime", list(ServiceRuntime))
def test_primary_runtime_starts_whatever_the_other_urls_are(
    no_primary_runtime, monkeypatch, runtime: ServiceRuntime, others: str | None
):
    """Чужие переменные пусты или отсутствуют — процесс стартует по своей."""
    from src.infra.database import init_primary_runtime

    own = db_url_env(runtime)
    _load_db_urls(monkeypatch, {name: _TEST_URL if name == own else others for name in _ALL_DB_URL_ENVS})

    init_primary_runtime(runtime)

    assert get_primary_runtime().engine.url.render_as_string(hide_password=False) == _TEST_URL


@pytest.mark.parametrize("runtime", list(ServiceRuntime))
def test_primary_runtime_refuses_its_own_empty_url(no_primary_runtime, monkeypatch, runtime: ServiceRuntime):
    from src.config import DatabaseConfigError
    from src.infra.database import init_primary_runtime

    own = db_url_env(runtime)
    _load_db_urls(monkeypatch, {name: "" if name == own else _TEST_URL for name in _ALL_DB_URL_ENVS})

    with pytest.raises(DatabaseConfigError, match=own):
        init_primary_runtime(runtime)


async def test_primary_runtime_shutdown_resets_it(no_primary_runtime):
    from src.infra.database import PrimaryRuntimeNotInitializedError, init_primary_runtime, shutdown_primary_runtime

    init_primary_runtime(ServiceRuntime.CALCULATION)
    await shutdown_primary_runtime()

    with pytest.raises(PrimaryRuntimeNotInitializedError):
        get_primary_runtime()
    await shutdown_primary_runtime()  # повторный вызов безопасен


@pytest.mark.parametrize("assume_role", [False, True])
def test_connect_args_switch_role_only_in_shared_login_mode(monkeypatch, assume_role: bool):
    """Стартовый параметр `role` передаётся только в режиме общего логина, и это логин роли."""
    from src.infra.database import RUNTIME_IDENTITIES, _connect_args
    from src.infra.db_schemas import EHR_ROLE

    monkeypatch.setattr("src.infra.database.settings.db_assume_runtime_role", assume_role)

    connect_args = _connect_args(RUNTIME_IDENTITIES[ServiceRuntime.EHR])

    assert connect_args == ({"server_settings": {"role": EHR_ROLE}} if assume_role else {})


def test_runtime_identities_cover_every_runtime():
    """Одна запись на роль: логин, карта схем и переменная меняются только вместе."""
    from src.config import db_url_env
    from src.infra.database import RUNTIME_IDENTITIES
    from src.infra.db_schemas import (
        BULK_RECALC_ROLE,
        BULK_RECALC_SCHEMA_MAP,
        CALCULATION_ROLE,
        CALCULATION_SCHEMA_MAP,
        EHR_ROLE,
        EHR_SCHEMA_MAP,
        PROFILE_ROLE,
        PROFILE_SCHEMA_MAP,
    )

    expected = {
        ServiceRuntime.PROFILE: (PROFILE_ROLE, PROFILE_SCHEMA_MAP),
        ServiceRuntime.CALCULATION: (CALCULATION_ROLE, CALCULATION_SCHEMA_MAP),
        ServiceRuntime.EHR: (EHR_ROLE, EHR_SCHEMA_MAP),
        ServiceRuntime.BULK_RECALC: (BULK_RECALC_ROLE, BULK_RECALC_SCHEMA_MAP),
    }
    assert set(RUNTIME_IDENTITIES) == set(ServiceRuntime)
    for runtime, (login, schema_map) in expected.items():
        identity = RUNTIME_IDENTITIES[runtime]
        assert identity.runtime is runtime
        assert identity.login == login
        assert identity.schema_map is schema_map
        assert identity.url_env == db_url_env(runtime)


async def test_verify_runtime_login_alerts_before_it_raises(caplog: pytest.LogCaptureFixture):
    """Логин из строки подключения — сама граница: расхождение обязано попасть в структурный лог."""
    from src.infra.database import ServiceRuntimeMismatchError, verify_runtime_login
    from src.infra.db_schemas import MIGRATION_ROLE, PROFILE_ROLE
    from src.logger import ALERT

    with caplog.at_level(ALERT, logger="app"), pytest.raises(ServiceRuntimeMismatchError):
        await verify_runtime_login(_engine_answering_current_user(MIGRATION_ROLE), ServiceRuntime.PROFILE)

    records = [r for r in caplog.records if r.message == "runtime login mismatch"]
    assert len(records) == 1
    assert records[0].levelno == ALERT
    assert getattr(records[0], "log_context", {}) == {
        "check": "runtime_login",
        "runtime": "profile",
        "expected": PROFILE_ROLE,
        "actual": MIGRATION_ROLE,
    }


async def test_verify_runtime_login_reports_the_assumed_role(monkeypatch, captured_app_logs):
    """В режиме общего логина на старте видно, под каким логином соединились и в какой переключились."""
    from src.infra.database import verify_runtime_login
    from src.infra.db_schemas import EHR_ROLE, PROFILE_ROLE

    monkeypatch.setattr("src.infra.database.settings.db_assume_runtime_role", True)

    await verify_runtime_login(_engine_answering_current_user(EHR_ROLE, session_user=PROFILE_ROLE), ServiceRuntime.EHR)

    assert captured_app_logs.context_of("db runtime role assumed") == {
        "runtime": "ehr",
        "session_user": PROFILE_ROLE,
        "current_user": EHR_ROLE,
    }


async def test_verify_runtime_login_is_silent_without_shared_login_mode(monkeypatch, captured_app_logs):
    from src.infra.database import verify_runtime_login
    from src.infra.db_schemas import EHR_ROLE

    monkeypatch.setattr("src.infra.database.settings.db_assume_runtime_role", False)

    await verify_runtime_login(_engine_answering_current_user(EHR_ROLE), ServiceRuntime.EHR)

    assert "db runtime role assumed" not in captured_app_logs.messages()


def test_bulk_recalc_runtime_has_no_local_views():
    """Карта продюсера тождественная: локальных представлений у роли нет, он читает физический
    реестр версий и больше ничего."""
    from src.infra.db_schemas import BULK_RECALC_SCHEMA_MAP, CALCULATION_SCHEMA, PROFILE_SCHEMA

    assert BULK_RECALC_SCHEMA_MAP[PROFILE_SCHEMA] == PROFILE_SCHEMA
    assert BULK_RECALC_SCHEMA_MAP[CALCULATION_SCHEMA] == CALCULATION_SCHEMA
