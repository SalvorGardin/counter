from src.exceptions import DbOperationError, NonRetriableDbError, RetriableDbError, RiskBaseError


class TestExceptionHierarchy:
    def test_risk_base_error_is_base_exception(self):
        assert issubclass(RiskBaseError, Exception)

    def test_db_operation_error_inherits_risk_base_error(self):
        assert issubclass(DbOperationError, RiskBaseError)

    def test_retriable_inherits_db_operation_error(self):
        assert issubclass(RetriableDbError, DbOperationError)

    def test_non_retriable_inherits_db_operation_error(self):
        assert issubclass(NonRetriableDbError, DbOperationError)

    def test_db_operation_error_stores_cause_and_attempts(self):
        cause = ValueError("boom")
        err = NonRetriableDbError("msg", cause=cause, attempts=2)
        assert err.cause is cause
        assert err.attempts == 2


class TestSchemaIsolationErrors:
    """Ошибки изоляции схем — доменные: ловятся общим `RiskBaseError` наравне с остальными."""

    def test_service_runtime_mismatch_inherits_risk_base_error(self):
        from src.infra.database import ServiceRuntimeMismatchError

        assert issubclass(ServiceRuntimeMismatchError, RiskBaseError)

    def test_empty_role_password_keeps_value_error_for_configuration_validation(self):
        from src.infra.db_bootstrap import EmptyRolePasswordError

        assert issubclass(EmptyRolePasswordError, RiskBaseError)
        assert issubclass(EmptyRolePasswordError, ValueError)

    def test_unsafe_bootstrap_driver_inherits_risk_base_error(self):
        from src.infra.db_bootstrap import UnsafeBootstrapDriverError

        assert issubclass(UnsafeBootstrapDriverError, RiskBaseError)

    def test_database_config_error_keeps_value_error_for_configuration_validation(self):
        from src.config import DatabaseConfigError

        assert issubclass(DatabaseConfigError, RiskBaseError)
        assert issubclass(DatabaseConfigError, ValueError)
