"""Фейковый DOM и запуск скриптов панели в node.

Панель — статические файлы без сборки, поэтому её правила проверяются исполнением настоящих
скриптов поверх минимального DOM: узлы запоминают только то, о чём спрашивают тесты.
"""

import shutil
import subprocess
from html.parser import HTMLParser
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
WEB = ROOT / "web/questionnaire"

HTML = (WEB / "index.html").read_text(encoding="utf-8")
START_FORM_JS = (WEB / "start_form.js").read_text(encoding="utf-8")

# Диалог подтверждения — обычный узел с showModal/close: тесту важно, открыт он или нет, а не как
# браузер его рисует. Запросы уходят в очередь `requests`, ответы задаёт тест через `responses`.
HARNESS = r"""
class FakeNode {
  constructor(tag = "div") {
    this.tag = tag;
    this.hidden = true;
    this.disabled = false;
    this.open = false;
    this.value = "";
    this.textContent = "";
    this.children = [];
    this.classList = { toggle() {}, add() {}, remove() {} };
    this.listeners = [];
  }
  addEventListener(type, handler) { this.listeners.push({ type, handler }); }
  append(...nodes) { this.children.push(...nodes); }
  replaceChildren(...nodes) { this.children = nodes; }
  querySelectorAll() { return []; }
  showModal() { this.open = true; }
  close() { this.open = false; }
}
const nodes = new Map();
function nodeFor(id) { if (!nodes.has(id)) nodes.set(id, new FakeNode()); return nodes.get(id); }
const document = {
  querySelector: () => nodeFor("card"),
  getElementById: (id) => nodeFor(id),
  createElement: (tag) => new FakeNode(tag),
  addEventListener: () => {},
};
const window = { location: { origin: "http://panel.test" } };
// Шаг биомаркеров живёт в biomarkers.js, который сюда не подключён.
function resetBiomarkerEntries() {}
// Нажатие кнопки: обработчики повешены на узлы при загрузке скрипта.
const click = (id) => nodeFor(id).listeners.find((entry) => entry.type === "click").handler();
const requests = [];
// Каждый ответ — { status, body }; очередь задаёт тест, порядок — порядок запросов панели.
let responses = [];
function respond(url, options) {
  requests.push({ url: String(url), method: options?.method ?? "GET" });
  const next = responses.shift() ?? { status: 200, body: { isSuccess: true } };
  return Promise.resolve({
    ok: next.status < 400,
    status: next.status,
    json: async () => next.body,
  });
}
const fetch = respond;
"""


def run_start_form_script(assertions: str) -> None:
    """Прогоняет проверки поверх настоящего start_form.js."""
    node = shutil.which("node")
    if node is None:
        pytest.skip("node is required to execute the panel rules")

    # Без check=True: CalledProcessError печатает весь склеенный скрипт, и настоящее сообщение
    # проверки тонет в нём. Падение теста — это stderr узла.
    result = subprocess.run(
        [node, "-e", "\n".join((HARNESS, START_FORM_JS, assertions))],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        pytest.fail(result.stderr.strip() or f"node exited with {result.returncode}")


# Пустые теги закрывающего тега не имеют — иначе стек предков разъехался бы на первом же <input>.
_VOID_TAGS = frozenset({"meta", "link", "input", "br", "img"})


class MarkupIndex(HTMLParser):
    """Тег каждого узла с id и множество идентификаторов и классов его предков."""

    def __init__(self) -> None:
        super().__init__()
        self._stack: list[tuple[str | None, set[str]]] = []
        self.ancestors: dict[str, set[str]] = {}
        self.tags: dict[str, str] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        node_id = attributes.get("id")
        if node_id is not None:
            self.tags[node_id] = tag
            self.ancestors[node_id] = {
                value
                for ancestor_id, classes in self._stack
                for value in ({ancestor_id} if ancestor_id is not None else set()) | classes
            }
        if tag not in _VOID_TAGS:
            self._stack.append((node_id, set((attributes.get("class") or "").split())))

    def handle_endtag(self, tag: str) -> None:
        if tag not in _VOID_TAGS and self._stack:
            self._stack.pop()


def index_markup() -> MarkupIndex:
    parser = MarkupIndex()
    parser.feed(HTML)
    return parser
