from tests.unit.web.panel_dom import index_markup, run_start_form_script


def test_start_screen_offers_the_reset_next_to_the_confirmation_dialog() -> None:
    parser = index_markup()

    assert "screen-start" in parser.ancestors["reset-patient-btn"]
    assert "screen-start" in parser.ancestors["start-status"]
    assert parser.tags["reset-patient-dialog"] == "dialog"
    # Диалог вне экрана старта: он не должен прятаться вместе с экраном при переключении.
    assert "screen-start" not in parser.ancestors["reset-patient-dialog"]
    for node_id in ("reset-patient-target", "reset-patient-confirm", "reset-patient-cancel"):
        assert "reset-patient-dialog" in parser.ancestors[node_id]


def test_reset_asks_for_confirmation_before_touching_the_server() -> None:
    """Сброс необратим для живых данных: без подтверждения запрос не уходит."""
    run_start_form_script(r"""
(async () => {
  nodeFor("client-id").value = "panel-reset-1";
  click("reset-patient-btn");
  if (!nodeFor("reset-patient-dialog").open) throw new Error("the reset must open the confirmation dialog");
  if (requests.length !== 0) throw new Error("no request may be sent before the reset is confirmed");
  if (nodeFor("reset-patient-target").textContent !== "panel-reset-1") {
    throw new Error("the dialog must name the clientId the reset will be sent for");
  }

  click("reset-patient-cancel");
  if (nodeFor("reset-patient-dialog").open) throw new Error("cancelling must close the dialog");
  if (requests.length !== 0) throw new Error("a cancelled reset must not reach the server");
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_confirmed_reset_sends_one_system_code_per_system() -> None:
    """answers-reset требует системы явно, а список систем знает только сервер."""
    run_start_form_script(r"""
(async () => {
  responses = [
    { status: 200, body: { isSuccess: true, systemInterpretationResults: [
      { systemCode: "CVD" }, { systemCode: "RESP" },
    ] } },
    { status: 202, body: { isSuccess: true } },
  ];
  nodeFor("client-id").value = "panel-reset-2";
  state.hasAnswers = true;

  click("reset-patient-btn");
  await click("reset-patient-confirm");

  if (nodeFor("reset-patient-dialog").open) throw new Error("confirming must close the dialog");
  if (requests.length !== 2) throw new Error(`expected the risk and the reset request, got ${requests.length}`);
  if (requests[0].url !== "http://panel.test/api/v1/clients/panel-reset-2/medical-risk") {
    throw new Error(`the system list must come from the server, got ${requests[0].url}`);
  }
  const reset = requests[1];
  if (reset.method !== "POST") throw new Error("answers-reset is an event and is posted");
  const expected = "http://panel.test/api/v1/clients/panel-reset-2/medical-risk/events/answers-reset"
    + "?systemCode=CVD&systemCode=RESP";
  if (reset.url !== expected) throw new Error(`every system must be passed, got ${reset.url}`);
  if (state.hasAnswers !== false) throw new Error("a reset patient starts the questionnaire from scratch");
  if (nodeFor("start-status").hidden) throw new Error("the outcome of the reset must be reported");
  if (nodeFor("client-id").value !== "panel-reset-2") {
    throw new Error("the reset keeps the patient: it is the same clientId that is passed again");
  }
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_reset_rejects_an_invalid_client_id_without_opening_the_dialog() -> None:
    run_start_form_script(r"""
(async () => {
  nodeFor("client-id").value = "нет";
  click("reset-patient-btn");
  if (nodeFor("reset-patient-dialog").open) throw new Error("an invalid clientId has nothing to confirm");
  if (nodeFor("start-error").hidden) throw new Error("the clientId error must be shown");
  if (requests.length !== 0) throw new Error("no request may be sent for an invalid clientId");
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_failed_reset_is_reported_as_an_error() -> None:
    """Ошибка сброса не должна выглядеть как успешный сброс: прогресс панели остаётся."""
    run_start_form_script(r"""
(async () => {
  responses = [{ status: 404, body: { isSuccess: false, error: { code: "CLIENT_NOT_FOUND", message: "нет" } } }];
  nodeFor("client-id").value = "panel-reset-3";
  state.hasAnswers = true;

  click("reset-patient-btn");
  await click("reset-patient-confirm");

  if (nodeFor("start-error").hidden) throw new Error("a failed reset must be reported");
  if (!nodeFor("start-status").hidden) throw new Error("a failed reset must not report success");
  if (state.hasAnswers !== true) throw new Error("a failed reset must not forget the panel progress");
  if (nodeFor("reset-patient-btn").disabled) throw new Error("the reset must stay available after a failure");
})().catch((error) => { console.error(error); process.exit(1); });
""")
