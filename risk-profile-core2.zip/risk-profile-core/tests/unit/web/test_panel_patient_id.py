from tests.unit.web.panel_dom import index_markup, run_start_form_script

# Экраны опроса и узел, которым каждый называет своего пациента.
PATIENT_ID_NODES = {
    "screen-biomarkers": "biomarkers-patient-id",
    "screen-question": "question-patient-id",
    "screen-final": "final-patient-id",
}


def test_every_questionnaire_screen_names_its_patient_in_the_header() -> None:
    parser = index_markup()

    for screen, node_id in PATIENT_ID_NODES.items():
        assert screen in parser.ancestors[node_id]
        assert "patient-id" in parser.ancestors[node_id]

    # Шапки у экранов разные, но идентификатор стоит в каждой, а не в теле экрана.
    assert "screen-header" in parser.ancestors["biomarkers-patient-id"]
    assert "q-header" in parser.ancestors["question-patient-id"]
    assert "final-header" in parser.ancestors["final-patient-id"]


def test_screen_switch_writes_the_current_patient_into_every_header() -> None:
    """Идентификатор пишется на смене экрана — тогда его негде забыть обновить."""
    run_start_form_script(r"""
(async () => {
  const headers = ["biomarkers-patient-id", "question-patient-id", "final-patient-id"];
  state.clientId = "panel-shown-1";
  showScreen("question");
  for (const id of headers) {
    if (nodeFor(id).textContent !== "panel-shown-1") {
      throw new Error(`${id} must name the current patient, got ${nodeFor(id).textContent}`);
    }
  }

  // Новый пациент проходит стартовую форму: до неё называть в шапках некого.
  startNewPatient();
  for (const id of headers) {
    if (nodeFor(id).textContent !== "") throw new Error(`${id} must not keep the previous patient`);
  }
})().catch((error) => { console.error(error); process.exit(1); });
""")
