from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HTML = (ROOT / "web/questionnaire/index.html").read_text(encoding="utf-8")

SUMMARY = "results-summary"
DETAIL = "results-detail"


class _AreaParser(HTMLParser):
    """Собирает для каждого id классы его предков: важно не наличие блока, а область, в которой он лежит."""

    def __init__(self) -> None:
        super().__init__()
        self.stack: list[set[str]] = []
        self.areas: dict[str, set[str]] = {}
        self.scripts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        src = attributes.get("src")
        if tag == "script" and src is not None:
            self.scripts.append(src)
        # void-элементы не попадают в handle_endtag, поэтому в стек их не кладём
        if tag in {"meta", "link", "input", "br", "img"}:
            return
        classes = set((attributes.get("class") or "").split())
        node_id = attributes.get("id")
        if node_id is not None:
            self.areas[node_id] = {name for ancestor in self.stack for name in ancestor}
        self.stack.append(classes)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"meta", "link", "input", "br", "img"}:
            return
        if self.stack:
            self.stack.pop()


def _parsed() -> _AreaParser:
    parser = _AreaParser()
    parser.feed(HTML)
    return parser


def test_results_screen_is_split_into_summary_and_detail() -> None:
    parser = _parsed()

    assert SUMMARY in parser.areas["risk-results"]
    assert SUMMARY in parser.areas["recommendations"]
    for block in ("calc-explanation", "biomarker-interpretation", "user-info"):
        assert DETAIL in parser.areas[block], block
        assert SUMMARY not in parser.areas[block], block


def test_script_order_is_preserved() -> None:
    parser = _parsed()

    assert parser.scripts.index("biomarker_outcomes.js") < parser.scripts.index("final_page.js")
    assert parser.scripts.index("final_page.js") < parser.scripts.index("explanation.js")
