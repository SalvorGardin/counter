from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HTML = (ROOT / "web/questionnaire/index.html").read_text(encoding="utf-8")
JS = (ROOT / "web/questionnaire/data_download.js").read_text(encoding="utf-8")


class _DownloadButtonParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.button_found = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == "button" and attributes.get("id") == "download-data-btn":
            self.button_found = True


def test_download_button_sends_authenticated_request_for_encoded_patient() -> None:
    parser = _DownloadButtonParser()
    parser.feed(HTML)

    assert parser.button_found
    assert "/patients/${encodeURIComponent(patientId)}/export" in JS
    assert 'fetch(url, { headers: { "X-Test-Api-Key": window.TEST_TOKEN } })' in JS
