import shutil
import subprocess
from html.parser import HTMLParser
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
HTML = (ROOT / "web/questionnaire/index.html").read_text(encoding="utf-8")
START_FORM_JS = (ROOT / "web/questionnaire/start_form.js").read_text(encoding="utf-8")
QUESTIONNAIRE_JS = (ROOT / "web/questionnaire/main_questionnaire.js").read_text(encoding="utf-8")

# Фейковый DOM для прогона правил навигации в node: узлы запоминают тег, классы, детей и
# подписки, чтобы тест мог отличить кнопку системы от справочной строки общих вопросов.
HARNESS = r"""
class FakeClassList {
  constructor() { this.values = new Set(); }
  toggle(name, enabled) { if (enabled) this.values.add(name); else this.values.delete(name); }
  add(name) { this.values.add(name); }
  remove(name) { this.values.delete(name); }
  contains(name) { return this.values.has(name); }
}
class FakeNode {
  constructor(tag = "div") {
    this.tag = tag;
    this.hidden = true;
    this.disabled = false;
    this.value = "";
    this.textContent = "";
    this.className = "";
    this.classList = new FakeClassList();
    this.style = {};
    this.children = [];
    this.listeners = [];
  }
  addEventListener(type, handler) { this.listeners.push({ type, handler }); }
  append(...nodes) { this.children.push(...nodes); }
  replaceChildren(...nodes) { this.children = nodes; }
  querySelectorAll() { return []; }
  setAttribute() {}
  focus() {}
}
const nodes = new Map();
function nodeFor(id) { if (!nodes.has(id)) nodes.set(id, new FakeNode()); return nodes.get(id); }
const document = {
  querySelector: () => nodeFor("card"),
  getElementById: (id) => nodeFor(id),
  createElement: (tag) => new FakeNode(tag),
  addEventListener: () => {},
};
const window = { location: { origin: "http://panel.test" } };
const RESULTS_MODE_FINAL = "final";
let shownResultsMode = null;
function showResults(mode) { shownResultsMode = mode; }
// Перерисовка списка идёт фоновым запросом: тесту нужно отдать очередь микрозадач и таймеров.
const flush = () => new Promise((resolve) => setTimeout(resolve, 0));
const navigationItems = () => nodeFor("question-systems-list").children;
"""


def _run_navigation_script(assertions: str) -> None:
    node = shutil.which("node")
    if node is None:
        pytest.skip("node is required to execute the questionnaire navigation rules")

    # Без check=True: CalledProcessError печатает весь склеенный скрипт, и настоящее сообщение
    # проверки тонет в нём. Падение теста — это stderr узла.
    result = subprocess.run(
        [node, "-e", "\n".join((HARNESS, START_FORM_JS, QUESTIONNAIRE_JS, assertions))],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        pytest.fail(result.stderr.strip() or f"node exited with {result.returncode}")


class _QuestionScreenParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.stack: list[tuple[str, str | None, set[str]]] = []
        self.ancestors: dict[str, set[str]] = {}
        self.tags: dict[str, str] = {}
        self.scripts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        node_id = attributes.get("id")
        if node_id is not None:
            self.tags[node_id] = tag
            self.ancestors[node_id] = {
                value
                for _, ancestor_id, classes in self.stack
                for value in ({ancestor_id} if ancestor_id is not None else set()) | classes
            }
        script_src = attributes.get("src")
        if tag == "script" and script_src is not None:
            self.scripts.append(script_src)
        if tag not in {"meta", "link", "input", "br", "img"}:
            self.stack.append((tag, node_id, set((attributes.get("class") or "").split())))

    def handle_endtag(self, tag: str) -> None:
        if tag not in {"meta", "link", "input", "br", "img"} and self.stack:
            self.stack.pop()


def test_question_screen_contains_navigation_and_current_question_areas() -> None:
    parser = _QuestionScreenParser()
    parser.feed(HTML)

    assert parser.tags["question-systems-list"] == "div"
    assert parser.tags["question-systems-error"] == "p"
    assert "screen-question" in parser.ancestors["question-systems-list"]
    assert "question-systems" in parser.ancestors["question-systems-list"]
    assert "question-systems" in parser.ancestors["question-systems-error"]
    for node_id in ("system-name", "question-text", "answer-form"):
        assert "screen-question" in parser.ancestors[node_id]
        assert "question-current" in parser.ancestors[node_id]


def test_questionnaire_scripts_and_v2_request_are_wired_in_dependency_order() -> None:
    parser = _QuestionScreenParser()
    parser.feed(HTML)

    assert parser.scripts.index("start_form.js") < parser.scripts.index("biomarkers.js")
    assert parser.scripts.index("biomarkers.js") < parser.scripts.index("main_questionnaire.js")
    assert parser.scripts.index("main_questionnaire.js") < parser.scripts.index("final_page.js")
    assert "/api/v2/clients/${encodeURIComponent(state.clientId)}/questions/answers" in START_FORM_JS
    assert "postJson(path, { questionCode, systemCode }, body)" in START_FORM_JS


def test_navigation_rules_execute_in_browser_script() -> None:
    _run_navigation_script(r"""
(async () => {
  const question = { questionCode: "common-q", type: "select", text: "Общий вопрос", isSkippable: true };
  getMedicalRisk = async () => ({ systemInterpretationResults: [] });
  state.selectedSystemCode = "CVD";
  state.navigationSystems = [
    { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 10 },
    { systemCode: "RESP", systemName: "Дыхательная", systemCompletionPercentage: 20 },
  ];

  advance({ systemCode: "COMMON", systemName: "Общие", systemCompletionPercentage: 30, question });
  if (state.selectedSystemCode !== "CVD" || state.systemCode !== "COMMON") {
    throw new Error("a common question must not replace the selected system");
  }

  state.navigationSystems = [
    { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 10 },
    { systemCode: "RESP", systemName: "Дыхательная", systemCompletionPercentage: 20 },
  ];
  updateNavigationProgress({ systemCode: "COMMON", systemCompletionPercentage: 45 }, "CVD");
  if (state.navigationSystems[0].systemCompletionPercentage !== 45) {
    throw new Error("progress must belong to the requested system");
  }

  const calls = [];
  postAnswer = async (questionCode, body, systemCode) => {
    calls.push({ questionCode, body, systemCode });
    return {
      systemCode: "RESP",
      systemName: "Дыхательная",
      systemCompletionPercentage: 20,
      question: { questionCode: "resp-q", type: "select", text: "Вопрос", isSkippable: false },
    };
  };
  await advanceAfterRequest(
    { systemCode: null, systemName: null, systemCompletionPercentage: 100, question: null },
    "CVD",
  );
  if (calls.length !== 1 || calls[0].systemCode !== null || state.selectedSystemCode !== "RESP") {
    throw new Error("system completion must request an unscoped question and select its system");
  }

  shownResultsMode = null;
  calls.length = 0;
  await advanceAfterRequest(
    { systemCode: null, systemName: null, systemCompletionPercentage: 100, question: null },
    null,
  );
  if (shownResultsMode !== RESULTS_MODE_FINAL || calls.length !== 0) {
    throw new Error("only an empty unscoped response may open final results");
  }
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_shown_question_reloads_the_whole_system_list() -> None:
    """Ответ несёт процент одной системы, а двигает несколько — список перечитывается целиком."""
    _run_navigation_script(r"""
(async () => {
  const question = { questionCode: "cvd-q", type: "select", text: "Вопрос", isSkippable: true };
  let requests = 0;
  getMedicalRisk = async () => {
    requests += 1;
    return { systemInterpretationResults: [
      { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 40 },
      { systemCode: "RESP", systemName: "Дыхательная", systemCompletionPercentage: 55 },
    ] };
  };
  state.selectedSystemCode = "CVD";
  state.navigationSystems = [
    { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 10 },
    { systemCode: "RESP", systemName: "Дыхательная", systemCompletionPercentage: 20 },
  ];

  advance({ systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 40, question });
  await flush();
  if (requests !== 1) throw new Error("a shown question must reload the system list");
  const percentages = state.navigationSystems.map((system) => system.systemCompletionPercentage);
  if (percentages.join(",") !== "40,55") {
    throw new Error(`every system must take the reloaded percentage, got ${percentages.join(",")}`);
  }

  // Экран результатов ведёт свой опрос расчёта: перечитывать список туда не за чем.
  requests = 0;
  postAnswer = async () => { throw new Error("no request expected"); };
  await advanceAfterRequest(
    { systemCode: null, systemName: null, systemCompletionPercentage: 100, question: null },
    null,
  );
  await flush();
  if (requests !== 0) throw new Error("leaving for results must not reload the system list");
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_stale_system_list_response_does_not_overwrite_a_newer_one() -> None:
    """Быстрые ответы дают наложение запросов: применяется только самый свежий."""
    _run_navigation_script(r"""
(async () => {
  const question = { questionCode: "cvd-q", type: "select", text: "Вопрос", isSkippable: true };
  const pending = [];
  getMedicalRisk = () => new Promise((resolve) => { pending.push(resolve); });
  state.navigationSystems = [{ systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 10 }];

  advance({ systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 20, question });
  advance({ systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 30, question });
  if (pending.length !== 2) throw new Error("each shown question must issue its own reload");

  pending[1]({ systemInterpretationResults: [
    { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 30 },
  ] });
  await flush();
  pending[0]({ systemInterpretationResults: [
    { systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 20 },
  ] });
  await flush();

  if (state.navigationSystems[0].systemCompletionPercentage !== 30) {
    throw new Error("a late earlier response must not repaint the list with stale percentages");
  }
})().catch((error) => { console.error(error); process.exit(1); });
""")


def test_common_questions_are_listed_as_a_reference_row() -> None:
    """COMMON нет в medical-risk и нет заполненности: строка справочная и не выбирается."""
    _run_navigation_script(r"""
(async () => {
  getMedicalRisk = async () => ({ systemInterpretationResults: [] });
  state.navigationSystems = [{ systemCode: "CVD", systemName: "ССЗ", systemCompletionPercentage: 10 }];
  state.selectedSystemCode = "CVD";
  state.systemCode = "CVD";

  renderSystemNavigation();
  const [common, cvd] = navigationItems();
  if (navigationItems().length !== 2) throw new Error("the common row must precede the server systems");
  if (common.tag === "button" || common.listeners.length !== 0) {
    throw new Error("the common row must not be selectable: systemCode=COMMON ends the questionnaire");
  }
  if (common.children.length !== 1) throw new Error("the common row must not show a completion percentage");
  if (common.children[0].textContent !== "Общие вопросы") {
    throw new Error(`the common row must be named after the catalog, got ${common.children[0].textContent}`);
  }
  if (cvd.tag !== "button" || cvd.children.length !== 2) throw new Error("system rows keep their percentage");
  if (common.classList.contains("current")) throw new Error("the common row is marked only on a common question");

  state.systemCode = "COMMON";
  renderSystemNavigation();
  if (!navigationItems()[0].classList.contains("current")) {
    throw new Error("a common question must mark the common row");
  }
})().catch((error) => { console.error(error); process.exit(1); });
""")
