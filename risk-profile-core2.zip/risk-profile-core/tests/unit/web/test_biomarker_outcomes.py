import json
import shutil
import subprocess
from html.parser import HTMLParser
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
HTML = (ROOT / "web/questionnaire/index.html").read_text(encoding="utf-8")
HELPER = ROOT / "web/questionnaire/biomarker_outcomes.js"


class _PanelParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.ids: set[str] = set()
        self.scripts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        node_id = attributes.get("id")
        if node_id is not None:
            self.ids.add(node_id)
        src = attributes.get("src")
        if tag == "script" and src is not None:
            self.scripts.append(src)


def test_biomarker_outcome_panel_loads_helper_before_final_page() -> None:
    parser = _PanelParser()
    parser.feed(HTML)

    assert {"biomarker-interpretation", "biomarker-interpretation-error"} <= parser.ids
    assert parser.scripts.index("biomarker_outcomes.js") < parser.scripts.index("final_page.js")


def test_biomarker_outcomes_include_only_clinrec_rows_and_join_by_system_code() -> None:
    node = shutil.which("node")
    if node is None:
        pytest.skip("node is required to execute the browser correlation helper")
    payload = {
        "medicalRisk": {
            "systemInterpretationResults": [
                {"systemCode": "BLOOD", "systemName": "Кровь"},
                {"systemCode": "CVD", "systemName": "ССЗ"},
            ]
        },
        "results": [
            {"instrumentCode": "biomarker_kr", "diseaseCode": "D1", "systemCode": "BLOOD"},
            {"instrumentCode": "biomarker_kr", "diseaseCode": "D2", "systemCode": "UNKNOWN"},
            {"instrumentCode": "form_blood", "diseaseCode": None, "systemCode": "BLOOD"},
        ],
    }
    script = (
        "const fs=require('fs');"
        "const input=JSON.parse(fs.readFileSync(0,'utf8'));"
        f"const helper=require({json.dumps(str(HELPER))});"
        "process.stdout.write(JSON.stringify(helper.buildBiomarkerClinicalOutcomes(input.medicalRisk,input.results)));"
    )

    completed = subprocess.run(
        [node, "-e", script],
        input=json.dumps(payload),
        capture_output=True,
        check=True,
        text=True,
    )
    outcomes = json.loads(completed.stdout)

    assert [item["result"]["diseaseCode"] for item in outcomes] == ["D1", "D2"]
    assert outcomes[0]["system"]["systemCode"] == "BLOOD"
    assert outcomes[1]["system"] is None
