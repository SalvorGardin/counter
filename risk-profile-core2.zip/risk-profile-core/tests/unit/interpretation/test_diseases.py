"""Группы заболеваний по результатам калькуляторов и опросников — `InstrumentDiseaseResolver`.

Разметка приходит готовой из каталога: только активные `calc`/`form`, только группы своей системы.
Поэтому здесь она задаётся литералом, а правила построения разметки проверяются тестами каталога.
"""

from src.interpretation.domain.diseases import InstrumentDiseaseResolver
from src.interpretation.domain.models import InterpretationReasonCode, ResultRow

_MARKUP: dict[tuple[str, str], tuple[str, ...]] = {
    ("ENDO", "findrisk"): ("diabetes_mellitus",),
    ("ENDO", "form_dm2"): ("diabetes_mellitus",),
    ("ENDO", "half_frax"): ("osteoporosis",),
    ("GI", "form_gi"): ("gastritis",),
    ("CVD", "ckd_cvd"): ("infarction_ischemic_stroke",),
    ("URO", "ckd_cvd"): ("renal_failure",),
}


def _row(instrument: str, risk_level: str | None, applicability: bool = True) -> ResultRow:
    return ResultRow(instrument_code=instrument, risk_level=risk_level, applicability=applicability)


def _resolve(system_code: str, *rows: ResultRow) -> list[str] | None:
    return InstrumentDiseaseResolver(_MARKUP).resolve(system_code, rows).value


def test_medium_and_high_confirm_the_group() -> None:
    assert _resolve("ENDO", _row("findrisk", "medium")) == ["diabetes_mellitus"]
    assert _resolve("ENDO", _row("findrisk", "high")) == ["diabetes_mellitus"]


def test_other_significant_risk_does_not_exclude_the_group() -> None:
    """Инструмент без групп с высоким риском больше не обнуляет заболевания системы."""
    assert _resolve("ENDO", _row("findrisk", "high"), _row("form_endo", "high")) == ["diabetes_mellitus"]


def test_inapplicable_result_adds_nothing() -> None:
    assert _resolve("ENDO", _row("findrisk", "high", applicability=False)) is None


def test_low_or_missing_level_adds_nothing() -> None:
    assert _resolve("ENDO", _row("findrisk", "low")) is None
    assert _resolve("ENDO", _row("findrisk", None)) is None


def test_instrument_without_markup_adds_nothing() -> None:
    """Неактивный инструмент, инструмент другого типа или без групп в разметку каталога не попадает."""
    assert _resolve("ENDO", _row("old_findrisk", "high")) is None


def test_different_groups_are_kept_together() -> None:
    assert _resolve("ENDO", _row("findrisk", "medium"), _row("half_frax", "high")) == [
        "diabetes_mellitus",
        "osteoporosis",
    ]


def test_same_code_from_two_instruments_is_kept_once() -> None:
    assert _resolve("ENDO", _row("findrisk", "high"), _row("form_dm2", "medium")) == ["diabetes_mellitus"]


def test_same_instrument_in_two_rows_is_kept_once() -> None:
    assert _resolve("ENDO", _row("findrisk", "high"), _row("findrisk", "medium")) == ["diabetes_mellitus"]


def test_only_groups_of_the_current_system_are_taken() -> None:
    """Инструмент нескольких систем даёт каждой системе только её группы."""
    assert _resolve("CVD", _row("ckd_cvd", "high")) == ["infarction_ischemic_stroke"]
    assert _resolve("URO", _row("ckd_cvd", "high")) == ["renal_failure"]


def test_any_system_with_markup_gets_groups() -> None:
    """Правил по системам больше нет: группу получает любая система, где есть разметка."""
    assert _resolve("GI", _row("form_gi", "high")) == ["gastritis"]


def test_no_medium_high_results_reason() -> None:
    outcome = InstrumentDiseaseResolver(_MARKUP).resolve("ENDO", [_row("findrisk", "low")])
    assert outcome.value is None
    assert outcome.reason_code is InterpretationReasonCode.NO_MEDIUM_HIGH_RESULTS


def test_no_results_reason_is_no_medium_high_results() -> None:
    outcome = InstrumentDiseaseResolver(_MARKUP).resolve("ENDO", [])
    assert outcome.reason_code is InterpretationReasonCode.NO_MEDIUM_HIGH_RESULTS


def test_no_group_matched_reason() -> None:
    outcome = InstrumentDiseaseResolver(_MARKUP).resolve("ENDO", [_row("form_endo", "high")])
    assert outcome.value is None
    assert outcome.reason_code is InterpretationReasonCode.NO_GROUP_MATCHED


def test_confirmed_groups_have_no_reason() -> None:
    outcome = InstrumentDiseaseResolver(_MARKUP).resolve("ENDO", [_row("findrisk", "high")])
    assert outcome.reason_code is None
