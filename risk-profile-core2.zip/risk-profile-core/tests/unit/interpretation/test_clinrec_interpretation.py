"""Клинрек-источник интерпретации: отбор факторов, заболевания и риск системы — без базы."""

from datetime import UTC, datetime
from decimal import Decimal

from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.patients.dtos import ActiveParameter
from src.interpretation.computing import SystemInterpreter
from src.interpretation.domain.clinrec_factors import applicable_clinrec_disease_codes, select_clinrec_factors
from src.interpretation.domain.models import ResultRow
from src.interpretation.loading import LoadedInterpretationData
from src.interpretation.reason_collector import InterpretationReasonCollector
from tests.catalog_builder import (
    biomarker,
    biomarker_mapping,
    disease,
    instrument,
    instrument_parameter,
    make_catalog,
    parameter,
    risk_factor,
    risk_factor_score,
    risk_factor_system,
    risk_factor_trigger,
    score,
    system_instrument,
)
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_GENDER

SYSTEM = "ENDO"
OTHER_SYSTEM = "CVD"
PATIENT = "p1"
BIOMARKER_KR = "biomarker_kr"
# Группа заболеваний фигурирует в тесте кодом: и `instruments.diseases`, и итог интерпретации
# хранят `diseases.code`. Описание нужно только справочнику.
DIABETES_GROUP = "diabetes_mellitus"
DIABETES_NAME = "Сахарный диабет"
LDL = "biomarker_ldl"
_NOW = datetime(2026, 1, 1, tzinfo=UTC)


def _catalog(**overrides: tuple) -> InterpretationCatalog:
    """Каталог с одной группой заболеваний ENDO и одним клинрек-фактором на биомаркере."""
    tables: dict[str, tuple] = {
        "instruments": (
            instrument(BIOMARKER_KR, type="biomarker_kr", instrument_id=1),
            instrument("findrisk_t", type="calc", instrument_id=2, diseases=[DIABETES_GROUP]),
        ),
        # Параметр-биомаркер обязан быть активным И связанным с `biomarker_kr` через
        # `instruments_parameters` — тот же отбор, по которому его берёт расчёт.
        "parameters": (parameter(LDL), parameter("smoking_t")),
        "instruments_parameters": (
            instrument_parameter("findrisk_t", "smoking_t", is_required=True),
            instrument_parameter(BIOMARKER_KR, LDL, is_required=False),
        ),
        "systems_instruments": (
            system_instrument(SYSTEM, BIOMARKER_KR),
            system_instrument(OTHER_SYSTEM, BIOMARKER_KR),
            system_instrument(SYSTEM, "findrisk_t"),
        ),
        "diseases": (disease(DIABETES_GROUP, SYSTEM, description=DIABETES_NAME),),
        "risk_factors": (
            risk_factor("rf_ldl", description="ЛПНП повышен", risk_factor_id=10),
            risk_factor("rf_smoke", description="курит", risk_factor_id=20),
        ),
        "risk_factor_systems": (
            risk_factor_system("rf_ldl", SYSTEM, reasoning="почему ЛПНП"),
            risk_factor_system("rf_smoke", SYSTEM, reasoning=None),
        ),
        "risk_factor_triggers": (
            risk_factor_trigger("rf_ldl", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=1),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=2),
        ),
        "risk_factor_scores": (risk_factor_score("rf_ldl", DIABETES_GROUP, score=3),),
        "parameter_scores": (score("smoking_t", SYSTEM, value="yes", score=Decimal("2")),),
    }
    tables.update(overrides)
    return InterpretationCatalog(make_catalog(**tables))


def _loaded(results: list[ResultRow], values: dict[str, str]) -> LoadedInterpretationData:
    parameters = {
        code: ActiveParameter(code, value, _NOW, _NOW, index)
        for index, (code, value) in enumerate(values.items(), start=1)
    }
    return LoadedInterpretationData(
        systems=(SYSTEM,),
        results_by_system={SYSTEM: results},
        patient_parameters=parameters,
        patient_values=values,
        gender=values.get(PARAMETER_CODE_GENDER),
        systems_by_instrument={},
    )


def _clinrec_result(*, applicability: bool = True, disease_code: str = DIABETES_GROUP) -> ResultRow:
    return ResultRow(
        instrument_code=BIOMARKER_KR,
        risk_level="high" if applicability else None,
        applicability=applicability,
        disease_code=disease_code,
    )


def _interpret(catalog: InterpretationCatalog, loaded: LoadedInterpretationData):
    interpreter = SystemInterpreter(catalog, InterpretationReasonCollector())
    return interpreter.interpret(PATIENT, loaded).interpretations[SYSTEM]


_NORMALIZED_OLD = "lipoprotein_a_old"
_NORMALIZED_NEW = "lipoprotein_a_new"
_BIOMARKER_OLD = "biomarker_lpa_old"
_BIOMARKER_NEW = "biomarker_lpa_new"


def _duplicate_case(
    excluded_by_instrument: dict[str, frozenset[str]] | None = None,
) -> tuple[InterpretationCatalog, LoadedInterpretationData]:
    """Старые значения одного биомаркера срабатывают по условиям обоих источников, свежие — нет."""
    normalized_old, normalized_new = _NORMALIZED_OLD, _NORMALIZED_NEW
    biomarker_old, biomarker_new = _BIOMARKER_OLD, _BIOMARKER_NEW
    catalog = _catalog(
        parameters=tuple(parameter(code) for code in (normalized_old, normalized_new, biomarker_old, biomarker_new)),
        biomarkers=(biomarker(96, biomarker_old), biomarker(96, biomarker_new)),
        biomarker_parameter_mappings=(
            biomarker_mapping(biomarker_old, normalized_old),
            biomarker_mapping(biomarker_new, normalized_new),
        ),
        instruments_parameters=(
            instrument_parameter("findrisk_t", normalized_old),
            instrument_parameter("findrisk_t", normalized_new),
            instrument_parameter(BIOMARKER_KR, biomarker_old),
            instrument_parameter(BIOMARKER_KR, biomarker_new),
        ),
        risk_factors=(
            risk_factor("rf_scored_old", risk_factor_id=30),
            risk_factor("rf_clinrec_old", risk_factor_id=31),
        ),
        risk_factor_systems=(
            risk_factor_system("rf_scored_old", SYSTEM),
            risk_factor_system("rf_clinrec_old", SYSTEM),
        ),
        risk_factor_triggers=(
            risk_factor_trigger("rf_scored_old", SYSTEM, normalized_old, value_text="yes", trigger_id=30),
            risk_factor_trigger("rf_clinrec_old", SYSTEM, biomarker_old, value_text="yes", trigger_id=31),
        ),
        parameter_scores=(score(normalized_old, SYSTEM, value="yes", score=Decimal("2")),),
        risk_factor_scores=(risk_factor_score("rf_clinrec_old", DIABETES_GROUP, score=3),),
    )
    later = _NOW.replace(second=1)
    parameters = {
        normalized_old: ActiveParameter(normalized_old, "yes", later, _NOW, 1),
        normalized_new: ActiveParameter(normalized_new, "no", later, later, 2),
        biomarker_old: ActiveParameter(biomarker_old, "yes", later, _NOW, 3),
        biomarker_new: ActiveParameter(biomarker_new, "no", later, later, 4),
    }
    loaded = LoadedInterpretationData(
        systems=(SYSTEM,),
        results_by_system={SYSTEM: [_clinrec_result()]},
        patient_parameters=parameters,
        patient_values={code: row.value for code, row in parameters.items()},
        gender=None,
        systems_by_instrument={},
        excluded_by_instrument=excluded_by_instrument,
    )
    return catalog, loaded


def test_duplicate_biomarkers_are_filtered_in_both_factor_sources() -> None:
    catalog, loaded = _duplicate_case()

    assert _interpret(catalog, loaded).risk_factors == []


def test_passed_exclusions_replace_recomputed_ones() -> None:
    """Отсев, переданный вызывающим, берётся как есть и не пересчитывается по снимку.

    Переданный отсев намеренно обратный собственному: вытеснены свежие значения. Сработавшие
    факторы на старых значениях доказывают, что отбор взял именно его.
    """
    catalog, loaded = _duplicate_case(
        {"findrisk_t": frozenset({_NORMALIZED_NEW}), BIOMARKER_KR: frozenset({_BIOMARKER_NEW})},
    )

    assert {row.code for row in _interpret(catalog, loaded).risk_factors} == {"rf_scored_old", "rf_clinrec_old"}


def test_applicable_clinrec_result_raises_system_risk_to_high() -> None:
    interpretation = _interpret(_catalog(), _loaded([_clinrec_result()], {LDL: "5"}))
    assert interpretation.risk_level == "high"


def test_cleared_clinrec_result_does_not_raise_risk() -> None:
    interpretation = _interpret(_catalog(), _loaded([_clinrec_result(applicability=False)], {LDL: "5"}))
    assert interpretation.risk_level is None


def test_non_biomarker_result_with_disease_code_is_not_a_clinrec_source() -> None:
    result = ResultRow(
        instrument_code="findrisk_t",
        risk_level="high",
        applicability=True,
        disease_code=DIABETES_GROUP,
    )

    interpretation = _interpret(_catalog(), _loaded([result], {LDL: "5"}))

    assert interpretation.risk_factors == []


def test_clinrec_factor_and_disease_are_selected_together() -> None:
    interpretation = _interpret(_catalog(), _loaded([_clinrec_result()], {LDL: "5"}))
    assert [factor.code for factor in interpretation.risk_factors] == ["rf_ldl"]
    assert interpretation.diseases == [DIABETES_GROUP]


def test_applicable_result_without_matched_factor_adds_no_disease() -> None:
    """Строка результата применима, но биомаркер уже не превышает порог — ни фактора, ни группы."""
    interpretation = _interpret(_catalog(), _loaded([_clinrec_result()], {LDL: "1"}))
    assert interpretation.risk_factors == []
    assert interpretation.diseases is None


def test_expired_biomarker_gives_no_factor() -> None:
    """В снимке только актуальные ответы: истёкшего биомаркера в нём нет — фактор не отбирается."""
    interpretation = _interpret(_catalog(), _loaded([_clinrec_result()], {}))
    assert interpretation.risk_factors == []
    assert interpretation.diseases is None


def test_factor_without_system_link_is_not_selected() -> None:
    """Фактор связан только с другой системой: без строки `risk_factor_systems` текущей системы
    его нечем показать, поэтому в отбор он не идёт."""
    catalog = _catalog(
        risk_factor_systems=(
            risk_factor_system("rf_ldl", OTHER_SYSTEM, reasoning=None),
            risk_factor_system("rf_smoke", SYSTEM, reasoning=None),
        ),
        risk_factor_triggers=(
            risk_factor_trigger("rf_ldl", OTHER_SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=1),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=2),
        ),
    )
    interpretation = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5"}))
    assert interpretation.risk_factors == []


def test_trigger_system_code_does_not_restrict_the_clinrec_source() -> None:
    """`system_code` условия может отличаться: систему фактору даёт `risk_factor_systems`."""
    catalog = _catalog(
        risk_factor_systems=(
            risk_factor_system("rf_ldl", SYSTEM, reasoning="почему ЛПНП"),
            risk_factor_system("rf_ldl", OTHER_SYSTEM, reasoning=None),
            risk_factor_system("rf_smoke", SYSTEM, reasoning=None),
        ),
        risk_factor_triggers=(
            risk_factor_trigger("rf_ldl", OTHER_SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=1),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=2),
        ),
    )
    interpretation = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5"}))
    assert [factor.code for factor in interpretation.risk_factors] == ["rf_ldl"]


def test_score_other_than_three_is_not_a_clinrec_factor() -> None:
    catalog = _catalog(risk_factor_scores=(risk_factor_score("rf_ldl", DIABETES_GROUP, score=2),))
    interpretation = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5"}))
    assert interpretation.risk_factors == []


def test_clinrec_block_follows_the_questionnaire_block() -> None:
    loaded = _loaded(
        [_clinrec_result(), ResultRow(instrument_code="findrisk_t", risk_level="high", applicability=True)],
        {LDL: "5", "smoking_t": "yes"},
    )
    interpretation = _interpret(_catalog(), loaded)
    assert [factor.code for factor in interpretation.risk_factors] == ["rf_smoke", "rf_ldl"]


def test_factor_in_both_blocks_keeps_the_first_instance() -> None:
    """Один фактор отобран обоими источниками: в списке остаётся запись первого блока с баллом."""
    catalog = _catalog(
        risk_factor_scores=(risk_factor_score("rf_smoke", DIABETES_GROUP, score=3),),
        risk_factor_triggers=(
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=2),
            risk_factor_trigger("rf_smoke", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=3),
        ),
    )
    loaded = _loaded(
        [_clinrec_result(), ResultRow(instrument_code="findrisk_t", risk_level="high", applicability=True)],
        {LDL: "5", "smoking_t": "yes"},
    )
    interpretation = _interpret(catalog, loaded)
    plan_codes = [factor.code for factor in interpretation.risk_factors]
    # Обе записи остаются в памяти прогона, но представителем кода становится запись первого
    # блока — она идёт раньше и несёт балл параметра.
    assert plan_codes[0] == "rf_smoke"
    assert interpretation.risk_factors[0].score == Decimal("2")


def test_clinrec_groups_merge_with_instrument_groups_without_duplicates() -> None:
    """Группа, подтверждённая и калькулятором, и клинрек-строкой, попадает в заболевания один раз."""
    loaded = _loaded(
        [_clinrec_result(), ResultRow(instrument_code="findrisk_t", risk_level="high", applicability=True)],
        {LDL: "5", "smoking_t": "yes"},
    )
    interpretation = _interpret(_catalog(), loaded)
    assert interpretation.diseases == [DIABETES_GROUP]


def test_distinct_clinrec_group_is_appended_after_instrument_groups() -> None:
    """Разные группы двух источников объединяются: сначала группы по разметке инструментов, затем клинрек.

    Код клинрек-группы по алфавиту стоит раньше группы калькулятора: итог в порядке источников,
    а не отсортирован.
    """
    clinrec_group = "d_clinrec"
    catalog = _catalog(
        diseases=(
            disease(DIABETES_GROUP, SYSTEM, description=DIABETES_NAME),
            disease(clinrec_group, SYSTEM, description="Клинрек-группа"),
        ),
        risk_factor_scores=(risk_factor_score("rf_ldl", clinrec_group, score=3),),
    )
    loaded = _loaded(
        [
            _clinrec_result(disease_code=clinrec_group),
            ResultRow(instrument_code="findrisk_t", risk_level="high", applicability=True),
        ],
        {LDL: "5", "smoking_t": "yes"},
    )
    interpretation = _interpret(catalog, loaded)
    assert interpretation.diseases == [DIABETES_GROUP, clinrec_group]


def test_gender_restricted_clinrec_trigger() -> None:
    catalog = _catalog(
        risk_factor_triggers=(
            risk_factor_trigger(
                "rf_ldl", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), gender=GENDER_FEMALE, trigger_id=1
            ),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=2),
        ),
    )
    male = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5", PARAMETER_CODE_GENDER: GENDER_MALE}))
    assert male.risk_factors == []
    female = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5", PARAMETER_CODE_GENDER: GENDER_FEMALE}))
    assert [factor.code for factor in female.risk_factors] == ["rf_ldl"]


def test_clinrec_block_is_ordered_by_trigger_id() -> None:
    """Порядок второго блока задаёт `trigger_id` условия, а не идентификатор фактора.

    Идентификаторы факторов подобраны в обратном порядке к идентификаторам условий: очередь
    определяет именно `trigger_id` (wiki «Интерпретация» §4.3, шаг 3).
    """
    catalog = _catalog(
        risk_factors=(
            risk_factor("rf_late", description="поздний", risk_factor_id=10),
            risk_factor("rf_early", description="ранний", risk_factor_id=90),
            risk_factor("rf_smoke", description="курит", risk_factor_id=20),
        ),
        risk_factor_systems=(
            risk_factor_system("rf_late", SYSTEM, reasoning=None),
            risk_factor_system("rf_early", SYSTEM, reasoning=None),
            risk_factor_system("rf_smoke", SYSTEM, reasoning=None),
        ),
        risk_factor_triggers=(
            risk_factor_trigger("rf_late", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=7),
            risk_factor_trigger("rf_early", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=3),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=9),
        ),
        risk_factor_scores=(
            risk_factor_score("rf_late", DIABETES_GROUP, score=3),
            risk_factor_score("rf_early", DIABETES_GROUP, score=3),
        ),
    )

    interpretation = _interpret(catalog, _loaded([_clinrec_result()], {LDL: "5"}))

    assert [factor.code for factor in interpretation.risk_factors] == ["rf_early", "rf_late"]


def test_factor_of_two_groups_takes_the_position_of_its_senior_condition() -> None:
    """Фактор с несколькими сработавшими условиями встаёт на позицию наименьшего `trigger_id`."""
    another_group = "d_another"
    catalog = _catalog(
        diseases=(
            disease(DIABETES_GROUP, SYSTEM, description=DIABETES_NAME),
            disease(another_group, SYSTEM, description="Другая группа"),
        ),
        risk_factors=(
            risk_factor("rf_ldl", description="ЛПНП повышен", risk_factor_id=10),
            risk_factor("rf_other", description="другой", risk_factor_id=20),
            risk_factor("rf_smoke", description="курит", risk_factor_id=30),
        ),
        risk_factor_systems=(
            risk_factor_system("rf_ldl", SYSTEM, reasoning=None),
            risk_factor_system("rf_other", SYSTEM, reasoning=None),
            risk_factor_system("rf_smoke", SYSTEM, reasoning=None),
        ),
        risk_factor_triggers=(
            # У rf_ldl два условия: старшее (2) отобрано по одной группе, младшее (8) — по другой.
            risk_factor_trigger("rf_ldl", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=2),
            risk_factor_trigger("rf_ldl", SYSTEM, LDL, operator="gt", value_num=Decimal("4"), trigger_id=8),
            risk_factor_trigger("rf_other", SYSTEM, LDL, operator="gt", value_num=Decimal("3"), trigger_id=5),
            risk_factor_trigger("rf_smoke", SYSTEM, "smoking_t", value_text="yes", trigger_id=9),
        ),
        risk_factor_scores=(
            risk_factor_score("rf_ldl", DIABETES_GROUP, score=3),
            risk_factor_score("rf_ldl", another_group, score=3),
            risk_factor_score("rf_other", another_group, score=3),
        ),
    )

    interpretation = _interpret(
        catalog,
        _loaded([_clinrec_result(), _clinrec_result(disease_code=another_group)], {LDL: "5"}),
    )

    assert [factor.code for factor in interpretation.risk_factors] == ["rf_ldl", "rf_other"]
    # Представителем стало старшее условие фактора, а не первое встреченное при обходе групп.
    assert interpretation.risk_factors[0].trigger_id == 2


# --- Вход блока и его сработавшие условия: общие с разбором несработавших кандидатов ---


def test_applicable_disease_codes_take_only_applicable_biomarker_rows() -> None:
    """Вход §4.3 шага 1б: применимые строки `biomarker_kr`, отсортированные, без дублей.

    Результаты других инструментов группу не приносят, даже если у них заполнен `disease_code`:
    группа второго источника — только клинрек-строка.
    """
    codes = applicable_clinrec_disease_codes(
        [
            _clinrec_result(disease_code="d_b"),
            _clinrec_result(disease_code="d_a"),
            _clinrec_result(disease_code="d_cleared", applicability=False),
            ResultRow(instrument_code="findrisk_t", risk_level="high", applicability=True, disease_code="d_other"),
        ]
    )
    assert codes == ("d_a", "d_b")


def test_selection_reports_every_matched_condition_not_only_the_representative() -> None:
    """Фактор с двумя сработавшими условиями схлопнут в один, но оба условия остаются известны.

    По этому множеству читающая сторона отличает сработавшее условие от несработавшего; возьми она
    только `factors`, второе условие того же фактора ушло бы в ответ как несработавшее.
    """
    catalog = _catalog(
        risk_factor_triggers=(
            risk_factor_trigger(
                "rf_ldl",
                SYSTEM,
                LDL,
                operator="between",
                value_text=None,
                min_value=Decimal("3"),
                max_value=Decimal("9"),
                trigger_id=11,
            ),
            risk_factor_trigger(
                "rf_ldl",
                SYSTEM,
                LDL,
                operator="between",
                value_text=None,
                min_value=Decimal("4"),
                max_value=Decimal("8"),
                trigger_id=12,
            ),
        )
    )
    selection = select_clinrec_factors(
        candidates_by_disease={DIABETES_GROUP: catalog.clinrec_factors_for(SYSTEM, DIABETES_GROUP)},
        patient_params={LDL: "5"},
        gender=None,
    )
    assert len(selection.factors) == 1
    assert len(selection.matched_trigger_codes) == 2
