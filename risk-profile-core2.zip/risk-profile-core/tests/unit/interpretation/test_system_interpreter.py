"""Расчётная фаза §4.1-4.4 — без базы.

`SystemInterpreter` получает готовый снимок пациента и резидентный каталог, поэтому проверяется
как чистая функция: справочник собирается из DTO прямо в тесте, БД не поднимается.
"""

from datetime import UTC, datetime
from decimal import Decimal

import pytest

from src.infra.catalog.dtos import (
    RecommendedDoctorDTO,
    RiskFactorDTO,
    RiskFactorSystemDTO,
    RiskFactorTriggerDTO,
)
from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.patients.dtos import ActiveParameter
from src.interpretation.computing import SystemInterpreter
from src.interpretation.domain.models import InterpretationReasonCode, ResultRow, ValueStatus
from src.interpretation.loading import LoadedInterpretationData
from src.interpretation.reason_collector import InterpretationReasonCollector
from tests.catalog_builder import disease, instrument, instrument_parameter, make_catalog, score, system_instrument
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_GENDER

SYSTEM = "ENDO"
PATIENT = "p1"
_NOW = datetime(2026, 1, 1, tzinfo=UTC)


def _trigger(
    trigger_id: int,
    factor_code: str,
    parameter_code: str,
    *,
    system_code: str = SYSTEM,
    value_text: str | None = "yes",
) -> RiskFactorTriggerDTO:
    return RiskFactorTriggerDTO(
        trigger_id,
        f"{factor_code}__{system_code}__{parameter_code}__{trigger_id:02d}",
        factor_code,
        system_code,
        parameter_code,
        "text",
        "eq",
        None,
        None,
        None,
        value_text,
        None,
    )


def _catalog(
    *,
    instruments: tuple = (),
    instruments_parameters: tuple = (),
    systems_instruments: tuple = (),
    risk_factors: tuple = (),
    risk_factor_systems: tuple = (),
    risk_factor_triggers: tuple = (),
    parameter_scores: tuple = (),
    recommended_doctors: tuple = (),
    diseases: tuple = (disease("diabetes_mellitus", SYSTEM), disease("osteoporosis", SYSTEM)),
) -> InterpretationCatalog:
    return InterpretationCatalog(
        make_catalog(
            diseases=diseases,
            instruments=instruments,
            instruments_parameters=instruments_parameters,
            systems_instruments=systems_instruments,
            risk_factors=risk_factors,
            risk_factor_systems=risk_factor_systems,
            risk_factor_triggers=risk_factor_triggers,
            parameter_scores=parameter_scores,
            recommended_doctors=recommended_doctors,
        )
    )


def _loaded(
    results_by_system: dict[str, list[ResultRow]],
    patient_values: dict[str, str] | None = None,
    *,
    systems: tuple[str, ...] = (SYSTEM,),
) -> LoadedInterpretationData:
    values = patient_values or {}
    parameters = {
        code: ActiveParameter(code, value, _NOW, _NOW, index)
        for index, (code, value) in enumerate(values.items(), start=1)
    }
    return LoadedInterpretationData(
        systems=systems,
        results_by_system=results_by_system,
        patient_parameters=parameters,
        patient_values=values,
        gender=values.get(PARAMETER_CODE_GENDER),
        systems_by_instrument={},
    )


def _interpreter(catalog: InterpretationCatalog) -> tuple[SystemInterpreter, InterpretationReasonCollector]:
    """Сбор причин выключен так же, как в проде по умолчанию: коллектор сам no-op по флагу."""
    reasons = InterpretationReasonCollector()
    return SystemInterpreter(catalog, reasons), reasons


def _result(instrument_code: str, risk_level: str | None, *, applicability: bool = True) -> ResultRow:
    return ResultRow(instrument_code=instrument_code, risk_level=risk_level, applicability=applicability)


def test_no_results_yields_empty_interpretation() -> None:
    interpreter, _ = _interpreter(_catalog())

    computed = interpreter.interpret(PATIENT, _loaded({}))

    assert computed.interpretations[SYSTEM].risk_level is None
    assert computed.interpretations[SYSTEM].diseases is None
    assert computed.interpretations[SYSTEM].risk_factors == []
    assert [plan.system_code for plan in computed.plans] == [SYSTEM]


def test_low_risk_skips_risk_factor_selection() -> None:
    """Гейт §4.3: ниже medium отбор не выполняется, даже когда кандидат сработал бы."""
    catalog = _catalog(
        instruments=(instrument("instr_t", instrument_id=1),),
        instruments_parameters=(instrument_parameter("instr_t", "smoking_t", is_required=True),),
        systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        risk_factors=(RiskFactorDTO(1, "rf_smoke", "курит", "Модифицируемый"),),
        risk_factor_systems=(RiskFactorSystemDTO(1, "rf_smoke", SYSTEM, None),),
        risk_factor_triggers=(_trigger(1, "rf_smoke", "smoking_t"),),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(PATIENT, _loaded({SYSTEM: [_result("instr_t", "low")]}, {"smoking_t": "yes"}))

    assert computed.interpretations[SYSTEM].risk_level == "low"
    assert computed.interpretations[SYSTEM].risk_factors == []
    assert computed.plans[0].risk_factors_code is None


@pytest.mark.parametrize("risk_level", ["medium", "high"])
def test_medium_high_risk_selects_matching_factor(risk_level: str) -> None:
    catalog = _catalog(
        instruments=(instrument("instr_t", instrument_id=1),),
        instruments_parameters=(instrument_parameter("instr_t", "smoking_t", is_required=True),),
        systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        risk_factors=(RiskFactorDTO(1, "rf_smoke", "курит", "Модифицируемый"),),
        risk_factor_systems=(RiskFactorSystemDTO(1, "rf_smoke", SYSTEM, None),),
        risk_factor_triggers=(_trigger(1, "rf_smoke", "smoking_t"),),
        parameter_scores=(score("smoking_t", SYSTEM, value="yes", score=Decimal("2")),),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(PATIENT, _loaded({SYSTEM: [_result("instr_t", risk_level)]}, {"smoking_t": "yes"}))

    assert [rf.code for rf in computed.interpretations[SYSTEM].risk_factors] == ["rf_smoke"]
    assert computed.plans[0].risk_factors_code == ["rf_smoke"]


def test_one_code_across_two_parameters_collapses_to_one_representative() -> None:
    """Дедуп §4.3: один код, раскрытый в два параметра, попадает в план один раз."""
    catalog = _catalog(
        instruments=(instrument("instr_t", instrument_id=1),),
        instruments_parameters=(
            instrument_parameter("instr_t", "smoking_t", is_required=True),
            instrument_parameter("instr_t", "vaping_t", is_required=True),
        ),
        systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        risk_factors=(RiskFactorDTO(1, "rf_smoke", "курит", "Модифицируемый"),),
        risk_factor_systems=(RiskFactorSystemDTO(1, "rf_smoke", SYSTEM, None),),
        risk_factor_triggers=(_trigger(1, "rf_smoke", "smoking_t"), _trigger(2, "rf_smoke", "vaping_t")),
        parameter_scores=(
            score("smoking_t", SYSTEM, value="yes", score=Decimal("2")),
            score("vaping_t", SYSTEM, value="yes", score=Decimal("5")),
        ),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(
        PATIENT, _loaded({SYSTEM: [_result("instr_t", "high")]}, {"smoking_t": "yes", "vaping_t": "yes"})
    )

    # Обе строки сработали и обе видны в памяти, а в план уходит один представитель кода.
    assert [rf.code for rf in computed.interpretations[SYSTEM].risk_factors] == ["rf_smoke", "rf_smoke"]
    assert computed.plans[0].risk_factors_code == ["rf_smoke"]


def test_diseases_come_from_the_instrument_catalog() -> None:
    catalog = _catalog(
        instruments=(instrument("instr_t", instrument_id=1, diseases=["diabetes_mellitus"]),),
        systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(PATIENT, _loaded({SYSTEM: [_result("instr_t", "high")]}))

    assert computed.interpretations[SYSTEM].diseases == ["diabetes_mellitus"]
    assert computed.plans[0].diseases == ["diabetes_mellitus"]


def test_other_significant_risk_does_not_exclude_confirmed_group() -> None:
    """Инструмент системы без групп с высоким риском не обнуляет группу, подтверждённую другим."""
    catalog = _catalog(
        instruments=(
            instrument("findrisk_t", type="calc", instrument_id=1, diseases=["diabetes_mellitus"]),
            instrument("form_endo_t", type="form", instrument_id=2),
        ),
        systems_instruments=(system_instrument(SYSTEM, "findrisk_t"), system_instrument(SYSTEM, "form_endo_t")),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(
        PATIENT, _loaded({SYSTEM: [_result("findrisk_t", "medium"), _result("form_endo_t", "high")]})
    )

    assert computed.interpretations[SYSTEM].risk_level == "high"
    assert computed.plans[0].diseases == ["diabetes_mellitus"]


@pytest.mark.parametrize(
    ("gender", "expected_code"),
    [(GENDER_FEMALE, "19"), (GENDER_MALE, "35")],
)
def test_reprod_doctor_depends_on_gender(gender: str, expected_code: str) -> None:
    """§4.4: REPROD справочником не выражается — специалист выводится из пола пациента."""
    catalog = _catalog(
        instruments=(instrument("instr_r", instrument_id=1),),
        systems_instruments=(system_instrument("REPROD", "instr_r"),),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(
        PATIENT,
        _loaded(
            {"REPROD": [_result("instr_r", "high")]},
            {PARAMETER_CODE_GENDER: gender},
            systems=("REPROD",),
        ),
    )

    assert computed.plans[0].doctors_code == [expected_code]


def test_doctor_comes_from_the_reference_row_for_ordinary_systems() -> None:
    catalog = _catalog(
        instruments=(instrument("instr_t", instrument_id=1),),
        systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        recommended_doctors=(RecommendedDoctorDTO(SYSTEM, "high", 7, 1),),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(PATIENT, _loaded({SYSTEM: [_result("instr_t", "high")]}))

    assert computed.plans[0].doctors_code == ["7"]


def test_every_requested_system_is_computed_and_planned() -> None:
    catalog = _catalog(
        instruments=(
            instrument("instr_e", instrument_id=1, diseases=["diabetes_mellitus"]),
            instrument("instr_g", instrument_id=2),
        ),
        systems_instruments=(system_instrument("ENDO", "instr_e"), system_instrument("GI", "instr_g")),
    )
    interpreter, _ = _interpreter(catalog)

    computed = interpreter.interpret(
        PATIENT,
        _loaded(
            {"ENDO": [_result("instr_e", "high")], "GI": [_result("instr_g", "low")]},
            systems=("ENDO", "GI"),
        ),
    )

    assert set(computed.interpretations) == {"ENDO", "GI"}
    assert [plan.system_code for plan in computed.plans] == ["ENDO", "GI"]
    # План и возвращаемая интерпретация описывают одну и ту же систему одними и теми же величинами.
    for plan in computed.plans:
        interpretation = computed.interpretations[plan.system_code]
        assert plan.risk_level == interpretation.risk_level
        assert plan.diseases == interpretation.diseases


class TestReasonCodes:
    """Причины пустых результатов §4.3 — их различает проверяющий, поэтому проверяем отдельно."""

    @staticmethod
    def _record(catalog: InterpretationCatalog, loaded: LoadedInterpretationData, monkeypatch) -> dict:
        recorded: dict = {}
        reasons = InterpretationReasonCollector()

        def _capture(patient_id: str, system_code: str, **kwargs: object) -> None:  # noqa: ARG001
            recorded.update(kwargs)

        monkeypatch.setattr(reasons, "record_system", _capture)
        SystemInterpreter(catalog, reasons).interpret(PATIENT, loaded)
        return recorded

    def test_gate_not_passed(self, monkeypatch: pytest.MonkeyPatch) -> None:
        catalog = _catalog(
            instruments=(instrument("instr_t", instrument_id=1),),
            systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        )

        recorded = self._record(catalog, _loaded({SYSTEM: [_result("instr_t", "low")]}), monkeypatch)

        assert recorded["risk_factors"].reason_code == InterpretationReasonCode.RISK_LEVEL_NOT_MEDIUM_HIGH
        assert recorded["risk_factors"].status is ValueStatus.EMPTY

    def test_no_candidates_in_the_reference_data(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Гейт пройден, но у параметров системы нет ни одного кандидата — пробел в справочнике."""
        catalog = _catalog(
            instruments=(instrument("instr_t", instrument_id=1),),
            instruments_parameters=(instrument_parameter("instr_t", "smoking_t", is_required=True),),
            systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
        )

        recorded = self._record(catalog, _loaded({SYSTEM: [_result("instr_t", "high")]}), monkeypatch)

        assert recorded["risk_factors"].reason_code == InterpretationReasonCode.NO_CANDIDATES

    def test_candidates_present_but_none_matched(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Кандидат есть, но ответ пациента его не активирует — несовпадение условия, не пробел."""
        catalog = _catalog(
            instruments=(instrument("instr_t", instrument_id=1),),
            instruments_parameters=(instrument_parameter("instr_t", "smoking_t", is_required=True),),
            systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
            risk_factors=(RiskFactorDTO(1, "rf_smoke", "курит", "Модифицируемый"),),
            risk_factor_systems=(RiskFactorSystemDTO(1, "rf_smoke", SYSTEM, None),),
            risk_factor_triggers=(_trigger(1, "rf_smoke", "smoking_t"),),
            # Кандидатом первого блока условие делает строка `parameter_scores` по паре
            # «параметр × система»: без неё условие этому источнику не принадлежит вовсе.
            parameter_scores=(score("smoking_t", SYSTEM, value="yes", score=Decimal("2")),),
        )

        recorded = self._record(
            catalog, _loaded({SYSTEM: [_result("instr_t", "high")]}, {"smoking_t": "no"}), monkeypatch
        )

        assert recorded["risk_factors"].reason_code == InterpretationReasonCode.NO_CANDIDATE_MATCHED

    def test_computed_factors_carry_no_reason(self, monkeypatch: pytest.MonkeyPatch) -> None:
        catalog = _catalog(
            instruments=(instrument("instr_t", instrument_id=1),),
            instruments_parameters=(instrument_parameter("instr_t", "smoking_t", is_required=True),),
            systems_instruments=(system_instrument(SYSTEM, "instr_t"),),
            risk_factors=(RiskFactorDTO(1, "rf_smoke", "курит", "Модифицируемый"),),
            risk_factor_systems=(RiskFactorSystemDTO(1, "rf_smoke", SYSTEM, None),),
            risk_factor_triggers=(_trigger(1, "rf_smoke", "smoking_t"),),
            parameter_scores=(score("smoking_t", SYSTEM, value="yes", score=Decimal("2")),),
        )

        recorded = self._record(
            catalog, _loaded({SYSTEM: [_result("instr_t", "high")]}, {"smoking_t": "yes"}), monkeypatch
        )

        assert recorded["risk_factors"].reason_code is None
        assert recorded["risk_factors"].status is ValueStatus.COMPUTED

    def test_no_results_reason_for_risk_level(self, monkeypatch: pytest.MonkeyPatch) -> None:
        recorded = self._record(_catalog(), _loaded({}), monkeypatch)

        assert recorded["risk_level"].reason_code == InterpretationReasonCode.NO_RESULTS
