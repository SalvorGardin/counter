"""§4.1 — aggregate_risk_level: решение и причина пустого уровня."""

from src.interpretation.domain.models import InterpretationReasonCode, ResultRow
from src.interpretation.domain.risk_level import aggregate_risk_level


def _row(risk_level: str | None, applicability: bool = True, instrument: str = "x") -> ResultRow:
    return ResultRow(instrument_code=instrument, risk_level=risk_level, applicability=applicability)


def test_empty_returns_none() -> None:
    assert aggregate_risk_level([]).value is None


def test_all_inapplicable_returns_none() -> None:
    rows = [_row("high", applicability=False), _row("medium", applicability=False)]
    assert aggregate_risk_level(rows).value is None


def test_mixed_returns_max() -> None:
    rows = [_row("low"), _row("high"), _row("medium")]
    assert aggregate_risk_level(rows).value == "high"


def test_only_medium_and_low() -> None:
    rows = [_row("medium"), _row("low")]
    assert aggregate_risk_level(rows).value == "medium"


def test_only_low() -> None:
    rows = [_row("low"), _row("low")]
    assert aggregate_risk_level(rows).value == "low"


def test_applicable_with_none_risk_level_is_ignored() -> None:
    """applicability=True но risk_level=None — не вносим вклад в max."""
    rows = [_row(None), _row("low")]
    assert aggregate_risk_level(rows).value == "low"


def test_only_applicable_with_none_risk_level_returns_none() -> None:
    rows = [_row(None), _row(None, applicability=True)]
    assert aggregate_risk_level(rows).value is None


def test_high_in_inapplicable_does_not_count() -> None:
    rows = [_row("high", applicability=False), _row("low")]
    assert aggregate_risk_level(rows).value == "low"


# ── причина пустого уровня риска ─────────────────────────────────────────────


def test_no_results_reason() -> None:
    assert aggregate_risk_level([]).reason_code is InterpretationReasonCode.NO_RESULTS


def test_no_applicable_results_reason() -> None:
    """Все результаты неприменимы — это не «результатов нет»: разные дефекты для проверяющего."""
    rows = [_row("high", applicability=False), _row("medium", applicability=False)]
    assert aggregate_risk_level(rows).reason_code is InterpretationReasonCode.NO_APPLICABLE_RESULTS


def test_applicable_without_level_reason() -> None:
    rows = [_row(None), _row(None)]
    assert aggregate_risk_level(rows).reason_code is InterpretationReasonCode.APPLICABLE_WITHOUT_LEVEL


def test_applicable_without_level_wins_over_inapplicable_neighbour() -> None:
    """Есть применимый результат без уровня — причина о нём, а не об отсутствии применимых."""
    rows = [_row("high", applicability=False), _row(None)]
    assert aggregate_risk_level(rows).reason_code is InterpretationReasonCode.APPLICABLE_WITHOUT_LEVEL


def test_computed_level_has_no_reason() -> None:
    assert aggregate_risk_level([_row("low")]).reason_code is None
