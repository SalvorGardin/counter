"""Контракт коллектора причин интерпретации: выключенный флаг, изоляция записи.

БД здесь не нужна: проверяется поведение вокруг запроса (пойдёт ли он вообще, что будет с
ошибкой), а не сам SQL. Фабрика сессий подменяется заглушкой, которая либо запрещает обращение,
либо имитирует нужный ответ драйвера. Запись настоящих строк — в
tests/integration/interpretation/test_reason_collection.py.
"""

import logging
from decimal import Decimal
from types import SimpleNamespace
from typing import Any

import pytest
from sqlalchemy.exc import ProgrammingError

from src.config import settings
from src.interpretation.domain.models import (
    InterpretationReasonCode,
    Reasoned,
    RiskFactorMatch,
    RiskFactorRanked,
    ValueStatus,
)
from src.interpretation.reason_collector import InterpretationReasonCollector
from tests.consts import PARAMETER_CODE_AGE

PATIENT = "p1"
SYSTEM = "ENDO"


@pytest.fixture
def collection_on(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)


@pytest.fixture
def collection_off(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)


class _ForbiddenFactory:
    """Фабрика сессий, обращение к которой — провал теста."""

    def __call__(self) -> Any:
        raise AssertionError("при выключенном сборе сессия создаваться не должна")


class _RecordingSession:
    """Сессия, запоминающая выполненные стейтменты; execute может быть настроен на ошибку."""

    def __init__(self, error: Exception | None = None) -> None:
        self.error = error
        self.executed: list[Any] = []
        self.committed = False

    async def __aenter__(self) -> "_RecordingSession":
        return self

    async def __aexit__(self, *exc: object) -> bool:
        return False

    async def execute(self, statement: Any, params: Any = None) -> None:
        self.executed.append((statement, params))
        if self.error is not None:
            raise self.error

    async def commit(self) -> None:
        self.committed = True


class _RecordingFactory:
    def __init__(self, error: Exception | None = None) -> None:
        self.error = error
        self.sessions: list[_RecordingSession] = []

    def __call__(self) -> _RecordingSession:
        session = _RecordingSession(self.error)
        self.sessions.append(session)
        return session


def _database_error() -> ProgrammingError:
    """Отказ БД в форме, в которой его отдаёт asyncpg через SQLAlchemy (SQLSTATE 42P01).

    Конкретный код состояния на поведение не влияет: коллектор гасит любой `SQLAlchemyError`
    одинаково и сбор не отключает.
    """
    return ProgrammingError("stmt", {}, SimpleNamespace(sqlstate="42P01"))  # ty: ignore[invalid-argument-type]


def _factor(risk_factor_id: int, code: str = "rf") -> RiskFactorRanked:
    return RiskFactorRanked(
        risk_factor_id=risk_factor_id,
        trigger_id=risk_factor_id,
        trigger_code=f"trigger-{risk_factor_id}",
        code=code,
        parameter_code=PARAMETER_CODE_AGE,
        description="",
        reasoning="reason",
        score=Decimal("1"),
        value_type="number",
        operator="between",
        value_num=None,
        min_value=Decimal("60"),
        max_value=Decimal("100"),
        value_text=None,
        gender=None,
        modifiability="modifiable",
    )


def _record(
    collector: InterpretationReasonCollector,
    patient_id: str = PATIENT,
    system_code: str = SYSTEM,
    *,
    matches: tuple[RiskFactorMatch, ...] = (),
) -> None:
    collector.record_system(
        patient_id,
        system_code,
        risk_level=Reasoned("high"),
        diseases=Reasoned(None, InterpretationReasonCode.NO_GROUP_MATCHED),
        risk_factors=Reasoned(["rf"]),
        doctors=Reasoned(None, InterpretationReasonCode.NO_REFERENCE_ROW),
        matches=matches,
    )


class TestDisabledFlag:
    async def test_nothing_is_collected_and_no_session_is_opened(self, collection_off: None) -> None:
        collector = InterpretationReasonCollector(session_factory=_ForbiddenFactory())  # ty: ignore[invalid-argument-type]
        _record(collector, matches=(RiskFactorMatch(_factor(1), True),))
        # Ни строки в памяти — при выключенном сборе не собирается вообще ничего.
        assert collector.pending() == ({}, {})
        await collector.flush_patient(PATIENT)  # сессия не открывается, иначе фабрика упадёт

    async def test_enabling_the_flag_starts_collection_without_restart(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        _record(collector)
        await collector.flush_patient(PATIENT)
        assert len(factory.sessions) == 1
        assert factory.sessions[0].committed is True


class TestRecordedRows:
    async def test_status_pairs_follow_the_reason(self, collection_on: None) -> None:
        collector = InterpretationReasonCollector(session_factory=_RecordingFactory())  # ty: ignore[invalid-argument-type]
        _record(collector)
        statuses, _ = collector.pending()
        row = statuses[(PATIENT, SYSTEM)]
        assert row["risk_level_status"] == ValueStatus.COMPUTED.value
        assert row["risk_level_reason_code"] is None
        assert row["doctors_status"] == ValueStatus.EMPTY.value
        assert row["doctors_reason_code"] == InterpretationReasonCode.NO_REFERENCE_ROW.value

    async def test_blocking_instrument_codes_are_always_null(self, collection_on: None) -> None:
        """Деталь блокировки новыми прогонами не выставляется ни при какой причине заболеваний."""
        collector = InterpretationReasonCollector(session_factory=_RecordingFactory())  # ty: ignore[invalid-argument-type]
        for system_code, diseases in (
            (SYSTEM, Reasoned(None, InterpretationReasonCode.NO_GROUP_MATCHED)),
            ("CVD", Reasoned(["infarction_ischemic_stroke"])),
        ):
            collector.record_system(
                PATIENT,
                system_code,
                risk_level=Reasoned("high"),
                diseases=diseases,
                risk_factors=Reasoned(None, InterpretationReasonCode.NO_CANDIDATES),
                doctors=Reasoned(["23"]),
            )
        statuses, _ = collector.pending()
        assert statuses[(PATIENT, SYSTEM)]["blocking_instrument_codes"] is None
        assert statuses[(PATIENT, "CVD")]["blocking_instrument_codes"] is None

    async def test_matches_keep_representation_and_snapshot(self, collection_on: None) -> None:
        collector = InterpretationReasonCollector(session_factory=_RecordingFactory())  # ty: ignore[invalid-argument-type]
        factor_1, factor_2 = _factor(1, "rf1"), _factor(2, "rf2")
        matches = (
            RiskFactorMatch(factor_1, True),
            RiskFactorMatch(factor_2, False),
        )
        _record(collector, matches=matches)
        _, recorded = collector.pending()
        assert recorded[(PATIENT, SYSTEM, factor_2.trigger_code)]["is_representative"] is False
        assert recorded[(PATIENT, SYSTEM, factor_1.trigger_code)]["min_value"] == Decimal("60")


class TestPatientIsolation:
    async def test_flush_writes_only_the_requested_patient(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        _record(collector, "p1")
        _record(collector, "p2")
        await collector.flush_patient("p1")
        _statement, rows = factory.sessions[0].executed[0]
        assert [row["patient_id"] for row in rows] == ["p1"]
        statuses, _ = collector.pending()
        assert set(statuses) == {("p2", SYSTEM)}

    async def test_discarded_patient_is_never_written(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        _record(collector, matches=(RiskFactorMatch(_factor(1), True),))
        collector.discard_patient(PATIENT)
        await collector.flush_patient(PATIENT)
        assert factory.sessions == []
        assert collector.pending() == ({}, {})


class TestDeleteForSystems:
    """Чистка причин после risk-event удаления interpretations (см. RiskEventService)."""

    async def test_nothing_is_deleted_when_disabled(self, collection_off: None) -> None:
        collector = InterpretationReasonCollector(session_factory=_ForbiddenFactory())  # ty: ignore[invalid-argument-type]
        await collector.delete_for_systems(PATIENT, [SYSTEM])  # сессия не открывается

    async def test_empty_system_list_opens_no_session(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        await collector.delete_for_systems(PATIENT, [])
        assert factory.sessions == []

    async def test_both_tables_are_cleared_in_one_transaction(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        await collector.delete_for_systems(PATIENT, [SYSTEM, "CVD"])
        assert len(factory.sessions) == 1
        session = factory.sessions[0]
        # Статусы и сработавшие факторы — одной сессией и одним коммитом: match без своего статуса
        # был бы такой же осиротевшей диагностикой.
        assert len(session.executed) == 2
        assert session.committed is True
        assert [params for _statement, params in session.executed] == [
            {"target_patient_id": PATIENT, "target_system_codes": [SYSTEM, "CVD"]}
        ] * 2

    async def test_database_error_is_logged_without_raising(
        self, collection_on: None, caplog: pytest.LogCaptureFixture
    ) -> None:
        factory = _RecordingFactory(error=_database_error())
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]

        with caplog.at_level(logging.ERROR, logger="app"):
            await collector.delete_for_systems(PATIENT, [SYSTEM])  # не должно бросить исключение

        errors = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert len(errors) == 1
        assert collector.enabled is True


class TestErrorsDoNotDisableCollection:
    async def test_repeated_database_errors_are_logged_each_time(
        self, collection_on: None, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Сбой записи — не событие уровня процесса: он логируется на каждую попытку.

        Интерпретация при этом не падает — записать причины уже некуда, а интерпретации пациента
        закоммичены.
        """
        factory = _RecordingFactory(error=_database_error())
        collector = InterpretationReasonCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]

        with caplog.at_level(logging.ERROR, logger="app"):
            _record(collector)
            await collector.flush_patient(PATIENT)
            _record(collector)
            await collector.flush_patient(PATIENT)

        errors = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert len(errors) == 2
        assert len(factory.sessions) == 2
