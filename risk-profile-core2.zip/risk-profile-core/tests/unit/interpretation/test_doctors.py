"""§4.4 — resolve_doctors_code (предложение о записи к врачу)."""

import pytest

from src.interpretation.domain.constants import PATIENT_GENDER_FEMALE, PATIENT_GENDER_MALE
from src.interpretation.domain.doctors import resolve_doctors_code
from src.interpretation.domain.models import InterpretationReasonCode, Reasoned
from src.services.risk_init.domain.constants import GENDER_VALUE_BY_REQUEST


def test_gender_constants_match_risk_init() -> None:
    """Контракт: interpretation и risk_init используют одинаковые строки для пола.

    Если risk_init переименует значения — REPROD перестанет резолвить врача без ошибки.
    """
    assert GENDER_VALUE_BY_REQUEST["female"] == PATIENT_GENDER_FEMALE
    assert GENDER_VALUE_BY_REQUEST["male"] == PATIENT_GENDER_MALE


# Табличный справочник recommended_doctors: (system_code, risk_level) → [doctor_code].
# Совпадает с сидом catalog/0080_..._recommended_doctors.csv для систем, участвующих в тестах.
_TABLE: dict[tuple[str, str], list[str]] = {
    ("CVD", "low"): ["23"],
    ("CVD", "medium"): ["23"],
    ("CVD", "high"): ["23"],
    ("RESP", "low"): ["287"],
    ("RESP", "medium"): ["49"],
    ("RESP", "high"): ["49"],
}


def _resolve(
    *,
    system_code: str,
    risk_level: str | None,
    gender: str | None = None,
    patient_values: dict[str, str] | None = None,
) -> list[str] | None:
    """Решение функции: коды врачей либо их отсутствие — как и до появления причин."""
    return _reasoned(system_code=system_code, risk_level=risk_level, gender=gender, patient_values=patient_values).value


def _reason(
    *,
    system_code: str,
    risk_level: str | None,
    gender: str | None = None,
    patient_values: dict[str, str] | None = None,
) -> InterpretationReasonCode | None:
    return _reasoned(
        system_code=system_code, risk_level=risk_level, gender=gender, patient_values=patient_values
    ).reason_code


def _reasoned(
    *,
    system_code: str,
    risk_level: str | None,
    gender: str | None = None,
    patient_values: dict[str, str] | None = None,
) -> Reasoned[list[str] | None]:
    return resolve_doctors_code(
        system_code=system_code,
        risk_level=risk_level,
        gender=gender,
        patient_values=patient_values or {},
        recommended_by_system_level=_TABLE,
    )


@pytest.mark.parametrize("risk_level", ["low", "medium", "high"])
def test_deterministic_system_uses_table(risk_level: str) -> None:
    assert _resolve(system_code="CVD", risk_level=risk_level) == ["23"]


def test_resp_splits_by_risk_level() -> None:
    assert _resolve(system_code="RESP", risk_level="low") == ["287"]
    assert _resolve(system_code="RESP", risk_level="medium") == ["49"]
    assert _resolve(system_code="RESP", risk_level="high") == ["49"]


def test_null_risk_level_treated_as_low() -> None:
    # §4.4: «Риски не выявлены (null / low)» — null матчится на строку low.
    assert _resolve(system_code="CVD", risk_level=None) == ["23"]
    assert _resolve(system_code="RESP", risk_level=None) == ["287"]


def test_system_absent_from_table_returns_none() -> None:
    assert _resolve(system_code="COMMON", risk_level="high") is None


def test_reprod_by_gender() -> None:
    assert _resolve(system_code="REPROD", risk_level="low", gender=PATIENT_GENDER_FEMALE) == ["19"]
    assert _resolve(system_code="REPROD", risk_level="high", gender=PATIENT_GENDER_MALE) == ["35"]


def test_reprod_unknown_gender_returns_none() -> None:
    assert _resolve(system_code="REPROD", risk_level="high", gender=None) is None
    assert _resolve(system_code="REPROD", risk_level="high", gender="") is None


@pytest.mark.parametrize("risk_level", [None, "low"])
def test_sense_not_medium_high_returns_none(risk_level: str | None) -> None:
    # §4.4.1 срабатывает только при medium/high.
    values = {"vision_loss_1yr": "Да", "hearing_loss": "Да", "sense_cancer": "Да"}
    assert _resolve(system_code="SENSE", risk_level=risk_level, patient_values=values) is None


def test_sense_all_negative_returns_none() -> None:
    values = {"vision_loss_1yr": "Нет", "hearing_loss": "Нет", "sense_cancer": "Нет"}
    assert _resolve(system_code="SENSE", risk_level="medium", patient_values=values) is None


def test_sense_vision_only_returns_ophthalmologist() -> None:
    assert _resolve(system_code="SENSE", risk_level="medium", patient_values={"eye_strain_screen_work": "Да"}) == ["27"]


def test_sense_hearing_only_returns_ent() -> None:
    assert _resolve(system_code="SENSE", risk_level="high", patient_values={"tinnitus": "Иногда"}) == ["11"]


def test_sense_vision_and_hearing_returns_both_ordered() -> None:
    values = {"flashes_floaters_vision": "Да", "frequent_request_to_repeat_speech": "Часто"}
    assert _resolve(system_code="SENSE", risk_level="medium", patient_values=values) == ["27", "11"]


def test_sense_cancer_returns_both() -> None:
    assert _resolve(system_code="SENSE", risk_level="high", patient_values={"sense_cancer": "Да"}) == ["27", "11"]


def test_sense_cancer_and_vision_deduplicated() -> None:
    values = {"sense_cancer": "Да", "vision_loss_1yr": "Да"}
    assert _resolve(system_code="SENSE", risk_level="medium", patient_values=values) == ["27", "11"]


def test_sense_unanswered_params_ignored() -> None:
    # Параметр отсутствует в ответах пациента → как «Нет» (не активирует врача).
    assert _resolve(system_code="SENSE", risk_level="medium", patient_values={}) is None


# ── причина пустого списка врачей ────────────────────────────────────────────


def test_no_reference_row_reason() -> None:
    assert _reason(system_code="COMMON", risk_level="high") is InterpretationReasonCode.NO_REFERENCE_ROW


def test_gender_unknown_reason() -> None:
    """Пол не задан — своя причина, а не «нет строки справочника»: REPROD справочник не использует."""
    assert _reason(system_code="REPROD", risk_level="high", gender=None) is InterpretationReasonCode.GENDER_UNKNOWN


@pytest.mark.parametrize("risk_level", [None, "low"])
def test_sense_risk_level_not_medium_high_reason(risk_level: str | None) -> None:
    """Код назван по проверке гейта: у системы без уровня риска он тоже выставляется."""
    values = {"vision_loss_1yr": "Да"}
    assert (
        _reason(system_code="SENSE", risk_level=risk_level, patient_values=values)
        is InterpretationReasonCode.SENSE_RISK_LEVEL_NOT_MEDIUM_HIGH
    )


def test_sense_no_complaints_reason() -> None:
    """Гейт пройден, но жалоб нет — причина отличается от непройденного гейта."""
    values = {"vision_loss_1yr": "Нет", "hearing_loss": "Нет"}
    assert (
        _reason(system_code="SENSE", risk_level="medium", patient_values=values)
        is InterpretationReasonCode.SENSE_NO_COMPLAINTS
    )


def test_resolved_doctors_have_no_reason() -> None:
    assert _reason(system_code="CVD", risk_level="high") is None
