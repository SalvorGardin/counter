"""§4.3 — rank_risk_factors + pick_score."""

from decimal import Decimal

from src.interpretation.domain.models import RiskFactorRow, ScoreRow
from src.interpretation.domain.risk_factors import rank_risk_factors, select_by_code, select_scored_factors
from src.interpretation.domain.scores import pick_score
from tests.consts import GENDER_MALE, PARAMETER_CODE_AGE, PARAMETER_CODE_BMI, PARAMETER_CODE_GENDER


def _rf(
    rfid: int,
    code: str,
    parameter_code: str,
    *,
    param_value: str | None = None,
    min_v: str | None = None,
    max_v: str | None = None,
    modifiability: str = "Модифицируемый",
    trigger_id: int | None = None,
    trigger_code: str | None = None,
) -> RiskFactorRow:
    return RiskFactorRow(
        risk_factor_id=rfid,
        trigger_id=trigger_id if trigger_id is not None else rfid,
        trigger_code=trigger_code if trigger_code is not None else f"trigger-{rfid}",
        code=code,
        parameter_code=parameter_code,
        description=code,
        reasoning=f"reason-{code}",
        value_type="text" if param_value is not None else "number",
        operator="eq" if param_value is not None else "between",
        value_num=None,
        min_value=Decimal(min_v) if min_v is not None else None,
        max_value=Decimal(max_v) if max_v is not None else None,
        value_text=param_value,
        gender=None,
        modifiability=modifiability,
    )


def test_numeric_operators_respect_boundaries_and_invalid_input_does_not_fallback() -> None:
    def numeric(risk_factor_id: int, operator: str) -> RiskFactorRow:
        return RiskFactorRow(
            risk_factor_id=risk_factor_id,
            trigger_id=risk_factor_id,
            trigger_code=f"trigger-{risk_factor_id}",
            code=operator,
            parameter_code="p",
            description="factor",
            reasoning=None,
            value_type="number",
            operator=operator,
            value_num=Decimal("3"),
            min_value=None,
            max_value=None,
            value_text=None,
            gender=None,
            modifiability="mod",
        )

    gte = numeric(1, "gte")
    lte = numeric(2, "lte")
    gt = numeric(3, "gt")
    lt = numeric(4, "lt")
    assert [r.code for r in rank_risk_factors(candidates=[gte], patient_params={"p": "3"}, scores_by_param={})] == [
        "gte"
    ]
    assert [r.code for r in rank_risk_factors(candidates=[lte], patient_params={"p": "3"}, scores_by_param={})] == [
        "lte"
    ]
    assert rank_risk_factors(candidates=[gt], patient_params={"p": "3"}, scores_by_param={}) == []
    assert rank_risk_factors(candidates=[lt], patient_params={"p": "3"}, scores_by_param={}) == []
    assert [r.code for r in rank_risk_factors(candidates=[gt], patient_params={"p": "3.1"}, scores_by_param={})] == [
        "gt"
    ]
    assert [r.code for r in rank_risk_factors(candidates=[lt], patient_params={"p": "2.9"}, scores_by_param={})] == [
        "lt"
    ]
    assert rank_risk_factors(candidates=[gte], patient_params={"p": "not-a-number"}, scores_by_param={}) == []


def test_decimal_comma_answer_matches_numeric_threshold() -> None:
    """Ответ с десятичной запятой сравнивается как число: `29,9` — это 29.9, а не мусор."""
    row = RiskFactorRow(
        risk_factor_id=1,
        trigger_id=1,
        trigger_code="trigger-1",
        code="bmi_excess",
        parameter_code=PARAMETER_CODE_BMI,
        description="избыток массы тела",
        reasoning=None,
        value_type="number",
        operator="between",
        value_num=None,
        min_value=Decimal("25"),
        max_value=Decimal("29.9"),
        value_text=None,
        gender=None,
        modifiability="mod",
    )
    matched = rank_risk_factors(candidates=[row], patient_params={PARAMETER_CODE_BMI: "29,9"}, scores_by_param={})
    assert [r.code for r in matched] == ["bmi_excess"]
    assert rank_risk_factors(candidates=[row], patient_params={PARAMETER_CODE_BMI: "30,1"}, scores_by_param={}) == []


def test_gender_specific_trigger_requires_exact_gender() -> None:
    row = RiskFactorRow(
        risk_factor_id=1,
        trigger_id=1,
        trigger_code="trigger-1",
        code="waist",
        parameter_code="waist_circumference",
        description="waist",
        reasoning=None,
        value_type="text",
        operator="eq",
        value_num=None,
        min_value=None,
        max_value=None,
        value_text=">102 см",
        gender=GENDER_MALE,
        modifiability="mod",
    )
    assert (
        rank_risk_factors(candidates=[row], patient_params={"waist_circumference": ">102 см"}, scores_by_param={}) == []
    )
    assert (
        len(
            rank_risk_factors(
                candidates=[row],
                patient_params={"waist_circumference": ">102 см", PARAMETER_CODE_GENDER: GENDER_MALE},
                scores_by_param={},
            )
        )
        == 1
    )


# ── rank_risk_factors ────────────────────────────────────────────────────────


def test_rank_empty() -> None:
    assert rank_risk_factors(candidates=[], patient_params={}, scores_by_param={}) == []


def test_rank_filter_by_value_match() -> None:
    candidates = [
        _rf(1, "f1", PARAMETER_CODE_AGE, min_v="18", max_v="40"),
        _rf(2, "f2", PARAMETER_CODE_AGE, min_v="50", max_v="65"),
    ]
    patient = {PARAMETER_CODE_AGE: "30"}
    result = rank_risk_factors(
        candidates=candidates, patient_params=patient, scores_by_param={PARAMETER_CODE_AGE: Decimal("1")}
    )
    assert [r.code for r in result] == ["f1"]


def test_rank_no_patient_param_excluded() -> None:
    candidates = [_rf(1, "f1", "smoking", param_value="yes")]
    result = rank_risk_factors(candidates=candidates, patient_params={}, scores_by_param={})
    assert result == []


def test_rank_exact_match() -> None:
    candidates = [_rf(1, "f1", "smoking", param_value="yes")]
    result = rank_risk_factors(candidates=candidates, patient_params={"smoking": "yes"}, scores_by_param={})
    assert [r.code for r in result] == ["f1"]


def test_rank_param_value_mismatch_excluded() -> None:
    candidates = [_rf(1, "f1", "smoking", param_value="yes")]
    result = rank_risk_factors(candidates=candidates, patient_params={"smoking": "no"}, scores_by_param={})
    assert result == []


def test_rank_sort_by_score_desc() -> None:
    candidates = [
        _rf(1, "low_score", "a", param_value="1"),
        _rf(2, "high_score", "b", param_value="1"),
    ]
    patient = {"a": "1", "b": "1"}
    scores = {"a": Decimal("1"), "b": Decimal("5")}
    result = rank_risk_factors(candidates=candidates, patient_params=patient, scores_by_param=scores)
    assert [r.code for r in result] == ["high_score", "low_score"]


def test_rank_tiebreak_by_trigger_id_asc() -> None:
    """При равных баллах порядок задаёт trigger_id — строка условия в порядке строк каталога.

    `trigger_code` подобран в обратном порядке к идентификаторам: очередь определяет именно
    trigger_id (wiki «Интерпретация» §4.3, шаг 3), а не лексикографический порядок кода.
    """
    candidates = [
        _rf(3, "f_late", "a", param_value="1", trigger_id=7, trigger_code="trigger-a"),
        _rf(7, "f_early", "b", param_value="1", trigger_id=3, trigger_code="trigger-b"),
    ]
    patient = {"a": "1", "b": "1"}
    scores = {"a": Decimal("5"), "b": Decimal("5")}
    result = rank_risk_factors(candidates=candidates, patient_params=patient, scores_by_param=scores)
    assert [r.code for r in result] == ["f_early", "f_late"]


def test_rank_none_score_goes_last() -> None:
    candidates = [
        _rf(1, "no_score", "a", param_value="1"),
        _rf(2, "with_score", "b", param_value="1"),
    ]
    patient = {"a": "1", "b": "1"}
    scores: dict[str, Decimal | None] = {"a": None, "b": Decimal("1")}
    result = rank_risk_factors(candidates=candidates, patient_params=patient, scores_by_param=scores)
    assert [r.code for r in result] == ["with_score", "no_score"]


def test_rank_modifiable_and_unmodifiable_both_included() -> None:
    """§4.3: фильтр по modifiability не применяется."""
    candidates = [
        _rf(1, "modifiable", "smoking", param_value="yes"),
        _rf(2, "non_modifiable", PARAMETER_CODE_AGE, min_v="60", max_v="100"),
    ]
    patient = {"smoking": "yes", PARAMETER_CODE_AGE: "70"}
    scores = {"smoking": Decimal("1"), PARAMETER_CODE_AGE: Decimal("2")}
    result = rank_risk_factors(candidates=candidates, patient_params=patient, scores_by_param=scores)
    assert {r.code for r in result} == {"modifiable", "non_modifiable"}


# ── pick_score ───────────────────────────────────────────────────────────────


def test_pick_score_no_patient_value_returns_none() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("40"),
            score=Decimal("1"),
        )
    ]
    assert pick_score(rows, None) is None


def test_pick_score_no_rows_returns_none() -> None:
    assert pick_score([], "30") is None


def test_pick_score_range_match() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("40"),
            score=Decimal("1"),
        ),
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("41"),
            max_value=Decimal("65"),
            score=Decimal("3"),
        ),
    ]
    assert pick_score(rows, "30") == Decimal("1")
    assert pick_score(rows, "50") == Decimal("3")


def test_pick_score_no_match_returns_none() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("40"),
            score=Decimal("1"),
        ),
    ]
    assert pick_score(rows, "100") is None


def test_pick_score_exact_value_match() -> None:
    rows = [
        ScoreRow(parameter_code=PARAMETER_CODE_GENDER, value="male", min_value=None, max_value=None, score=Decimal("2"))
    ]
    assert pick_score(rows, "male") == Decimal("2")
    assert pick_score(rows, "female") is None


def test_pick_score_overlapping_returns_max() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("50"),
            score=Decimal("1"),
        ),
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("30"),
            max_value=Decimal("60"),
            score=Decimal("3"),
        ),
    ]
    assert pick_score(rows, "40") == Decimal("3")


def test_pick_score_lower_boundary_inclusive() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("40"),
            score=Decimal("1"),
        )
    ]
    assert pick_score(rows, "0") == Decimal("1")


def test_pick_score_upper_boundary_inclusive() -> None:
    rows = [
        ScoreRow(
            parameter_code=PARAMETER_CODE_AGE,
            value=None,
            min_value=Decimal("0"),
            max_value=Decimal("40"),
            score=Decimal("1"),
        )
    ]
    assert pick_score(rows, "40") == Decimal("1")


# ── select_by_code ───────────────────────────────────────────────────────────


def _ranked(*rows: RiskFactorRow) -> list:
    """Пропускает строки через отбор так, чтобы сработали все переданные."""
    patient = {
        row.parameter_code: row.value_text or (str(row.min_value) if row.min_value is not None else "1") for row in rows
    }
    return rank_risk_factors(candidates=list(rows), patient_params=patient, scores_by_param={})


def test_select_empty_collapses_to_missing_value() -> None:
    """Пусто — это отсутствующее значение, а не пустой список: разница доходит до контракта API."""
    selection = select_by_code([])
    assert selection.codes is None
    assert selection.matches == ()


def test_select_keeps_one_representative_per_code() -> None:
    ranked = _ranked(_rf(1, "f1", "a", param_value="1"), _rf(2, "f1", "b", param_value="1"))
    selection = select_by_code(ranked)
    assert selection.codes == ["f1"]


def test_select_marks_exactly_one_representative() -> None:
    ranked = _ranked(
        _rf(1, "f1", "a", param_value="1"),
        _rf(2, "f1", "b", param_value="1"),
        _rf(3, "f1", "c", param_value="1"),
    )
    selection = select_by_code(ranked)
    assert [(m.factor.risk_factor_id, m.is_representative) for m in selection.matches] == [
        (1, True),
        (2, False),
        (3, False),
    ]


def test_select_representative_is_first_by_rank() -> None:
    """Правило прежнее: представитель — первый по текущему порядку ранжирования."""
    rows = [_rf(9, "f1", "a", param_value="1"), _rf(4, "f1", "b", param_value="1")]
    ranked = _ranked(*rows)
    selection = select_by_code(ranked)
    representative = next(m for m in selection.matches if m.is_representative)
    assert representative.factor.risk_factor_id == ranked[0].risk_factor_id


def test_select_keeps_code_order_of_ranking() -> None:
    ranked = _ranked(_rf(1, "f_a", "a", param_value="1"), _rf(2, "f_b", "b", param_value="1"))
    assert select_by_code(ranked).codes == ["f_a", "f_b"]


def test_select_carries_condition_snapshot() -> None:
    """В снимке — данные справочника: условие и modifiability, без значений ответов пациента."""
    ranked = _ranked(_rf(1, "f1", PARAMETER_CODE_AGE, min_v="60", max_v="100", modifiability="Немодифицируемый"))
    (match,) = select_by_code(ranked).matches
    assert (match.factor.min_value, match.factor.max_value) == (Decimal("60"), Decimal("100"))
    assert match.factor.modifiability == "Немодифицируемый"


def test_rank_is_pure_and_repeatable_outside_a_run() -> None:
    """Отбор пригоден к пересчёту по запросу: тот же вход — тот же результат, без БД и настроек.

    На этом держится решение не хранить несработавших кандидатов: читающая сторона пересчитает
    их для конкретного случая теми же аргументами.
    """
    candidates = [_rf(1, "f1", PARAMETER_CODE_AGE, min_v="18", max_v="40"), _rf(2, "f2", "smoking", param_value="yes")]
    patient = {PARAMETER_CODE_AGE: "30", "smoking": "yes"}
    scores = {PARAMETER_CODE_AGE: Decimal("1"), "smoking": Decimal("2")}
    first = rank_risk_factors(candidates=candidates, patient_params=patient, scores_by_param=scores)
    second = rank_risk_factors(candidates=list(candidates), patient_params=dict(patient), scores_by_param=dict(scores))
    assert first == second


# --- select_scored_factors: вход первого источника (§4.3, шаг 1а) ---


def test_scored_selection_drops_conditions_without_a_score_row() -> None:
    """Условие без строки оценок первому источнику не принадлежит, хотя `rank_risk_factors` его берёт.

    Проверка нужна на этой функции, а не на отборе: сужение — единственное, что отличает кандидата
    первого блока от произвольного условия системы, и живёт оно здесь, в одном экземпляре на
    интерпретацию и на разбор несработавших кандидатов.
    """
    scored = _rf(1, "RF_SCORED", PARAMETER_CODE_BMI, min_v="30", max_v="40")
    unscored = _rf(2, "RF_UNSCORED", PARAMETER_CODE_AGE, min_v="40", max_v="60")

    result = select_scored_factors(
        system_candidates=[scored, unscored],
        score_rows={
            PARAMETER_CODE_BMI: (ScoreRow(PARAMETER_CODE_BMI, None, Decimal("30"), Decimal("40"), Decimal("2")),)
        },
        patient_params={PARAMETER_CODE_BMI: "31", PARAMETER_CODE_AGE: "50"},
    )

    assert [row.code for row in result.candidates] == ["RF_SCORED"]
    assert [row.code for row in result.ranked] == ["RF_SCORED"]


def test_scored_selection_carries_the_score_into_the_ranking() -> None:
    low = _rf(1, "RF_LOW", PARAMETER_CODE_BMI, min_v="25", max_v="35")
    high = _rf(2, "RF_HIGH", PARAMETER_CODE_AGE, min_v="40", max_v="60")

    result = select_scored_factors(
        system_candidates=[low, high],
        score_rows={
            PARAMETER_CODE_BMI: (ScoreRow(PARAMETER_CODE_BMI, None, Decimal("25"), Decimal("35"), Decimal("1")),),
            PARAMETER_CODE_AGE: (ScoreRow(PARAMETER_CODE_AGE, None, Decimal("40"), Decimal("60"), Decimal("5")),),
        },
        patient_params={PARAMETER_CODE_BMI: "31", PARAMETER_CODE_AGE: "50"},
    )

    assert [row.code for row in result.ranked] == ["RF_HIGH", "RF_LOW"]
