"""Причины по несработавшим кандидатам в факторы риска."""

from decimal import Decimal

from src.explanation.domain.constants import UnmatchedReasonCode
from src.explanation.domain.models import CandidateSources, ParameterSelection
from src.explanation.domain.unmatched import unmatched_candidates
from src.interpretation.domain.models import RiskFactorRow
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_AGE, PARAMETER_CODE_BMI, PARAMETER_CODE_GENDER


def _factor(
    risk_factor_id: int,
    parameter_code: str,
    *,
    operator: str = "eq",
    value_num: str | None = None,
    gender: str | None = None,
) -> RiskFactorRow:
    return RiskFactorRow(
        risk_factor_id=risk_factor_id,
        trigger_id=risk_factor_id,
        trigger_code=f"trigger-{risk_factor_id}",
        code=f"RF_{risk_factor_id}",
        parameter_code=parameter_code,
        description="фактор",
        reasoning="причина",
        value_type="text" if operator == "eq" else "number",
        operator=operator,
        value_num=Decimal(value_num) if value_num is not None else None,
        min_value=None,
        max_value=None,
        value_text="Да" if operator == "eq" else None,
        gender=gender,
        modifiability="modifiable",
    )


def _sources(
    *,
    system: set[str],
    scored: set[str] | None = None,
    clinrec_triggers: set[str] | None = None,
    clinrec_params: set[str] | None = None,
) -> CandidateSources:
    """По умолчанию у каждого показателя системы есть оценка: первый источник отбирает их все."""
    return CandidateSources(
        system_parameter_codes=frozenset(system),
        scored_parameter_codes=frozenset(system if scored is None else scored),
        clinrec_trigger_codes=frozenset(clinrec_triggers or ()),
        clinrec_parameter_codes=frozenset(clinrec_params or ()),
    )


def test_reason_per_candidate() -> None:
    outside = _factor(1, "foreign_param")
    unanswered = _factor(2, "system_param_b")
    mismatched = _factor(3, "system_param_c")
    matched = _factor(4, "system_param_d")

    result = unmatched_candidates(
        candidates=[outside, unanswered, mismatched, matched],
        sources=_sources(system={"system_param_b", "system_param_c", "system_param_d"}),
        patient_answers={"system_param_c": "Нет", "system_param_d": "Да", "foreign_param": "Да"},
        matched_trigger_codes={matched.trigger_code},
    )

    assert [(candidate.factor.risk_factor_id, candidate.reason_code) for candidate in result] == [
        (1, UnmatchedReasonCode.PARAMETER_NOT_IN_SYSTEM),
        (2, UnmatchedReasonCode.PARAMETER_NOT_ANSWERED),
        (3, UnmatchedReasonCode.OPERATOR_MISMATCH),
    ]


def test_matched_candidates_are_excluded() -> None:
    factor = _factor(1, "p")
    assert (
        unmatched_candidates(
            candidates=[factor],
            sources=_sources(system={"p"}),
            patient_answers={"p": "Да"},
            matched_trigger_codes={factor.trigger_code},
        )
        == []
    )


def test_gender_specific_candidate_reports_gender_mismatch() -> None:
    """Условие с полом у пациента другого пола — отдельная причина, а не «условие не выполнено».

    Иначе читающая сторона объясняла бы несрабатывание порогом, который к пациенту не относится
    вовсе: четыре строки обхвата талии заведены парами под каждый пол.
    """
    result = unmatched_candidates(
        candidates=[_factor(1, "waist", operator="gte", value_num="102", gender=GENDER_MALE)],
        sources=_sources(system={"waist"}),
        patient_answers={"waist": "110", PARAMETER_CODE_GENDER: GENDER_FEMALE},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.GENDER_MISMATCH


def test_unknown_patient_gender_is_a_gender_mismatch() -> None:
    result = unmatched_candidates(
        candidates=[_factor(1, "waist", operator="gte", value_num="102", gender=GENDER_MALE)],
        sources=_sources(system={"waist"}),
        patient_answers={"waist": "110"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.GENDER_MISMATCH


def test_non_numeric_answer_to_numeric_condition_reports_invalid_value() -> None:
    """Числовое условие поверх нечислового ответа — расхождение данных, а не невыполненный порог."""
    result = unmatched_candidates(
        candidates=[_factor(1, PARAMETER_CODE_AGE, operator="gte", value_num="40")],
        sources=_sources(system={PARAMETER_CODE_AGE}),
        patient_answers={PARAMETER_CODE_AGE: "затрудняюсь ответить"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.INVALID_NUMERIC_VALUE


def test_decimal_comma_answer_is_a_number_not_an_invalid_value() -> None:
    result = unmatched_candidates(
        candidates=[_factor(1, PARAMETER_CODE_BMI, operator="gte", value_num="30")],
        sources=_sources(system={PARAMETER_CODE_BMI}),
        patient_answers={PARAMETER_CODE_BMI: "29,9"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.OPERATOR_MISMATCH


def test_foreign_parameter_wins_over_answer_state() -> None:
    # Показатель, не относящийся к системе, до отбора не доходит вовсе — говорить о его ответе
    # нечего, даже если ответ есть и в условие он попадает.
    result = unmatched_candidates(
        candidates=[_factor(1, "foreign")],
        sources=_sources(system=set()),
        patient_answers={"foreign": "Да"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.PARAMETER_NOT_IN_SYSTEM


def test_parameter_without_score_is_not_a_candidate_of_the_first_source() -> None:
    """Показатель системы без строки оценок первый источник не отбирает (§4.3, шаг 1а).

    Объяснять такое несрабатывание оператором нельзя: условие до сравнения значения не доходит,
    и «ответ не удовлетворяет условию» было бы прямой ложью — ответ в условие как раз попадает.
    """
    result = unmatched_candidates(
        candidates=[_factor(1, "unscored")],
        sources=_sources(system={"unscored"}, scored=set()),
        patient_answers={"unscored": "Да"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.PARAMETER_SCORE_MISSING


def test_biomarker_without_applicable_disease_reports_the_clinrec_gate() -> None:
    """У биомаркера вход другой — применимая группа заболеваний (§4.3, шаг 1б.1), и её нет."""
    result = unmatched_candidates(
        candidates=[_factor(1, "biomarker_glucose")],
        sources=_sources(system={"biomarker_glucose"}, scored=set(), clinrec_params={"biomarker_glucose"}),
        patient_answers={"biomarker_glucose": "Да"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.CLINREC_DISEASE_NOT_APPLICABLE


def test_clinrec_candidate_is_judged_by_its_condition_not_by_system_parameters() -> None:
    """Кандидат второго блока проверяется условием, даже если его показатель — не показатель системы.

    Условие клинрек-фактора задано на биомаркере и от привязки показателя к инструментам системы
    не зависит (§4.3, шаг 1б.3): причина `parameter_not_in_system` тут была бы неверной.
    """
    factor = _factor(1, "biomarker_glucose", operator="gte", value_num="7")
    result = unmatched_candidates(
        candidates=[factor],
        sources=_sources(
            system=set(),
            clinrec_triggers={factor.trigger_code},
            clinrec_params={"biomarker_glucose"},
        ),
        patient_answers={"biomarker_glucose": "5"},
        matched_trigger_codes=set(),
    )
    assert result[0].reason_code is UnmatchedReasonCode.OPERATOR_MISMATCH


def test_parameter_excluded_as_duplicate_is_not_reported_as_unanswered() -> None:
    """Отвеченный показатель, вытесненный более свежей единицей того же биомаркера, — своя причина."""
    excluded = _factor(1, "lipoprotein_old")
    unanswered = _factor(2, "lipoprotein_other")

    result = unmatched_candidates(
        candidates=[excluded, unanswered],
        sources=_sources(system={"lipoprotein_old", "lipoprotein_other"}),
        patient_answers={},
        matched_trigger_codes=set(),
        selections_by_trigger_code={
            excluded.trigger_code: ParameterSelection({}, frozenset({"lipoprotein_old"})),
            unanswered.trigger_code: ParameterSelection({}, frozenset({"lipoprotein_old"})),
        },
    )

    assert [candidate.reason_code for candidate in result] == [
        UnmatchedReasonCode.PARAMETER_EXCLUDED_AS_DUPLICATE,
        UnmatchedReasonCode.PARAMETER_NOT_ANSWERED,
    ]
