"""Перепроверка снимка условия на текущих ответах пациента.

Сравнение общее с отбором (`src/domain/risk_factor_conditions.py`), поэтому здесь же проверяется,
что обе стороны отвечают одинаково: расхождение между «сработало при расчёте» и «сработало бы
сейчас» читающая сторона показала бы как изменение ответа пациента.
"""

from datetime import UTC, datetime
from decimal import Decimal

import pytest

from src.explanation.domain.models import RiskFactorMatchView
from src.explanation.service import _snapshot_matches
from src.interpretation.domain.models import RiskFactorRow
from src.interpretation.domain.risk_factors import trigger_matches
from tests.consts import GENDER_FEMALE, GENDER_MALE


def _match(
    operator: str,
    *,
    value_num: str | None = "3",
    min_value: str | None = None,
    max_value: str | None = None,
    value_text: str | None = None,
    gender: str | None = None,
) -> RiskFactorMatchView:
    return RiskFactorMatchView(
        system_code="CVD",
        trigger_code=f"threshold-{operator}",
        risk_factor_code="threshold",
        factor_description="threshold",
        reasoning=None,
        parameter_code="p",
        value_type="text" if operator == "eq" else "number",
        operator=operator,
        value_num=Decimal(value_num) if value_num is not None else None,
        min_value=Decimal(min_value) if min_value is not None else None,
        max_value=Decimal(max_value) if max_value is not None else None,
        value_text=value_text,
        gender=gender,
        modifiability="modifiable",
        is_representative=True,
        date_time=datetime.now(UTC),
    )


def _row(match: RiskFactorMatchView) -> RiskFactorRow:
    """Та же строка условия на стороне отбора."""
    return RiskFactorRow(
        risk_factor_id=1,
        trigger_id=1,
        trigger_code=match.trigger_code,
        code=match.risk_factor_code,
        parameter_code=match.parameter_code,
        description=match.factor_description,
        reasoning=match.reasoning,
        value_type=match.value_type,
        operator=match.operator,
        value_num=match.value_num,
        min_value=match.min_value,
        max_value=match.max_value,
        value_text=match.value_text,
        gender=match.gender,
        modifiability=match.modifiability,
    )


_CASES: list[tuple[RiskFactorMatchView, str, str | None, bool]] = [
    (_match("gt"), "3", None, False),
    (_match("gt"), "3.1", None, True),
    (_match("gte"), "3", None, True),
    (_match("gte"), "2.9", None, False),
    (_match("lt"), "3", None, False),
    (_match("lt"), "2.9", None, True),
    (_match("lte"), "3", None, True),
    (_match("lte"), "3.1", None, False),
    (_match("between", value_num=None, min_value="25", max_value="29.9"), "25", None, True),
    (_match("between", value_num=None, min_value="25", max_value="29.9"), "29.9", None, True),
    (_match("between", value_num=None, min_value="25", max_value="29.9"), "30", None, False),
    (_match("between", value_num=None, min_value="25", max_value="29.9"), "24.9", None, False),
    (_match("eq", value_num=None, value_text="Да"), "Да", None, True),
    (_match("eq", value_num=None, value_text="Да"), "Нет", None, False),
    # Десятичная запятая в ответе пациента — рабочая форма, а не мусор.
    (_match("gte"), "3,0", None, True),
    (_match("between", value_num=None, min_value="25", max_value="29.9"), "29,9", None, True),
    (_match("gte"), "не число", None, False),
    # Условие с полом требует точного совпадения; без пола пациента не срабатывает.
    (_match("gte", gender=GENDER_MALE), "4", GENDER_MALE, True),
    (_match("gte", gender=GENDER_MALE), "4", GENDER_FEMALE, False),
    (_match("gte", gender=GENDER_MALE), "4", None, False),
    # Пустой пол в условии — «без ограничения».
    (_match("gte"), "4", GENDER_FEMALE, True),
    # Неполное условие: у сравнения с порогом нет самого порога, у диапазона — границы.
    # Такая строка справочника не срабатывает никогда, вместо того чтобы падать на сравнении
    # с None. Значение ответа при этом заведомо числовое — проверяется именно неполнота условия.
    (_match("gt", value_num=None), "4", None, False),
    (_match("gte", value_num=None), "4", None, False),
    (_match("lt", value_num=None), "4", None, False),
    (_match("lte", value_num=None), "4", None, False),
    (_match("between", value_num=None, min_value=None, max_value="29.9"), "26", None, False),
    (_match("between", value_num=None, min_value="25", max_value=None), "26", None, False),
    (_match("between", value_num=None, min_value=None, max_value=None), "26", None, False),
    # Перевёрнутый диапазон пуст: ни одно значение в него не попадает.
    (_match("between", value_num=None, min_value="29.9", max_value="25"), "27", None, False),
    # Оператор вне словаря — условие не срабатывает, а не считается пройденным по умолчанию:
    # неизвестное правило не должно показывать пациенту фактор риска.
    (_match("ge"), "100", None, False),
    (_match(""), "100", None, False),
    # eq без текста сравнения: пустой ответ не совпадает с отсутствующим значением.
    (_match("eq", value_num=None, value_text=None), "", None, False),
]


@pytest.mark.parametrize(("match", "answer", "gender", "expected"), _CASES)
def test_snapshot_matches_condition(
    match: RiskFactorMatchView, answer: str, gender: str | None, expected: bool
) -> None:
    assert _snapshot_matches(match, answer, gender) is expected


@pytest.mark.parametrize(("match", "answer", "gender", "expected"), _CASES)
def test_snapshot_and_selection_agree(
    match: RiskFactorMatchView, answer: str, gender: str | None, expected: bool
) -> None:
    assert trigger_matches(_row(match), answer, gender) is expected
