"""Ответы пациента в логах: имена полей схемы обязаны попадать под маск-лист.

Тело ответа пишется в лог целиком (решение на период тестирования, см. CLAUDE.md), поэтому
защита от утечки ПДн держится на имени поля: `answer` есть в `DEFAULT_LOG_MASK_KEYS`.
Тест смотрит на настоящую схему ответа и настоящий форматтер — переименование поля его роняет.
"""

import json
import logging
from datetime import UTC, datetime

from src.api.v1.testing.explanation.schemas import (
    InstrumentParameterExplanation,
    RiskFactorCondition,
    UnmatchedRiskFactor,
    UnmatchedRiskFactorsResponse,
)
from src.logger import MonologFormatter
from tests.consts import PARAMETER_CODE_WEIGHT

ANSWER = "СЕКРЕТНЫЙ-ОТВЕТ-ПАЦИЕНТА"


def _response() -> UnmatchedRiskFactorsResponse:
    return UnmatchedRiskFactorsResponse(
        patient_id="patient-1",
        system_code="CVD",
        recomputed_at=datetime(2026, 8, 11, tzinfo=UTC),
        items=[
            UnmatchedRiskFactor(
                trigger_code="trigger-1",
                risk_factor_code="RF",
                name="Фактор",
                reasoning=None,
                parameter_code="smoke",
                parameter_name="Курение",
                condition=RiskFactorCondition(value_type="text", operator="eq", value_text="Да"),
                modifiability="modifiable",
                answer=ANSWER,
                reason_code="operator_mismatch",
                reason_text="Ответ пациента не попадает в условие фактора.",
            )
        ],
    )


def _format(context: dict[str, object]) -> str:
    record = logging.LogRecord(
        name="app",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="request completed",
        args=(),
        exc_info=None,
    )
    record.log_context = context
    return MonologFormatter().format(record)


def test_patient_answer_is_masked_in_response_body_log() -> None:
    body = _response().model_dump(by_alias=True, mode="json")
    # Ответ действительно несёт значение — иначе тест проверял бы пустоту.
    assert body["items"][0]["answer"] == ANSWER
    # Wire-ключи, которые читает web-панель: защита от незаметного расхождения camelCase-контракта.
    assert body["items"][0]["triggerCode"] == "trigger-1"
    assert body["items"][0]["riskFactorCode"] == "RF"
    assert body["items"][0]["condition"] == {
        "valueType": "text",
        "operator": "eq",
        "valueNum": None,
        "minValue": None,
        "maxValue": None,
        "valueText": "Да",
        "gender": None,
    }

    output = _format({"response_body": body})

    assert ANSWER not in output
    logged_body = json.loads(json.loads(output)["context"]["response_body"])
    assert logged_body["items"][0]["answer"] == "***"
    # Остальные поля объяснения остаются читаемыми: маскируется значение ответа, а не разбор.
    assert logged_body["items"][0]["reasonCode"] == "operator_mismatch"


def test_instrument_parameter_answer_is_masked_in_response_body_log() -> None:
    parameter = InstrumentParameterExplanation(
        code=PARAMETER_CODE_WEIGHT,
        name="Масса тела",
        required=True,
        answer=ANSWER,
    )
    body = {"parameters": [parameter.model_dump(by_alias=True, mode="json")]}

    output = _format({"response_body": body})

    assert ANSWER not in output
    logged_body = json.loads(json.loads(output)["context"]["response_body"])
    assert logged_body["parameters"][0]["answer"] == "***"
