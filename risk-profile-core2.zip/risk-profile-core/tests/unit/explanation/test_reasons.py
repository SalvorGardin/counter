"""Формулировки причин: полнота таксономий, неизвестный код, группировка технических причин."""

from src.calc.domain.models import STATUS_BY_REASON, CalcReasonCode, CalcStatus
from src.explanation.domain.reasons import (
    CALC_REASON_TEXTS,
    INTERPRETATION_REASON_TEXTS,
    UNKNOWN_REASON_TEXT,
    describe_calc_reason,
    describe_interpretation_reason,
)
from src.interpretation.domain.models import InterpretationReasonCode


def test_every_calc_reason_code_has_text() -> None:
    # Формулировки живут в коде, а набор кодов — в сборе: расхождение обнаруживается тестом,
    # а не пустым местом в ответе.
    assert {code.value for code in CalcReasonCode} <= set(CALC_REASON_TEXTS)


def test_every_interpretation_reason_code_has_text() -> None:
    assert {code.value for code in InterpretationReasonCode} <= set(INTERPRETATION_REASON_TEXTS)


def test_unknown_code_keeps_neutral_text() -> None:
    # Код, добавленный сбором раньше чтения, не теряется: текст нейтральный, код отдаётся отдельным
    # полем (см. схемы `reasonCode` рядом с `reasonText`).
    assert describe_calc_reason("brand_new_reason") == UNKNOWN_REASON_TEXT
    assert describe_interpretation_reason("brand_new_reason") == UNKNOWN_REASON_TEXT


def test_absent_reason_has_no_text() -> None:
    assert describe_calc_reason(None) is None
    assert describe_interpretation_reason(None) is None


def test_technical_reasons_share_one_status_and_keep_distinct_codes() -> None:
    technical = (CalcReasonCode.CVD_DISABLED, CalcReasonCode.CVD_ERROR, CalcReasonCode.CALCULATION_ERROR)
    assert {STATUS_BY_REASON[code] for code in technical} == {CalcStatus.UNAVAILABLE}
    assert len({code.value for code in technical}) == len(technical)
    # Формулировки тоже различимы: проверяющий не должен приписать модели недоступность сервиса.
    assert len({CALC_REASON_TEXTS[code.value] for code in technical}) == len(technical)


def test_technical_status_is_separate_from_data_and_applicability() -> None:
    assert STATUS_BY_REASON[CalcReasonCode.PREGNANT] is CalcStatus.NOT_APPLICABLE
    assert STATUS_BY_REASON[CalcReasonCode.NOT_ENOUGH_ANSWERS] is CalcStatus.INSUFFICIENT_DATA
