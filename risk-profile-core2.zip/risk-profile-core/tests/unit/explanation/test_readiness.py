"""Готовность объяснения: три состояния вместо двух, окно между транзакциями, отставший прогон."""

from datetime import UTC, datetime, timedelta

from src.explanation.domain.constants import (
    EXPLANATION_PENDING_WINDOW_SECONDS,
    InstrumentExplanationState,
    SystemExplanationState,
)
from src.explanation.domain.readiness import instrument_explanation_state, system_explanation_state

NOW = datetime(2026, 8, 11, 12, 0, tzinfo=UTC)
JUST_NOW = NOW - timedelta(seconds=1)
LONG_AGO = NOW - timedelta(seconds=EXPLANATION_PENDING_WINDOW_SECONDS + 1)


def _instrument(
    *, status_at: datetime | None, result_at: datetime | None, questionnaire_started: bool = True
) -> InstrumentExplanationState:
    return instrument_explanation_state(
        status_at=status_at,
        result_at=result_at,
        now=NOW,
        questionnaire_started=questionnaire_started,
    )


def test_status_not_older_than_result_matches() -> None:
    assert _instrument(status_at=NOW, result_at=JUST_NOW) is InstrumentExplanationState.MATCHES


def test_status_without_result_matches() -> None:
    # Строка сбора и объясняет, почему результата нет: это согласованное состояние, не дефект.
    assert _instrument(status_at=NOW, result_at=None) is InstrumentExplanationState.MATCHES


def test_status_older_than_result_is_previous_run() -> None:
    assert _instrument(status_at=LONG_AGO, result_at=NOW) is InstrumentExplanationState.PREVIOUS_RUN


def test_fresh_result_without_status_is_pending() -> None:
    # Окно между коммитом результата и коммитом объяснения — «готовится», а не «причины нет».
    assert _instrument(status_at=None, result_at=JUST_NOW) is InstrumentExplanationState.PENDING


def test_stale_result_without_status_is_missing() -> None:
    assert _instrument(status_at=None, result_at=LONG_AGO) is InstrumentExplanationState.MISSING


def test_no_result_and_answers_present_is_not_calculated() -> None:
    assert (
        _instrument(status_at=None, result_at=None, questionnaire_started=True)
        is InstrumentExplanationState.NOT_CALCULATED
    )


def test_no_result_and_no_answers_is_questionnaire_not_started() -> None:
    assert (
        _instrument(status_at=None, result_at=None, questionnaire_started=False)
        is InstrumentExplanationState.QUESTIONNAIRE_NOT_STARTED
    )


def test_naive_timestamps_are_compared_as_utc() -> None:
    # Строки, вставленные мимо приложения, приезжают наивными — сравнение не должно падать.
    naive_status = NOW.replace(tzinfo=None)
    assert _instrument(status_at=naive_status, result_at=JUST_NOW) is InstrumentExplanationState.MATCHES


def test_system_states() -> None:
    assert (
        system_explanation_state(status_at=NOW, interpretation_at=JUST_NOW, now=NOW) is SystemExplanationState.MATCHES
    )
    assert (
        system_explanation_state(status_at=LONG_AGO, interpretation_at=NOW, now=NOW)
        is SystemExplanationState.PREVIOUS_RUN
    )
    assert (
        system_explanation_state(status_at=None, interpretation_at=JUST_NOW, now=NOW) is SystemExplanationState.PENDING
    )
    assert (
        system_explanation_state(status_at=None, interpretation_at=LONG_AGO, now=NOW) is SystemExplanationState.MISSING
    )
    assert (
        system_explanation_state(status_at=None, interpretation_at=None, now=NOW)
        is SystemExplanationState.NOT_INTERPRETED
    )
