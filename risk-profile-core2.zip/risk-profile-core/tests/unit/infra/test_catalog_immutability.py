import pytest

from tests.conftest import build_calc_catalog


def test_catalog_maps_reject_mutation():
    cat = build_calc_catalog()
    with pytest.raises(TypeError):
        cat.instrument_configs["x"] = None  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.system_codes_by_instrument["x"] = ()  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.question_codes_by_instrument["x"] = frozenset()  # ty: ignore[invalid-assignment]


def test_instrument_definition_codes_are_tuples():
    cat = build_calc_catalog()
    d = cat.instrument_configs["form_a"]
    assert isinstance(d.required_parameter_codes, tuple)
    with pytest.raises(AttributeError):
        d.required_parameter_codes.append("z")  # ty: ignore[unresolved-attribute]
