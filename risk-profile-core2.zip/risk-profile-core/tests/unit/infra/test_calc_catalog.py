from decimal import Decimal
from types import MappingProxyType

import pytest

from src.calc.domain.consts import (
    BIOMARKER_CLINREC_INSTRUMENT_CODE,
    FORM_COMMON_INSTRUMENT_CODE,
    INSTRUMENT_TYPE_BIOMARKER_CLINREC,
)
from src.infra.catalog.base import Catalog, CatalogLoadError
from src.infra.catalog.calc import CalcCatalog
from src.services.risk_communication.domain.models import ConditionView
from tests.catalog_builder import (
    condition,
    disease,
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    parameter,
    question,
    risk_factor_score,
    risk_factor_system,
    risk_factor_trigger,
    score,
    system_instrument,
)
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER


def _catalog() -> Catalog:
    return make_catalog(
        conditions=[
            condition("Q_OPT", PARAMETER_CODE_GENDER, value=GENDER_FEMALE),
            condition("Q_OPT", PARAMETER_CODE_AGE, type="age", min_age=18, max_age=65),
        ],
        instruments=[
            instrument("form_a", instrument_id=1),
            instrument("form_shared", instrument_id=2),
            instrument("calc_b", type="calc", instrument_id=3),
            instrument("old_c", status="inactive", instrument_id=4),
        ],
        instruments_parameters=[
            instrument_parameter("form_a", "p_gen", is_required=True),
            instrument_parameter("form_a", "p_opt"),
            # form_shared шэрит p_opt с form_a → вопрос Q_OPT принадлежит обоим.
            instrument_parameter("form_shared", "p_opt"),
            instrument_parameter("calc_b", "p_gen"),
            # p_calc живёт только на calc_b, но calc_b — второй инструмент системы s1,
            # поэтому его вопрос попадает в пул form_a (пул строится по СИСТЕМЕ).
            instrument_parameter("calc_b", "p_calc"),
            instrument_parameter("old_c", "p_x", is_required=True),
        ],
        options=[
            option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen", value="yes", option_id=1),
            # Q_OPT пишет два параметра: p_opt (не-«общий» параметр form_a) и p_extra
            # (в form_a не входит) — «отвечен» требует ОБА, см. params_by_question.
            option("OPT_A1", question_code="Q_OPT", parameter_code="p_opt", value="yes", option_id=2),
            option("OPT_A2", question_code="Q_OPT", parameter_code="p_extra", value="no", option_id=3),
            option("OPT_C1", question_code="Q_CALC", parameter_code="p_calc", value="yes", option_id=4),
            option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="sad", option_id=5),
            option("BDI1_04", question_code="BDI1", parameter_code="bdi1", value="very sad", option_id=6),
        ],
        questions=[
            question("Q_GEN", group_code=1, question_id=1),  # group_code=1 → general
            question("Q_OPT", question_id=2),
            question("Q_CALC", question_id=3),
            question("BDI1", question_id=4),
        ],
        systems_instruments=[
            system_instrument("s1", "form_a"),
            system_instrument("s2", "form_a"),
            system_instrument("s1", "calc_b"),
            system_instrument("s3", "form_shared"),
        ],
        parameter_scores=[
            score("p_gen", "s1", value="yes", score=Decimal("2")),
            score("p_opt", "s2", min_value=Decimal("10"), max_value=Decimal("20"), score=Decimal("3")),
        ],
    )


def test_instrument_configs_active_only_with_tuples():
    cat = CalcCatalog(_catalog())
    cfg = cat.instrument_configs
    assert set(cfg) == {"form_a", "form_shared", "calc_b"}  # inactive old_c excluded
    assert cfg["form_a"].required_parameter_codes == ("p_gen",)
    assert cfg["form_a"].optional_parameter_codes == ("p_opt",)


def _partition_catalog() -> Catalog:
    """Каталог со всеми тремя видами инструментов: формульный, опросник и контейнер form_common."""
    return make_catalog(
        instruments=[
            instrument("score_2", type="calc", instrument_id=1),
            instrument("form_cvd", instrument_id=2),
            instrument(FORM_COMMON_INSTRUMENT_CODE, instrument_id=3),
            instrument("form_onco", status="inactive", instrument_id=4),
        ],
        instruments_parameters=[
            instrument_parameter("score_2", "p_calc", is_required=True),
            instrument_parameter("form_cvd", "p_cvd"),
            instrument_parameter(FORM_COMMON_INSTRUMENT_CODE, "p_common"),
            instrument_parameter("form_onco", "p_onco"),
        ],
        # BDI-вопрос с опциями обязателен: без него CalcCatalog падает на пустой bdi_score_map.
        questions=[question("BDI1", question_id=5)],
        options=[
            option("BDI1_01", question_code="BDI1", parameter_code="bdi1", value="ok", option_id=1),
            option("BDI1_04", question_code="BDI1", parameter_code="bdi1", value="very sad", option_id=2),
        ],
    )


def test_formula_configs_drop_questionnaires_and_form_common():
    cat = CalcCatalog(_partition_catalog())
    assert set(cat.formula_configs) == {"score_2"}
    # Та же запись, что и в instrument_configs: проекция фильтрует, а не пересобирает определения.
    assert cat.formula_configs["score_2"] is cat.instrument_configs["score_2"]


def test_questionnaire_configs_keep_only_registry_codes():
    cat = CalcCatalog(_partition_catalog())
    # form_onco неактивен и до instrument_configs не доходит, form_common в QUESTIONNAIRE_CODES нет.
    assert set(cat.questionnaire_configs) == {"form_cvd"}


def test_config_projections_partition_instrument_configs():
    """Инструмент попадает ровно в одну проекцию, кроме form_common — тот не считается вовсе."""
    cat = CalcCatalog(_partition_catalog())
    assert not set(cat.formula_configs) & set(cat.questionnaire_configs)
    assert set(cat.formula_configs) | set(cat.questionnaire_configs) | {FORM_COMMON_INSTRUMENT_CODE} == set(
        cat.instrument_configs
    )


def test_system_codes_by_instrument():
    cat = CalcCatalog(_catalog())
    assert cat.system_codes_by_instrument["form_a"] == ("s1", "s2")


def test_bdi_score_map():
    cat = CalcCatalog(_catalog())
    # score = int(code[-2:]) - 1  → BDI1_02 -> 1, BDI1_04 -> 3
    assert cat.bdi_score_map == {"sad": 1, "very sad": 3}


def test_empty_bdi_score_map_fails_fast():
    # Partial seed: options/questions non-empty (table-level guard passes) but no BDI question,
    # so the score map ends up empty → must fail-fast at build, not silently at calc time.
    src = _catalog()
    tables = dict(src.tables)
    tables["questions"] = (question("Q_GEN", group_code=1, question_id=1),)
    tables["options"] = (option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen", value="yes", option_id=1),)
    with pytest.raises(CatalogLoadError, match="bdi_score_map empty"):
        CalcCatalog(Catalog(tables=MappingProxyType(tables)))


def test_instrument_codes_for_parameters_active_only():
    cat = CalcCatalog(_catalog())
    assert cat.instrument_codes_for_parameters({"p_gen"}) == {"form_a", "calc_b"}
    assert cat.instrument_codes_for_parameters({"p_x"}) == set()  # only on inactive old_c
    assert cat.instrument_codes_for_parameters(set()) == set()


def test_eligibility_views():
    cat = CalcCatalog(_catalog())
    # form_a has one required param (p_gen)
    assert cat.required_by_instrument == {"form_a": frozenset({"p_gen"})}
    # Questionnaires (type=form, active) → the pair universe uses ALL their params.
    assert cat.params_by_questionnaire == {
        "form_a": frozenset({"p_gen", "p_opt"}),
        "form_shared": frozenset({"p_opt"}),
    }


def test_question_views_for_the_gate():
    cat = CalcCatalog(_catalog())
    # Пул строится по СИСТЕМЕ инструмента: form_a входит в s1 и s2, поэтому в его пул попадают
    # Q_GEN (общий вопрос — отдельного исключения больше нет), Q_OPT и Q_CALC — вопрос параметра
    # соседнего по системе s1 инструмента calc_b. form_shared живёт в s3 в одиночку → только
    # Q_OPT; тот же вопрос считается и в form_a, независимо (ревью !156). calc_b не type=form —
    # своей записи не получает.
    assert cat.question_codes_by_instrument == {
        "form_a": frozenset({"Q_GEN", "Q_OPT", "Q_CALC"}),
        "form_shared": frozenset({"Q_OPT"}),
    }
    # ALL option-params of the question, not just the instrument's ones («отвечен» needs them all).
    assert cat.params_by_question["Q_OPT"] == frozenset({"p_opt", "p_extra"})
    assert cat.params_by_question["Q_GEN"] == frozenset({"p_gen"})
    # Опции шкалы BDI тоже пишут параметр (bdi1), так что вопрос в индексе есть. В пул опросника он
    # не попадает: bdi1 не входит ни в один instruments_parameters фикстуры — см. выше.
    assert cat.params_by_question["BDI1"] == frozenset({"bdi1"})
    # Условия сворачиваются сразу в `ConditionView` — модель, которую принимает classify_question:
    # перевод не зависит от пациента, а классификатор строится на каждого пациента пачки.
    assert cat.condition_views_by_question["Q_OPT"] == (
        ConditionView(
            type="except", parameter_code=PARAMETER_CODE_GENDER, value=GENDER_FEMALE, min_age=None, max_age=None
        ),
        ConditionView(type="age", parameter_code=PARAMETER_CODE_AGE, value=None, min_age=18, max_age=65),
    )
    assert "Q_GEN" not in cat.condition_views_by_question


def test_returned_maps_are_immutable():
    cat = CalcCatalog(_catalog())
    with pytest.raises(TypeError):
        cat.instrument_configs["x"] = None  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.formula_configs["x"] = None  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.questionnaire_configs["x"] = None  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.params_by_questionnaire["x"] = frozenset()  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.question_codes_by_instrument["x"] = frozenset()  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.params_by_question["x"] = frozenset()  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        cat.condition_views_by_question["x"] = ()  # ty: ignore[invalid-assignment]


def _clinrec_catalog(*, with_diseases: bool = True, with_scores: bool = True) -> Catalog:
    """Каталог с инструментом `biomarker_kr` и справочником клинических рекомендаций."""
    return make_catalog(
        instruments=[
            instrument("score_2", type="calc", instrument_id=1),
            instrument("calc_unknown", type="calc", instrument_id=2),
            instrument(BIOMARKER_CLINREC_INSTRUMENT_CODE, type=INSTRUMENT_TYPE_BIOMARKER_CLINREC, instrument_id=3),
            instrument("form_cvd", instrument_id=4),
            instrument("kr_off", type=INSTRUMENT_TYPE_BIOMARKER_CLINREC, status="inactive", instrument_id=5),
        ],
        instruments_parameters=[
            instrument_parameter("score_2", "p_calc", is_required=True),
            instrument_parameter("calc_unknown", "p_calc"),
            instrument_parameter(BIOMARKER_CLINREC_INSTRUMENT_CODE, "biomarker_ldl"),
            instrument_parameter("form_cvd", "p_cvd"),
        ],
        parameters=[
            parameter("biomarker_ldl"),
            parameter("biomarker_glucose"),
            parameter("biomarker_old", status="inactive"),
            parameter("smoking"),
        ],
        questions=[question("BDI1", question_id=6)],
        options=[
            option("BDI1_01", question_code="BDI1", parameter_code="bdi1", value="ok", option_id=1),
            option("BDI1_04", question_code="BDI1", parameter_code="bdi1", value="very sad", option_id=2),
        ],
        diseases=[disease("d_dm", "ENDO"), disease("d_cvd", "CVD"), disease("d_uro", "URO")] if with_diseases else [],
        risk_factor_systems=[risk_factor_system("rf_ldl", "CVD"), risk_factor_system("rf_ldl", "ENDO")],
        risk_factor_triggers=[
            risk_factor_trigger("rf_ldl", "CVD", "biomarker_ldl", operator="gt", value_num=Decimal("3"), trigger_id=1),
            risk_factor_trigger("rf_ldl", "ENDO", "biomarker_ldl", operator="gt", value_num=Decimal("5"), trigger_id=2),
            # Условие по НЕбиомаркерному параметру в клинрек-индекс не попадает.
            risk_factor_trigger("rf_smoke", "CVD", "smoking", trigger_id=3),
            # Неактивный параметр-биомаркер тоже отбрасывается.
            risk_factor_trigger("rf_old", "CVD", "biomarker_old", trigger_id=4),
            # Активный параметр с префиксом, но без связи с `biomarker_kr`, в расчёт не входит.
            risk_factor_trigger("rf_unlinked", "CVD", "biomarker_glucose", trigger_id=5),
        ],
        risk_factor_scores=(
            [
                risk_factor_score("rf_ldl", "d_cvd", score=3),
                risk_factor_score("rf_ldl", "d_dm", score=3),
                # Фактор не связан с URO через `risk_factor_systems`: эта группа не участвует.
                risk_factor_score("rf_ldl", "d_uro", score=3),
                # Балл, отличный от 3, фактор в клинрек-индекс не заводит.
                risk_factor_score("rf_smoke", "d_cvd", score=2),
                # Ссылка на неизвестную группу заболеваний: без строки `diseases` у результата
                # не было бы системы, поэтому связь отбрасывается.
                risk_factor_score("rf_ldl", "d_missing", score=3),
            ]
            if with_scores
            else []
        ),
    )


def test_routing_splits_instruments_by_explicit_type():
    cat = CalcCatalog(_clinrec_catalog())
    assert set(cat.formula_configs) == {"score_2"}
    assert set(cat.questionnaire_configs) == {"form_cvd"}
    assert set(cat.biomarker_clinrec_configs) == {BIOMARKER_CLINREC_INSTRUMENT_CODE}
    # Тип `calc` без формулы в реестре в формульный pipeline не попадает, но и не теряется.
    assert cat.unsupported_calc_codes == frozenset({"calc_unknown"})
    # Неактивный инструмент не маршрутизируется вообще.
    assert "kr_off" not in cat.biomarker_clinrec_configs


def test_biomarker_parameter_codes_are_active_linked_prefixed_parameters():
    cat = CalcCatalog(_clinrec_catalog())
    assert cat.biomarker_parameter_codes == frozenset({"biomarker_ldl"})


def test_biomarker_triggers_are_grouped_by_factor_ignoring_trigger_system():
    cat = CalcCatalog(_clinrec_catalog())
    # `rf_unlinked` отфильтрован по отсутствию связи параметра с инструментом.
    assert set(cat.biomarker_triggers_by_factor) == {"rf_ldl"}
    # Оба условия фактора остаются, включая условие чужой системы: система фактора определяется
    # не триггером, а связями заболевания и `risk_factor_systems`.
    assert [t.trigger_id for t in cat.biomarker_triggers_by_factor["rf_ldl"]] == [1, 2]


def test_clinrec_diseases_keep_only_exact_score_three():
    cat = CalcCatalog(_clinrec_catalog())
    assert cat.clinrec_diseases_by_factor == {"rf_ldl": ("d_cvd", "d_dm")}


def test_system_code_by_disease():
    cat = CalcCatalog(_clinrec_catalog())
    assert cat.system_code_by_disease == {"d_dm": "ENDO", "d_cvd": "CVD", "d_uro": "URO"}


def test_sparse_clinrec_catalog_builds_empty_indexes():
    """Справочник клинрек-расчёта заливается отдельно: до его заливки каталог обязан собираться."""
    cat = CalcCatalog(_clinrec_catalog(with_diseases=False, with_scores=False))
    assert cat.system_code_by_disease == {}
    assert cat.clinrec_diseases_by_factor == {}
    # Маршрутизация инструментов от наличия справочника не зависит.
    assert set(cat.biomarker_clinrec_configs) == {BIOMARKER_CLINREC_INSTRUMENT_CODE}
