from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from sqlalchemy.exc import IntegrityError, InterfaceError, OperationalError, SQLAlchemyError

from src.infra.db_retry import (
    DEFAULT_RETRIABLE,
    NonRetriableDbError,
    RetriableDbError,
    TransactionalRetryExecutor,
    tolerate_retriable_db_error,
)


def _fake_session() -> MagicMock:
    session = MagicMock()
    begin_ctx = AsyncMock()
    begin_ctx.__aenter__ = AsyncMock(return_value=None)
    begin_ctx.__aexit__ = AsyncMock(return_value=None)
    session.begin = MagicMock(return_value=begin_ctx)
    return session


def _operational_error() -> OperationalError:
    return OperationalError("stmt", {}, Exception("boom"))


def _interface_error() -> InterfaceError:
    return InterfaceError("stmt", {}, Exception("iface"))


def _integrity_error() -> IntegrityError:
    return IntegrityError("stmt", {}, Exception("constraint"))


class TestExecutorSuccess:
    async def test_returns_op_value_on_first_attempt(self) -> None:
        session = _fake_session()
        op = AsyncMock(return_value="ok")
        executor = TransactionalRetryExecutor(session)

        result = await executor.run(op, 1, key=2)

        assert result == "ok"
        op.assert_awaited_once_with(1, key=2)
        assert session.begin.call_count == 1

    async def test_default_retriable_includes_operational_and_interface(self) -> None:
        assert OperationalError in DEFAULT_RETRIABLE
        assert InterfaceError in DEFAULT_RETRIABLE


class TestExecutorRetry:
    async def test_retries_then_succeeds(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=[_operational_error(), "ok"])
        executor = TransactionalRetryExecutor(session, backoff_base_s=0.0)

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()) as sleep:
            result = await executor.run(op)

        assert result == "ok"
        assert op.await_count == 2
        sleep.assert_awaited_once()

    async def test_retries_exhausted_raises_retriable(self) -> None:
        session = _fake_session()
        original = _operational_error()
        op = AsyncMock(side_effect=[original, _operational_error(), _operational_error()])
        executor = TransactionalRetryExecutor(session, max_attempts=3, backoff_base_s=0.0)

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()):
            with pytest.raises(RetriableDbError) as exc_info:
                await executor.run(op)

        assert exc_info.value.attempts == 3
        assert isinstance(exc_info.value.cause, OperationalError)
        assert op.await_count == 3

    async def test_interface_error_is_retriable(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=[_interface_error(), "ok"])
        executor = TransactionalRetryExecutor(session, backoff_base_s=0.0)

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()):
            result = await executor.run(op)

        assert result == "ok"

    async def test_exponential_backoff_delays(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=[_operational_error(), _operational_error(), "ok"])
        executor = TransactionalRetryExecutor(session, max_attempts=3, backoff_base_s=0.5)

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()) as sleep:
            await executor.run(op)

        delays = [call.args[0] for call in sleep.await_args_list]
        assert delays == [0.5, 1.0]


class TestExecutorNonRetriable:
    async def test_integrity_error_is_non_retriable(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=_integrity_error())
        executor = TransactionalRetryExecutor(session)

        with pytest.raises(NonRetriableDbError) as exc_info:
            await executor.run(op)

        assert exc_info.value.attempts == 1
        assert isinstance(exc_info.value.cause, IntegrityError)
        assert op.await_count == 1

    async def test_sqlalchemy_error_without_dbapi_is_non_retriable(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=SQLAlchemyError("mapper misconfigured"))
        executor = TransactionalRetryExecutor(session)

        with pytest.raises(NonRetriableDbError) as exc_info:
            await executor.run(op)

        assert isinstance(exc_info.value.cause, SQLAlchemyError)
        assert op.await_count == 1

    async def test_non_database_error_propagates_unchanged(self) -> None:
        """Ошибка не от базы выходит как есть: обёртка назвала бы дефект домена сбоем базы.

        Под именем NonRetriableDbError её видит и лог («database error is permanent»), и тот,
        кто разбирает инцидент, — а чинить нужно вызванный внутри транзакции код.
        """
        session = _fake_session()
        op = AsyncMock(side_effect=OverflowError("date value out of range"))
        executor = TransactionalRetryExecutor(session)

        with pytest.raises(OverflowError):
            await executor.run(op)

        assert op.await_count == 1


class TestExecutorConfig:
    async def test_max_attempts_one_no_retry(self) -> None:
        session = _fake_session()
        op = AsyncMock(side_effect=_operational_error())
        executor = TransactionalRetryExecutor(session, max_attempts=1, backoff_base_s=0.0)

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()) as sleep:
            with pytest.raises(RetriableDbError) as exc_info:
                await executor.run(op)

        assert exc_info.value.attempts == 1
        assert op.await_count == 1
        sleep.assert_not_awaited()

    async def test_custom_retriable_tuple(self) -> None:
        session = _fake_session()

        class CustomError(Exception):
            pass

        op = AsyncMock(side_effect=[CustomError(), "ok"])
        executor = TransactionalRetryExecutor(
            session,
            retriable=(CustomError,),
            backoff_base_s=0.0,
        )

        with patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()):
            result = await executor.run(op)

        assert result == "ok"

    async def test_custom_retriable_does_not_retry_default(self) -> None:
        session = _fake_session()

        class CustomError(Exception):
            pass

        op = AsyncMock(side_effect=_operational_error())
        executor = TransactionalRetryExecutor(session, retriable=(CustomError,))

        with pytest.raises(NonRetriableDbError):
            await executor.run(op)

        assert op.await_count == 1

    def test_max_attempts_zero_rejected(self) -> None:
        session = _fake_session()
        with pytest.raises(ValueError):
            TransactionalRetryExecutor(session, max_attempts=0)


class TestTolerateRetriableDbError:
    """Граница «транзиентный гасим — перманентный пропускаем» у общего контекст-менеджера."""

    def test_retriable_is_swallowed_and_marks_the_attempt_failed(self) -> None:
        with patch("src.infra.db_retry.logger") as mock_logger:
            with tolerate_retriable_db_error("db.step: failed", patient_id="p1") as attempt:
                raise RetriableDbError("exhausted", cause=Exception("deadlock"), attempts=3)

        assert attempt.failed is True
        mock_logger.error.assert_called_once()
        assert mock_logger.error.call_args.args[0] == "db.step: failed"
        log_context = mock_logger.error.call_args.kwargs["extra"]["log_context"]
        # Поля вызывающего и поля исключения лежат в одном контексте под одними именами
        # у всех write-шагов — иначе по ним нельзя было бы искать в Kibana одним запросом.
        assert log_context == {"patient_id": "p1", "attempts": 3, "error": "deadlock"}
        assert mock_logger.error.call_args.kwargs["exc_info"].attempts == 3

    def test_non_retriable_propagates(self) -> None:
        with pytest.raises(NonRetriableDbError), tolerate_retriable_db_error("db.step: failed") as attempt:
            raise NonRetriableDbError("schema mismatch", cause=Exception("permanent"), attempts=1)

        assert attempt.failed is False

    def test_unrelated_exception_propagates(self) -> None:
        with pytest.raises(ValueError), tolerate_retriable_db_error("db.step: failed"):
            raise ValueError("not a db error")

    def test_success_leaves_the_attempt_clean_and_logs_nothing(self) -> None:
        with patch("src.infra.db_retry.logger") as mock_logger:
            with tolerate_retriable_db_error("db.step: failed") as attempt:
                pass

        assert attempt.failed is False
        mock_logger.error.assert_not_called()
