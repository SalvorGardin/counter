"""Фильтры по списку значений компилируются в один текст запроса на любую длину списка.

Это и есть инвариант, ради которого фильтры переведены с `IN` на `= ANY(:values)`: пока текст не
зависит от длины, `pg_stat_statements` держит один логический запрос одной записью.
"""

from sqlalchemy import Integer, String, select
from sqlalchemy.dialects import postgresql

from src.infra.sql import any_of, any_of_param, none_of
from src.models.doctor import Doctor
from src.models.result import Result


def _compiled(stmt) -> str:
    return str(stmt.compile(dialect=postgresql.dialect()))


def test_any_of_text_does_not_depend_on_list_length() -> None:
    texts = {
        _compiled(select(Result.patient_id).where(any_of(Result.instrument_code, [f"i{n}" for n in range(size)])))
        for size in (0, 1, 10, 50)
    }
    assert len(texts) == 1


def test_any_of_renders_any_over_single_array_parameter() -> None:
    stmt = select(Result.patient_id).where(any_of(Result.instrument_code, ["a", "b", "c"]))
    compiled = stmt.compile(dialect=postgresql.dialect())
    assert "= ANY (" in str(compiled)
    assert len(compiled.params) == 1
    assert next(iter(compiled.params.values())) == ["a", "b", "c"]


def test_empty_sequence_keeps_the_single_array_parameter() -> None:
    """Пустая последовательность не уходит в особый путь: тот же текст, тот же один параметр."""
    compiled = select(Result.patient_id).where(any_of(Result.instrument_code, [])).compile(dialect=postgresql.dialect())
    assert "= ANY (" in str(compiled)
    assert len(compiled.params) == 1
    assert next(iter(compiled.params.values())) == []


def test_any_of_derives_element_type_from_column() -> None:
    assert isinstance(Result.instrument_code.type, String)
    assert isinstance(Doctor.code.type, Integer)
    assert "VARCHAR[]" in _compiled(select(Result.patient_id).where(any_of(Result.instrument_code, ["a"])))
    assert "INTEGER[]" in _compiled(select(Doctor.code).where(any_of(Doctor.code, [1])))


def test_any_of_accepts_a_set() -> None:
    stmt = select(Result.patient_id).where(any_of(Result.instrument_code, {"a"}))
    assert next(iter(stmt.compile(dialect=postgresql.dialect()).params.values())) == ["a"]


def test_none_of_renders_all() -> None:
    compiled = _compiled(select(Result.patient_id).where(none_of(Result.instrument_code, ["a", "b"])))
    assert "!= ALL (" in compiled


def test_any_of_param_binds_by_name_and_is_length_independent() -> None:
    stmt = select(Result.patient_id).where(any_of_param(Result.patient_id, "patient_ids"))
    compiled = stmt.compile(dialect=postgresql.dialect())
    assert "= ANY (" in str(compiled)
    assert "patient_ids" in compiled.params
    # Тот же стейтмент, исполненный с разными списками, — один и тот же текст: он скомпилирован
    # до подстановки значений, длина списка на компиляцию не влияет вовсе.
    assert str(compiled) == _compiled(stmt)
