from datetime import UTC, datetime
from decimal import Decimal
from types import MappingProxyType

import pytest

from src.infra.catalog.base import Catalog, CatalogLoadError
from src.infra.catalog.dtos import (
    DoctorDTO,
    RecommendationDTO,
    RecommendedDoctorDTO,
    RiskFactorDTO,
    RiskFactorSystemDTO,
)
from src.infra.catalog.http import HttpCatalog
from tests.catalog_builder import (
    condition,
    disease_examination,
    examination,
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    parameter,
    question,
    score,
    system_checkup_examination,
    system_instrument,
)
from tests.catalog_builder import system as system_
from tests.consts import GENDER_FEMALE


def _base() -> Catalog:
    return make_catalog(
        systems=(
            system_("SYS", system_id=2, description="System", rang=2),
            system_("COMMON", system_id=1, description="Common", rang=1),
        ),
        parameters=(
            parameter("p1", parameter_id=1, description="P1", validity_period=datetime(2030, 1, 1, tzinfo=UTC)),
        ),
        doctors=(DoctorDTO(2, 35, "Second"), DoctorDTO(1, 19, "Doctor")),
        recommendations=(
            RecommendationDTO(2, None, "SYS", "Common", None, "common"),
            RecommendationDTO(1, "rf", "SYS", "Name", "Text", None),
        ),
        conditions=(condition("q1", "p1", value="no"),),
        instruments=(instrument("form", instrument_id=1, description="Form"),),
        instruments_parameters=(instrument_parameter("form", "p1", is_required=True),),
        options=(
            option("o2", question_code="q1", parameter_code="p1", value=None, option_id=2),
            option("o1", question_code="q1", parameter_code="p1", value="yes", option_id=1),
        ),
        questions=(
            question("q2", group_code=2, question_id=2, question="Later", type="numeric", is_skippable=True),
            question("q1", group_code=1, question_id=1, question="Question"),
        ),
        systems_instruments=(system_instrument("SYS", "form"),),
        recommended_doctors=(
            RecommendedDoctorDTO("SYS", "high", 35, 2),
            RecommendedDoctorDTO("SYS", "high", 19, 1),
        ),
        risk_factors=(RiskFactorDTO(1, "rf", "Risk", "mod"),),
        risk_factor_systems=(RiskFactorSystemDTO(1, "rf", "SYS", None),),
        parameter_scores=(score("p1", "SYS", min_value=Decimal("1"), score=Decimal("2")),),
    )


def test_http_catalog_builds_ordered_immutable_relationships() -> None:
    catalog = HttpCatalog(_base())

    assert [system.code for system in catalog.ordered_systems] == ["COMMON", "SYS"]
    question = catalog.question_view("q1")
    assert question is not None
    assert question.text == "Question"
    assert catalog.option_views_for_question("q1")[0].code == "o1"
    nullable_option = catalog.option_view("o2")
    assert nullable_option is not None
    assert nullable_option.text == ""
    assert catalog.option_view("missing") is None
    assert catalog.question_view("missing") is None
    assert catalog.system_view("missing") is None
    assert catalog.parameter_codes_by_system["SYS"] == frozenset({"p1"})
    assert catalog.parameter_codes_by_instrument["form"] == frozenset({"p1"})
    assert catalog.parameter_codes_by_question["q1"] == frozenset({"p1"})
    assert catalog.questions_by_parameter["p1"] == frozenset({"q1"})
    assert catalog.instruments_by_system["SYS"][0].code == "form"
    assert catalog.conditions_by_question["q1"][0].value == "no"
    condition = catalog.condition_views_by_question(["q1"])["q1"][0]
    assert condition.parameter_code == "p1"
    assert catalog.condition_views_by_question(["q1"])["q1"][0] is condition
    assert catalog.risk_factors_by_system["SYS"][0].reasoning is None
    assert [row.recommendation_id for row in catalog.recommendations_by_system["SYS"]] == [1, 2]
    parameter_question = catalog.question_views_for_params({"p1"})[0]
    assert parameter_question.code == "q1"
    assert catalog.question_views_for_params({"p1"})[0] is parameter_question
    assert catalog.question_view("q1") is parameter_question
    assert [row.code for row in catalog.ordered_questions] == ["q1", "q2"]
    assert [row.recommendation_id for row in catalog.ordered_recommendations] == [1, 2]
    with pytest.raises(TypeError):
        catalog.systems["NEW"] = object()  # ty: ignore[invalid-assignment]
    with pytest.raises(TypeError):
        catalog.parameter_codes_by_system["SYS"] = frozenset()  # ty: ignore[invalid-assignment]


def test_systems_instruments_pointing_at_a_missing_row_fails_with_context() -> None:
    """Дыра в связке защищена FK, но если она есть — падать надо с указанием строки.

    Каталог собирается в lifespan, так что ошибка сборки уносит под целиком; голый KeyError оставил
    бы в логе только имя ключа без таблицы.
    """
    tables = dict(_base().tables)
    tables["systems_instruments"] = (system_instrument("SYS", "gone"),)

    with pytest.raises(CatalogLoadError, match="instrument_code=gone"):
        HttpCatalog(Catalog(MappingProxyType(tables)))


def test_inactive_examinations_are_absent_from_examination_indexes() -> None:
    """Неактивное исследование в подборе не участвует — его связи в снимок не попадают."""
    active = examination()
    inactive = examination(examination_type="instrumental", status="inactive")
    tables = dict(_base().tables)
    tables["examinations"] = (active, inactive)
    tables["disease_examinations"] = (
        disease_examination("d1", active.code),
        disease_examination("d1", inactive.code, category=None),
    )
    tables["system_checkup_examinations"] = (
        system_checkup_examination("SYS", active.code, gender=GENDER_FEMALE),
        system_checkup_examination("SYS", inactive.code),
    )
    catalog = HttpCatalog(Catalog(MappingProxyType(tables)))

    disease_links = catalog.disease_examinations_by_disease["d1"]
    checkup_links = catalog.checkup_examinations_by_system["SYS"]

    assert [link.examination.code for link in disease_links] == [active.code]
    assert disease_links[0].category == "basic"
    assert [link.examination.code for link in checkup_links] == [active.code]
    assert checkup_links[0].gender == GENDER_FEMALE


def test_examination_links_are_ordered_by_row_id() -> None:
    """SELECT'ы каталога идут без ORDER BY, поэтому порядок связей задают их идентификаторы."""
    first = examination()
    second = examination()
    tables = dict(_base().tables)
    tables["examinations"] = (first, second)
    tables["disease_examinations"] = (
        disease_examination("d1", second.code, disease_examination_id=2),
        disease_examination("d1", first.code, disease_examination_id=1),
    )
    tables["system_checkup_examinations"] = (
        system_checkup_examination("SYS", second.code, system_checkup_examination_id=2),
        system_checkup_examination("SYS", first.code, system_checkup_examination_id=1),
    )
    catalog = HttpCatalog(Catalog(MappingProxyType(tables)))

    disease_codes = [link.examination.code for link in catalog.disease_examinations_by_disease["d1"]]
    checkup_codes = [link.examination.code for link in catalog.checkup_examinations_by_system["SYS"]]

    assert disease_codes == [first.code, second.code]
    assert checkup_codes == [first.code, second.code]


def test_examination_indexes_tolerate_empty_catalog() -> None:
    catalog = HttpCatalog(_base())

    assert catalog.disease_examinations_by_disease == {}
    assert catalog.checkup_examinations_by_system == {}


def test_views_carry_gendered_forms_next_to_neutral_text() -> None:
    catalog = HttpCatalog(
        make_catalog(
            options=(
                option(
                    "o1",
                    question_code="q1",
                    parameter_code="p1",
                    value="Я расстроен(а)",
                    value_male="Я расстроен",
                    value_female="Я расстроена",
                ),
                option("o2", question_code="q1", parameter_code="p1", value="Я плачу"),
            ),
            questions=(
                question("q1", question="Я спокоен(на).", question_male="Я спокоен.", question_female="Я спокойна."),
            ),
        )
    )

    question_view = catalog.question_view("q1")
    assert question_view is not None
    assert (question_view.text, question_view.text_male, question_view.text_female) == (
        "Я спокоен(на).",
        "Я спокоен.",
        "Я спокойна.",
    )
    gendered, neutral = catalog.option_views_for_question("q1")
    # value — ключ хранения ответа — остаётся нейтральным, родовые формы идут отдельно.
    assert (gendered.value, gendered.text, gendered.text_male, gendered.text_female) == (
        "Я расстроен(а)",
        "Я расстроен(а)",
        "Я расстроен",
        "Я расстроена",
    )
    assert (neutral.text_male, neutral.text_female) == (None, None)
    assert catalog.option_view("o1") == gendered
