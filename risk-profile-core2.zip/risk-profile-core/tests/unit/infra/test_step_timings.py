"""Механика `TimingSink`: каскад флага, накопление шагов, вложенность и no-op при выключенном сборе."""

from dataclasses import dataclass, field

import pytest

from src.infra.step_timings import _NOOP_STEP, TimingSink, resolve_sink


@dataclass
class _Inner(TimingSink):
    read_ms: float = 0.0


@dataclass
class _Outer(TimingSink):
    total_ms: float = 0.0
    outer_ms: float = 0.0
    inner_step_ms: float = 0.0
    inner: _Inner = field(default_factory=_Inner)


def test_step_accumulates_across_calls() -> None:
    t = _Outer()
    with t.step("total"):
        pass
    first = t.total_ms
    with t.step("total"):
        pass

    assert first > 0.0
    assert t.total_ms > first


def test_nested_step_is_subtracted_from_parent() -> None:
    t = _Outer()
    with t.step("outer"):
        with t.step("inner_step"):
            _busy()
        _busy()

    assert t.inner_step_ms > 0.0
    # Родитель показывает только своё время: вложенный шаг из него вычтен, а не удвоен.
    assert t.outer_ms > 0.0


def test_nested_sink_step_is_not_subtracted_from_parent() -> None:
    # Шаги разных sink'ов независимы: под-разбивка `inner` из `outer_ms` не вычитается.
    t = _Outer()
    with t.step("outer"):
        with t.inner.step("read"):
            _busy()

    assert t.inner.read_ms > 0.0
    assert t.outer_ms >= t.inner.read_ms


def test_step_measures_even_when_body_raises() -> None:
    t = _Outer()
    with pytest.raises(RuntimeError), t.step("total"):
        raise RuntimeError("boom")

    assert t.total_ms > 0.0


def test_disabled_sink_returns_shared_noop_and_writes_nothing() -> None:
    t = _Outer()
    t.enable(False)

    step = t.step("total")
    assert step is _NOOP_STEP
    with step:
        pass
    with t.inner.step("read"):
        pass

    assert t.total_ms == 0.0
    assert t.inner.read_ms == 0.0


def test_enable_cascades_into_nested_sinks() -> None:
    t = _Outer()
    t.enable(False)
    assert not t.enabled
    assert not t.inner.enabled

    t.enable(True)
    assert t.enabled
    assert t.inner.enabled


def test_unknown_step_name_fails_immediately() -> None:
    t = _Outer()
    with pytest.raises(AttributeError):
        t.step("nope")


def test_resolve_sink_falls_back_to_disabled() -> None:
    passed = _Outer()
    disabled = _Outer()
    disabled.enable(False)

    assert resolve_sink(passed, disabled) is passed
    assert resolve_sink(None, disabled) is disabled


def _busy() -> None:
    """Немного работы, чтобы `perf_counter` дал ненулевую разницу на любой платформе."""
    total = 0
    for i in range(10_000):
        total += i
