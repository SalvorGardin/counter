"""Пины конфигурации пула соединений.

Форма пула определяет, сколько транзакций сервис отдаёт в БД помимо полезных. Ключевой пин —
отсутствие pre-ping: в диалекте asyncpg проба реализована как явная транзакция, которая всегда
завершается ROLLBACK (`_async_ping` в sqlalchemy/dialects/postgresql/asyncpg.py), поэтому каждый
чекаут соединения регистрировался в pg_stat_database.xact_rollback — по откату на запрос, включая
успешные записи. Тот же отказ (соединение прибито во время простоя) закрывается пересозданием
по возрасту, которое не стоит ни round-trip'а, ни транзакции.
"""

import pytest

from src.config import settings
from src.infra.database import _pool_recycle_seconds, get_primary_runtime


def test_pool_does_not_pre_ping() -> None:
    assert get_primary_runtime().engine.pool._pre_ping is False


def test_pool_recycles_by_age() -> None:
    assert settings.db_pool_recycle_seconds > 0
    assert get_primary_runtime().engine.pool._recycle == settings.db_pool_recycle_seconds


@pytest.mark.parametrize(("configured", "expected"), [(300, 300), (1, 1), (0, -1)])
def test_recycle_setting_maps_to_sqlalchemy_encoding(configured: int, expected: int) -> None:
    """0 в настройках означает «не пересоздавать по возрасту»; SQLAlchemy кодирует это как -1."""
    assert _pool_recycle_seconds(configured) == expected
