"""Тесты клиента Docker Engine API (src/infra/docker/engine.py).

Демон не поднимаем: транспорт подменяется `httpx2.MockTransport`. Проверяется ровно формат
протокола — label-фильтр, параметры `all` и `t`, разбор `Names`, оборачивание отказов.
"""

from typing import Any

import httpx2
import pytest

from src.infra.docker import Container, DockerEngineClient, DockerEngineError

_PROJECT = "risk-profile-core"


def _client(handler: Any) -> DockerEngineClient:
    http = httpx2.AsyncClient(transport=httpx2.MockTransport(handler), base_url="http://docker")
    return DockerEngineClient(http)


async def test_list_filters_by_compose_labels() -> None:
    """Контейнеры ищутся по label-фильтру проекта и сервиса: по именам нельзя — реплик N штук."""
    seen: dict[str, Any] = {}

    def handler(request: httpx2.Request) -> httpx2.Response:
        seen["path"] = request.url.path
        seen["filters"] = request.url.params["filters"]
        return httpx2.Response(200, json=[])

    await _client(handler).list_service_containers(_PROJECT, "consumer", include_stopped=True)

    assert seen["path"] == "/containers/json"
    assert f'"com.docker.compose.project={_PROJECT}"' in seen["filters"]
    assert '"com.docker.compose.service=consumer"' in seen["filters"]


@pytest.mark.parametrize(("include_stopped", "expected"), [(True, "true"), (False, "false")])
async def test_include_stopped_maps_to_all_param(include_stopped: bool, expected: str) -> None:
    """`all` у Engine API: без него демон перечисляет только запущенные контейнеры."""
    seen: dict[str, Any] = {}

    def handler(request: httpx2.Request) -> httpx2.Response:
        seen["all"] = request.url.params["all"]
        return httpx2.Response(200, json=[])

    await _client(handler).list_service_containers(_PROJECT, "app", include_stopped=include_stopped)

    assert seen["all"] == expected


async def test_container_name_loses_leading_slash_and_daemon_order_is_kept() -> None:
    """`Names` приходит с ведущим слешем. Порядок клиент не меняет — это решение вызывающего."""

    def handler(_: httpx2.Request) -> httpx2.Response:
        return httpx2.Response(200, json=[{"Id": "id-b", "Names": ["/b"]}, {"Id": "id-a", "Names": ["/a"]}])

    containers = await _client(handler).list_service_containers(_PROJECT, "consumer", include_stopped=True)

    assert containers == [Container(id="id-b", name="b"), Container(id="id-a", name="a")]


async def test_unexpected_payload_becomes_engine_error() -> None:
    """Смена формата ответа демона — это ошибка клиента, а не KeyError посреди перезапуска."""

    def handler(_: httpx2.Request) -> httpx2.Response:
        return httpx2.Response(200, json=[{"Id": "id-a"}])

    with pytest.raises(DockerEngineError):
        await _client(handler).list_service_containers(_PROJECT, "consumer", include_stopped=True)


async def test_list_failure_becomes_engine_error() -> None:
    """Отказ демона на перечислении оборачивается в DockerEngineError с именем сервиса."""

    def handler(_: httpx2.Request) -> httpx2.Response:
        return httpx2.Response(500, json={"message": "boom"})

    with pytest.raises(DockerEngineError, match="consumer"):
        await _client(handler).list_service_containers(_PROJECT, "consumer", include_stopped=True)


async def test_restart_sends_stop_timeout() -> None:
    """`t` — бюджет graceful stop. Без него демон возьмёт свои 10 с и прибьёт дренаж SIGKILL."""
    seen: dict[str, Any] = {}

    def handler(request: httpx2.Request) -> httpx2.Response:
        seen["path"] = request.url.path
        seen["t"] = request.url.params["t"]
        return httpx2.Response(204)

    await _client(handler).restart(Container(id="id-a", name="a"), stop_timeout_s=60)

    assert seen["path"] == "/containers/id-a/restart"
    assert seen["t"] == "60"


async def test_restart_failure_names_the_container() -> None:
    """Отказ на конкретном контейнере несёт его имя: по отчёту видно, какая реплика встала."""

    def handler(_: httpx2.Request) -> httpx2.Response:
        return httpx2.Response(409, json={"message": "container is marked for removal"})

    with pytest.raises(DockerEngineError) as exc_info:
        await _client(handler).restart(Container(id="id-a", name="a"), stop_timeout_s=60)

    assert exc_info.value.container == "a"
    assert "409" in str(exc_info.value)
