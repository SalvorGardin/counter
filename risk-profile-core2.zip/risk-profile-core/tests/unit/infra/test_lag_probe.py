"""Unit-тесты RecalcLagProbe: подсчёт лага, отрицательный кэш, single-flight, выдача коллектора.

aiokafka-клиенты мокаются (по образцу test_kafka_admin/test_kafka_consumer) — брокер не поднимаем.
Моки внедряются через cast: поля `_consumer`/`_admin` типизированы конкретными клиентами, а мок —
`Mock`; возвращаем сам мок отдельно, чтобы мутации/ассерты шли по нему (ty видит `Mock`, не жалуется).
"""

import asyncio
from typing import cast
from unittest.mock import AsyncMock, Mock, patch

import pytest
from aiokafka import AIOKafkaConsumer, TopicPartition
from aiokafka.admin import AIOKafkaAdminClient
from aiokafka.structs import OffsetAndMetadata

from src.config import KafkaSettings
from src.infra.kafka.lag_probe import RecalcLagProbe
from tests.conftest import LogSink

_TOPIC = "risk-profile.recalc-commands"


def _settings() -> KafkaSettings:
    return KafkaSettings(enabled=True, bootstrap_servers="localhost:9092", security_protocol="PLAINTEXT")


def _probe_with_mocks(
    *,
    partitions: set[int],
    end_offsets: dict[TopicPartition, int],
    committed: dict[TopicPartition, OffsetAndMetadata],
) -> tuple[RecalcLagProbe, Mock, Mock]:
    """Проба с внедрёнными моками consumer/admin — минуя start() (без реального брокера).

    Возвращает (probe, consumer_mock, admin_mock): мутации и ассерты делаем по мокам, а не по
    `probe._consumer` (тот типизирован `AIOKafkaConsumer | None`).
    """
    probe = RecalcLagProbe(_settings())
    consumer = Mock()
    consumer.partitions_for_topic = Mock(return_value=partitions)  # sync в aiokafka
    consumer.end_offsets = AsyncMock(return_value=end_offsets)
    consumer.topics = AsyncMock(return_value={_TOPIC})
    admin = Mock()
    admin.list_consumer_group_offsets = AsyncMock(return_value=committed)
    probe._consumer = cast(AIOKafkaConsumer, consumer)
    probe._admin = cast(AIOKafkaAdminClient, admin)
    return probe, consumer, admin


def _lag_samples(probe: RecalcLagProbe) -> dict[str, float]:
    """{partition: lag} из семплов коллектора."""
    out: dict[str, float] = {}
    for family in probe.collect():
        if family.name == "risk_profile_core_recalc_queue_lag":
            for sample in family.samples:
                out[sample.labels["partition"]] = sample.value
    return out


def _lag_ok(probe: RecalcLagProbe) -> float:
    for family in probe.collect():
        if family.name == "risk_profile_core_recalc_queue_lag_ok":
            return family.samples[0].value
    raise AssertionError("lag_ok family missing")


async def test_happy_path_lag_is_end_minus_committed() -> None:
    tp = TopicPartition(_TOPIC, 0)
    probe, _consumer, _admin = _probe_with_mocks(
        partitions={0},
        end_offsets={tp: 110},
        committed={tp: OffsetAndMetadata(100, "")},
    )
    await probe.refresh()
    assert _lag_ok(probe) == 1.0
    assert _lag_samples(probe) == {"0": 10.0}


async def test_group_without_commit_treats_lag_as_full_end() -> None:
    """Нет коммита группы по партиции (committed отсутствует / offset −1) → lag = end."""
    tp0, tp1 = TopicPartition(_TOPIC, 0), TopicPartition(_TOPIC, 1)
    probe, _consumer, _admin = _probe_with_mocks(
        partitions={0, 1},
        end_offsets={tp0: 50, tp1: 70},
        committed={tp1: OffsetAndMetadata(-1, "")},  # tp0 отсутствует вовсе, tp1 — offset −1
    )
    await probe.refresh()
    assert _lag_ok(probe) == 1.0
    assert _lag_samples(probe) == {"0": 50.0, "1": 70.0}


async def test_poll_error_sets_lag_ok_zero_and_no_rows() -> None:
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, _admin = _probe_with_mocks(partitions={0}, end_offsets={tp: 110}, committed={})
    consumer.end_offsets = AsyncMock(side_effect=RuntimeError("broker down"))
    await probe.refresh()
    assert _lag_ok(probe) == 0.0
    assert _lag_samples(probe) == {}  # рядов лага нет


async def test_negative_result_is_cached_second_refresh_does_not_poll() -> None:
    """Отрицательный результат кэшируется: при лежащем брокере второй скрейп не платит таймаут."""
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, _admin = _probe_with_mocks(partitions={0}, end_offsets={tp: 110}, committed={})
    consumer.end_offsets = AsyncMock(side_effect=RuntimeError("broker down"))
    await probe.refresh()
    await probe.refresh()
    assert consumer.end_offsets.await_count == 1


async def test_cache_second_refresh_within_ttl_does_not_repoll() -> None:
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, admin = _probe_with_mocks(
        partitions={0}, end_offsets={tp: 110}, committed={tp: OffsetAndMetadata(100, "")}
    )
    await probe.refresh()
    await probe.refresh()
    # Два refresh подряд (в пределах TTL) → один поход в Kafka.
    assert consumer.end_offsets.await_count == 1
    assert admin.list_consumer_group_offsets.await_count == 1


async def test_snapshot_replaced_wholesale_drops_vanished_partitions() -> None:
    """Снимок заменяется целиком: партиция, пропавшая из второго опроса, не залипает в выдаче."""
    tp0, tp1 = TopicPartition(_TOPIC, 0), TopicPartition(_TOPIC, 1)
    probe, consumer, _admin = _probe_with_mocks(
        partitions={0, 1},
        end_offsets={tp0: 10, tp1: 20},
        committed={},
    )
    await probe.refresh()
    assert set(_lag_samples(probe)) == {"0", "1"}

    # Второй опрос видит только партицию 0 — сбрасываем кэш и меняем моки.
    probe._last_poll_at = None
    consumer.partitions_for_topic = Mock(return_value={0})
    consumer.end_offsets = AsyncMock(return_value={tp0: 15})
    await probe.refresh()
    assert set(_lag_samples(probe)) == {"0"}


async def test_lag_ok_zero_before_any_poll() -> None:
    """Свежая проба (коллектор зарегистрирован, но опроса ещё не было) → lag_ok=0, рядов лага нет.
    Это и есть видимый сигнал «данных о лаге пока нет», ради которого коллектор регистрируется до
    старта клиентов (см. _init_lag_probe)."""
    probe = RecalcLagProbe(_settings())
    assert _lag_ok(probe) == 0.0
    assert _lag_samples(probe) == {}


async def test_start_cleans_up_consumer_if_admin_start_fails() -> None:
    """Частичный старт (consumer поднялся, admin упал) не должен течь: consumer.stop() вызывается,
    start() пробрасывает ошибку."""
    consumer = Mock()
    consumer.start = AsyncMock()
    consumer.stop = AsyncMock()
    admin = Mock()
    admin.start = AsyncMock(side_effect=RuntimeError("no offsets ACL"))
    admin.close = AsyncMock()
    probe = RecalcLagProbe(_settings())
    with (
        patch("src.infra.kafka.lag_probe.AIOKafkaConsumer", return_value=consumer),
        patch("src.infra.kafka.lag_probe.AIOKafkaAdminClient", return_value=admin),
    ):
        try:
            await probe.start()
            raise AssertionError("start() должен был проброситься")
        except RuntimeError:
            pass
    consumer.stop.assert_awaited_once()  # поднятый consumer прибран
    assert probe._consumer is None and probe._admin is None  # поля не выставлены — stop() позже no-op


async def test_single_flight_concurrent_refresh_polls_once() -> None:
    """Два одновременных refresh() → один опрос Kafka: второй ждёт лок и выходит по свежему кэшу."""
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, _admin = _probe_with_mocks(partitions={0}, end_offsets={tp: 10}, committed={})
    gate = asyncio.Event()
    calls = 0

    async def slow_end_offsets(_partitions: list[TopicPartition]) -> dict[TopicPartition, int]:
        nonlocal calls
        calls += 1
        await gate.wait()  # держим первый опрос «в полёте», пока второй refresh не встанет на лок
        return {tp: 10}

    consumer.end_offsets = slow_end_offsets
    first = asyncio.create_task(probe.refresh())
    await asyncio.sleep(0)  # даём first захватить лок и войти в _poll
    second = asyncio.create_task(probe.refresh())
    await asyncio.sleep(0)  # second встаёт в очередь на лок
    gate.set()
    await asyncio.gather(first, second)
    assert calls == 1


async def test_cancellation_during_poll_does_not_mark_cache_fresh() -> None:
    """CancelledError во время _poll() (скрейп-клиент отвалился) НЕ должен пометить кэш свежим:
    иначе следующие 10 с отдавали бы устаревший снимок вместо повторного опроса. Инвариант
    lag_probe.py — метка ставится в теле try/except, а не в finally."""
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, _admin = _probe_with_mocks(partitions={0}, end_offsets={tp: 10}, committed={})
    entered = asyncio.Event()

    async def hang(_partitions: list[TopicPartition]) -> dict[TopicPartition, int]:
        entered.set()
        await asyncio.Event().wait()  # виснем до отмены задачи
        return {tp: 10}

    consumer.end_offsets = hang
    task = asyncio.create_task(probe.refresh())
    await entered.wait()  # ждём входа в _poll
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert probe._last_poll_at is None  # метка не обновлена → следующий скрейп повторит опрос
    assert probe._ok is False


async def test_fetches_metadata_when_partitions_not_cached() -> None:
    """Пустой partitions_for_topic на свежем клиенте → форсируем topics() и повторяем."""
    tp = TopicPartition(_TOPIC, 0)
    probe, consumer, _admin = _probe_with_mocks(partitions=set(), end_offsets={tp: 5}, committed={})
    # первый вызов — пусто, после topics() — {0}
    consumer.partitions_for_topic = Mock(side_effect=[set(), {0}])
    await probe.refresh()
    consumer.topics.assert_awaited_once()
    assert _lag_samples(probe) == {"0": 5.0}
    assert _lag_ok(probe) == 1.0


async def test_successful_start_binds_clients_and_reports_group(captured_app_logs: LogSink) -> None:
    """Успешный старт: клиенты сохранены в поля пробы, топик и группа — в логе.

    Группа берётся из настроек, и опрос идёт по ней: смотреть надо на лаг воркеров пересчёта,
    а не на лаг самой пробы — та подписки не имеет.
    """
    consumer = Mock(start=AsyncMock(), stop=AsyncMock())
    admin = Mock(start=AsyncMock(), close=AsyncMock())
    probe = RecalcLagProbe(_settings())

    with (
        patch("src.infra.kafka.lag_probe.AIOKafkaConsumer", return_value=consumer),
        patch("src.infra.kafka.lag_probe.AIOKafkaAdminClient", return_value=admin),
    ):
        await probe.start()

    assert probe._consumer is consumer and probe._admin is admin
    context = captured_app_logs.context_of("recalc lag probe started")
    assert context["topic"] == probe._topic
    assert context["group_id"] == probe._group_id


async def test_cleanup_failure_is_logged_and_does_not_mask_start_error(captured_app_logs: LogSink) -> None:
    """Уборка после частичного старта сама упала: наружу уходит ИСХОДНАЯ ошибка старта.

    Без warning-а недобитый клиент не оставил бы ни строчки: это код старта, где нет
    per-request X-Enable-Debug, а MonologFilter режет sub-INFO без него.
    """
    consumer = Mock(start=AsyncMock(), stop=AsyncMock(side_effect=OSError("socket already closed")))
    admin = Mock(start=AsyncMock(side_effect=RuntimeError("no offsets ACL")), close=AsyncMock())
    probe = RecalcLagProbe(_settings())

    with (
        patch("src.infra.kafka.lag_probe.AIOKafkaConsumer", return_value=consumer),
        patch("src.infra.kafka.lag_probe.AIOKafkaAdminClient", return_value=admin),
        pytest.raises(RuntimeError, match="no offsets ACL"),
    ):
        await probe.start()

    # Обход не прерывается на первом сбое: admin.close() всё равно вызывается.
    admin.close.assert_awaited_once()
    assert "recalc lag probe: cleanup after failed start errored" in captured_app_logs.messages()


async def test_stop_closes_both_clients_and_is_idempotent() -> None:
    """stop() освобождает клиентов и переживает повторный вызов.

    Дёргается на каждом штатном завершении из `_shutdown_lag_probe`, где повторный вызов возможен
    (teardown может быть перезапущен после таймаута), а лишний close по закрытому клиенту
    в aiokafka — уже ошибка.
    """
    probe, consumer, admin = _probe_with_mocks(partitions={0}, end_offsets={}, committed={})
    consumer.stop = AsyncMock()
    admin.close = AsyncMock()

    await probe.stop()
    await probe.stop()

    consumer.stop.assert_awaited_once()
    admin.close.assert_awaited_once()
    assert probe._consumer is None and probe._admin is None


async def test_stop_without_start_is_noop() -> None:
    """Проба, которая не поднялась (сбой старта — best-effort), не должна ронять teardown."""
    await RecalcLagProbe(_settings()).stop()


async def test_poll_before_start_reports_lag_unavailable() -> None:
    """refresh() до start(): _poll() поднимает RuntimeError, а наружу это выходит как lag_ok=0.

    Проба — обзервабилити: «опрос не удаётся» показывается рядом (=0), но исключение из скрейпа
    /metrics не вылетает.
    """
    probe = RecalcLagProbe(_settings())

    await probe.refresh()

    assert _lag_ok(probe) == 0.0
    assert _lag_samples(probe) == {}


async def test_topic_without_partitions_yields_empty_snapshot_marked_ok() -> None:
    """Метаданные подтянулись, а партиций всё равно нет — топик ещё не создан.

    Данных о лаге нет, но и сбоя опроса нет: lag_ok=1 при пустом наборе рядов отличает
    «топик пуст/не создан» от «брокер недоступен».
    """
    probe, consumer, _admin = _probe_with_mocks(partitions=set(), end_offsets={}, committed={})
    consumer.partitions_for_topic = Mock(return_value=set())

    await probe.refresh()

    consumer.topics.assert_awaited_once()
    assert _lag_samples(probe) == {}
    assert _lag_ok(probe) == 1.0
