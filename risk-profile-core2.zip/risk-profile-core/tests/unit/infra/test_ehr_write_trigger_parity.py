"""Триггер ЭМК и Python-хелпер пишут параметр одинаково — проверка набора колонок.

Путь ЭМК исполняет не `archive_and_upsert_patient_parameter`, а замороженную копию его правила:
функцию `risk_ehr.write_patient_parameter()` из миграции 0146. Копия не подтягивает правки
хелпера, и без этой проверки новая колонка `patients_parameters` попала бы только в одну из двух
реализаций — живые строки и история разъехались бы по источнику записи, молча.

Проверка статическая (без БД), потому что доказательство нужно на каждом прогоне CI, а не только
там, где поднят PostgreSQL: набор колонок — ровно то, что расходится при правке модели.
Поведение обеих реализаций на живых данных сверяет
`tests/integration/db_isolation/test_ehr_write_view.py::test_trigger_writes_the_same_row_as_the_helper`.
"""

import re
from pathlib import Path

from src.infra.patients_parameters import _HISTORY_COLUMNS
from src.models.patient_parameter import PatientParameter

_MIGRATION = (
    Path(__file__).resolve().parents[3] / "migrations/versions/0146_isolate_service_schemas_7918bbab2957.py"
).read_text(encoding="utf-8")

# Ключи уникального индекса и суррогатный PK в upsert не переписываются: первые задают строку,
# второй принадлежит БД. Всё остальное, что есть у модели, обязана писать каждая реализация.
_ROW_IDENTITY = {"patient_parameter_id", "patient_id", "parameter_code"}


def _insert_columns(table: str) -> set[str]:
    match = re.search(rf"INSERT INTO {re.escape(table)}\s*\(([^)]*)\)", _MIGRATION)
    assert match, f"в миграции 0146 не нашлось INSERT в {table}"
    return {column.strip() for column in match.group(1).split(",")}


def _upsert_columns() -> set[str]:
    match = re.search(r"DO UPDATE SET(.*?)RETURNING", _MIGRATION, re.DOTALL)
    assert match, "в миграции 0146 не нашлось ON CONFLICT DO UPDATE"
    return set(re.findall(r"(\w+)\s*=\s*EXCLUDED\.", match.group(1)))


def test_trigger_archives_the_same_columns_as_the_helper() -> None:
    assert _insert_columns("risk_profile.patients_parameters_history") == set(_HISTORY_COLUMNS)


def test_trigger_writes_every_column_of_the_model() -> None:
    model_columns = {column.name for column in PatientParameter.__table__.columns}

    assert _insert_columns("risk_profile.patients_parameters") == model_columns - {"patient_parameter_id"}
    assert _upsert_columns() == model_columns - _ROW_IDENTITY


def test_helper_archives_every_column_of_the_model() -> None:
    """Та же мерка для хелпера: история хранит строку целиком, кроме собственного суррогатного PK."""
    model_columns = {column.name for column in PatientParameter.__table__.columns}

    assert set(_HISTORY_COLUMNS) == model_columns - {"patient_parameter_id"}
