"""Unit-тесты `KafkaTopicConsumer`: порядок, параллелизм, commit, poison-tolerance, трассировка,
инжектируемые декодер payload и настройки consumer-группы."""

import json
from types import SimpleNamespace
from typing import Any

import pytest
from aiokafka.errors import ConsumerStoppedError, KafkaConnectionError

from src.config import KafkaConsumerSettings, KafkaSettings
from src.infra.kafka import consumer as consumer_module
from src.infra.kafka.consumer import KafkaTopicConsumer, raw_decoder
from src.logger import debug_enabled_var, request_id_var, x_enable_debug_var

TOPIC = "risk-profile.recalc-commands"


def _settings(max_concurrency: int = 4) -> KafkaSettings:
    return KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="PLAINTEXT",
        client_id="test-consumer",
        consumer=KafkaConsumerSettings(max_concurrency=max_concurrency),
    )


def _record(value: Any, *, partition: int = 0, offset: int = 0, headers: list | None = None) -> SimpleNamespace:
    raw = json.dumps(value).encode("utf-8") if value is not None else None
    return _raw_record(raw, partition=partition, offset=offset, headers=headers)


def _raw_record(
    raw: bytes | None, *, partition: int = 0, offset: int = 0, headers: list | None = None
) -> SimpleNamespace:
    """Запись с payload как есть — для топиков, где разбор делает обработчик, а не консюмер."""
    return SimpleNamespace(
        topic=TOPIC,
        partition=partition,
        offset=offset,
        value=raw,
        headers=headers or [],
    )


class _FakeAIOKafkaConsumer:
    """Проигрывает заданную последовательность шагов на getmany: dict-батч возвращается,
    BaseException — бросается. Когда шаги кончились — ConsumerStoppedError (штатный останов)."""

    def __init__(self, steps: list, **kwargs: Any) -> None:
        self._steps = list(steps)
        self.kwargs = kwargs  # с какими параметрами консюмер собрал AIOKafkaConsumer
        self.started = False
        self.stopped = False
        self.commit_count = 0
        # Сбой коммита оффсета: тесты дублирующей доставки держат его отдельно от сбоя poll.
        self.commit_fail_with: BaseException | None = None

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def getmany(self, *, timeout_ms: int, max_records: int) -> dict:
        if not self._steps:
            raise ConsumerStoppedError()
        step = self._steps.pop(0)
        if isinstance(step, BaseException):
            raise step
        return step

    async def commit(self, offsets: Any = None) -> None:
        self.commit_count += 1
        if self.commit_fail_with is not None:
            raise self.commit_fail_with


@pytest.fixture
def patch_consumer(monkeypatch: pytest.MonkeyPatch):
    holder: dict[str, _FakeAIOKafkaConsumer] = {}

    def _install(batches: list[dict]) -> dict[str, _FakeAIOKafkaConsumer]:
        def _factory(*_a: Any, **kwargs: Any) -> _FakeAIOKafkaConsumer:
            inst = _FakeAIOKafkaConsumer(batches, **kwargs)
            holder["instance"] = inst
            return inst

        monkeypatch.setattr(consumer_module, "AIOKafkaConsumer", _factory)
        return holder

    return _install


async def test_decodes_json_value_and_passes_dict_to_handler(patch_consumer) -> None:
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    batch = {"tp0": [_record({"clientId": "p1", "parameterCodes": None}, offset=0)]}
    patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    # Сырые bytes раскодированы в dict до передачи в обработчик.
    assert seen == [{"clientId": "p1", "parameterCodes": None}]


async def test_commit_called_once_per_batch(patch_consumer) -> None:
    async def handler(_value: Any) -> None:
        return None

    holder = patch_consumer([{"tp0": [_record({"clientId": "p1"})]}])
    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert holder["instance"].commit_count == 1


async def test_preserves_order_within_partition(patch_consumer) -> None:
    seen: list[str] = []

    async def handler(value: Any) -> None:
        seen.append(value["clientId"])

    batch = {
        "tp0": [
            _record({"clientId": "a"}, partition=0, offset=0),
            _record({"clientId": "b"}, partition=0, offset=1),
            _record({"clientId": "c"}, partition=0, offset=2),
        ]
    }
    patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    # Внутри партиции — строгий порядок оффсетов (порядок пересчётов на пациента).
    assert seen == ["a", "b", "c"]


async def test_poison_record_is_skipped_and_batch_still_commits(patch_consumer) -> None:
    processed: list[Any] = []

    async def handler(value: Any) -> None:
        if value == {"bad": True}:
            raise ValueError("poison")
        processed.append(value)

    batch = {
        "tp0": [
            _record({"ok": 1}, offset=0),
            _record({"bad": True}, offset=1),
            _record({"ok": 2}, offset=2),
        ]
    }
    holder = patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()  # не должно бросить

    # Битое сообщение пропущено, остальные обработаны, оффсет всё равно прокоммичен.
    assert processed == [{"ok": 1}, {"ok": 2}]
    assert holder["instance"].commit_count == 1


async def test_restores_trace_context_from_headers(patch_consumer) -> None:
    captured: dict[str, str] = {}

    async def handler(_value: Any) -> None:
        captured["request_id"] = request_id_var.get()
        captured["x_enable_debug"] = x_enable_debug_var.get()

    headers = [("x-request-id", b"req-99"), ("x-enable-debug", b"true")]
    batch = {"tp0": [_record({"clientId": "p1"}, headers=headers)]}
    patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert captured["request_id"] == "req-99"
    assert captured["x_enable_debug"] == "true"


async def test_generates_request_id_when_header_absent(patch_consumer) -> None:
    captured: dict[str, str] = {}

    async def handler(_value: Any) -> None:
        captured["request_id"] = request_id_var.get()

    batch = {"tp0": [_record({"clientId": "p1"}, headers=[])]}
    patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert captured["request_id"]  # непустой uuid сгенерирован


async def test_run_before_start_raises(patch_consumer) -> None:
    async def handler(_value: Any) -> None:
        return None

    patch_consumer([])
    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    from src.infra.kafka.exceptions import KafkaInitError

    with pytest.raises(KafkaInitError):
        await c.run()


async def test_poll_kafka_error_is_retried_not_fatal(patch_consumer, monkeypatch: pytest.MonkeyPatch) -> None:
    """Транзиентная KafkaError из getmany не роняет цикл: лог + backoff + retry, сообщение доходит."""
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    # Шаг 1 — обрыв связи (KafkaError), шаг 2 — нормальный батч; затем штатный останов.
    holder = patch_consumer([KafkaConnectionError("blip"), {"tp0": [_record({"clientId": "p1"})]}])
    # Ускоряем backoff, чтобы тест не ждал реальную секунду.
    monkeypatch.setattr(KafkaTopicConsumer, "_POLL_ERROR_BACKOFF_INITIAL", 0.001)

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()  # не должно пробросить KafkaError

    assert seen == [{"clientId": "p1"}]
    assert holder["instance"].commit_count == 1


async def test_x_enable_debug_normalized_at_trust_boundary(patch_consumer) -> None:
    """Мусорный x-enable-debug из заголовка не включает debug — нормализуем к "" на границе доверия."""
    captured: dict[str, Any] = {}

    async def handler(_value: Any) -> None:
        captured["x_enable_debug"] = x_enable_debug_var.get()
        captured["debug_enabled"] = debug_enabled_var.get()

    headers = [("x-request-id", b"req-1"), ("x-enable-debug", b"HACKME\n")]
    patch_consumer([{"tp0": [_record({"clientId": "p1"}, headers=headers)]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert captured["x_enable_debug"] == ""
    assert captured["debug_enabled"] is False


async def test_raw_decoder_passes_payload_bytes_to_handler(patch_consumer) -> None:
    """С декодером сырых байтов обработчик получает payload как есть, без разбора JSON."""
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    patch_consumer([{"tp0": [_raw_record(b'{"clientId": "p1"}')]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler, decoder=raw_decoder)
    await c.start()
    await c.run()

    assert seen == [b'{"clientId": "p1"}']


async def test_raw_decoder_delivers_broken_json_to_handler(patch_consumer) -> None:
    """Битый JSON доходит до обработчика: разбор — часть доменной валидации такого топика,
    и код причины должен писать обработчик, а не общий `except` консюмера."""
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    holder = patch_consumer([{"tp0": [_raw_record(b"{")]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler, decoder=raw_decoder)
    await c.start()
    await c.run()

    assert seen == [b"{"]
    assert holder["instance"].commit_count == 1


async def test_injected_consumer_settings_define_group(patch_consumer) -> None:
    """Переданные настройки задают consumer-группу: без этого два воркера сели бы в одну группу
    и отбирали бы друг у друга партиции."""

    async def handler(_value: Any) -> None:
        return None

    holder = patch_consumer([])
    settings = _settings()

    c = KafkaTopicConsumer(
        settings,
        TOPIC,
        handler,
        consumer_settings=KafkaConsumerSettings(group_id="other-topic-workers", max_concurrency=2),
    )
    await c.start()

    kwargs = holder["instance"].kwargs
    assert kwargs["group_id"] == "other-topic-workers"
    assert settings.consumer.group_id == "risk-recalc-workers"  # дефолт не тронут


async def test_default_consumer_settings_come_from_kafka_settings(patch_consumer) -> None:
    """Без явных настроек группа берётся из `kafka.consumer` — путь пересчёта не меняется."""

    async def handler(_value: Any) -> None:
        return None

    holder = patch_consumer([])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()

    assert holder["instance"].kwargs["group_id"] == "risk-recalc-workers"


@pytest.mark.parametrize("header", ["x-request-id", "x-enable-debug"])
async def test_undecodable_trace_header_does_not_break_the_loop(header: str, patch_consumer) -> None:
    """Битые байты в трейс-заголовке не роняют цикл: заголовки декодируются ДО перехвата
    poison-сообщений, и голый `bytes.decode` вылетел бы из `run()` наружу.

    Проверяем именно последствия падения, а не только его отсутствие: соседняя валидная запись
    того же батча обработана и оффсет закоммичен. Без этого битый байт останавливал бы чтение
    топика насовсем — оффсет не двигается, после рестарта приезжает тот же батч.
    """
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    batch = {
        "tp0": [
            _record({"clientId": "p1"}, offset=1, headers=[(header, b"\xff\xfe")]),
            _record({"clientId": "p2"}, offset=2),
        ]
    }
    holder = patch_consumer([batch])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert seen == [{"clientId": "p1"}, {"clientId": "p2"}]
    assert holder["instance"].commit_count == 1


async def test_undecodable_request_id_falls_back_to_generated_one(patch_consumer) -> None:
    """Неразбираемый `x-request-id` трактуется как отсутствующий: подставляется новый
    идентификатор, а не склеенная из байтов-замен строка — мусор продюсера в логи не уезжает."""
    captured: dict[str, Any] = {}

    async def handler(_value: Any) -> None:
        captured["request_id"] = request_id_var.get()

    patch_consumer([{"tp0": [_record({"clientId": "p1"}, headers=[("x-request-id", b"\xff\xfe")])]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert captured["request_id"]
    assert "�" not in captured["request_id"]


async def test_empty_poll_result_just_polls_again(patch_consumer) -> None:
    """Пустая выдача poll — не повод коммитить: цикл идёт за следующим батчем."""

    async def handler(value: Any) -> None:
        seen.append(value)

    seen: list[Any] = []
    holder = patch_consumer([{}, {"tp0": [_record({"clientId": "p1"})]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    await c.run()

    assert seen == [{"clientId": "p1"}]
    assert holder["instance"].commit_count == 1


async def test_commit_failure_is_logged_and_loop_survives(patch_consumer, caplog: pytest.LogCaptureFixture) -> None:
    """Упавший commit не роняет цикл: сообщения приедут повторно (at-least-once), обработка идемпотентна.

    Молчаливый выход отсюда означал бы остановку воркера при живом брокере, а необработанная
    ошибка — потерю следа причины дублирующей доставки.
    """
    seen: list[Any] = []

    async def handler(value: Any) -> None:
        seen.append(value)

    holder = patch_consumer([{"tp0": [_record({"clientId": "p1"})]}, {"tp0": [_record({"clientId": "p2"})]}])

    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()
    holder["instance"].commit_fail_with = KafkaConnectionError("commit refused")
    with caplog.at_level("ERROR", logger="app"):
        await c.run()

    assert seen == [{"clientId": "p1"}, {"clientId": "p2"}]
    assert holder["instance"].commit_count == 2
    assert "kafka.consumer: offset commit failed" in caplog.text


async def test_stop_closes_consumer_and_is_idempotent(patch_consumer) -> None:
    """Повторный stop не падает: shutdown вызывается и по сигналу, и из finally воркера."""

    async def handler(_value: Any) -> None:
        return None

    holder = patch_consumer([])
    c = KafkaTopicConsumer(_settings(), TOPIC, handler)
    await c.start()

    await c.stop()
    assert holder["instance"].stopped
    await c.stop()


async def test_stop_before_start_is_noop(patch_consumer) -> None:
    """Останов невзлетевшего консюмера тоже безопасен: старт мог упасть на ретраях."""

    async def handler(_value: Any) -> None:
        return None

    patch_consumer([])
    await KafkaTopicConsumer(_settings(), TOPIC, handler).stop()
