"""Best-effort-обвязка пробы лага в lifespan и чтение версии сервиса.

Проба лага — обзервабилити, а не бизнес-функция: ни её старт, ни её остановка не имеют права
повлиять на выдачу. Обе стороны этого договора проверяются здесь, потому что
`test_lifespan_shutdown` подменяет `_init_lag_probe`/`_shutdown_lag_probe` заглушками.
"""

import json
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import pytest

import src.main as main_module
from src.metrics import LOCAL_REGISTRY
from tests.conftest import LogSink


def _registered_names() -> set[str]:
    """Имена метрик, реально уходящих в /metrics из локального реестра."""
    return {family.name for family in LOCAL_REGISTRY.collect()}


@pytest.fixture(autouse=True)
def _restore_lag_probe() -> object:
    """Проба живёт в модульной переменной и в глобальном реестре — возвращаем обе на место."""
    original = main_module._lag_probe
    yield
    probe = main_module._lag_probe
    if probe is not None and probe is not original:
        LOCAL_REGISTRY.unregister(probe)
    main_module._lag_probe = original


@pytest.mark.parametrize(
    ("kafka_enabled", "metrics_enabled"),
    [(False, True), (True, False), (False, False)],
)
async def test_probe_not_created_unless_both_kafka_and_metrics_are_on(
    kafka_enabled: bool, metrics_enabled: bool
) -> None:
    """Лаг очереди нечем мерить без Kafka и некуда отдавать без метрик — клиентов не создаём."""
    with (
        patch.object(main_module.settings.kafka, "enabled", kafka_enabled),
        patch.object(main_module.settings.metrics, "enabled", metrics_enabled),
        patch.object(main_module, "RecalcLagProbe") as probe_class,
    ):
        await main_module._init_lag_probe()

    probe_class.assert_not_called()
    assert main_module._lag_probe is None


async def test_probe_start_failure_leaves_collector_registered(captured_app_logs: LogSink) -> None:
    """Брокер недоступен на старте: приложение поднимается, а ряд `lag_ok` остаётся в выдаче.

    Коллектор регистрируется ДО старта клиентов именно ради этого: дашборд заказчика должен
    видеть «опрос не удаётся» (значение 0), а не отсутствие ряда, которое читается как «метрики
    сломались» и уводит разбор не туда.
    """
    # describe() задаём явно: реестр спрашивает его первым, и авто-атрибут Mock-а туда не годится.
    probe = Mock(
        start=AsyncMock(side_effect=RuntimeError("no ACL for group offsets")),
        describe=Mock(return_value=[]),
    )
    with (
        patch.object(main_module.settings.kafka, "enabled", True),
        patch.object(main_module.settings.metrics, "enabled", True),
        patch.object(main_module, "RecalcLagProbe", return_value=probe),
    ):
        await main_module._init_lag_probe()

    assert main_module._lag_probe is probe
    assert probe in LOCAL_REGISTRY._collector_to_names
    assert "recalc lag probe failed to start; lag_ok will report 0 until restart" in captured_app_logs.messages()


async def test_started_probe_exposes_lag_metrics_and_is_removed_on_shutdown() -> None:
    """Полный цикл: после старта ряды пробы в выдаче, после остановки их там нет.

    Снятие коллектора на shutdown обязательно: реестр глобальный, и осевшая в нём остановленная
    проба отдавала бы на каждом скрейпе снимок, который больше никто не обновляет.
    """
    probe = main_module.RecalcLagProbe(main_module.settings.kafka)
    with (
        patch.object(main_module.settings.kafka, "enabled", True),
        patch.object(main_module.settings.metrics, "enabled", True),
        patch.object(main_module, "RecalcLagProbe", return_value=probe),
        patch.object(probe, "start", AsyncMock()),
        patch.object(probe, "stop", AsyncMock()) as stop,
    ):
        await main_module._init_lag_probe()
        assert "risk_profile_core_recalc_queue_lag_ok" in _registered_names()

        await main_module._shutdown_lag_probe()

    stop.assert_awaited_once()
    assert "risk_profile_core_recalc_queue_lag_ok" not in _registered_names()
    assert main_module._lag_probe is None


async def test_probe_stop_failure_does_not_abort_the_rest_of_teardown(captured_app_logs: LogSink) -> None:
    """Битый коннект к брокеру на shutdown не должен сорвать остальной teardown.

    `_teardown` в lifespan обёрнут только в `except TimeoutError`, поэтому проброс отсюда пропустил
    бы дренаж продюсера и `engine.dispose()` — недосланные события и незакрытый пул соединений.
    """
    probe = Mock(stop=AsyncMock(side_effect=OSError("connection reset")), describe=Mock(return_value=[]))
    LOCAL_REGISTRY.register(probe)
    main_module._lag_probe = probe

    await main_module._shutdown_lag_probe()

    assert main_module._lag_probe is None
    assert probe not in LOCAL_REGISTRY._collector_to_names
    assert "recalc lag probe stop failed during shutdown" in captured_app_logs.messages()


async def test_shutdown_without_probe_is_noop() -> None:
    """Проба не поднималась (Kafka или метрики выключены) — teardown проходит молча."""
    main_module._lag_probe = None
    await main_module._shutdown_lag_probe()


def test_service_version_is_read_from_version_json(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    (tmp_path / "version.json").write_text(json.dumps({"version": "1.2.3"}))
    monkeypatch.chdir(tmp_path)

    assert main_module._service_version() == "1.2.3"


@pytest.mark.parametrize(
    ("content", "case"),
    [("{ not json", "битый JSON"), (json.dumps({"build": 7}), "нет ключа version")],
)
def test_service_version_falls_back_to_unknown(
    content: str, case: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
) -> None:
    """Версия уезжает в метрики и в стартовый лог — нечитаемый файл не имеет права ронять старт.

    Отсутствующий ключ отдаёт "unknown" молча (штатный дефолт), битый файл — с warning-ом.
    """
    (tmp_path / "version.json").write_text(content)
    monkeypatch.chdir(tmp_path)

    assert main_module._service_version() == "unknown"
    if case == "битый JSON":
        assert "failed to read version.json" in captured_app_logs.messages()


def test_service_version_survives_missing_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Файла нет вовсе — запуск не из корня репозитория или урезанный образ."""
    monkeypatch.chdir(tmp_path)

    assert main_module._service_version() == "unknown"
