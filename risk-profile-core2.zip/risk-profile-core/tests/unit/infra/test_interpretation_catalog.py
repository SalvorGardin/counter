import logging
from decimal import Decimal

import pytest

from src.infra.catalog.base import Catalog
from src.infra.catalog.dtos import (
    InstrumentDTO,
    RecommendedDoctorDTO,
    RiskFactorDTO,
    RiskFactorSystemDTO,
    RiskFactorTriggerDTO,
)
from src.infra.catalog.interpretation import (
    DISEASE_CODE_SYSTEM_NOT_LINKED,
    DISEASE_CODE_UNKNOWN,
    InterpretationCatalog,
    RejectedDiseaseCode,
)
from tests.catalog_builder import (
    disease,
    instrument,
    instrument_parameter,
    make_catalog,
    parameter,
    risk_factor,
    risk_factor_score,
    risk_factor_system,
    risk_factor_trigger,
    score,
    system_instrument,
)

# RecommendedDoctorDTO / RiskFactorDTO / RiskFactorSystemDTO / RiskFactorTriggerDTO have no
# factory in tests/catalog_builder.py (it only covers the seven-table calc-reference catalog) —
# constructed directly here.


def _catalog() -> Catalog:
    return make_catalog(
        instruments=[
            instrument("findrisk_t", type="calc", instrument_id=1, diseases=["diabetes_2"]),
            instrument("instr_low", type="calc", instrument_id=2),
        ],
        instruments_parameters=[
            instrument_parameter("findrisk_t", "smoking_t", is_required=True),
            instrument_parameter("findrisk_t", "bmi_t"),
        ],
        systems_instruments=[
            system_instrument("ENDO", "findrisk_t"),
            system_instrument("CARDIO", "findrisk_t"),
        ],
        recommended_doctors=[
            RecommendedDoctorDTO("ENDO", "high", 19, 2),
            RecommendedDoctorDTO("ENDO", "high", 35, 1),
        ],
        risk_factors=[
            RiskFactorDTO(1, "rf_smoke", "smokes", "Модифицируемый"),
            RiskFactorDTO(2, "rf_other", "x", "Немодифицируемый"),
        ],
        risk_factor_systems=[
            RiskFactorSystemDTO(1, "rf_smoke", "ENDO", None),
            RiskFactorSystemDTO(2, "rf_other", "ENDO", None),
        ],
        risk_factor_triggers=[
            RiskFactorTriggerDTO(
                1,
                "rf_smoke__ENDO__smoking_t__01",
                "rf_smoke",
                "ENDO",
                "smoking_t",
                "text",
                "eq",
                None,
                None,
                None,
                "yes",
                None,
            ),
            RiskFactorTriggerDTO(
                2,
                "rf_other__ENDO__other_p__01",
                "rf_other",
                "ENDO",
                "other_p",
                "text",
                "eq",
                None,
                None,
                None,
                "x",
                None,
            ),
        ],
        parameter_scores=[
            score("smoking_t", "ENDO", value="yes", score=Decimal("2")),
            score("bmi_t", "CARDIO", min_value=Decimal("30"), max_value=Decimal("40"), score=Decimal("3")),
        ],
    )


_REJECTED_MESSAGE = "interpretation.catalog: instrument disease code rejected"


def _disease_catalog(*instruments: InstrumentDTO, systems_instruments: tuple = ()) -> Catalog:
    return make_catalog(
        instruments=instruments,
        systems_instruments=systems_instruments,
        diseases=[
            disease("diabetes_mellitus", "ENDO"),
            disease("osteoporosis", "ENDO"),
            disease("sleep_apnea", "RESP"),
            disease("renal_failure", "URO"),
            disease("infarction_ischemic_stroke", "CVD"),
        ],
    )


def test_disease_codes_are_keyed_by_system_and_instrument() -> None:
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("findrisk", type="calc", diseases=["diabetes_mellitus"]),
            instrument("form_dm2", type="form", diseases=["diabetes_mellitus", "osteoporosis"]),
            systems_instruments=(system_instrument("ENDO", "findrisk"), system_instrument("ENDO", "form_dm2")),
        )
    )

    assert cat.disease_codes_by_system_instrument == {
        ("ENDO", "findrisk"): ("diabetes_mellitus",),
        ("ENDO", "form_dm2"): ("diabetes_mellitus", "osteoporosis"),
    }
    assert cat.rejected_disease_codes == ()


def test_instrument_of_several_systems_gets_each_group_under_its_own_system() -> None:
    """Группа одной системы инструмента не ошибка для другой его системы — она просто не её."""
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("ckd_cvd", type="calc", diseases=["infarction_ischemic_stroke", "renal_failure"]),
            systems_instruments=(system_instrument("CVD", "ckd_cvd"), system_instrument("URO", "ckd_cvd")),
        )
    )

    assert cat.disease_codes_by_system_instrument == {
        ("CVD", "ckd_cvd"): ("infarction_ischemic_stroke",),
        ("URO", "ckd_cvd"): ("renal_failure",),
    }
    assert cat.rejected_disease_codes == ()


def test_unknown_disease_code_is_rejected() -> None:
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("findrisk", type="calc", diseases=["diabetes_2", "diabetes_mellitus"]),
            systems_instruments=(system_instrument("ENDO", "findrisk"),),
        )
    )

    assert cat.disease_codes_by_system_instrument == {("ENDO", "findrisk"): ("diabetes_mellitus",)}
    assert cat.rejected_disease_codes == (
        RejectedDiseaseCode(instrument_code="findrisk", disease_code="diabetes_2", cause=DISEASE_CODE_UNKNOWN),
    )


def test_disease_of_a_system_not_linked_to_the_instrument_is_rejected() -> None:
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("findrisk", type="calc", diseases=["sleep_apnea"]),
            systems_instruments=(system_instrument("ENDO", "findrisk"),),
        )
    )

    assert cat.disease_codes_by_system_instrument == {}
    assert cat.rejected_disease_codes == (
        RejectedDiseaseCode(
            instrument_code="findrisk", disease_code="sleep_apnea", cause=DISEASE_CODE_SYSTEM_NOT_LINKED
        ),
    )


@pytest.mark.parametrize(
    "excluded",
    [
        instrument("old_findrisk", type="calc", status="inactive", diseases=["diabetes_mellitus"]),
        instrument("biomarker_kr", type="biomarker_kr", diseases=["diabetes_mellitus"]),
        instrument("other_type", type="survey", diseases=["diabetes_mellitus"]),
    ],
    ids=["inactive", "biomarker_kr", "other_type"],
)
def test_only_active_calc_and_form_instruments_are_indexed(excluded: InstrumentDTO) -> None:
    """Инструмент вне правила не индексируется и не проверяется: ни группы, ни ошибки."""
    cat = InterpretationCatalog(
        _disease_catalog(excluded, systems_instruments=(system_instrument("ENDO", excluded.code),))
    )

    assert cat.disease_codes_by_system_instrument == {}
    assert cat.rejected_disease_codes == ()


def test_instrument_without_groups_is_not_indexed() -> None:
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("form_endo", type="form", diseases=None),
            instrument("form_empty", type="form", diseases=[]),
            systems_instruments=(system_instrument("ENDO", "form_endo"), system_instrument("ENDO", "form_empty")),
        )
    )

    assert cat.disease_codes_by_system_instrument == {}


def test_duplicate_disease_codes_are_indexed_once() -> None:
    cat = InterpretationCatalog(
        _disease_catalog(
            instrument("findrisk", type="calc", diseases=["diabetes_mellitus", "diabetes_mellitus"]),
            systems_instruments=(system_instrument("ENDO", "findrisk"),),
        )
    )

    assert cat.disease_codes_by_system_instrument == {("ENDO", "findrisk"): ("diabetes_mellitus",)}


def test_disease_codes_index_is_immutable() -> None:
    """Каталог резидентен на весь процесс: ни маппинг, ни его значения не правятся."""
    base = _disease_catalog(
        instrument("findrisk", type="calc", diseases=["diabetes_mellitus"]),
        systems_instruments=(system_instrument("ENDO", "findrisk"),),
    )
    cat = InterpretationCatalog(base)

    with pytest.raises(TypeError):
        cat.disease_codes_by_system_instrument[("ENDO", "x")] = ()  # ty: ignore[invalid-assignment]
    # Значение — кортеж-копия, а не тот же list, что лежит в DTO: правка источника вью не задевает.
    source = base.get("instruments")[0].diseases
    assert source is not None
    source.append("osteoporosis")
    assert cat.disease_codes_by_system_instrument[("ENDO", "findrisk")] == ("diabetes_mellitus",)


def test_each_rejected_code_is_logged_once(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.ERROR, logger="src"):
        InterpretationCatalog(
            _disease_catalog(
                instrument("findrisk", type="calc", diseases=["diabetes_2", "sleep_apnea"]),
                systems_instruments=(system_instrument("ENDO", "findrisk"),),
            )
        )

    records = [r for r in caplog.records if r.message == _REJECTED_MESSAGE]
    assert [r.levelno for r in records] == [logging.ERROR, logging.ERROR]
    assert [r.log_context for r in records] == [  # ty: ignore[unresolved-attribute]
        {"instrument_code": "findrisk", "disease_code": "diabetes_2", "cause": DISEASE_CODE_UNKNOWN},
        {"instrument_code": "findrisk", "disease_code": "sleep_apnea", "cause": DISEASE_CODE_SYSTEM_NOT_LINKED},
    ]


def test_valid_disease_markup_logs_no_errors(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.ERROR, logger="src"):
        InterpretationCatalog(
            _disease_catalog(
                instrument("findrisk", type="calc", diseases=["diabetes_mellitus"]),
                systems_instruments=(system_instrument("ENDO", "findrisk"),),
            )
        )

    assert [r for r in caplog.records if r.message == _REJECTED_MESSAGE] == []


def test_param_codes_by_system_union() -> None:
    cat = InterpretationCatalog(_catalog())
    assert cat.param_codes_by_system["ENDO"] == frozenset({"smoking_t", "bmi_t"})
    assert cat.param_codes_by_system["CARDIO"] == frozenset({"smoking_t", "bmi_t"})


def test_recommended_doctors_ordered_by_id_as_str() -> None:
    cat = InterpretationCatalog(_catalog())
    # ordered by recommended_doctor_id (1 before 2), codes cast to str.
    assert cat.recommended_doctors_by_system_level[("ENDO", "high")] == ("35", "19")


def test_risk_factors_for_filters_by_params() -> None:
    cat = InterpretationCatalog(_catalog())
    rows = cat.risk_factors_for("ENDO", {"smoking_t"})
    assert [r.code for r in rows] == ["rf_smoke"]
    assert cat.risk_factors_for("ENDO", set()) == []


def test_score_rows_for_filters_by_params() -> None:
    cat = InterpretationCatalog(_catalog())
    rows = cat.score_rows_for("ENDO", {"smoking_t", "bmi_t"})
    assert set(rows) == {"smoking_t"}
    assert rows["smoking_t"][0].score == Decimal("2")


def _clinrec_catalog() -> Catalog:
    """Каталог клинрек-источника: биомаркерные условия, баллы и связи факторов с системами."""
    return make_catalog(
        instruments=[instrument("biomarker_kr", type="biomarker_kr", instrument_id=1)],
        # Клинрек-источник берёт условие только по активному параметру-биомаркеру, связанному с
        # инструментом, — тот же отбор, что и расчёт. Параметр `smoking` связан, но префикса не
        # имеет, поэтому его условие в источник не попадает.
        parameters=[parameter("biomarker_ldl"), parameter("biomarker_gluc"), parameter("smoking")],
        instruments_parameters=[
            instrument_parameter("biomarker_kr", "biomarker_ldl", is_required=False),
            instrument_parameter("biomarker_kr", "biomarker_gluc", is_required=False),
            instrument_parameter("biomarker_kr", "smoking", is_required=False),
        ],
        diseases=[disease("d_cvd", "CVD", description="Инфаркт"), disease("d_dm", "ENDO", description="Диабет")],
        risk_factors=[
            risk_factor("rf_ldl", description="ЛПНП повышен", risk_factor_id=10),
            risk_factor("rf_gluc", description="Глюкоза повышена", risk_factor_id=11),
            risk_factor("rf_low", description="Балл ниже трёх", risk_factor_id=12),
        ],
        risk_factor_systems=[
            risk_factor_system("rf_ldl", "CVD", reasoning="почему ЛПНП"),
            # Фактор связан с двумя системами: у одного из его условий `system_code` — ENDO,
            # и связь для него обязана существовать (инвариант сборки каталога).
            risk_factor_system("rf_ldl", "ENDO", reasoning="почему ЛПНП в ENDO"),
            risk_factor_system("rf_gluc", "ENDO", reasoning="почему глюкоза"),
            risk_factor_system("rf_low", "CVD", reasoning=None),
        ],
        risk_factor_triggers=[
            # `system_code` условия отличается от системы фактора — на отбор это не влияет.
            risk_factor_trigger("rf_ldl", "ENDO", "biomarker_ldl", operator="gt", value_num=Decimal("3"), trigger_id=1),
            risk_factor_trigger("rf_ldl", "CVD", "biomarker_ldl", operator="gt", value_num=Decimal("5"), trigger_id=2),
            risk_factor_trigger(
                "rf_gluc", "ENDO", "biomarker_gluc", operator="gt", value_num=Decimal("6"), trigger_id=3
            ),
            risk_factor_trigger("rf_low", "CVD", "biomarker_ldl", operator="gt", value_num=Decimal("1"), trigger_id=4),
            # Условие по НЕбиомаркерному параметру клинрек-источник не отбирает.
            risk_factor_trigger("rf_ldl", "CVD", "smoking", trigger_id=5),
        ],
        risk_factor_scores=[
            risk_factor_score("rf_ldl", "d_cvd", score=3),
            risk_factor_score("rf_gluc", "d_dm", score=3),
            risk_factor_score("rf_low", "d_cvd", score=2),
        ],
    )


def test_diseases_by_code_carries_description_and_system() -> None:
    cat = InterpretationCatalog(_clinrec_catalog())
    assert cat.diseases_by_code["d_cvd"].description == "Инфаркт"
    assert cat.diseases_by_code["d_cvd"].system_code == "CVD"


def test_clinrec_factors_are_keyed_by_system_and_disease() -> None:
    cat = InterpretationCatalog(_clinrec_catalog())
    rows = cat.clinrec_factors_for("CVD", "d_cvd")
    # По строке на каждое биомаркерное условие фактора; условие по `smoking` не попадает.
    assert [(row.code, row.trigger_id) for row in rows] == [("rf_ldl", 1), ("rf_ldl", 2)]
    # `reasoning` берётся из связи фактора с ЭТОЙ системой.
    assert {row.reasoning for row in rows} == {"почему ЛПНП"}


def test_clinrec_factors_drop_scores_other_than_three() -> None:
    cat = InterpretationCatalog(_clinrec_catalog())
    assert all(row.code != "rf_low" for row in cat.clinrec_factors_for("CVD", "d_cvd"))


def test_clinrec_factors_require_factor_system_link() -> None:
    cat = InterpretationCatalog(_clinrec_catalog())
    # rf_gluc связан только с ENDO: в CVD его нет ни по одной группе.
    assert cat.clinrec_factors_for("ENDO", "d_dm") != ()
    assert cat.clinrec_factors_for("CVD", "d_dm") == ()


def test_clinrec_index_is_empty_without_reference_rows() -> None:
    """Справочник клинрек-расчёта заливается отдельно: без него интерпретация обязана считаться."""
    cat = InterpretationCatalog(_catalog())
    assert cat.diseases_by_code == {}
    assert cat.clinrec_factors_for("ENDO", "d_dm") == ()


def test_inactive_instrument_is_left_out_of_instrument_views() -> None:
    cat = InterpretationCatalog(
        make_catalog(
            instruments=[
                instrument("active_i", instrument_id=1),
                instrument("old_i", status="inactive", instrument_id=2),
            ],
            instruments_parameters=[
                instrument_parameter("active_i", "p_active"),
                instrument_parameter("old_i", "p_old"),
            ],
            systems_instruments=[system_instrument("S", "active_i"), system_instrument("S", "old_i")],
        )
    )

    assert cat.instrument_codes_by_system["S"] == ("active_i",)
    assert cat.parameter_codes_by_instrument == {"active_i": frozenset({"p_active"})}
    assert cat.param_codes_by_system["S"] == frozenset({"p_active"})
