import dataclasses
from decimal import Decimal
from types import MappingProxyType

import pytest

from src.constants import CLINREC_FACTOR_SCORE
from src.infra.catalog.base import _TABLE_SPECS, Catalog, CatalogLoadError
from src.infra.catalog.dtos import (
    BiomarkerDTO,
    BiomarkerParameterMappingDTO,
    ConditionDTO,
    DiseaseDTO,
    DiseaseExaminationDTO,
    DoctorDTO,
    ExaminationDTO,
    InstrumentDTO,
    InstrumentParameterDTO,
    OptionDTO,
    ParameterDTO,
    QuestionDTO,
    RecommendationDTO,
    RecommendedDoctorDTO,
    RiskFactorDTO,
    RiskFactorScoreDTO,
    RiskFactorSystemDTO,
    RiskFactorTriggerDTO,
    ScoreDTO,
    SystemCheckupExaminationDTO,
    SystemDTO,
    SystemInstrumentDTO,
)
from tests.catalog_builder import (
    biomarker,
    biomarker_mapping,
    condition,
    disease,
    disease_examination,
    examination,
    instrument,
    instrument_parameter,
    option,
    question,
    risk_factor_score,
    score,
    system_checkup_examination,
    system_instrument,
)
from tests.catalog_builder import system as system_
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER


def test_dtos_are_frozen():
    dto = instrument("i1", type="form", status="active", instrument_id=1, description="i1")
    with pytest.raises(dataclasses.FrozenInstanceError):
        dto.status = "inactive"  # ty: ignore[invalid-assignment]


def test_dto_fields():
    """По одному DTO на каждую таблицу из `_TABLE_SPECS` — см. `test_every_catalog_table_has_a_dto_field_test`.

    RecommendedDoctorDTO/RiskFactorDTO/RiskFactorSystemDTO/RiskFactorTriggerDTO/DoctorDTO/
    RecommendationDTO/ParameterDTO have no factory in tests/catalog_builder.py (it only covers
    the seven-table calc-reference catalog) — constructed directly here.
    """
    inst = instrument("i1", type="form", status="active", instrument_id=1, description="i1", diseases=["E11"])
    assert (inst.code, inst.type, inst.status, inst.diseases) == ("i1", "form", "active", ["E11"])
    ip = instrument_parameter("i1", "p1", is_required=True)
    assert (ip.instrument_code, ip.parameter_code, ip.is_required) == ("i1", "p1", True)
    opt = option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="a bit", option_id=1)
    assert opt.code == "BDI1_02"
    q = question("BDI1", group_code=2, question_id=1, question="BDI1")
    assert q.group_code == 2
    si = system_instrument("s1", "i1")
    assert (si.system_code, si.instrument_code) == ("s1", "i1")
    cond = condition(
        "sq_0350",
        PARAMETER_CODE_GENDER,
        value=GENDER_FEMALE,
        type="except",
        min_age=None,
        max_age=None,
    )
    assert (cond.question_code, cond.parameter_code, cond.value, cond.type, cond.min_age, cond.max_age) == (
        "sq_0350",
        PARAMETER_CODE_GENDER,
        GENDER_FEMALE,
        "except",
        None,
        None,
    )
    rd = RecommendedDoctorDTO(system_code="ENDO", risk_level="high", code=19, recommended_doctor_id=1)
    assert (rd.system_code, rd.risk_level, rd.code, rd.recommended_doctor_id) == ("ENDO", "high", 19, 1)
    rf = RiskFactorDTO(
        risk_factor_id=1,
        code="rf1",
        description="d",
        modifiability="Модифицируемый",
    )
    assert (rf.risk_factor_id, rf.code, rf.description) == (1, "rf1", "d")
    assert rf.modifiability == "Модифицируемый"
    link = RiskFactorSystemDTO(1, "rf1", "ENDO", "why")
    assert (link.risk_factor_code, link.system_code, link.reasoning) == ("rf1", "ENDO", "why")
    trigger = RiskFactorTriggerDTO(
        1, "rf1__ENDO__smoking_t__01", "rf1", "ENDO", "smoking_t", "text", "eq", None, None, None, "yes", None
    )
    assert (trigger.operator, trigger.value_text, trigger.gender) == ("eq", "yes", None)
    sc = score("smoking_t", "ENDO", value="yes", min_value=None, max_value=None, score=Decimal("2"))
    assert (sc.parameter_code, sc.system_code, sc.value) == ("smoking_t", "ENDO", "yes")
    assert (sc.min_value, sc.max_value, sc.score) == (None, None, Decimal("2"))
    # Диапазонный вариант той же таблицы: value=None, границы заданы.
    ranged = score(
        PARAMETER_CODE_AGE,
        "ENDO",
        value=None,
        min_value=Decimal("40"),
        max_value=Decimal("60"),
        score=Decimal("1.5"),
    )
    assert (ranged.value, ranged.min_value, ranged.max_value) == (None, Decimal("40"), Decimal("60"))
    assert system_("SYS", system_id=1, description="System", rang=1).code == "SYS"
    assert ParameterDTO.__dataclass_fields__["validity_period"]
    dis = disease("d_diabetes", "ENDO", description="Сахарный диабет", disease_id=1)
    assert (dis.disease_id, dis.code, dis.description, dis.system_code) == (
        1,
        "d_diabetes",
        "Сахарный диабет",
        "ENDO",
    )
    rfs = risk_factor_score("rf1", "d_diabetes", score=3, risk_factor_score_id=1)
    assert (rfs.risk_factor_code, rfs.disease_code, rfs.score, rfs.influence) == (
        "rf1",
        "d_diabetes",
        Decimal("3"),
        "increase",
    )
    assert DoctorDTO(1, 19, "Doctor").code == 19
    assert RecommendationDTO(1, None, "SYS", "Name", None, None).system_code == "SYS"
    biomarker_row = biomarker(101, "biomarker_101", biomarker_id=1)
    assert (biomarker_row.biomarker_code, biomarker_row.parameter_code) == (101, "biomarker_101")
    mapping_row = biomarker_mapping("biomarker_101", "target", biomarker_parameter_mapping_id=1)
    assert (mapping_row.biomarker_parameter_code, mapping_row.parameter_code) == ("biomarker_101", "target")
    exam = examination(examination_type="instrumental", status="inactive", name="УЗИ", examination_id=1)
    assert (exam.examination_id, exam.name, exam.examination_type, exam.status) == (
        1,
        "УЗИ",
        "instrumental",
        "inactive",
    )
    disease_link = disease_examination("d_diabetes", exam.code, category=None, disease_examination_id=1)
    assert (disease_link.disease_examination_id, disease_link.disease_code, disease_link.category) == (
        1,
        "d_diabetes",
        None,
    )
    assert disease_link.examination_code == exam.code
    checkup_link = system_checkup_examination("ENDO", exam.code, gender=GENDER_FEMALE, system_checkup_examination_id=1)
    assert (checkup_link.system_checkup_examination_id, checkup_link.system_code, checkup_link.gender) == (
        1,
        "ENDO",
        GENDER_FEMALE,
    )
    assert checkup_link.examination_code == exam.code


def test_every_catalog_table_has_a_dto_field_test():
    """Новая таблица в `_TABLE_SPECS` обязана появиться и в `test_dto_fields` — иначе этот тест падает."""
    covered = {
        BiomarkerDTO,
        BiomarkerParameterMappingDTO,
        ConditionDTO,
        DiseaseDTO,
        DiseaseExaminationDTO,
        DoctorDTO,
        ExaminationDTO,
        InstrumentDTO,
        InstrumentParameterDTO,
        OptionDTO,
        ParameterDTO,
        QuestionDTO,
        RecommendationDTO,
        RecommendedDoctorDTO,
        RiskFactorDTO,
        RiskFactorScoreDTO,
        RiskFactorSystemDTO,
        RiskFactorTriggerDTO,
        ScoreDTO,
        SystemCheckupExaminationDTO,
        SystemDTO,
        SystemInstrumentDTO,
    }
    assert {dto for _, dto, _ in _TABLE_SPECS} == covered


def test_dto_fields_match_selected_columns():
    """Строки маппятся как `dto(**row._mapping)` — имена колонок в select обязаны совпасть с полями DTO."""
    for name, dto, stmt in _TABLE_SPECS:
        selected = [c.name for c in stmt.selected_columns]
        assert set(selected) == {f.name for f in dataclasses.fields(dto)}, name


def test_get_returns_stored_tuple():
    cat = Catalog(tables=MappingProxyType({"instruments": (instrument("i1", instrument_id=1),)}))
    rows = cat.get("instruments")
    assert rows == (instrument("i1", instrument_id=1),)
    assert isinstance(rows, tuple)


def test_get_unknown_table_raises():
    cat = Catalog(tables=MappingProxyType({}))
    with pytest.raises(KeyError):
        cat.get("nope")  # ty: ignore[no-matching-overload]  # intentionally probes a non-table key


def test_catalog_load_error_is_domain_error():
    from src.exceptions import RiskBaseError

    assert issubclass(CatalogLoadError, RiskBaseError)


def test_second_active_clinrec_instrument_fails_catalog_load() -> None:
    """Инструмент типа `biomarker_kr` обязан быть один: на нём завязаны ключ строки и пометка `done`."""
    from src.infra.catalog.biomarkers import active_clinrec_instrument_codes

    instruments = (
        instrument("biomarker_kr", type="biomarker_kr", instrument_id=1),
        instrument("biomarker_kr_2", type="biomarker_kr", instrument_id=2),
    )
    with pytest.raises(CatalogLoadError, match="more than one active instrument"):
        active_clinrec_instrument_codes(instruments)


def test_inactive_second_clinrec_instrument_is_allowed() -> None:
    from src.infra.catalog.biomarkers import active_clinrec_instrument_codes

    instruments = (
        instrument("biomarker_kr", type="biomarker_kr", instrument_id=1),
        instrument("biomarker_kr_old", type="biomarker_kr", status="inactive", instrument_id=2),
    )
    assert active_clinrec_instrument_codes(instruments) == frozenset({"biomarker_kr"})


def test_instrument_dto_diseases_defaults_to_none() -> None:
    # diseases is nullable in the database, unlike the required identity and description fields.
    assert instrument("i1", instrument_id=1).diseases is None


def test_clinrec_dtos_are_frozen() -> None:
    """Справочник клинрек-расчёта резидентен: строка не должна правиться на горячем пути."""
    dis = disease("d_diabetes", "ENDO")
    with pytest.raises(dataclasses.FrozenInstanceError):
        dis.system_code = "CVD"  # ty: ignore[invalid-assignment]
    rfs = risk_factor_score("rf1", "d_diabetes")
    with pytest.raises(dataclasses.FrozenInstanceError):
        rfs.score = Decimal("1")  # ty: ignore[invalid-assignment]


def test_emr_biomarker_dtos_are_frozen() -> None:
    biomarker_row = biomarker(101, "biomarker_101")
    with pytest.raises(dataclasses.FrozenInstanceError):
        biomarker_row.type = "qualitative"  # ty: ignore[invalid-assignment]
    mapping_row = biomarker_mapping("biomarker_101", "target")
    with pytest.raises(dataclasses.FrozenInstanceError):
        mapping_row.mapping_type = "flag"  # ty: ignore[invalid-assignment]


def test_clinrec_dto_fields_are_required() -> None:
    """Ни одно поле клинрек-DTO не имеет дефолта: неполная строка справочника должна падать сразу."""
    for dto in (DiseaseDTO, RiskFactorScoreDTO):
        for field in dataclasses.fields(dto):
            assert field.default is dataclasses.MISSING, (dto, field.name)
            assert field.default_factory is dataclasses.MISSING, (dto, field.name)


def test_risk_factor_score_is_integer() -> None:
    """Балл — целое число: колонка справочника integer, и сравнение с порогом идёт по int."""
    assert isinstance(risk_factor_score("rf1", "d1", score=2).score, int)
    assert risk_factor_score("rf1", "d1", score=2).score != CLINREC_FACTOR_SCORE
