"""Бутстрап ролей обязан ходить драйвером с серверной подстановкой параметров.

Пароли рантаймов попадают в SQL связанными параметрами `set_config`. Свойство «пароль не
оказался в тексте запроса» держит драйвер, а не вызывающий код: psycopg2 подставляет значения
на клиенте, и на сервер уходит готовый литерал — видимый в `pg_stat_activity.query` и
попадающий в лог при `log_statement=all`.
"""

import secrets
from types import SimpleNamespace
from typing import Any, cast

import pytest
from pydantic import SecretStr
from sqlalchemy import Connection, create_engine

from src.infra import db_bootstrap
from src.infra.db_bootstrap import (
    EmptyRolePasswordError,
    RoleCredentials,
    UnknownLoginRoleError,
    UnsafeBootstrapDriverError,
    UnsupportedServerVersionError,
    bootstrap_logins,
    bootstrap_roles,
    bootstrap_roles_at_url,
)
from src.infra.db_schemas import BULK_RECALC_ROLE


def _credentials() -> RoleCredentials:
    return RoleCredentials(
        profile=SecretStr(secrets.token_urlsafe(8)),
        calculation=SecretStr(secrets.token_urlsafe(8)),
        ehr=SecretStr(secrets.token_urlsafe(8)),
        bulk_recalc=SecretStr(secrets.token_urlsafe(8)),
        migrations=SecretStr(secrets.token_urlsafe(8)),
    )


class _ConnectionOn:
    """Соединение, от которого нужен только диалект: проверка драйвера стоит до первого запроса."""

    def __init__(self, url: str) -> None:
        engine = create_engine(url)
        self.dialect = engine.dialect
        engine.dispose()


class _ConnectionReporting:
    """Соединение, отвечающее заданной версией сервера: проверка версии стоит до первой выдачи."""

    def __init__(self, server_version_num: int) -> None:
        engine = create_engine("postgresql+asyncpg://u:p@h:5432/d")
        self.dialect = engine.dialect
        engine.dispose()
        self._server_version_num = server_version_num

    def execute(self, *_args: Any, **_kwargs: Any) -> Any:
        return SimpleNamespace(scalar_one=lambda: self._server_version_num)


@pytest.mark.parametrize("url", ["postgresql+psycopg2://u:p@h:5432/d", "postgresql://u:p@h:5432/d"])
def test_bootstrap_refuses_a_client_side_parameter_driver(url: str) -> None:
    with pytest.raises(UnsafeBootstrapDriverError, match="psycopg2"):
        bootstrap_roles(cast(Connection, _ConnectionOn(url)), _credentials())


@pytest.mark.parametrize("server_version_num", [140000, 150000, 159999])
def test_bootstrap_refuses_a_server_without_membership_without_set_role(server_version_num: int) -> None:
    """До 16-й версии членство в прежнем владельце отдаёт миграциям `SET ROLE` в суперпользователя."""
    with pytest.raises(UnsupportedServerVersionError, match="SET FALSE"):
        bootstrap_roles(cast(Connection, _ConnectionReporting(server_version_num)), _credentials())


async def test_the_entry_point_opens_the_connection_on_asyncpg(monkeypatch: pytest.MonkeyPatch) -> None:
    """Драйвер админского URL не в счёт: оператор запишет любой, безопасный выбирает код."""
    seen: list[str] = []

    class _ConnectStartedError(Exception):
        """Сигнал «движок собран и пошёл соединяться»: дальше идти незачем, URL уже записан."""

    class _Engine:
        def begin(self) -> Any:
            raise _ConnectStartedError

        async def dispose(self) -> None:
            return None

    def _capture(url: Any) -> _Engine:
        seen.append(url.render_as_string(hide_password=False))
        return _Engine()

    monkeypatch.setattr(db_bootstrap, "create_async_engine", _capture)

    with pytest.raises(_ConnectStartedError):
        await bootstrap_roles_at_url("postgresql+psycopg2://postgres:secret@db:5432/riskdb", _credentials())

    assert seen == ["postgresql+asyncpg://postgres:secret@db:5432/riskdb"]


def test_login_bootstrap_refuses_a_client_side_parameter_driver() -> None:
    with pytest.raises(UnsafeBootstrapDriverError, match="psycopg2"):
        bootstrap_logins(
            cast(Connection, _ConnectionOn("postgresql+psycopg2://u:p@h:5432/d")),
            {BULK_RECALC_ROLE: SecretStr(secrets.token_urlsafe(8))},
        )


@pytest.mark.parametrize("logins", [{"postgres": "x"}, {}], ids=["foreign-role", "none"])
def test_login_bootstrap_refuses_roles_outside_the_isolation_set(logins: dict[str, str]) -> None:
    """Суперпользователю кластера этим путём пароль не сменить: имена ограничены ролями изоляции."""
    with pytest.raises(UnknownLoginRoleError):
        bootstrap_logins(
            cast(Connection, _ConnectionOn("postgresql+asyncpg://u:p@h:5432/d")),
            {role: SecretStr(password) for role, password in logins.items()},
        )


def test_login_bootstrap_refuses_an_empty_password() -> None:
    with pytest.raises(EmptyRolePasswordError, match=BULK_RECALC_ROLE):
        bootstrap_logins(
            cast(Connection, _ConnectionOn("postgresql+asyncpg://u:p@h:5432/d")), {BULK_RECALC_ROLE: SecretStr("")}
        )
