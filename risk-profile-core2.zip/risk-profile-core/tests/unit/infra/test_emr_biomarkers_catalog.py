from datetime import UTC, datetime
from decimal import Decimal

import pytest

from src.infra.catalog.base import CatalogLoadError
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from tests.catalog_builder import biomarker, biomarker_mapping, make_catalog, option, parameter


def test_entries_are_grouped_and_ordered_with_parameter_fields() -> None:
    earlier = parameter(
        "biomarker_earlier",
        status="inactive",
        validity_period=datetime(1970, 2, 1, tzinfo=UTC),
    )
    later = parameter("biomarker_later", validity_period=datetime(1970, 3, 1, tzinfo=UTC))
    catalog = EmrBiomarkersCatalog(
        make_catalog(
            parameters=(earlier, later),
            biomarkers=(
                biomarker(101, later.code, biomarker_id=20, unit_code=10),
                biomarker(101, earlier.code, biomarker_id=10, unit_code=169),
            ),
        )
    )

    entries = catalog.entries_by_biomarker_code[101]
    assert [entry.parameter_code for entry in entries] == [earlier.code, later.code]
    assert entries[0].parameter_status == "inactive"
    assert entries[0].validity_period == earlier.validity_period
    assert entries[1].unit_code == 10


def test_mappings_are_grouped_and_resolve_option_and_target_validity() -> None:
    source = parameter("biomarker_101")
    target = parameter("target", validity_period=datetime(1971, 1, 1, tzinfo=UTC))
    target_option = option("target_yes", question_code="Q", parameter_code=target.code, value="Да")
    catalog = EmrBiomarkersCatalog(
        make_catalog(
            parameters=(source, target),
            options=(target_option,),
            biomarker_parameter_mappings=(
                biomarker_mapping(
                    source.code,
                    target.code,
                    biomarker_parameter_mapping_id=20,
                    mapping_type="flag",
                    operator="gt",
                    value_num=Decimal("5.5"),
                    option_code=target_option.code,
                ),
            ),
        )
    )

    [mapping] = catalog.mappings_by_biomarker_parameter_code[source.code]
    assert mapping.parameter_code == target.code
    assert mapping.option_value == "Да"
    assert mapping.value_num == Decimal("5.5")
    assert mapping.validity_period == target.validity_period


def test_value_mapping_has_no_option_value() -> None:
    source = parameter("biomarker_101")
    target = parameter("target")
    catalog = EmrBiomarkersCatalog(
        make_catalog(
            parameters=(source, target),
            biomarker_parameter_mappings=(biomarker_mapping(source.code, target.code),),
        )
    )

    [mapping] = catalog.mappings_by_biomarker_parameter_code[source.code]
    assert mapping.mapping_type == "value"
    assert mapping.option_value is None


@pytest.mark.parametrize(
    ("catalog", "expected"),
    [
        (
            make_catalog(biomarkers=(biomarker(101, "missing", biomarker_id=11),)),
            "biomarker_id=11 parameter_code=missing",
        ),
        (
            make_catalog(
                parameters=(parameter("target"),),
                biomarker_parameter_mappings=(
                    biomarker_mapping("missing", "target", biomarker_parameter_mapping_id=12),
                ),
            ),
            "mapping_id=12 parameter_code=missing",
        ),
        (
            make_catalog(
                parameters=(parameter("source"),),
                biomarker_parameter_mappings=(
                    biomarker_mapping("source", "missing", biomarker_parameter_mapping_id=13),
                ),
            ),
            "mapping_id=13 parameter_code=missing",
        ),
        (
            make_catalog(
                parameters=(parameter("source"), parameter("target")),
                biomarker_parameter_mappings=(
                    biomarker_mapping(
                        "source",
                        "target",
                        biomarker_parameter_mapping_id=14,
                        mapping_type="flag",
                        operator="eq",
                        value_text="Обнаружен",
                        option_code="missing",
                    ),
                ),
            ),
            "mapping_id=14 option_code=missing",
        ),
    ],
)
def test_missing_references_fail_catalog_build(catalog: object, expected: str) -> None:
    with pytest.raises(CatalogLoadError, match=expected):
        EmrBiomarkersCatalog(catalog)  # ty: ignore[invalid-argument-type]
