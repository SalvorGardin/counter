"""Unit-тесты `ensure_topics`: per-topic число партиций и совместимость с голыми именами."""

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from aiokafka.errors import KafkaConnectionError, TopicAlreadyExistsError

from src.config import KafkaSettings
from src.infra.kafka.admin import TopicSpec, ensure_topics
from src.infra.kafka.exceptions import KafkaInitError
from tests.conftest import LogSink


def _settings() -> KafkaSettings:
    return KafkaSettings(enabled=True, bootstrap_servers="localhost:9092", security_protocol="PLAINTEXT")


async def test_creates_topics_with_per_topic_partition_counts() -> None:
    captured: dict[str, Any] = {}

    mock_admin = AsyncMock()
    mock_admin.list_topics = AsyncMock(return_value=set())

    async def _create(new_topics: list) -> None:
        captured["new_topics"] = new_topics

    mock_admin.create_topics = AsyncMock(side_effect=_create)

    with patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin):
        # Голое имя → 1 партиция (совместимость); TopicSpec → заданное число.
        await ensure_topics(_settings(), ["plain", TopicSpec("commands", num_partitions=6)])

    by_name = {t.name: t for t in captured["new_topics"]}
    assert by_name["plain"].num_partitions == 1
    assert by_name["commands"].num_partitions == 6


async def test_skips_already_existing_topics() -> None:
    mock_admin = AsyncMock()
    mock_admin.list_topics = AsyncMock(return_value={"commands"})
    mock_admin.create_topics = AsyncMock()

    with patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin):
        await ensure_topics(_settings(), [TopicSpec("commands", num_partitions=6)])

    mock_admin.create_topics.assert_not_called()


async def test_connect_failure_is_wrapped_and_client_is_not_left_open() -> None:
    """Брокер недоступен — наружу доменная ошибка с причиной в тексте.

    Тип ловит воркер провижининга и ретраит именно его; исходный KafkaError прошёл бы мимо ретраев
    и убил бы one-shot с первой попытки, хотя SASL-listener брокера штатно поднимается позже порта.
    """
    mock_admin = AsyncMock()
    mock_admin.start = AsyncMock(side_effect=KafkaConnectionError("connection refused"))

    with (
        patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin),
        pytest.raises(KafkaInitError, match="failed to connect kafka admin client"),
    ):
        await ensure_topics(_settings(), ["commands"])

    assert "connection refused" in str(mock_admin.start.side_effect)
    # Клиент не стартовал — закрывать нечего, close() в этой ветке не зовём.
    mock_admin.close.assert_not_called()


async def test_admin_client_is_closed_even_when_listing_fails() -> None:
    """Сбой уже после старта не должен оставить открытый admin-клиент.

    Провижининг запускается по одному разу на деплой, но воркер ретраит его до шести раз — утёкший
    клиент на каждой попытке держал бы соединение с брокером до конца жизни процесса.
    """
    mock_admin = AsyncMock()
    mock_admin.list_topics = AsyncMock(side_effect=KafkaConnectionError("metadata timeout"))

    with (
        patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin),
        pytest.raises(KafkaConnectionError),
    ):
        await ensure_topics(_settings(), ["commands"])

    mock_admin.close.assert_awaited_once()


async def test_concurrent_create_race_is_not_an_error() -> None:
    """Топик создал сосед между list_topics и create_topics — это успех, а не сбой.

    Провижининг запускается одновременно во всех инстансах воркера, и гонка тут штатна: результат
    один и тот же — топик существует.
    """
    mock_admin = AsyncMock()
    mock_admin.list_topics = AsyncMock(return_value=set())
    mock_admin.create_topics = AsyncMock(side_effect=TopicAlreadyExistsError("commands"))

    with patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin):
        await ensure_topics(_settings(), ["commands"])

    mock_admin.close.assert_awaited_once()


async def test_create_failure_is_wrapped_and_logged(captured_app_logs: LogSink) -> None:
    """Отказ создания (нет прав на CreateTopics) — доменная ошибка и запись со стектрейсом.

    Названия топиков обязаны быть в контексте: без них на стенде видно только «провижининг упал»,
    и разбор начинается с угадывания, какому именно топику не хватило ACL.
    """
    mock_admin = AsyncMock()
    mock_admin.list_topics = AsyncMock(return_value=set())
    mock_admin.create_topics = AsyncMock(side_effect=KafkaConnectionError("not authorized"))

    with (
        patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin),
        pytest.raises(KafkaInitError, match="failed to create topics"),
    ):
        await ensure_topics(_settings(), ["commands", TopicSpec("results")])

    assert captured_app_logs.context_of("kafka.topics create failed")["topics"] == ["commands", "results"]
    mock_admin.close.assert_awaited_once()
