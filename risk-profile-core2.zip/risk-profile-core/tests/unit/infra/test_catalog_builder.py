"""Тесты `src/infra/catalog/builder.py`: единая точка создания каталогов.

Контракт, ради которого модуль появился: `catalog_builder` собирает базовый каталог и обе
доменные проекции ЗА ОДИН проход и сам замораживает стартовый heap — точки входа больше не зовут
`freeze_startup_heap` руками. `build_catalogs` делает то же без заморозки (одноразовые каталоги
в `run_recalc`): заморозка навсегда, замораживать per-command каталог нельзя.

Загрузку из БД подменяем: здесь проверяется композиция шагов, а не SQL (это покрыто
`test_catalog_base.py`). Базовый каталог берём из фикстуры calc-тестов, дополняя его пустыми
interpretation- и EMR-таблицами — минимальный набор, на котором строятся все проекции.
"""

import gc
from contextlib import asynccontextmanager
from types import MappingProxyType, SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock

import pytest

from src.infra.catalog.base import Catalog
from src.infra.catalog.builder import build_catalogs, catalog_builder
from src.infra.catalog.calc import CalcCatalog
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from src.infra.catalog.interpretation import InterpretationCatalog
from tests.unit.infra.test_calc_catalog import _catalog


def _base_catalog() -> Catalog:
    tables: dict[str, tuple[object, ...]] = dict(_catalog().tables)
    tables["recommended_doctors"] = ()
    tables["risk_factors"] = ()
    tables["risk_factor_systems"] = ()
    tables["risk_factor_triggers"] = ()
    return Catalog(tables=MappingProxyType(tables))


@pytest.fixture(autouse=True)
def _stub_load_catalog(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("src.infra.catalog.builder.load_catalog", AsyncMock(return_value=_base_catalog()))
    monkeypatch.setattr("src.infra.catalog.builder.HttpCatalog", lambda catalog: object())


class _Engine:
    def __init__(self, on_dispose: Any = None) -> None:
        self._on_dispose = on_dispose

    async def dispose(self) -> None:
        if self._on_dispose is not None:
            self._on_dispose()


def _install_runtime(monkeypatch: pytest.MonkeyPatch, session_factory: Any, engine: Any = None) -> None:
    """Подменяет основной рантайм процесса целиком: `AsyncEngine.dispose` — read-only атрибут,
    точечно его не заменить."""
    runtime = SimpleNamespace(session_factory=session_factory, engine=engine or _Engine())
    monkeypatch.setattr("src.infra.catalog.builder.get_primary_runtime", lambda: runtime)


@asynccontextmanager
async def _session_factory() -> Any:
    yield object()


@pytest.fixture
def _stub_session_factory(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_runtime(monkeypatch, _session_factory)


async def test_build_catalogs_returns_all_projections() -> None:
    catalogs = await build_catalogs(object())  # ty: ignore[invalid-argument-type]

    assert isinstance(catalogs.calc, CalcCatalog)
    assert isinstance(catalogs.interpretation, InterpretationCatalog)
    assert isinstance(catalogs.emr_biomarkers, EmrBiomarkersCatalog)


async def test_build_catalogs_does_not_freeze_heap() -> None:
    """Одноразовые каталоги не замораживаем: заморозка навсегда, а такой каталог живёт одну команду."""
    gc.unfreeze()
    try:
        before = gc.get_freeze_count()
        await build_catalogs(object())  # ty: ignore[invalid-argument-type]
        assert gc.get_freeze_count() == before
    finally:
        gc.unfreeze()


@pytest.mark.usefixtures("_stub_session_factory")
async def test_catalog_builder_builds_and_freezes_in_one_pass() -> None:
    """Резидентные каталоги: открыть сессию → собрать проекции → заморозить стартовый heap."""
    gc.unfreeze()
    try:
        resident = [{"catalog_row": i} for i in range(100)]
        before = gc.get_freeze_count()

        catalogs = await catalog_builder()

        assert isinstance(catalogs.calc, CalcCatalog)
        assert isinstance(catalogs.interpretation, InterpretationCatalog)
        assert isinstance(catalogs.emr_biomarkers, EmrBiomarkersCatalog)
        assert gc.get_freeze_count() > before
        assert resident  # держим ссылку живой до конца теста
    finally:
        gc.unfreeze()


async def test_catalog_builder_disposes_pool_before_freezing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Пул БД возвращается в исходное состояние ДО заморозки: стартовые соединения — первый и
    единственный на этот момент пользователь пула, а `pool_pre_ping` со временем заменяет их на
    новые, и в permanent generation им не место."""
    order: list[str] = []

    _install_runtime(monkeypatch, _session_factory, _Engine(on_dispose=lambda: order.append("dispose")))
    monkeypatch.setattr("src.infra.catalog.builder.freeze_startup_heap", lambda: order.append("freeze"))

    await catalog_builder()

    assert order == ["dispose", "freeze"]


async def test_catalog_builder_closes_its_session() -> None:
    """Сессия сборки — своя и закрывается до возврата: резидентный каталог не держит коннект."""
    closed = False

    @asynccontextmanager
    async def _factory() -> Any:
        nonlocal closed
        try:
            yield object()
        finally:
            closed = True

    with pytest.MonkeyPatch.context() as mp:
        _install_runtime(mp, _factory)
        gc.unfreeze()
        try:
            await catalog_builder()
        finally:
            gc.unfreeze()

    assert closed
