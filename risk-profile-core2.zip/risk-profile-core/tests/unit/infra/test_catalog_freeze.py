"""Тесты `freeze_startup_heap`: перевод стартового heap'а (в т.ч. каталога) в permanent generation.

Зачем это вообще: резидентный каталог — ~117k отслеживаемых GC объектов, которые gen2-сборка
обходит на каждом проходе впустую (каталог неизменяем и живёт весь процесс). Замер в playground
показал stop-the-world паузы ~45мс на gen2, ложащиеся ровно на хвостовые команды (p99 122.9 → 78.5,
max 138.1 → 92.8 после freeze). См. DATABASE_MAX_TIME_SPIKE.CLAUDE.md §0.
"""

import gc

from src.infra.catalog.base import freeze_startup_heap


def test_freeze_startup_heap_moves_live_objects_into_permanent_generation() -> None:
    """Живой объект, созданный до вызова, после freeze уходит в permanent generation.

    Проверяем именно наблюдаемый эффект (рост `gc.get_freeze_count()`), а не факт вызова:
    смысл фикса в том, что gen2 перестаёт обходить эти объекты.
    """
    gc.unfreeze()
    resident = [{"catalog_row": i} for i in range(100)]
    before = gc.get_freeze_count()

    try:
        freeze_startup_heap()
        assert gc.get_freeze_count() > before
    finally:
        gc.unfreeze()

    assert resident  # держим ссылку живой до конца теста


def test_freeze_startup_heap_is_idempotent() -> None:
    """Повторный вызов не падает и не разфризивает уже замороженное (стартовые пути не координируются)."""
    gc.unfreeze()
    try:
        freeze_startup_heap()
        first = gc.get_freeze_count()
        freeze_startup_heap()
        assert gc.get_freeze_count() >= first
    finally:
        gc.unfreeze()
