"""Unit-тесты для KafkaProducer: сериализация, заголовки трассировки, обработка ошибок."""

import asyncio
import json
from collections.abc import Callable
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from aiokafka.errors import KafkaConnectionError
from pydantic import SecretStr

from src.config import KafkaSettings
from src.infra.kafka import producer as producer_module
from src.infra.kafka.exceptions import KafkaInitError, KafkaPublishError
from src.infra.kafka.producer import KafkaProducer, _aiokafka_security_kwargs, _build_ssl_context
from src.logger import request_id_var, x_enable_debug_var


def _make_settings(max_pending_publishes: int = 256) -> KafkaSettings:
    # PLAINTEXT — чтобы start() не пытался прогрузить cert-файлы; SSL-логика покрыта своими тестами.
    return KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="PLAINTEXT",
        client_id="test-client",
        max_pending_publishes=max_pending_publishes,
    )


class _FakeAIOKafkaProducer:
    """Заменяет aiokafka.AIOKafkaProducer — фиксирует вызовы start/stop/send_and_wait."""

    def __init__(
        self,
        *,
        value_serializer: Callable[[Any], bytes],
        key_serializer: Callable[[Any], bytes | None],
        **_kwargs: Any,
    ) -> None:
        self._value_serializer = value_serializer
        self._key_serializer = key_serializer
        self.started = False
        self.stopped = False
        self.sent: list[dict[str, Any]] = []
        self.fail_with: BaseException | None = None
        # Задержка публикации: тесты дренажа держат отправку незавершённой, пока не отпустят событие.
        self.gate: asyncio.Event | None = None

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def send_and_wait(
        self,
        topic: str,
        value: Any,
        key: Any = None,
        headers: list[tuple[str, bytes]] | None = None,
    ) -> None:
        if self.gate is not None:
            await self.gate.wait()
        if self.fail_with is not None:
            raise self.fail_with
        # aiokafka сам прогоняет value/key через serializer'ы — повторяем это в фейке.
        self.sent.append(
            {
                "topic": topic,
                "value": self._value_serializer(value),
                "key": self._key_serializer(key),
                "headers": list(headers or []),
            }
        )


@pytest.fixture
def fake_kafka(monkeypatch: pytest.MonkeyPatch) -> dict[str, _FakeAIOKafkaProducer]:
    """Внедряет фейк вместо AIOKafkaProducer и возвращает контейнер с инстансом."""
    holder: dict[str, _FakeAIOKafkaProducer] = {}

    def _factory(**kwargs: Any) -> _FakeAIOKafkaProducer:
        instance = _FakeAIOKafkaProducer(**kwargs)
        holder["instance"] = instance
        return instance

    monkeypatch.setattr(producer_module, "AIOKafkaProducer", _factory)
    return holder


async def test_send_serializes_value_to_json_and_injects_request_id(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]
    assert fake.started

    token = request_id_var.set("req-42")
    try:
        await p.send("test.topic", value={"hello": "мир"}, key="k1")
    finally:
        request_id_var.reset(token)

    assert len(fake.sent) == 1
    sent = fake.sent[0]
    assert sent["topic"] == "test.topic"
    assert json.loads(sent["value"].decode("utf-8")) == {"hello": "мир"}
    assert sent["key"] == b"k1"
    headers = dict(sent["headers"])
    assert headers["x-request-id"] == b"req-42"


async def test_send_merges_custom_headers(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]

    await p.send("t", value={"a": 1}, headers={"x-custom": "v1"})

    headers = dict(fake.sent[0]["headers"])
    assert headers["x-custom"] == b"v1"
    assert "x-request-id" in headers


async def test_send_propagates_x_enable_debug_header(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Спека стр. 7: X-Enable-Debug пробрасывается в downstream аналогично X-Request-ID."""
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]

    debug_tok = x_enable_debug_var.set("true")
    try:
        await p.send("t", value={"a": 1})
    finally:
        x_enable_debug_var.reset(debug_tok)

    headers = dict(fake.sent[0]["headers"])
    assert headers["x-enable-debug"] == b"true"
    # И x-request-id всё ещё там — regress.
    assert "x-request-id" in headers


async def test_send_omits_x_enable_debug_when_unset(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Пустое значение X-Enable-Debug (default) НЕ добавляется — иначе случайно включим debug в downstream."""
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]

    # x_enable_debug_var по умолчанию = "" (см. src/logger.py).
    await p.send("t", value={"a": 1})

    headers = dict(fake.sent[0]["headers"])
    assert "x-enable-debug" not in headers
    assert "x-request-id" in headers


async def test_send_x_enable_debug_does_not_override_custom_headers(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    """Явный headers={"x-enable-debug": ...} от вызывающего имеет приоритет над contextvar."""
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]

    debug_tok = x_enable_debug_var.set("true")
    try:
        await p.send("t", value={"a": 1}, headers={"x-enable-debug": "false"})
    finally:
        x_enable_debug_var.reset(debug_tok)

    headers = dict(fake.sent[0]["headers"])
    assert headers["x-enable-debug"] == b"false"


async def test_send_without_start_raises_init_error() -> None:
    p = KafkaProducer(_make_settings())
    with pytest.raises(KafkaInitError):
        await p.send("t", value={})


async def test_send_wraps_kafka_error(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]
    fake.fail_with = KafkaConnectionError("boom")

    with pytest.raises(KafkaPublishError) as exc:
        await p.send("t", value={"x": 1})
    assert exc.value.topic == "t"
    assert isinstance(exc.value.cause, KafkaConnectionError)


async def test_stop_is_idempotent(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    await p.stop()
    assert fake_kafka["instance"].stopped
    # повторный stop без падения
    await p.stop()


async def test_init_kafka_producer_noop_when_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    started = AsyncMock()
    monkeypatch.setattr(producer_module, "AIOKafkaProducer", started)
    monkeypatch.setattr(producer_module.settings.kafka, "enabled", False)

    await producer_module.init_kafka_producer()

    started.assert_not_called()
    with pytest.raises(KafkaInitError):
        producer_module.get_kafka_producer()


async def test_send_emits_business_log_only_on_success(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    """Канал "business" пишется только после успешного send_and_wait, не на ошибке.

    Регресс-страховка: если кто-то переставит вызов business() выше try или в except —
    тест сломается. Без этого теста ошибочный publish мог бы попасть в Kibana как успех."""
    from unittest.mock import patch as mock_patch  # noqa: PLC0415

    import src.infra.kafka.producer as prod_mod  # noqa: PLC0415

    p = KafkaProducer(_make_settings())
    await p.start()

    # 1) Успех — business вызван ровно 1 раз с topic/key в context.
    with mock_patch.object(prod_mod, "business") as mock_business:
        await p.send("my.topic", value={"a": 1}, key="k1")
    mock_business.assert_called_once()
    args, kwargs = mock_business.call_args
    assert args[0] == "kafka.publish succeeded"
    assert kwargs["context"] == {"topic": "my.topic"}

    # 2) Ошибка — business НЕ вызывается.
    fake_kafka["instance"].fail_with = KafkaConnectionError("boom")
    with mock_patch.object(prod_mod, "business") as mock_business:
        with pytest.raises(KafkaPublishError):
            await p.send("my.topic", value={"a": 1}, key="k1")
    mock_business.assert_not_called()


async def test_send_wraps_buffer_error(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    fake_kafka["instance"].fail_with = BufferError("internal buffer full")

    with pytest.raises(KafkaPublishError) as exc:
        await p.send("t", value={"x": 1})
    assert exc.value.topic == "t"
    assert isinstance(exc.value.cause, BufferError)


async def test_send_background_delivers_message(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()

    p.send_background(topic="t", value={"a": 1}, key="k")

    assert len(p._pending) == 1
    await asyncio.gather(*list(p._pending), return_exceptions=True)
    assert fake_kafka["instance"].sent[0]["topic"] == "t"


async def test_send_background_propagates_x_enable_debug(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    """send_background через asyncio.create_task сохраняет ContextVar-снапшот — x-enable-debug должен дойти.

    Регресс-страховка: если кто-то заменит create_task на run_in_executor / threadpool, ContextVar
    перестанет копироваться и хедер пропадёт молча. (Контекст: ревью MR-D, criterion testing.md.)"""
    p = KafkaProducer(_make_settings())
    await p.start()

    debug_tok = x_enable_debug_var.set("true")
    try:
        p.send_background(topic="t", value={"a": 1}, key="k")
        await asyncio.gather(*list(p._pending), return_exceptions=True)
    finally:
        x_enable_debug_var.reset(debug_tok)

    headers = dict(fake_kafka["instance"].sent[0]["headers"])
    assert headers["x-enable-debug"] == b"true"
    assert "x-request-id" in headers


async def test_send_background_removes_task_from_pending_after_completion(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()

    p.send_background(topic="t", value={}, key="k")
    await asyncio.gather(*list(p._pending), return_exceptions=True)

    assert len(p._pending) == 0


async def test_send_background_queue_full_skips_and_logs_error(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    from unittest.mock import patch as mock_patch

    import src.infra.kafka.producer as prod_mod

    p = KafkaProducer(_make_settings(max_pending_publishes=0))
    await p.start()

    with mock_patch.object(prod_mod.logger, "error") as mock_error:
        p.send_background(topic="t", value={}, key="k")

    assert len(p._pending) == 0
    assert len(fake_kafka["instance"].sent) == 0
    mock_error.assert_called_once()
    assert "kafka.background: queue full" in mock_error.call_args.args[0]


async def test_send_background_swallows_publish_error_silently(
    fake_kafka: dict[str, _FakeAIOKafkaProducer],
) -> None:
    p = KafkaProducer(_make_settings())
    await p.start()
    fake_kafka["instance"].fail_with = KafkaConnectionError("boom")

    p.send_background(topic="t", value={}, key="k")
    # should not raise even though send() will raise KafkaPublishError
    await asyncio.gather(*list(p._pending), return_exceptions=True)
    assert fake_kafka["instance"].sent == []


def test_security_kwargs_sasl_plaintext_passes_sasl_fields() -> None:
    """SASL_PLAINTEXT: SASL-поля прокидываются в aiokafka, ssl_context не нужен."""
    settings = KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="SASL_PLAINTEXT",
        sasl_mechanism="SCRAM-SHA-512",
        sasl_username="risk-app",
        sasl_password=SecretStr("s3cret"),
    )

    kwargs = _aiokafka_security_kwargs(settings)

    assert kwargs == {
        "security_protocol": "SASL_PLAINTEXT",
        "ssl_context": None,
        "sasl_mechanism": "SCRAM-SHA-512",
        "sasl_plain_username": "risk-app",
        "sasl_plain_password": "s3cret",
    }


def test_security_kwargs_sasl_ssl_combines_ssl_context_and_sasl(monkeypatch: pytest.MonkeyPatch) -> None:
    """SASL_SSL — прод-путь: aiokafka получает ssl_context (только CA, без client-cert) И SASL-поля."""
    fake_ctx = MagicMock()
    monkeypatch.setattr(producer_module.ssl, "create_default_context", lambda cafile: fake_ctx)

    settings = KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="SASL_SSL",
        ssl_cafile="/fake/ca.crt",
        sasl_mechanism="SCRAM-SHA-512",
        sasl_username="risk-app",
        sasl_password=SecretStr("s3cret"),
    )

    kwargs = _aiokafka_security_kwargs(settings)

    assert kwargs["security_protocol"] == "SASL_SSL"
    assert kwargs["ssl_context"] is fake_ctx
    assert kwargs["sasl_mechanism"] == "SCRAM-SHA-512"
    assert kwargs["sasl_plain_username"] == "risk-app"
    assert kwargs["sasl_plain_password"] == "s3cret"
    # SASL_SSL не использует mTLS — клиентский сертификат не подгружается.
    fake_ctx.load_cert_chain.assert_not_called()


def test_build_ssl_context_ssl_without_client_cert_skips_load_cert_chain(monkeypatch: pytest.MonkeyPatch) -> None:
    """SSL с пустыми ssl_certfile/keyfile — context собирается (CA-only), load_cert_chain не вызывается."""
    fake_ctx = MagicMock()
    monkeypatch.setattr(producer_module.ssl, "create_default_context", lambda cafile: fake_ctx)

    settings = KafkaSettings(
        enabled=False,  # обход model-валидатора, который требует cert/key при enabled=True + SSL
        security_protocol="SSL",
        ssl_cafile="/fake/ca.crt",
    )

    ctx = _build_ssl_context(settings)

    assert ctx is fake_ctx
    fake_ctx.load_cert_chain.assert_not_called()


def test_build_ssl_context_empty_cafile_uses_system_trust_store(monkeypatch: pytest.MonkeyPatch) -> None:
    """Пустой ssl_cafile → cafile=None в create_default_context (системный truststore)."""
    captured: dict[str, Any] = {}
    fake_ctx = MagicMock()

    def fake_create_default_context(cafile: Any = None) -> MagicMock:
        captured["cafile"] = cafile
        return fake_ctx

    monkeypatch.setattr(producer_module.ssl, "create_default_context", fake_create_default_context)

    settings = KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="SASL_SSL",
        ssl_cafile="",  # ← публичный/системный CA, явный путь не нужен
        sasl_username="risk-app",
        sasl_password=SecretStr("s3cret"),
    )

    ctx = _build_ssl_context(settings)

    assert ctx is fake_ctx
    assert captured["cafile"] is None  # передаём None, а не "" — иначе ssl падает с ENOENT


def test_security_kwargs_plaintext_omits_sasl() -> None:
    """PLAINTEXT: SASL-поля не прокидываются в kwargs aiokafka."""
    settings = KafkaSettings(enabled=False, security_protocol="PLAINTEXT")
    kwargs = _aiokafka_security_kwargs(settings)
    assert kwargs == {"security_protocol": "PLAINTEXT", "ssl_context": None}


def test_sasl_password_rejects_comma() -> None:
    """Запятая в sasl_password ломает CSV-bootstrap bitnami — конструкция настроек должна падать."""
    from pydantic import ValidationError  # noqa: PLC0415

    with pytest.raises(ValidationError, match="comma breaks broker CSV bootstrap"):
        KafkaSettings(
            enabled=True,
            bootstrap_servers="kafka:9093",
            security_protocol="SASL_SSL",
            ssl_cafile="/fake/ca.crt",
            sasl_username="risk-app",
            sasl_password=SecretStr("bad,password"),
        )


def test_sasl_mechanism_validated_only_for_sasl_protocols() -> None:
    """SASL_MECHANISM не валидируется, если SASL не используется — stale env не должен ронять старт."""
    # PLAINTEXT: некорректное значение sasl_mechanism принимается (поле игнорируется).
    s = KafkaSettings(security_protocol="PLAINTEXT", sasl_mechanism="GSSAPI")
    assert s.sasl_mechanism == "GSSAPI"

    # SASL_SSL: то же значение валится.
    from pydantic import ValidationError  # noqa: PLC0415

    with pytest.raises(ValidationError, match="sasl_mechanism must be one of"):
        KafkaSettings(security_protocol="SASL_SSL", sasl_mechanism="GSSAPI")


# --- Дренаж фоновых публикаций при остановке ---


async def test_stop_waits_for_pending_publish_to_finish(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Незавершённая фоновая публикация досылается до закрытия продюсера.

    Это и есть цена редеплоя: без ожидания результат уже посчитанного расчёта не уехал бы
    в топик, а клиент увидел бы пропуск без единой ошибки в логах.
    """
    from unittest.mock import patch as mock_patch  # noqa: PLC0415

    import src.infra.kafka.producer as prod_mod  # noqa: PLC0415

    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]
    fake.gate = asyncio.Event()
    p.send_background(topic="t", value={"a": 1}, key="k")
    await asyncio.sleep(0)  # даём задаче дойти до send_and_wait и остановиться на воротах
    assert len(p._pending) == 1

    with mock_patch.object(prod_mod, "notice") as mock_notice:
        stop = asyncio.ensure_future(p.stop(drain_timeout=5))
        await asyncio.sleep(0)
        assert not stop.done(), "stop закрыл продюсер, не дождавшись фоновой публикации"
        fake.gate.set()
        await stop

    assert fake.sent[0]["topic"] == "t"
    assert fake.stopped
    drain_messages = [call.args[0] for call in mock_notice.call_args_list]
    assert "kafka.producer: draining background tasks before shutdown" in drain_messages


async def test_stop_alerts_when_drain_times_out(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Публикация не уложилась в бюджет дренажа: alert и всё равно закрываемся.

    Зависнуть на остановке нельзя — процесс дожал бы SIGKILL, — поэтому единственный контракт
    здесь «сообщить о потере и не задерживать shutdown».
    """
    from unittest.mock import patch as mock_patch  # noqa: PLC0415

    import src.infra.kafka.producer as prod_mod  # noqa: PLC0415

    p = KafkaProducer(_make_settings())
    await p.start()
    fake = fake_kafka["instance"]
    fake.gate = asyncio.Event()
    p.send_background(topic="t", value={"a": 1}, key="k")
    await asyncio.sleep(0)
    hanging = next(iter(p._pending))

    with mock_patch.object(prod_mod, "alert") as mock_alert:
        await p.stop(drain_timeout=0.01)

    assert fake.stopped, "продюсер должен закрыться даже после неудачного дренажа"
    assert fake.sent == []
    mock_alert.assert_called_once()
    assert "drain timed out" in mock_alert.call_args.args[0]
    assert mock_alert.call_args.args[1]["timeout_s"] == 0.01

    fake.gate.set()
    await asyncio.gather(hanging, return_exceptions=True)


async def test_stop_without_pending_does_not_drain(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Пустая очередь — без уведомления о дренаже: в штатном редеплое лог не шумит."""
    from unittest.mock import patch as mock_patch  # noqa: PLC0415

    import src.infra.kafka.producer as prod_mod  # noqa: PLC0415

    p = KafkaProducer(_make_settings())
    await p.start()

    with mock_patch.object(prod_mod, "notice") as mock_notice:
        await p.stop(drain_timeout=5)

    messages = [call.args[0] for call in mock_notice.call_args_list]
    assert "kafka.producer: draining background tasks before shutdown" not in messages
    assert "kafka.producer stopped" in messages


async def test_start_is_idempotent(fake_kafka: dict[str, _FakeAIOKafkaProducer]) -> None:
    """Повторный start() не поднимает второго клиента: иначе первый утёк бы вместе с его сокетами."""
    p = KafkaProducer(_make_settings())
    await p.start()
    first = fake_kafka["instance"]

    await p.start()

    assert fake_kafka["instance"] is first


async def test_start_wraps_broker_failure_into_init_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Брокер недоступен на старте — наружу уходит доменная ошибка с текстом причины.

    Тип важен: старт приложения и воркеров ловит именно KafkaInitError, а исходный KafkaError
    из aiokafka прошёл бы мимо и упал бы необработанным.
    """

    def _factory(**_kwargs: Any) -> Any:
        instance = MagicMock()
        instance.start = AsyncMock(side_effect=KafkaConnectionError("no route to broker"))
        return instance

    monkeypatch.setattr(producer_module, "AIOKafkaProducer", _factory)

    with pytest.raises(KafkaInitError, match="failed to start kafka producer") as exc_info:
        await KafkaProducer(_make_settings()).start()

    assert "no route to broker" in str(exc_info.value)
    assert isinstance(exc_info.value.__cause__, KafkaConnectionError)


async def test_global_producer_lifecycle(
    fake_kafka: dict[str, _FakeAIOKafkaProducer], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Полный цикл модульного продюсера: init → get → shutdown → снова недоступен.

    `get_kafka_producer` — FastAPI-зависимость роутов публикации, поэтому её ответ после init и
    после shutdown должен различаться: продюсер, переживший shutdown, слал бы в закрытый клиент.
    """
    monkeypatch.setattr(producer_module.settings.kafka, "enabled", True)
    monkeypatch.setattr(producer_module, "_producer", None)

    await producer_module.init_kafka_producer()

    produced = producer_module.get_kafka_producer()
    assert isinstance(produced, KafkaProducer)
    assert fake_kafka["instance"].started is True

    await producer_module.shutdown_kafka_producer()

    assert fake_kafka["instance"].stopped is True
    with pytest.raises(KafkaInitError, match="RISK_MODEL_KAFKA__ENABLED"):
        producer_module.get_kafka_producer()


async def test_shutdown_without_init_is_noop(monkeypatch: pytest.MonkeyPatch) -> None:
    """Kafka выключена — teardown приложения всё равно зовёт shutdown, и он обязан пройти молча."""
    monkeypatch.setattr(producer_module, "_producer", None)

    await producer_module.shutdown_kafka_producer(drain_timeout=1.0)


def test_build_ssl_context_loads_client_cert_chain_with_password(monkeypatch: pytest.MonkeyPatch) -> None:
    """mTLS: cert+key заданы — цепочка грузится, пароль ключа достаётся из SecretStr.

    Пароль обязан уходить в ssl раскрытым значением, а не объектом SecretStr: последний
    load_cert_chain принял бы как есть и упал бы уже внутри OpenSSL, без внятной причины.
    """
    fake_ctx = MagicMock()
    monkeypatch.setattr(producer_module.ssl, "create_default_context", lambda cafile: fake_ctx)

    _build_ssl_context(
        KafkaSettings(
            enabled=True,
            bootstrap_servers="kafka:9093",
            security_protocol="SSL",
            ssl_certfile="/certs/client.crt",
            ssl_keyfile="/certs/client.key",
            ssl_password=SecretStr("key-passphrase"),
        )
    )

    fake_ctx.load_cert_chain.assert_called_once_with(
        certfile="/certs/client.crt",
        keyfile="/certs/client.key",
        password="key-passphrase",
    )
