from src.infra.catalog.biomarkers import (
    active_required_parameter_codes_by_instrument,
    biomarker_code_by_parameter,
    competing_biomarker_parameter_codes,
)
from src.infra.catalog.calc import CalcCatalog
from src.infra.catalog.interpretation import InterpretationCatalog
from tests.catalog_builder import (
    biomarker,
    biomarker_mapping,
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    question,
)


def test_parameter_biomarker_codes_follow_direct_and_value_mappings() -> None:
    rows = [biomarker(10, "biomarker_a"), biomarker(20, "biomarker_b")]
    mappings = [
        biomarker_mapping("biomarker_b", "biomarker_a"),
        biomarker_mapping("biomarker_a", "single_target"),
        biomarker_mapping("biomarker_a", "repeated_target", operator="gt"),
        biomarker_mapping("biomarker_a", "repeated_target", operator="lt"),
        biomarker_mapping("biomarker_a", "ambiguous_target"),
        biomarker_mapping("biomarker_b", "ambiguous_target"),
        biomarker_mapping("biomarker_a", "flag_target", mapping_type="flag"),
        biomarker_mapping("biomarker_a", "value_target"),
        biomarker_mapping("biomarker_a", "second_flag_target", mapping_type="flag"),
    ]

    result = biomarker_code_by_parameter(rows, mappings)

    assert result == {
        "biomarker_a": 10,
        "biomarker_b": 20,
        "single_target": 10,
        "repeated_target": 10,
        "value_target": 10,
    }
    assert "ambiguous_target" not in result
    assert "flag_target" not in result
    assert "second_flag_target" not in result
    assert "outside_catalog" not in result


def test_value_mapping_source_outside_biomarkers_is_ignored() -> None:
    result = biomarker_code_by_parameter(
        [biomarker(10, "biomarker_a")],
        [
            biomarker_mapping("biomarker_a", "target"),
            biomarker_mapping("missing_biomarker", "target"),
            biomarker_mapping("missing_biomarker", "orphan_target"),
        ],
    )

    assert result["target"] == 10
    assert "orphan_target" not in result


def test_competing_parameters_have_a_shared_defined_biomarker_code() -> None:
    code_by_parameter = biomarker_code_by_parameter(
        [biomarker(10, "biomarker_a"), biomarker(20, "biomarker_b")],
        [biomarker_mapping("biomarker_a", "same_a"), biomarker_mapping("biomarker_a", "same_b")],
    )

    assert competing_biomarker_parameter_codes(code_by_parameter) == frozenset({"biomarker_a", "same_a", "same_b"})


def test_required_parameters_are_indexed_per_active_instrument() -> None:
    """Индекс обязательных параметров: только активные инструменты и только обязательные связи."""
    ips = [
        instrument_parameter("form_a", "required_p", is_required=True),
        instrument_parameter("form_a", "optional_p"),
        # Тот же параметр, но связь с другим инструментом необязательная.
        instrument_parameter("form_b", "required_p"),
        instrument_parameter("old_a", "required_p", is_required=True),
    ]

    result = active_required_parameter_codes_by_instrument(ips, {"form_a", "form_b"})

    assert result == {"form_a": frozenset({"required_p"})}


def test_calc_and_interpretation_catalogs_share_biomarker_views() -> None:
    base = make_catalog(
        biomarkers=[biomarker(10, "biomarker_a")],
        biomarker_parameter_mappings=[biomarker_mapping("biomarker_a", "normalized_a")],
        instruments=[instrument("form_a", instrument_id=1), instrument("old_a", status="inactive", instrument_id=2)],
        instruments_parameters=[
            instrument_parameter("form_a", "biomarker_a", is_required=True),
            instrument_parameter("form_a", "normalized_a"),
            instrument_parameter("old_a", "biomarker_a", is_required=True),
        ],
        questions=[question("BDI1")],
        options=[option("BDI1_01", question_code="BDI1", parameter_code="bdi1", value="answer")],
    )

    calc = CalcCatalog(base)
    interpretation = InterpretationCatalog(base)

    expected_codes = {"biomarker_a": 10, "normalized_a": 10}
    expected_competing = frozenset(expected_codes)
    expected_required = {"form_a": frozenset({"biomarker_a"})}
    assert calc.biomarker_code_by_parameter == expected_codes
    assert interpretation.biomarker_code_by_parameter == expected_codes
    assert calc.competing_biomarker_parameter_codes == expected_competing
    assert interpretation.competing_biomarker_parameter_codes == expected_competing
    assert calc.required_parameter_codes_by_instrument == expected_required
    assert interpretation.required_parameter_codes_by_instrument == expected_required
