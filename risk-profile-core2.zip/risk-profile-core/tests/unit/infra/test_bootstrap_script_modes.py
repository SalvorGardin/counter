"""Режимы `scripts/bootstrap_db_roles.py`: выдача ролей и их снятие — разные ветки одного входа.

Проверяется именно разводка по режимам: перепутать их значит либо снять роли вместо ротации
паролей, либо молча ничего не снять при откате.
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from unittest.mock import AsyncMock

import pytest

_ADMIN_URL = "postgresql+asyncpg://postgres:secret@db:5432/riskdb"


def _load_script() -> ModuleType:
    path = Path(__file__).resolve().parents[3] / "scripts" / "bootstrap_db_roles.py"
    spec = importlib.util.spec_from_file_location("bootstrap_db_roles_under_test", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def script(monkeypatch: pytest.MonkeyPatch) -> ModuleType:
    module = _load_script()
    monkeypatch.setattr(module, "bootstrap_roles_at_url", AsyncMock())
    monkeypatch.setattr(module, "drop_roles_at_url", AsyncMock())
    monkeypatch.setattr(module, "bootstrap_logins_at_url", AsyncMock())
    monkeypatch.setenv("RISK_MODEL_DB_ADMIN_URL", _ADMIN_URL)
    for variable in module._PASSWORD_VARS.values():
        monkeypatch.setenv(variable, "unused-in-this-test")  # noqa: S106 — фиктивное значение, не секрет
    return module


def test_default_run_grants_roles(script: ModuleType, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py"])

    assert script.main() == 0

    script.bootstrap_roles_at_url.assert_awaited_once()
    script.drop_roles_at_url.assert_not_awaited()
    script.bootstrap_logins_at_url.assert_not_awaited()


def test_drop_roles_flag_only_drops(script: ModuleType, monkeypatch: pytest.MonkeyPatch) -> None:
    """Снятие не требует паролей и не должно случайно задеть ветку выдачи."""
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--drop-roles"])

    assert script.main() == 0

    script.drop_roles_at_url.assert_awaited_once_with(_ADMIN_URL)
    script.bootstrap_roles_at_url.assert_not_awaited()


def test_missing_admin_url_stops_both_modes(script: ModuleType, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RISK_MODEL_DB_ADMIN_URL")
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--drop-roles"])

    assert script.main() == 2

    script.drop_roles_at_url.assert_not_awaited()
    script.bootstrap_roles_at_url.assert_not_awaited()


@pytest.fixture
def password_file(tmp_path: Path) -> Path:
    path = tmp_path / "password"
    path.write_text("from-file\n", encoding="utf-8")
    return path


def test_role_flag_sets_up_only_the_requested_logins(
    script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path
) -> None:
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--role", f"risk_bulk_recalc_app={password_file}"])

    assert script.main() == 0

    script.bootstrap_roles_at_url.assert_not_awaited()
    script.drop_roles_at_url.assert_not_awaited()
    ((admin_url, logins), _) = script.bootstrap_logins_at_url.await_args
    assert admin_url == _ADMIN_URL
    assert {role: password.get_secret_value() for role, password in logins.items()} == {
        "risk_bulk_recalc_app": "from-file"
    }


def test_role_flag_repeats(script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "bootstrap_db_roles.py",
            "--role",
            f"risk_bulk_recalc_app={password_file}",
            "--role",
            f"risk_ehr_app={password_file}",
        ],
    )

    assert script.main() == 0

    ((_, logins), _) = script.bootstrap_logins_at_url.await_args
    assert set(logins) == {"risk_bulk_recalc_app", "risk_ehr_app"}


@pytest.mark.parametrize(
    "value",
    [
        "risk_bulk_recalc_app",  # нет файла
        "=/some/file",  # нет имени
        "risk_bulk_recalc_app=",  # пустой путь
        "postgres={file}",  # чужая роль
        "risk_bulk_recalc_app={missing}",  # файла нет на диске
        "risk_bulk_recalc_app={empty}",  # пустой пароль
    ],
    ids=["no-file", "no-name", "empty-path", "unknown-role", "missing-file", "empty-file"],
)
def test_invalid_role_argument_stops_before_touching_the_database(
    script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path, tmp_path: Path, value: str
) -> None:
    empty = tmp_path / "empty"
    empty.write_text("\n", encoding="utf-8")
    argument = value.format(file=password_file, missing=tmp_path / "missing", empty=empty)
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--role", argument])

    with pytest.raises(SystemExit) as exit_info:
        script.main()

    assert exit_info.value.code == 2
    script.bootstrap_logins_at_url.assert_not_awaited()
    script.bootstrap_roles_at_url.assert_not_awaited()


def test_repeated_login_is_rejected(script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path) -> None:
    """Два пароля одному логину — опечатка оператора: какой из них выиграл бы, неочевидно."""
    argument = f"risk_bulk_recalc_app={password_file}"
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--role", argument, "--role", argument])

    with pytest.raises(SystemExit):
        script.main()

    script.bootstrap_logins_at_url.assert_not_awaited()


def test_role_flag_and_drop_roles_are_exclusive(
    script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path
) -> None:
    monkeypatch.setattr(
        sys, "argv", ["bootstrap_db_roles.py", "--drop-roles", "--role", f"risk_bulk_recalc_app={password_file}"]
    )

    with pytest.raises(SystemExit):
        script.main()

    script.drop_roles_at_url.assert_not_awaited()
    script.bootstrap_logins_at_url.assert_not_awaited()


def test_shared_login_is_passed_to_the_full_run(script: ModuleType, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", "--shared-login", "risk_profile_app"])

    assert script.main() == 0

    assert script.bootstrap_roles_at_url.await_args.kwargs["shared_login"] == "risk_profile_app"


def test_default_run_grants_no_shared_login(script: ModuleType, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py"])

    assert script.main() == 0

    assert script.bootstrap_roles_at_url.await_args.kwargs["shared_login"] is None


@pytest.mark.parametrize("mode", ["drop", "role"])
def test_shared_login_is_rejected_outside_the_full_run(
    script: ModuleType, monkeypatch: pytest.MonkeyPatch, password_file: Path, mode: str
) -> None:
    """Выдача членства — часть полного прогона: при снятии ролей или обновлении одного логина
    ключ молча потерялся бы."""
    flags = ["--drop-roles"] if mode == "drop" else ["--role", f"risk_bulk_recalc_app={password_file}"]
    monkeypatch.setattr(sys, "argv", ["bootstrap_db_roles.py", *flags, "--shared-login", "risk_profile_app"])

    with pytest.raises(SystemExit):
        script.main()

    script.bootstrap_roles_at_url.assert_not_awaited()
    script.drop_roles_at_url.assert_not_awaited()
    script.bootstrap_logins_at_url.assert_not_awaited()
