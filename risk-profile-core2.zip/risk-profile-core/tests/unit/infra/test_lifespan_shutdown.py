"""Остановка сервиса: задержка для балансировщика и бюджет на освобождение ресурсов.

Всё, что закрывается на shutdown (lag-probe, cvd-клиент, дренаж kafka, engine.dispose), может
зависнуть на TCP-blackhole. Uvicorn такой зависон не покрывает — lifespan он ждёт без таймаута,
поэтому бюджет здесь свой, и его срабатывание обязано быть видно в логах.
"""

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI

import src.main as main_module

# Моки инлайн-рантайма, поднятые последним вызовом `_stub_lifespan_services`: тянуть их через
# модуль нельзя — типизатор видит там обычные функции, а не заглушки.
_INLINE_MOCKS: dict[str, AsyncMock | MagicMock] = {}


def _stub_lifespan_services(monkeypatch: pytest.MonkeyPatch) -> AsyncMock:
    """Подменяет всё, что lifespan поднимает и гасит; возвращает мок закрытия пула соединений."""
    for name in (
        "init_kafka_producer",
        "init_cvd_client",
        "shutdown_cvd_client",
        "shutdown_kafka_producer",
        "_init_lag_probe",
        "_shutdown_lag_probe",
        # Логин рантайма сверяется с БД на старте; здесь БД нет, а проверка не предмет теста.
        "verify_runtime_login",
    ):
        monkeypatch.setattr(main_module, name, AsyncMock())
    monkeypatch.setattr(main_module, "init_metrics", lambda *args, **kwargs: None)
    inline_init, inline_shutdown = MagicMock(), AsyncMock()
    monkeypatch.setattr(main_module, "init_calculation_runtime", inline_init)
    monkeypatch.setattr(main_module, "shutdown_calculation_runtime", inline_shutdown)
    _INLINE_MOCKS.clear()
    _INLINE_MOCKS.update(init=inline_init, shutdown=inline_shutdown)
    dispose = AsyncMock()
    monkeypatch.setattr(main_module, "shutdown_primary_runtime", dispose)
    catalogs = SimpleNamespace(base=object(), calc=object(), interpretation=object(), http=object())
    monkeypatch.setattr(main_module, "catalog_builder", AsyncMock(return_value=catalogs))
    return dispose


@pytest.fixture(autouse=True)
def _restore_shutdown_flag() -> object:
    """Флаг живёт в модульной переменной: если lifespan упадёт, он утечёт в следующие тесты."""
    original = main_module._is_shutting_down
    yield
    main_module._is_shutting_down = original


@pytest.mark.asyncio
async def test_grace_delay_holds_shutdown_before_releasing_resources(monkeypatch: pytest.MonkeyPatch) -> None:
    """Задержка отрабатывает до закрытия ресурсов — балансировщик успевает увидеть 503 на /readiness."""
    dispose = _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0.05)
    monkeypatch.setattr(main_module.settings, "shutdown_timeout", 5)

    loop = asyncio.get_running_loop()
    started = loop.time()
    async with main_module.lifespan(FastAPI()):
        pass
    elapsed = loop.time() - started

    assert elapsed >= 0.05
    dispose.assert_awaited_once()


@pytest.mark.asyncio
async def test_teardown_timeout_alerts_instead_of_hanging(monkeypatch: pytest.MonkeyPatch) -> None:
    """Зависший teardown не держит процесс: бюджет истекает, уходит alert, lifespan завершается.

    Без таймаута shutdown упирался бы в SIGKILL, и причина зависания не попадала бы в логи вовсе.
    """
    dispose = _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0.0)
    monkeypatch.setattr(main_module.settings, "shutdown_timeout", 0.05)

    async def _hang(**_kwargs: object) -> None:
        await asyncio.Event().wait()

    monkeypatch.setattr(main_module, "shutdown_kafka_producer", AsyncMock(side_effect=_hang))

    with patch.object(main_module, "alert") as mock_alert:
        async with main_module.lifespan(FastAPI()):
            pass

    mock_alert.assert_called_once()
    assert "shutdown timed out" in mock_alert.call_args.args[0]
    assert mock_alert.call_args.args[1]["timeout_s"] == 0.05
    # Зависли на дренаже kafka — до engine.dispose дело не дошло, и это должно быть видно из лога.
    dispose.assert_not_awaited()


@pytest.mark.asyncio
async def test_profiler_is_started_and_stopped_within_lifespan(monkeypatch: pytest.MonkeyPatch) -> None:
    """При включённом профайлере окно поднимается на старте и гасится ДО освобождения ресурсов.

    Остановка идёт до бюджета teardown осознанно: профайлер держит каталог с бакетами, и снос
    этого каталога не должен конкурировать с дренажом kafka за один и тот же бюджет времени.
    """
    _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0.0)
    monkeypatch.setattr(main_module.settings, "shutdown_timeout", 5)
    monkeypatch.setattr(main_module.settings.profiler, "enabled", True)
    profiler = SimpleNamespace(start=AsyncMock(), stop=AsyncMock())
    monkeypatch.setattr(main_module, "RollingProfiler", lambda **_kwargs: profiler)

    async with main_module.lifespan(FastAPI()):
        assert main_module._profiler is profiler

    profiler.start.assert_awaited_once()
    profiler.stop.assert_awaited_once()
    # Ссылка снимается: иначе /api/v1/debug/profile после рестарта lifespan отдал бы окно
    # остановленного профайлера с каталогом, который уже снесён.
    assert main_module._profiler is None


@pytest.mark.asyncio
async def test_profiler_absent_when_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    """Дефолт — выключен: yappi не инструментирует боевой процесс."""
    _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0.0)
    monkeypatch.setattr(main_module.settings, "shutdown_timeout", 5)
    monkeypatch.setattr(main_module.settings.profiler, "enabled", False)

    async with main_module.lifespan(FastAPI()):
        assert main_module._profiler is None


@pytest.mark.asyncio
async def test_calculation_engine_is_not_created_in_the_production_shape(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Kafka включена, testing-API выключен: считать в этом процессе некому, второй пул не нужен."""
    _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0)
    monkeypatch.setattr(main_module.settings.kafka, "enabled", True)
    monkeypatch.setattr(main_module.settings, "testing_api_enabled", False)

    async with main_module.lifespan(FastAPI()):
        _INLINE_MOCKS["init"].assert_not_called()

    _INLINE_MOCKS["shutdown"].assert_awaited_once()


@pytest.mark.asyncio
async def test_calculation_engine_is_created_on_startup_when_kafka_is_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Инлайн-режим: нехватка учётных данных расчёта обязана всплыть на старте, а не на первом пересчёте."""
    _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0)
    monkeypatch.setattr(main_module.settings.kafka, "enabled", False)
    monkeypatch.setattr(main_module.settings, "testing_api_enabled", False)

    async with main_module.lifespan(FastAPI()):
        _INLINE_MOCKS["init"].assert_called_once()

    _INLINE_MOCKS["shutdown"].assert_awaited_once()


@pytest.mark.asyncio
async def test_calculation_engine_is_created_on_startup_for_the_testing_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Стенд с testing-API: `POST /testing/calculation/run` пишет результаты в этом же процессе.

    Kafka при этом включена, и без второго пула запуск расчёта уходил бы в БД под профильным
    логином — с `SELECT, DELETE` на результатах и отказом в правах на первом апсерте.
    """
    _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0)
    monkeypatch.setattr(main_module.settings.kafka, "enabled", True)
    monkeypatch.setattr(main_module.settings, "testing_api_enabled", True)

    async with main_module.lifespan(FastAPI()):
        _INLINE_MOCKS["init"].assert_called_once()

    _INLINE_MOCKS["shutdown"].assert_awaited_once()


@pytest.mark.asyncio
async def test_lifespan_brings_up_the_profile_runtime_and_closes_it(
    monkeypatch: pytest.MonkeyPatch, no_primary_runtime: None
) -> None:
    """API — профильный процесс: роль объявляет lifespan, а не окружение, и логин сверяется с БД."""
    from src.config import ServiceRuntime
    from src.infra import database

    dispose = _stub_lifespan_services(monkeypatch)
    monkeypatch.setattr(main_module.settings, "shutdown_grace_delay", 0.0)

    async with main_module.lifespan(FastAPI()):
        assert database._primary is not None
        assert database._primary.runtime is ServiceRuntime.PROFILE
        verify = main_module.verify_runtime_login
        assert isinstance(verify, AsyncMock)
        verify.assert_any_await(database.get_primary_runtime().engine, ServiceRuntime.PROFILE)

    dispose.assert_awaited_once()
