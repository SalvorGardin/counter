from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import FastAPI

import src.main as main_module
from src.infra.catalog.base import CatalogLoadError


def _stub_lifespan_services(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in (
        "init_kafka_producer",
        "init_cvd_client",
        "shutdown_cvd_client",
        "shutdown_kafka_producer",
        "_init_lag_probe",
        "_shutdown_lag_probe",
        # Логин рантайма сверяется с БД на старте; здесь БД нет, а проверка не предмет теста.
        "verify_runtime_login",
    ):
        monkeypatch.setattr(main_module, name, AsyncMock())
    monkeypatch.setattr(main_module, "init_metrics", lambda *args, **kwargs: None)
    monkeypatch.setattr(main_module, "shutdown_primary_runtime", AsyncMock())


async def test_lifespan_stores_catalogs_before_yield(monkeypatch: pytest.MonkeyPatch) -> None:
    _stub_lifespan_services(monkeypatch)
    catalogs = SimpleNamespace(calc=object(), interpretation=object(), http=object())
    monkeypatch.setattr(main_module, "catalog_builder", AsyncMock(return_value=catalogs))
    test_app = FastAPI()

    async with main_module.lifespan(test_app):
        assert test_app.state.catalogs is catalogs

    main_module._is_shutting_down = False


async def test_lifespan_does_not_become_ready_when_catalog_construction_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _stub_lifespan_services(monkeypatch)
    failure = CatalogLoadError("catalog unavailable")
    monkeypatch.setattr(main_module, "catalog_builder", AsyncMock(side_effect=failure))
    init_kafka = AsyncMock()
    monkeypatch.setattr(main_module, "init_kafka_producer", init_kafka)
    test_app = FastAPI()

    with pytest.raises(CatalogLoadError, match="catalog unavailable"):
        async with main_module.lifespan(test_app):
            pytest.fail("lifespan yielded after catalog construction failed")

    assert not hasattr(test_app.state, "http_catalog")
    init_kafka.assert_not_awaited()
    main_module._is_shutting_down = False
