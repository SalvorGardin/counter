"""Счётчик ошибок как побочный эффект логирования и порог уровня при невалидном конфиге.

Обе ветки — про одно: логирование не имеет права упасть само. Инкремент счётчика ERRORS_TOTAL
висит отдельным хендлером на логгере, и его сбой не должен всплыть в вызов `logger.error(...)`
в бизнес-коде. Порог уровня читается лениво из настроек, потому что невалидный конфиг нужно
где-то залогировать — а логгер к этому моменту уже создан.
"""

import logging
from typing import Any

import pytest

import src.logger as logger_module
from src.logger import NOTICE, _MetricsHandler, _threshold


def _record(level: int = logging.ERROR) -> logging.LogRecord:
    return logging.LogRecord(name="app", level=level, pathname=__file__, lineno=1, msg="boom", args=(), exc_info=None)


def test_increment_failure_does_not_reach_the_caller(monkeypatch: pytest.MonkeyPatch) -> None:
    """Метрика упала — `logger.error(...)` всё равно возвращается нормально.

    Иначе обзервабилити ломала бы обработку ошибки, ради логирования которой её и звали.
    """

    def _explode(**_kwargs: object) -> object:
        raise RuntimeError("registry is broken")

    monkeypatch.setattr("src.metrics.ERRORS_TOTAL.labels", _explode)

    _MetricsHandler().emit(_record())


def test_increment_failure_stays_off_stderr(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture) -> None:
    """Сбой инкремента гасится молча: во время инцидента, который и так сыплет ERROR, стандартный
    handleError удваивал бы вывод трейсом на каждую запись."""

    def _explode(**_kwargs: object) -> object:
        raise RuntimeError("registry is broken")

    monkeypatch.setattr("src.metrics.ERRORS_TOTAL.labels", _explode)
    monkeypatch.setattr(logging, "raiseExceptions", True)

    _MetricsHandler().emit(_record())

    captured = capsys.readouterr()
    assert captured.err == ""
    assert captured.out == ""


@pytest.mark.parametrize("level", [logging.DEBUG, logging.INFO, logger_module.NOTICE, logging.WARNING])
def test_records_below_error_are_not_counted(level: int, monkeypatch: pytest.MonkeyPatch) -> None:
    """Счётчик — про ошибки: NOTICE и WARNING в него не идут, иначе дежурный алерт по нему бесполезен."""
    calls: list[dict[str, object]] = []
    monkeypatch.setattr("src.metrics.ERRORS_TOTAL.labels", lambda **kwargs: calls.append(kwargs) or _NoopCounter())

    _MetricsHandler().emit(_record(level))

    assert calls == []


class _NoopCounter:
    def inc(self) -> None:
        return


def test_error_is_counted_with_level_and_component(monkeypatch: pytest.MonkeyPatch) -> None:
    """Лейблы: уровень в нижнем регистре и модуль вызвавшего кода."""
    calls: list[dict[str, object]] = []
    monkeypatch.setattr("src.metrics.ERRORS_TOTAL.labels", lambda **kwargs: calls.append(kwargs) or _NoopCounter())

    _MetricsHandler().emit(_record(logging.CRITICAL))

    assert calls == [{"level": "critical", "component": logger_module._component_from_record(_record())}]


def test_threshold_falls_back_to_notice_when_settings_cannot_load(monkeypatch: pytest.MonkeyPatch) -> None:
    """Конфиг невалиден (пустой RISK_MODEL_PROFILE_DB_URL) — логгер не падает, а берёт NOTICE.

    Порог нужен раньше, чем валидируются настройки: без отката саму ошибку конфига было бы
    некуда записать, и процесс умирал бы молча.
    """
    import builtins  # noqa: PLC0415

    real_import = builtins.__import__

    # Сигнатура-переходник: аргументы уходят в настоящий __import__ как есть, поэтому Any,
    # а не object — иначе типизатор не даёт передать их дальше.
    def _fail_on_config(name: str, *args: Any, **kwargs: Any) -> object:
        if name == "src.config":
            raise RuntimeError("RISK_MODEL_LOG_BODY_MAX_BYTES must be >= 1, got 0")
        return real_import(name, *args, **kwargs)

    monkeypatch.delitem(__import__("sys").modules, "src.config", raising=False)
    monkeypatch.setattr(builtins, "__import__", _fail_on_config)

    assert _threshold() == NOTICE


def test_make_logger_does_not_stack_handlers_on_repeated_calls() -> None:
    """Повторная сборка логгера возвращает уже настроенный, не добавляя вторых хендлеров.

    Логгер «app» глобален, а модуль импортируется и из воркеров, и из alembic-окружения: лишний
    комплект хендлеров означал бы дублирование КАЖДОЙ строки в Kibana.
    """
    before = list(logger_module.logger.handlers)

    rebuilt = logger_module._make_logger()

    assert rebuilt is logger_module.logger
    assert list(rebuilt.handlers) == before
