"""Каждая точка входа поднимает основной рантайм под своей ролью, а не под соседней.

Роль задаёт константа в точке входа, и подмена её на соседнюю роль не видна ни одному другому
тесту: `init_primary_runtime` возьмёт строку подключения той же соседней роли, а
`verify_runtime_login` сверит логин с ней же и пропустит. В общем наборе переменных пода процесс
при этом тихо заработает под чужим логином — для массового пересчёта это логин расчёта с правом
переписать результаты любого пациента.

Пул переменных здесь полный: строки подключения всех ролей с разными логинами и прежние
переменные. Проверка логина подменена: запоминает, с чем её вызвали, и останавливает старт —
дальше точке входа нужны Kafka и БД, а роль к этому моменту уже выбрана.
"""

from collections.abc import Awaitable, Callable
from types import ModuleType
from typing import Any

import pytest
from pydantic import SecretStr

import src.main as main
import src.workers.bulk_recalc as bulk_recalc
import src.workers.calc_consumer as calc_consumer
import src.workers.emr_biomarkers_consumer as emr_consumer
from src.config import ServiceRuntime, db_url_env
from src.infra.database import RUNTIME_IDENTITIES, get_primary_runtime


class _StopAtLoginCheckError(Exception):
    """Старт дошёл до проверки логина — дальше тесту идти незачем."""


async def _start_api() -> None:
    async with main.lifespan(main.app):
        pass


def _prepare_bulk_recalc(monkeypatch: pytest.MonkeyPatch) -> None:
    # Выключенный прогон или выключенная Kafka завершают его раньше проверки логина.
    monkeypatch.setattr("src.config.settings.bulk_recalc.enabled", True)
    monkeypatch.setattr("src.config.settings.kafka.enabled", True)
    monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: "test")


def _prepare_calc_consumer(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(calc_consumer, "require_calculation_version", lambda: "test")


_ENTRYPOINTS: list[tuple[ServiceRuntime, ModuleType, Callable[[], Awaitable[Any]], Callable[..., None] | None]] = [
    (ServiceRuntime.PROFILE, main, _start_api, None),
    (ServiceRuntime.CALCULATION, calc_consumer, calc_consumer._main, _prepare_calc_consumer),
    (ServiceRuntime.EHR, emr_consumer, emr_consumer._main, None),
    (ServiceRuntime.BULK_RECALC, bulk_recalc, bulk_recalc._main, _prepare_bulk_recalc),
]


def _url(runtime: ServiceRuntime) -> str:
    return f"postgresql+asyncpg://{RUNTIME_IDENTITIES[runtime].login}:pw@db:5432/riskdb"


@pytest.mark.usefixtures("no_primary_runtime")
@pytest.mark.parametrize(
    ("runtime", "module", "start", "prepare"), _ENTRYPOINTS, ids=[runtime.value for runtime, *_ in _ENTRYPOINTS]
)
async def test_entrypoint_starts_under_its_own_role_in_a_shared_environment(
    monkeypatch: pytest.MonkeyPatch,
    runtime: ServiceRuntime,
    module: ModuleType,
    start: Callable[[], Awaitable[Any]],
    prepare: Callable[..., None] | None,
) -> None:
    for any_runtime in ServiceRuntime:
        field = db_url_env(any_runtime).removeprefix("RISK_MODEL_").lower()
        monkeypatch.setattr(f"src.config.settings.{field}", SecretStr(_url(any_runtime)))
    monkeypatch.setenv("RISK_MODEL_DB_URL", _url(ServiceRuntime.PROFILE))
    monkeypatch.setenv("RISK_MODEL_SERVICE_RUNTIME", ServiceRuntime.PROFILE.value)
    if prepare is not None:
        prepare(monkeypatch)
    checked: list[tuple[object, ServiceRuntime]] = []

    async def _check_login(engine: object, checked_runtime: ServiceRuntime) -> None:
        checked.append((engine, checked_runtime))
        raise _StopAtLoginCheckError

    monkeypatch.setattr(module, "verify_runtime_login", _check_login)

    with pytest.raises(_StopAtLoginCheckError):
        await start()

    engine = get_primary_runtime().engine
    assert engine.url.render_as_string(hide_password=False) == _url(runtime)
    assert checked == [(engine, runtime)]
