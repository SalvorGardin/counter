"""Контракт билдера ин-мемори каталога для unit-тестов."""

from decimal import Decimal

import pytest

from src.constants import ANSWER_YES
from src.infra.catalog.base import Catalog
from src.infra.catalog.calc import CalcCatalog
from tests.catalog_builder import make_catalog, option, question, score


def test_unnamed_tables_default_to_empty() -> None:
    cat = make_catalog(questions=[question("Q1")])
    assert isinstance(cat, Catalog)
    assert cat.get("questions")[0].code == "Q1"
    assert cat.get("options") == ()
    assert cat.get("parameter_scores") == ()
    assert cat.get("recommendations") == ()


def test_ids_are_auto_assigned_and_distinct() -> None:
    cat = make_catalog(questions=[question("Q1"), question("Q2")])
    ids = {q.question_id for q in cat.get("questions")}
    assert len(ids) == 2


def test_explicit_id_is_respected() -> None:
    cat = make_catalog(questions=[question("Q1", question_id=42)])
    assert cat.get("questions")[0].question_id == 42


def test_defaults_are_production_plausible() -> None:
    opt = option("O1", question_code="Q1", parameter_code="p1")
    assert opt.value == ANSWER_YES
    q = question("Q1")
    assert q.type == "select" and q.group_code == 2 and q.is_skippable is False


def test_built_catalog_drives_calc_catalog() -> None:
    """Билдер обязан отдавать каталог, который принимает боевой CalcCatalog, а не только Catalog.

    BDI-вопрос и опция обязательны: CalcCatalog строит bdi_score_map в __init__ и падает
    CatalogLoadError, если ни одной BDI-опции нет (src/infra/catalog/calc.py:85).
    CalcCatalog не хранит исходный Catalog — он строит вью, поэтому проверяем
    через params_by_question, а не через .get("questions").
    """
    cat = CalcCatalog(
        make_catalog(
            questions=[question("Q_GEN", group_code=1), question("BDI1")],
            options=[
                option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen"),
                option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="sad"),
            ],
            parameter_scores=[score("p_gen", "s1", value=ANSWER_YES, score=Decimal("2"))],
        )
    )
    assert cat.params_by_question["Q_GEN"] == frozenset({"p_gen"})


def test_unknown_table_name_is_rejected() -> None:
    """Опечатка в имени справочника должна падать сразу, а не отдавать пустую таблицу."""
    with pytest.raises(ValueError, match="unknown catalog tables"):
        make_catalog(questionz=[question("Q1")])
