from src.api.v1.testing.biomarkers.router import list_biomarkers
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from tests.catalog_builder import biomarker, biomarker_mapping, make_catalog, parameter


async def test_list_biomarkers_includes_catalog_parameter_codes() -> None:
    source = parameter("biomarker_101")
    first_target = parameter("target_a")
    second_target = parameter("target_b")
    catalog = EmrBiomarkersCatalog(
        make_catalog(
            parameters=(source, first_target, second_target),
            biomarkers=(biomarker(101, source.code, biomarker_id=1),),
            biomarker_parameter_mappings=(
                biomarker_mapping(source.code, second_target.code, biomarker_parameter_mapping_id=2),
                biomarker_mapping(source.code, first_target.code, biomarker_parameter_mapping_id=1),
            ),
        )
    )

    [choice] = await list_biomarkers(catalog)

    assert choice.parameter_code == "biomarker_101"
    assert choice.mapped_parameter_codes == ["target_a", "target_b"]


async def test_list_biomarkers_reports_each_mapped_parameter_once() -> None:
    """Пара «источник → цель» размечается несколькими условиями, а код параметра — один."""
    source = parameter("biomarker_101")
    target = parameter("target_a")
    catalog = EmrBiomarkersCatalog(
        make_catalog(
            parameters=(source, target),
            biomarkers=(biomarker(101, source.code, biomarker_id=1),),
            biomarker_parameter_mappings=(
                biomarker_mapping(source.code, target.code, biomarker_parameter_mapping_id=1),
                biomarker_mapping(source.code, target.code, biomarker_parameter_mapping_id=2),
            ),
        )
    )

    [choice] = await list_biomarkers(catalog)

    assert choice.mapped_parameter_codes == ["target_a"]
