import io
import json
import zipfile
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import inspect

from src.models.interpretation import Interpretation
from src.models.patient import Patient
from src.models.patient_parameter import PatientParameter
from src.models.result import Result
from src.testing.infra.patient_export_repository import PatientExportRows
from src.testing.patient_export import ARCHIVE_FILES, build_patient_archive, model_row


def _documents(content: bytes) -> tuple[list[str], dict[str, list[dict]]]:
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        names = archive.namelist()
        return names, {name: json.loads(archive.read(name)) for name in names}


def test_model_row_serializes_every_model_column_and_json_types() -> None:
    timestamp = datetime(2026, 8, 12, 9, 30, tzinfo=UTC)
    interpretation = Interpretation(
        interpretation_id=9,
        system_code="cardio",
        patient_id="p1",
        risk_level=None,
        text="Текст",
        diseases=["d1", "d2"],
        risk_factors_code=[],
        doctors_code=None,
        date_time=timestamp,
    )
    result = Result(
        result_id=5,
        instrument_code="i1",
        patient_id="p1",
        value=Decimal("12.340000"),
        indicator="score",
        date_time=timestamp,
        interpretation_status="done",
        expiration_date=timestamp,
        risk_level="low",
        applicability=True,
        unit=None,
    )

    interpretation_data = model_row(interpretation)
    result_data = model_row(result)

    assert set(interpretation_data) == {column.key for column in inspect(Interpretation).columns}
    assert set(result_data) == {column.key for column in inspect(Result).columns}
    assert interpretation_data["date_time"] == "2026-08-12T09:30:00+00:00"
    assert interpretation_data["diseases"] == ["d1", "d2"]
    assert interpretation_data["risk_factors_code"] == []
    assert interpretation_data["doctors_code"] is None
    assert result_data["value"] == 12.34
    assert result_data["applicability"] is True
    assert result_data["unit"] is None


def test_archive_has_exact_files_complete_rows_and_deterministic_order() -> None:
    timestamp = datetime(2026, 8, 12, 9, 30, tzinfo=UTC)
    patient = Patient(unique_id=1, patient_id="p1", is_pregnant=False)
    parameter_1 = PatientParameter(
        patient_parameter_id=1,
        patient_id="p1",
        parameter_code="a",
        value="1",
        source="test",
        expiration_date=timestamp,
        date_time=timestamp,
    )
    parameter_2 = PatientParameter(
        patient_parameter_id=2,
        patient_id="p1",
        parameter_code="b",
        value="2",
        source="test",
        expiration_date=timestamp,
        date_time=timestamp,
    )
    rows = PatientExportRows(
        patient=patient,
        patient_parameters=[parameter_1, parameter_2],
        interpretations=[],
        results=[],
    )

    first = build_patient_archive(rows)
    second = build_patient_archive(rows)
    names, documents = _documents(first)

    assert names == list(ARCHIVE_FILES)
    assert documents["patients.json"] == [{"unique_id": 1, "patient_id": "p1", "is_pregnant": False}]
    assert [row["patient_parameter_id"] for row in documents["patients_parameters.json"]] == [1, 2]
    assert documents["interpretations.json"] == []
    assert documents["results.json"] == []
    assert _documents(second) == (names, documents)
