from datetime import UTC, datetime
from decimal import Decimal
from types import SimpleNamespace

from src.api.v1.testing.calculation.router import _result_row
from tests.catalog_builder import disease


def test_disease_scoped_result_is_enriched_with_name_and_system_code() -> None:
    row = SimpleNamespace(
        result_id=1,
        instrument_code="biomarker_kr",
        disease_code="D1",
        value=Decimal("3"),
        indicator="Показатель",
        date_time=datetime(2026, 9, 2, tzinfo=UTC),
        interpretation_status="done",
        expiration_date=datetime(2026, 10, 2, tzinfo=UTC),
        risk_level="high",
        applicability=True,
        unit=None,
    )

    result = _result_row(row, {"D1": disease("D1", "BLOOD", description="Группа крови")})

    assert result.disease_name == "Группа крови"
    assert result.system_code == "BLOOD"


def test_result_without_disease_is_not_enriched() -> None:
    row = SimpleNamespace(
        result_id=2,
        instrument_code="form_blood",
        disease_code=None,
        value=Decimal("1"),
        indicator="Показатель",
        date_time=datetime(2026, 9, 2, tzinfo=UTC),
        interpretation_status="done",
        expiration_date=datetime(2026, 10, 2, tzinfo=UTC),
        risk_level="low",
        applicability=True,
        unit=None,
    )

    result = _result_row(row, {})

    assert result.disease_name is None
    assert result.system_code is None
