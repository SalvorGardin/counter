"""Разбор числового ответа пациента."""

from decimal import Decimal

import pytest

from src.utils.numeric import parse_answer_decimal


@pytest.mark.parametrize(
    ("answer", "expected"),
    [
        ("30", Decimal("30")),
        ("29.9", Decimal("29.9")),
        # Десятичная запятая — рабочая форма ответа: пороги справочника заведены точкой, ответы
        # приходят и так, и так.
        ("29,9", Decimal("29.9")),
        ("0,5", Decimal("0.5")),
        ("-1,5", Decimal("-1.5")),
    ],
)
def test_parses_both_decimal_separators(answer: str, expected: Decimal) -> None:
    assert parse_answer_decimal(answer) == expected


@pytest.mark.parametrize("answer", ["", "Да", "не число", "1,2,3", "29,9 кг", "nan", "NaN", "Infinity", "-inf"])
def test_non_numbers_and_special_values_are_rejected(answer: str) -> None:
    """`NaN`/`Infinity` для `Decimal` разбираются, но числом ответа не являются.

    Сравнение с `NaN` бросает `InvalidOperation` уже в месте сравнения, а не разбора, поэтому такие
    значения отсекаются здесь наравне с нечислами.
    """
    assert parse_answer_decimal(answer) is None


# Формы записи, которые Decimal принимает наравне с обычным числом. Значение ответа приходит от
# клиента и сравнивается с порогами справочника (`domain/risk_factor_conditions.py`), поэтому
# набор принимаемых форм — часть контракта границы, а не деталь Decimal: сузить его позже, не
# сломав этих проверок, не получится.
_ACCEPTED_UNUSUAL_FORMS = [
    ("+30", Decimal("30")),
    # Пробелы по краям Decimal съедает сам.
    (" 30 ", Decimal("30")),
    ("30\n", Decimal("30")),
    # Разделитель разрядов Python и экспоненциальная запись: "1_0" читается как 10,
    # "1e5" — как 100000. Ответ вида "1e5" пройдёт любой верхний порог справочника.
    ("1_0", Decimal("10")),
    ("1e5", Decimal("100000")),
    ("2E-3", Decimal("0.002")),
    # Не-ASCII цифры (арабо-индийские) — Decimal разбирает их как обычные.
    ("٣٠", Decimal("30")),
]


@pytest.mark.parametrize(("answer", "expected"), _ACCEPTED_UNUSUAL_FORMS)
def test_unusual_but_accepted_numeric_forms(answer: str, expected: Decimal) -> None:
    assert parse_answer_decimal(answer) == expected


def test_none_is_not_handled_and_raises() -> None:
    """None разбор не переваривает: AttributeError мимо except, а не None в ответе.

    Вызывающие стороны передают сюда значение ответа пациента, которое к этому месту уже строка,
    поэтому граница зафиксирована как есть — падением, а не тихим None.
    """
    with pytest.raises(AttributeError):
        parse_answer_decimal(None)  # ty: ignore[invalid-argument-type]
