import json
from pathlib import Path
from typing import cast
from unittest.mock import AsyncMock, _Call, patch

import pytest

import playground.calc_playground as pg
from playground.calc_playground import (
    CommandTiming,
    PlaygroundError,
    format_report,
    load_requests,
    parse_args,
    select_requests,
)
from src.calc.outcomes import CalcRunResult
from src.infra.catalog.builder import Catalogs
from tests.consts import PARAMETER_CODE_AGE

# run_recalc подменяется AsyncMock-ом в этих тестах, каталоги только форвардятся и не используются —
# отдаём заглушку под нужным типом, чтобы не поднимать реальные каталоги (нужна БД).
_FAKE_CATALOGS = cast(Catalogs, object())

# Playground — внутренний (не боевой) инструмент, как и сам сбор по-шаговых замеров: оба живут за
# флагами и в прод-путь не входят. Весь модуль под test_internal, см. маркер в pyproject.toml.
pytestmark = pytest.mark.test_internal

_REQ_A = {"clientId": "aaaa", "parameterCodes": None}
_REQ_B = {"clientId": "bbbb", "parameterCodes": [PARAMETER_CODE_AGE]}


def _write(tmp_path: Path, payload: object) -> Path:
    p = tmp_path / "requests.json"
    p.write_text(json.dumps(payload), encoding="utf-8")
    return p


def test_load_requests_reads_named_dict(tmp_path: Path) -> None:
    path = _write(tmp_path, {"a": _REQ_A, "b": _REQ_B})
    assert load_requests(path) == {"a": _REQ_A, "b": _REQ_B}


def test_load_requests_rejects_non_object(tmp_path: Path) -> None:
    path = _write(tmp_path, [_REQ_A])
    with pytest.raises(PlaygroundError):
        load_requests(path)


def test_select_no_keys_runs_all_in_file_order() -> None:
    selected = select_requests({"a": _REQ_A, "b": _REQ_B}, keys=[], repeat=1)
    assert selected == [("a", _REQ_A), ("b", _REQ_B)]


def test_select_unknown_key_raises_listing_available() -> None:
    with pytest.raises(PlaygroundError) as exc:
        select_requests({"a": _REQ_A}, keys=["nope"], repeat=1)
    assert "a" in str(exc.value)


def test_select_repeat_expands_in_order() -> None:
    selected = select_requests({"a": _REQ_A, "b": _REQ_B}, keys=["a"], repeat=3)
    assert selected == [("a", _REQ_A), ("a", _REQ_A), ("a", _REQ_A)]


def test_parse_args_defaults_and_keys() -> None:
    ns = parse_args(["--file", "r.json", "a", "b"])
    assert ns.file == Path("r.json")
    assert ns.repeat == 1
    assert ns.keys == ["a", "b"]


def test_parse_args_rejects_zero_repeat() -> None:
    with pytest.raises(SystemExit):
        parse_args(["--file", "r.json", "--repeat", "0"])


def test_format_report_has_summary_totals() -> None:
    timings = [
        CommandTiming(key="a", run_index=1, total_runs=2, patient_id="aaaa", elapsed_ms=100.0, status="ok"),
        CommandTiming(key="a", run_index=2, total_runs=2, patient_id="aaaa", elapsed_ms=200.0, status="ok"),
    ]
    report = format_report(timings)
    assert "count=2" in report
    assert "total=300.0ms" in report
    assert "mean=150.0ms" in report
    assert "aaaa" in report


def test_format_report_lists_recalculated_instruments_per_key() -> None:
    # Разные инструменты в повторах одного ключа объединяются и сортируются в секции по ключу.
    timings = [
        CommandTiming(
            key="a",
            run_index=1,
            total_runs=2,
            patient_id="aaaa",
            elapsed_ms=1.0,
            status="ok",
            instrument_codes=("phq9", "airi_ssz"),
        ),
        CommandTiming(
            key="a",
            run_index=2,
            total_runs=2,
            patient_id="aaaa",
            elapsed_ms=1.0,
            status="ok",
            instrument_codes=("gad7",),
        ),
    ]
    report = format_report(timings)
    assert "recalculated instruments (per key)" in report
    assert "a: airi_ssz, gad7, phq9" in report


def test_format_report_shows_none_when_no_instruments() -> None:
    timings = [
        CommandTiming(key="a", run_index=1, total_runs=1, patient_id="aaaa", elapsed_ms=1.0, status="ok"),
    ]
    report = format_report(timings)
    assert "a: (none)" in report


def test_format_report_empty() -> None:
    assert "no commands run" in format_report([])


def test_format_report_omits_lag_section_by_default() -> None:
    timings = [CommandTiming(key="a", run_index=1, total_runs=1, patient_id="aaaa", elapsed_ms=1.0, status="ok")]
    report = format_report(timings)
    assert "event-loop lag" not in report


def test_format_report_renders_lag_section_when_samples_passed() -> None:
    timings = [CommandTiming(key="a", run_index=1, total_runs=1, patient_id="aaaa", elapsed_ms=1.0, status="ok")]
    # 1..100 ms -> mean=50.5, nearest-rank p95=95, p99=99, max=100.
    report = format_report(timings, lag_samples=[float(i) for i in range(1, 101)])
    assert "event-loop lag" in report
    assert "samples=100" in report
    assert "mean=50.5ms" in report
    assert "p95=95.0ms" in report
    assert "p99=99.0ms" in report
    assert "max=100.0ms" in report


def test_format_report_lag_section_handles_empty_samples() -> None:
    timings = [CommandTiming(key="a", run_index=1, total_runs=1, patient_id="aaaa", elapsed_ms=1.0, status="ok")]
    report = format_report(timings, lag_samples=[])
    assert "event-loop lag" in report
    assert "samples=0" in report


async def test_lag_probe_collects_samples_until_cancelled() -> None:
    import asyncio

    samples: list[float] = []
    probe = asyncio.create_task(pg._lag_probe(0.001, samples))
    await asyncio.sleep(0.05)
    probe.cancel()
    with pytest.raises(asyncio.CancelledError):
        await probe
    # Проба крутилась ~50ms с интервалом 1ms — должна была накопить сэмплы, все неотрицательны.
    assert samples
    assert all(s >= 0.0 for s in samples)


def test_percentile_nearest_rank() -> None:
    values = [float(i) for i in range(1, 101)]  # 1..100
    assert pg.percentile(values, 95) == 95.0
    assert pg.percentile(values, 99) == 99.0
    assert pg.percentile(values, 100) == 100.0
    # Один элемент — любой перцентиль возвращает его.
    assert pg.percentile([42.0], 95) == 42.0


def test_format_report_has_tail_percentiles() -> None:
    timings = [
        CommandTiming(key="a", run_index=i, total_runs=10, patient_id="aaaa", elapsed_ms=float(i), status="ok")
        for i in range(1, 11)  # 1..10 ms
    ]
    report = format_report(timings)
    # nearest-rank: p95 -> rank ceil(0.95*10)=10 -> 10ms; p99 -> rank 10 -> 10ms; max=10ms.
    assert "p95=10.0ms" in report
    assert "p99=10.0ms" in report
    assert "max=10.0ms" in report


def _timing_with_steps(steps: pg.StepTimings, elapsed_ms: float = 1.0) -> CommandTiming:
    return CommandTiming(
        key="a", run_index=1, total_runs=1, patient_id="aaaa", elapsed_ms=elapsed_ms, status="ok", steps=steps
    )


def test_step_breakdown_aggregates_ran_steps() -> None:
    timings = [
        _timing_with_steps(pg.StepTimings(ran=True, load_ms=10.0, formula_ms=2.0, upsert_ms=5.0)),
        _timing_with_steps(pg.StepTimings(ran=True, load_ms=20.0, formula_ms=4.0, upsert_ms=7.0)),
    ]
    lines = pg._format_step_breakdown(timings)
    body = "\n".join(lines)
    assert "--- step breakdown ---" in body
    assert "runs=2" in body
    # load: total=30, mean=15; nearest-rank p95/p99/max on [10,20] -> 20.
    load_line = next(line for line in lines if line.startswith("load"))
    assert "30.0" in load_line and "15.0" in load_line and "20.0" in load_line


def test_step_breakdown_excludes_non_ran_and_missing() -> None:
    # ran=False (no-op short-circuit) and steps=None (invalid) must not count toward the samples.
    timings = [
        _timing_with_steps(pg.StepTimings(ran=True, load_ms=8.0)),
        _timing_with_steps(pg.StepTimings(ran=False, load_ms=999.0)),
        CommandTiming(key="a", run_index=1, total_runs=1, patient_id="-", elapsed_ms=0.0, status="invalid"),
    ]
    lines = pg._format_step_breakdown(timings)
    assert "runs=1" in "\n".join(lines)
    load_line = next(line for line in lines if line.startswith("load"))
    assert "999" not in load_line


def test_step_breakdown_reports_disabled_collection() -> None:
    # Флаг RISK_MODEL_STEP_TIMINGS_ENABLED выключен: хендлер отработал (`ran`), но замеров нет —
    # печатаем подсказку вместо стены нулей.
    disabled = pg.StepTimings(ran=True)
    disabled.enable(False)
    lines = pg._format_step_breakdown([_timing_with_steps(disabled)])
    body = "\n".join(lines)
    assert "RISK_MODEL_STEP_TIMINGS_ENABLED" in body
    assert "runs=" not in body


def test_step_breakdown_reports_disabled_collection_with_no_op_commands() -> None:
    # У no-op команды sink не тронут и остаётся с дефолтным `enabled=True`: решение о подсказке
    # принимается только по командам, где хендлер отработал.
    disabled = pg.StepTimings(ran=True)
    disabled.enable(False)
    lines = pg._format_step_breakdown([_timing_with_steps(pg.StepTimings()), _timing_with_steps(disabled)])
    assert "RISK_MODEL_STEP_TIMINGS_ENABLED" in "\n".join(lines)


def test_step_breakdown_no_handler_runs() -> None:
    timings = [CommandTiming(key="a", run_index=1, total_runs=1, patient_id="-", elapsed_ms=0.0, status="invalid")]
    assert "(no handler runs)" in "\n".join(pg._format_step_breakdown(timings))


def test_step_breakdown_renders_interpretation_substeps() -> None:
    from src.interpretation.timings import InterpretationTimings

    timings = [
        _timing_with_steps(
            pg.StepTimings(
                ran=True,
                interpretation_ms=100.0,
                interpretation=InterpretationTimings(load_ms=10.0, compute_ms=20.0, upsert_ms=30.0),
            )
        ),
        _timing_with_steps(
            pg.StepTimings(
                ran=True,
                interpretation_ms=200.0,
                interpretation=InterpretationTimings(load_ms=30.0, compute_ms=40.0, upsert_ms=50.0),
            )
        ),
    ]
    lines = pg._format_step_breakdown(timings)
    # Под-фазы идут отступом (2 пробела) под строкой interpretation.
    compute_line = next(line for line in lines if line.startswith("  compute"))
    # compute: total=60, mean=30; nearest-rank p95/p99/max on [20,40] -> 40.
    assert "60.0" in compute_line and "30.0" in compute_line and "40.0" in compute_line
    assert any(line.startswith("  load") for line in lines)
    assert any(line.startswith("  upsert") for line in lines)
    # reverse_index/mark_done больше не собираются — в breakdown их быть не должно.
    assert not any("reverse_index" in line or "mark_done" in line for line in lines)


def test_step_breakdown_renders_cvd_as_own_step() -> None:
    timings = [
        _timing_with_steps(pg.StepTimings(ran=True, formula_ms=5.0, cvd_ms=7.0)),
        _timing_with_steps(pg.StepTimings(ran=True, formula_ms=9.0, cvd_ms=3.0)),
    ]
    lines = pg._format_step_breakdown(timings)
    # cvd — отдельная строка верхнего уровня (без отступа), не под-фаза interpretation.
    cvd_line = next(line for line in lines if line.startswith("cvd "))
    # cvd: total=10, mean=5; nearest-rank p95/p99/max on [3,7] -> 7.
    assert "10.0" in cvd_line and "5.0" in cvd_line and "7.0" in cvd_line
    formula_line = next(line for line in lines if line.startswith("formula "))
    assert "14.0" in formula_line  # formula не включает cvd


async def test_run_one_ok_times_and_calls_run_recalc() -> None:
    with patch.object(
        pg,
        "run_recalc",
        new=AsyncMock(return_value=CalcRunResult(processed_codes=["phq9", "gad7"], processed=2)),
    ) as run_recalc:
        outcome = await pg.run_one(
            {"clientId": "aaaa", "parameterCodes": [PARAMETER_CODE_AGE]},
            catalogs=_FAKE_CATALOGS,
        )
    run_recalc.assert_awaited_once()
    assert outcome.patient_id == "aaaa"
    assert outcome.status == "ok"
    # Границы прогона — сырые отсчёты perf_counter, длительность выводится из них.
    assert outcome.ended >= outcome.started
    assert outcome.elapsed_ms >= 0.0
    # Возврат run_recalc пробрасывается как коды пересчитанных инструментов (tuple).
    assert outcome.instrument_codes == ("phq9", "gad7")
    # Sink передаётся в run_recalc; на «ok» он не None (реальный CalcHandler проставил бы ran=True).
    assert outcome.steps is not None
    assert cast(_Call, run_recalc.await_args).kwargs["timings"] is outcome.steps


async def test_run_one_empty_codes_is_noop() -> None:
    with patch.object(pg, "run_recalc", new=AsyncMock(return_value=CalcRunResult())):
        outcome = await pg.run_one(
            {"clientId": "aaaa", "parameterCodes": []},
            catalogs=_FAKE_CATALOGS,
        )
    assert outcome.status == "no-op"
    assert outcome.instrument_codes == ()


async def test_run_one_malformed_payload_is_invalid() -> None:
    with patch.object(pg, "run_recalc", new=AsyncMock()) as run_recalc:
        outcome = await pg.run_one(
            {"parameterCodes": None},
            catalogs=_FAKE_CATALOGS,
        )  # no clientId
    run_recalc.assert_not_awaited()
    assert outcome.status == "invalid"
    assert outcome.instrument_codes == ()
    # Пересчёта не было — границы схлопнуты, длительность ровно 0.
    assert outcome.elapsed_ms == 0.0
    # invalid: хендлер не запускался — sink отсутствует (в breakdown команда не войдёт).
    assert outcome.steps is None


async def test_run_batch_builds_indexed_timings() -> None:
    selected = [("a", {"clientId": "aaaa", "parameterCodes": None})] * 2
    with patch.object(
        pg, "run_recalc", new=AsyncMock(return_value=CalcRunResult(processed_codes=["phq9"], processed=1))
    ):
        timings = await pg._run_batch(selected, catalogs=_FAKE_CATALOGS)
    assert [t.run_index for t in timings] == [1, 2]
    assert all(t.total_runs == 2 and t.key == "a" for t in timings)
    assert all(t.instrument_codes == ("phq9",) for t in timings)
