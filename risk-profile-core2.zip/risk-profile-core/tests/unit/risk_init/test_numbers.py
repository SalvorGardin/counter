"""Unit-тесты parse_positive_float — разбора сырого patients_parameters.value.

Функция общая для risk-communication (деривация bmi по cq_040/cq_050) и risk-event
(реконсиляция осиротевшего bmi), и её краевые случаи стоят дороже обычного: в `value` лежит
текст произвольного содержания, а рост стоит в знаменателе ИМТ. До сих пор они проверялись
только косвенно, через медленные интеграционные тесты с БД — здесь без БД и по существу.
"""

import pytest

from src.services.risk_init.domain.numbers import parse_positive_float


@pytest.mark.parametrize(
    "value",
    [
        None,  # параметра нет вовсе
        "",  # пустая строка: float("") бросает ValueError
        "нет данных",  # свободный текст из cq_040/cq_050
        "0",  # рост=0 уронил бы compute_bmi через ZeroDivisionError
        "0.0",
        "-1",  # coerce_numeric_answer отрицательные пропускает, а ИМТ от них бессмыслен
        "-175.5",
    ],
)
def test_returns_none_for_unusable_value(value: str | None) -> None:
    assert parse_positive_float(value) is None


@pytest.mark.parametrize(("value", "expected"), [("175", 175.0), ("72.4", 72.4), ("0.01", 0.01)])
def test_parses_positive_number(value: str, expected: float) -> None:
    assert parse_positive_float(value) == expected
