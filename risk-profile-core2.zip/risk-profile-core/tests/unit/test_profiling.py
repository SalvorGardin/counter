"""Tests for the yappi rolling profiler (src/profiling.py)."""

import pstats

import pytest

from src.profiling import RollingProfiler, _empty_pstats_bytes, _keep_project_func


class _FakeStat:
    def __init__(self, module: str) -> None:
        self.module = module


def test_keep_project_func_includes_calc_and_request_paths():
    assert _keep_project_func(_FakeStat("/app/src/calc/handler.py"))
    assert _keep_project_func(_FakeStat("/app/src/api/v1/risk_profile/router.py"))
    assert _keep_project_func(_FakeStat("/app/src/services/risk_event/domain/service.py"))


def test_keep_project_func_excludes_third_party_and_stdlib():
    assert not _keep_project_func(_FakeStat("/venv/lib/python3.12/site-packages/fastapi/routing.py"))
    assert not _keep_project_func(_FakeStat("/usr/lib/python3.12/asyncio/events.py"))
    assert not _keep_project_func(_FakeStat(""))


def test_empty_pstats_bytes_is_loadable(tmp_path):
    out = tmp_path / "empty.prof"
    out.write_bytes(_empty_pstats_bytes())
    # Должен распарситься как валидный pstats без исключений.
    pstats.Stats(str(out))


@pytest.mark.asyncio
async def test_dump_pstats_returns_valid_prof_when_no_data(tmp_path):
    profiler = RollingProfiler(retention_minutes=1, bucket_seconds=1)
    await profiler.start()
    try:
        data = await profiler.dump_pstats()
        out = tmp_path / "p.prof"
        out.write_bytes(data)
        pstats.Stats(str(out))  # не падает
    finally:
        await profiler.stop()


@pytest.mark.asyncio
async def test_rotation_evicts_buckets_beyond_window(tmp_path):
    # Окно 1 бакет: после двух ротаций на диске остаётся ровно один.
    profiler = RollingProfiler(retention_minutes=1, bucket_seconds=60)
    profiler._dir = tmp_path
    assert profiler._max_buckets == 1

    await profiler._rotate()
    await profiler._rotate()

    assert len(profiler._buckets) == 1
    existing = list(tmp_path.glob("bucket-*.ystat"))
    assert len(existing) == 1


@pytest.mark.asyncio
async def test_max_buckets_derived_from_window():
    profiler = RollingProfiler(retention_minutes=20, bucket_seconds=60)
    assert profiler._max_buckets == 20
    profiler = RollingProfiler(retention_minutes=5, bucket_seconds=30)
    assert profiler._max_buckets == 10
