"""Таблица решений подбора рекомендованных исследований.

Вход функций — то, что отдаёт индекс каталога: неактивные исследования в него не попадают,
поэтому строк с `status = inactive` здесь нет (проверка самого индекса —
tests/unit/infra/test_http_catalog.py).
"""

import uuid
from collections.abc import Mapping

import pytest

from src.services.risk_profile.domain.constants import ExaminationCategory, ExaminationType
from src.services.risk_profile.domain.examinations import (
    build_examination_lists,
    select_checkup_examinations,
    select_disease_examinations,
)
from src.services.risk_profile.domain.exceptions import ExaminationCategoryInvalidError
from src.services.risk_profile.domain.models import CheckupExaminationView, DiseaseExaminationView, ExaminationView
from tests.consts import GENDER_FEMALE, GENDER_MALE

SYSTEM = "SYS"
LAB = ExaminationView(uuid.uuid4(), ExaminationType.LABORATORY)
OTHER_LAB = ExaminationView(uuid.uuid4(), ExaminationType.LABORATORY)
THIRD_LAB = ExaminationView(uuid.uuid4(), ExaminationType.LABORATORY)
INSTRUMENTAL = ExaminationView(uuid.uuid4(), ExaminationType.INSTRUMENTAL)


def _select(disease_codes: list[str], links: Mapping[str, tuple[DiseaseExaminationView, ...]]) -> list[uuid.UUID]:
    selected = select_disease_examinations(
        system_code=SYSTEM, disease_codes=disease_codes, examinations_by_disease=links
    )
    return [item.examination.code for item in selected]


def test_group_with_examinations_is_selected() -> None:
    links = {"d1": (DiseaseExaminationView(LAB, ExaminationCategory.BASIC),)}

    assert _select(["d1"], links) == [LAB.code]


def test_group_without_examinations_selects_nothing() -> None:
    """Пустой отбор — сигнал сервису перейти к общему чек-апу системы."""
    assert _select(["d1"], {}) == []


def test_partially_filled_groups_select_only_the_filled_one() -> None:
    links = {"d1": (DiseaseExaminationView(LAB, ExaminationCategory.EXTENDED),)}

    assert _select(["d1", "d2"], links) == [LAB.code]


def test_no_group_with_examinations_selects_nothing() -> None:
    links = {"d3": (DiseaseExaminationView(LAB, ExaminationCategory.BASIC),)}

    assert _select(["d1", "d2"], links) == []


@pytest.mark.parametrize(
    "categories",
    [
        (ExaminationCategory.EXTENDED, ExaminationCategory.BASIC),
        (ExaminationCategory.BASIC, ExaminationCategory.EXTENDED),
    ],
)
def test_same_examination_in_two_groups_keeps_basic(
    categories: tuple[ExaminationCategory, ExaminationCategory],
) -> None:
    """Анализ, пришедший по двум группам как `basic` и `extended`, входит в базовый пакет один
    раз независимо от порядка групп; дополнительных анализов у системы не остаётся, поэтому
    расширенный пакет пуст."""
    first, second = categories
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1", "d2"],
        examinations_by_disease={
            "d1": (DiseaseExaminationView(LAB, first),),
            "d2": (DiseaseExaminationView(LAB, second),),
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == (LAB.code,)
    assert lists.extended == ()
    assert lists.diagnostics == ()


def test_same_instrumental_in_two_groups_appears_once() -> None:
    """Дедупликация по коду работает и для `diagnostics`, где категории нет; оба пакета
    лабораторных анализов при этом пустые."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1", "d2"],
        examinations_by_disease={
            "d1": (DiseaseExaminationView(INSTRUMENTAL, None),),
            "d2": (DiseaseExaminationView(INSTRUMENTAL, None),),
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == ()
    assert lists.extended == ()
    assert lists.diagnostics == (INSTRUMENTAL.code,)


def test_instrumental_goes_to_diagnostics() -> None:
    """Инструментальное исследование группы входит только в `diagnostics` и ни в один из пакетов
    лабораторных анализов."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1"],
        examinations_by_disease={
            "d1": (
                DiseaseExaminationView(INSTRUMENTAL, None),
                DiseaseExaminationView(OTHER_LAB, ExaminationCategory.EXTENDED),
            )
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == ()
    assert lists.extended == (OTHER_LAB.code,)
    assert lists.diagnostics == (INSTRUMENTAL.code,)


def test_system_without_laboratory_examinations_returns_two_empty_packages() -> None:
    """У системы только инструментальные исследования: оба пакета — пустые перечни, а сама
    система из ответа не выпадает, потому что `diagnostics` непуст."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1"],
        examinations_by_disease={"d1": (DiseaseExaminationView(INSTRUMENTAL, None),)},
    )

    lists = build_examination_lists(selected)

    assert lists.basic == ()
    assert lists.extended == ()
    assert lists.diagnostics == (INSTRUMENTAL.code,)


def test_basic_and_extended_analyses_fill_both_packages() -> None:
    """При наличии дополнительных анализов базовый пакет содержит только базовые UUID, а
    расширенный — полный набор лабораторных анализов системы, где базовый пакет является его
    подпоследовательностью в порядке первого появления исследования в отборе."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1", "d2"],
        examinations_by_disease={
            "d1": (
                DiseaseExaminationView(LAB, ExaminationCategory.BASIC),
                DiseaseExaminationView(OTHER_LAB, ExaminationCategory.EXTENDED),
            ),
            "d2": (DiseaseExaminationView(THIRD_LAB, ExaminationCategory.BASIC),),
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == (LAB.code, THIRD_LAB.code)
    assert lists.extended == (LAB.code, OTHER_LAB.code, THIRD_LAB.code)
    assert lists.diagnostics == ()


def test_shared_analysis_appears_once_in_a_filled_extended_package() -> None:
    """Анализ, пришедший по двум группам, входит в непустой расширенный пакет один раз: пакеты
    строятся из одного дедуплицированного перечня, а не конкатенацией базового и дополнительного."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1", "d2"],
        examinations_by_disease={
            "d1": (
                DiseaseExaminationView(LAB, ExaminationCategory.EXTENDED),
                DiseaseExaminationView(OTHER_LAB, ExaminationCategory.EXTENDED),
            ),
            "d2": (DiseaseExaminationView(LAB, ExaminationCategory.BASIC),),
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == (LAB.code,)
    assert lists.extended == (LAB.code, OTHER_LAB.code)


def test_only_basic_analyses_leave_the_extended_package_empty() -> None:
    """Дополнительных анализов у системы нет — расширенный пакет остаётся пустым перечнем и
    базовый в нём не повторяется."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1"],
        examinations_by_disease={
            "d1": (
                DiseaseExaminationView(LAB, ExaminationCategory.BASIC),
                DiseaseExaminationView(OTHER_LAB, ExaminationCategory.BASIC),
            )
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == (LAB.code, OTHER_LAB.code)
    assert lists.extended == ()


def test_only_extended_analyses_leave_the_basic_package_empty() -> None:
    """Базовых анализов у системы нет — базовый пакет пустой, а расширенный содержит UUID
    дополнительных анализов."""
    selected = select_disease_examinations(
        system_code=SYSTEM,
        disease_codes=["d1"],
        examinations_by_disease={
            "d1": (
                DiseaseExaminationView(LAB, ExaminationCategory.EXTENDED),
                DiseaseExaminationView(OTHER_LAB, ExaminationCategory.EXTENDED),
            )
        },
    )

    lists = build_examination_lists(selected)

    assert lists.basic == ()
    assert lists.extended == (LAB.code, OTHER_LAB.code)


def test_checkup_filters_rows_by_client_gender() -> None:
    rows = (
        CheckupExaminationView(LAB, None),
        CheckupExaminationView(OTHER_LAB, GENDER_FEMALE),
        CheckupExaminationView(INSTRUMENTAL, GENDER_MALE),
    )

    selected = select_checkup_examinations(rows=rows, gender=GENDER_MALE)

    assert [item.examination.code for item in selected] == [LAB.code, INSTRUMENTAL.code]


def test_checkup_analyses_go_only_to_the_basic_package() -> None:
    """В `system_checkup_examinations` категории нет: лабораторные анализы чек-апа входят только
    в базовый пакет, расширенный остаётся пустым перечнем."""
    rows = (CheckupExaminationView(LAB, None), CheckupExaminationView(INSTRUMENTAL, None))

    lists = build_examination_lists(select_checkup_examinations(rows=rows, gender=GENDER_MALE))

    assert lists.basic == (LAB.code,)
    assert lists.extended == ()
    assert lists.diagnostics == (INSTRUMENTAL.code,)


@pytest.mark.parametrize(
    ("link", "expected_category"),
    [
        (DiseaseExaminationView(LAB, None), None),
        (DiseaseExaminationView(LAB, "unknown"), "unknown"),
        (DiseaseExaminationView(INSTRUMENTAL, ExaminationCategory.BASIC), ExaminationCategory.BASIC),
    ],
)
def test_category_inconsistent_with_type_raises(link: DiseaseExaminationView, expected_category: str | None) -> None:
    with pytest.raises(ExaminationCategoryInvalidError) as exc_info:
        select_disease_examinations(system_code=SYSTEM, disease_codes=["d1"], examinations_by_disease={"d1": (link,)})

    error = exc_info.value
    assert (error.system_code, error.disease_code) == (SYSTEM, "d1")
    assert error.examination_code == link.examination.code
    assert error.category == expected_category
