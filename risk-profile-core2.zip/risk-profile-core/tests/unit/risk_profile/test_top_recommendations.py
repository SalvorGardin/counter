"""Unit-тесты _build_top_recommendations (шаг 7 wiki Risk-profile).

Правила (Внешние-контракты-API/Risk-profile §7):
- Основная выборка — ТОЛЬКО risk_factor_group систем с risk_level high/medium.
  Порядок: high → medium, затем по systems.rang (возр.), затем по позиции risk_factors_code.
- Дополнение — если в основной выборке меньше 5 позиций, хвост добивается common_group
  (по systems.rang), пока не наберётся 5 или не закончатся кандидаты. common_group идёт
  ПОСЛЕ risk_factor-выдачи, не выше неё.
- Финализация — дедуп по title (первый по порядку сортировки), не более 5, пустой → None.
"""

from src.api.v1.risk_profile.schemas import Recommendation
from src.services.risk_profile.domain.constants import (
    RECOMMENDATIONS_GROUP_COMMON,
    RECOMMENDATIONS_GROUP_RISK_FACTOR,
)
from src.services.risk_profile.service import _build_top_recommendations, _TopRecCandidate


def _cand(
    title: str,
    *,
    rang: int,
    risk_level: str,
    group: str = RECOMMENDATIONS_GROUP_RISK_FACTOR,
    rf_index: int = 0,
) -> _TopRecCandidate:
    return _TopRecCandidate(
        rec=Recommendation(title=title, details=None),
        system_rang=rang,
        risk_level=risk_level,
        group=group,
        rf_index=rf_index,
    )


def _titles(result: list[Recommendation] | None) -> list[str]:
    assert result is not None
    return [r.title for r in result]


def test_empty_returns_none() -> None:
    assert _build_top_recommendations([]) is None


def test_high_before_medium() -> None:
    cands = [
        _cand("m1", rang=1, risk_level="medium"),
        _cand("h1", rang=9, risk_level="high"),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["h1", "m1"]


def test_same_level_sorted_by_rang() -> None:
    cands = [
        _cand("b", rang=5, risk_level="high"),
        _cand("a", rang=2, risk_level="high"),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["a", "b"]


def test_within_system_sorted_by_rf_index() -> None:
    cands = [
        _cand("second", rang=1, risk_level="high", rf_index=1),
        _cand("first", rang=1, risk_level="high", rf_index=0),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["first", "second"]


def test_common_group_supplements_after_risk_factor() -> None:
    # risk_factor идёт первым, common добивает хвост (не выше risk_factor).
    cands = [
        _cand("rf", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
        _cand("common", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["rf", "common"]


def test_fewer_than_limit_padded_with_common() -> None:
    cands = [
        _cand("rf1", rang=1, risk_level="high", rf_index=0),
        _cand("rf2", rang=1, risk_level="high", rf_index=1),
        _cand("c1", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
        _cand("c2", rang=2, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    # risk_factor first (by rf_index), then common by rang, до лимита 5.
    assert _titles(_build_top_recommendations(cands)) == ["rf1", "rf2", "c1", "c2"]


def test_supplement_stops_at_limit_five() -> None:
    # 4 risk_factor + 3 common: добиваем только до 5, common обрезается.
    cands = [
        _cand("rf1", rang=1, risk_level="high", rf_index=0),
        _cand("rf2", rang=1, risk_level="high", rf_index=1),
        _cand("rf3", rang=1, risk_level="high", rf_index=2),
        _cand("rf4", rang=1, risk_level="high", rf_index=3),
        _cand("c1", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
        _cand("c2", rang=2, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
        _cand("c3", rang=3, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["rf1", "rf2", "rf3", "rf4", "c1"]


def test_common_dedup_against_risk_factor_title() -> None:
    # common с тем же title, что у risk_factor — отбрасывается дедупом (первый по порядку — risk_factor).
    cands = [
        _cand("dup", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
        _cand("dup", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
        _cand("c2", rang=2, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["dup", "c2"]


def test_low_does_not_contribute_when_high_present() -> None:
    cands = [
        _cand("low-rf", rang=1, risk_level="low"),
        _cand("high-rf", rang=9, risk_level="high"),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["high-rf"]


def test_dedup_by_title_and_limit_five() -> None:
    cands = [
        _cand("X", rang=1, risk_level="high"),
        _cand("X", rang=2, risk_level="high"),
        _cand("Y", rang=3, risk_level="high"),
        _cand("Z", rang=4, risk_level="medium"),
        _cand("W", rang=5, risk_level="medium"),
        _cand("V", rang=6, risk_level="medium"),
        _cand("U", rang=7, risk_level="medium"),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["X", "Y", "Z", "W", "V"]


def test_only_common_when_high_has_no_risk_factor_recs() -> None:
    # high-система существует, но risk_factor_group рекомендаций нет → топ целиком из common_group.
    cands = [
        _cand("common", rang=1, risk_level="high", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["common"]


def test_only_common_when_no_high_or_medium() -> None:
    cands = [
        _cand("c-rang5", rang=5, risk_level="low", group=RECOMMENDATIONS_GROUP_COMMON),
        _cand("c-rang2", rang=2, risk_level="low", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    assert _titles(_build_top_recommendations(cands)) == ["c-rang2", "c-rang5"]


def test_only_low_with_no_common_returns_none() -> None:
    # low-система без common_group рекомендаций (risk_factor у low не матчится) → None
    cands = [
        _cand("orphan-rf", rang=1, risk_level="low", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
    ]
    assert _build_top_recommendations(cands) is None
