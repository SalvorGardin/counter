"""Сопоставление значения параметра с условиями risk_factors (шаг 5).

Ошибка здесь молча добавляет или теряет фактор риска у пациента, поэтому каждый исход
решения зафиксирован отдельным кейсом.
"""

import logging

import pytest

from src.services.risk_profile.domain.range_match import value_matches


@pytest.mark.parametrize(
    ("value", "param_value", "expected"),
    [
        ("Да", "Да", True),
        ("Нет", "Да", False),
        ("10", "10.0", False),  # строгое равенство по строке, без приведения к числу
    ],
)
def test_param_value_is_exact_string_equality(value: str, param_value: str, expected: bool) -> None:
    assert value_matches(value=value, param_value=param_value, min_param_value=None, max_param_value=None) is expected


def test_no_condition_at_all_does_not_apply() -> None:
    """Ни param_value, ни границ — фактор не применяется.

    Вернуть True значило бы навесить фактор на всех пациентов подряд.
    """
    assert value_matches(value="42", param_value=None, min_param_value=None, max_param_value=None) is False


@pytest.mark.parametrize(
    ("value", "min_v", "max_v", "expected"),
    [
        ("30", "30", "40", True),  # нижняя граница включительна
        ("40", "30", "40", True),  # верхняя граница включительна
        ("29.9", "30", "40", False),
        ("40.1", "30", "40", False),
        ("35", "30", "40", True),
        ("1000", "30", None, True),  # диапазон только снизу
        ("29", "30", None, False),
        ("1", None, "40", True),  # диапазон только сверху
        ("41", None, "40", False),
    ],
)
def test_numeric_range_is_inclusive(value: str, min_v: str | None, max_v: str | None, expected: bool) -> None:
    assert value_matches(value=value, param_value=None, min_param_value=min_v, max_param_value=max_v) is expected


@pytest.mark.parametrize(
    ("value", "min_v", "max_v", "expected"),
    [
        ("b", "a", "c", True),  # нечисловое значение и границы — лексикографическое сравнение
        ("a", "b", "c", False),
        ("d", "a", "c", False),
        ("b", "b", "b", True),
        ("5", "a", "c", False),  # числовое значение против нечисловых границ: "5" < "a"
        ("abc", "1", "10", False),  # нечисловое значение против числовых границ: "abc" > "10"
    ],
)
def test_string_fallback_when_value_or_bound_is_non_numeric(
    value: str, min_v: str | None, max_v: str | None, expected: bool
) -> None:
    assert value_matches(value=value, param_value=None, min_param_value=min_v, max_param_value=max_v) is expected


def test_string_fallback_is_logged(caplog: pytest.LogCaptureFixture) -> None:
    """Переход на строковое сравнение — диагностика для разбора: обычно это ошибка данных в справочнике."""
    with caplog.at_level(logging.DEBUG, logger="app"):
        value_matches(value="abc", param_value=None, min_param_value="1", max_param_value="10")

    assert "range_match falling back to string comparison" in caplog.text
