"""Unit-тесты _to_recommendations: дедупликация risk.recommendations по name (шаг аналогичен 7.3).

- Порядок групп до дедупликации: risk_factor_group, затем common_group; при совпадении name
  остаётся первое вхождение (побеждает risk_factor_group).
- Одноимённые записи с ОДИНАКОВЫМ text схлопываются молча (штатная структура каталога).
- Одноимённые записи с РАЗНЫМ text ВНУТРИ группы → logger.warning (аномалия сида каталога).
  Межгрупповое расхождение text — не аномалия (крит. 2), не логируется.
"""

from unittest.mock import patch

from src.services.risk_profile.domain.constants import (
    RECOMMENDATIONS_GROUP_COMMON,
    RECOMMENDATIONS_GROUP_RISK_FACTOR,
)
from src.services.risk_profile.domain.models import RecommendationView
from src.services.risk_profile.service import _names_with_divergent_text, _to_recommendations


def _view(
    name: str,
    *,
    text: str | None = None,
    group: str = RECOMMENDATIONS_GROUP_RISK_FACTOR,
) -> RecommendationView:
    return RecommendationView(name=name, text=text, group=group, risk_factors_code=None)


def _titles(views: list[RecommendationView]) -> list[str]:
    return [r.title for r in _to_recommendations(views, system_code="CVD")]


def test_empty_returns_empty_list() -> None:
    assert _to_recommendations([], system_code="CVD") == []


def test_distinct_names_ordered_risk_factor_then_common() -> None:
    views = [
        _view("common-1", group=RECOMMENDATIONS_GROUP_COMMON),
        _view("rf-1", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
    ]
    # Порядок задаёт группа, а не порядок в списке: risk_factor_group первым.
    assert _titles(views) == ["rf-1", "common-1"]


def test_same_name_same_text_collapses_to_one() -> None:
    views = [
        _view("Контроль давления", text="следите за АД"),
        _view("Контроль давления", text="следите за АД"),
    ]
    assert _titles(views) == ["Контроль давления"]


def test_cross_group_same_name_prefers_risk_factor() -> None:
    views = [
        _view("Здоровый образ жизни", text="общий", group=RECOMMENDATIONS_GROUP_COMMON),
        _view("Здоровый образ жизни", text="по фактору", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
    ]
    result = _to_recommendations(views, system_code="CVD")
    assert [r.title for r in result] == ["Здоровый образ жизни"]
    assert result[0].details == "по фактору"


def test_names_with_divergent_text_flags_only_divergent() -> None:
    views = [
        _view("A", text="x"),
        _view("A", text="x"),  # тот же — не аномалия
        _view("B", text="p"),
        _view("B", text="q"),  # разный — аномалия
        _view("C", text=None),
        _view("C", text="z"),  # None vs текст — аномалия
    ]
    assert _names_with_divergent_text(views) == {"B", "C"}


def test_intra_group_divergent_text_logs_warning() -> None:
    views = [
        _view("Контроль давления", text="ранний", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
        _view("Контроль давления", text="поздний", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
    ]
    with patch("src.services.risk_profile.service.logger") as mock_logger:
        result = _to_recommendations(views, system_code="CVD")

    assert [r.title for r in result] == ["Контроль давления"]
    mock_logger.warning.assert_called_once()
    log_context = mock_logger.warning.call_args.kwargs["extra"]["log_context"]
    assert log_context["system_code"] == "CVD"
    assert log_context["names"] == ["Контроль давления"]


def test_benign_duplicates_do_not_log() -> None:
    # Много risk_factor_code → одно name/text (штатный каталог): дедупликация без предупреждений.
    views = [_view("Контроль давления", text="следите за АД") for _ in range(4)]
    with patch("src.services.risk_profile.service.logger") as mock_logger:
        _to_recommendations(views, system_code="CVD")
    mock_logger.warning.assert_not_called()


def test_cross_group_divergent_text_does_not_log() -> None:
    # Разный text у одного name В РАЗНЫХ группах — дизайн (крит. 2), не аномалия.
    views = [
        _view("Здоровый образ жизни", text="по фактору", group=RECOMMENDATIONS_GROUP_RISK_FACTOR),
        _view("Здоровый образ жизни", text="общий", group=RECOMMENDATIONS_GROUP_COMMON),
    ]
    with patch("src.services.risk_profile.service.logger") as mock_logger:
        _to_recommendations(views, system_code="CVD")
    mock_logger.warning.assert_not_called()
