"""One-shot провижининга топиков: ретраи на неготовом брокере и поведение при исчерпании попыток.

Порядок старта на стенде — `kafka-init` до app-tier: TCP-порт брокера открывается раньше, чем
SASL listener и ACL, поэтому первые попытки штатно падают. Если этот воркер тихо завершится, не
создав топики, продюсер приложения закэширует «unauthorized»-топик, и лечится это только рестартом
приложения — молчаливого успеха тут быть не должно.
"""

from unittest.mock import AsyncMock, patch

import pytest

import src.workers.kafka_init as kafka_init
from src.infra.kafka.exceptions import KafkaInitError
from tests.conftest import LogSink


def _topic_names() -> list[str]:
    return [spec.name for spec in kafka_init._topic_specs()]


def test_topic_specs_cover_all_application_topics() -> None:
    """Список топиков берётся из настроек: забытый тут топик приложение не создаст нигде больше."""
    topics = kafka_init.settings.kafka.topics
    assert _topic_names() == [
        topics.test,
        topics.risk_calculation,
        topics.recalc_commands,
        topics.emr_biomarkers,
    ]


def test_recalc_commands_is_the_only_multi_partition_topic() -> None:
    """Число партиций команд пересчёта — потолок параллелизма воркеров, оно приходит из настроек.

    Остальные топики однопартиционные осознанно (низкий объём, проще порядок), и подмена этого
    числа на дефолт тихо ограничила бы пересчёт одним воркером.
    """
    by_name = {spec.name: spec.num_partitions for spec in kafka_init._topic_specs()}
    commands = kafka_init.settings.kafka.topics.recalc_commands

    assert by_name[commands] == kafka_init.settings.kafka.recalc_commands_partitions
    assert [count for name, count in by_name.items() if name != commands] == [1, 1, 1]


async def test_disabled_kafka_skips_provisioning_entirely(captured_app_logs: LogSink) -> None:
    """`kafka.enabled=False` — брокера нет, к нему не идём вовсе."""
    with (
        patch.object(kafka_init.settings.kafka, "enabled", False),
        patch.object(kafka_init, "ensure_topics", AsyncMock()) as ensure,
    ):
        await kafka_init._main()

    ensure.assert_not_awaited()
    assert "kafka.init skipped — kafka disabled" in captured_app_logs.messages()


async def test_first_attempt_success_does_not_sleep(captured_app_logs: LogSink) -> None:
    with (
        patch.object(kafka_init.settings.kafka, "enabled", True),
        patch.object(kafka_init, "ensure_topics", AsyncMock()) as ensure,
        patch.object(kafka_init.asyncio, "sleep", AsyncMock()) as sleep,
    ):
        await kafka_init._main()

    ensure.assert_awaited_once()
    sleep.assert_not_awaited()
    assert captured_app_logs.context_of("kafka.init done")["attempts"] == 1


async def test_retries_until_broker_accepts_and_reports_attempt_number(captured_app_logs: LogSink) -> None:
    """Брокер поднялся с третьей попытки: провижининг доходит до конца, а номер попытки — в логе.

    Номер нужен на разборе: «done с первой» и «done с пятой» — это исправный стенд и стенд, который
    вот-вот перестанет успевать за таймаутом старта.
    """
    ensure = AsyncMock(side_effect=[KafkaInitError("no listener"), KafkaInitError("no acl"), None])
    with (
        patch.object(kafka_init.settings.kafka, "enabled", True),
        patch.object(kafka_init, "ensure_topics", ensure),
        patch.object(kafka_init.asyncio, "sleep", AsyncMock()) as sleep,
    ):
        await kafka_init._main()

    assert ensure.await_count == 3
    # Задержки берутся по порядку из _RETRY_DELAYS — растущий backoff, а не фиксированная пауза.
    assert [call.args[0] for call in sleep.await_args_list] == list(kafka_init._RETRY_DELAYS[:2])
    assert captured_app_logs.context_of("kafka.init done")["attempts"] == 3


async def test_exhausted_retries_reraise_last_error_with_traceback(captured_app_logs: LogSink) -> None:
    """Попытки кончились — ошибка уходит наружу, а не гасится: exit code воркера должен быть ненулевым.

    В лог обязана попасть последняя ошибка со стектрейсом, иначе на стенде видно только «под не
    поднялся», без причины.
    """
    last = KafkaInitError("broker still down")
    ensure = AsyncMock(side_effect=[KafkaInitError("earlier"), *([last] * len(kafka_init._RETRY_DELAYS))])
    with (
        patch.object(kafka_init.settings.kafka, "enabled", True),
        patch.object(kafka_init, "ensure_topics", ensure),
        patch.object(kafka_init.asyncio, "sleep", AsyncMock()) as sleep,
        pytest.raises(KafkaInitError) as exc_info,
    ):
        await kafka_init._main()

    assert exc_info.value is last
    assert ensure.await_count == len(kafka_init._RETRY_DELAYS)
    # Спим после КАЖДОЙ неудачи, включая последнюю: провижининг не должен ретраиться быстрее backoff-а.
    assert sleep.await_count == len(kafka_init._RETRY_DELAYS)
    assert captured_app_logs.context_of("kafka.init failed after retries")["attempts"] == len(kafka_init._RETRY_DELAYS)
    assert "KafkaInitError" in captured_app_logs.output()
