"""Unit-тесты воркера emr_biomarkers_consumer: жизненный цикл и параметры подписки.

Kafka не поднимается — консюмер подменяется моком; проверяем ровно то, что видно снаружи:
создаётся ли консюмер при выключенном флаге и на какой топик и в какой группе он подписывается.
"""

import os
import signal as signal_module
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import src.workers.consumer_runtime as consumer_runtime
import src.workers.emr_biomarkers_consumer as emr_consumer
from src.emr_biomarkers.processing import EmrBiomarkersProcessor
from src.emr_biomarkers.service import handle_emr_biomarkers_record
from src.infra.kafka import raw_decoder


@pytest.fixture(autouse=True)
def _ehr_runtime(monkeypatch: pytest.MonkeyPatch, no_primary_runtime: None) -> None:
    """Процесс до старта: основной рантайм поднимает сам `_main` консюмера, под ролью ЭМК."""
    # Логин рантайма сверяется с БД на старте; здесь БД нет, а проверка не предмет этих тестов —
    # её держит tests/integration/db_isolation/test_runtime_login_check.py.
    monkeypatch.setattr(emr_consumer, "verify_runtime_login", AsyncMock())


def _fake_health_server() -> MagicMock:
    """Подменяет uvicorn.Server: serve() завершается сразу (порт не биндится), should_exit
    выставляется реальным атрибутом — тесты _main не поднимают настоящий сервер проб."""
    server = MagicMock()
    server.serve = AsyncMock()
    server.should_exit = False
    return server


def _patched_resources() -> tuple[AsyncMock, AsyncMock, AsyncMock]:
    """Внешние ресурсы воркера: продюсер команд пересчёта и пул соединений.

    В unit-тестах ни Kafka, ни базы нет, а жизненный цикл воркера их поднимает и гасит —
    поэтому подменяются моками, по которым же проверяется, что гашение вызвано.
    """
    return AsyncMock(), AsyncMock(), AsyncMock()


def _patched_catalog() -> tuple[AsyncMock, object]:
    catalog = object()
    return AsyncMock(return_value=SimpleNamespace(emr_biomarkers=catalog)), catalog


def _stopping_consumer() -> MagicMock:
    """Мок консюмера, который на старте шлёт SIGTERM: к этому моменту _run уже повесил
    обработчик сигнала, поэтому воркер уходит в штатный shutdown вместо бесконечного цикла."""
    consumer = MagicMock()
    consumer.start = AsyncMock(side_effect=lambda: os.kill(os.getpid(), signal_module.SIGTERM))
    consumer.run = AsyncMock()
    consumer.stop = AsyncMock()
    return consumer


@pytest.mark.parametrize(
    ("case", "kafka_enabled", "emr_enabled"),
    [
        ("emr_flag_off", True, False),
        ("kafka_off", False, True),
        ("both_off", False, False),
    ],
)
async def test_idles_without_creating_consumer_when_disabled(
    case: str, kafka_enabled: bool, emr_enabled: bool, monkeypatch: pytest.MonkeyPatch
) -> None:
    """При выключенном флаге воркер простаивает: консюмер не создаётся, пробы поднимаются и гаснут."""
    fake_server = _fake_health_server()
    catalog_builder, _catalog = _patched_catalog()

    monkeypatch.setattr(emr_consumer.settings.kafka, "enabled", kafka_enabled)
    monkeypatch.setattr(emr_consumer.settings.kafka, "emr_biomarkers_enabled", emr_enabled)
    monkeypatch.setattr(emr_consumer.settings, "host", "127.0.0.1")
    monkeypatch.setattr(emr_consumer.settings, "emr_consumer_health_port", 8124)

    with (
        patch.object(consumer_runtime, "build_server", return_value=fake_server) as mock_build,
        patch.object(emr_consumer, "KafkaTopicConsumer") as mock_consumer_cls,
        patch.object(emr_consumer, "catalog_builder", catalog_builder),
        patch.object(emr_consumer, "idle_until_signal", AsyncMock()),
    ):
        await emr_consumer._main()

    mock_consumer_cls.assert_not_called()
    catalog_builder.assert_not_awaited()
    assert mock_build.call_args.kwargs == {"host": "127.0.0.1", "port": 8124}, case
    fake_server.serve.assert_awaited_once()
    assert fake_server.should_exit is True, case


async def test_subscribes_to_emr_topic_in_own_group(monkeypatch: pytest.MonkeyPatch) -> None:
    """При включённом флаге подписка идёт на топик биомаркеров в его собственной группе,
    payload доезжает до обработчика сырым, а сам обработчик связан с обработкой биомаркеров."""
    monkeypatch.setattr(emr_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(emr_consumer.settings.kafka, "emr_biomarkers_enabled", True)
    init_producer, shutdown_producer, shutdown_runtime = _patched_resources()
    catalog_builder, catalog = _patched_catalog()

    with (
        patch.object(consumer_runtime, "build_server", return_value=_fake_health_server()),
        patch.object(emr_consumer, "KafkaTopicConsumer", return_value=_stopping_consumer()) as mock_consumer_cls,
        patch.object(emr_consumer, "catalog_builder", catalog_builder),
        patch.object(emr_consumer, "init_kafka_producer", init_producer),
        patch.object(emr_consumer, "shutdown_kafka_producer", shutdown_producer),
        patch.object(emr_consumer, "shutdown_primary_runtime", shutdown_runtime),
    ):
        await emr_consumer._main()

    kafka = emr_consumer.settings.kafka
    assert mock_consumer_cls.call_args.args == (kafka,)
    kwargs = mock_consumer_cls.call_args.kwargs
    assert kwargs["topic"] == kafka.topics.emr_biomarkers
    assert kwargs["consumer_settings"] == kafka.emr_biomarkers_consumer
    assert kwargs["decoder"] == raw_decoder
    handler = kwargs["record_handler"]
    assert handler.func is handle_emr_biomarkers_record
    # Обработка инжектируется в обработчик записи: разбор о базе и очереди команд не знает.
    assert isinstance(handler.keywords["process"].__self__, EmrBiomarkersProcessor)
    assert handler.keywords["process"].__self__._catalog is catalog
    catalog_builder.assert_awaited_once()


async def test_producer_is_started_before_consumer_and_stopped_on_exit(monkeypatch: pytest.MonkeyPatch) -> None:
    """Продюсер команд пересчёта поднимается до консюмера и гасится на выходе вместе с пулом
    соединений: сообщение, обработанное без продюсера, потеряло бы пересчёт."""
    monkeypatch.setattr(emr_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(emr_consumer.settings.kafka, "emr_biomarkers_enabled", True)
    init_producer, shutdown_producer, shutdown_runtime = _patched_resources()
    catalog_builder, _catalog = _patched_catalog()
    startup_order: list[str] = []
    catalog_builder.side_effect = lambda: startup_order.append("catalog") or catalog_builder.return_value
    init_producer.side_effect = lambda: startup_order.append("producer")

    with (
        patch.object(consumer_runtime, "build_server", return_value=_fake_health_server()),
        patch.object(emr_consumer, "KafkaTopicConsumer", return_value=_stopping_consumer()) as mock_consumer_cls,
        patch.object(emr_consumer, "catalog_builder", catalog_builder),
        patch.object(emr_consumer, "init_kafka_producer", init_producer),
        patch.object(emr_consumer, "shutdown_kafka_producer", shutdown_producer),
        patch.object(emr_consumer, "shutdown_primary_runtime", shutdown_runtime),
    ):
        await emr_consumer._main()

    init_producer.assert_awaited_once()
    catalog_builder.assert_awaited_once()
    assert startup_order == ["catalog", "producer"]
    mock_consumer_cls.assert_called_once()
    shutdown_producer.assert_awaited_once()
    # Дренаж укладывается в остаток общего бюджета остановки, а не отсчитывается заново.
    drain = shutdown_producer.await_args
    assert drain is not None
    assert drain.kwargs["drain_timeout"] > 0
    shutdown_runtime.assert_awaited_once()


async def test_catalog_failure_stops_before_kafka_clients(monkeypatch: pytest.MonkeyPatch) -> None:
    """Неполный справочник роняет включённый воркер до создания producer и consumer."""
    monkeypatch.setattr(emr_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(emr_consumer.settings.kafka, "emr_biomarkers_enabled", True)
    init_producer = AsyncMock()

    with (
        patch.object(consumer_runtime, "build_server", return_value=_fake_health_server()),
        patch.object(emr_consumer, "KafkaTopicConsumer") as consumer_cls,
        patch.object(emr_consumer, "catalog_builder", AsyncMock(side_effect=RuntimeError("catalog unavailable"))),
        patch.object(emr_consumer, "init_kafka_producer", init_producer),
        pytest.raises(RuntimeError, match="catalog unavailable"),
    ):
        await emr_consumer._main()

    init_producer.assert_not_awaited()
    consumer_cls.assert_not_called()


async def test_health_bind_failure_fails_fast_and_stops_server(monkeypatch: pytest.MonkeyPatch) -> None:
    """Порт проб занят на старте → serve() падает; _main пробрасывает сбой ДО старта консюмера
    и всё равно гасит серверную задачу в finally."""
    fake_server = _fake_health_server()
    fake_server.started = False  # порт не забиндился
    fake_server.serve = AsyncMock(side_effect=OSError("address already in use"))

    monkeypatch.setattr(emr_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(emr_consumer.settings.kafka, "emr_biomarkers_enabled", True)

    with (
        patch.object(consumer_runtime, "build_server", return_value=fake_server),
        patch.object(emr_consumer, "KafkaTopicConsumer") as mock_consumer_cls,
        pytest.raises(OSError, match="address already in use"),
    ):
        await emr_consumer._main()

    mock_consumer_cls.assert_not_called()
    assert fake_server.should_exit is True
