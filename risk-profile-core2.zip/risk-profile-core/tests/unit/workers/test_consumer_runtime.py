"""Unit-тесты общего рантайма consumer-воркеров.

Оба воркера гоняют этот код через свои `_main`, но ретрай старта консюмера ни один из них
не проходит: в их тестах брокер поднимается с первой попытки. Здесь закрываем именно его —
он и есть то, ради чего воркер переживает «поднялся раньше брокера» вместо restart-loop.
"""

import asyncio
from typing import cast
from unittest.mock import AsyncMock, MagicMock

import pytest
import uvicorn

import src.workers.consumer_runtime as consumer_runtime
from src.infra.kafka.exceptions import KafkaInitError
from src.workers.health import WorkerHealth


@pytest.fixture(autouse=True)
def _instant_retries(monkeypatch: pytest.MonkeyPatch) -> None:
    """Бэкофф в тестах не ждём: проверяем число попыток, а не длительность пауз."""
    monkeypatch.setattr(consumer_runtime, "_START_RETRY_DELAYS", (0, 0, 0))


async def test_start_retries_until_broker_accepts() -> None:
    """Брокер поднялся позже воркера: первые попытки падают, воркер доживает до успешной."""
    consumer = MagicMock()
    consumer.start = AsyncMock(side_effect=[KafkaInitError("no broker"), KafkaInitError("no broker"), None])

    await consumer_runtime.start_consumer_with_retry(consumer, name="test.consumer")

    assert consumer.start.await_count == 3


async def test_start_gives_up_after_last_attempt() -> None:
    """Попытки исчерпаны — ошибка идёт наверх, чтобы процесс упал ненулевым кодом."""
    consumer = MagicMock()
    consumer.start = AsyncMock(side_effect=KafkaInitError("no broker"))

    with pytest.raises(KafkaInitError, match="no broker"):
        await consumer_runtime.start_consumer_with_retry(consumer, name="test.consumer")

    assert consumer.start.await_count == 3


async def test_start_succeeds_on_first_attempt_without_retry() -> None:
    consumer = MagicMock()
    consumer.start = AsyncMock()

    await consumer_runtime.start_consumer_with_retry(consumer, name="test.consumer")

    assert consumer.start.await_count == 1


# --- Ожидание бинда порта проб ---


class _FakeServer:
    """uvicorn.Server в объёме, который нужен ожиданию старта: флаг `started` и `should_exit`."""

    def __init__(self, *, started: bool = False) -> None:
        self.started = started
        self.should_exit = False


def _fake_server(*, started: bool = False) -> uvicorn.Server:
    """Заглушка под сигнатуру ожидания старта: настоящий Server требует собранный Config."""
    return cast("uvicorn.Server", _FakeServer(started=started))


async def test_health_start_propagates_serve_failure() -> None:
    """serve() упал (типично — порт занят): исключение идёт наверх, процесс падает ненулевым кодом.

    Проглотить его значило бы вступить в consumer-группу с мёртвыми пробами — k8s увёл бы воркер
    в restart-loop, а настоящая причина всплыла бы только на teardown.
    """

    async def _fail() -> None:
        raise OSError("address already in use")

    task = asyncio.create_task(_fail())
    await asyncio.sleep(0)

    with pytest.raises(OSError, match="address already in use"):
        await consumer_runtime._await_health_started(_fake_server(), task, name="test.consumer")


async def test_health_start_rejects_server_that_exited_without_error() -> None:
    """serve() вернулась, не подняв сервер: без своей ошибки воркер поехал бы дальше без проб."""

    async def _exit_quietly() -> None:
        return None

    task = asyncio.create_task(_exit_quietly())
    await asyncio.sleep(0)

    with pytest.raises(RuntimeError, match="health probe server exited before startup"):
        await consumer_runtime._await_health_started(_fake_server(), task, name="test.consumer")


async def test_health_start_times_out_when_port_never_binds(monkeypatch: pytest.MonkeyPatch) -> None:
    """Сервер не забиндил порт за отведённое время — старт считается сбойным, а не медленным."""
    monkeypatch.setattr(consumer_runtime, "_HEALTH_START_TIMEOUT", 0.05)
    task = asyncio.create_task(asyncio.Event().wait())

    with pytest.raises(TimeoutError, match="did not start"):
        await consumer_runtime._await_health_started(_fake_server(), task, name="test.consumer")

    task.cancel()


# --- Падение цикла консюмера ---


async def test_run_loop_crash_is_logged_and_reraised(caplog: pytest.LogCaptureFixture) -> None:
    """Падение `consumer.run()` отличается от штатной остановки: лог + проброс наверх.

    Без проброса `gather` проглотил бы исключение, процесс завершился бы кодом 0, и docker
    молча крутил бы restart-loop без единой записи о причине.
    """
    consumer = MagicMock()
    consumer.start = AsyncMock()
    consumer.stop = AsyncMock()
    consumer.run = AsyncMock(side_effect=RuntimeError("broker went away"))
    health = WorkerHealth()

    with caplog.at_level("ERROR", logger="app"), pytest.raises(RuntimeError, match="broker went away"):
        await consumer_runtime.serve_until_stop(consumer, health, name="test.consumer")

    assert "test.consumer: run loop crashed" in caplog.text
    # Готовность снимается на любом выходе — балансировщик не должен слать трафик в упавший воркер.
    assert health.ready is False
    consumer.stop.assert_awaited_once()
