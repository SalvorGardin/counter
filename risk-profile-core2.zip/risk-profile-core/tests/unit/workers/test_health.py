"""Unit-тесты HTTP-проб здоровья consumer-воркера (src/workers/health.py).

Сервер не поднимаем по-настоящему: гоняем Starlette-app через httpx2 ASGITransport —
быстро и без биндинга портов. Проверяем контракт эндпоинтов и семантику `WorkerHealth.ready`.
"""

import threading
from unittest.mock import patch

import httpx2
import pytest
from prometheus_client import CONTENT_TYPE_LATEST

import src.workers.health as health_module
from src.config import settings
from src.metrics import SERVICE_PREFIX
from src.workers.health import WorkerHealth, build_app, build_server

_RECALC_HISTOGRAMS = (
    f"{SERVICE_PREFIX}_recalc_answer_to_result_seconds",
    f"{SERVICE_PREFIX}_recalc_queue_wait_seconds",
    f"{SERVICE_PREFIX}_recalc_duration_seconds",
)


def _client(app: object) -> httpx2.AsyncClient:
    transport = httpx2.ASGITransport(app=app)  # ty: ignore[invalid-argument-type]
    return httpx2.AsyncClient(transport=transport, base_url="http://health")


@pytest.mark.parametrize(("path", "expected_status"), [("/liveness", "alive"), ("/health", "ok")])
async def test_probe_ok_regardless_of_readiness(path: str, expected_status: str) -> None:
    """Обе пробы отдают 200 независимо от readiness — доказывают лишь, что loop жив."""
    app = build_app(WorkerHealth())
    async with _client(app) as client:
        resp = await client.get(path)
    assert resp.status_code == 200
    assert resp.json() == {"status": expected_status}


async def test_readiness_503_until_ready() -> None:
    """Пока ready=False (окно старта / drain) — 503; после ready=True — 200."""
    health = WorkerHealth()
    app = build_app(health)
    async with _client(app) as client:
        not_ready = await client.get("/readiness")
        assert not_ready.status_code == 503
        assert not_ready.json() == {"status": "not_ready"}

        health.ready = True
        ready = await client.get("/readiness")
        assert ready.status_code == 200
        assert ready.json() == {"status": "ready"}

        # drain: флаг снова снят → снова 503.
        health.ready = False
        assert (await client.get("/readiness")).status_code == 503


def test_build_server_disables_signal_handlers() -> None:
    """uvicorn НЕ должен перехватывать SIGINT/SIGTERM — их ловит сам воркер."""
    server = build_server(WorkerHealth(), host="127.0.0.1", port=8123)
    assert server.config.port == 8123
    assert server.config.access_log is False
    # install_signal_handlers заглушён — вызов ничего не делает и не падает.
    server.install_signal_handlers()  # ty: ignore[unresolved-attribute]


@pytest.mark.parametrize("path", ["/health", "/readiness", "/liveness"])
async def test_probe_paths_exist(path: str) -> None:
    """Все три пути смонтированы (не 404) — контракт совпадает с src/main.py."""
    app = build_app(WorkerHealth())
    async with _client(app) as client:
        resp = await client.get(path)
    assert resp.status_code in (200, 503)


async def test_metrics_exposes_recalc_histograms() -> None:
    """Расчёт живёт в этом процессе, поэтому и его метрики отдаёт он сам, а не процесс app."""
    app = build_app(WorkerHealth())
    async with _client(app) as client:
        resp = await client.get("/metrics")

    assert resp.status_code == 200
    assert resp.headers["content-type"] == CONTENT_TYPE_LATEST
    for name in _RECALC_HISTOGRAMS:
        assert name in resp.text


async def test_metrics_disabled_returns_404_but_probes_stay_alive() -> None:
    """Рубильник метрик не должен задевать пробы: иначе выключение экспозиции убило бы liveness."""
    app = build_app(WorkerHealth())
    with patch.object(settings.metrics, "enabled", False):
        async with _client(app) as client:
            metrics = await client.get("/metrics")
            liveness = await client.get("/liveness")

    assert metrics.status_code == 404
    assert metrics.json() == {"detail": "Metrics endpoint is disabled"}
    assert liveness.status_code == 200


async def test_metrics_are_rendered_outside_the_event_loop() -> None:
    """Сервер проб делит event loop с consumer.run(): синхронная сборка выдачи прямо в хендлере
    конкурировала бы с расчётом и пробами за то же ядро."""
    render_thread: dict[str, int] = {}

    def _record_thread() -> bytes:
        render_thread["ident"] = threading.get_ident()
        return b"# rendered\n"

    app = build_app(WorkerHealth())
    with patch.object(health_module, "render", _record_thread):
        async with _client(app) as client:
            resp = await client.get("/metrics")

    assert resp.status_code == 200
    # Тело теста исполняется в потоке цикла событий — значит сборка ушла в другой поток.
    assert render_thread["ident"] != threading.get_ident()
