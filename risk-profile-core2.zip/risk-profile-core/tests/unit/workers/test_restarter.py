"""Тесты HTTP-поверхности ручки перезапуска (src/workers/restarter.py).

Здесь проверяются только авторизация и отображение отчёта в ответ: что именно перезапускается —
в tests/unit/container_restart, формат Engine API — в tests/unit/infra/test_docker_engine.py.
"""

import httpx2
import pytest
from fastapi import FastAPI

from src.workers.restarter import build_app, get_engine_client
from tests.unit.container_restart.fakes import DEFAULT_CONTAINERS, PROJECT, FakeEngineClient


def _app_for(client: FakeEngineClient) -> FastAPI:
    app = build_app()

    async def _override() -> FakeEngineClient:
        return client

    app.dependency_overrides[get_engine_client] = _override
    return app


def _http(app: FastAPI) -> httpx2.AsyncClient:
    transport = httpx2.ASGITransport(app=app)
    return httpx2.AsyncClient(transport=transport, base_url="http://restarter")


async def test_full_restart_answers_200_with_report(restarter_headers: dict[str, str]) -> None:
    """Перезапущены все сервисы — 200 с поимённым отчётом и без поля `failed`."""
    async with _http(_app_for(FakeEngineClient())) as client:
        resp = await client.post("/restart", headers=restarter_headers)

    assert resp.status_code == 200
    assert resp.json()["restarted"] == DEFAULT_CONTAINERS
    assert "failed" not in resp.json()


async def test_partial_restart_answers_500_keeping_progress(restarter_headers: dict[str, str]) -> None:
    """Частичный успех — 500: тестовой фикстуре достаточно `raise_for_status()`, чтобы не пойти
    дальше с процессом, который держит старый каталог. `restarted` при этом не пустеет."""
    failing = f"{PROJECT}-consumer-2"
    engine = FakeEngineClient(failing=frozenset({failing}))

    async with _http(_app_for(engine)) as client:
        resp = await client.post("/restart", headers=restarter_headers)

    assert resp.status_code == 500
    body = resp.json()
    assert failing in body["failed"]["consumer"]
    assert body["restarted"]["consumer"] == [f"{PROJECT}-consumer-1"]
    assert body["restarted"]["app"] == DEFAULT_CONTAINERS["app"]


@pytest.mark.parametrize("headers", [{}, {"X-Restarter-Api-Key": "wrong-key-value-0000"}])
async def test_restart_requires_restarter_token(headers: dict[str, str]) -> None:
    """Без валидного X-Restarter-Api-Key ручка не перезапускает ничего."""
    engine = FakeEngineClient()
    async with _http(_app_for(engine)) as client:
        resp = await client.post("/restart", headers=headers)

    assert resp.status_code == 401
    assert engine.restarted == []


async def test_test_api_key_does_not_open_restart(auth_headers: dict[str, str]) -> None:
    """Ключ тестового API не годится для перезапуска: он отдаётся браузеру опросника
    (`/questionnaire/config.js`) без авторизации, и общий ключ отдал бы перезапуск процессов
    ядра любому, кто открыл страницу."""
    engine = FakeEngineClient()
    async with _http(_app_for(engine)) as client:
        resp = await client.post("/restart", headers=auth_headers)

    assert resp.status_code == 401
    assert engine.restarted == []


async def test_liveness_needs_no_token() -> None:
    """Проба для compose-healthcheck: без авторизации, как /liveness в остальных процессах."""
    async with _http(_app_for(FakeEngineClient())) as client:
        resp = await client.get("/liveness")

    assert resp.status_code == 200
    assert resp.json() == {"status": "alive"}
