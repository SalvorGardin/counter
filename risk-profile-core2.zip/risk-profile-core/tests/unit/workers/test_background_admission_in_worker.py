"""Воркер пересчёта под политикой допуска: отброшенная фоновая команда не считается, но
коммитится, а идущая следом пользовательская команда того же пациента выполняется.

Консюмер собирается настоящий (`KafkaTopicConsumer`) на поддельном AIOKafkaConsumer: проверяются
именно связка обработчика с циклом батча и коммит оффсета, а не сама политика — её матрица
решений покрыта в tests/unit/calc/test_background_admission.py.
"""

import functools
import json
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import src.workers.calc_consumer as calc_consumer
from src.calc.background_admission import BackgroundAdmission
from src.calc.recalc_message import encode_command
from src.config import KafkaConsumerSettings, KafkaSettings
from src.infra.kafka import consumer as consumer_module
from src.infra.kafka.consumer import KafkaTopicConsumer

TOPIC = "risk-profile.recalc-commands"


def _settings() -> KafkaSettings:
    return KafkaSettings(
        enabled=True,
        bootstrap_servers="kafka:9093",
        security_protocol="PLAINTEXT",
        client_id="test-consumer",
        consumer=KafkaConsumerSettings(max_concurrency=1),
    )


def _record(value: dict, *, offset: int = 0) -> SimpleNamespace:
    return SimpleNamespace(
        topic=TOPIC,
        partition=0,
        offset=offset,
        value=json.dumps(value).encode("utf-8"),
        headers=[],
    )


class _FakeAIOKafkaConsumer:
    def __init__(self, steps: list, **kwargs: Any) -> None:
        self._steps = list(steps)
        self.kwargs = kwargs
        self.commit_count = 0

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def getmany(self, *, timeout_ms: int, max_records: int) -> dict:
        from aiokafka.errors import ConsumerStoppedError  # noqa: PLC0415

        if not self._steps:
            raise ConsumerStoppedError()
        return self._steps.pop(0)

    async def commit(self, offsets: Any = None) -> None:
        self.commit_count += 1


@pytest.fixture
def patch_consumer(monkeypatch: pytest.MonkeyPatch):
    holder: dict[str, _FakeAIOKafkaConsumer] = {}

    def _install(batches: list[dict]) -> dict[str, _FakeAIOKafkaConsumer]:
        def _factory(*_a: Any, **kwargs: Any) -> _FakeAIOKafkaConsumer:
            holder["instance"] = _FakeAIOKafkaConsumer(batches, **kwargs)
            return holder["instance"]

        monkeypatch.setattr(consumer_module, "AIOKafkaConsumer", _factory)
        return holder

    return _install


async def _run_worker(admission: BackgroundAdmission) -> AsyncMock:
    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        consumer = KafkaTopicConsumer(
            _settings(),
            TOPIC,
            functools.partial(calc_consumer._handle_command, catalogs=MagicMock(), admission=admission),
        )
        await consumer.start()
        await consumer.run()
    return run_mock


async def test_dropped_background_command_does_not_calculate_but_commits(patch_consumer) -> None:
    holder = patch_consumer([{"tp0": [_record(encode_command("p1", None, background=True))]}])

    run_mock = await _run_worker(BackgroundAdmission(0, is_saturated=lambda: False))

    run_mock.assert_not_awaited()
    assert holder["instance"].commit_count == 1


async def test_user_command_behind_dropped_background_ones_is_calculated(patch_consumer) -> None:
    """Head-of-line blocking снимается стоимостью отбрасывания, а не отдельным топиком:
    пользовательская команда доезжает до расчёта, отстояв очередь из отброшенных фоновых."""
    batch = {
        "tp0": [
            _record(encode_command("p1", None, background=True), offset=0),
            _record(encode_command("p1", None, background=True), offset=1),
            _record(encode_command("p1", None), offset=2),
        ]
    }
    holder = patch_consumer([batch])

    run_mock = await _run_worker(BackgroundAdmission(0, is_saturated=lambda: False))

    run_mock.assert_awaited_once()
    assert run_mock.await_args is not None
    assert run_mock.await_args.args == ("p1", None)
    assert holder["instance"].commit_count == 1


async def test_background_command_is_calculated_when_capacity_allows(patch_consumer) -> None:
    holder = patch_consumer([{"tp0": [_record(encode_command("p1", None, background=True))]}])

    run_mock = await _run_worker(BackgroundAdmission(1, is_saturated=lambda: False))

    run_mock.assert_awaited_once()
    assert holder["instance"].commit_count == 1
