"""Тесты политики перезапуска (src/services/container_restart/service.py).

Проверяется, ЧТО и в каком порядке перезапускается и как считается отчёт. Разговор с демоном
подменён `FakeEngineClient` — формат Engine API проверяется отдельно, на уровне клиента.
"""

from src.config import settings
from src.services.container_restart.service import restart_catalog_services
from tests.unit.container_restart.fakes import DEFAULT_CONTAINERS, PROJECT, FakeEngineClient


async def test_report_lists_containers_per_service() -> None:
    """Успешный проход отдаёт поимённый список перезапущенных контейнеров по сервисам."""
    report = await restart_catalog_services(FakeEngineClient())

    assert report.ok
    assert report.restarted == DEFAULT_CONTAINERS
    assert report.failed == {}


async def test_consumers_restart_before_app() -> None:
    """Порядок фиксирован: сначала консюмеры, `app` последним — на нём QA проверяет результат.

    Реплики внутри сервиса идут по имени: демон отдаёт их в произвольном порядке, и без
    сортировки отчёт и логи меняли бы порядок от прогона к прогону.
    """
    # Клиент отдаёт реплики НЕ по возрастанию имени — так и ведёт себя живой демон.
    containers = dict(DEFAULT_CONTAINERS) | {"consumer": list(reversed(DEFAULT_CONTAINERS["consumer"]))}
    client = FakeEngineClient(containers=containers)

    await restart_catalog_services(client)

    assert client.restarted == [
        f"{PROJECT}-consumer-1",
        f"{PROJECT}-consumer-2",
        f"{PROJECT}-emr-consumer-1",
        f"{PROJECT}-app-1",
    ]


async def test_service_without_containers_fails_whole_restart() -> None:
    """Сервис без контейнеров — сбой: иначе фикстура с `raise_for_status()` пропустит
    протухший каталог в том процессе, который никто не перезапустил."""
    containers = dict(DEFAULT_CONTAINERS) | {"emr-consumer": []}

    report = await restart_catalog_services(FakeEngineClient(containers=containers))

    assert not report.ok
    assert "emr-consumer" in report.failed
    # Остальные сервисы всё равно перезапущены: отчёт показывает, что именно осталось протухшим.
    assert report.restarted["consumer"] == DEFAULT_CONTAINERS["consumer"]
    assert report.restarted["app"] == DEFAULT_CONTAINERS["app"]


async def test_failure_on_second_replica_keeps_partial_progress() -> None:
    """Первая реплика перезапущена, вторая упала — отчёт обязан показать обе половины.

    «Встали на второй реплике» и «не перезапущено ничего» — разные состояния стенда: в первом
    достаточно доперезапустить остаток. Имя сбойного контейнера — в тексте ошибки.
    """
    failing = f"{PROJECT}-consumer-2"

    report = await restart_catalog_services(FakeEngineClient(failing=frozenset({failing})))

    assert not report.ok
    assert report.restarted["consumer"] == [f"{PROJECT}-consumer-1"]
    assert failing in report.failed["consumer"]
    # Сбой одного сервиса не отменяет перезапуск остальных.
    assert report.restarted["app"] == DEFAULT_CONTAINERS["app"]


async def test_stopped_containers_are_requested() -> None:
    """Перечисляем и остановленные контейнеры: упавший консюмер надо поднять, а не объявить
    сервис отсутствующим — перезапуск как раз и есть нужное действие."""
    client = FakeEngineClient()

    await restart_catalog_services(client)

    assert {include_stopped for _, _, include_stopped in client.listed} == {True}
    assert {project for project, _, _ in client.listed} == {settings.restarter.compose_project}


async def test_stop_timeout_is_taken_from_settings() -> None:
    """`t` — бюджет graceful stop. Без него демон возьмёт свои 10 с и прибьёт дренаж SIGKILL."""
    client = FakeEngineClient()

    await restart_catalog_services(client)

    assert set(client.stop_timeouts) == {settings.restarter.stop_timeout_s}
