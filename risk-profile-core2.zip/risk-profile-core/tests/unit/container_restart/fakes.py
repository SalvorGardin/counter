"""Подставной клиент Docker Engine для тестов операции перезапуска.

Формат Engine API здесь не воспроизводится намеренно: он проверяется в
tests/unit/infra/test_docker_engine.py, а тестам операции нужен только контракт клиента.
"""

from src.config import settings
from src.infra.docker import Container, DockerEngineClient, DockerEngineError

PROJECT = settings.restarter.compose_project

# Контейнеры «стенда по умолчанию»: consumer в двух репликах, остальные по одной.
DEFAULT_CONTAINERS: dict[str, list[str]] = {
    "consumer": [f"{PROJECT}-consumer-1", f"{PROJECT}-consumer-2"],
    "emr-consumer": [f"{PROJECT}-emr-consumer-1"],
    "app": [f"{PROJECT}-app-1"],
}


class FakeEngineClient(DockerEngineClient):
    """Отдаёт заданные контейнеры по сервисам и записывает порядок обращений."""

    def __init__(
        self,
        containers: dict[str, list[str]] | None = None,
        failing: frozenset[str] = frozenset(),
    ) -> None:
        self.containers = DEFAULT_CONTAINERS if containers is None else containers
        # Имена контейнеров, на которых демон отказывает.
        self.failing = failing
        self.restarted: list[str] = []
        self.stop_timeouts: list[int] = []
        # (project, service, include_stopped) каждого перечисления.
        self.listed: list[tuple[str, str, bool]] = []

    async def list_service_containers(self, project: str, service: str, *, include_stopped: bool) -> list[Container]:
        self.listed.append((project, service, include_stopped))
        return [Container(id=f"id-{name}", name=name) for name in self.containers.get(service, [])]

    async def restart(self, container: Container, *, stop_timeout_s: int) -> None:
        if container.name in self.failing:
            raise DockerEngineError(
                f"failed to restart container {container.name!r}: 409 Conflict",
                container=container.name,
            )
        self.restarted.append(container.name)
        self.stop_timeouts.append(stop_timeout_s)
