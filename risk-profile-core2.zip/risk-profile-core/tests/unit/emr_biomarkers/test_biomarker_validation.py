"""Валидация уровня биомаркера топика `emr-biomarkers` (шаг 3 бизнес-логики контракта).

Нарушение здесь пропускает только свой элемент: остальные биомаркеры сообщения принимаются.
Каждый случай проверяется на сообщении из трёх элементов — валидный, проверяемый, валидный, —
чтобы отдельно видеть и код причины пропуска, и то, что соседи уцелели.
"""

import logging
import os
import time
from datetime import UTC, datetime, timedelta
from typing import Any

import pytest

from src.emr_biomarkers.domain.constants import (
    BIOMARKER_CODE_MAX,
    BIOMARKER_ID_MAX,
    BIOMARKER_UNIT_CODE_MAX,
    EmrBiomarkerErrorCode,
)
from src.emr_biomarkers.domain.exceptions import InvalidBiomarkerError
from src.emr_biomarkers.domain.validation import parse_biomarker, parse_message
from tests.unit.emr_biomarkers.conftest import (
    BIOMARKER_SKIPPED,
    MESSAGE_REJECTED,
    VALID_CLIENT_ID,
    encode,
    error_codes,
    handle,
    make_biomarker,
    make_payload,
    summary,
)

FORMAT = EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT
OPERATION = EmrBiomarkerErrorCode.INVALID_OPERATION_TYPE

# Соседи проверяемого элемента: их приём доказывает, что пропущен ровно один биомаркер.
_NEIGHBOURS = (make_biomarker(id=9_000_000_001), make_biomarker(id=9_000_000_002))


def _offset_from_now(**delta: float) -> str:
    """Момент, отстоящий от текущего на заданный интервал, в форме записи контракта."""
    return (datetime.now() + timedelta(**delta)).strftime("%Y-%m-%dT%H:%M:%S")


def _server_time_as_utc(value: datetime) -> datetime:
    """Naive wall-clock сервера в UTC; ожидаемое значение не привязано к timezone CI."""
    return value.astimezone(UTC)


def _without(field: str) -> dict[str, Any]:
    """Валидный биомаркер без одного обязательного поля."""
    biomarker = make_biomarker()
    del biomarker[field]
    return biomarker


async def _skip_codes(candidate: Any, log_records: list[logging.LogRecord]) -> list[str]:
    """Прогоняет сообщение с проверяемым элементом посередине и отдаёт коды пропусков."""
    await handle(make_payload([_NEIGHBOURS[0], candidate, _NEIGHBOURS[1]]))
    assert error_codes(log_records, MESSAGE_REJECTED) == []  # уровень сообщения не задет
    return error_codes(log_records, BIOMARKER_SKIPPED)


@pytest.mark.parametrize(
    ("case", "candidate", "expected_code"),
    [
        # Элемент не объект — ошибка уровня биомаркера, а не сообщения.
        ("element_string", "junk", FORMAT),
        ("element_number", 5, FORMAT),
        ("element_null", None, FORMAT),
        # id: целое положительное длиной не более 10 цифр.
        ("id_missing", _without("id"), FORMAT),
        ("id_zero", make_biomarker(id=0), FORMAT),
        ("id_negative", make_biomarker(id=-1), FORMAT),
        ("id_string", make_biomarker(id="845231"), FORMAT),
        ("id_bool", make_biomarker(id=True), FORMAT),
        ("id_fractional", make_biomarker(id=845231.5), FORMAT),
        ("id_above_ten_digits", make_biomarker(id=BIOMARKER_ID_MAX + 1), FORMAT),
        # biomarkerCode: целое положительное длиной не более 10 цифр.
        ("biomarker_code_missing", _without("biomarkerCode"), FORMAT),
        ("biomarker_code_zero", make_biomarker(biomarkerCode=0), FORMAT),
        ("biomarker_code_negative", make_biomarker(biomarkerCode=-1), FORMAT),
        ("biomarker_code_string", make_biomarker(biomarkerCode="192"), FORMAT),
        ("biomarker_code_bool", make_biomarker(biomarkerCode=True), FORMAT),
        ("biomarker_code_fractional", make_biomarker(biomarkerCode=192.0), FORMAT),
        ("biomarker_code_above_ten_digits", make_biomarker(biomarkerCode=BIOMARKER_CODE_MAX + 1), FORMAT),
        # Прежнее имя поля из первой редакции контракта: `code` теперь неизвестное поле,
        # поэтому элемент отбраковывается как элемент без обязательного `biomarkerCode`.
        ("biomarker_code_legacy_name", {**_without("biomarkerCode"), "code": 192}, FORMAT),
        ("biomarker_code_internal_name", {**_without("biomarkerCode"), "biomarker_code": 192}, FORMAT),
        ("biomarker_code_internal_name_with_alias", make_biomarker(biomarker_code=999), FORMAT),
        # unitCode: целое положительное длиной не более 10 цифр либо null.
        ("unit_code_zero", make_biomarker(unitCode=0), FORMAT),
        ("unit_code_negative", make_biomarker(unitCode=-1), FORMAT),
        ("unit_code_string", make_biomarker(unitCode="1"), FORMAT),
        ("unit_code_bool", make_biomarker(unitCode=True), FORMAT),
        ("unit_code_fractional", make_biomarker(unitCode=1.5), FORMAT),
        ("unit_code_above_ten_digits", make_biomarker(unitCode=BIOMARKER_UNIT_CODE_MAX + 1), FORMAT),
        ("unit_code_internal_name", {**_without("unitCode"), "unit_code": 1}, FORMAT),
        ("unit_code_internal_name_with_alias", make_biomarker(unit_code=999), FORMAT),
        # Любое изолированное нарушение operationType получает отдельный код контракта.
        ("operation_missing", _without("operationType"), OPERATION),
        ("operation_null", make_biomarker(operationType=None), OPERATION),
        ("operation_number", make_biomarker(operationType=1), OPERATION),
        ("operation_bool", make_biomarker(operationType=True), OPERATION),
        ("operation_object", make_biomarker(operationType={"value": "save"}), OPERATION),
        ("operation_array", make_biomarker(operationType=["save"]), OPERATION),
        ("operation_internal_name", {**_without("operationType"), "operation_type": "save"}, FORMAT),
        ("operation_internal_name_with_alias", make_biomarker(operation_type="delete"), FORMAT),
        ("operation_unknown", make_biomarker(operationType="update"), OPERATION),
        ("operation_empty", make_biomarker(operationType=""), OPERATION),
        # Набор значений закрыт, поэтому ни регистр, ни обрамляющие пробелы не дают «то же
        # значение» — в отличие от name/value, где пробелы срезаются.
        ("operation_uppercase", make_biomarker(operationType="SAVE"), OPERATION),
        ("operation_padded", make_biomarker(operationType=" save "), OPERATION),
        ("operation_trailing_newline", make_biomarker(operationType="save\n"), OPERATION),
        # Ошибка другого поля сохраняет приоритет общего формата биомаркера.
        ("operation_null_and_invalid_id", make_biomarker(operationType=None, id=0), FORMAT),
        # name: непустая строка до 255 символов; пробелы не делают строку непустой.
        ("name_empty", make_biomarker(name=""), FORMAT),
        ("name_blank", make_biomarker(name="   "), FORMAT),
        ("name_too_long", make_biomarker(name="x" * 256), FORMAT),
        ("name_not_string", make_biomarker(name=42), FORMAT),
        # unit: строка до 32 символов либо null.
        ("unit_too_long", make_biomarker(unit="x" * 33), FORMAT),
        ("unit_not_string", make_biomarker(unit=1), FORMAT),
        # value: непустая строка; число не принимается даже для количественного биомаркера.
        ("value_empty", make_biomarker(value=""), FORMAT),
        ("value_blank", make_biomarker(value="  "), FORMAT),
        ("value_number", make_biomarker(value=3.6), FORMAT),
        # dateTime: локальная часть ровно YYYY-MM-DDThh:mm:ss, timezone-суффикс — только контрактный.
        ("date_only", make_biomarker(dateTime="2026-07-20"), FORMAT),
        ("date_space_separator", make_biomarker(dateTime="2026-07-20 08:30:00"), FORMAT),
        ("date_dotted", make_biomarker(dateTime="20.07.2026"), FORMAT),
        ("date_number", make_biomarker(dateTime=1_753_000_200), FORMAT),
        ("date_null", make_biomarker(dateTime=None), FORMAT),
        ("date_offset_hour_out_of_range", make_biomarker(dateTime="2026-07-20T08:30:00+24:00"), FORMAT),
        ("date_offset_minute_out_of_range", make_biomarker(dateTime="2026-07-20T08:30:00-03:60"), FORMAT),
        ("date_offset_short_hour", make_biomarker(dateTime="2026-07-20T08:30:00+3:00"), FORMAT),
        ("date_lowercase_zulu", make_biomarker(dateTime="2026-07-20T08:30:00z"), FORMAT),
        ("date_internal_name", {**_without("dateTime"), "date_time": "2026-07-20T08:30:00"}, FORMAT),
        (
            "date_internal_name_with_alias",
            make_biomarker(date_time="2026-07-21T08:30:00"),
            FORMAT,
        ),
        # Ширина компонентов обязательна: без ведущих нулей это уже не формат контракта.
        ("date_short_month", make_biomarker(dateTime="2026-7-20T08:30:00"), FORMAT),
        ("date_short_day", make_biomarker(dateTime="2026-07-2T08:30:00"), FORMAT),
        ("date_short_hour", make_biomarker(dateTime="2026-07-20T8:30:00"), FORMAT),
        ("date_short_everywhere", make_biomarker(dateTime="2026-7-2T8:3:0"), FORMAT),
        # Ширина верна, но такой даты не существует.
        ("date_nonexistent", make_biomarker(dateTime="2026-02-31T08:30:00"), FORMAT),
        # Доля секунды обязана быть непустой при разделителе.
        ("date_fraction_empty", make_biomarker(dateTime="2026-07-20T08:30:00."), FORMAT),
        ("date_fraction_empty_comma", make_biomarker(dateTime="2026-07-20T08:30:00,"), FORMAT),
        # 24 часа — только ровная полночь конца суток; ISO 8601 других значений в этом часе не знает.
        ("date_end_of_day_with_seconds", make_biomarker(dateTime="2026-07-20T24:00:01"), FORMAT),
        ("date_end_of_day_with_minutes", make_biomarker(dateTime="2026-07-20T24:30:00"), FORMAT),
        ("date_end_of_day_with_fraction", make_biomarker(dateTime="2026-07-20T24:00:00.500"), FORMAT),
        ("date_hour_out_of_range", make_biomarker(dateTime="2026-07-20T25:00:00"), FORMAT),
        # Смещение: часы обязаны быть двузначными, минуты — либо парой цифр, либо отсутствовать.
        ("date_offset_short_hour_only", make_biomarker(dateTime="2026-07-20T08:30:00+3"), FORMAT),
        ("date_offset_dangling_colon", make_biomarker(dateTime="2026-07-20T08:30:00+03:"), FORMAT),
        ("date_offset_single_minute_digit", make_biomarker(dateTime="2026-07-20T08:30:00+03:0"), FORMAT),
        # Конец суток 31.12.9999 переносится на несуществующий год — это выход за окно, не формат.
        ("date_end_of_day_overflows", make_biomarker(dateTime="9999-12-31T24:00:00"), FORMAT),
        # Смещение отделяется от времени не более чем одним пробелом.
        ("date_offset_two_spaces", make_biomarker(dateTime="2026-07-20T08:30:00  +03:00"), FORMAT),
        ("date_trailing_space", make_biomarker(dateTime="2026-07-20T08:30:00 "), FORMAT),
        # Дата существует, но лежит вне окна правдоподобия: результата анализа в таком году нет,
        # а 9999 год к тому же переполняет арифметику `expiration_date`.
        ("date_year_too_early", make_biomarker(dateTime="0001-01-01T10:00:00"), FORMAT),
        ("date_before_lower_bound", make_biomarker(dateTime="1899-12-31T23:59:59"), FORMAT),
        ("date_year_too_late", make_biomarker(dateTime="9999-01-01T10:00:00"), FORMAT),
        ("date_far_future", make_biomarker(dateTime=_offset_from_now(days=8)), FORMAT),
    ],
)
async def test_invalid_biomarker_is_skipped_alone(
    case: str, candidate: Any, expected_code: EmrBiomarkerErrorCode, log_records: list[logging.LogRecord]
) -> None:
    """Битый элемент пропускается со своим кодом, соседние биомаркеры принимаются."""
    assert await _skip_codes(candidate, log_records) == [expected_code], case
    assert summary(log_records) == {
        "client_id": VALID_CLIENT_ID,
        "total": 3,
        "accepted": 2,
        "skipped": 1,
        "skipped_by_code": {expected_code: 1},
        "skipped_not_logged": 0,
        "written": 0,
        "recalc_requested": False,
    }, case


@pytest.mark.parametrize(
    ("case", "candidate"),
    [
        ("operation_save", make_biomarker(operationType="save")),
        # delete проходит валидацию формата: контракт откладывает его обработку, но не приём.
        ("operation_delete", make_biomarker(operationType="delete")),
        ("id_min", make_biomarker(id=1)),
        ("id_max_ten_digits", make_biomarker(id=BIOMARKER_ID_MAX)),
        ("biomarker_code_max_ten_digits", make_biomarker(biomarkerCode=BIOMARKER_CODE_MAX)),
        ("unit_code_max_ten_digits", make_biomarker(unitCode=BIOMARKER_UNIT_CODE_MAX)),
        ("name_max_length", make_biomarker(name="x" * 255)),
        # У name и value пробелы по краям срезаются: там ограничение — «непустая строка».
        ("name_padded", make_biomarker(name="  Ферритин  ")),
        ("value_padded", make_biomarker(value="  24  ")),
        # Единица измерения не сверяется с справочной на этом уровне, поэтому пустая строка
        # форматом не отвергается.
        ("unit_empty_string", make_biomarker(unit="")),
        ("unit_null", make_biomarker(unit=None)),
        ("unit_max_length", make_biomarker(unit="x" * 32)),
        # unitCode необязателен: у безразмерных количественных и у качественных биомаркеров
        # его в сообщении нет либо он null.
        ("unit_code_missing", _without("unitCode")),
        ("unit_code_null", make_biomarker(unitCode=None)),
        ("value_decimal_point", make_biomarker(value="3.6")),
        ("value_decimal_comma", make_biomarker(value="6,4")),
        ("value_qualitative", make_biomarker(value="Обнаружен")),
        ("value_integer_string", make_biomarker(value="24")),
        ("date_zulu", make_biomarker(dateTime="2026-07-20T08:30:00Z")),
        ("date_positive_offset", make_biomarker(dateTime="2026-07-20T08:30:00+03:00")),
        ("date_negative_offset", make_biomarker(dateTime="2026-07-20T08:30:00-05:30")),
        # Продюсер шлёт долю секунды и смещение через пробел без двоеточия — оба варианта контрактны.
        ("date_fractional", make_biomarker(dateTime="2026-07-20T08:30:00.000")),
        ("date_fractional_with_spaced_offset", make_biomarker(dateTime="2026-07-20T08:30:00.000 +03:00")),
        ("date_offset_without_colon", make_biomarker(dateTime="2026-07-20T08:30:00+0300")),
        ("date_spaced_offset_without_colon", make_biomarker(dateTime="2026-07-20T08:30:00.000 +0300")),
        ("date_lower_bound", make_biomarker(dateTime="1900-01-01T00:00:00")),
        # Окно допускает сутки вперёд, чтобы покрыть расхождение часов источника и сервиса.
        ("date_near_future", make_biomarker(dateTime=_offset_from_now(hours=20))),
        # Прочие формы записи ISO 8601, встречающиеся у источников: запятая как десятичный
        # разделитель, смещение одними часами, доля секунды точнее микросекунд, конец суток.
        ("date_fraction_comma", make_biomarker(dateTime="2026-07-20T08:30:00,123")),
        ("date_offset_hours_only", make_biomarker(dateTime="2026-07-20T08:30:00+03")),
        ("date_offset_hours_only_spaced", make_biomarker(dateTime="2026-07-20T08:30:00,000 +03")),
        ("date_fraction_beyond_microseconds", make_biomarker(dateTime="2026-07-20T08:30:00.1234567")),
        ("date_end_of_day", make_biomarker(dateTime="2026-07-20T24:00:00")),
        ("unknown_field", make_biomarker(sourceSystem="lab")),
    ],
)
async def test_valid_biomarker_is_accepted(
    case: str, candidate: dict[str, Any], log_records: list[logging.LogRecord]
) -> None:
    """Значения на границах ограничений и неизвестные поля приёму не мешают."""
    assert await _skip_codes(candidate, log_records) == [], case
    assert summary(log_records)["accepted"] == 3, case


async def test_mixed_message_keeps_order_of_accepted_biomarkers(log_records: list[logging.LogRecord]) -> None:
    """Валидный, невалидный и снова валидный: приняты оба валидных в исходном порядке."""
    payload = make_payload([make_biomarker(id=10), make_biomarker(id=0), make_biomarker(id=30)])

    await handle(payload)
    assert error_codes(log_records, BIOMARKER_SKIPPED) == [FORMAT]
    assert summary(log_records)["accepted"] == 2

    # Порядок принятых виден только в результате разбора — счётчики его не показывают.
    message = parse_message(payload)
    accepted = []
    for raw in message.biomarkers:
        try:
            accepted.append(parse_biomarker(raw).id)
        except InvalidBiomarkerError:
            continue
    assert accepted == [10, 30]


async def test_value_is_kept_as_string_without_numeric_coercion() -> None:
    """`value` доезжает строкой как есть: приведение к числу — дело сверки со справочником."""
    message = parse_message(encode({"clientId": "abcde", "biomarkers": [make_biomarker(value="6,4")]}))

    assert parse_biomarker(message.biomarkers[0]).value == "6,4"


async def test_contract_fields_reach_parsed_biomarker() -> None:
    """`biomarkerCode` и `unitCode` доезжают до принятого биомаркера: сверке со справочником
    сравнивать их больше не с чего."""
    raw = make_biomarker(biomarkerCode=38, unitCode=8)
    message = parse_message(encode({"clientId": "abcde", "biomarkers": [raw]}))

    biomarker = parse_biomarker(message.biomarkers[0])
    assert biomarker.biomarker_code == 38
    assert biomarker.unit_code == 8


async def test_absent_unit_code_reaches_parsed_biomarker_as_none() -> None:
    """Отсутствие `unitCode` равносильно null: у безразмерного биомаркера код единицы пуст."""
    message = parse_message(encode({"clientId": "abcde", "biomarkers": [_without("unitCode")]}))

    assert parse_biomarker(message.biomarkers[0]).unit_code is None


async def test_date_time_without_timezone_uses_server_timezone(monkeypatch: pytest.MonkeyPatch) -> None:
    """Момент без смещения получает timezone сервера, а явное смещение остаётся приоритетным.

    Дальше naive-значения нет: целевые колонки — `timestamptz`, а правило свежести сравнивает
    входящий момент с сохранённым, и сравнение naive с aware в Python — ошибка.
    """
    original_time_zone = os.environ.get("TZ")
    monkeypatch.setenv("TZ", "Europe/Berlin")
    time.tzset()
    try:
        from_string = parse_biomarker(make_biomarker(dateTime="2026-07-20T08:30:00"))
        from_naive_datetime = parse_biomarker(make_biomarker(dateTime=datetime(2026, 1, 20, 8, 30)))
        from_explicit_offset = parse_biomarker(make_biomarker(dateTime="2026-07-20T08:30:00+03:00"))
    finally:
        if original_time_zone is None:
            monkeypatch.delenv("TZ", raising=False)
        else:
            monkeypatch.setenv("TZ", original_time_zone)
        time.tzset()

    assert from_string.date_time == datetime(2026, 7, 20, 6, 30, tzinfo=UTC)
    assert from_naive_datetime.date_time == datetime(2026, 1, 20, 7, 30, tzinfo=UTC)
    assert from_explicit_offset.date_time == datetime(2026, 7, 20, 5, 30, tzinfo=UTC)


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("2026-07-20T08:30:00Z", datetime(2026, 7, 20, 8, 30, tzinfo=UTC)),
        ("2026-07-20T08:30:00+03:00", datetime(2026, 7, 20, 5, 30, tzinfo=UTC)),
        ("2026-07-20T08:30:00-05:30", datetime(2026, 7, 20, 14, 0, tzinfo=UTC)),
    ],
)
async def test_date_time_timezone_suffix_defines_absolute_moment(raw: str, expected: datetime) -> None:
    """Явный timezone-суффикс учитывается при нормализации момента в UTC."""
    biomarker = parse_biomarker(make_biomarker(dateTime=raw))

    assert biomarker.date_time == expected


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("2026-07-20T08:30:00.000", _server_time_as_utc(datetime(2026, 7, 20, 8, 30))),
        ("2026-07-20T08:30:00.123456", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 123_456))),
        ("2026-07-20T08:30:00.5", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 500_000))),
        ("2026-07-20T08:30:00.123 +03:00", datetime(2026, 7, 20, 5, 30, 0, 123_000, tzinfo=UTC)),
    ],
)
async def test_date_time_keeps_fraction_of_second(raw: str, expected: datetime) -> None:
    """Доля секунды сохраняется: целевые колонки — `timestamptz`, и точность сравнения свежести выше."""
    assert parse_biomarker(make_biomarker(dateTime=raw)).date_time == expected


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        # Запятая — десятичный разделитель ISO 8601 наравне с точкой.
        ("2026-07-20T08:30:00,123", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 123_000))),
        # Точность выше микросекундной усекается, а не округляется: округление вверх сделало бы
        # входящий момент позже присланного и могло бы перебить запись, которой оно равно.
        ("2026-07-20T08:30:00.1234564", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 123_456))),
        ("2026-07-20T08:30:00.1234567", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 123_456))),
        ("2026-07-20T08:30:00.9999999", _server_time_as_utc(datetime(2026, 7, 20, 8, 30, 0, 999_999))),
        # Смещение одними часами — тоже контрактная форма и определяет абсолютный момент.
        ("2026-07-20T08:30:00+03", datetime(2026, 7, 20, 5, 30, tzinfo=UTC)),
        ("2026-07-20T08:30:00-05", datetime(2026, 7, 20, 13, 30, tzinfo=UTC)),
    ],
)
async def test_alternative_iso_forms_parse_to_the_same_moment(raw: str, expected: datetime) -> None:
    """Формы записи ISO 8601, различающие только оформление, дают один и тот же момент."""
    assert parse_biomarker(make_biomarker(dateTime=raw)).date_time == expected


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("2026-07-20T24:00:00", _server_time_as_utc(datetime(2026, 7, 21))),
        ("2026-07-20T24:00:00.000", _server_time_as_utc(datetime(2026, 7, 21))),
        ("2026-07-20T24:00:00,0 +03:00", datetime(2026, 7, 20, 21, 0, tzinfo=UTC)),
        # Перенос идёт по календарю, а не прибавлением суток к строке.
        ("2026-02-28T24:00:00", _server_time_as_utc(datetime(2026, 3, 1))),
        ("2024-02-28T24:00:00", _server_time_as_utc(datetime(2024, 2, 29))),
        ("2025-12-31T24:00:00", _server_time_as_utc(datetime(2026, 1, 1))),
    ],
)
async def test_end_of_day_hour_becomes_next_midnight(raw: str, expected: datetime) -> None:
    """`24:00:00` — полночь следующих суток: ISO 8601 знает этот час только как конец суток."""
    assert parse_biomarker(make_biomarker(dateTime=raw)).date_time == expected


@pytest.mark.parametrize("raw", ["0001-01-01T10:00:00", "9999-01-01T10:00:00", "9999-12-31T24:00:00"])
async def test_date_time_out_of_range_names_the_window(raw: str) -> None:
    """Причина пропуска называет окно, а не форму записи: у такого значения формат как раз верный."""
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        parse_biomarker(make_biomarker(dateTime=raw))

    assert exc_info.value.code == FORMAT
    assert "must be within" in exc_info.value.reason


async def test_duplicate_id_skips_only_later_biomarker(log_records: list[logging.LogRecord]) -> None:
    """Первый валидный id сохраняет позицию, повтор пропускается, следующие элементы принимаются."""
    processor = await handle(make_payload([make_biomarker(id=10), make_biomarker(id=10), make_biomarker(id=30)]))

    assert [item.id for item in processor.calls[0][1]] == [10, 30]
    assert error_codes(log_records, BIOMARKER_SKIPPED) == [FORMAT]
    assert summary(log_records)["accepted"] == 2
    assert summary(log_records)["skipped_by_code"] == {FORMAT: 1}


async def test_invalid_biomarker_does_not_reserve_its_id(log_records: list[logging.LogRecord]) -> None:
    """Форматно битый элемент не мешает следующему валидному элементу с тем же id."""
    processor = await handle(make_payload([make_biomarker(id=10, name=""), make_biomarker(id=10)]))

    assert [item.id for item in processor.calls[0][1]] == [10]
    assert error_codes(log_records, BIOMARKER_SKIPPED) == [FORMAT]
    assert summary(log_records)["accepted"] == 1


async def test_same_id_is_allowed_in_separate_messages(log_records: list[logging.LogRecord]) -> None:
    """Множество id создаётся заново на каждую Kafka-запись, чтобы повторная доставка обновляла результат."""
    first = await handle(make_payload([make_biomarker(id=10)]))
    second = await handle(make_payload([make_biomarker(id=10)]))

    assert [item.id for item in first.calls[0][1]] == [10]
    assert [item.id for item in second.calls[0][1]] == [10]
    assert error_codes(log_records, BIOMARKER_SKIPPED) == []
