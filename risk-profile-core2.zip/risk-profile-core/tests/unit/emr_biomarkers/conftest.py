"""Общая оснастка тестов разбора сообщений топика `emr-biomarkers`.

Записи снимаются собственным handler'ом на логгере `app`, а не через `caplog`: у логгера
проекта `propagate=False`, поэтому root-handler фикстуры pytest его записей не видит.
"""

import json
import logging
from collections.abc import Generator, Sequence
from typing import Any

import pytest

from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.processing import ProcessingReport
from src.emr_biomarkers.service import handle_emr_biomarkers_record

# Валидный биомаркер — первый элемент примера сообщения из вики «Emr-biomarkers».
_VALID_BIOMARKER: dict[str, Any] = {
    "id": 845231,
    "biomarkerCode": 192,
    "operationType": "save",
    "name": "Холестерин ЛПНП",
    "unit": "ммоль/л",
    "unitCode": 1,
    "value": "3.6",
    "dateTime": "2026-07-20T08:30:00",
}

# clientId примера из вики: 36 символов, в пределах ограничений контракта.
VALID_CLIENT_ID = "123e4567-e89b-12d3-a456-426614174000"

MESSAGE_REJECTED = "emr.biomarkers: message rejected"
BIOMARKER_SKIPPED = "emr.biomarkers: biomarker skipped"
MESSAGE_VALIDATED = "emr.biomarkers: message validated"


@pytest.fixture
def log_records() -> Generator[list[logging.LogRecord], None, None]:
    """Все записи логгера `app`, сделанные за время теста."""
    records: list[logging.LogRecord] = []

    class _Collector(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            records.append(record)

    handler = _Collector()
    app_logger = logging.getLogger("app")
    app_logger.addHandler(handler)
    try:
        yield records
    finally:
        app_logger.removeHandler(handler)


def make_biomarker(**overrides: Any) -> dict[str, Any]:
    """Валидный биомаркер с точечными подменами полей."""
    return {**_VALID_BIOMARKER, **overrides}


def encode(message: Any) -> bytes:
    """Сообщение в том виде, в каком его кладёт в топик продюсер."""
    return json.dumps(message).encode("utf-8")


def make_payload(biomarkers: Any, client_id: str = VALID_CLIENT_ID, **extra: Any) -> bytes:
    """Payload валидного по уровню сообщения с заданным массивом биомаркеров."""
    return encode({"clientId": client_id, "biomarkers": biomarkers, **extra})


def log_context(record: logging.LogRecord) -> dict[str, Any]:
    """Структурированный контекст записи: атрибут проставляется через `extra`, поэтому читается
    так же, как его читает форматтер логгера."""
    return getattr(record, "log_context", {})


def channel(record: logging.LogRecord) -> str:
    """Канал записи: `business` у бизнес-событий, `app` у остальных."""
    return getattr(record, "channel", "app")


def contexts(records: list[logging.LogRecord], message: str) -> list[dict[str, Any]]:
    """`log_context` записей с указанным сообщением, в порядке их появления."""
    return [log_context(record) for record in records if record.getMessage() == message]


def error_codes(records: list[logging.LogRecord], message: str) -> list[str]:
    """Коды причин из записей с указанным сообщением."""
    return [ctx["error_code"] for ctx in contexts(records, message)]


def summary(records: list[logging.LogRecord]) -> dict[str, Any]:
    """Счётчики итогового бизнес-события; пустой словарь, если события не было."""
    found = contexts(records, MESSAGE_VALIDATED)
    return found[0] if found else {}


class StubProcessor:
    """Подмена обработки принятых биомаркеров.

    Разбор сообщения ни к базе, ни к очереди команд не обращается, поэтому его тесты обходятся
    без них: стаб запоминает, с чем обработку позвали, и отдаёт заранее заданный отчёт.
    """

    def __init__(self, report: ProcessingReport | None = None) -> None:
        self.report = report if report is not None else ProcessingReport()
        self.calls: list[tuple[str, list[EmrBiomarker]]] = []

    async def __call__(self, client_id: str, biomarkers: Sequence[EmrBiomarker]) -> ProcessingReport:
        self.calls.append((client_id, list(biomarkers)))
        return self.report


async def handle(payload: bytes | None, *, process: StubProcessor | None = None) -> StubProcessor:
    """Прогоняет запись топика через обработчик с подменённой обработкой и отдаёт её стаб."""
    processor = process if process is not None else StubProcessor()
    await handle_emr_biomarkers_record(payload, process=processor)
    return processor
