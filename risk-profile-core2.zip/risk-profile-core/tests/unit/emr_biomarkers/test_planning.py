"""План записи параметров по сообщению (шаги 5 и 6 бизнес-логики контракта).

Планирование — чистая функция над прочитанным состоянием, поэтому база здесь не нужна:
сохранённые записи и строки разметки собираются прямо в тесте.
"""

from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest

from src.emr_biomarkers.domain.catalog import BiomarkerEntry, BiomarkerMapping, StoredParameter
from src.emr_biomarkers.domain.constants import BiomarkerType, MappingOperator, MappingType
from src.emr_biomarkers.domain.matching import MatchedBiomarker
from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.domain.planning import ParameterWrite, plan_writes
from tests.factories import validity_period_for_days
from tests.unit.emr_biomarkers.conftest import make_biomarker

_NOW = datetime(2026, 8, 31, 12, 0, tzinfo=UTC)
_YEAR = validity_period_for_days(365)
_TEN_YEARS = validity_period_for_days(3650)

_BIOMARKER_PARAMETER = "biomarker_192_169"
_QUESTION_PARAMETER = "sq_0100"


def _matched(
    *,
    value: str = "3.6",
    date_time: datetime | None = None,
    external_id: int = 845231,
    biomarker_type: str = BiomarkerType.QUANTITATIVE,
    parameter_code: str = _BIOMARKER_PARAMETER,
) -> MatchedBiomarker:
    moment = date_time if date_time is not None else _NOW - timedelta(days=1)
    biomarker = EmrBiomarker.model_validate(make_biomarker(id=external_id, value=value, dateTime=moment.isoformat()))
    entry = BiomarkerEntry(
        biomarker_code=biomarker.biomarker_code,
        unit_code=biomarker.unit_code,
        parameter_code=parameter_code,
        type=biomarker_type,
        parameter_status="active",
        validity_period=_YEAR,
    )
    return MatchedBiomarker(biomarker=biomarker, entry=entry, value=value)


def _stored(
    *,
    parameter_code: str = _BIOMARKER_PARAMETER,
    value: str | None = "3.0",
    date_time: datetime | None = None,
    expires_in: timedelta = timedelta(days=100),
) -> dict[str, StoredParameter]:
    moment = date_time if date_time is not None else _NOW - timedelta(days=10)
    return {
        parameter_code: StoredParameter(
            parameter_code=parameter_code,
            value=value,
            date_time=moment,
            expiration_date=_NOW + expires_in,
        )
    }


def _mapping(
    *,
    mapping_type: str = MappingType.VALUE,
    operator: str | None = None,
    value_num: Decimal | None = None,
    value_text: str | None = None,
    option_value: str | None = None,
    parameter_code: str = _QUESTION_PARAMETER,
) -> BiomarkerMapping:
    return BiomarkerMapping(
        biomarker_parameter_code=_BIOMARKER_PARAMETER,
        parameter_code=parameter_code,
        mapping_type=mapping_type,
        operator=operator,
        value_num=value_num,
        value_text=value_text,
        option_value=option_value,
        validity_period=_TEN_YEARS,
    )


def _plan(
    matched: list[MatchedBiomarker],
    *,
    mappings: Mapping[str, Sequence[BiomarkerMapping]] | None = None,
    stored: Mapping[str, StoredParameter] | None = None,
) -> list[ParameterWrite]:
    return list(plan_writes(matched, mappings=mappings or {}, stored=stored or {}, now=_NOW).writes)


def _by_code(writes: list[ParameterWrite]) -> dict[str, ParameterWrite]:
    return {write.parameter_code: write for write in writes}


# --- Шаг 5: правило свежести и дубль -------------------------------------------------------


def test_writes_when_no_record_exists() -> None:
    [write] = _plan([_matched()])
    assert write.parameter_code == _BIOMARKER_PARAMETER
    assert write.value == "3.6"
    assert write.external_id == 845231


def test_fresher_value_overwrites() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=1))
    [write] = _plan([matched], stored=_stored(date_time=_NOW - timedelta(days=10)))
    assert write.value == "3.6"


def test_older_value_is_not_written() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=20))
    assert _plan([matched], stored=_stored(date_time=_NOW - timedelta(days=10))) == []


def test_duplicate_is_not_written() -> None:
    """Переотправка того же результата: значение и момент совпали с сохранёнными."""
    moment = _NOW - timedelta(days=10)
    matched = _matched(value="3.0", date_time=moment)
    assert _plan([matched], stored=_stored(value="3.0", date_time=moment)) == []


def test_same_moment_with_other_value_is_not_written() -> None:
    """Свежесть считается строго: значение с тем же моментом сохранённое не вытесняет."""
    moment = _NOW - timedelta(days=10)
    matched = _matched(value="9.9", date_time=moment)
    assert _plan([matched], stored=_stored(value="3.0", date_time=moment)) == []


def test_expiration_is_counted_from_biomarker_moment() -> None:
    moment = _NOW - timedelta(days=1)
    [write] = _plan([_matched(date_time=moment)])
    assert write.date_time == moment
    assert write.expiration_date == moment + timedelta(days=365)


# --- Шаг 5: просроченное входящее значение --------------------------------------------------


def test_expired_value_does_not_replace_actual_record() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=400))
    stored = _stored(date_time=_NOW - timedelta(days=500), expires_in=timedelta(days=10))
    assert _plan([matched], stored=stored) == []


def test_expired_value_is_written_when_no_actual_record() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=400))
    stored = _stored(date_time=_NOW - timedelta(days=500), expires_in=timedelta(days=-1))
    [write] = _plan([matched], stored=stored)
    assert write.expiration_date < _NOW


def test_expired_value_does_not_fill_question_parameter() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=400))
    writes = _plan([matched], mappings={_BIOMARKER_PARAMETER: [_mapping()]})
    assert _by_code(writes).keys() == {_BIOMARKER_PARAMETER}


def test_empty_answer_is_not_treated_as_actual_record() -> None:
    """Пропущенный вопрос значения не несёт, поэтому просроченный биомаркер его не задерживает."""
    matched = _matched(date_time=_NOW - timedelta(days=400))
    stored = _stored(value="", date_time=_NOW - timedelta(days=500))
    assert len(_plan([matched], stored=stored)) == 1


# --- Шаг 6: виды разметки -------------------------------------------------------------------


def test_value_mapping_copies_coerced_value() -> None:
    writes = _by_code(_plan([_matched(value="3.6")], mappings={_BIOMARKER_PARAMETER: [_mapping()]}))
    assert writes[_QUESTION_PARAMETER].value == "3.6"
    assert writes[_QUESTION_PARAMETER].value == writes[_BIOMARKER_PARAMETER].value


def test_question_parameter_expiration_uses_its_own_validity() -> None:
    moment = _NOW - timedelta(days=1)
    writes = _by_code(_plan([_matched(date_time=moment)], mappings={_BIOMARKER_PARAMETER: [_mapping()]}))
    assert writes[_BIOMARKER_PARAMETER].expiration_date == moment + timedelta(days=365)
    assert writes[_QUESTION_PARAMETER].expiration_date == moment + timedelta(days=3650)


@pytest.mark.parametrize(
    ("operator", "threshold", "value", "expected"),
    [
        (MappingOperator.GT, "3.0", "3.6", True),
        (MappingOperator.GT, "3.0", "3.0", False),
        (MappingOperator.GTE, "3.0", "3.0", True),
        (MappingOperator.LT, "3.0", "2.9", True),
        (MappingOperator.LT, "3.0", "3.0", False),
        (MappingOperator.LTE, "3.0", "3.0", True),
    ],
)
def test_flag_mapping_numeric_operators(operator: str, threshold: str, value: str, expected: bool) -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=operator, value_num=Decimal(threshold), option_value="Да"
    )
    writes = _by_code(_plan([_matched(value=value)], mappings={_BIOMARKER_PARAMETER: [mapping]}))
    assert (_QUESTION_PARAMETER in writes) is expected
    if expected:
        assert writes[_QUESTION_PARAMETER].value == "Да"


def test_flag_mapping_equality_on_qualitative_biomarker() -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.EQ, value_text="Обнаружен", option_value="Да"
    )
    matched = _matched(value="Обнаружен", biomarker_type=BiomarkerType.QUALITATIVE)
    writes = _by_code(_plan([matched], mappings={_BIOMARKER_PARAMETER: [mapping]}))
    assert writes[_QUESTION_PARAMETER].value == "Да"


def test_flag_mapping_equality_not_met() -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.EQ, value_text="Обнаружен", option_value="Да"
    )
    matched = _matched(value="Не обнаружен", biomarker_type=BiomarkerType.QUALITATIVE)
    writes = _by_code(_plan([matched], mappings={_BIOMARKER_PARAMETER: [mapping]}))
    assert _QUESTION_PARAMETER not in writes


def test_numeric_operator_on_qualitative_biomarker_is_skipped() -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("3.0"), option_value="Да"
    )
    matched = _matched(value="Обнаружен", biomarker_type=BiomarkerType.QUALITATIVE)
    plan = plan_writes([matched], mappings={_BIOMARKER_PARAMETER: [mapping]}, stored={}, now=_NOW)
    assert [write.parameter_code for write in plan.writes] == [_BIOMARKER_PARAMETER]
    assert [skipped.parameter_code for skipped in plan.skipped_mappings] == [_QUESTION_PARAMETER]


def test_option_without_text_is_skipped() -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("3.0"), option_value=None
    )
    plan = plan_writes([_matched()], mappings={_BIOMARKER_PARAMETER: [mapping]}, stored={}, now=_NOW)
    assert [write.parameter_code for write in plan.writes] == [_BIOMARKER_PARAMETER]
    assert plan.skipped_mappings[0].reason == "option has no value"


def test_biomarker_without_mappings_writes_only_its_own_parameter() -> None:
    assert [write.parameter_code for write in _plan([_matched()])] == [_BIOMARKER_PARAMETER]


# --- Шаг 6: несколько условий на одну пару --------------------------------------------------


def test_only_met_condition_fills_question_parameter() -> None:
    """Условия пары проверяются все, а пишет параметр то из них, которое выполнилось."""
    above = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("5.0"), option_value="Да"
    )
    below = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.LT, value_num=Decimal("5.0"), option_value="Нет"
    )
    writes = _by_code(_plan([_matched(value="3.6")], mappings={_BIOMARKER_PARAMETER: [above, below]}))
    assert writes[_QUESTION_PARAMETER].value == "Нет"


def test_first_of_the_met_conditions_wins() -> None:
    """Выполнились оба условия: у записей одного биомаркера момент общий, и первая остаётся."""
    strict = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("3.0"), option_value="Да"
    )
    inclusive = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GTE, value_num=Decimal("3.0"), option_value="Иногда"
    )
    writes = _by_code(_plan([_matched(value="3.6")], mappings={_BIOMARKER_PARAMETER: [strict, inclusive]}))
    assert writes[_QUESTION_PARAMETER].value == "Да"


# --- Шаг 6: правило приоритета --------------------------------------------------------------


def test_answer_newer_than_biomarker_wins() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=10))
    stored = _stored(parameter_code=_QUESTION_PARAMETER, value="Нет", date_time=_NOW - timedelta(days=1))
    writes = _by_code(_plan([matched], mappings={_BIOMARKER_PARAMETER: [_mapping()]}, stored=stored))
    assert _QUESTION_PARAMETER not in writes


def test_biomarker_newer_than_answer_overwrites() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=1))
    stored = _stored(parameter_code=_QUESTION_PARAMETER, value="Нет", date_time=_NOW - timedelta(days=10))
    writes = _by_code(_plan([matched], mappings={_BIOMARKER_PARAMETER: [_mapping()]}, stored=stored))
    assert writes[_QUESTION_PARAMETER].value == "3.6"


def test_skipped_question_is_overwritten_regardless_of_dates() -> None:
    matched = _matched(date_time=_NOW - timedelta(days=10))
    stored = _stored(parameter_code=_QUESTION_PARAMETER, value="", date_time=_NOW - timedelta(days=1))
    writes = _by_code(_plan([matched], mappings={_BIOMARKER_PARAMETER: [_mapping()]}, stored=stored))
    assert writes[_QUESTION_PARAMETER].value == "3.6"


# --- Свёртка нескольких биомаркеров одного сообщения ----------------------------------------


def test_freshest_value_of_repeated_biomarker_wins() -> None:
    older = _matched(value="1.0", date_time=_NOW - timedelta(days=5), external_id=1)
    newer = _matched(value="2.0", date_time=_NOW - timedelta(days=1), external_id=2)
    [write] = _plan([older, newer])
    assert (write.value, write.external_id) == ("2.0", 2)


def test_repeated_biomarker_is_written_once() -> None:
    """Промежуточные значения в базу не едут: одно сообщение — не больше одной архивной строки."""
    values = [
        _matched(value="1.0", date_time=_NOW - timedelta(days=5), external_id=1),
        _matched(value="2.0", date_time=_NOW - timedelta(days=3), external_id=2),
        _matched(value="3.0", date_time=_NOW - timedelta(days=1), external_id=3),
    ]
    assert len(_plan(values)) == 1


def test_equal_moments_keep_the_first_biomarker() -> None:
    moment = _NOW - timedelta(days=1)
    first = _matched(value="1.0", date_time=moment, external_id=1)
    second = _matched(value="2.0", date_time=moment, external_id=2)
    [write] = _plan([first, second])
    assert write.value == "1.0"


def test_flag_is_set_by_any_biomarker_of_the_message() -> None:
    """OR: условие выполнил второй биомаркер — параметр опросника заполнен."""
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("3.0"), option_value="Да"
    )
    below = _matched(value="1.0", date_time=_NOW - timedelta(days=5), external_id=1)
    above = _matched(value="9.0", date_time=_NOW - timedelta(days=1), external_id=2)
    writes = _by_code(_plan([below, above], mappings={_BIOMARKER_PARAMETER: [mapping]}))
    assert writes[_QUESTION_PARAMETER].value == "Да"


def test_flag_set_by_older_biomarker_survives_newer_normal_value() -> None:
    mapping = _mapping(
        mapping_type=MappingType.FLAG, operator=MappingOperator.GT, value_num=Decimal("3.0"), option_value="Да"
    )
    above = _matched(value="9.0", date_time=_NOW - timedelta(days=5), external_id=1)
    below = _matched(value="1.0", date_time=_NOW - timedelta(days=1), external_id=2)
    writes = _by_code(_plan([above, below], mappings={_BIOMARKER_PARAMETER: [mapping]}))
    assert writes[_QUESTION_PARAMETER].value == "Да"
    assert writes[_BIOMARKER_PARAMETER].value == "1.0"
