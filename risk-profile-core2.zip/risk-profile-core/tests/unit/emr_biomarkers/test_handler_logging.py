"""Логирование обработчика записей топика `emr-biomarkers`.

Контракт лога — часть критерия приёмки: по записи должно быть видно, что именно отбраковано
и почему. Отдельно закрепляем уровень записей: невалидные данные внешнего продюсера пишутся
уровнем WARNING и не инкрементируют `risk_profile_core_errors_total` — иначе шумный продюсер
загонял бы метрику ошибок сервиса в красное.
"""

import logging

import pytest
from prometheus_client import REGISTRY

from src.emr_biomarkers.domain.constants import (
    BIOMARKER_LOG_VALUE_MAX_LENGTH,
    BIOMARKER_SKIP_LOG_LIMIT,
    EmrBiomarkerErrorCode,
)
from src.emr_biomarkers.domain.exceptions import InvalidBiomarkerError
from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.processing import BiomarkerSkip, ProcessingReport
from src.logger import BUSINESS_CHANNEL
from tests.unit.emr_biomarkers.conftest import (
    BIOMARKER_SKIPPED,
    MESSAGE_REJECTED,
    MESSAGE_VALIDATED,
    VALID_CLIENT_ID,
    StubProcessor,
    channel,
    contexts,
    handle,
    log_context,
    make_biomarker,
    make_payload,
)

_ERRORS_METRIC = "risk_profile_core_errors_total"


def _errors_total() -> float:
    """Сумма всех серий счётчика ошибок — по ней видно инкремент с любыми лейблами."""
    total = 0.0
    for metric in REGISTRY.collect():
        total += sum(sample.value for sample in metric.samples if sample.name == _ERRORS_METRIC)
    return total


async def test_rejected_message_logs_single_warning_with_code(log_records: list[logging.LogRecord]) -> None:
    """Отброшенное сообщение — ровно одна запись WARNING с кодом и причиной; исключения нет."""
    before = _errors_total()

    await handle(b"{")

    assert [record.getMessage() for record in log_records] == [MESSAGE_REJECTED]
    assert log_records[0].levelno == logging.WARNING
    context = log_context(log_records[0])
    assert context["error_code"] == EmrBiomarkerErrorCode.INVALID_MESSAGE
    assert context["reason"]
    assert _errors_total() == before


async def test_skipped_biomarker_logs_contract_fields(log_records: list[logging.LogRecord]) -> None:
    """Запись о пропуске несёт клиента и поля биомаркера — как требует контракт."""
    before = _errors_total()
    candidate = make_biomarker(
        id=845231,
        biomarkerCode=192,
        name="Ферритин",
        unit="нг/мл",
        unitCode=12,
        value="24",
        operationType="update",
    )

    await handle(make_payload([candidate]))

    skipped = [record for record in log_records if record.getMessage() == BIOMARKER_SKIPPED]
    assert len(skipped) == 1
    assert skipped[0].levelno == logging.WARNING
    # Все поля биомаркера — строки: на проводе они бывают любого типа, а ключ должен оставаться
    # одного типа, чтобы по нему можно было фильтровать в хранилище логов.
    assert log_context(skipped[0]) == {
        "client_id": VALID_CLIENT_ID,
        "biomarker_id": "845231",
        "biomarker_code": "192",
        "biomarker_name": "Ферритин",
        "biomarker_unit": "нг/мл",
        "biomarker_unit_code": "12",
        "biomarker_value": "24",
        "error_code": EmrBiomarkerErrorCode.INVALID_OPERATION_TYPE,
        "reason": log_context(skipped[0])["reason"],
    }
    assert log_context(skipped[0])["reason"]
    assert _errors_total() == before


@pytest.mark.parametrize("operation_type", [None, 456, True, {"value": "save"}, ["save"]])
async def test_invalid_operation_type_shape_logs_special_code(
    operation_type: object,
    log_records: list[logging.LogRecord],
) -> None:
    """Тип значения не меняет специальный код ошибки поля `operationType`."""
    await handle(make_payload([make_biomarker(operationType=operation_type)]))

    [context] = contexts(log_records, BIOMARKER_SKIPPED)
    assert context["error_code"] == EmrBiomarkerErrorCode.INVALID_OPERATION_TYPE
    assert context["reason"].startswith("operationType:")


async def test_missing_operation_type_logs_special_code(log_records: list[logging.LogRecord]) -> None:
    candidate = make_biomarker()
    del candidate["operationType"]

    await handle(make_payload([candidate]))

    [context] = contexts(log_records, BIOMARKER_SKIPPED)
    assert context["error_code"] == EmrBiomarkerErrorCode.INVALID_OPERATION_TYPE
    assert context["reason"].startswith("operationType:")


async def test_skipped_non_object_element_logs_empty_biomarker_fields(
    log_records: list[logging.LogRecord],
) -> None:
    """Элемент-не-объект: полей биомаркера взять неоткуда, но клиент и код причины в логе есть."""
    await handle(make_payload(["junk"]))

    context = contexts(log_records, BIOMARKER_SKIPPED)[0]
    assert context["client_id"] == VALID_CLIENT_ID
    assert context["error_code"] == EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT
    assert context["biomarker_id"] is None
    assert context["biomarker_code"] is None


async def test_successful_parse_logs_business_event_with_counters(log_records: list[logging.LogRecord]) -> None:
    """Итог разбора — бизнес-событие со счётчиками «всего / принято / пропущено»."""
    payload = make_payload([make_biomarker(id=1), make_biomarker(id=0), make_biomarker(id=3)])

    await handle(payload)

    validated = [record for record in log_records if record.getMessage() == MESSAGE_VALIDATED]
    assert len(validated) == 1
    assert validated[0].levelno == logging.INFO
    assert channel(validated[0]) == BUSINESS_CHANNEL
    assert log_context(validated[0]) == {
        "client_id": VALID_CLIENT_ID,
        "total": 3,
        "accepted": 2,
        "skipped": 1,
        "skipped_by_code": {EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT: 1},
        "skipped_not_logged": 0,
        "written": 0,
        "recalc_requested": False,
    }


async def test_oversized_biomarker_field_is_truncated_in_log(log_records: list[logging.LogRecord]) -> None:
    """Значение длиннее предела контракта режется с маркером: сообщение приходит от внешнего
    продюсера, и одна запись не должна раздувать лог-строку без предела."""
    await handle(make_payload([make_biomarker(name="x" * 10_000)]))

    logged = contexts(log_records, BIOMARKER_SKIPPED)[0]["biomarker_name"]
    assert logged.startswith("x" * BIOMARKER_LOG_VALUE_MAX_LENGTH)
    assert logged.endswith("...[truncated]")
    assert len(logged) == BIOMARKER_LOG_VALUE_MAX_LENGTH + len("...[truncated]")


async def test_biomarker_field_within_contract_limit_is_not_truncated(
    log_records: list[logging.LogRecord],
) -> None:
    """Значение, укладывающееся в предел контракта, доезжает до лога целиком."""
    name = "x" * BIOMARKER_LOG_VALUE_MAX_LENGTH
    await handle(make_payload([make_biomarker(name=name, value="")]))

    assert contexts(log_records, BIOMARKER_SKIPPED)[0]["biomarker_name"] == name


async def test_container_biomarker_field_logs_type_not_content(log_records: list[logging.LogRecord]) -> None:
    """Массив или объект вместо скаляра: в лог уходит тип — содержимое не диагностично,
    а его размер ничем не ограничен."""
    await handle(make_payload([make_biomarker(name={"ru": "x" * 10_000})]))

    assert contexts(log_records, BIOMARKER_SKIPPED)[0]["biomarker_name"] == "<dict>"


async def test_rejected_message_reason_is_truncated(log_records: list[logging.LogRecord]) -> None:
    """Причина отбраковки сообщения тоже режется: текст ошибки разбора цитирует сам payload."""
    await handle(b'{"clientId": "' + b"x" * 10_000)

    reason = contexts(log_records, MESSAGE_REJECTED)[0]["reason"]
    assert len(reason) <= BIOMARKER_LOG_VALUE_MAX_LENGTH + len("...[truncated]")


async def test_number_longer_than_int_parse_limit_is_invalid_message(log_records: list[logging.LogRecord]) -> None:
    """Число длиннее предела разбора целых в строку не разбирается — это `INVALID_MESSAGE`,
    а не сбой обработки записи: обработчик не бросает."""
    await handle(b'{"clientId": "abcde", "biomarkers": [' + b"1" * 5000 + b"]}")

    assert contexts(log_records, MESSAGE_REJECTED)[0]["error_code"] == EmrBiomarkerErrorCode.INVALID_MESSAGE


async def test_skip_logs_are_capped_and_remainder_stays_in_counters(
    log_records: list[logging.LogRecord],
) -> None:
    """Пропуски описываются поштучно до лимита, остальные остаются в счётчиках итога.

    Без этого одно сообщение, где не прошёл ни один биомаркер, вытесняло бы из логов всё
    остальное: массив ограничен сверху числом на порядки больше любой настоящей доставки.
    """
    broken = BIOMARKER_SKIP_LOG_LIMIT + 7
    payload = make_payload([make_biomarker(id=0)] * broken + [make_biomarker(id=1)])

    await handle(payload)

    assert len(contexts(log_records, BIOMARKER_SKIPPED)) == BIOMARKER_SKIP_LOG_LIMIT
    assert contexts(log_records, MESSAGE_VALIDATED)[0] == {
        "client_id": VALID_CLIENT_ID,
        "total": broken + 1,
        "accepted": 1,
        "skipped": broken,
        # Разбивка по причинам не усечена — по ней видно, что именно не прошло.
        "skipped_by_code": {EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT: broken},
        # Без этого числа неполнота поштучных записей читалась бы как «пропусков было столько,
        # сколько записей», и потеря семи пропусков осталась бы незамеченной.
        "skipped_not_logged": 7,
        "written": 0,
        "recalc_requested": False,
    }


async def test_skip_logs_are_not_capped_below_the_limit(log_records: list[logging.LogRecord]) -> None:
    """Пока пропусков не больше лимита, поштучно описан каждый и усечения не заявляется."""
    payload = make_payload([make_biomarker(id=0)] * BIOMARKER_SKIP_LOG_LIMIT)

    await handle(payload)

    assert len(contexts(log_records, BIOMARKER_SKIPPED)) == BIOMARKER_SKIP_LOG_LIMIT
    assert contexts(log_records, MESSAGE_VALIDATED)[0]["skipped_not_logged"] == 0


async def test_client_not_found_is_logged_at_message_level(log_records: list[logging.LogRecord]) -> None:
    """Пациента нет — сообщение не обработано целиком: код уровня сообщения, итога нет."""
    report = ProcessingReport(error_code=EmrBiomarkerErrorCode.CLIENT_NOT_FOUND, reason="no patient with this clientId")

    await handle(make_payload([make_biomarker()]), process=StubProcessor(report))

    [rejected] = contexts(log_records, MESSAGE_REJECTED)
    assert rejected["error_code"] == EmrBiomarkerErrorCode.CLIENT_NOT_FOUND
    assert rejected["client_id"] == VALID_CLIENT_ID
    assert contexts(log_records, MESSAGE_VALIDATED) == []


async def test_processing_failure_leaves_no_business_event(log_records: list[logging.LogRecord]) -> None:
    """Сбой обработки уже описан `alert`-ом: итог со счётчиками читался бы как «записей нет»."""
    await handle(make_payload([make_biomarker()]), process=StubProcessor(ProcessingReport(failed=True)))

    assert contexts(log_records, MESSAGE_VALIDATED) == []
    assert contexts(log_records, MESSAGE_REJECTED) == []


async def test_catalog_skip_is_logged_with_the_same_fields(log_records: list[logging.LogRecord]) -> None:
    """Пропуск на сверке описывается теми же полями, что и пропуск разбора."""
    biomarker = EmrBiomarker.model_validate(make_biomarker())
    skip = BiomarkerSkip(
        biomarker=biomarker,
        error=InvalidBiomarkerError(EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER, "biomarkerCode 192 is not in the catalog"),
    )

    await handle(make_payload([make_biomarker()]), process=StubProcessor(ProcessingReport(skips=(skip,))))

    [context] = contexts(log_records, BIOMARKER_SKIPPED)
    assert context["error_code"] == EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER
    assert context["biomarker_id"] == str(biomarker.id)
    assert context["biomarker_code"] == str(biomarker.biomarker_code)
    assert context["biomarker_unit_code"] == str(biomarker.unit_code)
    assert context["client_id"] == VALID_CLIENT_ID


async def test_catalog_rejected_first_occurrence_still_reserves_id(log_records: list[logging.LogRecord]) -> None:
    """Успешный разбор резервирует id до сверки, даже если справочник затем отклоняет элемент."""
    first_raw = make_biomarker(id=10, biomarkerCode=999)
    first = EmrBiomarker.model_validate(first_raw)
    catalog_skip = BiomarkerSkip(
        biomarker=first,
        error=InvalidBiomarkerError(EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER, "unknown"),
    )
    processor = StubProcessor(ProcessingReport(skips=(catalog_skip,)))

    await handle(
        make_payload([first_raw, make_biomarker(id=10, biomarkerCode=192)]),
        process=processor,
    )

    assert [(item.id, item.biomarker_code) for item in processor.calls[0][1]] == [(10, 999)]
    assert [context["error_code"] for context in contexts(log_records, BIOMARKER_SKIPPED)] == [
        EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT,
        EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER,
    ]
    assert contexts(log_records, MESSAGE_VALIDATED)[0]["accepted"] == 0
    assert contexts(log_records, MESSAGE_VALIDATED)[0]["skipped_by_code"] == {
        EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT: 1,
        EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER: 1,
    }


async def test_catalog_skips_share_the_per_message_log_limit(log_records: list[logging.LogRecord]) -> None:
    """Лимит поштучных записей общий: пропуски разбора и сверки считаются вместе."""
    parse_skips = BIOMARKER_SKIP_LOG_LIMIT - 1
    catalog_skips = 5
    skip = BiomarkerSkip(
        biomarker=EmrBiomarker.model_validate(make_biomarker()),
        error=InvalidBiomarkerError(EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER, "unknown"),
    )
    report = ProcessingReport(skips=(skip,) * catalog_skips)
    valid_biomarkers = [make_biomarker(id=index + 1) for index in range(catalog_skips)]
    payload = make_payload([make_biomarker(id=0)] * parse_skips + valid_biomarkers)

    await handle(payload, process=StubProcessor(report))

    assert len(contexts(log_records, BIOMARKER_SKIPPED)) == BIOMARKER_SKIP_LOG_LIMIT
    summary_context = contexts(log_records, MESSAGE_VALIDATED)[0]
    assert summary_context["skipped"] == parse_skips + catalog_skips
    assert summary_context["skipped_by_code"] == {
        EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT: parse_skips,
        EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER: catalog_skips,
    }
    assert summary_context["skipped_not_logged"] == parse_skips + catalog_skips - BIOMARKER_SKIP_LOG_LIMIT


async def test_business_event_reports_written_parameters_and_recalc(log_records: list[logging.LogRecord]) -> None:
    """Принятый биомаркер и сохранённый — не одно и то же: в итоге видно и записи, и пересчёт."""
    report = ProcessingReport(written_parameters=("biomarker_192_169", "sq_0100"), recalc_requested=True)

    await handle(make_payload([make_biomarker()]), process=StubProcessor(report))

    summary_context = contexts(log_records, MESSAGE_VALIDATED)[0]
    assert summary_context["written"] == 2
    assert summary_context["recalc_requested"] is True


async def test_summary_counters_add_up_to_the_element_count(log_records: list[logging.LogRecord]) -> None:
    """«Принято» — прошедшее весь входной контроль: принято плюс пропущено равно числу элементов.

    Пропуск на сверке со справочником считается пропуском, хотя разбор он прошёл: иначе по итогу
    сообщения выходило бы больше биомаркеров, чем в нём было.
    """
    skip = BiomarkerSkip(
        biomarker=EmrBiomarker.model_validate(make_biomarker()),
        error=InvalidBiomarkerError(EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER, "unknown"),
    )
    payload = make_payload([make_biomarker(id=0), make_biomarker(id=1), make_biomarker(id=2)])

    await handle(payload, process=StubProcessor(ProcessingReport(skips=(skip,), written_parameters=("p",))))

    summary_context = contexts(log_records, MESSAGE_VALIDATED)[0]
    assert summary_context["total"] == 3
    assert summary_context["accepted"] == 1
    assert summary_context["skipped"] == 2
    assert summary_context["accepted"] + summary_context["skipped"] == summary_context["total"]
