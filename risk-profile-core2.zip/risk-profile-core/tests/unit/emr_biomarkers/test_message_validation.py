"""Валидация уровня сообщения топика `emr-biomarkers` (шаг 1 бизнес-логики контракта).

Нарушение здесь отбрасывает сообщение целиком: биомаркеры не обрабатываются, в лог уходит
код `INVALID_MESSAGE`, итогового бизнес-события нет. Обработчик при этом не бросает —
невалидные данные внешнего продюсера не должны выглядеть как сбой обработки записи.
"""

import logging
from typing import Any

import pytest

from src.emr_biomarkers.domain.constants import BIOMARKERS_MAX_LENGTH, EmrBiomarkerErrorCode
from tests.unit.emr_biomarkers.conftest import (
    BIOMARKER_SKIPPED,
    MESSAGE_REJECTED,
    VALID_CLIENT_ID,
    contexts,
    encode,
    error_codes,
    handle,
    make_biomarker,
    make_payload,
    summary,
)

# Сообщение-пример из вики «Внешние-контракты-API/Emr-biomarkers».
WIKI_EXAMPLE: dict[str, Any] = {
    "clientId": "123e4567-e89b-12d3-a456-426614174000",
    "biomarkers": [
        {
            "id": 845231,
            "biomarkerCode": 192,
            "operationType": "save",
            "name": "Холестерин ЛПНП",
            "unit": "ммоль/л",
            "unitCode": 1,
            "value": "3.6",
            "dateTime": "2026-07-20T08:30:00",
        },
        {
            "id": 845232,
            "biomarkerCode": 159,
            "operationType": "save",
            "name": "Глюкоза натощак",
            "unit": "ммоль/л",
            "unitCode": 1,
            "value": "6.4",
            "dateTime": "2026-07-20T08:30:00",
        },
        {
            "id": 845233,
            "biomarkerCode": 38,
            "operationType": "save",
            "name": "Гемоглобин гликозилированный",
            "unit": "%",
            "unitCode": 8,
            "value": "7.1",
            "dateTime": "2026-07-20T08:30:00",
        },
        {
            "id": 845234,
            "biomarkerCode": 88,
            "operationType": "save",
            "name": "Ферритин",
            "unit": "нг/мл",
            "unitCode": 12,
            "value": "24",
            "dateTime": "2026-07-20T08:30:00",
        },
        {
            "id": 845235,
            "biomarkerCode": 1746,
            "operationType": "save",
            "name": "ДНК Chlamydia trachomatis, соскоб урогенитальный качественно",
            "unit": None,
            "unitCode": None,
            "value": "Обнаружен",
            "dateTime": "2026-06-11T14:05:00",
        },
    ],
}


async def test_wiki_example_is_accepted_in_full(log_records: list[logging.LogRecord]) -> None:
    """Пример сообщения из контракта разбирается, все пять биомаркеров приняты."""
    await handle(encode(WIKI_EXAMPLE))

    assert summary(log_records) == {
        "client_id": WIKI_EXAMPLE["clientId"],
        "total": 5,
        "accepted": 5,
        "skipped": 0,
        "skipped_by_code": {},
        "skipped_not_logged": 0,
        "written": 0,
        "recalc_requested": False,
    }
    assert error_codes(log_records, MESSAGE_REJECTED) == []


@pytest.mark.parametrize(
    ("case", "payload"),
    [
        ("payload_none", None),
        ("payload_empty", b""),
        ("not_json", b"{"),
        ("invalid_utf8", b"\xff\xfe{}"),
        ("json_array", b"[1, 2]"),
        ("json_string", b'"message"'),
        ("json_number", b"5"),
    ],
)
async def test_unreadable_payload_is_rejected(
    case: str, payload: bytes | None, log_records: list[logging.LogRecord]
) -> None:
    """Пустой, нечитаемый и не-объектный payload отбрасывают сообщение целиком."""
    await handle(payload)

    assert error_codes(log_records, MESSAGE_REJECTED) == [EmrBiomarkerErrorCode.INVALID_MESSAGE], case
    assert summary(log_records) == {}, case


@pytest.mark.parametrize(
    ("case", "message"),
    [
        ("client_id_missing", {"biomarkers": [make_biomarker()]}),
        ("client_id_null", {"clientId": None, "biomarkers": [make_biomarker()]}),
        ("client_id_number", {"clientId": 12345, "biomarkers": [make_biomarker()]}),
        ("client_id_too_short", {"clientId": "abcd", "biomarkers": [make_biomarker()]}),
        ("client_id_too_long", {"clientId": "a" * 37, "biomarkers": [make_biomarker()]}),
        ("client_id_space", {"clientId": "abc de", "biomarkers": [make_biomarker()]}),
        ("client_id_dot", {"clientId": "abc.de", "biomarkers": [make_biomarker()]}),
        ("client_id_at", {"clientId": "abc@de", "biomarkers": [make_biomarker()]}),
        ("client_id_cyrillic", {"clientId": "клиент", "biomarkers": [make_biomarker()]}),
        ("client_id_internal_name", {"client_id": VALID_CLIENT_ID, "biomarkers": [make_biomarker()]}),
        (
            "client_id_internal_name_with_alias",
            {"clientId": VALID_CLIENT_ID, "client_id": "another-client", "biomarkers": [make_biomarker()]},
        ),
        ("biomarkers_missing", {"clientId": VALID_CLIENT_ID}),
        ("biomarkers_null", {"clientId": VALID_CLIENT_ID, "biomarkers": None}),
        ("biomarkers_empty", {"clientId": VALID_CLIENT_ID, "biomarkers": []}),
        ("biomarkers_object", {"clientId": VALID_CLIENT_ID, "biomarkers": {"id": 1}}),
        ("biomarkers_string", {"clientId": VALID_CLIENT_ID, "biomarkers": "biomarker"}),
    ],
)
async def test_message_level_constraints_reject_message(
    case: str, message: dict[str, Any], log_records: list[logging.LogRecord]
) -> None:
    """Нарушение ограничений `clientId` / `biomarkers` отбрасывает сообщение с кодом контракта."""
    await handle(encode(message))

    assert error_codes(log_records, MESSAGE_REJECTED) == [EmrBiomarkerErrorCode.INVALID_MESSAGE], case
    assert summary(log_records) == {}, case


@pytest.mark.parametrize("client_id", ["abcde", "a" * 36], ids=["min_length_5", "max_length_36"])
async def test_client_id_length_boundaries_are_accepted(client_id: str, log_records: list[logging.LogRecord]) -> None:
    """Границы длины `clientId` включительные: 5 и 36 символов проходят."""
    await handle(make_payload([make_biomarker()], client_id=client_id))

    assert error_codes(log_records, MESSAGE_REJECTED) == []
    assert summary(log_records)["accepted"] == 1


async def test_unknown_top_level_field_is_ignored(log_records: list[logging.LogRecord]) -> None:
    """Новое поле продюсера не превращает валидное сообщение в ошибку."""
    await handle(make_payload([make_biomarker()], messageVersion=2))

    assert error_codes(log_records, MESSAGE_REJECTED) == []
    assert summary(log_records)["accepted"] == 1


async def test_batch_at_max_length_is_accepted(log_records: list[logging.LogRecord]) -> None:
    """Граница числа элементов включительная: батч ровно в потолок разбирается целиком."""
    biomarkers = [make_biomarker(id=index + 1) for index in range(BIOMARKERS_MAX_LENGTH)]
    await handle(make_payload(biomarkers))

    assert error_codes(log_records, MESSAGE_REJECTED) == []
    assert summary(log_records)["accepted"] == BIOMARKERS_MAX_LENGTH


async def test_batch_over_max_length_rejects_whole_message(log_records: list[logging.LogRecord]) -> None:
    """Массив сверх потолка — нарушение уровня сообщения: разбора элементов не происходит вовсе.

    Размер сообщения у брокера ограничивает число элементов на порядки выше любой настоящей
    доставки, поэтому без этой границы одно сообщение раздувало бы разбор и логи без предела.
    """
    await handle(make_payload([make_biomarker()] * (BIOMARKERS_MAX_LENGTH + 1)))

    assert error_codes(log_records, MESSAGE_REJECTED) == [EmrBiomarkerErrorCode.INVALID_MESSAGE]
    assert summary(log_records) == {}
    assert contexts(log_records, BIOMARKER_SKIPPED) == []
