"""Поведение обработки биомаркеров при сбое базы.

Различие принципиальное: ретраибельный сбой — это моргание базы, его гасят ретраи, а исчерпание
попыток фиксируется `alert`-ом, потому что передоставки не будет (общий консюмер коммитит оффсет
и на исключении). Неретраибельный — постоянный дефект, он обязан дойти наверх с трассировкой,
а не выглядеть тем же морганием. `alert` о нём пишется до того, как исключение уйдёт наверх:
общий перехват консюмера логирует любой сбой обработки записи одинаково, и без этой записи
дефект базы читался бы как невалидное сообщение внешнего продюсера.
"""

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from src.emr_biomarkers.processing import EmrBiomarkersProcessor
from src.exceptions import NonRetriableDbError, RetriableDbError
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from src.infra.db_retry import TransactionalRetryExecutor
from src.logger import ALERT
from tests.catalog_builder import make_catalog
from tests.unit.emr_biomarkers.conftest import VALID_CLIENT_ID, log_context


def _session_factory() -> Any:
    """Фабрика сессий, отдающая заглушку: до самой сессии тест не доходит — падает исполнитель."""

    @asynccontextmanager
    async def _factory() -> AsyncIterator[Any]:
        yield AsyncMock()

    return lambda: _factory()


def _processor(dispatch: AsyncMock) -> EmrBiomarkersProcessor:
    return EmrBiomarkersProcessor(_session_factory(), EmrBiomarkersCatalog(make_catalog()), dispatch)


async def test_retriable_failure_alerts_and_leaves_message_unprocessed(
    log_records: list[logging.LogRecord],
) -> None:
    dispatch = AsyncMock()
    failure = RetriableDbError("retriable db error: attempts exhausted", cause=OSError("boom"), attempts=3)

    with patch.object(TransactionalRetryExecutor, "run", AsyncMock(side_effect=failure)):
        report = await _processor(dispatch).process(VALID_CLIENT_ID, [])

    assert report.completed is False
    assert report.error_code is None  # это не код контракта: причина инфраструктурная
    dispatch.assert_not_awaited()
    [record] = [
        r for r in log_records if r.getMessage() == "emr.biomarkers: message processing failed, message skipped"
    ]
    assert record.levelno == ALERT
    assert log_context(record)["client_id"] == VALID_CLIENT_ID


async def test_non_retriable_failure_alerts_and_propagates(log_records: list[logging.LogRecord]) -> None:
    dispatch = AsyncMock()
    failure = NonRetriableDbError("non-retriable db error", cause=ValueError("schema"), attempts=1)

    with (
        patch.object(TransactionalRetryExecutor, "run", AsyncMock(side_effect=failure)),
        pytest.raises(NonRetriableDbError),
    ):
        await _processor(dispatch).process(VALID_CLIENT_ID, [])

    dispatch.assert_not_awaited()
    [record] = [
        r
        for r in log_records
        if r.getMessage() == "emr.biomarkers: message processing failed, database error is permanent"
    ]
    assert record.levelno == ALERT
    assert record.exc_info is not None  # трассировку читает тот, кто чинит базу
    assert log_context(record)["client_id"] == VALID_CLIENT_ID
    assert log_context(record)["attempts"] == 1
