"""Сверка биомаркера со справочником (шаг 4 бизнес-логики контракта).

Проверки идут по строкам справочника, переданным аргументом: модуль сверки к базе не обращается,
поэтому и тесты обходятся без неё.
"""

from datetime import UTC, datetime

import pytest

from src.emr_biomarkers.domain.catalog import BiomarkerEntry
from src.emr_biomarkers.domain.constants import BiomarkerType, EmrBiomarkerErrorCode
from src.emr_biomarkers.domain.exceptions import InvalidBiomarkerError
from src.emr_biomarkers.domain.matching import match_biomarker
from src.emr_biomarkers.domain.models import EmrBiomarker
from tests.unit.emr_biomarkers.conftest import make_biomarker

# Срок жизни параметра: колонка `parameters.validity_period` хранит длительность от эпохи,
# поэтому «год» — это 1971-01-01. Для сверки значение неважно, важен лишь его тип.
_VALIDITY = datetime(1971, 1, 1, tzinfo=UTC)

_BIOMARKER_CODE = 192
_UNIT_CODE = 169


def _entry(
    *,
    unit_code: int | None = _UNIT_CODE,
    parameter_code: str = "biomarker_192_169",
    biomarker_type: str = BiomarkerType.QUANTITATIVE,
    parameter_status: str = "active",
) -> BiomarkerEntry:
    return BiomarkerEntry(
        biomarker_code=_BIOMARKER_CODE,
        unit_code=unit_code,
        parameter_code=parameter_code,
        type=biomarker_type,
        parameter_status=parameter_status,
        validity_period=_VALIDITY,
    )


def _biomarker(**overrides: object) -> EmrBiomarker:
    fields = {"biomarkerCode": _BIOMARKER_CODE, "unitCode": _UNIT_CODE, **overrides}
    return EmrBiomarker.model_validate(make_biomarker(**fields))


def _code_of(exc_info: pytest.ExceptionInfo[InvalidBiomarkerError]) -> str:
    return exc_info.value.code


def test_unknown_biomarker() -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(), [])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER


def test_unit_unexpected_for_dimensionless_biomarker() -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(), [_entry(unit_code=None)])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.UNIT_UNEXPECTED


def test_unit_missing_when_catalog_requires_one() -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(unitCode=None, unit=None), [_entry()])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.UNIT_MISSING


def test_unit_not_allowed() -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(unitCode=_UNIT_CODE + 1), [_entry()])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.UNIT_NOT_ALLOWED


def test_multi_unit_biomarker_selects_its_own_entry() -> None:
    """У биомаркера с несколькими единицами каждая запись несёт свой параметр."""
    other = _entry(unit_code=10, parameter_code="biomarker_192_10")
    matched = match_biomarker(_biomarker(), [other, _entry()])
    assert matched.entry.parameter_code == "biomarker_192_169"


def test_dimensionless_biomarker_matches_entry_without_unit() -> None:
    matched = match_biomarker(
        _biomarker(unitCode=None, unit=None, value="Обнаружен"),
        [_entry(unit_code=None, parameter_code="biomarker_192", biomarker_type=BiomarkerType.QUALITATIVE)],
    )
    assert matched.entry.parameter_code == "biomarker_192"


def test_parameter_not_active() -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(), [_entry(parameter_status="inactive")])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.PARAMETER_NOT_ACTIVE


def test_parameter_status_is_checked_before_value() -> None:
    """Порядок проверок контракта: выключенный параметр отбраковывает и валидное значение."""
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(value="не число"), [_entry(parameter_status="inactive")])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.PARAMETER_NOT_ACTIVE


@pytest.mark.parametrize(
    ("raw", "expected"),
    [("3,60", "3.6"), ("3.6", "3.6"), ("24", "24"), ("0.000001", "0.000001"), ("-1,5", "-1.5")],
)
def test_quantitative_value_is_coerced(raw: str, expected: str) -> None:
    assert match_biomarker(_biomarker(value=raw), [_entry()]).value == expected


# Пустое значение в этот набор не входит: его отбраковывает валидация формата (шаг 3),
# до сверки оно не доходит.
@pytest.mark.parametrize("raw", ["положительно", "3,6,1", "1e", "nan", "Infinity"])
def test_quantitative_value_rejected(raw: str) -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(value=raw), [_entry()])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.INVALID_VALUE


def test_quantitative_value_out_of_numeric_range() -> None:
    """`Numeric(12, 6)` вмещает шесть цифр целой части — семизначное значение не сохранить."""
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(value="1234567.0"), [_entry()])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.INVALID_VALUE


@pytest.mark.parametrize("raw", ["Обнаружен", "Не обнаружен"])
def test_qualitative_value_kept_as_is(raw: str) -> None:
    matched = match_biomarker(
        _biomarker(value=raw, unitCode=None, unit=None),
        [_entry(unit_code=None, biomarker_type=BiomarkerType.QUALITATIVE)],
    )
    assert matched.value == raw


@pytest.mark.parametrize("raw", ["Положительно", "обнаружен", "ОБНАРУЖЕН", "3.6"])
def test_qualitative_value_rejected(raw: str) -> None:
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(
            _biomarker(value=raw, unitCode=None, unit=None),
            [_entry(unit_code=None, biomarker_type=BiomarkerType.QUALITATIVE)],
        )
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.INVALID_VALUE


def test_unsupported_catalog_type_rejects_value() -> None:
    """Тип «перечисление» из справочника СберЗдоровья в скоуп не входит: проверить значение нечем."""
    with pytest.raises(InvalidBiomarkerError) as exc_info:
        match_biomarker(_biomarker(), [_entry(biomarker_type="enumeration")])
    assert _code_of(exc_info) == EmrBiomarkerErrorCode.INVALID_VALUE
