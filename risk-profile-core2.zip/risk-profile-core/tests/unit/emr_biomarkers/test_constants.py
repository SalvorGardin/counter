"""Кодовые константы обработки биомаркеров совпадают с контрактом.

Коды причин уходят наружу — в лог и в тест-кейсы контура, — поэтому набор фиксируется тестом:
опечатка в значении члена перечисления кода не ломает, а делает причину ненаходимой в Kibana.
"""

from src.emr_biomarkers.domain.constants import BIOMARKER_SOURCE, EmrBiomarkerErrorCode
from src.services.risk_init.domain.constants import ANSWER_SOURCE_EMR

# Раздел «Коды ошибок» вики «Внешние-контракты-API/Emr-biomarkers», оба уровня последствия.
_CONTRACT_ERROR_CODES = frozenset(
    {
        "INVALID_MESSAGE",
        "CLIENT_NOT_FOUND",
        "INVALID_OPERATION_TYPE",
        "INVALID_BIOMARKER_FORMAT",
        "UNKNOWN_BIOMARKER",
        "UNIT_UNEXPECTED",
        "UNIT_MISSING",
        "UNIT_NOT_ALLOWED",
        "PARAMETER_NOT_ACTIVE",
        "INVALID_VALUE",
    }
)


def test_error_codes_match_contract() -> None:
    assert {code.value for code in EmrBiomarkerErrorCode} == _CONTRACT_ERROR_CODES


def test_biomarker_source_matches_anthropometry_source() -> None:
    """Биомаркеры и антропометрия — один источник `EMR`: отдельного значения контракт не вводит."""
    assert BIOMARKER_SOURCE == ANSWER_SOURCE_EMR
