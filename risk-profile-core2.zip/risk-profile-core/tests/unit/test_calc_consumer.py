"""Unit-тесты воркера calc_consumer.

Покрывают путь принудительной отмены runner-а при зависании обработчика сообщений и разбор
команды в `_handle_command` — без реального Kafka/DB/CVD: вся инфра подменяется AsyncMock-ами.
"""

import asyncio
import os
import signal as signal_module
from collections.abc import Awaitable, Callable
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import src.workers.calc_consumer as calc_consumer
import src.workers.consumer_runtime as consumer_runtime
from src.calc.background_admission import BackgroundAdmission
from tests.consts import PARAMETER_CODE_HEIGHT


def _admission(capacity: int = 1, *, saturated: bool = False) -> BackgroundAdmission:
    """Политика допуска с предсказуемым внешним сервисом: её собственные тесты живут отдельно
    (tests/unit/calc/test_background_admission.py), здесь она только не должна мешать."""
    return BackgroundAdmission(capacity, is_saturated=lambda: saturated)


@pytest.fixture(autouse=True)
def _calculation_runtime(monkeypatch: pytest.MonkeyPatch, no_primary_runtime: None) -> None:
    """Процесс до старта: основной рантайм поднимает сам `_main` воркера, под ролью расчёта."""
    # Логин рантайма сверяется с БД на старте; здесь БД нет, а проверка не предмет этих тестов —
    # её держит tests/integration/db_isolation/test_runtime_login_check.py.
    monkeypatch.setattr(calc_consumer, "verify_runtime_login", AsyncMock())


def _fake_health_server() -> MagicMock:
    """Подменяет uvicorn.Server: serve() завершается сразу (порт не биндится), should_exit
    выставляется реальным атрибутом — тесты _main не поднимают настоящий сервер проб."""
    server = MagicMock()
    server.serve = AsyncMock()
    server.should_exit = False
    return server


async def test_force_cancel_on_stuck_runner_exits_nonzero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Если runner завис и wait_for истёк — _main поднимает RuntimeError (exit code != 0).

    Сценарий: consumer.run() никогда не возвращается (обработчик дедлочит),
    SIGTERM получен, wait_for(timeout=0.05s) истекает → runner.cancel() → crashed
    должен быть установлен → raise в конце _main → asyncio.run завершается с ошибкой.

    До фикса: crashed оставался None, процесс писал notice("stopped") и выходил кодом 0.
    """

    async def hanging_run() -> None:
        await asyncio.Event().wait()

    mock_consumer = MagicMock()
    # SIGTERM отправляется из side_effect consumer.start(): к этому моменту _main уже
    # зарегистрировал signal handler (add_signal_handler вызывается ДО _start_with_retry).
    mock_consumer.start = AsyncMock(
        side_effect=lambda: os.kill(os.getpid(), signal_module.SIGTERM),
    )
    mock_consumer.run = hanging_run
    mock_consumer.stop = AsyncMock()

    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(calc_consumer.settings, "consumer_shutdown_timeout", 0.05)

    with (
        patch.object(calc_consumer, "init_kafka_producer", AsyncMock()),
        patch.object(calc_consumer, "init_cvd_client", AsyncMock()),
        patch.object(calc_consumer, "catalog_builder", AsyncMock(return_value=MagicMock())),
        patch.object(calc_consumer, "KafkaTopicConsumer", return_value=mock_consumer),
        patch.object(consumer_runtime, "build_server", return_value=_fake_health_server()),
        patch("src.workers.calc_consumer.shutdown_cvd_client", AsyncMock()),
        patch("src.workers.calc_consumer.shutdown_kafka_producer", AsyncMock()),
        patch("src.workers.calc_consumer.shutdown_primary_runtime", AsyncMock()),
    ):
        with pytest.raises(RuntimeError, match="force-cancelled"):
            await calc_consumer._main()


async def test_consumer_stop_timeout_alerts_and_does_not_raise(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """consumer.stop() может зависнуть при TCP-blackhole (LeaveGroup без ответа).

    Проверяем: wait_for истекает → alert() вызван → _main НЕ падает из-за этого таймаута
    (runner завершился штатно, сам consumer.stop() просто не дождался ответа брокера).
    """

    async def hanging_stop() -> None:
        await asyncio.Event().wait()

    mock_consumer = MagicMock()
    mock_consumer.start = AsyncMock(
        side_effect=lambda: os.kill(os.getpid(), signal_module.SIGTERM),
    )
    mock_consumer.run = AsyncMock()
    mock_consumer.stop = hanging_stop

    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", True)
    monkeypatch.setattr(calc_consumer.settings, "consumer_shutdown_timeout", 0.05)

    with (
        patch.object(calc_consumer, "init_kafka_producer", AsyncMock()),
        patch.object(calc_consumer, "init_cvd_client", AsyncMock()),
        patch.object(calc_consumer, "catalog_builder", AsyncMock(return_value=MagicMock())),
        patch.object(calc_consumer, "KafkaTopicConsumer", return_value=mock_consumer),
        patch.object(consumer_runtime, "build_server", return_value=_fake_health_server()),
        patch("src.workers.calc_consumer.shutdown_cvd_client", AsyncMock()),
        patch("src.workers.calc_consumer.shutdown_kafka_producer", AsyncMock()),
        patch("src.workers.calc_consumer.shutdown_primary_runtime", AsyncMock()),
        patch.object(consumer_runtime, "alert") as mock_alert,
    ):
        await calc_consumer._main()

    msgs = [c[0][0] for c in mock_alert.call_args_list]
    assert any("consumer.stop()" in m for m in msgs)


async def test_idle_mode_serves_and_stops_health_server(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """При выключенной Kafka воркер простаивает, но сервер проб поднимается и корректно гасится.

    Проверяем: build_server вызван с settings.host/consumer_health_port, а на выходе из idle
    у сервера выставлен should_exit (его гасит _stop_health_server)."""
    fake_server = _fake_health_server()

    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", False)
    monkeypatch.setattr(calc_consumer.settings, "host", "127.0.0.1")
    monkeypatch.setattr(calc_consumer.settings, "consumer_health_port", 8123)

    with (
        patch.object(consumer_runtime, "build_server", return_value=fake_server) as mock_build,
        patch.object(calc_consumer, "idle_until_signal", AsyncMock()),
    ):
        await calc_consumer._main()

    mock_build.assert_called_once()
    assert mock_build.call_args.kwargs == {"host": "127.0.0.1", "port": 8123}
    fake_server.serve.assert_awaited_once()
    assert fake_server.should_exit is True


async def test_health_bind_failure_fails_fast_and_stops_server(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Порт проб занят на старте → serve() падает; _main пробрасывает сбой ДО старта консюмера
    и всё равно гасит серверную задачу в finally. Консюмер при этом не поднимается."""
    fake_server = _fake_health_server()
    fake_server.started = False  # порт не забиндился
    fake_server.serve = AsyncMock(side_effect=OSError("address already in use"))

    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", True)

    with (
        patch.object(consumer_runtime, "build_server", return_value=fake_server),
        patch.object(calc_consumer, "init_kafka_producer", AsyncMock()) as mock_producer,
        pytest.raises(OSError, match="address already in use"),
    ):
        await calc_consumer._main()

    mock_producer.assert_not_awaited()  # консюмер не стартовал
    assert fake_server.should_exit is True  # серверная задача погашена в finally _main


async def test_handle_command_forwards_enqueued_at() -> None:
    """Отметка постановки в очередь доезжает из сообщения до расчёта — по ней считается ожидание."""
    payload = {"clientId": "p1", "parameterCodes": [PARAMETER_CODE_HEIGHT], "enqueuedAt": 1_700_000_000.5}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission())

    assert run_mock.await_args is not None
    assert run_mock.await_args.kwargs["enqueued_at"] == 1_700_000_000.5


async def test_handle_command_without_enqueued_at_runs_unmeasured() -> None:
    """Команда без отметки (старое сообщение) считается как обычно, просто без замера."""
    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(
            {"clientId": "p1", "parameterCodes": None}, catalogs=MagicMock(), admission=_admission()
        )

    assert run_mock.await_args is not None
    assert run_mock.await_args.args == ("p1", None)
    assert run_mock.await_args.kwargs["enqueued_at"] is None


async def test_teardown_releases_resources_in_order_within_remaining_budget(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Порядок гашения: cvd-клиент → дренаж продюсера → пул соединений, остаток бюджета — продюсеру.

    Порядок не косметический. Продюсер дренируется после cvd-клиента, потому что расчёт может
    дослать событие-результат, и закрытый раньше времени продюсер потерял бы его молча; пул
    соединений закрывается последним, потому что до него ещё пишутся результаты обработки.
    Бюджет отдаётся именно продюсеру: это единственный шаг, который может ждать брокера.
    """
    calls: list[str] = []
    captured: list[Callable[[float], Awaitable[None]]] = []

    async def _capture_serve(
        _consumer: object,
        _health: object,
        *,
        name: str,  # noqa: ARG001
        teardown: Callable[[float], Awaitable[None]],
    ) -> None:
        captured.append(teardown)

    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", True)

    with (
        patch.object(calc_consumer, "catalog_builder", AsyncMock(return_value=MagicMock())),
        patch.object(calc_consumer, "init_kafka_producer", AsyncMock()),
        patch.object(calc_consumer, "init_cvd_client", AsyncMock()),
        patch.object(calc_consumer, "KafkaTopicConsumer", MagicMock()),
        patch.object(calc_consumer, "serve_until_stop", _capture_serve),
        patch.object(calc_consumer, "shutdown_cvd_client", AsyncMock(side_effect=lambda: calls.append("cvd"))) as cvd,
        patch.object(
            calc_consumer,
            "shutdown_kafka_producer",
            AsyncMock(side_effect=lambda **_kwargs: calls.append("producer")),
        ) as producer,
        patch.object(calc_consumer, "shutdown_primary_runtime", AsyncMock(side_effect=lambda: calls.append("engine"))),
    ):
        await calc_consumer._run(MagicMock())
        assert captured, "serve_until_stop должен получить teardown"
        await captured[0](2.5)

    assert calls == ["cvd", "producer", "engine"]
    cvd.assert_awaited_once()
    assert producer.await_args is not None
    assert producer.await_args.kwargs["drain_timeout"] == 2.5


async def test_run_builds_catalogs_before_starting_clients(monkeypatch: pytest.MonkeyPatch) -> None:
    """Каталоги строятся до продюсера и cvd-клиента.

    Тем же вызовом стартовый heap уходит из-под gen2-сборки, поэтому объекты клиентов, которые
    переживают переподключения, не должны попасть под заморозку — их создают уже после.
    """
    order: list[str] = []
    monkeypatch.setattr(calc_consumer.settings.kafka, "enabled", True)

    with (
        patch.object(
            calc_consumer,
            "catalog_builder",
            AsyncMock(side_effect=lambda: order.append("catalogs") or MagicMock()),
        ),
        patch.object(calc_consumer, "init_kafka_producer", AsyncMock(side_effect=lambda: order.append("producer"))),
        patch.object(calc_consumer, "init_cvd_client", AsyncMock(side_effect=lambda: order.append("cvd"))),
        patch.object(calc_consumer, "KafkaTopicConsumer", MagicMock()),
        patch.object(calc_consumer, "serve_until_stop", AsyncMock()),
    ):
        await calc_consumer._run(MagicMock())

    assert order == ["catalogs", "producer", "cvd"]


async def test_background_command_is_dropped_when_no_slot_is_free() -> None:
    """Отброшенная фоновая команда не считается: расчёт не запускается, а возврат из обработчика
    означает обработанное сообщение, то есть оффсет коммитится и очередь не блокируется."""
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission(capacity=0))

    run_mock.assert_not_awaited()


async def test_background_command_runs_when_a_slot_is_free() -> None:
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission(capacity=1))

    run_mock.assert_awaited_once()


async def test_background_flag_reaches_the_calculation() -> None:
    """Признак идёт дальше обработчика: по нему расчёт разделяет ряды метрик (лейбл `source`)
    и явно штампует реестр версий при пустом исходе."""
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission(capacity=1))

    assert run_mock.await_args is not None
    assert run_mock.await_args.kwargs["background"] is True


async def test_user_command_reaches_the_calculation_without_the_flag() -> None:
    payload = {"clientId": "p1", "parameterCodes": None}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission(capacity=1))

    assert run_mock.await_args is not None
    assert run_mock.await_args.kwargs["background"] is False


async def test_partial_command_with_the_background_marker_runs_as_a_user_command() -> None:
    """Сочетание частичного пересчёта с признаком фоновой прогон не порождает; такая команда
    идёт мимо политики допуска и попадает в пользовательские ряды метрик."""
    payload = {"clientId": "p1", "parameterCodes": ["a"], "background": True}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=_admission(capacity=0))

    assert run_mock.await_args is not None
    assert run_mock.await_args.kwargs["background"] is False


async def test_background_command_is_dropped_while_the_risk_service_is_saturated() -> None:
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}
    admission = _admission(capacity=1, saturated=True)

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=admission)

    run_mock.assert_not_awaited()


async def test_user_command_runs_even_with_no_background_capacity() -> None:
    """Ёмкость пользовательских команд фоновым ограничением не уменьшается."""
    payload = {"clientId": "p1", "parameterCodes": None}

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(
            payload, catalogs=MagicMock(), admission=_admission(capacity=0, saturated=True)
        )

    run_mock.assert_awaited_once()


async def test_background_slot_is_released_after_the_command() -> None:
    """Слот держится только на время обработки: иначе после первой же команды фон закрылся бы
    навсегда."""
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}
    admission = _admission(capacity=1)

    with patch.object(calc_consumer, "run_recalc", AsyncMock()) as run_mock:
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=admission)
        await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=admission)

    assert run_mock.await_count == 2
    assert admission.in_flight == 0


async def test_slot_is_released_even_if_the_recalculation_crashes() -> None:
    payload = {"clientId": "p1", "parameterCodes": None, "background": True}
    admission = _admission(capacity=1)

    with patch.object(calc_consumer, "run_recalc", AsyncMock(side_effect=RuntimeError("boom"))):
        with pytest.raises(RuntimeError):
            await calc_consumer._handle_command(payload, catalogs=MagicMock(), admission=admission)

    assert admission.in_flight == 0
