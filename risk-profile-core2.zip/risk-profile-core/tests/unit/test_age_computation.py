"""Возраст по дате рождения — две реализации, одна таблица случаев.

Полных лет считают два места: `compute_age` (risk-init, оттуда же значение параметра age берёт
risk-communication) и `_years_between` внутри условия по возрасту (`classify_question`, шаг 4
wiki Risk-profile). Реализации независимы, а расходиться им нельзя: одна решает, сколько лет
записать пациенту, вторая — попадает ли пациент в возрастное условие вопроса. Поэтому таблица
границ здесь одна и применяется к обеим.
"""

from datetime import date

import pytest

from src.services.risk_communication.domain.conditions import _years_between
from src.services.risk_init.domain.age import compute_age

# (дата рождения, дата расчёта, полных лет)
_AGE_CASES = [
    (date(1990, 3, 15), date(2026, 5, 21), 36),  # день рождения в этом году прошёл
    (date(1990, 9, 1), date(2026, 5, 21), 35),  # ещё не наступил
    (date(1990, 5, 21), date(2026, 5, 21), 36),  # ровно сегодня
    (date(1990, 5, 22), date(2026, 5, 21), 35),  # завтра
    (date(2026, 5, 21), date(2026, 5, 21), 0),  # родился сегодня
    # 29 февраля: в невисокосный год день рождения считается наступившим 1 марта.
    (date(2000, 2, 29), date(2026, 2, 28), 25),
    (date(2000, 2, 29), date(2026, 3, 1), 26),
    (date(2000, 2, 29), date(2024, 2, 29), 24),  # високосный год — ровно в день рождения
    # Границы года: 31 декабря и 1 января не должны давать лишний или недостающий год.
    (date(1999, 12, 31), date(2025, 12, 30), 25),
    (date(1999, 12, 31), date(2025, 12, 31), 26),
    (date(1999, 1, 1), date(2025, 12, 31), 26),
    # Возраст 18 — совершеннолетие, гейт допуска инструментов к расчёту.
    (date(2008, 1, 2), date(2026, 1, 1), 17),
    (date(2008, 1, 1), date(2026, 1, 1), 18),
    # Дата рождения из будущего даёт отрицательный возраст, а не ноль: вызывающая сторона
    # отсекает такое значение сама (см. _derive_age), и подменять его здесь нельзя.
    (date(2030, 1, 1), date(2026, 5, 21), -4),
    (date(2026, 5, 22), date(2026, 5, 21), -1),
]


@pytest.mark.parametrize(("birthdate", "today", "expected"), _AGE_CASES)
def test_compute_age(birthdate: date, today: date, expected: int) -> None:
    assert compute_age(birthdate, today) == expected


@pytest.mark.parametrize(("birthdate", "today", "expected"), _AGE_CASES)
def test_years_between_agrees_with_compute_age(birthdate: date, today: date, expected: int) -> None:
    """Условие по возрасту считает те же полные годы, что записаны пациенту в параметр age."""
    assert _years_between(birthdate, today) == expected
