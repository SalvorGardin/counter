"""Общий matcher условий факторов риска: операторы, пол, несовпавшие параметры.

Реализация одна на отбор факторов интерпретации, расчёт клинрек-факторов биомаркеров и сверку
снимка условия в объяснении, поэтому операторы проверяются здесь, на самой функции.
"""

from dataclasses import dataclass
from decimal import Decimal

import pytest

from src.domain.risk_factor_conditions import RiskFactorOperator, condition_matches
from tests.consts import GENDER_FEMALE, GENDER_MALE


@dataclass(frozen=True, slots=True)
class _Condition:
    operator: str
    value_num: Decimal | None = None
    min_value: Decimal | None = None
    max_value: Decimal | None = None
    value_text: str | None = None
    gender: str | None = None


@pytest.mark.parametrize(
    ("operator", "value_num", "answer", "expected"),
    [
        (RiskFactorOperator.GT, "5", "6", True),
        (RiskFactorOperator.GT, "5", "5", False),
        (RiskFactorOperator.GTE, "5", "5", True),
        (RiskFactorOperator.GTE, "5", "4.9", False),
        (RiskFactorOperator.LT, "5", "4", True),
        (RiskFactorOperator.LT, "5", "5", False),
        (RiskFactorOperator.LTE, "5", "5", True),
        (RiskFactorOperator.LTE, "5", "5.1", False),
    ],
)
def test_numeric_operators(operator: str, value_num: str, answer: str, expected: bool) -> None:
    condition = _Condition(operator=operator, value_num=Decimal(value_num))
    assert condition_matches(condition, answer, None) is expected


def test_between_includes_both_bounds() -> None:
    condition = _Condition(operator=RiskFactorOperator.BETWEEN, min_value=Decimal("10"), max_value=Decimal("20"))
    assert condition_matches(condition, "10", None) is True
    assert condition_matches(condition, "20", None) is True
    assert condition_matches(condition, "20.1", None) is False


def test_eq_compares_text() -> None:
    condition = _Condition(operator=RiskFactorOperator.EQ, value_text="Да")
    assert condition_matches(condition, "Да", None) is True
    assert condition_matches(condition, "Нет", None) is False


def test_decimal_comma_answer_is_parsed() -> None:
    condition = _Condition(operator=RiskFactorOperator.GT, value_num=Decimal("5"))
    assert condition_matches(condition, "5,5", None) is True


def test_non_numeric_answer_does_not_match_numeric_operator() -> None:
    condition = _Condition(operator=RiskFactorOperator.GT, value_num=Decimal("5"))
    assert condition_matches(condition, "много", None) is False


def test_gender_restriction() -> None:
    condition = _Condition(operator=RiskFactorOperator.GT, value_num=Decimal("5"), gender=GENDER_FEMALE)
    assert condition_matches(condition, "6", GENDER_FEMALE) is True
    assert condition_matches(condition, "6", GENDER_MALE) is False
    # Пол пациента неизвестен — условие с ограничением по полу не срабатывает.
    assert condition_matches(condition, "6", None) is False


def test_empty_gender_in_condition_matches_any_patient() -> None:
    condition = _Condition(operator=RiskFactorOperator.GT, value_num=Decimal("5"))
    assert condition_matches(condition, "6", GENDER_MALE) is True
    assert condition_matches(condition, "6", None) is True


def test_missing_bounds_never_match() -> None:
    assert condition_matches(_Condition(operator=RiskFactorOperator.GT), "6", None) is False
    assert condition_matches(_Condition(operator=RiskFactorOperator.BETWEEN), "6", None) is False
