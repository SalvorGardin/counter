from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from src.domain.biomarker_duplicates import excluded_biomarker_parameter_codes, instrument_parameter_values

_NOW = datetime(2026, 1, 1, tzinfo=UTC)
# `a`, `b`, `d` — разные представления одного биомаркера, `plain` — параметр вне его справочников.
# `third` связан с теми же `a` и `b`, что и `first`: обязательность задаётся на каждый инструмент
# своя, и тесту нужны два инструмента с одной парой параметров.
_BY_INSTRUMENT = {"first": {"a", "b", "d", "plain"}, "second": {"b", "c"}, "third": {"a", "b"}}
_BIOMARKER_CODES = {"a": 10, "b": 10, "c": 10, "d": 10}
_COMPETING = frozenset(_BIOMARKER_CODES)
# Обязательных параметров у инструмента нет — отбор идёт по времени и идентификатору записи.
_NO_REQUIRED: dict[str, set[str]] = {}


@dataclass(frozen=True)
class _Row:
    parameter_code: str
    date_time: datetime
    patient_parameter_id: int
    value: str = "value"


def _excluded(
    *rows: _Row,
    instrument_code: str = "first",
    required_by_instrument: dict[str, set[str]] = _NO_REQUIRED,
) -> frozenset[str]:
    return excluded_biomarker_parameter_codes(
        rows,
        instrument_code,
        _BY_INSTRUMENT,
        _BIOMARKER_CODES,
        _COMPETING,
        required_by_instrument,
    )


def test_excludes_older_value_of_same_biomarker() -> None:
    assert _excluded(_Row("a", _NOW, 1), _Row("b", _NOW + timedelta(seconds=1), 2)) == frozenset({"a"})


def test_keeps_single_value() -> None:
    assert _excluded(_Row("a", _NOW, 1)) == frozenset()


def test_keeps_parameter_with_undefined_biomarker_code() -> None:
    assert _excluded(_Row("plain", _NOW, 1), _Row("a", _NOW, 2)) == frozenset()


def test_equal_date_time_keeps_smallest_patient_parameter_id() -> None:
    assert _excluded(_Row("a", _NOW, 8), _Row("b", _NOW, 3)) == frozenset({"a"})


def test_skipped_answer_does_not_displace_value_of_same_biomarker() -> None:
    """Пропуск вопроса в выборку не входит и не вытесняет более раннее значение другой единицы."""
    rows = (_Row("a", _NOW, 1, "150"), _Row("b", _NOW + timedelta(seconds=1), 2, ""))

    assert _excluded(*rows) == frozenset()


def test_parameters_compete_only_inside_selected_instrument() -> None:
    rows = (_Row("a", _NOW + timedelta(seconds=2), 1), _Row("b", _NOW + timedelta(seconds=1), 2))

    assert _excluded(*rows, instrument_code="first") == frozenset({"b"})
    assert _excluded(*rows, instrument_code="second") == frozenset()


def test_instrument_values_exclude_only_loser_in_selected_instrument() -> None:
    parameters = {
        "a": _Row("a", _NOW, 1, "old"),
        "b": _Row("b", _NOW + timedelta(seconds=1), 2, "new"),
        "plain": _Row("plain", _NOW, 3, "plain"),
    }

    excluded = _excluded(*parameters.values())

    assert instrument_parameter_values(parameters, _BY_INSTRUMENT["first"], excluded) == {"b": "new", "plain": "plain"}


def test_required_parameter_is_not_displaced_by_fresher_optional_value() -> None:
    rows = (_Row("a", _NOW, 1), _Row("b", _NOW + timedelta(seconds=1), 2))

    assert _excluded(*rows, required_by_instrument={"first": {"a"}}) == frozenset({"b"})


def test_required_parameter_outranks_every_optional_repeat() -> None:
    rows = (
        _Row("a", _NOW, 3),
        _Row("b", _NOW + timedelta(seconds=1), 1),
        _Row("d", _NOW + timedelta(seconds=2), 2),
    )

    assert _excluded(*rows, required_by_instrument={"first": {"a"}}) == frozenset({"b", "d"})


def test_freshest_wins_among_two_required_parameters() -> None:
    rows = (_Row("a", _NOW, 1), _Row("b", _NOW + timedelta(seconds=1), 2))

    assert _excluded(*rows, required_by_instrument={"first": {"a", "b"}}) == frozenset({"a"})


def test_equal_date_time_of_two_required_parameters_keeps_smallest_id() -> None:
    rows = (_Row("a", _NOW, 8), _Row("b", _NOW, 3))

    assert _excluded(*rows, required_by_instrument={"first": {"a", "b"}}) == frozenset({"a"})


def test_required_flag_is_read_for_the_instrument_being_filtered() -> None:
    """Параметр обязателен для одного инструмента и необязателен для другого — выборки расходятся."""
    rows = (_Row("a", _NOW, 1), _Row("b", _NOW + timedelta(seconds=1), 2))
    required = {"first": {"a"}}

    assert _excluded(*rows, instrument_code="first", required_by_instrument=required) == frozenset({"b"})
    assert _excluded(*rows, instrument_code="third", required_by_instrument=required) == frozenset({"a"})
