import pytest

from src.services.risk_communication.domain.gendered_text import pick_text
from tests.consts import GENDER_FEMALE, GENDER_MALE

_NEUTRAL = "Я расстроен(а)"
_MALE = "Я расстроен"
_FEMALE = "Я расстроена"


@pytest.mark.parametrize(
    ("gender", "expected"),
    [
        (GENDER_FEMALE, _FEMALE),
        (GENDER_MALE, _MALE),
        (None, _NEUTRAL),
        # Иное значение (в т.ч. пропущенный ответ — пустая строка) — пол неизвестен.
        ("", _NEUTRAL),
        ("unknown", _NEUTRAL),
    ],
    ids=["female", "male", "no-gender", "skipped", "other-value"],
)
def test_form_follows_patient_gender(gender: str | None, expected: str) -> None:
    assert pick_text(neutral=_NEUTRAL, male=_MALE, female=_FEMALE, gender=gender) == expected


@pytest.mark.parametrize("gender", [GENDER_FEMALE, GENDER_MALE, None])
def test_text_without_gendered_forms_stays_neutral(gender: str | None) -> None:
    assert pick_text(neutral="Я плачу", male=None, female=None, gender=gender) == "Я плачу"
