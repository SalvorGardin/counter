"""Unit-тесты coerce_numeric_answer — приведение answer к Numeric(precision=12, scale=6)."""

import pytest

from src.services.risk_communication.domain.exceptions import InvalidAnswerTypeError
from src.services.risk_communication.domain.numeric import coerce_numeric_answer


class TestValidNormalization:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("0", "0"),
            ("1", "1"),
            ("42", "42"),
            ("1.5", "1.5"),
            ("100", "100"),
            ("-3.14", "-3.14"),
            # leading-нули не подмешиваем обратно
            ("0001.5", "1.5"),
            ("000042", "42"),
            # trailing-нули после запятой не подмешиваем обратно
            ("1.500000", "1.5"),
            ("0.500000", "0.5"),
            # максимум integer-цифр = 6 (precision-scale)
            ("999999.999999", "999999.999999"),
            # все знаки после запятой используются
            ("0.000001", "0.000001"),
            # научная нотация на входе допустима, на выходе — фиксированная
            ("5e2", "500"),
            ("1.5e-3", "0.0015"),
            # отрицательный ноль нормализуется в "0"
            ("-0", "0"),
            ("-0.0", "0"),
            # запятая как десятичный разделитель трактуется как точка
            ("1,5", "1.5"),
            ("0,000001", "0.000001"),
            ("-3,14", "-3.14"),
        ],
    )
    def test_normalizes(self, raw: str, expected: str) -> None:
        assert coerce_numeric_answer(raw) == expected

    def test_whitespace_stripped(self) -> None:
        assert coerce_numeric_answer("  1.5  ") == "1.5"


class TestRounding:
    def test_rounds_to_six_decimals_half_up(self) -> None:
        # 1.2345678 → 1.234568 (ROUND_HALF_UP)
        assert coerce_numeric_answer("1.2345678") == "1.234568"

    def test_truncates_negligible_decimals(self) -> None:
        # 0.0000001 < половины quantum → округляется до 0
        assert coerce_numeric_answer("0.0000001") == "0"

    def test_rounds_negative(self) -> None:
        assert coerce_numeric_answer("-1.2345675") == "-1.234568"


class TestInvalidInput:
    @pytest.mark.parametrize("raw", ["abc", "1.2.3", "", " ", "1,2,3", "1,2.3", "--1", "1e", "0x10"])
    def test_non_numeric_raises(self, raw: str) -> None:
        with pytest.raises(InvalidAnswerTypeError):
            coerce_numeric_answer(raw)

    @pytest.mark.parametrize("raw", ["NaN", "Infinity", "-Infinity", "Inf"])
    def test_non_finite_raises(self, raw: str) -> None:
        with pytest.raises(InvalidAnswerTypeError):
            coerce_numeric_answer(raw)

    @pytest.mark.parametrize("raw", ["1000000", "1000000.0", "-1000000", "1e6", "9999999.999999"])
    def test_integer_part_overflow_raises(self, raw: str) -> None:
        with pytest.raises(InvalidAnswerTypeError):
            coerce_numeric_answer(raw)
