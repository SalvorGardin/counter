"""Юнит-тесты compute_completion_percentage (шаги 11-12 Risk-communication).

Заполненность считается в целых вопросах расчётной системы. COMMON отдельно НЕ добавляется —
это ключевое отличие от прежней методологии (раньше scope = calc ∪ COMMON). Каталог собирается
из DTO в памяти — тем же классом `HttpCatalog`, что и в проде, поэтому индексы (система→параметры,
вопрос→параметры, порядок вопросов) проверяются настоящие, а не имитация. Глубокая логика
классификации вопросов покрыта в tests/unit/risk_communication/test_completion.py (общий core).
"""

from datetime import UTC, datetime

from src.infra.catalog.http import HttpCatalog
from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.constants import PREGNANCY_QUESTION_CODE
from src.services.risk_communication.progress import compute_completion_percentage
from tests.catalog_builder import (
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    parameter,
    question,
    system,
    system_instrument,
)

_TODAY = datetime(2026, 7, 24, tzinfo=UTC).date()
_VALIDITY = datetime(2099, 1, 1, tzinfo=UTC)


def _catalog(
    *,
    params_by_system: dict[str, set[str]],
    params_by_question: dict[str, set[str]],
) -> HttpCatalog:
    """Минимальный каталог: система → параметры, вопрос → параметры (через options).

    Обе связи в проде косвенные: система держит параметры через systems_instruments →
    instruments_parameters, вопрос — через options.parameter_code. Разворачиваем их так же,
    чтобы тест шёл по тем же индексам HttpCatalog, что и запрос.
    """
    parameter_codes = {code for codes in params_by_system.values() for code in codes} | {
        code for codes in params_by_question.values() for code in codes
    }
    question_codes = sorted(params_by_question)
    return HttpCatalog(
        make_catalog(
            systems=[
                system(code, system_id=rang, rang=rang) for rang, code in enumerate(sorted(params_by_system), start=1)
            ],
            parameters=[
                parameter(code, parameter_id=i, description=code, validity_period=_VALIDITY)
                for i, code in enumerate(sorted(parameter_codes), start=1)
            ],
            instruments=[
                instrument(f"i_{code}", instrument_id=i, description=code)
                for i, code in enumerate(sorted(params_by_system), start=1)
            ],
            systems_instruments=[system_instrument(code, f"i_{code}") for code in sorted(params_by_system)],
            instruments_parameters=[
                instrument_parameter(f"i_{sys_code}", param_code, is_required=True)
                for sys_code, params in sorted(params_by_system.items())
                for param_code in sorted(params)
            ],
            questions=[
                question(code, group_code=1, question_id=i, question=code)
                for i, code in enumerate(question_codes, start=1)
            ],
            options=[
                option(f"o_{q}_{p}", question_code=q, parameter_code=p, option_id=i)
                for i, (q, p) in enumerate(
                    ((q, p) for q in question_codes for p in sorted(params_by_question[q])), start=1
                )
            ],
        )
    )


def _answered(*codes: str) -> dict[str, ActiveParameter]:
    exp = datetime(2099, 1, 1, tzinfo=UTC)
    return {
        c: ActiveParameter(
            parameter_code=c,
            value="Да",
            expiration_date=exp,
            date_time=exp,
            patient_parameter_id=0,
        )
        for c in codes
    }


def _pct(
    catalog: HttpCatalog,
    *,
    calc_system_code: str,
    active: dict[str, ActiveParameter],
    is_pregnant: bool | None = None,
) -> int:
    return compute_completion_percentage(
        catalog=catalog,
        calc_system_code=calc_system_code,
        active_parameters=active,
        today=_TODAY,
        is_pregnant=is_pregnant,
    )


def test_common_not_unioned_into_calc_system() -> None:
    # SYS: q_s1 (отвечён) + q_s2 (не отвечён). COMMON: q_c1 (не отвечён) — НЕ должен влиять на SYS.
    catalog = _catalog(
        params_by_system={"SYS": {"s1", "s2"}, "COMMON": {"c1"}},
        params_by_question={"q_s1": {"s1"}, "q_s2": {"s2"}, "q_c1": {"c1"}},
    )
    # applicable={q_s1,q_s2}, progressed={q_s1} → floor(1/2×100)=50. Юнион с COMMON дал бы 1/3=33.
    assert _pct(catalog, calc_system_code="SYS", active=_answered("s1")) == 50


def test_calc_common_computes_own_progress() -> None:
    # Расчётной системой может быть сама COMMON (шаг 6 маршрутизировал на неё) — считаем её вопросы.
    catalog = _catalog(
        params_by_system={"COMMON": {"c1", "c2"}},
        params_by_question={"q_c1": {"c1"}, "q_c2": {"c2"}},
    )
    assert _pct(catalog, calc_system_code="COMMON", active=_answered("c1")) == 50


def test_empty_denominator_returns_100() -> None:
    # Нет вопросов, относящихся к системе → applicable=0 → 100.
    catalog = _catalog(params_by_system={"SYS": {"s1"}}, params_by_question={})
    assert _pct(catalog, calc_system_code="SYS", active={}) == 100


def test_cq030_progressed_via_is_pregnant() -> None:
    catalog = _catalog(
        params_by_system={"SYS": {"is_pregnant"}},
        params_by_question={PREGNANCY_QUESTION_CODE: {"is_pregnant"}},
    )
    # is_pregnant=False (ответ дан) → cq_030 progressed → 100.
    assert _pct(catalog, calc_system_code="SYS", active={}, is_pregnant=False) == 100
    # is_pregnant=None (не отвечен) → applicable=1, progressed=0 → 0.
    assert _pct(catalog, calc_system_code="SYS", active={}, is_pregnant=None) == 0
