"""Unit-тесты parse_iso_date — общего чтения ISO-дат из patients_parameters.value.

Парсер один на age-условия (conditions.py) и деривацию возраста (bug #169), поэтому его контракт
пинится здесь, а не в каждом из вызывающих мест: любой нераспознанный ввод — None, без исключения.
"""

from datetime import date

import pytest

from src.services.risk_communication.domain.iso_date import parse_iso_date


class TestParsed:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("1987-05-14", date(1987, 5, 14)),
            ("2000-01-01", date(2000, 1, 1)),
            ("2024-02-29", date(2024, 2, 29)),  # високосный год
        ],
    )
    def test_returns_date(self, raw: str, expected: date) -> None:
        assert parse_iso_date(raw) == expected


class TestNotParsed:
    def test_none_returns_none(self) -> None:
        # Параметра у пациента нет вовсе — вызывающий не обязан ветвиться до парсера.
        assert parse_iso_date(None) is None

    @pytest.mark.parametrize(
        "raw",
        [
            "",  # пропуск вопроса (isSkipped) пишет в параметр пустую строку
            " ",
            "abc",
            "14.05.1987",  # не ISO
            "1987-13-01",  # несуществующий месяц
            "1987-02-30",  # несуществующий день
            "1987",  # неполная дата
            "1987-05-14T10:00:00",  # datetime со временем — не date
        ],
    )
    def test_unparsable_returns_none_without_raising(self, raw: str) -> None:
        assert parse_iso_date(raw) is None
