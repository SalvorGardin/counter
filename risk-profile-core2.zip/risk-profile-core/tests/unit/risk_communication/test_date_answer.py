"""Unit-тесты coerce_date_answer — валидация/канонизация answer для вопросов type='date'."""

import pytest

from src.services.risk_communication.domain.date_answer import coerce_date_answer
from src.services.risk_communication.domain.exceptions import InvalidAnswerTypeError


class TestValidNormalization:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("1987-05-14", "1987-05-14"),
            ("2000-01-01", "2000-01-01"),
            ("2024-02-29", "2024-02-29"),  # високосный год
            # пробелы по краям срезаются
            ("  1987-05-14  ", "1987-05-14"),
        ],
    )
    def test_normalizes(self, raw: str, expected: str) -> None:
        assert coerce_date_answer(raw) == expected


class TestInvalidInput:
    @pytest.mark.parametrize(
        "raw",
        [
            "",
            " ",
            "abc",
            "14.05.1987",  # не ISO
            "05/14/1987",  # не ISO
            "1987-13-01",  # несуществующий месяц
            "1987-02-30",  # несуществующий день
            "1987-5-14",  # без ведущих нулей — не ISO для date
            "1987",  # неполная дата
            "1987-05-14T10:00:00",  # datetime со временем — не date
        ],
    )
    def test_non_iso_date_raises(self, raw: str) -> None:
        with pytest.raises(InvalidAnswerTypeError):
            coerce_date_answer(raw)

    def test_error_message_does_not_leak_pii_value(self) -> None:
        # str(exc) уходит в тело 400-ответа и логируется целиком — answer (дата рождения, ПДн)
        # не должен в нём фигурировать (маскирование логов по ключам его внутри message не ловит).
        with pytest.raises(InvalidAnswerTypeError) as exc_info:
            coerce_date_answer("1987-05-14T10:00:00")
        assert "1987" not in str(exc_info.value)
