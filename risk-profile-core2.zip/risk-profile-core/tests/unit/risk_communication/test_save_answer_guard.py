"""Страховка `_save_answer`: тело ответа без единого типа ответа.

На HTTP-границе такой запрос отсекает `validate_cross_fields` (400 INVALID_ANSWER_TYPE,
см. tests/api/test_risk_communication.py). Этот тест держит вторую линию: если сервис
позовут мимо роутера, он должен поднять доменную ошибку, а не молча записать пустоту
и вернуть 200 «ответ принят».
"""

from datetime import UTC, datetime
from unittest.mock import MagicMock

import pytest

from src.api.v1.risk_communication.schemas import AnswerRequest
from src.services.risk_communication.domain.exceptions import InvalidAnswerTypeError
from src.services.risk_communication.domain.models import QuestionView
from src.services.risk_communication.service import RiskCommunicationService

_NOW = datetime(2026, 7, 24, tzinfo=UTC)


def _question(*, code: str = "q1", type_: str = "select") -> QuestionView:
    return QuestionView(question_id=1, code=code, text=code, type=type_, is_skippable=True, group_code=1)


@pytest.mark.asyncio
@pytest.mark.parametrize("body", [AnswerRequest(), AnswerRequest(is_skipped=False)])
async def test_answer_without_any_answer_field_is_rejected(body: AnswerRequest) -> None:
    """`{}` и `{"isSkipped": false}` — оба «ответа нет»: запись не делается, поднимается ошибка.

    Сессия — MagicMock: до записи дело не доходит, любой её вызов означал бы, что пустой
    ответ уже что-то поменял в patients_parameters.
    """
    session = MagicMock()
    service = RiskCommunicationService(session, MagicMock())
    changed: set[str] = set()

    with pytest.raises(InvalidAnswerTypeError):
        await service._save_answer(
            client_id="patient-1",
            question=_question(),
            body=body,
            now=_NOW,
            changed=changed,
        )

    assert changed == set()
    session.execute.assert_not_called()
