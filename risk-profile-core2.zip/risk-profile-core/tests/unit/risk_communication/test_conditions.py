"""Юнит-тесты classify_question (шаг 4 wiki Risk-profile).

Пол (`except` по `gender`) и возраст (`age`) фильтруют знаменатель applicable_questions;
прочие `except` дают авто-зачёт в числителе (hidden=True) — вопрос считается пройденным,
потому что не будет показан пациенту.
"""

import logging
from datetime import UTC, datetime

import pytest

from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.conditions import classify_question, question_is_visible
from src.services.risk_communication.domain.constants import BIRTHDATE_PARAMETER_CODE, GENDER_PARAMETER_CODE
from src.services.risk_communication.domain.models import ConditionView
from tests.consts import GENDER_FEMALE, GENDER_MALE

_TODAY = datetime(2026, 7, 24, tzinfo=UTC).date()
_EXP = datetime(2099, 1, 1, tzinfo=UTC)


def _active(**pairs: str) -> dict[str, ActiveParameter]:
    return {
        c: ActiveParameter(
            parameter_code=c,
            value=v,
            expiration_date=_EXP,
            date_time=_EXP,
            patient_parameter_id=0,
        )
        for c, v in pairs.items()
    }


def _except(parameter_code: str, value: str) -> ConditionView:
    return ConditionView(type="except", parameter_code=parameter_code, value=value, min_age=None, max_age=None)


def _age(*, min_age: int | None = None, max_age: int | None = None) -> ConditionView:
    return ConditionView(
        type="age", parameter_code=BIRTHDATE_PARAMETER_CODE, value=None, min_age=min_age, max_age=max_age
    )


def test_no_conditions_is_applicable_and_not_hidden() -> None:
    result = classify_question(conditions=[], active_parameters=_active(), today=_TODAY)
    assert result.applicable is True
    assert result.hidden is False


def test_gender_except_match_excludes_from_denominator() -> None:
    result = classify_question(
        conditions=[_except(GENDER_PARAMETER_CODE, GENDER_MALE)],
        active_parameters=_active(gender=GENDER_MALE),
        today=_TODAY,
    )
    assert result.applicable is False
    assert result.hidden is False


def test_gender_except_no_match_stays_applicable() -> None:
    result = classify_question(
        conditions=[_except(GENDER_PARAMETER_CODE, GENDER_MALE)],
        active_parameters=_active(gender=GENDER_FEMALE),
        today=_TODAY,
    )
    assert result.applicable is True


def test_age_out_of_range_excludes_from_denominator() -> None:
    # birthdate 2010 → возраст 16 на _TODAY; условие min_age=18 не проходит.
    result = classify_question(
        conditions=[_age(min_age=18)],
        active_parameters=_active(**{BIRTHDATE_PARAMETER_CODE: "2010-01-01"}),
        today=_TODAY,
    )
    assert result.applicable is False


def test_age_in_range_stays_applicable() -> None:
    result = classify_question(
        conditions=[_age(min_age=18, max_age=65)],
        active_parameters=_active(**{BIRTHDATE_PARAMETER_CODE: "1990-01-01"}),
        today=_TODAY,
    )
    assert result.applicable is True


def test_non_gender_except_match_auto_credits_numerator() -> None:
    # except cancer=Нет: у пациента cancer='Нет' → условие срабатывает → вопрос скрыт (авто-зачёт).
    result = classify_question(
        conditions=[_except("cancer", "Нет")],
        active_parameters=_active(cancer="Нет"),
        today=_TODAY,
    )
    assert result.applicable is True
    assert result.hidden is True


def test_non_gender_except_no_match_is_visible() -> None:
    result = classify_question(
        conditions=[_except("cancer", "Нет")],
        active_parameters=_active(cancer="Да"),
        today=_TODAY,
    )
    assert result.applicable is True
    assert result.hidden is False


def test_gender_and_non_gender_conditions_combine() -> None:
    # Пол проходит (Женский != Мужской), но не-gender except скрывает вопрос → applicable + hidden.
    result = classify_question(
        conditions=[_except(GENDER_PARAMETER_CODE, GENDER_MALE), _except("cancer", "Нет")],
        active_parameters=_active(gender=GENDER_FEMALE, cancer="Нет"),
        today=_TODAY,
    )
    assert result.applicable is True
    assert result.hidden is True


def test_unknown_condition_type_treated_as_pass() -> None:
    unknown = ConditionView(type="weird", parameter_code="x", value="y", min_age=None, max_age=None)
    result = classify_question(conditions=[unknown], active_parameters=_active(), today=_TODAY)
    assert result.applicable is True
    assert result.hidden is False


# --- edge: отсутствующие демографические/управляющие параметры ---


def test_age_condition_missing_birthdate_excludes() -> None:
    # Нет актуальной записи birthdate → возраст не вычислить → вопрос исключается из знаменателя.
    result = classify_question(conditions=[_age(min_age=18)], active_parameters=_active(), today=_TODAY)
    assert result.applicable is False


def test_gender_except_missing_gender_stays_applicable() -> None:
    # Нет записи gender → conditions.value не с чем сравнивать → вопрос НЕ исключается (applicable).
    result = classify_question(
        conditions=[_except(GENDER_PARAMETER_CODE, GENDER_MALE)], active_parameters=_active(), today=_TODAY
    )
    assert result.applicable is True
    assert result.hidden is False


def test_non_gender_except_missing_param_is_visible() -> None:
    # Управляющий параметр show-условия не отвечён → условие не срабатывает → вопрос виден (не hidden).
    result = classify_question(conditions=[_except("cancer", "Нет")], active_parameters=_active(), today=_TODAY)
    assert result.applicable is True
    assert result.hidden is False


# --- question_is_visible: незнакомый тип условия ---


def test_question_is_visible_treats_unknown_condition_type_as_pass(caplog: pytest.LogCaptureFixture) -> None:
    """Незнакомый `condition.type` в справочнике не скрывает вопрос, но пишет warning.

    Это осознанный компромисс: битый сид делает вопрос безусловно видимым, а не роняет
    опросник, — и warning остаётся единственным следом такой ошибки данных.
    """
    unknown = ConditionView(type="weird", parameter_code="x", value="y", min_age=None, max_age=None)

    with caplog.at_level(logging.WARNING, logger="app"):
        visible = question_is_visible(conditions=[unknown], active_parameters=_active(), today=_TODAY)

    assert visible is True
    assert "unknown condition type, skipping (treat as pass)" in caplog.text
