"""Отрицательные исходы выбора системы и вопроса (шаги 6–11).

Каждый ранний `return None` здесь — это точка, где опросник заканчивается или, при ошибке
в справочнике, молча встаёт. Каталог собирается тем же `HttpCatalog`, что и в проде, чтобы
проверялись настоящие индексы, а не имитация.
"""

from datetime import UTC, datetime

from src.infra.catalog.http import HttpCatalog
from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.constants import COMMON_SYSTEM_CODE
from src.services.risk_communication.selection import (
    SelectionContext,
    _has_visible_question,
    first_visible_question,
    pick_question,
    resolve_selection_system,
)
from tests.catalog_builder import (
    condition,
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    parameter,
    question,
    system,
    system_instrument,
)

_TODAY = datetime(2026, 7, 24, tzinfo=UTC).date()
_VALIDITY = datetime(2099, 1, 1, tzinfo=UTC)
_GENDER = "cq_010"


def _catalog(
    *,
    params_by_system: dict[str, set[str]],
    params_by_question: dict[str, set[str]] | None = None,
    conditions: tuple[object, ...] = (),
) -> HttpCatalog:
    """Система → параметры и вопрос → параметры разворачиваются теми же связями, что в проде:
    systems_instruments → instruments_parameters и options.parameter_code."""
    params_by_question = params_by_question or {}
    parameter_codes = {code for codes in params_by_system.values() for code in codes} | {
        code for codes in params_by_question.values() for code in codes
    }
    question_codes = sorted(params_by_question)
    return HttpCatalog(
        make_catalog(
            systems=[
                system(code, system_id=rang, rang=rang) for rang, code in enumerate(sorted(params_by_system), start=1)
            ],
            parameters=[
                parameter(code, parameter_id=i, validity_period=_VALIDITY)
                for i, code in enumerate(sorted(parameter_codes), start=1)
            ],
            instruments=[
                instrument(f"i_{code}", instrument_id=i) for i, code in enumerate(sorted(params_by_system), start=1)
            ],
            systems_instruments=[system_instrument(code, f"i_{code}") for code in sorted(params_by_system)],
            instruments_parameters=[
                instrument_parameter(f"i_{sys_code}", param_code, is_required=True)
                for sys_code, params in sorted(params_by_system.items())
                for param_code in sorted(params)
            ],
            questions=[question(code, group_code=1, question_id=i) for i, code in enumerate(question_codes, start=1)],
            options=[
                option(f"o_{q}_{p}", question_code=q, parameter_code=p, option_id=i)
                for i, (q, p) in enumerate(
                    ((q, p) for q in question_codes for p in sorted(params_by_question[q])), start=1
                )
            ],
            conditions=conditions,
        )
    )


def _answered(*codes: str, value: str = "Да") -> dict[str, ActiveParameter]:
    return {
        c: ActiveParameter(
            parameter_code=c,
            value=value,
            expiration_date=_VALIDITY,
            date_time=_VALIDITY,
            patient_parameter_id=0,
        )
        for c in codes
    }


def _resolve(
    catalog: HttpCatalog, active: dict[str, ActiveParameter], requested: str | None = None
) -> SelectionContext | None:
    return resolve_selection_system(
        catalog=catalog,
        requested_system_code=requested,
        active_parameters=active,
        today=_TODAY,
    )


# --- шаги 6/8: система не выбирается ------------------------------------------------------------


def test_system_skipped_when_all_its_parameters_answered() -> None:
    """Все параметры системы отвечены — система пропускается, кандидатов больше нет."""
    catalog = _catalog(params_by_system={"SYS": {"s1"}}, params_by_question={"q_s1": {"s1"}})

    assert _resolve(catalog, _answered("s1")) is None


def test_system_skipped_when_every_question_is_hidden() -> None:
    """Единственный вопрос системы скрыт `except`-условием — система недостижима и пропускается.

    Без этой проверки flow вернул бы систему, для которой затем не нашлось бы ни одного вопроса,
    и опросник встал бы на ней навсегда.
    """
    catalog = _catalog(
        params_by_system={"SYS": {"s1"}},
        params_by_question={"q_s1": {"s1"}},
        conditions=(condition("q_s1", _GENDER, value="Женский"),),
    )

    assert _resolve(catalog, _answered(_GENDER, value="Женский")) is None


def test_system_without_questions_is_skipped() -> None:
    """Параметр системы не привязан ни к одному вопросу — спрашивать нечего."""
    catalog = _catalog(params_by_system={"SYS": {"s1"}})

    assert _resolve(catalog, {}) is None


def test_explicitly_requested_common_yields_no_selection() -> None:
    """COMMON как явный `systemCode` перекрытием уже обработан, в цикле кандидатов он пропускается."""
    catalog = _catalog(
        params_by_system={COMMON_SYSTEM_CODE: {"c1"}},
        params_by_question={"q_c1": {"c1"}},
    )

    assert _resolve(catalog, _answered("c1"), requested=COMMON_SYSTEM_CODE) is None


# --- шаги 7–11: вопрос не выбирается ------------------------------------------------------------


def test_pick_question_returns_none_for_empty_unanswered_set() -> None:
    catalog = _catalog(params_by_system={"SYS": {"s1"}}, params_by_question={"q_s1": {"s1"}})
    selection = SelectionContext(chosen_system_code="SYS", unanswered_parameter_codes=set())

    assert pick_question(catalog=catalog, selection=selection, active_parameters={}, today=_TODAY) is None


def test_pick_question_returns_none_when_no_question_covers_parameters() -> None:
    """Параметр не отвечён, но вопроса под него в справочнике нет — опросник заканчивается."""
    catalog = _catalog(params_by_system={"SYS": {"s1"}})
    selection = SelectionContext(chosen_system_code="SYS", unanswered_parameter_codes={"s1"})

    assert pick_question(catalog=catalog, selection=selection, active_parameters={}, today=_TODAY) is None


def test_pick_question_returns_none_when_all_candidates_hidden() -> None:
    """Все вопросы-кандидаты скрыты conditions."""
    catalog = _catalog(
        params_by_system={"SYS": {"s1"}},
        params_by_question={"q_s1": {"s1"}},
        conditions=(condition("q_s1", _GENDER, value="Женский"),),
    )
    selection = SelectionContext(chosen_system_code="SYS", unanswered_parameter_codes={"s1"})

    result = pick_question(
        catalog=catalog,
        selection=selection,
        active_parameters=_answered(_GENDER, value="Женский"),
        today=_TODAY,
    )

    assert result is None


def test_pick_question_returns_none_for_unknown_system_code() -> None:
    """Видимый вопрос есть, но выбранной системы нет в каталоге — ответ собрать не из чего."""
    catalog = _catalog(params_by_system={"SYS": {"s1"}}, params_by_question={"q_s1": {"s1"}})
    selection = SelectionContext(chosen_system_code="NOPE", unanswered_parameter_codes={"s1"})

    assert pick_question(catalog=catalog, selection=selection, active_parameters={}, today=_TODAY) is None


def test_first_visible_question_returns_none_when_every_question_hidden() -> None:
    catalog = _catalog(
        params_by_system={"SYS": {"s1", "s2"}},
        params_by_question={"q_s1": {"s1"}, "q_s2": {"s2"}},
        conditions=(
            condition("q_s1", _GENDER, value="Женский"),
            condition("q_s2", _GENDER, value="Женский"),
        ),
    )
    questions = catalog.question_views_for_params({"s1", "s2"})

    visible = first_visible_question(
        catalog=catalog,
        questions=questions,
        active_parameters=_answered(_GENDER, value="Женский"),
        today=_TODAY,
    )

    assert visible is None


def test_has_visible_question_is_false_for_empty_parameter_set() -> None:
    """Защитный выход: публичный путь сюда с пустым множеством не приходит, но `any()` по
    пустому каталогу вопросов дал бы True раньше, чем стало бы понятно, что спрашивать нечего."""
    catalog = _catalog(params_by_system={"SYS": {"s1"}}, params_by_question={"q_s1": {"s1"}})

    assert _has_visible_question(catalog, set(), {}, _TODAY) is False
