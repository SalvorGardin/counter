"""Юнит-тесты build_completion_sets / completion_percentage (общий core для medical-risk и
questions/answers; wiki Risk-profile шаг 4/6 == Risk-communication шаг 11/12, дословно).

Заполненность считается в целых вопросах. Вопрос относится к системе по релевантности
вариант→инструмент→система (пересечение параметров options и параметров системы); COMMON
отдельно не участвует — её вопросы попадают в системы через свои варианты. Знаменатель —
applicable (пол+возраст), числитель — progressed (отвечен ∨ скрыт non-gender show-условием).
"""

from datetime import UTC, datetime

from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.completion import build_completion_sets, completion_percentage
from src.services.risk_communication.domain.constants import GENDER_PARAMETER_CODE, PREGNANCY_QUESTION_CODE
from src.services.risk_communication.domain.models import ConditionView, QuestionView
from tests.consts import GENDER_MALE

_TODAY = datetime(2026, 7, 24, tzinfo=UTC).date()
_EXP = datetime(2099, 1, 1, tzinfo=UTC)


def _q(code: str) -> QuestionView:
    return QuestionView(question_id=0, code=code, text=code, type="select", is_skippable=False, group_code=1)


def _active(**pairs: str) -> dict[str, ActiveParameter]:
    return {
        c: ActiveParameter(
            parameter_code=c,
            value=v,
            expiration_date=_EXP,
            date_time=_EXP,
            patient_parameter_id=0,
        )
        for c, v in pairs.items()
    }


def _except(parameter_code: str, value: str) -> ConditionView:
    return ConditionView(type="except", parameter_code=parameter_code, value=value, min_age=None, max_age=None)


# --- completion_percentage ---


def test_percentage_empty_denominator_is_100() -> None:
    assert completion_percentage(0, 0) == 100


def test_percentage_floors() -> None:
    assert completion_percentage(2, 3) == 66


def test_percentage_full() -> None:
    assert completion_percentage(5, 5) == 100


def test_percentage_zero_progress() -> None:
    assert completion_percentage(0, 4) == 0


# --- build_completion_sets ---


def test_answered_question_is_progressed() -> None:
    sets = build_completion_sets(
        system_params={"SYS": {"p1"}},
        questions=[_q("q1")],
        params_by_question={"q1": {"p1"}},
        conditions_by_question={},
        active_parameters=_active(p1="Да"),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == {"q1"}
    assert sets.progressed_by_system["SYS"] == {"q1"}
    assert sets.global_applicable == {"q1"}
    assert sets.global_progressed == {"q1"}


def test_unanswered_visible_question_is_applicable_not_progressed() -> None:
    sets = build_completion_sets(
        system_params={"SYS": {"p1"}},
        questions=[_q("q1")],
        params_by_question={"q1": {"p1"}},
        conditions_by_question={},
        active_parameters=_active(),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == {"q1"}
    assert sets.progressed_by_system["SYS"] == set()


def test_partial_answer_not_progressed_all_params_required() -> None:
    # Вопрос пишет два параметра; отвечён только один → не progressed (шаг 4: нужны все).
    sets = build_completion_sets(
        system_params={"SYS": {"p1", "p2"}},
        questions=[_q("q1")],
        params_by_question={"q1": {"p1", "p2"}},
        conditions_by_question={},
        active_parameters=_active(p1="Да"),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.progressed_by_system["SYS"] == set()


def test_gender_excluded_from_denominator() -> None:
    sets = build_completion_sets(
        system_params={"SYS": {"p1"}},
        questions=[_q("q1")],
        params_by_question={"q1": {"p1"}},
        conditions_by_question={"q1": [_except(GENDER_PARAMETER_CODE, GENDER_MALE)]},
        active_parameters=_active(gender=GENDER_MALE),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == set()
    assert sets.global_applicable == set()


def test_non_gender_except_auto_credits_numerator() -> None:
    # Вопрос не отвечен (p1 отсутствует), но скрыт условием except cancer=Нет → progressed.
    sets = build_completion_sets(
        system_params={"SYS": {"p1"}},
        questions=[_q("q1")],
        params_by_question={"q1": {"p1"}},
        conditions_by_question={"q1": [_except("cancer", "Нет")]},
        active_parameters=_active(cancer="Нет"),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == {"q1"}
    assert sets.progressed_by_system["SYS"] == {"q1"}


def test_common_question_attaches_to_systems_via_variants() -> None:
    # Один вопрос с двумя вариантами: p_cvd относится к CVD, p_endo — к ENDO.
    # COMMON отдельно не задан — вопрос попадает в обе реальные системы через свои варианты.
    sets = build_completion_sets(
        system_params={"CVD": {"p_cvd"}, "ENDO": {"p_endo"}},
        questions=[_q("cq_common")],
        params_by_question={"cq_common": {"p_cvd", "p_endo"}},
        conditions_by_question={},
        active_parameters=_active(p_cvd="Да", p_endo="Да"),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["CVD"] == {"cq_common"}
    assert sets.applicable_by_system["ENDO"] == {"cq_common"}
    # Глобально — один вопрос (дедупликация по question_code), а не два.
    assert sets.global_applicable == {"cq_common"}
    assert sets.global_progressed == {"cq_common"}


def test_cq030_progressed_when_is_pregnant_not_null() -> None:
    # is_pregnant хранится в patients, параметр никогда не активен — но is_pregnant IS NOT NULL
    # (False здесь) даёт зачёт вопросу cq_030.
    sets = build_completion_sets(
        system_params={"SYS": {"is_pregnant"}},
        questions=[_q(PREGNANCY_QUESTION_CODE)],
        params_by_question={PREGNANCY_QUESTION_CODE: {"is_pregnant"}},
        conditions_by_question={},
        active_parameters=_active(),
        is_pregnant=False,
        today=_TODAY,
    )
    assert sets.progressed_by_system["SYS"] == {PREGNANCY_QUESTION_CODE}


def test_cq030_not_progressed_when_is_pregnant_null() -> None:
    sets = build_completion_sets(
        system_params={"SYS": {"is_pregnant"}},
        questions=[_q(PREGNANCY_QUESTION_CODE)],
        params_by_question={PREGNANCY_QUESTION_CODE: {"is_pregnant"}},
        conditions_by_question={},
        active_parameters=_active(),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == {PREGNANCY_QUESTION_CODE}
    assert sets.progressed_by_system["SYS"] == set()


def test_question_not_relevant_to_system_is_skipped() -> None:
    sets = build_completion_sets(
        system_params={"SYS": {"p1"}},
        questions=[_q("q_other")],
        params_by_question={"q_other": {"p_unrelated"}},
        conditions_by_question={},
        active_parameters=_active(),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.applicable_by_system["SYS"] == set()
    assert sets.global_applicable == set()


def test_global_dedup_across_systems() -> None:
    # q_shared в CVD и ENDO (progressed в обеих), q_endo только в ENDO (не отвечен).
    sets = build_completion_sets(
        system_params={"CVD": {"a"}, "ENDO": {"a", "b"}},
        questions=[_q("q_shared"), _q("q_endo")],
        params_by_question={"q_shared": {"a"}, "q_endo": {"b"}},
        conditions_by_question={},
        active_parameters=_active(a="Да"),
        is_pregnant=None,
        today=_TODAY,
    )
    assert sets.global_applicable == {"q_shared", "q_endo"}
    assert sets.global_progressed == {"q_shared"}
    # CVD: 1/1 → 100; ENDO: 1/2 → 50.
    assert completion_percentage(len(sets.progressed_by_system["CVD"]), len(sets.applicable_by_system["CVD"])) == 100
    assert completion_percentage(len(sets.progressed_by_system["ENDO"]), len(sets.applicable_by_system["ENDO"])) == 50
