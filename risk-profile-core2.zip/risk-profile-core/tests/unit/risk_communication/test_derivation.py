"""Unit-тесты чистой decision-логики деривации age/bmi.

Раньше корнер-кейсы (пустая/не-ISO дата рождения, дата из будущего, совпадение вычисленного
возраста с уже записанным, актуален только один из пары height/weight) закрывались только
интеграционными тестами с поднятым Postgres. Правила решения от БД не зависят, поэтому
пинятся здесь; интеграционные тесты остаются на связке с БД.
"""

from datetime import date

import pytest

from src.services.risk_communication.domain.derivation import (
    SkipReason,
    decide_age,
    decide_bmi,
)
from src.services.risk_init.domain.constants import HEIGHT_PARAMETER_CODE, WEIGHT_PARAMETER_CODE

_TODAY = date(2026, 9, 4)


class TestDecideAge:
    def test_derives_full_years_when_no_age_recorded(self) -> None:
        decision = decide_age(birthdate_value="1986-09-05", current_age_value=None, today=_TODAY)

        assert decision.value == "39"
        assert decision.skip_reason is None

    def test_derives_when_recorded_age_differs(self) -> None:
        decision = decide_age(birthdate_value="1986-09-04", current_age_value="39", today=_TODAY)

        assert decision.value == "40"
        assert decision.skip_reason is None

    def test_skips_when_recorded_age_equals_computed(self) -> None:
        # Value-diff guard (ревью !150): ретрай того же ответа не должен плодить историю.
        decision = decide_age(birthdate_value="1986-09-04", current_age_value="40", today=_TODAY)

        assert decision.value is None
        assert decision.skip_reason is SkipReason.AGE_UP_TO_DATE

    def test_missing_birthdate_is_skipped_and_reported_as_absent(self) -> None:
        decision = decide_age(birthdate_value=None, current_age_value=None, today=_TODAY)

        assert decision.value is None
        assert decision.skip_reason is SkipReason.BIRTHDATE_NOT_AVAILABLE
        assert decision.birthdate_present is False

    @pytest.mark.parametrize("raw", ["", "04.09.1986", "1986-13-01"])
    def test_unparsable_birthdate_is_skipped_but_reported_as_present(self, raw: str) -> None:
        # Пропуск вопроса (isSkipped) пишет '': строка есть, даты в ней нет.
        decision = decide_age(birthdate_value=raw, current_age_value=None, today=_TODAY)

        assert decision.value is None
        assert decision.skip_reason is SkipReason.BIRTHDATE_NOT_AVAILABLE
        assert decision.birthdate_present is True

    def test_future_birthdate_is_skipped(self) -> None:
        # coerce_date_answer проверяет только формат, поэтому дата из будущего в БД попасть может.
        decision = decide_age(birthdate_value="2027-01-01", current_age_value=None, today=_TODAY)

        assert decision.value is None
        assert decision.skip_reason is SkipReason.BIRTHDATE_IN_FUTURE

    def test_birthday_today_gives_full_years(self) -> None:
        decision = decide_age(birthdate_value="2026-09-04", current_age_value=None, today=_TODAY)

        assert decision.value == "0"
        assert decision.skip_reason is None


class TestDecideBmi:
    def test_derives_from_both_sources(self) -> None:
        decision = decide_bmi(height_value="180", weight_value="81")

        assert decision.value == "25"
        assert decision.skip_reason is None
        assert decision.invalid_source_codes == ()

    def test_uses_shared_number_format(self) -> None:
        decision = decide_bmi(height_value="170", weight_value="70")

        assert decision.value == "24.22"

    @pytest.mark.parametrize(
        ("height", "weight", "has_height", "has_weight"),
        [
            (None, "81", False, True),
            ("180", None, True, False),
            (None, None, False, False),
        ],
    )
    def test_skips_while_only_one_source_is_actual(
        self, height: str | None, weight: str | None, has_height: bool, has_weight: bool
    ) -> None:
        # После answers-reset height/weight инвалидируются вместе и отвечают на них по одному:
        # пока актуален один, ИМТ считался бы из протухшего второго значения (bug #136).
        decision = decide_bmi(height_value=height, weight_value=weight)

        assert decision.value is None
        assert decision.skip_reason is SkipReason.ANTHROPOMETRY_NOT_BOTH_ACTUAL
        assert (decision.has_height, decision.has_weight) == (has_height, has_weight)

    @pytest.mark.parametrize("raw", ["", "0", "-180", "abc"])
    def test_non_positive_height_is_skipped_and_reported_invalid(self, raw: str) -> None:
        decision = decide_bmi(height_value=raw, weight_value="81")

        assert decision.value is None
        assert decision.skip_reason is SkipReason.ANTHROPOMETRY_NOT_BOTH_ACTUAL
        assert decision.has_height is False
        assert decision.invalid_source_codes == (HEIGHT_PARAMETER_CODE,)

    def test_both_sources_invalid_are_reported_in_source_order(self) -> None:
        decision = decide_bmi(height_value="0", weight_value="abc")

        assert decision.invalid_source_codes == (HEIGHT_PARAMETER_CODE, WEIGHT_PARAMETER_CODE)

    def test_absent_source_is_not_reported_as_invalid(self) -> None:
        # Диагностический warning вызывающего — про кривое значение, а не про отсутствие строки.
        decision = decide_bmi(height_value=None, weight_value="81")

        assert decision.invalid_source_codes == ()
