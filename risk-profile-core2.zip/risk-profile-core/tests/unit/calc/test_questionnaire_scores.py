"""STEP-1/2/4 баллы опросников, посчитанные в памяти (sum_questionnaire_scores).

Раньше это был один пятитабличный SQL; здесь фиксируются ровно те его свойства, которые легко
потерять при переносе в память: инструмент в N системах получает N вкладов, вовлечённый
инструмент без совпадений даёт строку с нулём (а не отсутствие строки), диапазон матчится
только при value IS NULL и обеих границах, нечисловое значение в диапазон не попадает,
инструмент без systems_instruments выпадает целиком (inner join), повторные строки параметра
складываются, пустая строка (пропущенный вопрос) — обычное значение точного сравнения.
"""

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from types import MappingProxyType

from src.calc.domain.models import PatientParameterRow, QuestionnaireScoreRow, QuestionnaireScoreTarget
from src.calc.domain.scores import sum_questionnaire_scores
from src.infra.catalog.calc import CalcCatalog
from src.infra.catalog.dtos import ScoreDTO
from tests.catalog_builder import (
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    question,
    score,
    system_instrument,
)
from tests.consts import PARAMETER_CODE_AGE

_FUTURE = datetime.now(tz=UTC) + timedelta(days=30)


def _targets(scores: tuple[ScoreDTO, ...]) -> MappingProxyType[str, tuple[QuestionnaireScoreTarget, ...]]:
    """Шкалы из каталога: form_q в системах s1+s2, form_r в s1, lonely_q без систем, calc_z/old_q — мимо.

    Свёртку справочников делает `CalcCatalog`, поэтому вход функции строится через него, а не
    руками: тесты проверяют пару «свёртка + счёт» целиком, как её видит расчёт.
    """
    base = make_catalog(
        instruments=(
            instrument("form_q", instrument_id=1),
            instrument("form_r", instrument_id=2),
            instrument("lonely_q", instrument_id=3),
            instrument("calc_z", type="calc", instrument_id=4),
            instrument("old_q", status="inactive", instrument_id=5),
        ),
        instruments_parameters=(
            instrument_parameter("form_q", "q1", is_required=True),
            instrument_parameter("form_q", "q2"),
            instrument_parameter("form_q", PARAMETER_CODE_AGE),
            instrument_parameter("form_r", "q1"),
            instrument_parameter("lonely_q", "q1"),
            instrument_parameter("calc_z", "q1"),
            instrument_parameter("old_q", "q1"),
        ),
        options=(
            option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen", value="yes", option_id=1),
            option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="sad", option_id=2),
        ),
        questions=(
            question("Q_GEN", group_code=1, question_id=1),
            question("BDI1", question_id=2),
        ),
        systems_instruments=(
            system_instrument("s1", "form_q"),
            system_instrument("s2", "form_q"),
            system_instrument("s1", "form_r"),
        ),
        parameter_scores=scores,
    )
    return CalcCatalog(base).questionnaire_score_targets


def _row(patient_id: str, parameter_code: str, value: str) -> PatientParameterRow:
    return PatientParameterRow(
        patient_parameter_id=0,
        patient_id=patient_id,
        parameter_code=parameter_code,
        value=value,
        source="test",
        expiration_date=_FUTURE,
        date_time=_FUTURE,
    )


def _by_instrument(rows: list[QuestionnaireScoreRow]) -> dict[str, Decimal]:
    return {row.instrument_code: row.score for row in rows}


def test_exact_value_match_sums_per_instrument():
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    # form_q и form_r оба содержат q1 и оба состоят в s1 → каждый получает свой балл.
    assert result == {"form_q": Decimal("2"), "form_r": Decimal("2")}


def test_instrument_in_two_systems_gets_the_score_twice():
    """systems_instruments подключалась БЕЗ дедупликации: N систем — N вкладов."""
    targets = _targets(
        (
            score("q1", "s1", value="да", score=Decimal("2")),
            score("q1", "s2", value="да", score=Decimal("5")),
        )
    )

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    assert result["form_q"] == Decimal("7")  # s1 + s2
    assert result["form_r"] == Decimal("2")  # только s1


def test_multiple_matching_rows_each_add_a_summand():
    """Не «первое совпадение»: две строки с одним value давали два слагаемых."""
    targets = _targets(
        (
            score("q1", "s1", value="да", score=Decimal("2")),
            score("q1", "s1", value="да", score=Decimal("3")),
        )
    )

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    assert result["form_r"] == Decimal("5")


def test_engaged_instrument_without_any_match_gets_a_zero_row():
    """outer join + coalesce(score, 0): строка со нулём, а НЕ отсутствие строки."""
    targets = _targets((score("q1", "s1", value="нет", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    assert result == {"form_q": Decimal("0"), "form_r": Decimal("0")}


def test_range_match_only_when_value_is_null_and_both_bounds_set():
    targets = _targets(
        (
            score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("18"), max_value=Decimal("65"), score=Decimal("4")),
            # value NOT NULL + границы: диапазонная ветка требовала value IS NULL → не совпадает
            score(
                PARAMETER_CODE_AGE,
                "s2",
                value="40",
                min_value=Decimal("18"),
                max_value=Decimal("65"),
                score=Decimal("7"),
            ),
        )
    )

    result = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "40.5")], targets))

    assert result["form_q"] == Decimal("4")


def test_range_ignores_row_with_missing_bound():
    targets = _targets((score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("18"), score=Decimal("4")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "40")], targets))

    assert result["form_q"] == Decimal("0")


def test_range_bounds_are_inclusive():
    targets = _targets(
        (score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("18"), max_value=Decimal("65"), score=Decimal("4")),)
    )

    low = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "18")], targets))
    high = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "65")], targets))
    over = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "66")], targets))

    assert low["form_q"] == Decimal("4")
    assert high["form_q"] == Decimal("4")
    assert over["form_q"] == Decimal("0")


def test_non_numeric_value_never_matches_a_range():
    """SQL кастовал через CASE с регуляркой: нечисловое → NULL → ни одна граница не прошла."""
    targets = _targets(
        (score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("18"), max_value=Decimal("65"), score=Decimal("4")),)
    )

    result = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "сорок")], targets))

    assert result["form_q"] == Decimal("0")


def test_skipped_answer_is_an_empty_string_and_matches_nothing():
    """Пропущенный вопрос хранится пустой строкой, то есть ответ есть, а совпадений — нет.

    Пара «пациент × инструмент» появляется от самого факта строки, но `''` не равен ни одному
    value и не является числом — ни точная ветка, ни диапазонная вклада не дают.
    """
    targets = _targets(
        (
            score("q1", "s1", value="да", score=Decimal("2")),
            score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("0"), max_value=Decimal("120"), score=Decimal("4")),
        )
    )

    result = _by_instrument(
        sum_questionnaire_scores([_row("p1", "q1", ""), _row("p1", PARAMETER_CODE_AGE, "")], targets)
    )

    assert result == {"form_q": Decimal("0"), "form_r": Decimal("0")}


def test_empty_string_is_a_regular_exact_value():
    """`''` — обычный ключ точного сравнения, а не «пусто»: строка баллов с value='' совпадает."""
    targets = _targets((score("q1", "s1", value="", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "")], targets))

    assert result["form_r"] == Decimal("2")


def test_negative_and_fractional_values_are_numeric():
    targets = _targets(
        (score(PARAMETER_CODE_AGE, "s1", min_value=Decimal("-10"), max_value=Decimal("-1"), score=Decimal("4")),)
    )

    result = _by_instrument(sum_questionnaire_scores([_row("p1", PARAMETER_CODE_AGE, "-5.5")], targets))

    assert result["form_q"] == Decimal("4")


def test_instrument_without_systems_is_absent():
    """systems_instruments подключалась INNER JOIN: без систем инструмент не давал ни одной строки."""
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    assert "lonely_q" not in result


def test_non_questionnaire_and_inactive_instruments_are_excluded():
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да")], targets))

    assert "calc_z" not in result
    assert "old_q" not in result


def test_duplicate_parameter_rows_are_not_deduplicated():
    """Группировки по строкам не было: каждая строка patients_parameters давала свой вклад."""
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    result = _by_instrument(sum_questionnaire_scores([_row("p1", "q1", "да"), _row("p1", "q1", "да")], targets))

    assert result["form_r"] == Decimal("4")


def test_scores_are_isolated_per_patient():
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    rows = sum_questionnaire_scores([_row("p1", "q1", "да"), _row("p2", "q1", "нет")], targets)

    scores = {(row.patient_id, row.instrument_code): row.score for row in rows}
    assert scores[("p1", "form_r")] == Decimal("2")
    assert scores[("p2", "form_r")] == Decimal("0")


def test_parameter_outside_any_questionnaire_produces_nothing():
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    assert sum_questionnaire_scores([_row("p1", "unknown_param", "да")], targets) == []


def test_excluded_parameter_contributes_only_to_other_instrument_selections():
    targets = _targets((score("q1", "s1", value="да", score=Decimal("2")),))

    result = _by_instrument(
        sum_questionnaire_scores(
            [_row("p1", "q1", "да")],
            targets,
            {"p1": {"form_q": {"q1"}}},
        )
    )

    assert result == {"form_r": Decimal("2")}
