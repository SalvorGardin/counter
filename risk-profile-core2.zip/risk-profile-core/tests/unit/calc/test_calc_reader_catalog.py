from src.calc.domain.models import CalculationRequest
from src.calc.infra.reader import CalcReader
from tests.conftest import build_calc_catalog


def test_catalog_views_and_request_building():
    catalog = build_calc_catalog()
    reader = CalcReader(session=None, catalog=catalog)  # ty: ignore[invalid-argument-type]  # session unused on pure paths

    assert "form_a" in catalog.instrument_configs
    assert catalog.system_codes_by_instrument == {"form_a": ("s1", "s2")}
    assert catalog.bdi_score_map == {"sad": 1, "very sad": 3}
    assert catalog.instrument_codes_for_parameters({"p_gen"}) == {"form_a", "calc_b"}

    request = reader.build_request("pat1", {"p_gen"})
    assert request == CalculationRequest(patient_id="pat1", instrument_codes=frozenset({"calc_b", "form_a"}))
    assert reader.build_request("pat1", None) == CalculationRequest(patient_id="pat1")
