"""STEP-3 счётчики, посчитанные в памяти (CalcReader.build_questionnaire_eligibility).

Раньше это были SQL-запросы; здесь фиксируются ровно те их свойства, которые легко потерять при
переносе в память: особый случай is_pregnant (источник — `patients`, а не `patients_parameters`,
и после снятия последнего запроса он приходит готовым срезом `load_patient_snapshot`), пары «только
общие данные» как ключ, отсев неопросников и неактивных инструментов, дедуп повторных строк
параметра, изоляция пациентов.

Сама методология счёта вопросов, применимых пациенту (issue #190), живёт в
`src/calc/domain/eligibility.py` и покрыта своими тестами — тут проверяется только то, что гейт
скармливает ей правильные множества.
"""

from datetime import UTC, datetime, timedelta

from src.calc.domain.models import PatientParameterRow
from src.calc.infra.reader import CalcReader
from src.infra.catalog.calc import CalcCatalog
from tests.catalog_builder import (
    instrument,
    instrument_parameter,
    make_catalog,
    option,
    question,
    system_instrument,
)

_FUTURE = datetime.now(tz=UTC) + timedelta(days=30)


def _reader() -> CalcReader:
    # Условий показа нет: каждый вопрос применим и не скрыт ветвлением.
    base = make_catalog(
        instruments=(
            instrument("form_q", instrument_id=1),
            instrument("form_r", instrument_id=2),
            instrument("calc_z", type="calc", instrument_id=3),
            instrument("old_q", status="inactive", instrument_id=4),
        ),
        instruments_parameters=(
            # form_q: is_pregnant + p_gen — параметры общего вопроса Q_GEN, q1/q2/q3 — свои
            instrument_parameter("form_q", "is_pregnant", is_required=True),
            instrument_parameter("form_q", "p_gen"),
            instrument_parameter("form_q", "q1", is_required=True),
            instrument_parameter("form_q", "q2"),
            instrument_parameter("form_q", "q3"),
            # form_r: только общий параметр
            instrument_parameter("form_r", "p_gen"),
            # не опросник / неактивный — в eligibility попадать не должны
            instrument_parameter("calc_z", "q1"),
            instrument_parameter("old_q", "q1", is_required=True),
        ),
        options=(
            option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen", value="yes", option_id=1),
            option("OPT_PREG", question_code="Q_GEN", parameter_code="is_pregnant", value="yes", option_id=2),
            # Один вопрос на параметр: X формы form_q = {Q_GEN, Q1, Q2, Q3}.
            option("OPT_Q1", question_code="Q1", parameter_code="q1", value="yes", option_id=3),
            option("OPT_Q2", question_code="Q2", parameter_code="q2", value="yes", option_id=4),
            option("OPT_Q3", question_code="Q3", parameter_code="q3", value="yes", option_id=5),
            option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="sad", option_id=6),
        ),
        questions=(
            question("Q_GEN", group_code=1, question_id=1),
            question("Q1", question_id=2),
            question("Q2", question_id=3),
            question("Q3", question_id=4),
            question("BDI1", question_id=5),
        ),
        systems_instruments=(system_instrument("s1", "form_q"),),
    )
    # session не используется на этом пути — метод чистый, читает только каталог.
    return CalcReader(session=None, catalog=CalcCatalog(base))  # ty: ignore[invalid-argument-type]


def _row(patient_id: str, parameter_code: str, value: str = "да") -> PatientParameterRow:
    return PatientParameterRow(
        patient_parameter_id=0,
        patient_id=patient_id,
        parameter_code=parameter_code,
        value=value,
        source="test",
        expiration_date=_FUTURE,
        date_time=_FUTURE,
    )


def test_pregnancy_answer_comes_from_patients_not_parameters():
    """is_pregnant отсутствует в patients_parameters, но is_pregnant=False = «ответила на cq_030»."""
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1"],
        [_row("p1", "p_gen"), _row("p1", "q1")],
        {"p1": False},
    )

    elig = result[("p1", "form_q")]
    # Q_GEN (p_gen + is_pregnant) зачтён целиком: p_gen из строк, is_pregnant из patients.
    assert elig.progressed_questions == 2  # Q_GEN + Q1
    assert elig.required_total == 2  # is_pregnant + q1
    assert elig.required_answered == 2


def test_unanswered_pregnancy_is_not_counted():
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1"],
        [_row("p1", "p_gen"), _row("p1", "q1")],
        {"p1": None},
    )

    elig = result[("p1", "form_q")]
    # Без ответа на cq_030 вопрос Q_GEN не зачтён, хотя p_gen отвечен.
    assert elig.progressed_questions == 1  # только Q1
    assert elig.required_answered == 1


def test_question_counts_cover_all_applicable_questions():
    """X — все вопросы системы инструмента (условий показа нет), Y — отвеченные целиком."""
    reader = _reader()

    result = reader.build_questionnaire_eligibility(["p1"], [_row("p1", "q1"), _row("p1", "q2")], {"p1": True})

    elig = result[("p1", "form_q")]
    assert elig.applicable_questions == 4  # Q_GEN + Q1 + Q2 + Q3
    assert elig.progressed_questions == 2  # Q1 + Q2 (в Q_GEN не отвечен p_gen)


def test_general_only_pair_is_a_key_below_the_gate():
    """Ответ только на общие данные создаёт пару (ключ), но гейт по ней не проходит.

    Так required-guard высшего приоритета может сработать по инструменту, у которого не отвечено
    ни одного собственного вопроса. У form_r своих вопросов нет вовсе, поэтому его X = 0.
    """
    reader = _reader()

    result = reader.build_questionnaire_eligibility(["p1"], [_row("p1", "p_gen")], {"p1": False})

    assert ("p1", "form_r") in result
    assert result[("p1", "form_r")].applicable_questions == 0
    elig = result[("p1", "form_q")]
    assert elig.progressed_questions == 1  # только Q_GEN
    assert elig.progressed_questions / elig.applicable_questions < 0.5


def test_non_questionnaire_and_inactive_instruments_excluded():
    reader = _reader()

    result = reader.build_questionnaire_eligibility(["p1"], [_row("p1", "q1")], {"p1": False})

    assert set(result) == {("p1", "form_q")}


def test_duplicate_parameter_rows_counted_once():
    reader = _reader()

    result = reader.build_questionnaire_eligibility(["p1"], [_row("p1", "q1"), _row("p1", "q1")], {"p1": False})

    assert result[("p1", "form_q")].progressed_questions == 1
    # q1 засчитан один раз, +1 за is_pregnant (тоже required у form_q).
    assert result[("p1", "form_q")].required_answered == 2


def test_skipped_answer_stored_as_empty_string_counts_as_answered():
    """Пропущенный вопрос хранится пустой строкой и считается отвеченным.

    Критерий «отвечен» — наличие актуальной строки (value IS NOT NULL), а не непустота значения:
    пустая строка одинаково засчитывается и в required-guard, и в счёт вопросов.
    """
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1"],
        [_row("p1", "p_gen", value=""), _row("p1", "q1", value="")],
        {"p1": None},
    )

    elig = result[("p1", "form_q")]
    assert elig.required_answered == 1  # q1
    # Q1 закрыт пропуском; Q_GEN — нет, там не отвечена is_pregnant.
    assert elig.progressed_questions == 1


def test_patient_without_answers_has_no_entry():
    reader = _reader()

    result = reader.build_questionnaire_eligibility(["p1", "p2"], [_row("p1", "q1")], {"p1": False, "p2": False})

    assert not any(patient_id == "p2" for patient_id, _ in result)


def test_patients_are_isolated():
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1", "p2"],
        [_row("p1", "q1"), _row("p2", "q2"), _row("p2", "q3")],
        {"p1": False, "p2": None},
    )

    assert result[("p1", "form_q")].progressed_questions == 1  # только Q1
    assert result[("p1", "form_q")].required_answered == 2  # q1 + is_pregnant из patients
    assert result[("p2", "form_q")].progressed_questions == 2  # Q2 + Q3
    assert result[("p2", "form_q")].required_answered == 0  # ни q1, ни ответа на cq_030


def test_excluded_required_parameter_stays_answered_for_the_instrument():
    """Вытесненный повтором биомаркера обязательный параметр отвечен: guard инструмент не пропускает."""
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1"],
        [_row("p1", "q1"), _row("p1", "q2")],
        {"p1": False},
        {"p1": {"form_q": {"q1"}}},
    )

    eligibility = result[("p1", "form_q")]
    assert eligibility.required_answered == 2  # q1 + is_pregnant из patients
    assert eligibility.missing_required_codes == ()


def test_excluded_parameter_still_counts_as_answered_question():
    """Доля отвеченных вопросов считается по всем актуальным ответам, без отсева повторов."""
    reader = _reader()

    rows = [_row("p1", "q1"), _row("p1", "q2")]
    plain = reader.build_questionnaire_eligibility(["p1"], rows, {"p1": False})
    narrowed = reader.build_questionnaire_eligibility(["p1"], rows, {"p1": False}, {"p1": {"form_q": {"q2"}}})

    assert narrowed[("p1", "form_q")].progressed_questions == plain[("p1", "form_q")].progressed_questions == 2
    assert narrowed[("p1", "form_q")].applicable_questions == plain[("p1", "form_q")].applicable_questions


def test_engagement_is_decided_by_the_instrument_selection():
    """Признак вовлечённости — по выборке инструмента: инструмент без своих записей не рассматривается.

    В реальных данных сужение выборку не опустошает: победитель среди повторов биомаркера связан
    с тем же инструментом и из неё не уходит. Здесь проверяется, какой именно набор решает, есть ли
    пара «пациент — инструмент», — счётчики гейта на нём не считаются.
    """
    reader = _reader()

    result = reader.build_questionnaire_eligibility(
        ["p1"],
        [_row("p1", "q1")],
        {"p1": False},
        {"p1": {"form_q": {"q1"}}},
    )

    assert ("p1", "form_q") not in result
