"""Инжекция рантайма расчёта во весь граф вызовов пересчёта.

Расчёт открывает не одну транзакцию: собственные сессии есть у сбора статусов и у сбора причин
интерпретации, и открываются они уже после коммитов. В API-процессе (инлайн-режим) основной
рантайм — профильный, поэтому любая из этих сессий, взятая по умолчанию, ушла бы в БД под чужой
ролью. Тесты фиксируют, что фабрика доходит до каждого такого места.
"""

from unittest.mock import MagicMock

from sqlalchemy.ext.asyncio import async_sessionmaker

from src.calc.handler import CalcHandler
from src.interpretation.handler import InterpretationHandler


def _factory() -> async_sessionmaker:
    return MagicMock(spec=async_sessionmaker)


def test_calc_handler_passes_the_factory_to_status_collection() -> None:
    session_factory = _factory()

    handler = CalcHandler(
        MagicMock(),
        MagicMock(),
        interpretation_catalog=MagicMock(),
        session_factory=session_factory,
    )

    assert handler._statuses._session_factory is session_factory


def test_interpretation_handler_passes_the_factory_to_reason_collection() -> None:
    session_factory = _factory()

    handler = InterpretationHandler(MagicMock(), catalog=MagicMock(), session_factory=session_factory)

    assert handler._reasons._session_factory is session_factory


def test_calc_handler_propagates_the_factory_to_interpretation() -> None:
    """Интерпретация запускается изнутри расчёта и должна унаследовать ту же database identity."""
    session_factory = _factory()

    handler = CalcHandler(
        MagicMock(),
        MagicMock(),
        interpretation_catalog=MagicMock(),
        session_factory=session_factory,
    )

    assert handler._session_factory is session_factory


def test_handlers_fall_back_to_the_process_runtime_without_injection() -> None:
    """Воркер и playground уже подняты под ролью расчёта — им передавать нечего."""
    from src.infra.database import get_primary_runtime

    handler = CalcHandler(MagicMock(), MagicMock(), interpretation_catalog=MagicMock())

    assert handler._statuses._session_factory is get_primary_runtime().session_factory
