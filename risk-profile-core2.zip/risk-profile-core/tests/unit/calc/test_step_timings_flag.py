"""Флаг сбора по-шаговых замеров: каскад `enable` и неприкосновенность общего выключенного sink'а.

Сам сбор — внутренняя (не боевая) поверхность за `RISK_MODEL_STEP_TIMINGS_ENABLED`, поэтому модуль
под `test_internal`. Маркер общий на все внутренние поверхности, и правило пропуска
(tests/conftest.py) смотрит на один переключатель — `RISK_MODEL_TESTING_API_ENABLED`: выключив его,
вы погасите и эти тесты, независимо от значения `RISK_MODEL_STEP_TIMINGS_ENABLED`.

Поведение хендлеров под флагом проверяется интеграционно —
tests/integration/calc/test_step_timings_flag.py.
"""

import dataclasses

import pytest

from src.calc.timings import _DISABLED_TIMINGS, LoadTimings, StepTimings
from src.interpretation.timings import _DISABLED_TIMINGS as _DISABLED_INTERPRETATION_TIMINGS
from src.interpretation.timings import InterpretationLoadTimings, InterpretationTimings

pytestmark = pytest.mark.test_internal


def test_fresh_sinks_are_enabled_by_default() -> None:
    # Объект, собранный руками (diag-скрипты, фикстуры отчёта), представляет измеренные данные.
    assert StepTimings().enabled
    assert LoadTimings().enabled
    assert InterpretationTimings().enabled
    assert InterpretationLoadTimings().enabled


def test_enable_cascades_into_every_nested_sink() -> None:
    t = StepTimings()
    t.enable(False)
    assert not t.enabled
    assert not t.load.enabled
    assert not t.interpretation.enabled
    assert not t.interpretation.load.enabled

    t.enable(True)
    assert t.enabled
    assert t.load.enabled
    assert t.interpretation.enabled
    assert t.interpretation.load.enabled


def test_interpretation_enable_cascades_into_load() -> None:
    it = InterpretationTimings()
    it.enable(False)
    assert not it.enabled
    assert not it.load.enabled


def test_cvd_step_is_excluded_from_formula() -> None:
    # `formula` показывает только in-process расчёт: вложенный шаг внешнего вызова вычитается
    # самим sink'ом (см. StepTimings.cvd_ms), без арифметики в хендлерах.
    t = StepTimings()
    with t.step("formula"), t.step("cvd"):
        total = 0
        for i in range(10_000):
            total += i

    assert t.cvd_ms > 0.0
    assert t.formula_ms < t.cvd_ms


def _assert_clean_and_disabled(sink: object, path: str) -> None:
    """Рекурсивно: `enabled=False`, всё остальное — нули (`ran=False` / 0.0 мс)."""
    for f in dataclasses.fields(sink):  # ty: ignore[invalid-argument-type]
        value = getattr(sink, f.name)
        if dataclasses.is_dataclass(value):
            _assert_clean_and_disabled(value, f"{path}.{f.name}")
        elif f.name == "enabled":
            assert value is False, f"{path}.enabled"
        else:
            assert value in (False, 0.0), f"{path}.{f.name} is dirty: {value}"


def test_disabled_singletons_stay_zero_and_disabled() -> None:
    # Общие sink'и переиспользуются на каждом выключенном прогоне — если бы в них кто-то писал,
    # значения бы накапливались между диспатчами. Проверяем инвариант: всё, кроме `enabled`, — нули.
    _assert_clean_and_disabled(_DISABLED_TIMINGS, "StepTimings")
    _assert_clean_and_disabled(_DISABLED_INTERPRETATION_TIMINGS, "InterpretationTimings")
