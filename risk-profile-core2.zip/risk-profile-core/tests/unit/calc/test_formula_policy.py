import pytest

from src.calc.domain.formula import Formula
from src.calc.domain.formula_policy import resolve_formula_input
from src.calc.domain.formulas.beck_depression import BeckDepressionFormula
from src.calc.domain.formulas.spilberger_hanin import SpilbergerHaninFormula
from src.calc.domain.models import CalcReasonCode, CalcRejection, InstrumentDefinition, InstrumentsCodes
from tests.consts import PARAMETER_CODE_AGE, PARAMETER_CODE_WEIGHT

_SCALES = [
    pytest.param(InstrumentsCodes.BECK_DEPRESSION, tuple(BeckDepressionFormula.PARAMS_BECK_DEPRESSION), id="bdi"),
    pytest.param(InstrumentsCodes.SPILLBERGER_HANIN, SpilbergerHaninFormula.PARAMS_SPILBERGER_HANIN, id="stai"),
]


def _definition(code: str = "BCRAT", required: tuple[str, ...] = (PARAMETER_CODE_AGE,)) -> InstrumentDefinition:
    return InstrumentDefinition(
        instrument_code=code,
        required_parameter_codes=required,
        optional_parameter_codes=(),
    )


def test_returns_built_input_when_required_params_present() -> None:
    definition = _definition()
    input = resolve_formula_input(definition, {PARAMETER_CODE_AGE: "40"}, is_pregnant=False, patient_id="p1")
    assert not isinstance(input, CalcRejection)
    assert input.instrument_code == "BCRAT"
    assert input.params == {PARAMETER_CODE_AGE: "40"}
    assert input.is_pregnant is False


def test_non_pregnant_missing_params_is_skipped() -> None:
    definition = _definition()
    rejection = resolve_formula_input(definition, {}, is_pregnant=False, patient_id="p1")
    # Решение прежнее — инструмент пропускается; наружу теперь уходит и причина пропуска.
    assert rejection == CalcRejection(
        reason_code=CalcReasonCode.MISSING_REQUIRED_PARAMETERS, missing_parameter_codes=(PARAMETER_CODE_AGE,)
    )


def test_pregnant_missing_params_yields_inapplicable_input() -> None:
    definition = _definition(required=(PARAMETER_CODE_AGE, PARAMETER_CODE_WEIGHT))
    input = resolve_formula_input(definition, {}, is_pregnant=True, patient_id="p1")
    assert not isinstance(input, CalcRejection)
    assert input.is_pregnant is True
    assert input.params == {}
    assert input.instrument_code == "BCRAT"
    assert input.required_parameter_codes == (PARAMETER_CODE_AGE, PARAMETER_CODE_WEIGHT)


def test_pregnant_with_params_still_builds_normally() -> None:
    definition = _definition()
    input = resolve_formula_input(definition, {PARAMETER_CODE_AGE: "40"}, is_pregnant=True, patient_id="p1")
    assert not isinstance(input, CalcRejection)
    assert input.params == {PARAMETER_CODE_AGE: "40"}
    assert input.is_pregnant is True


class TestScaleGateOrder:
    """bdi/stai (issue #172): возраст проверяется раньше полноты ответов.

    age < 18 → «не применимо» (заглушка not_required), не глядя на ответы;
    age ≥ 18 и нет хотя бы одного ответа шкалы → инструмент пропускается целиком (отказ
    `incomplete_scale`): ни results/results_history, ни сообщения в risk-calculation.
    """

    @staticmethod
    def _scale_definition(code: str, answer_codes: tuple[str, ...]) -> InstrumentDefinition:
        return _definition(code=code, required=(PARAMETER_CODE_AGE, *answer_codes))

    @staticmethod
    def _answers(answer_codes: tuple[str, ...], age: str = "40") -> dict[str, str | None]:
        return {PARAMETER_CODE_AGE: age} | {code: f"{code}_answer" for code in answer_codes}

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_adult_with_all_answers_builds_input(self, code: str, answer_codes: tuple[str, ...]) -> None:
        definition = self._scale_definition(code, answer_codes)
        input = resolve_formula_input(definition, self._answers(answer_codes), is_pregnant=False, patient_id="p1")
        assert not isinstance(input, CalcRejection)
        assert set(input.params) == {PARAMETER_CODE_AGE, *answer_codes}
        assert Formula().is_applicable(input) is True

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_adult_missing_one_answer_is_skipped(self, code: str, answer_codes: tuple[str, ...]) -> None:
        definition = self._scale_definition(code, answer_codes)
        for dropped in answer_codes:
            values = self._answers(answer_codes)
            del values[dropped]
            rejection = resolve_formula_input(definition, values, is_pregnant=False, patient_id="p1")
            assert rejection == CalcRejection(
                reason_code=CalcReasonCode.INCOMPLETE_SCALE, missing_parameter_codes=(dropped,)
            ), dropped

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_adult_with_skipped_empty_answer_is_skipped(self, code: str, answer_codes: tuple[str, ...]) -> None:
        # Пропущенный ответ хранится пустой строкой — балл по нему не посчитать, значит «нет ответа».
        definition = self._scale_definition(code, answer_codes)
        values = self._answers(answer_codes) | {answer_codes[0]: ""}
        rejection = resolve_formula_input(definition, values, is_pregnant=False, patient_id="p1")
        assert isinstance(rejection, CalcRejection)
        assert rejection.reason_code is CalcReasonCode.INCOMPLETE_SCALE

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_adult_boundary_18_requires_answers(self, code: str, answer_codes: tuple[str, ...]) -> None:
        definition = self._scale_definition(code, answer_codes)
        # Граница: ровно 18 лет — взрослый, требуются ответы.
        rejection = resolve_formula_input(definition, {PARAMETER_CODE_AGE: "18"}, is_pregnant=False, patient_id="p1")
        assert isinstance(rejection, CalcRejection), "age=18 без ответов должен пропускать инструмент"
        assert rejection.reason_code is CalcReasonCode.INCOMPLETE_SCALE
        assert rejection.missing_parameter_codes == answer_codes
        # С полными ответами age=18 должен считаться.
        values = self._answers(answer_codes, age="18")
        input = resolve_formula_input(definition, values, is_pregnant=False, patient_id="p1")
        assert not isinstance(input, CalcRejection)
        assert Formula().is_applicable(input) is True

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_underage_without_answers_is_inapplicable_not_skipped(
        self, code: str, answer_codes: tuple[str, ...]
    ) -> None:
        definition = self._scale_definition(code, answer_codes)
        input = resolve_formula_input(definition, {PARAMETER_CODE_AGE: "17"}, is_pregnant=False, patient_id="p1")
        assert not isinstance(input, CalcRejection)
        assert input.params == {PARAMETER_CODE_AGE: "17"}
        assert input.is_pregnant is False
        # Итог для пайплайна: не применимо → not_required-заглушка, а не пропуск инструмента.
        assert Formula().is_applicable(input) is False
        # Причину «несовершеннолетний» по одному входу не восстановить — её проставляет резолв.
        assert Formula().inapplicability_reason(input) is CalcReasonCode.BELOW_ADULT_AGE

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_underage_with_all_answers_is_inapplicable(self, code: str, answer_codes: tuple[str, ...]) -> None:
        definition = self._scale_definition(code, answer_codes)
        values = self._answers(answer_codes, age="17")
        input = resolve_formula_input(definition, values, is_pregnant=False, patient_id="p1")
        assert not isinstance(input, CalcRejection)
        assert Formula().is_applicable(input) is False

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    @pytest.mark.parametrize("age", [None, "", "не указан"])
    def test_unusable_age_is_skipped(self, code: str, answer_codes: tuple[str, ...], age: str | None) -> None:
        definition = self._scale_definition(code, answer_codes)
        values = self._answers(answer_codes) | {PARAMETER_CODE_AGE: age}
        rejection = resolve_formula_input(definition, values, is_pregnant=False, patient_id="p1")
        assert rejection == CalcRejection(
            reason_code=CalcReasonCode.MISSING_REQUIRED_PARAMETERS, missing_parameter_codes=(PARAMETER_CODE_AGE,)
        )

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_pregnancy_still_precedes_the_scale_gate(self, code: str, answer_codes: tuple[str, ...]) -> None:
        definition = self._scale_definition(code, answer_codes)
        input = resolve_formula_input(definition, {}, is_pregnant=True, patient_id="p1")
        assert not isinstance(input, CalcRejection)
        assert input.is_pregnant is True
        assert input.params == {}

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_answer_codes_cover_the_whole_scale(self, code: str, answer_codes: tuple[str, ...]) -> None:
        expected_count = 21 if code == InstrumentsCodes.BECK_DEPRESSION else 40
        prefix = "bdi" if code == InstrumentsCodes.BECK_DEPRESSION else "stai"
        assert len(set(answer_codes)) == expected_count
        assert set(answer_codes) == {f"{prefix}{i}" for i in range(1, expected_count + 1)}

    def test_other_calculators_keep_the_default_order(self) -> None:
        # stop_bang: возраст тоже гейтит, но порядок общий — нехватка обязательных отсекает раньше.
        definition = _definition(code=InstrumentsCodes.STOP_BANG, required=(PARAMETER_CODE_AGE, "snoring"))
        rejection = resolve_formula_input(definition, {PARAMETER_CODE_AGE: "17"}, is_pregnant=False, patient_id="p1")
        assert rejection == CalcRejection(
            reason_code=CalcReasonCode.MISSING_REQUIRED_PARAMETERS, missing_parameter_codes=("snoring",)
        )

    @pytest.mark.parametrize(("code", "answer_codes"), _SCALES)
    def test_params_match_formula_definitions(self, code: str, answer_codes: tuple[str, ...]) -> None:
        # Убедиться, что PARAMS_* в формуле совпадают с тем, что видит formula_policy.
        if code == InstrumentsCodes.BECK_DEPRESSION:
            assert answer_codes == tuple(BeckDepressionFormula.PARAMS_BECK_DEPRESSION)
        else:
            assert answer_codes == SpilbergerHaninFormula.PARAMS_SPILBERGER_HANIN
