"""Unit-тесты `src/calc/dispatcher.py`: контракт `dispatch_recalc`."""

import functools
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.calc.dispatcher import dispatch_recalc, get_dispatcher, run_recalc
from src.calc.domain.models import CalculationRequest
from src.calc.outcomes import CalcRunResult
from tests.conftest import LogSink
from tests.consts import PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT


@pytest.fixture(autouse=True)
def _no_kafka(monkeypatch: pytest.MonkeyPatch) -> None:
    """Изолируем dispatcher от реального kafka-singleton."""
    from src.calc.dispatcher import KafkaInitError

    def _raise() -> None:
        raise KafkaInitError("kafka disabled in unit tests")

    monkeypatch.setattr("src.calc.dispatcher.get_kafka_producer", _raise)


@pytest.fixture(autouse=True)
def _stub_catalog(monkeypatch: pytest.MonkeyPatch) -> None:
    """run_recalc builds one-shot catalogs from its session when none is injected; these unit tests
    use a mocked session, so stub the build to a no-op (CalcReader/CalcHandler are mocked)."""
    monkeypatch.setattr("src.calc.dispatcher.build_catalogs", AsyncMock(return_value=MagicMock()))


@pytest.fixture
def fake_session_cm() -> AsyncMock:
    cm = AsyncMock()
    cm.__aenter__.return_value = AsyncMock(name="session")
    cm.__aexit__.return_value = None
    return cm


async def test_full_recalc_when_parameter_codes_is_none(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult()
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(patient_id="p1")
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler) as handler_cls,
        patch("src.calc.dispatcher.CalcReader", return_value=reader),
    ):
        await dispatch_recalc(patient_id="p1", parameter_codes=None)

    reader.build_request.assert_called_once_with("p1", None)
    handler_cls.assert_called_once()
    handler.run.assert_awaited_once()
    requests = handler.run.await_args.args[0]
    assert len(requests) == 1
    assert requests[0].patient_id == "p1"
    assert requests[0].instrument_codes is None


async def test_empty_parameter_codes_short_circuits(fake_session_cm: AsyncMock) -> None:
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)) as factory,
        patch("src.calc.dispatcher.CalcHandler") as handler_cls,
    ):
        await dispatch_recalc(patient_id="p1", parameter_codes=set())

    factory.assert_not_called()
    handler_cls.assert_not_called()


async def test_resolved_instruments_drive_requests(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult()
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(
        patient_id="p1", instrument_codes=frozenset({"BCRAT", "SCORE2"})
    )
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler),
        patch("src.calc.dispatcher.CalcReader", return_value=reader),
    ):
        await dispatch_recalc(patient_id="p1", parameter_codes={PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT})

    reader.build_request.assert_called_once_with("p1", {PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT})
    handler.run.assert_awaited_once()
    requests = handler.run.await_args.args[0]
    assert requests == [CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT", "SCORE2"}))]


async def test_no_instruments_resolved_skips_handler(fake_session_cm: AsyncMock) -> None:
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(patient_id="p1", instrument_codes=frozenset())
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler") as handler_cls,
        patch("src.calc.dispatcher.CalcReader", return_value=reader),
    ):
        await dispatch_recalc(patient_id="p1", parameter_codes={"orphan"})

    handler_cls.assert_not_called()


async def test_handler_exception_is_swallowed(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.side_effect = RuntimeError("calc blew up")
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler),
    ):
        # Не должно пробросить — BG-таска не должна валить процесс.
        await dispatch_recalc(patient_id="p1", parameter_codes=None)


async def test_run_recalc_rejects_empty_codes_on_its_own(fake_session_cm: AsyncMock) -> None:
    """Второй заслон против пустого набора — уже в `run_recalc`.

    `dispatch_recalc` закорачивает пустой набор до Kafka, но воркер вызывает `run_recalc` напрямую
    из полученной команды: если пустой набор всё же доедет до топика, обрабатывать его нельзя —
    `build_request` с пустым набором не должен превратиться в полный пересчёт.
    """
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)) as factory,
        patch("src.calc.dispatcher.CalcHandler") as handler_cls,
    ):
        assert await run_recalc(patient_id="p1", parameter_codes=set()) == CalcRunResult()

    factory.assert_not_called()
    handler_cls.assert_not_called()


async def test_injected_catalogs_are_not_rebuilt(fake_session_cm: AsyncMock, monkeypatch: pytest.MonkeyPatch) -> None:
    """Переданные каталоги идут в дело как есть — горячий путь воркера не ходит в БД за справочниками.

    Пересборка на каждую команду не только стоит запросов: `build_catalogs` создаёт новые объекты
    справочников, и они копились бы вне замороженного стартового heap-а.
    """
    build = AsyncMock()
    monkeypatch.setattr("src.calc.dispatcher.build_catalogs", build)
    catalogs = MagicMock(name="catalogs")
    handler = AsyncMock()
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"}))

    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler) as handler_cls,
        patch("src.calc.dispatcher.CalcReader", return_value=reader) as reader_cls,
    ):
        await run_recalc(patient_id="p1", parameter_codes=None, catalogs=catalogs)

    build.assert_not_awaited()
    assert reader_cls.call_args.args[1] is catalogs.calc
    assert handler_cls.call_args.args[1] is catalogs.calc
    assert handler_cls.call_args.kwargs["interpretation_catalog"] is catalogs.interpretation


async def test_unavailable_producer_disables_publishing_but_keeps_calculating(
    fake_session_cm: AsyncMock, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
) -> None:
    """Kafka включена, а продюсер не поднят: считаем, но результат опубликовать не сможем.

    Расчёт продолжается — результаты записываются в БД и доступны по HTTP. Молчать при этом нельзя:
    подписчики топика результатов перестают их получать, и без warning-а это выглядит как
    «пересчёт не запускался».
    """
    monkeypatch.setattr("src.calc.dispatcher.settings.kafka.enabled", True)
    handler = AsyncMock()
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"}))

    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(fake_session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler) as handler_cls,
        patch("src.calc.dispatcher.CalcReader", return_value=reader),
    ):
        await run_recalc(patient_id="p1", parameter_codes=None)

    assert handler_cls.call_args.args[2] is None  # продюсер не передан — публиковать нечем
    handler.run.assert_awaited_once()
    assert "calc.run_recalc: kafka producer unavailable, result publishing disabled" in captured_app_logs.messages()


def test_get_dispatcher_binds_catalogs_built_at_startup() -> None:
    """FastAPI-зависимость приклеивает каталоги приложения к inline-ветке пересчёта."""
    request = MagicMock()
    request.app.state.catalogs = MagicMock(name="catalogs")

    dispatcher = get_dispatcher(request)

    # Зависимость отдаёт именно partial: по нему и проверяются приклеенные каталоги.
    assert isinstance(dispatcher, functools.partial)
    assert dispatcher.func is dispatch_recalc
    assert dispatcher.keywords["catalogs"] is request.app.state.catalogs


def _runtime(session_cm: AsyncMock) -> SimpleNamespace:
    """Основной рантайм процесса, чья фабрика отдаёт сессию теста."""
    return SimpleNamespace(session_factory=MagicMock(return_value=session_cm))
