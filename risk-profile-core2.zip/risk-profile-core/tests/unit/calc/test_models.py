from src.calc.domain.models import CalculationRequest


def test_calculation_request_without_instruments():
    request = CalculationRequest(patient_id="p1")
    assert request.instrument_codes is None


def test_calculation_request_with_instruments():
    request = CalculationRequest(patient_id="p1", instrument_codes=frozenset({"CVD"}))
    assert request.instrument_codes == frozenset({"CVD"})
