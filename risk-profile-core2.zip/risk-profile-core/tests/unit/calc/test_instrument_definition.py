import dataclasses

import pytest

from src.calc.domain.models import InstrumentDefinition


def test_instrument_definition_is_frozen_with_tuples():
    d = InstrumentDefinition(
        instrument_code="i1",
        required_parameter_codes=("p1", "p2"),
        optional_parameter_codes=("p3",),
    )
    assert d.required_parameter_codes == ("p1", "p2")
    with pytest.raises(dataclasses.FrozenInstanceError):
        d.instrument_code = "i2"  # ty: ignore[invalid-assignment]
