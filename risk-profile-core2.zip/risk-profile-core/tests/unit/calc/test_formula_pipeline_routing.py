"""Маршрутизация формульного pipeline: только зарегистрированные коды типа `calc`."""

import logging

import pytest

from src.calc.domain.formula import Formula
from src.calc.domain.models import CalcStatus, InstrumentsCodes
from src.calc.formula_pipeline import FormulaPipeline
from src.calc.outcomes import CalcRunResult, ResultBatch
from src.calc.status_collector import CalcStatusCollector
from src.calc.timings import _DISABLED_TIMINGS
from src.infra.catalog.calc import CalcCatalog
from tests.catalog_builder import instrument, instrument_parameter, make_catalog, option, question
from tests.consts import GENDER_MALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER

_SKF_PARAMS = ("creatinine", PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER)


def _catalog() -> CalcCatalog:
    return CalcCatalog(
        make_catalog(
            instruments=[
                instrument(InstrumentsCodes.SKF, type="calc", instrument_id=1),
                instrument("calc_unknown", type="calc", instrument_id=2),
                instrument("biomarker_kr", type="biomarker_kr", instrument_id=3),
                instrument(InstrumentsCodes.CVD, instrument_id=4),
            ],
            instruments_parameters=[
                *[instrument_parameter(InstrumentsCodes.SKF, code, is_required=True) for code in _SKF_PARAMS],
                instrument_parameter("calc_unknown", "p_unknown", is_required=True),
                instrument_parameter("biomarker_kr", "biomarker_ldl"),
                instrument_parameter(InstrumentsCodes.CVD, "p_cvd"),
            ],
            questions=[question("BDI1", question_id=5)],
            options=[
                option("BDI1_01", question_code="BDI1", parameter_code="bdi1", value="ok", option_id=1),
                option("BDI1_04", question_code="BDI1", parameter_code="bdi1", value="bad", option_id=2),
            ],
        )
    )


async def _run(
    catalog: CalcCatalog,
    values: dict[str, str | None],
    *,
    allowed: frozenset[str] | None = None,
) -> tuple[ResultBatch, CalcRunResult]:
    batch = ResultBatch()
    outcome = CalcRunResult()
    pipeline = FormulaPipeline(
        Formula(), None, catalog.formula_configs, CalcStatusCollector(), catalog.unsupported_calc_codes
    )
    await pipeline.process("p1", values, False, allowed, batch, outcome, _DISABLED_TIMINGS, excluded_by_instrument={})
    return batch, outcome


async def test_supported_calc_code_is_computed() -> None:
    batch, outcome = await _run(
        _catalog(),
        {"creatinine": "80", PARAMETER_CODE_AGE: "40", PARAMETER_CODE_GENDER: GENDER_MALE},
    )
    assert [result.instrument_code for result in batch.results] == [InstrumentsCodes.SKF]
    assert batch.publish_codes == [InstrumentsCodes.SKF]


async def test_unsupported_calc_code_is_logged_and_skipped(caplog: pytest.LogCaptureFixture) -> None:
    catalog = _catalog()
    with caplog.at_level(logging.ERROR, logger="src"):
        batch, outcome = await _run(
            catalog,
            {"creatinine": "80", PARAMETER_CODE_AGE: "40", PARAMETER_CODE_GENDER: GENDER_MALE, "p_unknown": "1"},
        )
    # Пустой результат только по нему: соседний поддерживаемый инструмент посчитан.
    assert [result.instrument_code for result in batch.results] == [InstrumentsCodes.SKF]
    assert outcome.skipped == 1
    records = [r for r in caplog.records if r.message == "calc.formula: unsupported calc instrument"]
    assert len(records) == 1
    context = records[0].log_context  # ty: ignore[unresolved-attribute]
    # Контекст описывает справочник, а не пациента: `patient_id` в него не кладётся, потому что
    # запись одна на прогон, а не на каждого пациента пачки.
    assert context == {"instrument_code": "calc_unknown"}
    # Значения параметров пациента в лог не попадают.
    assert "p_unknown" not in str(context)


async def test_unsupported_calc_code_is_logged_once_per_run(caplog: pytest.LogCaptureFixture) -> None:
    """Дефект справочника один, пациентов много: ERROR пишется один раз, отказы — по каждому."""
    catalog = _catalog()
    values: dict[str, str | None] = {
        "creatinine": "80",
        PARAMETER_CODE_AGE: "40",
        PARAMETER_CODE_GENDER: GENDER_MALE,
        "p_unknown": "1",
    }
    batch = ResultBatch()
    outcome = CalcRunResult()
    statuses = CalcStatusCollector()
    pipeline = FormulaPipeline(Formula(), None, catalog.formula_configs, statuses, catalog.unsupported_calc_codes)
    with caplog.at_level(logging.ERROR, logger="src"):
        for patient_id in ("p1", "p2", "p3"):
            await pipeline.process(
                patient_id,
                values,
                False,
                None,
                batch,
                outcome,
                _DISABLED_TIMINGS,
                excluded_by_instrument={},
            )

    records = [r for r in caplog.records if r.message == "calc.formula: unsupported calc instrument"]
    assert len(records) == 1
    # Счётчик пропусков при этом поштучный: охват дефекта по пациентам не теряется.
    assert outcome.skipped == 3


async def test_biomarker_instrument_never_reaches_formula_pipeline() -> None:
    catalog = _catalog()
    assert "biomarker_kr" not in catalog.formula_configs
    assert "biomarker_kr" not in catalog.unsupported_calc_codes
    batch, outcome = await _run(catalog, {"biomarker_ldl": "5"})
    assert all(result.instrument_code != "biomarker_kr" for result in batch.results)


async def test_questionnaire_and_form_common_are_not_formulas() -> None:
    catalog = _catalog()
    assert set(catalog.formula_configs) == {InstrumentsCodes.SKF}
    assert set(catalog.questionnaire_configs) == {InstrumentsCodes.CVD}


async def test_partial_recalc_does_not_report_unrequested_unsupported_code() -> None:
    _, outcome = await _run(
        _catalog(),
        {"creatinine": "80", PARAMETER_CODE_AGE: "40", PARAMETER_CODE_GENDER: GENDER_MALE},
        allowed=frozenset({InstrumentsCodes.SKF}),
    )
    assert outcome.skipped == 0


def test_status_taxonomy_of_unsupported_code() -> None:
    """Неподдерживаемый calc — «временно недоступно», а не клиническая неприменимость."""
    from src.calc.domain.models import CalcReasonCode, CalcRejection

    assert CalcRejection(reason_code=CalcReasonCode.CALCULATION_ERROR).status is CalcStatus.UNAVAILABLE
