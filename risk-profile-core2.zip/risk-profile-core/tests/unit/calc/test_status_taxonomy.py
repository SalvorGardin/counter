"""Таксономия причин: по одному сценарию на каждый `reason_code`.

Проверяется на уровне пайплайнов, а не БД: сопоставление «решение расчёта → код причины»
принимается именно здесь, и держать его в интеграционных тестах значило бы платить поднятием PostgreSQL
за проверку ветвления. Запись накопленного в таблицу и грань строки — дело
tests/integration/calc/test_status_collection.py.

Коллектор берётся настоящий (с включённым флагом), а не заглушка: правило «первая запись по паре
выигрывает» — часть контракта, ради которого cvd-исходы регистрируются глубже по стеку.
"""

from datetime import timedelta
from unittest.mock import AsyncMock, patch

import pytest

from src.calc.domain.exceptions import FormulaCalculationError, QuestionnaireCalculationError
from src.calc.domain.formula import Formula
from src.calc.domain.formulas.beck_depression import BeckDepressionFormula
from src.calc.domain.models import (
    CalcReasonCode,
    CalcStatus,
    FormulaResult,
    InstrumentDefinition,
    InstrumentInput,
    InstrumentsCodes,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
    QuestionnaireEligibility,
    QuestionnaireScoreRow,
)
from src.calc.domain.questionnaire import QuestionnaireCalculator
from src.calc.formula_pipeline import FormulaPipeline
from src.calc.infra.cvd_client import CvdServiceError
from src.calc.outcomes import CalcRunResult, ResultBatch
from src.calc.questionnaire_pipeline import QuestionnairePipeline
from src.calc.status_collector import CalcStatusCollector
from src.calc.timings import StepTimings
from src.constants import ResultInterpretationStatus
from tests.consts import (
    GENDER_MALE,
    PARAMETER_CODE_AGE,
    PARAMETER_CODE_BMI,
    PARAMETER_CODE_GENDER,
    PARAMETER_CODE_WEIGHT,
)

PATIENT = "p1"


@pytest.fixture
def statuses(monkeypatch: pytest.MonkeyPatch) -> CalcStatusCollector:
    """Коллектор с включённым сбором и сессией, которой нельзя воспользоваться.

    Тесты проверяют накопленное (`pending`), а не запись: попытка открыть сессию здесь —
    ошибка теста, а не ожидаемое поведение.
    """
    from src.config import settings

    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)

    def _forbidden() -> None:
        raise AssertionError("сбор не должен открывать сессию до flush_patient")

    return CalcStatusCollector(session_factory=_forbidden)  # ty: ignore[invalid-argument-type]


def _definition(code: str, required: tuple[str, ...] = (PARAMETER_CODE_AGE,)) -> InstrumentDefinition:
    return InstrumentDefinition(instrument_code=code, required_parameter_codes=required, optional_parameter_codes=())


def _stub_result(instrument_code: str) -> FormulaResult:
    return FormulaResult(
        instrument_code=instrument_code,
        patient_id=PATIENT,
        value=1.0,
        unit=InstrumentsUnits.BCRAT,
        risk_level=InstrumentsRiskLevel.LOW,
        applicability=True,
        interpretation_status=ResultInterpretationStatus.READY,
        expiration_delta=timedelta(days=30),
        indicator=InstrumentsIndicators.BCRAT,
    )


def _recorded(statuses: CalcStatusCollector, instrument_code: str) -> dict[str, object]:
    pending = statuses.pending()
    assert (PATIENT, instrument_code) in pending, f"нет статуса по {instrument_code}: {pending}"
    return pending[(PATIENT, instrument_code)]


def _assert_reason(
    statuses: CalcStatusCollector,
    instrument_code: str,
    status: CalcStatus,
    reason: CalcReasonCode | None,
) -> dict[str, object]:
    row = _recorded(statuses, instrument_code)
    assert row["status"] == status.value
    assert row["reason_code"] == (reason.value if reason is not None else None)
    return row


async def _run_formula(
    statuses: CalcStatusCollector,
    definition: InstrumentDefinition,
    values: dict[str, str | None],
    *,
    is_pregnant: bool = False,
    cvd: object = None,
) -> CalcRunResult:
    outcome = CalcRunResult()
    pipeline = FormulaPipeline(Formula(), cvd, {definition.instrument_code: definition}, statuses)  # ty: ignore[invalid-argument-type]
    timings = StepTimings()
    timings.enable(False)
    await pipeline.process(PATIENT, values, is_pregnant, None, ResultBatch(), outcome, timings)
    return outcome


class TestFormulaTaxonomy:
    async def test_calculated_has_no_reason(self, statuses: CalcStatusCollector) -> None:
        definition = _definition("T_OK")
        with (
            patch.object(Formula, "is_applicable", lambda self, input: True),
            patch.object(Formula, "calculate", lambda self, input: _stub_result(input.instrument_code)),
        ):
            await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "40"})
        _assert_reason(statuses, "T_OK", CalcStatus.CALCULATED, None)

    async def test_missing_required_parameters_lists_codes(self, statuses: CalcStatusCollector) -> None:
        definition = _definition("T_MISS", required=(PARAMETER_CODE_AGE, PARAMETER_CODE_WEIGHT))
        await _run_formula(statuses, definition, {})
        row = _assert_reason(
            statuses, "T_MISS", CalcStatus.INSUFFICIENT_DATA, CalcReasonCode.MISSING_REQUIRED_PARAMETERS
        )
        assert row["missing_parameter_codes"] == [PARAMETER_CODE_AGE, PARAMETER_CODE_WEIGHT]

    async def test_pregnant_is_not_applicable(self, statuses: CalcStatusCollector) -> None:
        definition = _definition(InstrumentsCodes.STOP_BANG, required=(PARAMETER_CODE_AGE,))
        await _run_formula(statuses, definition, {}, is_pregnant=True)
        _assert_reason(statuses, InstrumentsCodes.STOP_BANG, CalcStatus.NOT_APPLICABLE, CalcReasonCode.PREGNANT)

    async def test_below_adult_age_is_distinct_from_out_of_clinical_range(self, statuses: CalcStatusCollector) -> None:
        answers = tuple(BeckDepressionFormula.PARAMS_BECK_DEPRESSION)
        definition = _definition(InstrumentsCodes.BECK_DEPRESSION, required=(PARAMETER_CODE_AGE, *answers))
        await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "17"})
        _assert_reason(
            statuses,
            InstrumentsCodes.BECK_DEPRESSION,
            CalcStatus.NOT_APPLICABLE,
            CalcReasonCode.BELOW_ADULT_AGE,
        )

    async def test_out_of_clinical_range_when_formula_refuses(self, statuses: CalcStatusCollector) -> None:
        # Реальный зарегистрированный код: OUT_OF_CLINICAL_RANGE — дефолт для формулы, отказавшей
        # по своим клиническим рамкам, а не для инструмента, которого нет в _REGISTRY (тот код
        # ниже отличается — см. test_unknown_instrument_is_calculation_error_not_out_of_clinical_range).
        definition = _definition(InstrumentsCodes.SKF)
        with (
            patch.object(Formula, "is_applicable", lambda self, input: False),
            patch.object(Formula, "make_dummy", lambda self, input: _stub_result(input.instrument_code)),
        ):
            await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "40"})
        _assert_reason(statuses, InstrumentsCodes.SKF, CalcStatus.NOT_APPLICABLE, CalcReasonCode.OUT_OF_CLINICAL_RANGE)

    async def test_unknown_instrument_is_calculation_error_not_out_of_clinical_range(
        self, statuses: CalcStatusCollector
    ) -> None:
        definition = _definition("T_UNKNOWN")
        await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "40"})
        _assert_reason(statuses, "T_UNKNOWN", CalcStatus.UNAVAILABLE, CalcReasonCode.CALCULATION_ERROR)

    async def test_incomplete_scale_lists_missing_answers(self, statuses: CalcStatusCollector) -> None:
        answers = tuple(BeckDepressionFormula.PARAMS_BECK_DEPRESSION)
        definition = _definition(InstrumentsCodes.BECK_DEPRESSION, required=(PARAMETER_CODE_AGE, *answers))
        values: dict[str, str | None] = {PARAMETER_CODE_AGE: "40"} | {code: "1" for code in answers[1:]}
        await _run_formula(statuses, definition, values)
        row = _assert_reason(
            statuses,
            InstrumentsCodes.BECK_DEPRESSION,
            CalcStatus.INSUFFICIENT_DATA,
            CalcReasonCode.INCOMPLETE_SCALE,
        )
        assert row["missing_parameter_codes"] == [answers[0]]

    async def test_calculation_error_keeps_no_exception_text(self, statuses: CalcStatusCollector) -> None:
        definition = _definition("T_ERR")

        def _boom(self, input: InstrumentInput) -> FormulaResult:
            raise FormulaCalculationError(input.instrument_code, ValueError("глюкоза 12.5 у пациента Иванов"))

        with (
            patch.object(Formula, "is_applicable", lambda self, input: True),
            patch.object(Formula, "calculate", _boom),
        ):
            await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "40"})
        row = _assert_reason(statuses, "T_ERR", CalcStatus.UNAVAILABLE, CalcReasonCode.CALCULATION_ERROR)
        assert row["missing_parameter_codes"] is None
        assert "Иванов" not in str(row)


class TestCvdTaxonomy:
    """`cvd_disabled` и `cvd_error` должны быть различимы между собой и от прочих исходов."""

    # Полный набор факторов риска: без него `build_risk_factors` упадёт раньше сетевого вызова,
    # и тест проверял бы не тот отказ.
    _RISK_FACTORS = {
        PARAMETER_CODE_AGE: "40",
        PARAMETER_CODE_GENDER: GENDER_MALE,
        PARAMETER_CODE_BMI: "24",
        "systolic_bp": "120",
        "lipoprotein_a": "10",
        "hdl": "1.2",
        "ldl": "3.0",
        "lipid_lowering_meds": "Нет",
        "atherosclerosis": "Нет",
        "diabetes": "Нет",
        "family_acute_cvd": "Нет",
        "family_hypercholesterolemia": "Нет",
    }

    @classmethod
    def _input(cls) -> InstrumentInput:
        return InstrumentInput(
            instrument_code=InstrumentsCodes.AIRI_SSZ,
            patient_id=PATIENT,
            is_pregnant=False,
            params=dict(cls._RISK_FACTORS),
            required_parameter_codes=tuple(cls._RISK_FACTORS),
        )

    async def test_disabled_integration_is_not_an_error(self, statuses: CalcStatusCollector) -> None:
        pipeline = FormulaPipeline(Formula(), None, {}, statuses)
        with patch.object(type(Formula()), "is_applicable", lambda self, input: True):
            await pipeline._calculate_airi(self._input())
        _assert_reason(statuses, InstrumentsCodes.AIRI_SSZ, CalcStatus.UNAVAILABLE, CalcReasonCode.CVD_DISABLED)

    async def test_service_failure_is_cvd_error(self, statuses: CalcStatusCollector) -> None:
        cvd = AsyncMock()
        cvd.calculate.side_effect = CvdServiceError("cvd unavailable")
        pipeline = FormulaPipeline(Formula(), cvd, {}, statuses)
        with pytest.raises(FormulaCalculationError):
            await pipeline._calculate_airi(self._input())
        _assert_reason(statuses, InstrumentsCodes.AIRI_SSZ, CalcStatus.UNAVAILABLE, CalcReasonCode.CVD_ERROR)

    async def test_cvd_reason_survives_the_callers_generic_record(self, statuses: CalcStatusCollector) -> None:
        """Заглушка выключенного cvd доезжает до `batch.add`, но `calculated` её не затирает."""
        definition = _definition(InstrumentsCodes.AIRI_SSZ)
        with patch.object(Formula, "is_applicable", lambda self, input: True):
            await _run_formula(statuses, definition, {PARAMETER_CODE_AGE: "40"}, cvd=None)
        _assert_reason(statuses, InstrumentsCodes.AIRI_SSZ, CalcStatus.UNAVAILABLE, CalcReasonCode.CVD_DISABLED)


class TestQuestionnaireTaxonomy:
    @staticmethod
    def _pipeline(
        statuses: CalcStatusCollector,
        *,
        eligibility: dict[tuple[str, str], QuestionnaireEligibility] | None = None,
        rows: list[QuestionnaireScoreRow] | None = None,
        configs: dict[str, InstrumentDefinition] | None = None,
        existing_keys: frozenset[tuple[str, str]] = frozenset(),
    ) -> QuestionnairePipeline:
        rows = rows or []
        resolved_configs = configs or {row.instrument_code: _definition(row.instrument_code) for row in rows}
        return QuestionnairePipeline(
            QuestionnaireCalculator(),
            resolved_configs,
            eligibility or {},
            {(row.patient_id, row.instrument_code): row for row in rows},
            existing_keys,
            statuses,
        )

    @staticmethod
    def _row(instrument_code: str, score: str = "1") -> QuestionnaireScoreRow:
        from decimal import Decimal

        return QuestionnaireScoreRow(patient_id=PATIENT, instrument_code=instrument_code, score=Decimal(score))

    def test_calculated(self, statuses: CalcStatusCollector) -> None:
        code = InstrumentsCodes.CVD.value
        pipeline = self._pipeline(statuses, rows=[self._row(code)])
        pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        _assert_reason(statuses, code, CalcStatus.CALCULATED, None)

    def test_pregnant(self, statuses: CalcStatusCollector) -> None:
        code = InstrumentsCodes.CVD.value
        pipeline = self._pipeline(statuses, configs={code: _definition(code)})
        pipeline.process(PATIENT, True, None, ResultBatch(), CalcRunResult())
        _assert_reason(statuses, code, CalcStatus.NOT_APPLICABLE, CalcReasonCode.PREGNANT)

    def test_not_enough_answers_carries_the_counts(self, statuses: CalcStatusCollector) -> None:
        code = InstrumentsCodes.GI.value
        eligibility = QuestionnaireEligibility(
            patient_id=PATIENT, instrument_code=code, applicable_questions=9, progressed_questions=3
        )
        pipeline = self._pipeline(statuses, eligibility={(PATIENT, code): eligibility}, rows=[self._row(code)])
        pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        row = _assert_reason(statuses, code, CalcStatus.INSUFFICIENT_DATA, CalcReasonCode.NOT_ENOUGH_ANSWERS)
        assert row["applicable_questions"] == 9
        assert row["progressed_questions"] == 3

    def test_required_parameters_missing_lists_codes(self, statuses: CalcStatusCollector) -> None:
        code = InstrumentsCodes.CVD.value
        eligibility = QuestionnaireEligibility(
            patient_id=PATIENT,
            instrument_code=code,
            applicable_questions=4,
            progressed_questions=4,
            required_total=2,
            required_answered=1,
            missing_required_codes=("smoking",),
        )
        pipeline = self._pipeline(statuses, eligibility={(PATIENT, code): eligibility}, rows=[self._row(code)])
        pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        row = _assert_reason(statuses, code, CalcStatus.INSUFFICIENT_DATA, CalcReasonCode.REQUIRED_PARAMETERS_MISSING)
        assert row["missing_parameter_codes"] == ["smoking"]

    def test_no_answered_parameters(self, statuses: CalcStatusCollector) -> None:
        """Гейтированный инструмент без единого ответа получает диагностический статус."""
        code = InstrumentsCodes.GI.value
        pipeline = self._pipeline(statuses, configs={code: _definition(code)})
        pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        _assert_reason(statuses, code, CalcStatus.INSUFFICIENT_DATA, CalcReasonCode.NO_ANSWERED_PARAMETERS)

    def test_calculation_error(self, statuses: CalcStatusCollector) -> None:
        code = InstrumentsCodes.CVD.value
        pipeline = self._pipeline(statuses, rows=[self._row(code)])
        with patch.object(
            QuestionnaireCalculator,
            "calculate",
            lambda self, row: (_ for _ in ()).throw(QuestionnaireCalculationError(row.instrument_code, KeyError("x"))),
        ):
            pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        _assert_reason(statuses, code, CalcStatus.UNAVAILABLE, CalcReasonCode.CALCULATION_ERROR)

    def test_stale_cleanup_is_insufficient_data(self, statuses: CalcStatusCollector) -> None:
        """Заглушка блока очистки: ответов больше нет, пересчитать нечем."""
        code = InstrumentsCodes.CVD.value
        pipeline = self._pipeline(
            statuses,
            configs={code: _definition(code)},
            existing_keys=frozenset({(PATIENT, code)}),
        )
        pipeline.process(PATIENT, False, None, ResultBatch(), CalcRunResult())
        _assert_reason(statuses, code, CalcStatus.INSUFFICIENT_DATA, CalcReasonCode.MISSING_REQUIRED_PARAMETERS)


def test_every_reason_code_has_a_status() -> None:
    """Страховка от пополнения таксономии без статуса: код без экрана показать нечем."""
    from src.calc.domain.models import STATUS_BY_REASON

    assert set(STATUS_BY_REASON) == set(CalcReasonCode)
