"""Unit-тесты гистограмм времени пересчёта: что и с какими метками пишет `run_recalc`.

Значения метрик глобальны и живут между тестами, поэтому проверяем ДЕЛЬТУ «до/после» вызова,
а не абсолютные числа. Ряды всех комбинаций меток предынициализированы при импорте
`src/metrics.py`, так что `get_sample_value` обязан находить их ещё до первого пересчёта.
"""

import contextlib
import time
from collections.abc import Iterator
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from prometheus_client import REGISTRY

import src.calc.dispatcher as dispatcher
from src.calc.domain.models import CalculationRequest
from src.calc.outcomes import CalcRunResult
from src.metrics import (
    RECALC_OUTCOMES,
    RECALC_SCOPE_PARTIAL,
    RECALC_SCOPES,
    RECALC_SOURCE_BACKGROUND,
    RECALC_SOURCE_USER,
    RECALC_SOURCES,
    SERVICE_PREFIX,
)
from tests.consts import PARAMETER_CODE_HEIGHT

_HISTOGRAMS = (
    f"{SERVICE_PREFIX}_recalc_answer_to_result_seconds",
    f"{SERVICE_PREFIX}_recalc_queue_wait_seconds",
    f"{SERVICE_PREFIX}_recalc_duration_seconds",
)
_WALL_CLOCK_HISTOGRAMS = (
    f"{SERVICE_PREFIX}_recalc_answer_to_result_seconds",
    f"{SERVICE_PREFIX}_recalc_queue_wait_seconds",
)


def _labels(outcome: str, scope: str, source: str) -> dict[str, str]:
    return {"outcome": outcome, "scope": scope, "source": source}


def _count(name: str, outcome: str, scope: str, source: str = RECALC_SOURCE_USER) -> float:
    value = REGISTRY.get_sample_value(f"{name}_count", _labels(outcome, scope, source))
    assert value is not None, f"ряд {name} с метками {outcome}/{scope}/{source} должен существовать с момента импорта"
    return value


def _counts(outcome: str, scope: str, source: str = RECALC_SOURCE_USER) -> tuple[float, ...]:
    """Счётчики наблюдений всех трёх гистограмм для одной комбинации меток."""
    return tuple(_count(name, outcome, scope, source) for name in _HISTOGRAMS)


def _all_counts() -> dict[tuple[str, str, str], tuple[float, ...]]:
    """Все предынициализированные комбинации меток.

    Пара `partial` × `background` пропущена: массовый прогон публикует только полный пересчёт,
    и ряда под неё нет намеренно (см. `src/metrics.py`).
    """
    return {
        (outcome, scope, source): _counts(outcome, scope, source)
        for outcome in RECALC_OUTCOMES
        for scope in RECALC_SCOPES
        for source in RECALC_SOURCES
        if not (scope == RECALC_SCOPE_PARTIAL and source == RECALC_SOURCE_BACKGROUND)
    }


def _sum(name: str, outcome: str, scope: str, source: str = RECALC_SOURCE_USER) -> float:
    value = REGISTRY.get_sample_value(f"{name}_sum", _labels(outcome, scope, source))
    assert value is not None, f"ряд {name}_sum с метками {outcome}/{scope}/{source} должен существовать"
    return value


def _bucket(name: str, outcome: str, scope: str, le: str, source: str = RECALC_SOURCE_USER) -> float:
    value = REGISTRY.get_sample_value(f"{name}_bucket", _labels(outcome, scope, source) | {"le": le})
    assert value is not None, f"корзина le={le} у {name} должна существовать"
    return value


@pytest.fixture(autouse=True)
def _no_kafka(monkeypatch: pytest.MonkeyPatch) -> None:
    """Изолируем dispatcher от реального kafka-singleton."""

    def _raise() -> None:
        raise dispatcher.KafkaInitError("kafka disabled in unit tests")

    monkeypatch.setattr("src.calc.dispatcher.get_kafka_producer", _raise)


@pytest.fixture(autouse=True)
def _stub_catalog(monkeypatch: pytest.MonkeyPatch) -> None:
    """Сессия замокана, поэтому сборку одноразовых каталогов из неё коротим в no-op."""
    monkeypatch.setattr("src.calc.dispatcher.build_catalogs", AsyncMock(return_value=MagicMock()))


@pytest.fixture
def fake_session_cm() -> AsyncMock:
    cm = AsyncMock()
    cm.__aenter__.return_value = AsyncMock(name="session")
    cm.__aexit__.return_value = None
    return cm


@contextlib.contextmanager
def _calc_stack(handler: AsyncMock, session_cm: AsyncMock) -> Iterator[None]:
    """Подменяет всё, что `run_recalc` берёт из инфраструктуры: сессию, читателя и хендлер."""
    reader = MagicMock()
    reader.build_request.return_value = CalculationRequest(patient_id="p1", instrument_codes=frozenset({"phq9"}))
    with (
        patch("src.calc.dispatcher.get_primary_runtime", return_value=_runtime(session_cm)),
        patch("src.calc.dispatcher.CalcHandler", return_value=handler),
        patch("src.calc.dispatcher.CalcReader", return_value=reader),
    ):
        yield


async def test_written_outcome_counts_all_three_histograms(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
    before = _counts("written", "partial")

    with _calc_stack(handler, fake_session_cm):
        result = await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time())

    assert result.processed_codes == ["phq9"]
    assert _counts("written", "partial") == tuple(value + 1 for value in before)


async def test_empty_outcome_when_nothing_was_written(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult()
    before = _counts("empty", "partial")

    with _calc_stack(handler, fake_session_cm):
        assert await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time()) == CalcRunResult()

    assert _counts("empty", "partial") == tuple(value + 1 for value in before)


async def test_failed_outcome_when_calculation_raises(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.side_effect = RuntimeError("calc blew up")
    before = _counts("failed", "partial")

    with _calc_stack(handler, fake_session_cm):
        # Исключение по-прежнему проглочено: BG-таска не должна валить процесс.
        assert await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time()) == CalcRunResult()

    assert _counts("failed", "partial") == tuple(value + 1 for value in before)


async def test_failed_outcome_when_batch_write_failed(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(failed=1)
    before_failed = _counts("failed", "partial")
    before_empty = _counts("empty", "partial")

    with _calc_stack(handler, fake_session_cm):
        assert await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time()) == CalcRunResult(
            failed=1
        )

    assert _counts("failed", "partial") == tuple(value + 1 for value in before_failed)
    assert _counts("empty", "partial") == before_empty


async def test_failed_outcome_wins_over_written_results(fake_session_cm: AsyncMock) -> None:
    """Часть инструментов записана, часть откатилась — исход `failed`, а не `written`.

    Пин приоритета правил: сбой записи важнее непустого списка записанных инструментов, иначе
    частично сбойный прогон попал бы в те же ряды, по которым смотрят здоровое время пересчёта.
    """

    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1, failed=1)
    before_failed = _counts("failed", "partial")
    before_written = _counts("written", "partial")

    with _calc_stack(handler, fake_session_cm):
        assert await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time()) == CalcRunResult(
            processed_codes=["phq9"], processed=1, failed=1
        )

    assert _counts("failed", "partial") == tuple(value + 1 for value in before_failed)
    assert _counts("written", "partial") == before_written


async def test_full_scope_when_parameter_codes_is_none(fake_session_cm: AsyncMock) -> None:
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
    before_full = _counts("written", "full")
    before_partial = _counts("written", "partial")

    with _calc_stack(handler, fake_session_cm):
        await dispatcher.run_recalc("p1", None, enqueued_at=time.time())

    assert _counts("written", "full") == tuple(value + 1 for value in before_full)
    assert _counts("written", "partial") == before_partial


async def test_command_without_enqueued_at_is_not_measured(fake_session_cm: AsyncMock) -> None:
    """Пути без постановки в очередь (playground, прямые вызовы) не замеряются."""
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
    before = _all_counts()

    with _calc_stack(handler, fake_session_cm):
        assert await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}) == CalcRunResult(
            processed_codes=["phq9"], processed=1
        )

    assert _all_counts() == before


async def test_clock_skew_is_clamped_to_zero(fake_session_cm: AsyncMock) -> None:
    """Отметка «из будущего» (разъехались часы процессов) даёт 0, а не отрицательное значение."""
    handler = AsyncMock()
    handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
    before_bucket = {name: _bucket(name, "written", "partial", "0.05") for name in _WALL_CLOCK_HISTOGRAMS}
    before_sum = {name: _sum(name, "written", "partial") for name in _WALL_CLOCK_HISTOGRAMS}

    with _calc_stack(handler, fake_session_cm):
        await dispatcher.run_recalc("p1", {PARAMETER_CODE_HEIGHT}, enqueued_at=time.time() + 3600)

    for name in _WALL_CLOCK_HISTOGRAMS:
        assert _bucket(name, "written", "partial", "0.05") == before_bucket[name] + 1
        # Сумма не изменилась — записан ровно ноль, а не просто что-то из первой корзины.
        assert _sum(name, "written", "partial") == before_sum[name]


async def test_inline_branch_passes_enqueued_at(monkeypatch: pytest.MonkeyPatch) -> None:
    """При выключенной Kafka пересчёт идёт в этом же процессе — и тоже замеряется."""
    monkeypatch.setattr(dispatcher.settings.kafka, "enabled", False)
    run_mock = AsyncMock()
    monkeypatch.setattr(dispatcher, "run_recalc", run_mock)

    before = time.time()
    await dispatcher.dispatch_recalc("p1", {PARAMETER_CODE_HEIGHT})
    after = time.time()

    assert run_mock.await_args is not None
    assert before <= run_mock.await_args.kwargs["enqueued_at"] <= after


class TestSourceLabel:
    """Разделение пользовательских команд и команд массового прогона.

    Смысл лейбла — в том, что фоновые наблюдения НЕ попадают в ряды, по которым смотрят время
    ответа пациенту: у фоновой команды нет ни ответа, с которого идёт отсчёт, ни ожидающего
    человека, зато очередь она занимает плотнее любого живого трафика.
    """

    async def test_background_command_lands_in_its_own_series(self, fake_session_cm: AsyncMock) -> None:
        handler = AsyncMock()
        handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
        before_background = _counts("written", "full", RECALC_SOURCE_BACKGROUND)
        before_user = _counts("written", "full", RECALC_SOURCE_USER)

        with _calc_stack(handler, fake_session_cm):
            await dispatcher.run_recalc("p1", None, enqueued_at=time.time(), background=True)

        assert _counts("written", "full", RECALC_SOURCE_BACKGROUND) == tuple(v + 1 for v in before_background)
        assert _counts("written", "full", RECALC_SOURCE_USER) == before_user

    async def test_user_command_is_the_default(self, fake_session_cm: AsyncMock) -> None:
        """Признак фоновой обязан приходить явно: команда без него — пользовательская."""
        handler = AsyncMock()
        handler.run.return_value = CalcRunResult(processed_codes=["phq9"], processed=1)
        before_user = _counts("written", "full", RECALC_SOURCE_USER)
        before_background = _counts("written", "full", RECALC_SOURCE_BACKGROUND)

        with _calc_stack(handler, fake_session_cm):
            await dispatcher.run_recalc("p1", None, enqueued_at=time.time())

        assert _counts("written", "full", RECALC_SOURCE_USER) == tuple(v + 1 for v in before_user)
        assert _counts("written", "full", RECALC_SOURCE_BACKGROUND) == before_background


def _runtime(session_cm: AsyncMock) -> SimpleNamespace:
    """Основной рантайм процесса, чья фабрика отдаёт сессию теста."""
    return SimpleNamespace(session_factory=MagicMock(return_value=session_cm))
