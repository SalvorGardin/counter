from src.calc.domain.models import CalculationRequest, normalize_calculation_requests


def test_empty_requests_stay_empty() -> None:
    assert normalize_calculation_requests([]) == []


def test_none_instrument_means_all_allowed() -> None:
    requests = [CalculationRequest(patient_id="p1")]
    assert normalize_calculation_requests(requests) == requests


def test_specific_codes_accumulate_into_set() -> None:
    requests = [
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"})),
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"SCORE2"})),
    ]
    assert normalize_calculation_requests(requests) == [
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT", "SCORE2"}))
    ]


def test_patients_are_independent() -> None:
    requests = [
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"})),
        CalculationRequest(patient_id="p2"),
    ]
    assert normalize_calculation_requests(requests) == requests


def test_specific_after_none_is_dominated_by_none() -> None:
    # Full recalc (None) dominates: a specific-code request arriving after a None one is ignored,
    # because None already allows every instrument. Mirrors test_none_after_specific_overwrites_set.
    requests = [
        CalculationRequest(patient_id="p1"),
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"})),
    ]
    assert normalize_calculation_requests(requests) == [CalculationRequest(patient_id="p1")]


def test_none_after_specific_overwrites_set() -> None:
    requests = [
        CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT"})),
        CalculationRequest(patient_id="p1"),
    ]
    assert normalize_calculation_requests(requests) == [CalculationRequest(patient_id="p1")]
