"""Unit-тесты версии расчёта как артефакта релиза (`src/calc/version.py`).

Версия участвует в сравнении на равенство при выборе когорты пересчёта, поэтому здесь проверяется
не только «читается», но и «отказывает вместо того, чтобы отдать приводимое к строке значение».
"""

import json
from collections.abc import Iterator
from pathlib import Path

import pytest

from src.calc.version import (
    CalculationVersionError,
    calculation_version,
    load_calculation_version,
    require_calculation_version,
)
from src.config import settings
from tests.conftest import LogSink


@pytest.fixture(autouse=True)
def _reset_version_cache() -> Iterator[None]:
    """Версия кэшируется на процесс — сбрасываем кэш вокруг каждого теста, иначе значение
    из одного теста утекло бы в следующий и в остальной набор."""
    calculation_version.cache_clear()
    yield
    calculation_version.cache_clear()


def _write(tmp_path: Path, payload: object) -> Path:
    path = tmp_path / "calculation-version.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def test_repository_version_file_is_readable() -> None:
    """Файл версии лежит в репозитории и едет в образе — без него не стартует ни один процесс,
    который считает риск."""
    assert load_calculation_version(Path(settings.calculation_version_file))


def test_process_reads_version_from_its_configured_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Значение берётся из файла, на который указывает конфигурация процесса."""
    monkeypatch.setattr(settings, "calculation_version_file", str(_write(tmp_path, {"version": "42"})))
    assert calculation_version() == "42"


def test_version_is_read_once_per_process(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Чтение одно на процесс: расчёт зовёт версию на каждую команду, а файл после старта
    контейнера не меняется."""
    path = _write(tmp_path, {"version": "42"})
    monkeypatch.setattr(settings, "calculation_version_file", str(path))
    assert calculation_version() == "42"
    path.write_text(json.dumps({"version": "43"}), encoding="utf-8")
    assert calculation_version() == "42"


def test_missing_file_refuses_startup(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calculation_version_file", str(tmp_path / "absent.json"))
    with pytest.raises(CalculationVersionError):
        require_calculation_version()


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"version": ""},
        {"version": 1},
        {"version": None},
        {"version": " 1"},
        {"version": "1 1"},
        {"version": "x" * 65},
        {"version": "bootstrap"},
        ["1"],
    ],
    ids=[
        "missing",
        "empty",
        "number",
        "null",
        "leading-space",
        "inner-space",
        "too-long",
        "bootstrap-sentinel",
        "not-an-object",
    ],
)
def test_unusable_value_refuses_startup(payload: object, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Приведения к строке нет намеренно: версия `1` и версия `"1"` дали бы когорту, которая то
    пуста, то нет, в зависимости от того, чем её проштамповали."""
    monkeypatch.setattr(settings, "calculation_version_file", str(_write(tmp_path, payload)))
    with pytest.raises(CalculationVersionError):
        require_calculation_version()


def test_broken_json_refuses_startup(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    path = tmp_path / "calculation-version.json"
    path.write_text("{not json", encoding="utf-8")
    monkeypatch.setattr(settings, "calculation_version_file", str(path))
    with pytest.raises(CalculationVersionError):
        require_calculation_version()


def test_refusal_is_alerted_before_the_process_dies(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
) -> None:
    """Исключение на старте видно только в stderr контейнера — сбой релизного артефакта обязан
    попасть и в структурированный лог."""
    monkeypatch.setattr(settings, "calculation_version_file", str(tmp_path / "absent.json"))
    with pytest.raises(CalculationVersionError):
        require_calculation_version()
    assert "calculation version unavailable" in captured_app_logs.messages()
