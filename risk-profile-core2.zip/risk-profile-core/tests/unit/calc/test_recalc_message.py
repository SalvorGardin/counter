"""Unit-тесты контракта команды пересчёта (`src/calc/recalc_message.py`)."""

import pytest

from src.calc.recalc_message import (
    RECALC_MESSAGE_TYPE,
    RecalcMessageError,
    decode_command,
    encode_command,
)
from tests.consts import PARAMETER_CODE_AGE, PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT


def test_encode_full_recalc_uses_null_parameter_codes() -> None:
    msg = encode_command("p1", None)
    assert msg == {
        "clientId": "p1",
        "parameterCodes": None,
        "messageType": RECALC_MESSAGE_TYPE,
        "enqueuedAt": None,
        "background": False,
    }


def test_encode_partial_recalc_sorts_codes() -> None:
    # set неупорядочен — кодируем в отсортированный список (детерминизм + читаемость в логах).
    msg = encode_command("p1", {PARAMETER_CODE_WEIGHT, PARAMETER_CODE_HEIGHT, PARAMETER_CODE_AGE})
    assert msg["parameterCodes"] == [PARAMETER_CODE_AGE, PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT]


def test_encode_keeps_enqueued_at() -> None:
    assert encode_command("p1", None, 1_700_000_000.5)["enqueuedAt"] == 1_700_000_000.5


def test_decode_roundtrip_partial() -> None:
    command = decode_command(encode_command("p1", {"a", "b"}))
    assert command.patient_id == "p1"
    assert command.parameter_codes == {"a", "b"}
    assert command.enqueued_at is None


def test_decode_roundtrip_full() -> None:
    command = decode_command(encode_command("p1", None))
    assert command.patient_id == "p1"
    assert command.parameter_codes is None
    assert command.enqueued_at is None


def test_decode_roundtrip_enqueued_at() -> None:
    assert decode_command(encode_command("p1", {"a"}, 1_700_000_000.5)).enqueued_at == 1_700_000_000.5


def test_decode_missing_parameter_codes_key_means_full_recalc() -> None:
    command = decode_command({"clientId": "p1"})
    assert (command.patient_id, command.parameter_codes, command.enqueued_at) == ("p1", None, None)


@pytest.mark.parametrize(
    "payload",
    [
        "not-an-object",
        ["clientId", "p1"],
        {"parameterCodes": None},  # нет clientId
        {"clientId": ""},  # пустой clientId
        {"clientId": 42},  # clientId не строка
        {"clientId": "p1", "parameterCodes": "height"},  # не список
        {"clientId": "p1", "parameterCodes": [1, 2]},  # элементы не строки
    ],
)
def test_decode_rejects_poison_payload(payload: object) -> None:
    with pytest.raises(RecalcMessageError):
        decode_command(payload)


@pytest.mark.parametrize(
    "raw",
    [
        "123",  # строка
        True,  # bool — подтип int, но не отметка времени
        [1],  # список
        None,  # явный null
        float("nan"),
        float("inf"),
        -1.0,  # отметка раньше эпохи: разность с ней дала бы десятилетия
        0,
    ],
)
def test_decode_invalid_enqueued_at_is_none_and_not_poison(raw: object) -> None:
    # Отметка времени служит только замерам: непригодное значение отбрасываем, но команду
    # пересчёта из-за него не роняем и не пропускаем.
    command = decode_command({"clientId": "p1", "enqueuedAt": raw})
    assert (command.patient_id, command.parameter_codes, command.enqueued_at) == ("p1", None, None)


def test_decode_accepts_integer_enqueued_at() -> None:
    assert decode_command({"clientId": "p1", "enqueuedAt": 1_700_000_000}).enqueued_at == 1_700_000_000.0


def test_encode_marks_a_background_command() -> None:
    assert encode_command("p1", None, background=True)["background"] is True


def test_encode_defaults_to_a_user_command() -> None:
    """Дефолт False: команду без явного признака порождает пользовательский путь, а не прогон."""
    assert encode_command("p1", None)["background"] is False


def test_decode_roundtrip_background() -> None:
    assert decode_command(encode_command("p1", None, background=True)).background is True


def test_decode_missing_background_key_means_user_command() -> None:
    """Отсутствие признака — это пользовательская команда, а не фоновая: так сообщение прошлого
    контракта (и сторонний продюсер) получает приоритетную обработку, а не отбрасывание."""
    assert decode_command({"clientId": "p1"}).background is False


@pytest.mark.parametrize("raw", ["true", 1, 0, None, [], {}], ids=["string", "one", "zero", "null", "list", "dict"])
def test_decode_invalid_background_is_user_command_and_not_poison(raw: object) -> None:
    # Ронять команду клинического пересчёта из-за кривого поля приоритета нельзя.
    command = decode_command({"clientId": "p1", "background": raw})
    assert command.background is False
    assert command.patient_id == "p1"


def test_background_marker_is_dropped_from_a_partial_command() -> None:
    """Фоновая команда всегда полная — на этом держится отсутствие рядов partial × background.
    Частичная команда с признаком пришла не от прогона и считается как пользовательская, а не
    отбрасывается: это команда клинического пересчёта."""
    command = decode_command(encode_command("p1", {"a"}, background=True))
    assert command.background is False
    assert command.parameter_codes == {"a"}


def test_unknown_keys_do_not_break_decoding() -> None:
    """Совместимость вперёд: разбор прошлого контракта игнорирует неизвестные ключи, поэтому
    во время раската воркер прошлой версии посчитает фоновую команду как обычную."""
    payload = encode_command("p1", None, background=True) | {"someFutureKey": {"nested": 1}}
    command = decode_command(payload)
    assert command.patient_id == "p1"
    assert command.parameter_codes is None
