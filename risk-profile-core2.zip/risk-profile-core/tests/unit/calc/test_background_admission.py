"""Политика допуска фоновых команд: матрица «слот × насыщение», ёмкость и счётчики.

Политика тестируется без Kafka и без БД намеренно — она и в проде обязана решать, не обращаясь
ни к тому, ни к другому: решение принимается на каждое сообщение и стоит микросекунды.
"""

import pytest
from prometheus_client import REGISTRY

from src.calc.background_admission import BackgroundAdmission
from src.metrics import (
    BACKGROUND_ADMITTED,
    BACKGROUND_DROPPED,
    BACKGROUND_REASON_NO_SLOT,
    BACKGROUND_REASON_NONE,
    BACKGROUND_REASON_RATE_LIMITED,
    BACKGROUND_REASON_SATURATED,
    SERVICE_PREFIX,
)

_COUNTER = f"{SERVICE_PREFIX}_recalc_background_commands_total"


def _policy(capacity: int = 1, *, saturated: bool = False) -> BackgroundAdmission:
    return BackgroundAdmission(capacity, is_saturated=lambda: saturated)


class _Clock:
    """Управляемые монотонные часы: граница интервала проверяется без реального ожидания."""

    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


def _counter(decision: str, reason: str) -> float:
    value = REGISTRY.get_sample_value(_COUNTER, {"decision": decision, "reason": reason})
    return value or 0.0


class TestDecisionMatrix:
    @pytest.mark.parametrize(
        ("capacity", "saturated", "expected"),
        [
            (1, False, True),
            (0, False, False),
            (1, True, False),
            (0, True, False),
        ],
        ids=["slot-and-healthy", "no-slot", "saturated", "neither"],
    )
    def test_command_runs_only_with_a_free_slot_and_a_healthy_service(
        self, capacity: int, saturated: bool, expected: bool
    ) -> None:
        with _policy(capacity, saturated=saturated).admit() as admitted:
            assert admitted is expected

    def test_saturation_is_reported_as_the_reason_even_with_a_free_slot(self) -> None:
        """Насыщение объясняет отказ полнее занятого слота, который при насыщении и так не
        освободится быстро."""
        assert _policy(1, saturated=True).refusal_reason() == BACKGROUND_REASON_SATURATED

    def test_saturation_is_asked_at_decision_time(self) -> None:
        """Признак насыщения меняется между командами — политика обязана спрашивать его в момент
        решения, а не помнить значение со старта процесса."""
        saturated = False
        policy = BackgroundAdmission(1, is_saturated=lambda: saturated)
        assert policy.refusal_reason() is None

        saturated = True

        assert policy.refusal_reason() == BACKGROUND_REASON_SATURATED


class TestCapacity:
    def test_capacity_is_an_absolute_number_of_simultaneous_commands(self) -> None:
        policy = _policy(2)
        with policy.admit() as first, policy.admit() as second, policy.admit() as third:
            assert (first, second, third) == (True, True, False)

    def test_slot_returns_after_the_command(self) -> None:
        policy = _policy(1)
        with policy.admit():
            pass

        assert policy.in_flight == 0
        with policy.admit() as admitted:
            assert admitted is True

    def test_slot_returns_after_a_crash(self) -> None:
        policy = _policy(1)
        with pytest.raises(RuntimeError), policy.admit():
            raise RuntimeError("boom")

        assert policy.in_flight == 0

    def test_zero_capacity_closes_background_entirely(self) -> None:
        with _policy(0).admit() as admitted:
            assert admitted is False

    def test_refused_command_takes_no_slot(self) -> None:
        """Отказ не должен тратить ёмкость: иначе завал отброшенных команд закрыл бы фон совсем."""
        policy = _policy(0)
        with policy.admit():
            pass

        assert policy.in_flight == 0


class TestObservability:
    def test_admitted_and_dropped_commands_are_counted_by_reason(self) -> None:
        """Счётчики — авторитетный признак того, сделал ли прогон работу: размер когорты
        уменьшает и пользовательский трафик, а эти ряды растут только от команд прогона."""
        before = {
            "admitted": _counter(BACKGROUND_ADMITTED, BACKGROUND_REASON_NONE),
            "no_slot": _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_NO_SLOT),
            "saturated": _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_SATURATED),
        }

        with _policy(1).admit():
            pass
        with _policy(0).admit():
            pass
        with _policy(1, saturated=True).admit():
            pass

        assert _counter(BACKGROUND_ADMITTED, BACKGROUND_REASON_NONE) == before["admitted"] + 1
        assert _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_NO_SLOT) == before["no_slot"] + 1
        assert _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_SATURATED) == before["saturated"] + 1


class TestRateCeiling:
    """Верхняя граница ТЕМПА фоновых команд — вторая величина рядом с ёмкостью.

    Ёмкость ограничивает одновременность: при capacity=1 короткие пересчёты идут вплотную друг
    за другом и выбирают пропускную способность базы и внешнего сервиса, не выходя за один слот.
    Интервал ограничивает именно частоту их начала.
    """

    @staticmethod
    def _policy(clock: "_Clock", *, interval: float = 10.0, capacity: int = 1) -> BackgroundAdmission:
        return BackgroundAdmission(capacity, is_saturated=lambda: False, min_interval_seconds=interval, clock=clock)

    def test_first_command_is_admitted_without_waiting(self) -> None:
        """Интервал ограничивает темп, а не отодвигает старт прогона."""
        with self._policy(_Clock()).admit() as admitted:
            assert admitted is True

    def test_next_command_inside_the_interval_is_dropped(self) -> None:
        clock = _Clock()
        policy = self._policy(clock)
        with policy.admit():
            pass

        clock.now += 9.9
        with policy.admit() as admitted:
            assert admitted is False
        assert policy.refusal_reason() == BACKGROUND_REASON_RATE_LIMITED

    def test_command_after_the_interval_is_admitted(self) -> None:
        clock = _Clock()
        policy = self._policy(clock)
        with policy.admit():
            pass

        clock.now += 10.0
        with policy.admit() as admitted:
            assert admitted is True

    def test_interval_is_measured_from_the_start_of_the_previous_command(self) -> None:
        """Отсчёт от начала, а не от завершения: темп обращений к базе и внешнему сервису не
        должен зависеть от того, сколько длился предыдущий расчёт."""
        clock = _Clock()
        policy = self._policy(clock)
        with policy.admit():
            clock.now += 10.0  # сам расчёт занял весь интервал

        with policy.admit() as admitted:
            assert admitted is True

    def test_dropped_command_does_not_move_the_window(self) -> None:
        """Окно двигает только допущенная команда: иначе плотный поток отброшенных отодвигал бы
        границу сам от себя и закрывал фон навсегда."""
        clock = _Clock()
        policy = self._policy(clock)
        with policy.admit():
            pass

        clock.now += 5.0
        with policy.admit() as admitted:
            assert admitted is False
        clock.now += 5.0
        with policy.admit() as admitted:
            assert admitted is True

    def test_zero_interval_leaves_only_the_capacity_limit(self) -> None:
        clock = _Clock()
        policy = self._policy(clock, interval=0.0)
        with policy.admit():
            pass
        with policy.admit() as admitted:
            assert admitted is True

    def test_saturation_and_no_slot_are_reported_before_the_rate_ceiling(self) -> None:
        """Темп — самая мимолётная причина: назвать её, когда есть другая, значило бы спрятать ту."""
        clock = _Clock()
        saturated = BackgroundAdmission(1, is_saturated=lambda: True, min_interval_seconds=10.0, clock=clock)
        with saturated.admit():
            pass
        assert saturated.refusal_reason() == BACKGROUND_REASON_SATURATED

        busy = self._policy(clock, capacity=1)
        with busy.admit():
            assert busy.refusal_reason() == BACKGROUND_REASON_NO_SLOT

    def test_rate_limited_drop_is_counted_with_its_own_reason(self) -> None:
        clock = _Clock()
        policy = self._policy(clock)
        with policy.admit():
            pass
        before = _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_RATE_LIMITED)

        with policy.admit():
            pass

        assert _counter(BACKGROUND_DROPPED, BACKGROUND_REASON_RATE_LIMITED) == before + 1
