"""Контракт коллектора статусов: выключенный флаг, изоляция записи.

БД здесь не нужна: проверяется поведение вокруг запроса (пойдёт ли он вообще, что будет с
ошибкой), а не сам SQL. Фабрика сессий подменяется заглушкой, которая либо запрещает обращение,
либо имитирует нужный ответ драйвера. Запись настоящих строк — в
tests/integration/calc/test_status_collection.py.
"""

import logging
from types import SimpleNamespace
from typing import Any

import pytest
from sqlalchemy.exc import ProgrammingError

from src.calc.domain.models import CalcReasonCode, CalcRejection
from src.calc.status_collector import CalcStatusCollector
from src.config import settings
from tests.conftest import LogSink

PATIENT = "p1"


@pytest.fixture
def collection_on(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)


@pytest.fixture
def collection_off(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)


class _ForbiddenFactory:
    """Фабрика сессий, обращение к которой — провал теста."""

    def __call__(self) -> Any:
        raise AssertionError("при выключенном сборе сессия создаваться не должна")


class _RecordingSession:
    """Сессия, запоминающая выполненные стейтменты; execute может быть настроен на ошибку."""

    def __init__(self, error: Exception | None = None) -> None:
        self.error = error
        self.executed: list[Any] = []
        self.committed = False

    async def __aenter__(self) -> "_RecordingSession":
        return self

    async def __aexit__(self, *exc: object) -> bool:
        return False

    async def execute(self, statement: Any, params: Any = None) -> None:
        self.executed.append((statement, params))
        if self.error is not None:
            raise self.error

    async def commit(self) -> None:
        self.committed = True


class _RecordingFactory:
    def __init__(self, error: Exception | None = None) -> None:
        self.error = error
        self.sessions: list[_RecordingSession] = []

    def __call__(self) -> _RecordingSession:
        session = _RecordingSession(self.error)
        self.sessions.append(session)
        return session


def _undefined_table_error() -> ProgrammingError:
    """`ProgrammingError` с SQLSTATE 42P01 — так его отдаёт asyncpg через SQLAlchemy."""
    return ProgrammingError("stmt", {}, SimpleNamespace(sqlstate="42P01"))  # ty: ignore[invalid-argument-type]


def _other_programming_error() -> ProgrammingError:
    return ProgrammingError("stmt", {}, SimpleNamespace(sqlstate="42703"))  # ty: ignore[invalid-argument-type]


class TestDisabledFlag:
    async def test_nothing_is_collected_and_no_session_is_opened(self, collection_off: None) -> None:
        collector = CalcStatusCollector(session_factory=_ForbiddenFactory())  # ty: ignore[invalid-argument-type]
        collector.record_calculated(PATIENT, "bcrat")
        collector.record_rejection(PATIENT, "stai", CalcRejection(reason_code=CalcReasonCode.PREGNANT))
        # Ни строки в памяти — при выключенном сборе не собирается вообще ничего.
        assert collector.pending() == {}
        await collector.flush_patient(PATIENT)  # сессия не открывается, иначе фабрика упадёт

    async def test_enabling_the_flag_starts_collection_without_restart(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        collector.record_calculated(PATIENT, "bcrat")
        await collector.flush_patient(PATIENT)
        assert len(factory.sessions) == 1
        assert factory.sessions[0].committed is True


class TestFirstWriteWins:
    async def test_specific_reason_is_not_overwritten_by_a_generic_one(self, collection_on: None) -> None:
        collector = CalcStatusCollector(session_factory=_RecordingFactory())  # ty: ignore[invalid-argument-type]
        collector.record_rejection(PATIENT, "airi_ssz", CalcRejection(reason_code=CalcReasonCode.CVD_ERROR))
        collector.record_rejection(PATIENT, "airi_ssz", CalcRejection(reason_code=CalcReasonCode.CALCULATION_ERROR))
        collector.record_calculated(PATIENT, "airi_ssz")
        assert collector.pending()[(PATIENT, "airi_ssz")]["reason_code"] == CalcReasonCode.CVD_ERROR.value


class TestPatientIsolation:
    async def test_flush_writes_only_the_requested_patient(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        collector.record_calculated("p1", "bcrat")
        collector.record_calculated("p2", "bcrat")
        await collector.flush_patient("p1")
        _statement, rows = factory.sessions[0].executed[0]
        assert [row["patient_id"] for row in rows] == ["p1"]
        assert set(collector.pending()) == {("p2", "bcrat")}

    async def test_discarded_patient_is_never_written(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        collector.record_calculated(PATIENT, "bcrat")
        collector.discard_patient(PATIENT)
        await collector.flush_patient(PATIENT)
        assert factory.sessions == []


class TestDeleteForInstruments:
    """Чистка статусов после risk-event удаления results (см. RiskEventService)."""

    async def test_nothing_is_deleted_when_disabled(self, collection_off: None) -> None:
        collector = CalcStatusCollector(session_factory=_ForbiddenFactory())  # ty: ignore[invalid-argument-type]
        await collector.delete_for_instruments(PATIENT, ["bcrat"])  # сессия не открывается

    async def test_empty_instrument_list_opens_no_session(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        await collector.delete_for_instruments(PATIENT, [])
        assert factory.sessions == []

    async def test_delete_statement_is_executed_and_committed(self, collection_on: None) -> None:
        factory = _RecordingFactory()
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]
        await collector.delete_for_instruments(PATIENT, ["bcrat", "stai"])
        assert len(factory.sessions) == 1
        assert factory.sessions[0].committed is True
        assert len(factory.sessions[0].executed) == 1

    async def test_database_error_is_logged_without_raising(
        self, collection_on: None, captured_app_logs: LogSink
    ) -> None:
        factory = _RecordingFactory(error=_undefined_table_error())
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]

        await collector.delete_for_instruments(PATIENT, ["bcrat"])  # не должно бросить исключение

        errors = [record for record in captured_app_logs.records if record.levelno >= logging.ERROR]
        assert len(errors) == 1
        assert collector.enabled is True


class TestErrorsDoNotDisableCollection:
    async def test_repeated_database_errors_are_logged_each_time(
        self, collection_on: None, captured_app_logs: LogSink
    ) -> None:
        """Сбой записи — не событие уровня процесса: он логируется на каждую попытку.

        Пересчёт при этом не падает — записать статусы уже некуда, а результаты пациента
        закоммичены.
        """
        factory = _RecordingFactory(error=_other_programming_error())
        collector = CalcStatusCollector(session_factory=factory)  # ty: ignore[invalid-argument-type]

        collector.record_calculated(PATIENT, "bcrat")
        await collector.flush_patient(PATIENT)
        collector.record_calculated(PATIENT, "bcrat")
        await collector.flush_patient(PATIENT)

        errors = [record for record in captured_app_logs.records if record.levelno >= logging.ERROR]
        assert len(errors) == 2
        assert len(factory.sessions) == 2
