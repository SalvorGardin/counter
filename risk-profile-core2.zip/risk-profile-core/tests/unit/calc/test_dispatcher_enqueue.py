"""Unit-тесты enqueue-ветки `dispatch_recalc`: публикация команды в Kafka.

Контракт: при включённой Kafka диспетчер кладёт команду в топик recalc_commands и НЕ считает
в этом процессе. Если Kafka включена, но опубликовать команду нельзя (продюсер не поднят или
publish упал) — поднимает `alert()` и НЕ деградирует на синхронный `run_recalc`. Синхронный расчёт
остаётся только для намеренно выключенной Kafka (`kafka.enabled=False`).
"""

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

import src.calc.dispatcher as dispatcher
from src.infra.kafka.exceptions import KafkaInitError, KafkaPublishError
from tests.consts import PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT


@pytest.fixture
def kafka_enabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dispatcher.settings.kafka, "enabled", True)


@pytest.fixture
def no_run_recalc(monkeypatch: pytest.MonkeyPatch) -> AsyncMock:
    """Подменяет тяжёлый run_recalc — проверяем только маршрутизацию enqueue vs inline."""
    run_mock = AsyncMock()
    monkeypatch.setattr(dispatcher, "run_recalc", run_mock)
    return run_mock


async def test_publishes_command_and_skips_inline_when_kafka_enabled(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    producer = AsyncMock()
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)

    await dispatcher.dispatch_recalc("p1", {PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT})

    producer.send.assert_awaited_once()
    kwargs = producer.send.await_args.kwargs
    assert kwargs["topic"] == dispatcher.settings.kafka.topics.recalc_commands
    assert kwargs["key"] == "p1"
    assert kwargs["value"]["clientId"] == "p1"
    assert kwargs["value"]["parameterCodes"] == [PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT]
    assert kwargs["value"]["messageType"] == "recalc"
    # Расчёт НЕ выполняется в этом процессе — его сделает consumer-воркер.
    no_run_recalc.assert_not_awaited()


async def test_full_recalc_publishes_null_parameter_codes(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    producer = AsyncMock()
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)

    await dispatcher.dispatch_recalc("p1", None)

    assert producer.send.await_args.kwargs["value"]["parameterCodes"] is None
    no_run_recalc.assert_not_awaited()


async def test_alerts_and_no_inline_when_producer_unavailable(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise() -> None:
        raise KafkaInitError("producer not started")

    monkeypatch.setattr(dispatcher, "get_kafka_producer", _raise)
    alert_mock = MagicMock()
    monkeypatch.setattr(dispatcher, "alert", alert_mock)

    await dispatcher.dispatch_recalc("p1", {"x"})

    # Поднимаем alert и НЕ деградируем на синхронный пересчёт.
    alert_mock.assert_called_once()
    no_run_recalc.assert_not_awaited()


async def test_alerts_and_no_inline_on_publish_error(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    producer = AsyncMock()
    producer.send.side_effect = KafkaPublishError("boom", topic="t")
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)
    alert_mock = MagicMock()
    monkeypatch.setattr(dispatcher, "alert", alert_mock)

    await dispatcher.dispatch_recalc("p1", None)

    # Публикация упала — поднимаем alert, команда теряется, inline не считаем.
    alert_mock.assert_called_once()
    no_run_recalc.assert_not_awaited()


async def test_empty_parameter_codes_is_noop(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    producer = AsyncMock()
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)

    await dispatcher.dispatch_recalc("p1", set())

    producer.send.assert_not_awaited()
    no_run_recalc.assert_not_awaited()


async def test_inline_when_kafka_disabled(no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch) -> None:
    # kafka.enabled=False (дефолт) — продюсер даже не запрашивается.
    monkeypatch.setattr(dispatcher.settings.kafka, "enabled", False)
    producer = AsyncMock()
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)

    await dispatcher.dispatch_recalc("p1", None)

    producer.send.assert_not_awaited()
    assert no_run_recalc.await_args is not None
    args, kwargs = no_run_recalc.await_args
    assert args == ("p1", None)
    assert kwargs["catalogs"] is None
    # Инлайн-пересчёт идёт под логином расчёта, а не под профильным рантаймом API-процесса.
    assert kwargs["session_factory"] is dispatcher.init_calculation_runtime().session_factory


async def test_published_command_carries_enqueued_at(
    kafka_enabled: None, no_run_recalc: AsyncMock, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Отметку ставит продюсер в момент публикации — по ней воркер считает ожидание в очереди.
    producer = AsyncMock()
    monkeypatch.setattr(dispatcher, "get_kafka_producer", lambda: producer)

    before = time.time()
    await dispatcher.dispatch_recalc("p1", {PARAMETER_CODE_HEIGHT})
    after = time.time()

    assert before <= producer.send.await_args.kwargs["value"]["enqueuedAt"] <= after
