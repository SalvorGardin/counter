"""Гейт опросников — счёт X/Y в вопросах системы, применимых пациенту.

Тесты собирают ту же композицию,
что и рабочий путь: `build_question_classifier` (граница calc, перевод в classify_question
Risk-profile) + `count_questions_by_instrument` (домен) — семантика классификации проверяется
по-настоящему, без стабов. Даты рождения строятся от «сегодня», чтобы возрастные границы
не поехали со временем.
"""

from datetime import UTC, date, datetime

from src.calc.domain.eligibility import QuestionCounts, count_questions_by_instrument
from src.calc.domain.models import PatientParameterRow
from src.calc.infra.reader import active_parameters_by_patient, build_question_classifier
from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.models import ConditionView
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER

_TODAY = date(2026, 8, 3)
_FUTURE = datetime(2099, 1, 1, tzinfo=UTC)

# (type, parameter_code, value, min_age, max_age) — _count подставит question_code из ключа.
_Condition = tuple[str, str, str | None, int | None, int | None]


def _birthdate(age: int) -> str:
    """ISO-дата рождения, дающая ровно `age` полных лет на _TODAY."""
    return _TODAY.replace(year=_TODAY.year - age).isoformat()


def _active(**values: str) -> dict[str, ActiveParameter]:
    return {
        code: ActiveParameter(
            parameter_code=code,
            value=value,
            expiration_date=_FUTURE,
            date_time=_FUTURE,
            patient_parameter_id=0,
        )
        for code, value in values.items()
    }


def _except(parameter_code: str, value: str) -> _Condition:
    return ("except", parameter_code, value, None, None)


def _age(min_age: int, max_age: int) -> _Condition:
    return ("age", PARAMETER_CODE_AGE, None, min_age, max_age)


def _count(
    *,
    question_codes_by_instrument: dict[str, frozenset[str]],
    params_by_question: dict[str, frozenset[str]],
    conditions_by_question: dict[str, tuple[_Condition, ...]] | None = None,
    active_parameters: dict[str, ActiveParameter],
) -> dict[str, QuestionCounts]:
    views_by_question = {
        question_code: tuple(
            ConditionView(type=t, parameter_code=p, value=v, min_age=min_age, max_age=max_age)
            for (t, p, v, min_age, max_age) in conditions
        )
        for question_code, conditions in (conditions_by_question or {}).items()
    }
    return count_questions_by_instrument(
        question_codes_by_instrument=question_codes_by_instrument,
        params_by_question=params_by_question,
        answered_param_codes=set(active_parameters),
        classify=build_question_classifier(views_by_question, active_parameters, _TODAY),
    )


def test_question_of_the_other_gender_is_excluded_from_both_x_and_y():
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0430", "sq_0440"})},
        params_by_question={"sq_0430": frozenset({"sti_history"}), "sq_0440": frozenset({"abnormal_discharge"})},
        conditions_by_question={"sq_0430": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),)},
        active_parameters=_active(gender=GENDER_MALE, abnormal_discharge="Нет"),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=1, progressed=1)


def test_gender_except_of_the_opposite_sex_keeps_question_applicable():
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0350"})},
        params_by_question={"sq_0350": frozenset({"elevated_psa"})},
        conditions_by_question={"sq_0350": (_except(PARAMETER_CODE_GENDER, GENDER_FEMALE),)},
        active_parameters=_active(gender=GENDER_MALE),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=1, progressed=0)


def test_question_out_of_age_range_is_excluded_from_both_x_and_y():
    conditions: dict[str, tuple[_Condition, ...]] = {"sq_0350": (_age(45, 100),)}
    params = {"sq_0350": frozenset({"elevated_psa"})}
    instruments = {"form_reprod": frozenset({"sq_0350"})}

    young = _count(
        question_codes_by_instrument=instruments,
        params_by_question=params,
        conditions_by_question=conditions,
        active_parameters=_active(birthdate=_birthdate(30), elevated_psa="Нет"),
    )
    in_range = _count(
        question_codes_by_instrument=instruments,
        params_by_question=params,
        conditions_by_question=conditions,
        active_parameters=_active(birthdate=_birthdate(50), elevated_psa="Нет"),
    )

    assert young["form_reprod"] == QuestionCounts(applicable=0, progressed=0)
    assert in_range["form_reprod"] == QuestionCounts(applicable=1, progressed=1)


def test_question_without_birthdate_is_excluded_from_x():
    """Возраст неизвестен → возрастное условие не проходит (как в заполненности Risk-profile)."""
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0350"})},
        params_by_question={"sq_0350": frozenset({"elevated_psa"})},
        conditions_by_question={"sq_0350": (_age(45, 100),)},
        active_parameters=_active(elevated_psa="Нет"),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=0, progressed=0)


def test_hidden_question_is_auto_credited():
    """Пин авто-зачёта: `except` с parameter_code != gender сработал → вопрос в X и в Y без ответа."""
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0010"})},
        params_by_question={"sq_0010": frozenset({"breast_cancer", "repro_f_cancer"})},
        conditions_by_question={"sq_0010": (_except("cancer", "Нет"),)},
        active_parameters=_active(cancer="Нет"),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=1, progressed=1)


def test_gender_age_and_branch_except_combined_on_one_question():
    """Комбо всех трёх видов условий на одном вопросе — реальный кейс сида (sq_0390/0400/0420:
    `except:gender` + `age` + `except:regular_menses_menopause`).

    Женщина 40 лет: gender-except (Мужской) не срабатывает, возраст в диапазоне — вопрос в X;
    сработавший branch-except (менопауза наступила) даёт авто-зачёт в Y без ответа.
    """
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0390"})},
        params_by_question={"sq_0390": frozenset({"painful_menses"})},
        conditions_by_question={
            "sq_0390": (
                _except(PARAMETER_CODE_GENDER, GENDER_MALE),
                _age(1, 55),
                _except("regular_menses_menopause", "Наступила менопауза"),
            )
        },
        active_parameters=_active(
            gender=GENDER_FEMALE, birthdate=_birthdate(40), regular_menses_menopause="Наступила менопауза"
        ),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=1, progressed=1)


def test_gender_exclusion_beats_branch_except_auto_credit():
    """То же комбо у мужчины: gender-except срабатывает → вопрос вне X, авто-зачёт не спасает."""
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0390"})},
        params_by_question={"sq_0390": frozenset({"painful_menses"})},
        conditions_by_question={
            "sq_0390": (
                _except(PARAMETER_CODE_GENDER, GENDER_MALE),
                _age(1, 55),
                _except("regular_menses_menopause", "Наступила менопауза"),
            )
        },
        active_parameters=_active(
            gender=GENDER_MALE, birthdate=_birthdate(40), regular_menses_menopause="Наступила менопауза"
        ),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=0, progressed=0)


def test_except_condition_on_unanswered_parameter_is_neither_hidden_nor_answered():
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0010"})},
        params_by_question={"sq_0010": frozenset({"breast_cancer", "repro_f_cancer"})},
        conditions_by_question={"sq_0010": (_except("cancer", "Нет"),)},
        active_parameters=_active(gender=GENDER_MALE),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=1, progressed=0)


def test_multi_parameter_question_answered_partially_is_not_progressed():
    """«Отвечен» = ВСЕ option-параметры вопроса, включая те, что не входят в этот инструмент."""
    params_by_question = {"sq_1210": frozenset({"extreme_sport_estet", "extreme_sport_speed", "no_sports"})}
    instruments = {"form_reprod": frozenset({"sq_1210"})}

    partial = _count(
        question_codes_by_instrument=instruments,
        params_by_question=params_by_question,
        active_parameters=_active(extreme_sport_estet="Да", extreme_sport_speed="Нет"),
    )
    full = _count(
        question_codes_by_instrument=instruments,
        params_by_question=params_by_question,
        active_parameters=_active(extreme_sport_estet="Да", extreme_sport_speed="Нет", no_sports="Нет"),
    )

    assert partial["form_reprod"] == QuestionCounts(applicable=1, progressed=0)
    assert full["form_reprod"] == QuestionCounts(applicable=1, progressed=1)


def test_skipped_question_counts_as_answered():
    """isSkipped сохраняется пустой строкой — запись есть, значит вопрос отвечен."""
    counts = _count(
        question_codes_by_instrument={"form_gi": frozenset({"sq_0630"})},
        params_by_question={"sq_0630": frozenset({"helicobacter_pylori_history"})},
        active_parameters=_active(helicobacter_pylori_history=""),
    )
    assert counts["form_gi"] == QuestionCounts(applicable=1, progressed=1)


def test_question_shared_by_two_instruments_counts_in_each():
    """Пин: вопрос, чьи параметры входят в несколько инструментов, участвует в X/Y каждого."""
    counts = _count(
        question_codes_by_instrument={
            "form_gi": frozenset({"sq_1150", "sq_0630"}),
            "form_blood": frozenset({"sq_1150"}),
        },
        params_by_question={"sq_1150": frozenset({"food"}), "sq_0630": frozenset({"helicobacter_pylori_history"})},
        active_parameters=_active(food="Да"),
    )
    assert counts["form_gi"] == QuestionCounts(applicable=2, progressed=1)
    assert counts["form_blood"] == QuestionCounts(applicable=1, progressed=1)


def test_instrument_without_applicable_questions_yields_zero_denominator():
    """Пин X = 0: все вопросы инструмента отсеяны по полу — знаменателя нет (решение — за гейтом)."""
    counts = _count(
        question_codes_by_instrument={"form_reprod": frozenset({"sq_0430", "sq_0450"})},
        params_by_question={"sq_0430": frozenset({"sti_history"}), "sq_0450": frozenset({"regular_gyn_checkup"})},
        conditions_by_question={
            "sq_0430": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),),
            "sq_0450": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),),
        },
        active_parameters=_active(gender=GENDER_MALE),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=0, progressed=0)


def test_reprod_repro_case_of_issue_190():
    """Мужчина 50 лет полностью прошёл form_reprod: X=6, Y=6 (раньше 6/16 параметров = 0.375)."""
    counts = _count(
        question_codes_by_instrument={
            "form_reprod": frozenset(
                {
                    "sq_0010",  # ЗНО-локализации — скрыт `except cancer=Нет`
                    "sq_0350",  # ПСА — мужской, 45–100
                    "sq_0360",  # женские
                    "sq_0390",
                    "sq_0400",
                    "sq_0410",
                    "sq_0420",
                    "sq_0430",
                    "sq_0450",
                    "sq_0440",  # бесполые
                    "sq_1080",
                    "sq_1150",
                    "sq_1210",
                }
            )
        },
        params_by_question={
            "sq_0010": frozenset({"breast_cancer", "repro_f_cancer", "repro_m_cancer"}),
            "sq_0350": frozenset({"elevated_psa"}),
            "sq_0360": frozenset({"regular_menses", "regular_menses_menopause"}),
            "sq_0390": frozenset({"painful_menses"}),
            "sq_0400": frozenset({"intermenstrual_spotting"}),
            "sq_0410": frozenset({"pelvic_inflammatory_disease"}),
            "sq_0420": frozenset({"infertility_over_1_year"}),
            "sq_0430": frozenset({"sti_history"}),
            "sq_0440": frozenset({"abnormal_discharge"}),
            "sq_0450": frozenset({"regular_gyn_checkup"}),
            "sq_1080": frozenset({"smoking"}),
            "sq_1150": frozenset({"food"}),
            "sq_1210": frozenset({"extreme_sport_estet"}),
        },
        conditions_by_question={
            "sq_0010": (_except("cancer", "Нет"),),
            "sq_0350": (_except(PARAMETER_CODE_GENDER, GENDER_FEMALE), _age(45, 100)),
            "sq_0360": (_except(PARAMETER_CODE_GENDER, GENDER_MALE), _age(1, 55)),
            "sq_0390": (_except(PARAMETER_CODE_GENDER, GENDER_MALE), _age(1, 55)),
            "sq_0400": (_except(PARAMETER_CODE_GENDER, GENDER_MALE), _age(1, 55)),
            "sq_0410": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),),
            "sq_0420": (_except(PARAMETER_CODE_GENDER, GENDER_MALE), _age(1, 49)),
            "sq_0430": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),),
            "sq_0450": (_except(PARAMETER_CODE_GENDER, GENDER_MALE),),
        },
        active_parameters=_active(
            gender=GENDER_MALE,
            birthdate=_birthdate(50),
            cancer="Нет",
            elevated_psa="Нет",
            abnormal_discharge="Нет",
            smoking="Нет",
            food="Да",
            extreme_sport_estet="Нет",
        ),
    )
    assert counts["form_reprod"] == QuestionCounts(applicable=6, progressed=6)


def test_active_parameters_grouped_by_patient_skip_null_values():
    rows = [
        PatientParameterRow(1, "p1", "smoking", "Да", "test", _FUTURE, _FUTURE),
        PatientParameterRow(2, "p1", "food", "", "test", _FUTURE, _FUTURE),
        PatientParameterRow(3, "p2", "smoking", None, "test", _FUTURE, _FUTURE),
    ]

    grouped = active_parameters_by_patient(rows)

    assert grouped["p1"].keys() == {"smoking", "food"}
    assert grouped["p1"]["food"].value == ""  # пропуск — это ответ
    assert "p2" not in grouped  # NULL-значение — не ответ


def test_no_instruments_yields_empty_result():
    assert _count(question_codes_by_instrument={}, params_by_question={}, active_parameters={}) == {}
