import asyncio
import dataclasses
import io
import logging
import os
import secrets
from collections.abc import AsyncGenerator, Generator, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING
from unittest.mock import patch

import pytest
import pytest_asyncio
from alembic import command
from alembic.config import Config
from pydantic import SecretStr
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, AsyncSession, create_async_engine

from src.infra.db_schemas import (
    CALCULATION_SCHEMA,
    CALCULATION_SCHEMA_MAP,
    CALCULATION_TABLES,
    CATALOG_SCHEMA,
    EHR_SCHEMA,
    EHR_SCHEMA_MAP,
    MIGRATION_ROLE,
    PROFILE_SCHEMA,
    PROFILE_SCHEMA_MAP,
    PROFILE_TABLES,
)
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_GENDER
from tests.postgres import postgres_server

if TYPE_CHECKING:
    from src.infra.catalog.calc import CalcCatalog
    from src.infra.catalog.http import HttpCatalog
    from src.infra.catalog.interpretation import InterpretationCatalog
    from src.infra.database import DatabaseRuntime
    from tests.db_assertions import DbRead
    from tests.factories import Factory


class LogSink(logging.StreamHandler):
    """Записи, прошедшие реальный MonologFilter + FingersCrossedHandler."""

    def __init__(self, formatter: logging.Formatter | None) -> None:
        self._buffer = io.StringIO()
        super().__init__(self._buffer)
        self.setFormatter(formatter)
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)
        super().emit(record)

    def messages(self) -> list[str]:
        return [record.getMessage() for record in self.records]

    def context_of(self, message: str) -> dict[str, object]:
        record = next(record for record in self.records if record.getMessage() == message)
        context = getattr(record, "log_context", {})
        return context if isinstance(context, dict) else {}

    def output(self) -> str:
        """Отформатированный JSON-вывод, который вместо stdout получил sink."""
        return self._buffer.getvalue()


# Заглушка строк подключения всех ролей: основной рантайм процесса поднимает фикстура
# `primary_runtime` (движок ленивый, get_session в тестах подменяется — сюда никто не коннектится).
_DUMMY_DB_URL = "postgresql+asyncpg://test:test@localhost:5432/test"

_TEST_API_KEY = secrets.token_hex(16)
# Ключ ручки перезапуска — ОТДЕЛЬНЫЙ от тестового: тестовый отдаётся браузеру опросника,
# и общий ключ означал бы, что перезапуск процессов доступен всем, кто открыл страницу.
_RESTARTER_API_KEY = secrets.token_hex(16)

# Capture real value before setdefault so the skip decision reflects actual env.
_TESTING_API_ENABLED = os.environ.get("RISK_MODEL_TESTING_API_ENABLED", "").lower() == "true"

_DB_FIXTURES = frozenset({"migration_container", "postgres_url", "runtime_db_urls"})

# Прогон идёт с выключенной Kafka, то есть в инлайн-режиме пересчёта — а он требует и URL логина
# расчёта. Тесты, которым нужен настоящий инлайн-пересчёт, подменяют рантайм на логин расчёта стенда.
for _db_url_env in (
    "RISK_MODEL_PROFILE_DB_URL",
    "RISK_MODEL_CALCULATION_DB_URL",
    "RISK_MODEL_EHR_DB_URL",
    "RISK_MODEL_BULK_RECALC_DB_URL",
    "RISK_MODEL_MIGRATIONS_DB_URL",
):
    os.environ.setdefault(_db_url_env, _DUMMY_DB_URL)
os.environ.setdefault("RISK_MODEL_TESTING_API_ENABLED", "true")
os.environ["RISK_MODEL_TEST_API_KEY"] = _TEST_API_KEY
os.environ["RISK_MODEL_RESTARTER__API_KEY"] = _RESTARTER_API_KEY


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    for item in items:
        fixture_names = getattr(item, "fixturenames", ())
        if _DB_FIXTURES.intersection(fixture_names) and item.get_closest_marker("db") is None:
            item.add_marker(pytest.mark.db)

    if _TESTING_API_ENABLED:
        return
    skip = pytest.mark.skip(reason="RISK_MODEL_TESTING_API_ENABLED is not set to true")
    for item in items:
        if item.get_closest_marker("test_internal"):
            item.add_marker(skip)


@pytest.fixture(scope="session")
def _profile_database_runtime() -> "DatabaseRuntime":
    """Один ленивый движок профиля на прогон: без запроса он не соединяется, а создавать его на
    каждый тест — лишняя работа."""
    from src.config import ServiceRuntime  # noqa: PLC0415
    from src.infra.database import RUNTIME_IDENTITIES, create_database_runtime  # noqa: PLC0415

    return create_database_runtime(RUNTIME_IDENTITIES[ServiceRuntime.PROFILE], SecretStr(_DUMMY_DB_URL))


@pytest.fixture(autouse=True)
def primary_runtime(monkeypatch: pytest.MonkeyPatch, _profile_database_runtime: "DatabaseRuntime") -> None:
    """Основной рантайм профиля — как у процесса API после старта lifespan.

    Процесс получает его от точки входа; тестам, которые ходят в код с `get_primary_runtime()`
    напрямую, точки входа нет. Состояние модуля восстанавливается после теста — тест точки входа
    может поднять рантайм своей роли.
    """
    from src.config import ServiceRuntime  # noqa: PLC0415
    from src.infra import database  # noqa: PLC0415

    monkeypatch.setattr(
        database, "_primary", database._Primary(runtime=ServiceRuntime.PROFILE, database=_profile_database_runtime)
    )


@pytest.fixture
def no_primary_runtime(monkeypatch: pytest.MonkeyPatch) -> None:
    """Процесс до старта: основной рантайм не поднят. Для тестов точек входа."""
    from src.infra import database  # noqa: PLC0415

    monkeypatch.setattr(database, "_primary", None)


def install_primary_session_factory(monkeypatch: pytest.MonkeyPatch, session_factory: object) -> None:
    """Уводит сессии основного рантайма на фабрику теста (обычно — на `db_session` стенда)."""
    from src.infra import database  # noqa: PLC0415

    primary = database._primary
    assert primary is not None, "основной рантайм не поднят"
    runtime = dataclasses.replace(primary.database, session_factory=session_factory)
    monkeypatch.setattr(database, "_primary", dataclasses.replace(primary, database=runtime))


@pytest.fixture(scope="session")
def auth_headers() -> dict[str, str]:
    return {"X-Test-Api-Key": _TEST_API_KEY}


@pytest.fixture(scope="session")
def restarter_headers() -> dict[str, str]:
    """Заголовок ручки перезапуска (src/workers/restarter.py). Ключ свой, не тестового API."""
    return {"X-Restarter-Api-Key": _RESTARTER_API_KEY}


@pytest.fixture
def mock_db_string() -> str:
    return _DUMMY_DB_URL


@dataclass(frozen=True)
class RuntimeDbUrls:
    """Готовые URL-ы логинов стенда. Пароли генерируются на прогон и никуда не сохраняются."""

    base_sync_url: str
    passwords: Mapping[str, SecretStr]

    def sync_url(self, role: str) -> str:
        return self._url(role, "postgresql+psycopg2")

    def async_url(self, role: str) -> str:
        return self._url(role, "postgresql+asyncpg")

    def _url(self, role: str, drivername: str) -> str:
        password = self.passwords[role].get_secret_value()
        url = make_url(self.base_sync_url).set(drivername=drivername, username=role, password=password)
        return url.render_as_string(hide_password=False)


_RUNTIME_DB_URLS: "RuntimeDbUrls | None" = None


def _provision_runtime_roles(sync_url: str) -> "RuntimeDbUrls":
    """Заводит владельцев схем и рантайм-логины ДО alembic — тем же кодом, что и деплой."""
    global _RUNTIME_DB_URLS
    from src.infra.db_bootstrap import RoleCredentials, bootstrap_roles_at_url  # noqa: PLC0415
    from src.infra.db_schemas import BULK_RECALC_ROLE, CALCULATION_ROLE, EHR_ROLE, PROFILE_ROLE  # noqa: PLC0415

    credentials = RoleCredentials(
        profile=SecretStr(secrets.token_urlsafe(24)),
        calculation=SecretStr(secrets.token_urlsafe(24)),
        ehr=SecretStr(secrets.token_urlsafe(24)),
        bulk_recalc=SecretStr(secrets.token_urlsafe(24)),
        migrations=SecretStr(secrets.token_urlsafe(24)),
    )
    # Тем же входом, что и деплой: он сам открывает соединение на драйвере, который не выносит
    # пароли в текст запроса. Своего event loop у синхронной фикстуры нет, отсюда asyncio.run.
    asyncio.run(bootstrap_roles_at_url(sync_url, credentials, legacy_owner=make_url(sync_url).username))

    _RUNTIME_DB_URLS = RuntimeDbUrls(
        base_sync_url=sync_url,
        passwords={
            PROFILE_ROLE: credentials.profile,
            CALCULATION_ROLE: credentials.calculation,
            EHR_ROLE: credentials.ehr,
            BULK_RECALC_ROLE: credentials.bulk_recalc,
            MIGRATION_ROLE: credentials.migrations,
        },
    )
    return _RUNTIME_DB_URLS


@pytest.fixture(scope="session")
def runtime_db_urls(postgres_url: str) -> "RuntimeDbUrls":
    """URL-ы каждого рантайм-логина тестового стенда.

    Стенд повторяет ролевую топологию прода: тесты границ прав обязаны ходить под настоящими
    логинами, а не под суперпользователем кластера — иначе они доказывали бы обратное.
    """
    assert _RUNTIME_DB_URLS is not None, "postgres_url не поднял стенд"
    return _RUNTIME_DB_URLS


@pytest.fixture(scope="session")
def postgres_url() -> Generator[str, None, None]:
    with postgres_server() as sync_url:
        async_url = make_url(sync_url).set(drivername="postgresql+asyncpg").render_as_string(hide_password=False)
        runtime_urls = _provision_runtime_roles(sync_url)
        cfg = Config("alembic.ini")
        # Миграции гоняются под миграционным логином, а не под суперпользователем кластера:
        # прод так же не даёт alembic ничего сверх этой роли, и нехватка прав должна падать здесь.
        cfg.set_main_option("sqlalchemy.url", runtime_urls.sync_url(MIGRATION_ROLE))
        command.upgrade(cfg, "head")
        _create_physical_view_schema(sync_url)
        yield async_url


# Один engine на сессию: create_async_engine + dispose() на каждый тест — это новый пул и новый
# коннект-хендшейк на все 363 теста с БД. Пул переиспользует коннекты между тестами, а коннект
# asyncpg привязан к event loop, в котором открыт, поэтому loop_scope="session" здесь и
# asyncio_default_test_loop_scope="session" в pyproject.toml — одно неделимое изменение.
@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def engine(postgres_url: str) -> AsyncGenerator[AsyncEngine, None]:
    engine = create_async_engine(postgres_url)
    yield engine
    await engine.dispose()


# Карта схем ORM по рантайму. Ключ — значение ServiceRuntime (StrEnum), а не сам enum: src.config
# на этом уровне не импортируется — Settings собирается на импорте, а заглушки строк подключения
# кладутся в окружение выше по модулю.
_SCHEMA_MAPS: Mapping[str, Mapping[str, str]] = {
    "profile": PROFILE_SCHEMA_MAP,
    "calculation": CALCULATION_SCHEMA_MAP,
    "ehr": EHR_SCHEMA_MAP,
}

# Схема, которую рантайм считает своей: её локальные представления должны перекрывать физические
# таблицы чужих схем, поэтому в search_path она идёт первой.
_OWN_SCHEMA: Mapping[str, str] = {
    "profile": PROFILE_SCHEMA,
    "calculation": CALCULATION_SCHEMA,
    "ehr": EHR_SCHEMA,
}

# Тестовая схема сквозных представлений: по одному на каждую физическую таблицу профиля и расчёта.
#
# Порядком схем в search_path «физическую таблицу-владельца» выразить нельзя: и `risk_profile`, и
# `risk_calculation` содержат объекты со ВСЕМИ этими именами — свои таблицы плюс представления над
# чужими. При любом порядке половина имён попадёт в чужое представление, а часть таких
# представлений сознательно урезана в правах (`risk_profile.results_history` — только INSERT), и
# чтение через них падает отказом в правах. Отдельная схема разрешает каждое имя в его владельца
# независимо от порядка.
#
# Представления простые (`SELECT *`), то есть автообновляемые: запись через них доходит до таблицы
# и поднимает её триггеры. Схема существует только на стенде и ролям рантаймов не выдаётся.
TEST_PHYSICAL_SCHEMA: str = "test_physical"

# Путь разрешения имён без маркера: таблица-владелец, затем общие справочники.
_PHYSICAL_SEARCH_PATH: tuple[str, ...] = (TEST_PHYSICAL_SCHEMA, CATALOG_SCHEMA, "public")


def _create_physical_view_schema(sync_url: str) -> None:
    """Заводит `test_physical` после миграций: представления строятся по готовым таблицам."""
    engine = create_engine(sync_url)
    try:
        with engine.begin() as connection:
            connection.execute(text(f"CREATE SCHEMA {TEST_PHYSICAL_SCHEMA}"))
            for schema, tables in ((PROFILE_SCHEMA, PROFILE_TABLES), (CALCULATION_SCHEMA, CALCULATION_TABLES)):
                for table in tables:
                    connection.execute(
                        text(f"CREATE VIEW {TEST_PHYSICAL_SCHEMA}.{table} AS SELECT * FROM {schema}.{table}")
                    )
    finally:
        engine.dispose()


# Движки, которые тесты поднимают сами (сценарии с закоммиченными данными), не проходят через
# `db_session` и его SET LOCAL. Тот же физический путь на уровне соединения — чтобы сырой SQL без
# схемы читался одинаково, на какой бы сессии он ни выполнялся.
PHYSICAL_CONNECT_ARGS: Mapping[str, object] = {"server_settings": {"search_path": ", ".join(_PHYSICAL_SEARCH_PATH)}}


def _search_path(role: str | None) -> str:
    """Порядок разрешения имён для сырого SQL: своя схема рантайма первой, владельцы — запасным ходом.

    Своя схема первой — это и есть роль файла: `patients_parameters` в файле расчёта попадает в
    представление `risk_calculation`, а не в таблицу профиля. Владельцы следом, чтобы имена без
    локального представления (справочники, чужие таблицы в arrange-шагах) всё равно разрешались.
    """
    if role is None:
        return ", ".join(_PHYSICAL_SEARCH_PATH)
    return ", ".join((_OWN_SCHEMA[role], *_PHYSICAL_SEARCH_PATH))


@pytest.fixture
def db_role(request: pytest.FixtureRequest) -> str | None:
    """Рантайм, от имени которого файл теста ходит в БД. Задаётся маркером `db_role` на модуле.

    Один маркер на файл вместо схемы в каждом запросе: он же выбирает карту трансляции схем для
    ORM, он же ставит `search_path` для сырого SQL. Без маркера — физический путь, как до
    разделения схем: сырой SQL адресует таблицы-владельцы.

    Схему в запросе всё же приходится называть в двух случаях:

    * DDL (`ALTER TABLE`, `DROP TABLE`) — `search_path` без маркера приводит в `test_physical`, а
      это представления, и менять структуру через них нельзя;
    * SQL на соединении, которое тест открыл сам мимо `db_session` — туда `SET LOCAL` не достаёт.
      Если это отдельный движок, ему проще передать `connect_args=PHYSICAL_CONNECT_ARGS`.

    По той же причине общие хелперы (`tests/factories.py`, `tests/db_assertions.py`) всегда пишут
    схему явно: у них нет одной роли, а ассерты обязаны читать физическую таблицу, а не то
    представление, которое видит роль конкретного файла.
    """
    marker = request.node.get_closest_marker("db_role")
    return None if marker is None else marker.args[0]


@pytest_asyncio.fixture(loop_scope="session")
async def db_session(engine: AsyncEngine, db_role: str | None) -> AsyncGenerator[AsyncSession, None]:
    async with engine.connect() as conn:
        await conn.begin()
        if db_role is not None:
            await conn.execution_options(schema_translate_map=dict(_SCHEMA_MAPS[db_role]))
        # SET LOCAL, а не SET: движок на сессию, коннекты переиспользуются между тестами, и
        # глобальный SET протёк бы в следующий тест. Транзакция закрывается откатом ниже.
        await conn.execute(text(f"SET LOCAL search_path TO {_search_path(db_role)}"))
        session = AsyncSession(conn, expire_on_commit=False, join_transaction_mode="create_savepoint")
        yield session
        await conn.rollback()


@pytest.fixture
def factory(db_session: AsyncSession) -> "Factory":
    """Фабрики, привязанные к сессии теста: db_session не протаскивается через каждый вызов."""
    from tests.factories import Factory  # noqa: PLC0415 — импорт внутри, как у make_calc_catalog

    return Factory(db_session)


@pytest.fixture
def db_read(db_session: AsyncSession) -> "DbRead":
    """Читалки для ассертов, привязанные к сессии теста."""
    from tests.db_assertions import DbRead  # noqa: PLC0415

    return DbRead(db_session)


@pytest.fixture
def captured_app_logs() -> Generator[LogSink, None, None]:
    """Re-point the real "app" logger's FingersCrossedHandler at a capturing sink.

    Records still pass through the production MonologFilter and fingers-crossed logic
    (the handler/filter under test) — only the terminal stdout stream is swapped. So if
    MonologLogger's gating changes, these calc e2e assertions move with it.

    The "app" logger is force-enabled for the duration: Alembic's fileConfig() (run by the
    integration DB fixture) defaults to disable_existing_loggers=True and switches off the
    already-created "app" logger. That's a test-only artifact — in prod Alembic runs as a
    separate CLI process — so it must not mask the logging contract under test.
    """
    from src.logger import FingersCrossedHandler  # noqa: PLC0415
    from src.logger import logger as app_logger  # noqa: PLC0415

    handler = next(item for item in app_logger.handlers if isinstance(item, FingersCrossedHandler))
    original_target = handler._target
    sink = LogSink(original_target.formatter)
    sink.setLevel(original_target.level)
    for record_filter in original_target.filters:
        sink.addFilter(record_filter)

    was_disabled = app_logger.disabled
    handler._target = sink
    app_logger.disabled = False
    try:
        yield sink
    finally:
        handler._target = original_target
        app_logger.disabled = was_disabled


async def make_calc_catalog(session: AsyncSession) -> "CalcCatalog":
    """Build a CalcCatalog from a DB session (integration tests). Mirrors prod build-after-seed:
    call it AFTER the test has seeded its reference rows so the catalog reflects them."""
    from src.infra.catalog.base import load_catalog
    from src.infra.catalog.calc import CalcCatalog

    return CalcCatalog(await load_catalog(session))


async def make_interpretation_catalog(session: AsyncSession) -> "InterpretationCatalog":
    """Build an InterpretationCatalog from a DB session. Same contract as make_calc_catalog:
    call it AFTER the test has seeded its reference rows."""
    from src.infra.catalog.base import load_catalog
    from src.infra.catalog.interpretation import InterpretationCatalog

    return InterpretationCatalog(await load_catalog(session))


async def make_http_catalog(session: AsyncSession) -> "HttpCatalog":
    """Build the HTTP snapshot on a separate session, without changing the caller's transaction."""
    from src.infra.catalog.base import load_catalog
    from src.infra.catalog.http import HttpCatalog

    bind = session.bind
    if not isinstance(bind, (AsyncConnection, AsyncEngine)):
        raise RuntimeError("make_http_catalog requires a session bound to an async engine or connection")

    # Integration tests bind their session to a connection wrapped in an outer rollback-only
    # transaction. A new engine connection cannot see rows seeded inside that transaction, even
    # after session.commit() (it only releases a savepoint). Use a separate session on the same
    # connection and give it its own savepoint: it sees test seeds without owning or rolling back
    # the caller's session. An engine-bound caller follows the production shape and gets a normal
    # independent session/connection.
    join_mode = "create_savepoint" if isinstance(bind, AsyncConnection) else "conditional_savepoint"
    async with AsyncSession(bind, join_transaction_mode=join_mode) as catalog_session:
        return HttpCatalog(await load_catalog(catalog_session))


def build_calc_catalog() -> "CalcCatalog":
    """In-memory CalcCatalog for unit tests (no DB)."""
    from src.infra.catalog.calc import CalcCatalog
    from tests.catalog_builder import (
        condition,
        instrument,
        instrument_parameter,
        make_catalog,
        option,
        question,
        system_instrument,
    )

    base = make_catalog(
        conditions=(condition("Q_OPT", PARAMETER_CODE_GENDER, value=GENDER_FEMALE),),
        instruments=(
            instrument("form_a", instrument_id=1),
            instrument("calc_b", type="calc", instrument_id=2),
        ),
        instruments_parameters=(
            instrument_parameter("form_a", "p_gen", is_required=True),
            instrument_parameter("form_a", "p_opt"),
            instrument_parameter("calc_b", "p_gen"),
        ),
        options=(
            option("OPT_GEN", question_code="Q_GEN", parameter_code="p_gen", value="yes", option_id=1),
            option("OPT_A", question_code="Q_OPT", parameter_code="p_opt", value="yes", option_id=2),
            option("BDI1_02", question_code="BDI1", parameter_code="bdi1", value="sad", option_id=3),
            option("BDI1_04", question_code="BDI1", parameter_code="bdi1", value="very sad", option_id=4),
        ),
        questions=(
            question("Q_GEN", group_code=1, question_id=1),
            question("Q_OPT", question_id=2),
            question("BDI1", question_id=3),
        ),
        systems_instruments=(
            system_instrument("s1", "form_a"),
            system_instrument("s2", "form_a"),
        ),
    )
    return CalcCatalog(base)


class _AnyInstrumentCode:
    """Реестр формул, в который «входит» любой код инструмента.

    Каталог маршрутизирует инструмент типа `calc` в формульный pipeline, только если его код
    зарегистрирован реестром формул. Тесты хендлера считают выдуманными инструментами со
    стабом формулы, поэтому на время такого теста реестр открывается — иначе проверялся бы не
    порядок вызовов и батчинг, а отсутствие фиктивного кода в реестре.
    """

    def __contains__(self, item: object) -> bool:
        return True


@contextmanager
def open_formula_registry() -> Iterator[None]:
    """Считать формульным любой активный инструмент типа `calc` — только для тестов со стабом."""
    with patch("src.infra.catalog.calc.FORMULA_CODES", _AnyInstrumentCode()):
        yield
