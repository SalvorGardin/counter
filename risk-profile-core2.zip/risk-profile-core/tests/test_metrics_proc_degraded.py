"""Пути пропуска /proc-коллектора и multiprocess-ветка render().

`/proc` читается на каждом скрейпе, без блокировок: процесс может исчезнуть между листингом и
чтением его файлов, а на не-Linux каталога нет вовсе. Ни то, ни другое не имеет права уронить
`GET /metrics` — иначе обзервабилити падает ровно тогда, когда она нужнее всего.

Вместо настоящего `/proc` подставляется каталог с теми же файлами: так проверяются ветки, которые
на живой системе воспроизводятся только гонкой.
"""

import os
from pathlib import Path

import pytest
from prometheus_client.parser import text_string_to_metric_families

import src.metrics as metrics
from src.metrics import _drop_default_process_collectors, _read_proc_stats, render
from src.metrics_multiproc import MULTIPROC_ENV, prepare_multiproc_dir

_MASTER = 1000

# utime 40 + stime 12 = 52 тика; ppid подставляется в шаблон.
_STAT = "{pid} (uvicorn) S {ppid} 1 1 0 -1 4194560 100 0 0 0 40 12 0 0 20 0 4 0 999"
_STATM = "4200 512 480 4 0 300 0"


def _write_proc(root: Path, pid: int, *, ppid: int, stat: str | None = None, statm: str | None = None) -> None:
    entry = root / str(pid)
    entry.mkdir()
    (entry / "stat").write_text(stat if stat is not None else _STAT.format(pid=pid, ppid=ppid))
    if statm is not None:
        (entry / "statm").write_text(statm)


@pytest.fixture
def fake_proc(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Подменяет корень /proc и фиксирует мастер-PID — иначе результат зависел бы от pid тестов."""
    monkeypatch.setattr(metrics, "_PROC_ROOT", str(tmp_path))
    monkeypatch.setattr(metrics, "_master_pid", lambda _workers: _MASTER)
    return tmp_path


def test_absent_proc_root_disables_collector(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Не-Linux: каталога нет — коллектор молча не отдаёт рядов."""
    monkeypatch.setattr(metrics, "_PROC_ROOT", str(tmp_path / "nope"))

    assert _read_proc_stats(1) is None


def test_unreadable_proc_root_disables_collector(fake_proc: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Листинг /proc упал (ограничения контейнера) — отдаём None, а не поднимаем ошибку в скрейп."""

    def _raise(_path: str) -> list[str]:
        raise PermissionError("hidepid=2")

    monkeypatch.setattr(metrics.os, "listdir", _raise)

    assert _read_proc_stats(1) is None


def test_sums_master_and_its_children_only(fake_proc: Path) -> None:
    """В сумму идут мастер и процессы с ppid == мастер; чужие дети — нет.

    Гейт по ppid — единственное, что отделяет воркеры uvicorn от посторонних процессов
    контейнера, и его ошибка завысила бы cpu/ram сервиса на чужие значения.
    """
    _write_proc(fake_proc, _MASTER, ppid=1, statm=_STATM)
    _write_proc(fake_proc, 1001, ppid=_MASTER, statm=_STATM)
    _write_proc(fake_proc, 2002, ppid=7, statm=_STATM)  # чужой ребёнок
    (fake_proc / "self").mkdir()  # не-числовая запись каталога

    stats = _read_proc_stats(4)

    assert stats is not None
    cpu_seconds, rss_bytes, count = stats
    assert count == 2
    assert cpu_seconds == pytest.approx(2 * 52 / metrics._CLK_TCK)
    assert rss_bytes == 2 * 512 * metrics._PAGE_SIZE


def test_process_vanished_between_listing_and_read_is_skipped(fake_proc: Path) -> None:
    """Каталог есть, файлов нет — процесс завершился, пока мы шли по списку.

    Такой pid просто не учитывается: сумма по остальным всё равно отдаётся, иначе один умерший
    воркер обнулял бы cpu/ram по всему сервису.
    """
    _write_proc(fake_proc, _MASTER, ppid=1, statm=_STATM)
    (fake_proc / "1001").mkdir()  # ни stat, ни statm

    stats = _read_proc_stats(4)

    assert stats is not None
    assert stats[2] == 1


def test_malformed_stat_is_skipped(fake_proc: Path) -> None:
    """Битый stat (обрезанное чтение) не должен ронять скрейп — пропускаем этот pid."""
    _write_proc(fake_proc, _MASTER, ppid=1, statm=_STATM)
    _write_proc(fake_proc, 1001, ppid=_MASTER, stat="1001 (trunc", statm=_STATM)

    stats = _read_proc_stats(4)

    assert stats is not None
    assert stats[2] == 1


def test_child_with_unreadable_statm_is_skipped(fake_proc: Path) -> None:
    """stat прочитался, statm — нет: pid отбрасывается целиком,половинчатые значения в сумму не идут."""
    _write_proc(fake_proc, _MASTER, ppid=1, statm=_STATM)
    _write_proc(fake_proc, 1001, ppid=_MASTER)  # statm отсутствует

    stats = _read_proc_stats(4)

    assert stats is not None
    assert stats[2] == 1
    assert stats[1] == 512 * metrics._PAGE_SIZE


def test_no_readable_process_disables_collector(fake_proc: Path) -> None:
    """Не удалось прочитать ни одного процесса, включая мастера — рядов нет вовсе.

    Ноль здесь был бы хуже отсутствия: «сервис не потребляет CPU» читается как исправное
    состояние, а «ряда нет» — как проблема сбора.
    """
    assert _read_proc_stats(1) is None


def test_dropping_default_collectors_twice_is_idempotent() -> None:
    """Коллекторы process_/platform_/gc_ уже сняты при импорте — повтор не должен падать.

    Функция вызывается на импорте модуля, а тесты импортируют его многократно (перезагрузка
    настроек, подпроцессы), поэтому повторный вызов — штатный, а не исключительный.
    """
    _drop_default_process_collectors()
    _drop_default_process_collectors()

    body = render().decode()
    assert "process_virtual_memory_bytes" not in body
    assert "python_gc_objects_collected_total" not in body


def test_render_in_multiprocess_mode_merges_worker_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Боевой режим (workers>1): тело собирается из mmap-файлов воркеров плюс локальный реестр.

    Реестр MultiProcessCollector строится заново на каждый скрейп — он вычитывает файлы в момент
    сборки, и переиспользованный реестр отдавал бы снимок первого скрейпа навсегда.
    """
    monkeypatch.setattr(metrics, "_MULTIPROC_PATH", str(tmp_path))
    monkeypatch.setenv(MULTIPROC_ENV, str(tmp_path))
    built: list[object] = []
    real_collector = metrics.MultiProcessCollector
    monkeypatch.setattr(
        metrics,
        "MultiProcessCollector",
        lambda registry: built.append(registry) or real_collector(registry),
    )

    first = render().decode()
    second = render().decode()

    # Тело валидно как prometheus text format даже при пустом наборе файлов воркеров.
    # Сравнивать два тела между собой нельзя: в локальном реестре живут scrape-time метрики,
    # значения которых меняются от скрейпа к скрейпу.
    list(text_string_to_metric_families(first))
    list(text_string_to_metric_families(second))
    # Реестр собирается на КАЖДЫЙ скрейп и каждый раз новый: переиспользованный отдавал бы
    # снимок первого скрейпа навсегда.
    assert len(built) == 2
    assert built[0] is not built[1]


def test_prepare_multiproc_dir_removes_stale_worker_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Чистим на старте, а не на shutdown: после OOM-kill или crash shutdown-код не выполняется,
    и счётчики прошлой жизни контейнера прибавились бы к текущим."""
    stale = tmp_path / "counter_1234.db"
    stale.write_bytes(b"stale")
    keep = tmp_path / "notes.txt"
    keep.write_text("не mmap-файл метрик")
    monkeypatch.setenv(MULTIPROC_ENV, str(tmp_path))

    prepare_multiproc_dir()

    assert not stale.exists()
    assert keep.exists()


def test_prepare_multiproc_dir_without_env_is_noop(monkeypatch: pytest.MonkeyPatch) -> None:
    """Single-process режим (переменная не задана: тесты, локальный запуск): каталога нет, готовить нечего."""
    monkeypatch.delenv(MULTIPROC_ENV, raising=False)

    prepare_multiproc_dir()

    assert os.environ.get(MULTIPROC_ENV) is None


def test_collector_yields_nothing_when_proc_is_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    """`/proc` недоступен — коллектор отдаёт пустую выдачу, а не ряды с нулями.

    Ноль CPU и ноль RSS выглядели бы как исправно простаивающий сервис; отсутствие рядов честно
    показывает, что источник данных недоступен (на не-Linux — постоянно).
    """
    monkeypatch.setattr(metrics, "_read_proc_stats", lambda _workers: None)

    assert list(metrics._ProcStatsCollector(workers=4).collect()) == []
