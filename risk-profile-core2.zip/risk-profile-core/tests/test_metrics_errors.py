"""Тесты счётчика ошибок risk_profile_core_errors_total (хук _MetricsHandler на логгере "app").

Счётчик инкрементится на каждый лог-рекорд уровня ERROR+ (в т.ч. «200-но-ошибка»), лейблы:
level (error/critical/alert/emergency) и component (модуль вызвавшего кода). Ниже ERROR —
не считается; fingers-crossed не задваивает.
"""

import logging

from prometheus_client import REGISTRY

from src.logger import (
    FingersBuffer,
    _component_from_record,
    alert,
    business,
    emergency,
    fingers_crossed_var,
    logger,
    notice,
)

_METRIC = "risk_profile_core_errors_total"
# record.module для лог-вызовов из ЭТОГО файла — имя файла без расширения.
_COMPONENT = "test_metrics_errors"


def _errors(level: str, component: str = _COMPONENT) -> float:
    value = REGISTRY.get_sample_value(_METRIC, {"level": level, "component": component})
    return value or 0.0


def test_error_increments_counter_with_module_component() -> None:
    """logger.error из этого модуля → errors_total{level=error, component=test_metrics_errors} +1."""
    before = _errors("error")
    logger.error("boom", extra={"log_context": {}})
    assert _errors("error") == before + 1


def test_alert_helper_increments_with_alert_level() -> None:
    """alert() (через _log, stacklevel=3) → level=alert, component = реальный вызывающий модуль."""
    before = _errors("alert")
    alert("degraded")
    assert _errors("alert") == before + 1


def test_critical_and_emergency_map_to_lowercased_levels() -> None:
    before_crit = _errors("critical")
    logger.critical("crit", extra={"log_context": {}})
    assert _errors("critical") == before_crit + 1

    before_emerg = _errors("emergency")
    emergency("emerg")
    assert _errors("emergency") == before_emerg + 1


def test_below_error_levels_do_not_increment() -> None:
    """notice / warning / business (INFO) счётчик не трогают — emit() гейтит уровень до inc()."""
    notice("n")
    logger.warning("w", extra={"log_context": {}})
    business("b")
    # ни одна из этих записей не создаёт ряд в счётчике (все < ERROR).
    assert _errors("notice") == 0.0
    assert _errors("warning") == 0.0
    assert _errors("info") == 0.0


def test_error_in_request_context_increments_exactly_once() -> None:
    """ERROR внутри fingers-crossed запроса считается один раз: слив буфера в поток идёт мимо
    логгера (в target-handler), а не переигрывается через callHandlers → без задвоения."""
    before = _errors("error")
    token = fingers_crossed_var.set(FingersBuffer())
    try:
        logger.debug("buffered-debug", extra={"log_context": {}})
        notice("buffered-notice")
        logger.error("trigger-in-request", extra={"log_context": {}})
    finally:
        fingers_crossed_var.reset(token)
    assert _errors("error") == before + 1


def _record(pathname: str) -> logging.LogRecord:
    return logging.LogRecord("app", logging.ERROR, pathname, 0, "x", (), None)


def test_component_from_record_is_package_qualified_under_src() -> None:
    """component берётся пакет-квалифицированным относительно src/, иначе calc/handler.py и
    interpretation/handler.py оба дали бы 'handler' и домен сбоя по метрике не различить."""
    assert _component_from_record(_record("/app/src/calc/handler.py")) == "calc.handler"
    assert _component_from_record(_record("/app/src/interpretation/handler.py")) == "interpretation.handler"


def test_component_from_record_falls_back_to_module_outside_src() -> None:
    """Код вне src/ (тесты, сторонние библиотеки) — по record.module (голое имя файла)."""
    assert _component_from_record(_record("/somewhere/tests/foo_test.py")) == "foo_test"
