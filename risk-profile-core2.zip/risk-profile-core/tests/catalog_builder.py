"""Сборка ин-мемори Catalog для unit-тестов без БД.

Каждая фабрика принимает только то, что тест реально задаёт;
остальное — боевые дефолты. Суррогатные ключи выдаёт счётчик,
поэтому тест не выдумывает id и не ловит коллизии.
Таблицы, не переданные в make_catalog, приходят пустыми:
тест описывает свой срез каталога, а не все пятнадцать справочников.

Все id-поля разных таблиц используют единый модульный счётчик _ids,
а не отдельные счётчики на таблицу — это отличается от боевых
последовательностей, но допустимо, так как ids никогда не сравниваются
между таблицами.
"""

from collections.abc import Sequence
from datetime import UTC, datetime
from decimal import Decimal
from itertools import count
from types import MappingProxyType
from uuid import UUID, uuid4

from src.constants import ANSWER_YES
from src.infra.catalog.base import _TABLE_SPECS, Catalog
from src.infra.catalog.dtos import (
    BiomarkerDTO,
    BiomarkerParameterMappingDTO,
    ConditionDTO,
    DiseaseDTO,
    DiseaseExaminationDTO,
    ExaminationDTO,
    InstrumentDTO,
    InstrumentParameterDTO,
    OptionDTO,
    ParameterDTO,
    QuestionDTO,
    RiskFactorDTO,
    RiskFactorScoreDTO,
    RiskFactorSystemDTO,
    RiskFactorTriggerDTO,
    ScoreDTO,
    SystemCheckupExaminationDTO,
    SystemDTO,
    SystemInstrumentDTO,
)

_ids = count(1)
CATALOG_TABLE_NAMES = tuple(name for name, _, _ in _TABLE_SPECS)


def _next_id() -> int:
    return next(_ids)


def make_catalog(**tables: Sequence[object]) -> Catalog:
    """Catalog из переданных таблиц; неупомянутые таблицы — пустые кортежи."""
    unknown = set(tables) - set(CATALOG_TABLE_NAMES)
    if unknown:
        raise ValueError(f"unknown catalog tables: {sorted(unknown)}")
    filled: dict[str, tuple[object, ...]] = {name: () for name in CATALOG_TABLE_NAMES}
    for name, rows in tables.items():
        filled[name] = tuple(rows)
    return Catalog(tables=MappingProxyType(filled))


def question(
    code: str,
    *,
    group_code: int = 2,
    question_id: int | None = None,
    question: str | None = None,
    type: str = "select",  # noqa: A002 — имя поля DTO
    is_skippable: bool = False,
    question_male: str | None = None,
    question_female: str | None = None,
) -> QuestionDTO:
    return QuestionDTO(
        code,
        group_code,
        question_id if question_id is not None else _next_id(),
        question or code,
        type,
        is_skippable,
        question_male,
        question_female,
    )


def option(
    code: str,
    *,
    question_code: str,
    parameter_code: str,
    value: str | None = ANSWER_YES,
    option_id: int | None = None,
    value_male: str | None = None,
    value_female: str | None = None,
) -> OptionDTO:
    return OptionDTO(
        code,
        value,
        question_code,
        parameter_code,
        option_id if option_id is not None else _next_id(),
        value_male,
        value_female,
    )


def instrument(
    code: str,
    *,
    type: str = "form",  # noqa: A002 — имя поля DTO
    status: str = "active",
    instrument_id: int | None = None,
    description: str | None = None,
    diseases: list[str] | None = None,
) -> InstrumentDTO:
    return InstrumentDTO(
        code,
        type,
        status,
        instrument_id if instrument_id is not None else _next_id(),
        description or code,
        diseases,
    )


def instrument_parameter(
    instrument_code: str, parameter_code: str, *, is_required: bool = False
) -> InstrumentParameterDTO:
    return InstrumentParameterDTO(instrument_code, parameter_code, is_required)


def system_instrument(system_code: str, instrument_code: str) -> SystemInstrumentDTO:
    return SystemInstrumentDTO(system_code, instrument_code)


def condition(
    question_code: str,
    parameter_code: str,
    *,
    value: str | None = None,
    type: str = "except",  # noqa: A002 — имя поля DTO
    min_age: int | None = None,
    max_age: int | None = None,
) -> ConditionDTO:
    return ConditionDTO(question_code, parameter_code, value, type, min_age, max_age)


def score(
    parameter_code: str,
    system_code: str,
    *,
    value: str | None = None,
    min_value: Decimal | None = None,
    max_value: Decimal | None = None,
    score: Decimal,  # noqa: A002 — имя поля DTO
) -> ScoreDTO:
    return ScoreDTO(parameter_code, system_code, value, min_value, max_value, score)


def parameter(
    code: str,
    *,
    parameter_id: int | None = None,
    description: str | None = None,
    status: str = "active",
    validity_period: datetime | None = None,
) -> ParameterDTO:
    # validity_period — длительность от эпохи (src/services/risk_communication/domain/expiration.py),
    # дефолт «30 дней», а не абсолютная дата.
    default = datetime(1970, 1, 31, tzinfo=UTC)
    return ParameterDTO(
        parameter_id if parameter_id is not None else _next_id(),
        code,
        description or code,
        status,
        validity_period or default,
    )


def biomarker(
    biomarker_code: int,
    parameter_code: str,
    *,
    biomarker_id: int | None = None,
    unit_code: int | None = 169,
    name: str = "Биомаркер",
    type: str = "quantitative",  # noqa: A002 — имя поля DTO
    unit: str | None = "ммоль/л",
) -> BiomarkerDTO:
    return BiomarkerDTO(
        biomarker_id if biomarker_id is not None else _next_id(),
        biomarker_code,
        unit_code,
        parameter_code,
        name,
        type,
        unit,
    )


def biomarker_mapping(
    biomarker_parameter_code: str,
    parameter_code: str,
    *,
    biomarker_parameter_mapping_id: int | None = None,
    mapping_type: str = "value",
    operator: str | None = None,
    value_num: Decimal | None = None,
    value_text: str | None = None,
    option_code: str | None = None,
    unit: str | None = None,
) -> BiomarkerParameterMappingDTO:
    return BiomarkerParameterMappingDTO(
        biomarker_parameter_mapping_id if biomarker_parameter_mapping_id is not None else _next_id(),
        biomarker_parameter_code,
        parameter_code,
        mapping_type,
        operator,
        value_num,
        value_text,
        option_code,
        unit,
    )


def system(
    code: str,
    *,
    system_id: int | None = None,
    description: str | None = None,
    rang: int | None = None,
) -> SystemDTO:
    sid = system_id if system_id is not None else _next_id()
    return SystemDTO(sid, code, description or code, rang if rang is not None else sid)


def disease(
    code: str,
    system_code: str,
    *,
    description: str | None = None,
    disease_id: int | None = None,
) -> DiseaseDTO:
    return DiseaseDTO(
        disease_id if disease_id is not None else _next_id(),
        code,
        description or code,
        system_code,
    )


def risk_factor(
    code: str,
    *,
    description: str | None = None,
    modifiability: str = "Модифицируемый",
    risk_factor_id: int | None = None,
) -> RiskFactorDTO:
    return RiskFactorDTO(
        risk_factor_id if risk_factor_id is not None else _next_id(),
        code,
        description or code,
        modifiability,
    )


def risk_factor_system(
    risk_factor_code: str,
    system_code: str,
    *,
    reasoning: str | None = None,
    risk_factor_system_id: int | None = None,
) -> RiskFactorSystemDTO:
    return RiskFactorSystemDTO(
        risk_factor_system_id if risk_factor_system_id is not None else _next_id(),
        risk_factor_code,
        system_code,
        reasoning,
    )


def risk_factor_trigger(
    risk_factor_code: str,
    system_code: str,
    parameter_code: str,
    *,
    operator: str = "eq",
    value_text: str | None = ANSWER_YES,
    value_num: Decimal | None = None,
    min_value: Decimal | None = None,
    max_value: Decimal | None = None,
    gender: str | None = None,
    trigger_id: int | None = None,
    trigger_code: str | None = None,
) -> RiskFactorTriggerDTO:
    tid = trigger_id if trigger_id is not None else _next_id()
    return RiskFactorTriggerDTO(
        tid,
        trigger_code or f"{risk_factor_code}__{system_code}__{parameter_code}__{tid:02d}",
        risk_factor_code,
        system_code,
        parameter_code,
        "text" if operator == "eq" else "number",
        operator,
        value_num,
        min_value,
        max_value,
        value_text if operator == "eq" else None,
        gender,
    )


def risk_factor_score(
    risk_factor_code: str,
    disease_code: str,
    *,
    score: int = 3,  # noqa: A002 — имя поля DTO
    influence: str = "increase",
    risk_factor_score_id: int | None = None,
) -> RiskFactorScoreDTO:
    return RiskFactorScoreDTO(
        risk_factor_score_id if risk_factor_score_id is not None else _next_id(),
        risk_factor_code,
        disease_code,
        score,
        influence,
    )


def examination(
    code: UUID | None = None,
    *,
    examination_type: str = "laboratory",
    status: str = "active",
    name: str | None = None,
    examination_id: int | None = None,
) -> ExaminationDTO:
    ecode = code if code is not None else uuid4()
    return ExaminationDTO(
        examination_id if examination_id is not None else _next_id(),
        ecode,
        name or str(ecode),
        examination_type,
        status,
    )


def disease_examination(
    disease_code: str,
    examination_code: UUID,
    *,
    category: str | None = "basic",
    disease_examination_id: int | None = None,
) -> DiseaseExaminationDTO:
    return DiseaseExaminationDTO(
        disease_examination_id if disease_examination_id is not None else _next_id(),
        disease_code,
        examination_code,
        category,
    )


def system_checkup_examination(
    system_code: str,
    examination_code: UUID,
    *,
    gender: str | None = None,
    system_checkup_examination_id: int | None = None,
) -> SystemCheckupExaminationDTO:
    return SystemCheckupExaminationDTO(
        system_checkup_examination_id if system_checkup_examination_id is not None else _next_id(),
        system_code,
        examination_code,
        gender,
    )
