"""Единая точка создания объектов в тестах с БД.

Сессия привязывается один раз фикстурой `factory`, поэтому db_session не протаскивается
через каждый вызов. Дефолты боевые: тест задаёт только то поле, про которое он написан.

Вставки строгие, без ON CONFLICT DO NOTHING. Тихое проглатывание конфликта означает,
что тест, считающий строку своей, на самом деле проверяет строку, засеянную миграцией:
такой тест зелёный ровно до тех пор, пока справочник не поменяют. Данные из справочников
берутся явно — через каталог, а не случайным попаданием в чужую строку.
"""

import itertools
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import NamedTuple
from uuid import UUID, uuid4

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from tests.consts import ANSWER_YES, BIOMARKER_CLINREC_INSTRUMENT_CODE

_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)

# Значение ответа, которого заведомо нет ни в одной строке parameter_scores: ответ есть,
# вклад в сумму баллов нулевой. Тест, которому нужен балл, сеет свою строку начисления.
UNSCORED_ANSWER = "__test_unscored__"

# (type, parameter_code, value, min_age, max_age) — как conditions читает гейт опросников.
ConditionRow = tuple[str, str, str | None, int | None, int | None]

# (status, reason_code) — как interpretation_statuses хранит каждую часть интерпретации.
StatusPair = tuple[str, str | None]

_DOCTOR_CODE_SEQ = itertools.count(10_000)

# biomarkers.biomarker_code — часть уникальной пары с unit_code; счётчик держит коды тестов
# в стороне от кодов справочника СберЗдоровья.
_BIOMARKER_CODE_SEQ = itertools.count(900_000)


class RiskFactorRow(NamedTuple):
    """Фактор риска отдаёт оба идентификатора: по id его находят тесты каталога,
    по trigger_code — тесты сопоставления."""

    risk_factor_id: int
    trigger_code: str | None

    @property
    def trigger(self) -> str:
        """Код триггера там, где тест на него ссылается. Без `parameter_code` триггера нет."""
        if self.trigger_code is None:
            raise AssertionError("фактор заведён без parameter_code — триггера у него нет")
        return self.trigger_code


def unique_doctor_code() -> int:
    """doctors.code — UNIQUE; счётчик от 10_000, чтобы не пересекаться с сидами миграций (макс 287)."""
    return next(_DOCTOR_CODE_SEQ)


def now_utc() -> datetime:
    return datetime.now(tz=UTC)


def unique_id(prefix: str) -> str:
    return f"{prefix}_{uuid4().hex[:8]}"


def unique_biomarker_code() -> int:
    """biomarkers.biomarker_code для тестов: заведомо не пересекается с наполнением справочника."""
    return next(_BIOMARKER_CODE_SEQ)


def unique_rang() -> int:
    """systems.rang — UNIQUE; смещение от 100, чтобы не конфликтовать с сидами миграций (0–13)."""
    return int(uuid4().int % 1_000_000) + 100


def validity_period_for_days(days: int) -> datetime:
    """parameters.validity_period хранится как TIMESTAMP, но семантически это длительность
    от UNIX-эпохи: expiration_date = now + (validity_period − epoch).
    См. src/services/risk_communication/domain/expiration.py."""
    return _EPOCH + timedelta(days=days)


class Factory:
    """Фабрики, привязанные к одной сессии теста."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def patient(self, *, patient_id: str | None = None, is_pregnant: bool | None = False) -> str:
        pid = patient_id or str(uuid4())
        await self._session.execute(
            text("INSERT INTO risk_profile.patients (patient_id, is_pregnant) VALUES (:pid, :preg)"),
            {"pid": pid, "preg": is_pregnant},
        )
        return pid

    async def parameter(
        self, code: str, *, validity_days: int = 30, status: str = "active", description: str = ""
    ) -> str:
        await self._session.execute(
            text(
                "INSERT INTO catalog.parameters (code, description, status, validity_period)"
                " VALUES (:code, :desc, :status, :validity)"
            ),
            {
                "code": code,
                "desc": description,
                "status": status,
                "validity": validity_period_for_days(validity_days),
            },
        )
        return code

    async def instrument(
        self,
        code: str,
        *,
        type: str = "manual",  # noqa: A002
        status: str = "active",
        description: str = "",
    ) -> str:
        await self._session.execute(
            text(
                "INSERT INTO catalog.instruments (code, description, type, status) VALUES (:code, :desc, :type,"
                " :status)"
            ),
            {"code": code, "desc": description, "type": type, "status": status},
        )
        return code

    async def biomarker_clinrec_instrument(self) -> str:
        """Отдаёт засеянный `biomarker_kr`, сняв с него связи справочника.

        Свой синтетический инструмент клинрек-расчёта тест завести не может: код канонического
        инструмента захардкожен в интерпретации (reader, пометка `done`, отбор строк системы), и
        строка с другим кодом до неё не дойдёт. Поэтому берём засеянную строку, но снимаем её
        13 систем и 53 параметра-биомаркера: иначе они попадали бы в набор систем
        calculation-event и в снимок значений пациента, и тест проверял бы справочник вместо
        своего сценария. Транзакция теста откатывается, поэтому справочник не страдает.
        """
        code = BIOMARKER_CLINREC_INSTRUMENT_CODE
        seeded = await self._session.execute(text("SELECT code FROM catalog.instruments WHERE code = :c"), {"c": code})
        if seeded.scalar_one_or_none() is None:
            raise AssertionError(f"instruments.{code} не засеян миграциями — снимать связи не с чего")
        await self._session.execute(
            text("DELETE FROM catalog.systems_instruments WHERE instrument_code = :c"), {"c": code}
        )
        await self._session.execute(
            text("DELETE FROM catalog.instruments_parameters WHERE instrument_code = :c"), {"c": code}
        )
        return code

    async def system(self, code: str | None = None, *, description: str = "", rang: int | None = None) -> str:
        scode = code or unique_id("SYS")
        await self._session.execute(
            text("INSERT INTO catalog.systems (code, description, rang) VALUES (:code, :desc, :rang)"),
            {"code": scode, "desc": description, "rang": rang if rang is not None else unique_rang()},
        )
        return scode

    async def disease(self, code: str | None = None, *, description: str = "", system_code: str | None = None) -> str:
        dcode = code or unique_id("DIS")
        system = system_code or await self.system()
        await self._session.execute(
            text("INSERT INTO catalog.diseases (code, description, system_code) VALUES (:code, :desc, :system)"),
            {"code": dcode, "desc": description or dcode, "system": system},
        )
        return dcode

    async def examination(
        self,
        code: UUID | None = None,
        *,
        name: str = "",
        examination_type: str = "laboratory",
        status: str = "active",
    ) -> UUID:
        ecode = code or uuid4()
        await self._session.execute(
            text(
                "INSERT INTO catalog.examinations (code, name, examination_type, status) VALUES (:code, :name, :type,"
                " :status)"
            ),
            {"code": ecode, "name": name or unique_id("EXAM"), "type": examination_type, "status": status},
        )
        return ecode

    async def disease_examination(
        self,
        *,
        disease_code: str,
        examination_code: UUID,
        category: str | None = None,
    ) -> None:
        """Связь группы заболеваний с исследованием; категория есть только у лабораторных."""
        await self._session.execute(
            text(
                "INSERT INTO disease_examinations (disease_code, examination_code, category)"
                " VALUES (:disease, :exam, :category)"
            ),
            {"disease": disease_code, "exam": examination_code, "category": category},
        )

    async def system_checkup_examination(
        self,
        *,
        system_code: str,
        examination_code: UUID,
        gender: str | None = None,
    ) -> None:
        """Строка общего чек-апа системы; пустой gender — без ограничения по полу."""
        await self._session.execute(
            text(
                "INSERT INTO system_checkup_examinations (system_code, examination_code, gender)"
                " VALUES (:system, :exam, :gender)"
            ),
            {"system": system_code, "exam": examination_code, "gender": gender},
        )

    async def link_system_instrument(self, *, system_code: str, instrument_code: str) -> None:
        await self._session.execute(
            text("INSERT INTO catalog.systems_instruments (system_code, instrument_code) VALUES (:s, :i)"),
            {"s": system_code, "i": instrument_code},
        )

    async def link_parameter(self, *, instrument_code: str, parameter_code: str, is_required: bool = True) -> None:
        await self._session.execute(
            text(
                "INSERT INTO catalog.instruments_parameters (instrument_code, parameter_code, is_required)"
                " VALUES (:i, :p, :req)"
            ),
            {"i": instrument_code, "p": parameter_code, "req": is_required},
        )

    async def question(
        self,
        code: str | None = None,
        *,
        type: str = "select",  # noqa: A002
        group_code: int = 2,
        is_skippable: bool = False,
        question_text: str = "вопрос",
    ) -> str:
        qcode = code or unique_id("Q")
        await self._session.execute(
            text(
                "INSERT INTO catalog.questions (code, question, type, group_code, is_skippable)"
                " VALUES (:code, :q, :type, :gc, :skip)"
            ),
            {"code": qcode, "q": question_text, "type": type, "gc": group_code, "skip": is_skippable},
        )
        return qcode

    async def option(
        self,
        code: str | None = None,
        *,
        question_code: str,
        parameter_code: str,
        value: str | None = ANSWER_YES,
    ) -> str:
        ocode = code or unique_id("OPT")
        await self._session.execute(
            text(
                "INSERT INTO catalog.options (code, value, question_code, parameter_code) VALUES (:code, :value, :q,"
                " :p)"
            ),
            {"code": ocode, "value": value, "q": question_code, "p": parameter_code},
        )
        return ocode

    async def biomarker(
        self,
        *,
        parameter_code: str,
        biomarker_code: int | None = None,
        unit_code: int | None = None,
        unit: str | None = None,
        name: str = "биомаркер",
        type: str = "quantitative",  # noqa: A002
    ) -> int:
        """Строка справочника `biomarkers` — биомаркер в одной допустимой единице измерения.

        `unit` и `unit_code` заполнены либо пусты одновременно (ограничение таблицы), поэтому
        подпись единицы достраивается по её коду, если тест задал только код.
        """
        code = biomarker_code if biomarker_code is not None else unique_biomarker_code()
        await self._session.execute(
            text(
                "INSERT INTO catalog.biomarkers (biomarker_code, unit_code, parameter_code, name, type, unit)"
                " VALUES (:code, :unit_code, :parameter, :name, :type, :unit)"
            ),
            {
                "code": code,
                "unit_code": unit_code,
                "parameter": parameter_code,
                "name": name,
                "type": type,
                "unit": unit if unit is not None or unit_code is None else f"ед. {unit_code}",
            },
        )
        return code

    async def biomarker_mapping(
        self,
        *,
        biomarker_parameter_code: str,
        parameter_code: str,
        mapping_type: str = "value",
        operator: str | None = None,
        value_num: Decimal | None = None,
        value_text: str | None = None,
        option_code: str | None = None,
        unit: str | None = None,
    ) -> None:
        """Строка разметки «биомаркер заполняет параметр опросника»."""
        await self._session.execute(
            text(
                "INSERT INTO catalog.biomarker_parameter_mappings"
                " (biomarker_parameter_code, parameter_code, mapping_type, operator, value_num,"
                " value_text, option_code, unit)"
                " VALUES (:source, :parameter, :mapping_type, :operator, :value_num, :value_text,"
                " :option, :unit)"
            ),
            {
                "source": biomarker_parameter_code,
                "parameter": parameter_code,
                "mapping_type": mapping_type,
                "operator": operator,
                "value_num": value_num,
                "value_text": value_text,
                "option": option_code,
                "unit": unit,
            },
        )

    async def answer(
        self,
        *,
        patient_id: str,
        parameter_code: str,
        value: str | None,
        source: str = "test",
        external_id: int | None = None,
        expiration_date: datetime | None = None,
        date_time: datetime | None = None,
    ) -> None:
        """`external_id` заполнен только у записей из ЭМК: вместе с `source` он отличает биомаркер
        от антропометрии того же происхождения, и сброс ответов различает их именно по этой паре."""
        exp = expiration_date or datetime.now(tz=UTC) + timedelta(days=30)
        if date_time is None:
            # date_time не задан → server_default=now(); задан → пишем явно (проверки архивации).
            await self._session.execute(
                text(
                    "INSERT INTO risk_profile.patients_parameters"
                    " (patient_id, parameter_code, value, source, external_id,"
                    " expiration_date)"
                    " VALUES (:pid, :p, :v, :src, :ext, :exp)"
                ),
                {"pid": patient_id, "p": parameter_code, "v": value, "src": source, "ext": external_id, "exp": exp},
            )
            return
        await self._session.execute(
            text(
                "INSERT INTO risk_profile.patients_parameters"
                " (patient_id, parameter_code, value, source, external_id, expiration_date, date_time)"
                " VALUES (:pid, :p, :v, :src, :ext, :exp, :dt)"
            ),
            {
                "pid": patient_id,
                "p": parameter_code,
                "v": value,
                "src": source,
                "ext": external_id,
                "exp": exp,
                "dt": date_time,
            },
        )

    async def expire_answer(self, *, patient_id: str, parameter_code: str) -> None:
        """Двигает expiration_date в прошлое — как это делает soft-invalidate risk-event."""
        await self._session.execute(
            text(
                "UPDATE risk_profile.patients_parameters SET expiration_date = now() - INTERVAL '1 day'"
                " WHERE patient_id = :pid AND parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )

    async def link_system(self, *, instrument_code: str, system_code: str | None = None) -> str:
        """Кладёт инструмент в систему, создавая её при необходимости. Возвращает код системы.

        Гейт опросников считает вопросы СИСТЕМЫ инструмента, поэтому инструмент без строки
        `systems_instruments` даёт пустой знаменатель.
        """
        scode = system_code if system_code is not None else await self.system(f"SYS_{instrument_code}")
        await self.link_system_instrument(system_code=scode, instrument_code=instrument_code)
        return scode

    async def parameter_score(
        self,
        *,
        parameter_code: str,
        system_code: str,
        score: Decimal | float,
        value: str | None = None,
        min_value: Decimal | float | None = None,
        max_value: Decimal | float | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO catalog.parameter_scores (parameter_code, system_code, value, min_value, max_value, score)"
                " VALUES (:p, :s, :val, :mn, :mx, :score)"
            ),
            {
                "p": parameter_code,
                "s": system_code,
                "val": value,
                "mn": min_value,
                "mx": max_value,
                "score": score,
            },
        )

    async def condition(
        self,
        *,
        question_code: str,
        parameter_code: str,
        type: str = "except",  # noqa: A002
        value: str | None = None,
        min_age: int | None = None,
        max_age: int | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO catalog.conditions (type, question_code, parameter_code, value, min_age, max_age)"
                " VALUES (:type, :q, :p, :val, :mn, :mx)"
            ),
            {"type": type, "q": question_code, "p": parameter_code, "val": value, "mn": min_age, "mx": max_age},
        )

    async def question_with_options(
        self,
        question_code: str,
        parameter_codes: Sequence[str],
        *,
        instrument_code: str | None = None,
        group_code: int = 2,
        conditions: Sequence[ConditionRow] = (),
    ) -> str:
        """Вопрос со своими параметрами (по опции на параметр) и, если задан, условиями показа.

        Гейт опросников считается в ВОПРОСАХ, поэтому тесту мало `instruments_parameters`:
        параметр попадает в знаменатель только через `options.question_code`. `instrument_code`
        линкует все параметры вопроса к инструменту.

        Параметры из `parameter_codes` создаются здесь; параметры из `conditions` — НЕТ.
        Условие ссылается либо на боевой параметр из сидов миграций (`gender`, `age`), либо на
        синтетический, который тест завёл сам: создавать его здесь значило бы вернуть
        ON CONFLICT DO NOTHING и снова прятать попадание в чужую строку.
        """
        await self.question(question_code, group_code=group_code, question_text="")
        for index, parameter_code in enumerate(parameter_codes, start=1):
            await self.parameter(parameter_code)
            await self.option(
                f"{question_code}_{index:02d}",
                question_code=question_code,
                parameter_code=parameter_code,
                value=ANSWER_YES,
            )
            if instrument_code is not None:
                await self.link_parameter(
                    instrument_code=instrument_code, parameter_code=parameter_code, is_required=False
                )
        for condition_type, parameter_code, value, min_age, max_age in conditions:
            await self.condition(
                question_code=question_code,
                parameter_code=parameter_code,
                type=condition_type,
                value=value,
                min_age=min_age,
                max_age=max_age,
            )
        return question_code

    async def answer_question(self, *, patient_id: str, question_code: str, value: str = UNSCORED_ANSWER) -> list[str]:
        """Отвечает на вопрос ЦЕЛИКОМ: по строке patients_parameters на каждый параметр опций.

        «Отвечен» = актуальная запись по КАЖДОМУ параметру вопроса, поэтому частичный ответ
        вопрос не засчитывает (см. src/calc/domain/eligibility.py).
        """
        result = await self._session.execute(
            text("SELECT DISTINCT parameter_code FROM catalog.options WHERE question_code = :q"),
            {"q": question_code},
        )
        answered = [pcode for (pcode,) in result.all()]
        for pcode in answered:
            await self.answer(patient_id=patient_id, parameter_code=pcode, value=value)
        return answered

    async def answer_all_general_params(self, *, patient_id: str, values: dict[str, str] | None = None) -> list[str]:
        """Отвечает на каждый параметр «Общих данных» — вопросы с group_code=1 из сидов миграций.

        `values` переопределяет плейсхолдер по коду параметра: там, где гейт разбирает ответ по
        существу (`gender` в `except`-условиях, `birthdate` в `age`-условиях), 'true' полом
        не является и датой не парсится.
        """
        result = await self._session.execute(
            text(
                "SELECT DISTINCT o.parameter_code"
                " FROM catalog.options o JOIN catalog.questions q ON q.code = o.question_code"
                " WHERE q.group_code = 1 AND o.parameter_code IS NOT NULL"
            )
        )
        answered = [pcode for (pcode,) in result.all()]
        for pcode in answered:
            await self.answer(patient_id=patient_id, parameter_code=pcode, value=(values or {}).get(pcode, "true"))
        return answered

    async def answer_real_common_questions(self, *, patient_id: str, exclude: set[str] | None = None) -> list[str]:
        """Отвечает за все параметры «Общих данных» (group_code=1) из сидов миграций.

        Отличается от `answer_all_general_params` значением ответа: здесь плейсхолдер 'yes',
        и разбирать его по существу тесты этого хелпера не просят. `exclude` оставляет параметр
        без ответа — для тестов, которые задают его сами.
        """
        return await self._answer_question_params(patient_id=patient_id, exclude=exclude, group_codes=[1])

    async def answer_all_real_question_params(self, *, patient_id: str, exclude: set[str] | None = None) -> list[str]:
        """Отвечает за параметры ВСЕХ вопросов реального каталога, любой group_code.

        Нужен тестам, которые хотят увидеть в выдаче один конкретный вопрос: всё остальное
        уже отвечено, поэтому кандидат остаётся единственным. `exclude` — его собственный параметр.
        """
        return await self._answer_question_params(patient_id=patient_id, exclude=exclude, group_codes=None)

    async def answer_system_params(
        self, *, patient_id: str, system_code: str, exclude: set[str] | None = None
    ) -> list[str]:
        """Отвечает за каждый параметр любого инструмента системы — «система пройдена целиком»."""
        rows = await self._session.execute(
            text(
                "SELECT DISTINCT ip.parameter_code"
                " FROM catalog.instruments_parameters ip"
                " JOIN catalog.systems_instruments si ON si.instrument_code = ip.instrument_code"
                " WHERE si.system_code = :s"
            ),
            {"s": system_code},
        )
        return await self._answer_each(patient_id=patient_id, codes=[c for (c,) in rows.all()], exclude=exclude)

    async def _answer_question_params(
        self, *, patient_id: str, exclude: set[str] | None, group_codes: list[int] | None
    ) -> list[str]:
        if group_codes is None:
            rows = await self._session.execute(
                text("SELECT DISTINCT o.parameter_code FROM catalog.options o WHERE o.parameter_code IS NOT NULL")
            )
        else:
            rows = await self._session.execute(
                text(
                    "SELECT DISTINCT o.parameter_code"
                    " FROM catalog.options o JOIN catalog.questions q ON q.code = o.question_code"
                    " WHERE q.group_code = ANY(:groups) AND o.parameter_code IS NOT NULL"
                ),
                {"groups": group_codes},
            )
        return await self._answer_each(patient_id=patient_id, codes=[c for (c,) in rows.all()], exclude=exclude)

    async def _answer_each(self, *, patient_id: str, codes: list[str], exclude: set[str] | None) -> list[str]:
        """Отвечает 'yes' за каждый код, пропуская исключённые и уже отвеченные.

        Наборы этих хелперов пересекаются (система и «Общие данные» делят параметры), поэтому
        пропуск уже отвеченного обязателен: вторая строка по той же паре удвоила бы вклад
        в сумму баллов и в счёт гейта.
        """
        exclude = exclude or set()
        existing = await self._session.execute(
            text("SELECT parameter_code FROM risk_profile.patients_parameters WHERE patient_id = :p"),
            {"p": patient_id},
        )
        already = {pcode for (pcode,) in existing.all()}
        answered: list[str] = []
        for pcode in codes:
            if pcode in exclude or pcode in already:
                continue
            await self.answer(patient_id=patient_id, parameter_code=pcode, value="yes", source="test-seed")
            answered.append(pcode)
        return answered

    async def make_questionnaire(self, code: str) -> str:
        """Переводит УЖЕ существующий инструмент в тип «опросник».

        Боевые коды (`InstrumentsCodes.CVD` и прочие) заводит миграция, поэтому тест не вставляет
        их заново, а меняет тип у своей строки. rowcount проверяется: если миграция перестала
        сеять этот код, тест должен упасть здесь, а не молча считать пустой опросник.
        """
        updated = (
            await self._session.execute(
                text("UPDATE catalog.instruments SET type = :t WHERE code = :c RETURNING code"),
                {"t": "form", "c": code},
            )
        ).scalar_one_or_none()
        if updated is None:
            raise AssertionError(f"instruments.{code} не засеян миграциями — переводить в опросник нечего")
        return code

    async def answer_instrument_params(
        self, *, patient_id: str, instrument_code: str, value: str = UNSCORED_ANSWER, limit: int | None = None
    ) -> list[str]:
        """Отвечает за реальные параметры инструмента (не больше `limit`).

        Уже отвеченные пациентом параметры пропускаются: дубль строки удвоил бы вклад
        в сумму баллов и в счёт гейта.
        """
        params = await self._session.execute(
            text(
                "SELECT parameter_code FROM catalog.instruments_parameters WHERE instrument_code = :i ORDER BY"
                " parameter_code"
            ),
            {"i": instrument_code},
        )
        codes = [pcode for (pcode,) in params.all()]
        if limit is not None:
            codes = codes[:limit]
        existing = await self._session.execute(
            text("SELECT parameter_code FROM risk_profile.patients_parameters WHERE patient_id = :p"),
            {"p": patient_id},
        )
        already = {pcode for (pcode,) in existing.all()}
        inserted: list[str] = []
        for pcode in codes:
            if pcode in already:
                continue
            await self.answer(patient_id=patient_id, parameter_code=pcode, value=value)
            inserted.append(pcode)
        return inserted

    async def result(
        self,
        *,
        patient_id: str,
        instrument_code: str,
        indicator: str = "result",
        disease_code: str | None = None,
        value: str | float | None = None,
        unit: str | None = None,
        risk_level: str | None = None,
        applicability: bool = True,
        interpretation_status: str = "ready",
        expiration_date: datetime | None = None,
        date_time: datetime | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO risk_calculation.results"
                " (patient_id, instrument_code, indicator, disease_code, value, unit, risk_level,"
                "  applicability, interpretation_status, expiration_date, date_time)"
                " VALUES (:pid, :i, :ind, :disease, :v, :unit, :rl, :app, :istatus, :exp, :dt)"
            ),
            {
                "pid": patient_id,
                "i": instrument_code,
                "ind": indicator,
                "disease": disease_code,
                "v": value,
                "unit": unit,
                "rl": risk_level,
                "app": applicability,
                "istatus": interpretation_status,
                "exp": expiration_date if expiration_date is not None else now_utc() + timedelta(days=30),
                "dt": date_time if date_time is not None else now_utc(),
            },
        )

    async def calc_status(
        self,
        *,
        patient_id: str,
        instrument_code: str,
        status: str,
        date_time: datetime | None = None,
        reason_code: str | None = None,
        missing_parameter_codes: list[str] | None = None,
        applicable_questions: int | None = None,
        progressed_questions: int | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO risk_calculation.calculation_statuses"
                " (patient_id, instrument_code, status, reason_code, date_time, missing_parameter_codes,"
                "  applicable_questions, progressed_questions)"
                " VALUES (:pid, :i, :status, :reason, :dt, :missing, :applicable, :progressed)"
            ),
            {
                "pid": patient_id,
                "i": instrument_code,
                "status": status,
                "reason": reason_code,
                "dt": date_time if date_time is not None else now_utc(),
                "missing": missing_parameter_codes,
                "applicable": applicable_questions,
                "progressed": progressed_questions,
            },
        )

    async def interpretation(
        self,
        *,
        patient_id: str,
        system_code: str,
        date_time: datetime | None = None,
        risk_level: str | None = None,
        text_value: str | None = None,
        diseases: list[str] | None = None,
        risk_factors_code: list[str] | None = None,
        doctors_code: list[str] | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO risk_calculation.interpretations"
                " (patient_id, system_code, risk_level, text, diseases, risk_factors_code, doctors_code, date_time)"
                " VALUES (:pid, :s, :rl, :txt, :d, :rf, :doc, :dt)"
            ),
            {
                "pid": patient_id,
                "s": system_code,
                "rl": risk_level,
                "txt": text_value,
                "d": diseases,
                "rf": risk_factors_code,
                "doc": doctors_code,
                "dt": date_time if date_time is not None else now_utc(),
            },
        )

    async def interpretation_status(
        self,
        *,
        patient_id: str,
        system_code: str,
        date_time: datetime | None = None,
        risk_level: StatusPair = ("computed", None),
        diseases: StatusPair = ("computed", None),
        risk_factors: StatusPair = ("computed", None),
        doctors: StatusPair = ("computed", None),
        blocking_instrument_codes: list[str] | None = None,
    ) -> None:
        """Каждая часть интерпретации — пара (status, reason_code), как её хранит таблица."""
        await self._session.execute(
            text(
                "INSERT INTO risk_calculation.interpretation_statuses"
                " (patient_id, system_code, risk_level_status, risk_level_reason_code, diseases_status,"
                "  diseases_reason_code, risk_factors_status, risk_factors_reason_code, doctors_status,"
                "  doctors_reason_code, blocking_instrument_codes, date_time)"
                " VALUES (:pid, :s, :rls, :rlr, :ds, :dr, :rfs, :rfr, :docs, :docr, :blocking, :dt)"
            ),
            {
                "pid": patient_id,
                "s": system_code,
                "rls": risk_level[0],
                "rlr": risk_level[1],
                "ds": diseases[0],
                "dr": diseases[1],
                "rfs": risk_factors[0],
                "rfr": risk_factors[1],
                "docs": doctors[0],
                "docr": doctors[1],
                "blocking": blocking_instrument_codes,
                "dt": date_time if date_time is not None else now_utc(),
            },
        )

    async def risk_factor(
        self,
        code: str,
        *,
        system_code: str,
        parameter_code: str | None = None,
        description: str = "",
        modifiability: str = "modifiable",
        reasoning: str | None = None,
        param_value: str | None = None,
        min_param_value: str | None = None,
        max_param_value: str | None = None,
        trigger_code: str | None = None,
    ) -> RiskFactorRow:
        """Фактор риска, его привязка к системе и — если задан `parameter_code` — триггер.

        Без `parameter_code` строка `risk_factor_triggers` НЕ пишется: тестам medical-risk триггер
        не нужен, они читают фактор и его привязку к системе, а лишний триггер поменял бы то,
        что подбирает сопоставление факторов.
        """
        risk_factor_id = (
            await self._session.execute(
                text(
                    "INSERT INTO catalog.risk_factors (code, description, modifiability) VALUES (:c, :d, :m)"
                    " RETURNING risk_factor_id"
                ),
                {"c": code, "d": description, "m": modifiability},
            )
        ).scalar_one()
        await self._session.execute(
            text(
                "INSERT INTO catalog.risk_factor_systems (risk_factor_code, system_code, reasoning) VALUES (:c, :s, :r)"
            ),
            {"c": code, "s": system_code, "r": reasoning},
        )
        if parameter_code is None:
            return RiskFactorRow(risk_factor_id, None)
        return RiskFactorRow(
            risk_factor_id,
            await self.risk_factor_trigger(
                code=code,
                system_code=system_code,
                parameter_code=parameter_code,
                param_value=param_value,
                min_param_value=min_param_value,
                max_param_value=max_param_value,
                trigger_code=trigger_code,
            ),
        )

    async def link_risk_factor_system(
        self, *, risk_factor_code: str, system_code: str, reasoning: str | None = None
    ) -> None:
        """Ещё одна система у уже заведённого фактора — представление фактора в ней.

        Отдельно от `risk_factor`, потому что фактор бывает представлен в системе, по которой у него
        нет ни одного условия: клинрек-условие задано на биомаркере и от системы не зависит.
        """
        await self._session.execute(
            text(
                "INSERT INTO catalog.risk_factor_systems (risk_factor_code, system_code, reasoning) VALUES (:c, :s, :r)"
            ),
            {"c": risk_factor_code, "s": system_code, "r": reasoning},
        )

    async def risk_factor_trigger(
        self,
        *,
        code: str,
        system_code: str,
        parameter_code: str,
        param_value: str | None = None,
        min_param_value: str | None = None,
        max_param_value: str | None = None,
        trigger_code: str | None = None,
    ) -> str:
        """Ещё один бакет уже заведённого фактора: один фактор — много триггеров.

        Отдельный метод, а не upsert внутри `risk_factor`: повторная вставка родителя молча
        прошла бы и по строке из сидов миграций, а здесь тест явно говорит, что родитель его.
        """
        is_text = param_value is not None
        identity = param_value if is_text else f"{min_param_value}-{max_param_value}"
        tcode = trigger_code or f"{code}__{system_code}__{parameter_code}__{identity}"
        await self._session.execute(
            text(
                "INSERT INTO catalog.risk_factor_triggers"
                " (trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator,"
                "  value_text, min_value, max_value)"
                " VALUES (:tc, :c, :s, :p, :vt, :op, :pv, :mn, :mx)"
            ),
            {
                "tc": tcode,
                "c": code,
                "s": system_code,
                "p": parameter_code,
                "vt": "text" if is_text else "number",
                "op": "eq" if is_text else "between",
                "pv": param_value,
                "mn": min_param_value,
                "mx": max_param_value,
            },
        )
        return tcode

    async def risk_factor_score(
        self,
        *,
        risk_factor_code: str,
        disease_code: str,
        score: int = 3,
        influence: str = "increase",
    ) -> None:
        """Балл фактора риска в группе заболеваний — вход клинрек-расчёта.

        Балл ровно 3 отбирает фактор и в расчёт `biomarker_kr`, и в клинрек-блок интерпретации,
        поэтому он же стоит дефолтом.
        """
        await self._session.execute(
            text(
                "INSERT INTO catalog.risk_factor_scores (risk_factor_code, disease_code, score, influence)"
                " VALUES (:c, :d, :score, :i)"
            ),
            {"c": risk_factor_code, "d": disease_code, "score": score, "i": influence},
        )

    async def risk_factor_match(
        self,
        *,
        patient_id: str,
        code: str,
        system_code: str,
        trigger_code: str,
        parameter_code: str,
        date_time: datetime | None = None,
        param_value: str | None = None,
        min_param_value: str | None = None,
        max_param_value: str | None = None,
        modifiability: str = "modifiable",
        is_representative: bool = True,
        factor_description: str | None = None,
        reasoning: str | None = None,
    ) -> None:
        """Сработавший фактор.

        По умолчанию описание и обоснование копируются из справочника, как это делает бой, —
        для этого фактор и его привязка к системе должны существовать. Явные
        `factor_description`/`reasoning` пишут строку без справочника: так тесты чистки
        диагностики заводят совпадение, не заводя сам фактор.
        """
        is_text = param_value is not None
        if factor_description is not None:
            await self._session.execute(
                text(
                    "INSERT INTO risk_calculation.risk_factor_matches"
                    " (patient_id, system_code, trigger_code, risk_factor_code, factor_description, reasoning,"
                    "  parameter_code, value_type, operator, value_text, min_value, max_value, modifiability,"
                    "  is_representative, date_time)"
                    " VALUES (:pid, :s, :tc, :c, :desc, :reason, :p, :vt, :op, :pv, :mn, :mx, :m, :rep, :dt)"
                ),
                {
                    "pid": patient_id,
                    "s": system_code,
                    "tc": trigger_code,
                    "c": code,
                    "desc": factor_description,
                    "reason": reasoning,
                    "p": parameter_code,
                    "vt": "text" if is_text else "number",
                    "op": "eq" if is_text else "between",
                    "pv": param_value,
                    "mn": min_param_value,
                    "mx": max_param_value,
                    "m": modifiability,
                    "rep": is_representative,
                    "dt": date_time if date_time is not None else now_utc(),
                },
            )
            return
        await self._session.execute(
            text(
                "INSERT INTO risk_calculation.risk_factor_matches"
                " (patient_id, system_code, trigger_code, risk_factor_code, factor_description, reasoning,"
                "  parameter_code, value_type, operator, value_text, min_value, max_value, modifiability,"
                "  is_representative, date_time)"
                " SELECT :pid, :s, :tc, CAST(:c AS VARCHAR), rf.description, rfs.reasoning,"
                "  :p, :vt, :op, :pv, :mn, :mx, :m, :rep, :dt"
                " FROM catalog.risk_factors rf JOIN catalog.risk_factor_systems rfs"
                "  ON rfs.risk_factor_code = rf.code AND rfs.system_code = :s"
                " WHERE rf.code = CAST(:c AS VARCHAR)"
            ),
            {
                "pid": patient_id,
                "s": system_code,
                "tc": trigger_code,
                "c": code,
                "p": parameter_code,
                "vt": "text" if is_text else "number",
                "op": "eq" if is_text else "between",
                "pv": param_value,
                "mn": min_param_value,
                "mx": max_param_value,
                "m": modifiability,
                "rep": is_representative,
                "dt": date_time if date_time is not None else now_utc(),
            },
        )

    async def recommendation(
        self,
        *,
        system_code: str,
        name: str,
        recommendations_group: str,
        risk_factors_code: str | None = None,
        text_value: str | None = None,
    ) -> None:
        await self._session.execute(
            text(
                "INSERT INTO catalog.recommendations (recommendations_group, risk_factors_code, system_code, name,"
                " text)"
                " VALUES (:grp, :rfc, :s, :name, :txt)"
            ),
            {"grp": recommendations_group, "rfc": risk_factors_code, "s": system_code, "name": name, "txt": text_value},
        )

    async def doctor(self, *, code: int | None = None, description: str) -> int:
        dcode = code if code is not None else unique_doctor_code()
        await self._session.execute(
            text("INSERT INTO catalog.doctors (code, description) VALUES (:code, :desc)"),
            {"code": dcode, "desc": description},
        )
        return dcode

    async def set_instrument_diseases(self, *, instrument_code: str, diseases: list[str] | None) -> None:
        """Список диагностик инструмента — колонка справочника, а не своя строка."""
        await self._session.execute(
            text("UPDATE catalog.instruments SET diseases = :d WHERE code = :code"),
            {"d": diseases, "code": instrument_code},
        )

    async def clear_recommendations(self) -> None:
        """Удаляет каталог recommendations внутри текущей транзакции.

        Каталог сидится миграцией, а тесты точного состава рекомендаций считают строки —
        rollback в конце теста восстанавливает справочник.
        """
        await self._session.execute(text("DELETE FROM catalog.recommendations"))

    async def unlink_system_instruments(self, *, system_code: str) -> None:
        """Отвязывает инструменты каталога от системы внутри текущей транзакции.

        systems.rang UNIQUE и занят реальными системами (0–13), а systemPriority в ответе
        medical-risk ограничен ≤13 — поэтому синтетическая система невозможна и тест
        переиспользует реальный код. Чтобы applicable/progressed считались ТОЛЬКО по вопросам
        теста, реальная связка system↔instrument зачищается; rollback восстанавливает.
        FK-безопасно: на systems_instruments никто не ссылается.
        """
        await self._session.execute(
            text("DELETE FROM catalog.systems_instruments WHERE system_code = :s"),
            {"s": system_code},
        )

    async def instrument_with_params(
        self,
        code: str | None = None,
        *,
        required: Sequence[str] = (),
        optional: Sequence[str] = (),
        system_code: str | None = None,
        in_system: bool = True,
        status: str = "active",
        description: str = "",
        create_parameters: bool = True,
        type: str = "calc",  # noqa: A002 — имя колонки
    ) -> str:
        """Инструмент со своими параметрами и системой — самая частая связка в тестах.

        Строка systems_instruments обязательна: гейт опросников считает вопросы СИСТЕМЫ
        инструмента, и без неё знаменатель гейта пустой. `in_system=False` эту строку не пишет —
        для тестов, которым нужен инструмент ВНЕ системы, и разница для них существенна.

        `create_parameters=False` — когда параметры уже заведены (справочником или соседним
        инструментом) и нужна только строка связи: строгая вставка второй строки parameters упала бы.
        """
        icode = code or unique_id("I")
        # Тип по умолчанию — `calc`: помощник заводит инструмент, который что-то считает, а
        # каталог маршрутизирует расчёт по явному типу (см. CalcCatalog).
        await self.instrument(icode, status=status, description=description, type=type)
        if in_system:
            scode = system_code or await self.system()
            await self.link_system_instrument(system_code=scode, instrument_code=icode)
        for pcode, is_required in [(p, True) for p in required] + [(p, False) for p in optional]:
            if create_parameters:
                await self.parameter(pcode)
            await self.link_parameter(instrument_code=icode, parameter_code=pcode, is_required=is_required)
        return icode
