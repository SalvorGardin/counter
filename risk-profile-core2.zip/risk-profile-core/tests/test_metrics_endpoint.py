"""Тесты экспозиции метрик Prometheus (GET /metrics) и каркаса src/metrics.py."""

import json
import os
import subprocess
import sys
from collections.abc import Generator
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient
from prometheus_client import CONTENT_TYPE_LATEST, REGISTRY, Counter
from prometheus_client.mmap_dict import mmap_key
from prometheus_client.parser import text_string_to_metric_families

from src import main as main_module
from src.config import settings
from src.infra.kafka.lag_probe import RecalcLagProbe
from src.main import app
from src.metrics import (
    BACKGROUND_ADMITTED,
    BACKGROUND_REASON_NONE,
    ERRORS_TOTAL,
    HOSTNAME,
    RECALC_BACKGROUND_COMMANDS,
    RECALC_OUTCOMES,
    RECALC_SCOPE_PARTIAL,
    RECALC_SCOPES,
    RECALC_SOURCE_BACKGROUND,
    RECALC_SOURCES,
    RECALC_TIMING_BUCKETS,
    SERVICE_PREFIX,
    init_metrics,
    render,
)
from src.metrics_multiproc import MULTIPROC_ENV, prepare_multiproc_dir

client = TestClient(app)

_TEST_VERSION = "1.2.3-test"

_RECALC_HISTOGRAMS = (
    f"{SERVICE_PREFIX}_recalc_answer_to_result_seconds",
    f"{SERVICE_PREFIX}_recalc_queue_wait_seconds",
    f"{SERVICE_PREFIX}_recalc_duration_seconds",
)


def assert_no_duplicate_type_lines(body: str) -> None:
    """Ни одно имя метрики не должно объявляться дважды. Также запрещаем лейбл `pid`: его несёт
    ТОЛЬКО метрика, утёкшая из mmap в LOCAL_REGISTRY-выдачу, — самый дешёвый страж инварианта.
    """
    type_names = [line.split()[2] for line in body.splitlines() if line.startswith("# TYPE ")]
    assert len(type_names) == len(set(type_names)), f"дубли блоков TYPE: {type_names}"
    assert "pid=" not in body, f"лейбл pid в выдаче — метрика утекла из mmap:\n{body}"


@pytest.fixture(autouse=True)
def _init_metrics() -> None:
    """TestClient без контекст-менеджера не запускает lifespan, а build_info регистрируется
    именно там — поднимаем коллектор явно, как это сделал бы старт приложения."""
    init_metrics(_TEST_VERSION)


def test_metrics_endpoint_returns_prometheus_text() -> None:
    response = client.get("/metrics")
    assert response.status_code == 200
    # Сверяем с константой библиотеки, а не с её текущим значением: бамп prometheus-client
    # меняет версию формата в заголовке, и хардкод уронил бы тест без функциональной причины.
    assert response.headers["content-type"] == CONTENT_TYPE_LATEST


def test_metrics_exposes_build_info_with_version() -> None:
    body = client.get("/metrics").text
    assert f'risk_profile_core_build_info{{version="{_TEST_VERSION}"}} 1.0' in body


def test_metrics_output_is_parseable_and_prefixed() -> None:
    """Выдача должна парситься штатным парсером Prometheus и содержать ТОЛЬКО наши метрики:
    штатные python_*/process_* сняты с default REGISTRY, иначе локальная выдача расходилась бы
    со стендовой (в multiproc-режиме их там нет физически)."""
    families = list(text_string_to_metric_families(client.get("/metrics").text))
    assert families, "выдача не должна быть пустой"
    assert all(f.name.startswith("risk_profile_core") for f in families), [f.name for f in families]


def test_metrics_has_no_duplicate_metric_families() -> None:
    """Два реестра в одной выдаче: имя, попавшее в оба, дало бы второй блок HELP/TYPE на имя.

    Проверяем по СЫРОМУ тексту, а не через text_string_to_metric_families: парсер молча
    склеивает СМЕЖНЫЕ одноимённые семейства в одно (проверено), поэтому ассерт на его выводе
    ловит дубль только когда тому случайно повезло оказаться несмежным — то есть держится на
    порядке коллекторов, а не на инварианте.
    """
    assert_no_duplicate_type_lines(client.get("/metrics").text)


def test_lag_metrics_absent_when_kafka_disabled() -> None:
    """kafka.enabled=false → проба лага не поднимается, recalc_queue_lag* в выдаче нет вообще."""
    body = client.get("/metrics").text
    assert "risk_profile_core_recalc_queue_lag" not in body


async def test_lag_probe_registered_when_enabled_exposes_lag_ok_then_unregisters() -> None:
    """Проверяет реальную проводку _init_lag_probe/_shutdown_lag_probe: при kafka+metrics enabled
    коллектор регистрируется ДО старта клиентов (lag_ok=0 виден даже без опроса), а shutdown его
    снимает. start() мокаем — реальный брокер не поднимаем."""
    with (
        patch.object(settings.kafka, "enabled", True),
        patch.object(settings.metrics, "enabled", True),
        patch.object(RecalcLagProbe, "start", AsyncMock()),
    ):
        try:
            await main_module._init_lag_probe()
            assert main_module._lag_probe is not None
            assert "risk_profile_core_recalc_queue_lag_ok 0.0" in render().decode()
        finally:
            await main_module._shutdown_lag_probe()
    assert main_module._lag_probe is None
    assert "risk_profile_core_recalc_queue_lag_ok" not in render().decode()


def test_metrics_disabled_returns_404() -> None:
    with patch.object(settings.metrics, "enabled", False):
        response = client.get("/metrics")
    assert response.status_code == 404


def test_metrics_path_not_logged_as_request_completed() -> None:
    """Скрейп раз в 15 с вечно — в NOTICE ему делать нечего (как и пробам)."""
    with patch("src.main.notice") as mock_notice:
        client.get("/metrics")
    assert not [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]


def test_recalc_histograms_series_exist_before_any_recalc() -> None:
    """Ряды всех комбинаций меток видны с момента старта процесса.

    Без предынициализации `increase()` и `histogram_quantile()` увидели бы не рождение счётчика
    в нуле, а появление ряда из ниоткуда, а проверка готовности на тихом стенде зависела бы от
    того, случился ли уже хоть один пересчёт.
    """
    missing = [
        (name, outcome, scope, source)
        for name in _RECALC_HISTOGRAMS
        for outcome in RECALC_OUTCOMES
        for scope in RECALC_SCOPES
        for source in RECALC_SOURCES
        if not (scope == RECALC_SCOPE_PARTIAL and source == RECALC_SOURCE_BACKGROUND)
        if REGISTRY.get_sample_value(f"{name}_count", {"outcome": outcome, "scope": scope, "source": source}) is None
    ]
    assert not missing


def test_partial_background_series_is_not_preinitialized() -> None:
    """Массовый прогон публикует только полный пересчёт, поэтому ряда `partial`×`background` нет.

    Постоянный ноль в выдаче читался бы как «такого не случается» наравне с настоящими нулями
    остальных комбинаций.
    """
    for name in _RECALC_HISTOGRAMS:
        labels = {"outcome": "written", "scope": RECALC_SCOPE_PARTIAL, "source": RECALC_SOURCE_BACKGROUND}
        assert REGISTRY.get_sample_value(f"{name}_count", labels) is None


def test_recalc_histogram_buckets_cover_queue_wait_scale() -> None:
    """Шкала своя, а не дефолтная: у библиотеки верхняя конечная корзина 10 с, а ожидание команды
    в очереди под нагрузкой уходит в десятки секунд."""
    assert RECALC_TIMING_BUCKETS == (0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 20.0, 30.0)
    body = client.get("/metrics").text
    for name in _RECALC_HISTOGRAMS:
        assert f'{name}_bucket{{le="30.0",outcome="written",scope="full",source="user"}}' in body
        assert f'{name}_bucket{{le="+Inf",outcome="written",scope="full",source="user"}}' in body


def test_init_metrics_is_idempotent() -> None:
    """lifespan поднимается повторно в тестах: вторая регистрация того же имени уронила бы старт."""
    init_metrics(_TEST_VERSION)
    init_metrics("9.9.9")
    body = render().decode()
    assert 'risk_profile_core_build_info{version="9.9.9"} 1.0' in body
    assert _TEST_VERSION not in body


# --- mmap-директория multiprocess-режима ---


@pytest.fixture
def _multiproc_dir(tmp_path: "os.PathLike[str]") -> Generator[str, None, None]:
    path = os.path.join(str(tmp_path), "prometheus-multiproc")
    with patch.dict(os.environ, {MULTIPROC_ENV: path}):
        yield path


def test_prepare_multiproc_dir_creates_dir_and_clears_stale_files(_multiproc_dir: str) -> None:
    """Контейнер переживает crash/OOM-kill с файлами прошлой жизни на диске: без очистки на
    старте их счётчики прибавились бы к текущим."""
    os.makedirs(_multiproc_dir)
    stale = os.path.join(_multiproc_dir, "counter_123.db")
    keep = os.path.join(_multiproc_dir, "not-a-db.txt")
    for f in (stale, keep):
        with open(f, "w") as fh:
            fh.write("x")

    prepare_multiproc_dir()

    assert os.path.isdir(_multiproc_dir)
    assert not os.path.exists(stale)
    assert os.path.exists(keep), "чужие файлы не трогаем — чистим только *.db"


def test_prepare_multiproc_dir_creates_missing_dir(_multiproc_dir: str) -> None:
    prepare_multiproc_dir()
    assert os.path.isdir(_multiproc_dir)


def test_prepare_multiproc_dir_noop_without_env() -> None:
    """Локально/в тестах env не задан — single-process режим, директории быть не должно."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop(MULTIPROC_ENV, None)
        prepare_multiproc_dir()  # не должно бросить


# --- Прод-режим (multiprocess) ---

_REPO_ROOT = Path(__file__).resolve().parent.parent

# Повторяет boot-путь контейнера при нескольких воркерах: свежая ФС без mmap-директории → точка
# входа (`src/__main__.py`) чистит директорию, не загружая ни приложение, ни метрики → спавн
# воркеров, каждый импортирует src.metrics уже после очистки → скрейп обслуживает один из воркеров.
# uvicorn спавнит воркеры через spawn-процессы, поэтому дети здесь тоже spawn, а не fork.
_MULTIPROC_PROBE = '''
import multiprocessing, os


def worker(_i):
    """Роль uvicorn-воркера: свой процесс, свой комплект mmap-файлов, метрики — после очистки."""
    import src.metrics as m

    for _ in range(5):
        m.ERRORS_TOTAL.labels(level="error", component="probe").inc()
    m.HTTP_REQUEST_DURATION.labels(method="GET", path="/p", status="200", host="h").observe(0.01)


def scrape(queue):
    """Скрейп обслуживает воркер, а не мастер: отдельный процесс со своими файлами."""
    import src.metrics as m

    m.init_metrics("1.2.3-test")
    queue.put(m.render().decode())


# spawn-дети заново прогоняют этот файл как __mp_main__: на верхнем уровне — только определения,
# работа мастера — под guard'ом.
if __name__ == "__main__":
    mp_dir = os.environ["PROMETHEUS_MULTIPROC_DIR"]
    assert not os.path.isdir(mp_dir), "директории быть не должно: старт свежего контейнера"

    # Мастер — как точка входа: чистит директорию, не импортируя src.metrics.
    from src.metrics_multiproc import prepare_multiproc_dir

    prepare_multiproc_dir()
    ctx = multiprocessing.get_context("spawn")
    procs = [ctx.Process(target=worker, args=(i,)) for i in range(3)]
    for p in procs:
        p.start()
    for p in procs:
        p.join()
        assert p.exitcode == 0, "воркер упал: %s" % p.exitcode

    queue = ctx.Queue()
    scraper = ctx.Process(target=scrape, args=(queue,))
    scraper.start()
    body = queue.get(timeout=60)
    scraper.join()

    type_names = [line.split()[2] for line in body.splitlines() if line.startswith("# TYPE ")]
    assert len(type_names) == len(set(type_names)), "дубли блоков TYPE: %s" % type_names
    assert "pid=" not in body, "лейбл pid в выдаче — метрика утекла из mmap:\\n%s" % body
    assert all(n.startswith("risk_profile_core") for n in type_names), type_names
    assert 'risk_profile_core_build_info{version="1.2.3-test"} 1.0' in body, body
    # Ради этой строки и существует весь multiproc: 3 процесса x 5 инкрементов, суммирует скрейп.
    assert 'risk_profile_core_errors_total{component="probe",level="error"} 15.0' in body, body
    assert "risk_profile_core_http_request_duration_seconds_bucket{" in body, body
    print("PROBE_OK")
'''


def test_render_in_multiprocess_mode(tmp_path: Path) -> None:
    """На стенде (workers=4) сервис работает в multiprocess-режиме, а весь остальной набор тестов —
    в single-process: режим выбирается по env ПРИ ИМПОРТЕ prometheus_client, внутри одного процесса
    его не переключить. Отсюда подпроцесс — только он проверяет выдачу в том режиме, в котором
    сервис реально работает, и только он проверяет суммирование счётчиков между воркерами.

    Держит инвариант LOCAL_REGISTRY (см. src/metrics.py): Gauge на нём писал бы ещё и в mmap,
    и метрика попала бы в выдачу дважды. Мутационно проверено, что тест это ловит; остальные
    тесты — нет, в single-process дефект невидим.
    """
    # Пробу кладём файлом, а не `python -c`: spawn-дети заново импортируют __main__, а код из
    # `-c` не импортируется. PYTHONPATH — чтобы `import src.metrics` работал из чужой директории.
    probe = tmp_path / "probe.py"
    probe.write_text(_MULTIPROC_PROBE)
    env = {
        **os.environ,
        MULTIPROC_ENV: str(tmp_path / "prometheus-multiproc"),
        "PYTHONPATH": str(_REPO_ROOT),
    }
    result = subprocess.run(  # noqa: S603
        [sys.executable, str(probe)],
        env=env,
        cwd=_REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, f"stdout={result.stdout}\nstderr={result.stderr}"
    assert "PROBE_OK" in result.stdout


# Старт процесса app с одним воркером по реальному пути: точка входа исполняется как `python -m src`,
# а подменённый `uvicorn.run` делает то, что uvicorn делает при одном воркере, — загружает
# приложение по импорт-строке в этом же процессе и обслуживает в нём запросы. Запрос на
# несуществующий путь попадает в HTTP-гистограмму (404), затем — скрейп `/metrics`; выдачу
# разбирает тест. Lifespan не поднимается: ему нужна БД, а заведение рядов от него не зависит.
_SINGLE_WORKER_START = """
import importlib, json, os, runpy, sys

stale_values, body_path = json.loads(sys.argv[1]), sys.argv[2]
mp_dir = os.environ["PROMETHEUS_MULTIPROC_DIR"]
os.makedirs(mp_dir)

# Файл прошлого запуска с PID этого процесса: в контейнере процесс точки входа при каждом старте
# получает один и тот же PID, и value-class prometheus_client открывает файл именно с этим именем.
# Пишем его собственным писателем библиотеки: формат бинарный, и только так файл одинаково читают
# и value-class при заведении ряда, и MultiProcessCollector на скрейпе.
from prometheus_client.mmap_dict import MmapedDict

stale = MmapedDict(os.path.join(mp_dir, "counter_%d.db" % os.getpid()))
for key, value in stale_values:
    stale.write_value(key, value, 0.0)
stale.close()

import uvicorn


def serve_in_this_process(app, **kwargs):
    assert kwargs["workers"] == 1, kwargs
    from fastapi.testclient import TestClient

    module_name, _, attr = app.partition(":")
    client = TestClient(getattr(importlib.import_module(module_name), attr))
    assert client.get("/no-such-path").status_code == 404
    with open(body_path, "w", encoding="utf-8") as fh:
        fh.write(client.get("/metrics").text)


uvicorn.run = serve_in_this_process
runpy.run_module("src", run_name="__main__")
"""


def _counter_key(metric: Counter, labels: dict[str, str]) -> str:
    """Ключ ряда счётчика в mmap-файле — тот же, что строит value-class при заведении ряда. Имя и
    текст справки берутся из живой метрики: ключ с другим текстом справки был бы другим рядом."""
    family = next(iter(metric.collect()))
    return mmap_key(family.name, f"{family.name}_total", list(labels), list(labels.values()), family.documentation)


def test_single_worker_exposes_own_series_without_previous_run_values(tmp_path: Path) -> None:
    """При одном воркере (`RISK_MODEL_WORKERS=1`; профайлер форсирует то же самое) uvicorn
    обслуживает запросы в процессе точки входа. Выдача обязана содержать ряды этого процесса: и
    наблюдения его запросов, и ряды, заведённые при импорте `src.metrics`. Очистка директории после
    этого импорта удалила бы уже открытые файлы процесса — значения уходили бы в удалённые файлы, и
    выдача осталась бы без единого счётного ряда.

    Файл прошлого запуска с тем же PID в выдачу не попадает ни целиком (ряд, которого процесс не
    заводил), ни через ряд, который процесс заводит сам: счётчик начинается с нуля, а не с
    сохранённого значения.
    """
    admitted = {"decision": BACKGROUND_ADMITTED, "reason": BACKGROUND_REASON_NONE}
    previous_run_only = {"level": "error", "component": "previous_run"}
    stale_values = [
        (_counter_key(RECALC_BACKGROUND_COMMANDS, admitted), 5.0),
        (_counter_key(ERRORS_TOTAL, previous_run_only), 7.0),
    ]
    body_path = tmp_path / "metrics.txt"
    env = {**os.environ, MULTIPROC_ENV: str(tmp_path / "prometheus-multiproc"), "RISK_MODEL_WORKERS": "1"}
    result = subprocess.run(  # noqa: S603
        [sys.executable, "-c", _SINGLE_WORKER_START, json.dumps(stale_values), str(body_path)],
        env=env,
        cwd=_REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, f"stdout={result.stdout}\nstderr={result.stderr}"

    body = body_path.read_text(encoding="utf-8")
    samples = {
        (sample.name, frozenset(sample.labels.items())): sample.value
        for family in text_string_to_metric_families(body)
        for sample in family.samples
    }

    def value(name: str, labels: dict[str, str]) -> float | None:
        return samples.get((f"{SERVICE_PREFIX}_{name}", frozenset(labels.items())))

    request = {"method": "GET", "path": "unmatched", "status": "404", "host": HOSTNAME}
    preinitialized = {"outcome": "written", "scope": "full", "source": "user"}
    assert value("http_request_duration_seconds_count", request) == 1.0, f"нет ряда обслуженного запроса:\n{body}"
    assert value("recalc_duration_seconds_count", preinitialized) == 0.0, f"нет предынициализированного ряда:\n{body}"
    assert value("recalc_background_commands_total", admitted) == 0.0, f"значение прошлого запуска:\n{body}"
    assert "previous_run" not in body, f"ряд из файла прошлого запуска:\n{body}"


async def test_cvd_saturated_row_appears_in_the_exposition(monkeypatch: pytest.MonkeyPatch) -> None:
    """Признак насыщения внешнего сервиса риска виден в выдаче процесса, который
    в этот сервис ходит. Метрика служит людям и алертам; решение о допуске фоновых команд
    принимается по состоянию в процессе, а не по ней."""
    import src.calc.infra.cvd_client as cvd_module  # noqa: PLC0415

    monkeypatch.setattr(cvd_module.settings.cvd, "enabled", True)
    await cvd_module.init_cvd_client()
    try:
        exposition = render().decode()
    finally:
        await cvd_module.shutdown_cvd_client()

    assert f"{SERVICE_PREFIX}_cvd_saturated" in exposition
