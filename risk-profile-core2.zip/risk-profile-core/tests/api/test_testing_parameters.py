"""Tests for the read-only /api/v1/testing/parameters endpoints."""

from datetime import UTC, datetime

import pytest
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.parameter import Parameter

URL = "/api/v1/testing/parameters"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

_VALIDITY_DT = datetime(2027, 1, 1, tzinfo=UTC)


def _parameter(code: str = "BMI") -> Parameter:
    return Parameter(
        code=code,
        description="Body mass index",
        status="active",
        validity_period=_VALIDITY_DT,
    )


pytestmark = pytest.mark.test_internal

# --- Auth ---


async def test_missing_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL)
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL, headers=WRONG_HEADERS)
    assert response.status_code == 401


# --- List ---


async def test_list_parameters_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(_parameter("BMI"))
    db_session.add(_parameter("AGE"))
    await db_session.flush()

    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    codes = {item["code"] for item in data}
    assert {"BMI", "AGE"}.issubset(codes)


async def test_list_parameters_seeded(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200


# --- Get single ---


async def test_get_parameter_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(_parameter("BMI"))
    await db_session.flush()

    response = await async_client.get(f"{URL}/BMI", headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    assert data["code"] == "BMI"
    assert data["status"] == "active"


async def test_get_parameter_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(f"{URL}/UNKNOWN", headers=auth_headers)
    assert response.status_code == 404


@pytest.mark.parametrize(("method", "path"), [("post", URL), ("put", f"{URL}/BMI"), ("delete", f"{URL}/BMI")])
async def test_mutating_methods_are_not_allowed(
    async_client: AsyncClient, auth_headers: dict[str, str], method: str, path: str
) -> None:
    response = await async_client.request(method, path, headers=auth_headers, json={})
    assert response.status_code == 405
