"""Сборка CalcHandler зависимостью тестового маршрута расчёта.

В API-тестах хендлер подменяется через `dependency_overrides`, поэтому сама зависимость не
исполняется — а решает она одно: считать ли, когда публиковать результаты некуда.
"""

from unittest.mock import MagicMock, patch

import pytest

from src.api.v1.testing.calculation.router import get_calc_handler, get_calc_reader
from src.infra.kafka.exceptions import KafkaInitError

pytestmark = pytest.mark.test_internal


def test_handler_is_built_without_producer_when_kafka_is_unavailable() -> None:
    """Продюсер не поднят — расчёт всё равно доступен, просто без публикации событий.

    Тестовый маршрут расчёта нужен ровно тогда, когда стенд собран не полностью; падать на
    отсутствии Kafka значило бы лишить его смысла.
    """
    with patch(
        "src.api.v1.testing.calculation.router.get_kafka_producer",
        side_effect=KafkaInitError("kafka producer is not initialized"),
    ):
        handler = get_calc_handler(session=MagicMock(), catalog=MagicMock(), interpretation_catalog=MagicMock())

    assert handler._kafka is None


def test_handler_receives_the_resident_producer_when_available() -> None:
    """Продюсер поднят — он передаётся в хендлер, а не создаётся заново на каждый запрос."""
    producer = MagicMock(name="producer")

    with patch("src.api.v1.testing.calculation.router.get_kafka_producer", return_value=producer):
        handler = get_calc_handler(session=MagicMock(), catalog=MagicMock(), interpretation_catalog=MagicMock())

    assert handler._kafka is producer


def test_reader_is_bound_to_the_request_session_and_catalog() -> None:
    """Читатель берёт сессию запроса и статический каталог — своих не заводит."""
    session = MagicMock(name="session")
    catalog = MagicMock(name="catalog")

    reader = get_calc_reader(session=session, catalog=catalog)

    assert reader._session is session
    assert reader._catalog is catalog
