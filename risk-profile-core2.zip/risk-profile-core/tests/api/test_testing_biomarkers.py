from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

from src.api.v1.testing.biomarkers.router import list_biomarkers, submit_manual_biomarkers
from src.api.v1.testing.biomarkers.schemas import ManualBiomarkersRequest
from src.emr_biomarkers.domain.constants import EmrBiomarkerErrorCode
from src.emr_biomarkers.processing import ProcessingReport
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from tests.catalog_builder import biomarker, make_catalog, parameter


@pytest.fixture
def biomarker_catalog() -> EmrBiomarkersCatalog:
    source = parameter("biomarker_700")
    return EmrBiomarkersCatalog(
        make_catalog(
            parameters=(source,),
            biomarkers=(biomarker(700, source.code, biomarker_id=1, unit_code=169),),
        )
    )


async def test_catalog_exposes_active_biomarker(biomarker_catalog: EmrBiomarkersCatalog) -> None:
    response = await list_biomarkers(biomarker_catalog)

    assert [choice.model_dump(by_alias=True) for choice in response] == [
        {
            "biomarkerCode": 700,
            "unitCode": 169,
            "type": "quantitative",
            "parameterCode": "biomarker_700",
            "mappedParameterCodes": [],
        }
    ]


async def test_manual_submission_parses_and_processes_entries() -> None:
    processor = AsyncMock()
    processor.process.return_value = ProcessingReport(
        written_parameters=("biomarker_700",),
        recalc_requested=True,
    )
    body = ManualBiomarkersRequest.model_validate(
        {"patientId": "patient-700", "biomarkers": [{"biomarkerCode": 700, "unitCode": 169, "value": "1,50"}]}
    )

    response = await submit_manual_biomarkers(body, processor)

    assert response.model_dump(by_alias=True) == {
        "writtenParameterCodes": ["biomarker_700"],
        "skippedCount": 0,
        "recalculationRequested": True,
    }
    client_id, biomarkers = processor.process.await_args.args
    assert client_id == "patient-700"
    assert len(biomarkers) == 1
    assert biomarkers[0].biomarker_code == 700
    assert biomarkers[0].unit_code == 169


async def test_manual_submission_reports_unknown_patient() -> None:
    processor = AsyncMock()
    processor.process.return_value = ProcessingReport(
        error_code=EmrBiomarkerErrorCode.CLIENT_NOT_FOUND,
        reason="no patient with this clientId",
    )
    body = ManualBiomarkersRequest.model_validate(
        {"patientId": "missing-700", "biomarkers": [{"biomarkerCode": 700, "unitCode": 169, "value": "1"}]}
    )

    with pytest.raises(HTTPException, match="no patient with this clientId") as raised:
        await submit_manual_biomarkers(body, processor)

    assert raised.value.status_code == 404
