"""Tests for /api/v1/testing/patient-parameters CRUD endpoints."""

from datetime import UTC, datetime

import pytest
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.parameter import Parameter
from src.models.patient import Patient
from src.models.patient_parameter import PatientParameter

URL = "/api/v1/testing/patient-parameters"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

_EXPIRY = "2027-01-01T00:00:00Z"
_EXPIRY_DT = datetime(2027, 1, 1, tzinfo=UTC)

VALID_BODY = {
    "patientId": "p1",
    "parameterCode": "BMI",
    "value": "25.5",
    "source": "manual",
    "expirationDate": _EXPIRY,
}

UPDATE_BODY = {
    "patientId": "p1",
    "parameterCode": "BMI",
    "value": "27.0",
    "source": "import",
    "expirationDate": _EXPIRY,
}

pytestmark = pytest.mark.test_internal


async def _seed_parents(db_session: AsyncSession) -> None:
    """Insert the patient and parameter rows required by FK constraints."""
    db_session.add(Patient(patient_id="p1", is_pregnant=False))
    db_session.add(Patient(patient_id="p2", is_pregnant=False))
    db_session.add(
        Parameter(
            code="BMI",
            description="Body mass index",
            status="active",
            validity_period=_EXPIRY_DT,
        )
    )
    await db_session.flush()


def _pp(patient_id: str = "p1") -> PatientParameter:
    return PatientParameter(
        patient_id=patient_id,
        parameter_code="BMI",
        value="25.5",
        source="manual",
        expiration_date=_EXPIRY_DT,
    )


# --- Auth ---


async def test_missing_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL)
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL, headers=WRONG_HEADERS)
    assert response.status_code == 401


# --- List ---


async def test_list_patient_parameters_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    db_session.add(_pp("p1"))
    db_session.add(_pp("p2"))
    await db_session.flush()

    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    assert len(response.json()) == 2


async def test_list_patient_parameters_filters_by_patient_id(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    db_session.add(_pp("p1"))
    db_session.add(_pp("p2"))
    await db_session.flush()

    response = await async_client.get(URL, headers=auth_headers, params={"patientId": "p1"})

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["patientId"] == "p1"


async def test_list_patient_parameters_empty(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    assert response.json() == []


# --- Get single ---


async def test_get_patient_parameter_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    pp = _pp("p1")
    db_session.add(pp)
    await db_session.flush()

    response = await async_client.get(f"{URL}/{pp.patient_parameter_id}", headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    assert data["patientId"] == "p1"
    assert data["value"] == "25.5"


async def test_get_patient_parameter_not_found_returns_404(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.get(f"{URL}/999999", headers=auth_headers)
    assert response.status_code == 404


# --- Create ---


async def test_create_patient_parameter_returns_201(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)

    response = await async_client.post(URL, headers=auth_headers, json=VALID_BODY)

    assert response.status_code == 201
    data = response.json()
    assert data["patientId"] == "p1"
    assert data["parameterCode"] == "BMI"
    assert isinstance(data["patientParameterId"], int)
    # date_time проставлен и виден в ответе testing-API.
    assert datetime.fromisoformat(data["dateTime"]).year >= 2026


async def test_create_patient_parameter_missing_required_field_returns_400(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.post(URL, headers=auth_headers, json={"patientId": "p1"})
    assert response.status_code == 400


# --- Update ---


async def test_update_patient_parameter_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    db_session.add(_pp("p1"))
    await db_session.flush()

    response = await async_client.put(URL, headers=auth_headers, json=UPDATE_BODY)

    assert response.status_code == 200
    assert response.json()["source"] == "import"


async def test_update_patient_parameter_refreshes_date_time(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    old_dt = datetime(2020, 1, 1, tzinfo=UTC)
    pp = _pp("p1")
    pp.date_time = old_dt
    db_session.add(pp)
    await db_session.flush()

    response = await async_client.put(URL, headers=auth_headers, json=UPDATE_BODY)

    assert response.status_code == 200
    # Перезапись через testing-API обновляет date_time — устаревшее значение не возвращается.
    assert datetime.fromisoformat(response.json()["dateTime"]) > old_dt


async def test_update_patient_parameter_creates_when_not_found_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)

    response = await async_client.put(URL, headers=auth_headers, json=UPDATE_BODY)

    assert response.status_code == 200
    assert response.json()["source"] == "import"
    assert isinstance(response.json()["patientParameterId"], int)


# --- Delete ---


async def test_delete_patient_parameter_returns_204(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_parents(db_session)
    pp = _pp("p1")
    db_session.add(pp)
    await db_session.flush()

    response = await async_client.delete(f"{URL}/{pp.patient_parameter_id}", headers=auth_headers)

    assert response.status_code == 204


async def test_delete_patient_parameter_not_found_returns_404(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.delete(f"{URL}/999999", headers=auth_headers)
    assert response.status_code == 404
