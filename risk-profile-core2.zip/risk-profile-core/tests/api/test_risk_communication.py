"""API-тесты POST /api/v1/clients/{clientId}/questions/answers — валидация и envelope."""

from collections.abc import Generator
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from src.api.v1.risk_communication.router import get_risk_communication_service
from src.api.v1.risk_communication.schemas import AnswerResponse
from src.main import app
from src.services.risk_communication.domain.exceptions import (
    CatalogConsistencyError,
    ClientNotFoundError,
    InvalidOptionCodeError,
    QuestionNotFoundError,
    QuestionNotSkippableError,
    SystemCodeNotFoundError,
)
from src.services.risk_communication.domain.models import RecalcSignal
from tests.api.conftest import VALID_CLIENT_ID

URL = f"/api/v1/clients/{VALID_CLIENT_ID}/questions/answers"


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    """Подменяет RiskCommunicationService — тесты не дотягиваются до реальной БД."""
    mock = AsyncMock()
    mock.handle.return_value = (AnswerResponse(system_completion_percentage=0), RecalcSignal.empty())
    app.dependency_overrides[get_risk_communication_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_communication_service, None)


# --- Cross-field валидация query + body ---


def test_empty_body_without_question_code_passes(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={})
    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    assert body["error"] is None  # error присутствует и == null в любом успешном ответе (баг-репорт)
    assert fake_service.handle.await_count == 1


def test_non_empty_body_without_question_code_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={"answer": "x"})
    assert response.status_code == 400
    fake_service.handle.assert_not_awaited()


def test_question_code_without_body_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={})
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "INVALID_ANSWER_TYPE"
    assert body["error"]["message"] == (
        "При передаче questionCode необходимо указать один из параметров: optionCodes, answer или isSkipped."
    )
    fake_service.handle.assert_not_awaited()


def test_invalid_client_id(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post("/api/v1/clients/abc/questions/answers", json={})
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "INVALID_CLIENT_ID"
    assert body["error"]["message"] == "Идентификатор клиента должен содержать от 5 до 36 символов."
    fake_service.handle.assert_not_awaited()


def test_question_code_with_option_codes(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"optionCodes": ["a1"]})
    assert response.status_code == 200


def test_question_code_with_answer(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, params={"questionCode": "self-assessment"}, json={"answer": "ок"})
    assert response.status_code == 200


def test_question_code_with_skipped(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, params={"questionCode": "sleep-issues"}, json={"isSkipped": True})
    assert response.status_code == 200


def test_is_skipped_false_with_question_code_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # isSkipped=false семантически = «не пропускаю» = ответа нет → 400, иначе сервис уйдёт в no-op.
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"isSkipped": False})
    assert response.status_code == 400
    fake_service.handle.assert_not_awaited()


def test_is_skipped_false_without_question_code_passes(client: TestClient, fake_service: AsyncMock) -> None:
    # isSkipped=false без questionCode — «пустой» запрос с точки зрения наличия ответа; пропускаем.
    response = client.post(URL, json={"isSkipped": False})
    assert response.status_code == 200


def test_is_skipped_false_alongside_real_answer_passes(client: TestClient, fake_service: AsyncMock) -> None:
    # isSkipped=false не должно конфликтовать с реальным ответом в other field.
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"answer": "x", "isSkipped": False})
    assert response.status_code == 200


# --- Pydantic-валидация полей запроса ---


def test_more_than_one_field_in_body_fails(client: TestClient) -> None:
    response = client.post(URL, json={"answer": "x", "isSkipped": True})
    assert response.status_code == 400


def test_answer_too_long(client: TestClient) -> None:
    response = client.post(URL, json={"answer": "x" * 256})
    assert response.status_code == 400


def test_option_code_invalid_chars(client: TestClient) -> None:
    response = client.post(URL, json={"optionCodes": ["with space"]})
    assert response.status_code == 400


def test_question_code_too_short(client: TestClient) -> None:
    response = client.post(URL, params={"questionCode": "ab"}, json={})
    assert response.status_code == 400


def test_extra_field_forbidden(client: TestClient) -> None:
    response = client.post(URL, json={"unknown": "x"})
    assert response.status_code == 400


def test_unknown_query_param_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # Опечатка `systemCod` вместо `systemCode`: неизвестный query-параметр должен отвергаться 400,
    # а не молча игнорироваться (иначе реальный systemCode считается непереданным).
    response = client.post(URL, params={"systemCod": "TRAUMA"}, json={})
    assert response.status_code == 400
    assert response.json()["isSuccess"] is False
    fake_service.handle.assert_not_awaited()


def test_known_query_params_not_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # Контроль: легитимные systemCode/questionCode сквозь зависимость проходят.
    response = client.post(
        URL, params={"questionCode": "anxiety-freq", "systemCode": "MENTAL"}, json={"optionCodes": ["a1"]}
    )
    assert response.status_code == 200
    fake_service.handle.assert_awaited_once()


def test_explicit_null_in_body_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # #17: явный null трактуется как «значение не передано», должен возвращаться 400.
    for payload in (
        {"optionCodes": None},
        {"answer": None},
        {"isSkipped": None},
    ):
        response = client.post(URL, json=payload)
        assert response.status_code == 400, (payload, response.json())
        fake_service.handle.assert_not_awaited()


def test_empty_option_codes_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # #17: пустой массив optionCodes — не валидное значение.
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"optionCodes": []})
    assert response.status_code == 400
    fake_service.handle.assert_not_awaited()


def test_empty_answer_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # #17: пустая строка answer — не валидное значение (для пропуска есть isSkipped=true).
    response = client.post(URL, params={"questionCode": "self-assessment"}, json={"answer": ""})
    assert response.status_code == 400
    fake_service.handle.assert_not_awaited()


# --- Доменные ошибки → envelope ---


def test_client_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = ClientNotFoundError("client-123")
    response = client.post(URL, json={})
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CLIENT_NOT_FOUND"


def test_question_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = QuestionNotFoundError("missing-q")
    response = client.post(URL, params={"questionCode": "missing-q"}, json={"answer": "x"})
    assert response.status_code == 404
    body = response.json()
    assert body["error"]["code"] == "QUESTION_NOT_FOUND"


def test_system_code_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = SystemCodeNotFoundError(["BOGUS"])
    response = client.post(URL, params={"systemCode": "BOGUS"}, json={})
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "SYSTEM_CODE_NOT_FOUND"
    assert body["error"]["message"] == "Система организма с указанным кодом не найдена."
    # Код не утекает в HTTP-ответ — только generic message по контракту.
    assert "BOGUS" not in body["error"]["message"]


def test_question_not_skippable_returns_400_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = QuestionNotSkippableError("q-code")
    response = client.post(URL, params={"questionCode": "q-code"}, json={"isSkipped": True})
    assert response.status_code == 400
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "QUESTION_NOT_SKIPPABLE"


def test_invalid_option_code_returns_400_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = InvalidOptionCodeError("anxiety-freq", ["bogus"])
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"optionCodes": ["bogus"]})
    assert response.status_code == 400
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "INVALID_OPTION_CODE"
    # Невалидные коды не утекают в HTTP-ответ — только generic message.
    assert "bogus" not in body["error"]["message"]


def test_catalog_consistency_returns_500_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.handle.side_effect = CatalogConsistencyError(question_code="anxiety-freq")
    response = client.post(URL, params={"questionCode": "anxiety-freq"}, json={"isSkipped": True})
    assert response.status_code == 500
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CATALOG_INCONSISTENCY"
    # Код вопроса не утекает в HTTP-ответ — он только в логе.
    assert "anxiety-freq" not in body["error"]["message"]


# --- Передача параметров в сервис ---


def test_query_params_propagate_to_service(client: TestClient, fake_service: AsyncMock) -> None:
    client.post(URL, params={"questionCode": "anxiety-freq", "systemCode": "MENTAL"}, json={"optionCodes": ["a1"]})
    call_kwargs = fake_service.handle.await_args.kwargs
    assert call_kwargs["client_id"] == VALID_CLIENT_ID
    assert call_kwargs["question_code"] == "anxiety-freq"
    assert call_kwargs["system_code"] == "MENTAL"
    assert call_kwargs["body"].option_codes == ["a1"]


# --- Триггеры пересчёта (issue #29) ---


def test_recalc_with_parameter_codes_when_no_pregnancy_flip(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder
) -> None:
    fake_service.handle.return_value = (
        AnswerResponse(system_completion_percentage=0),
        RecalcSignal(parameter_codes=frozenset({"q01"}), pregnancy_flipped=False),
    )
    response = client.post(URL, params={"questionCode": "q01"}, json={"answer": "x"})
    assert response.status_code == 200
    assert dispatcher_recorder.calls == [(VALID_CLIENT_ID, {"q01"})]


def test_recalc_full_when_pregnancy_flipped(client: TestClient, fake_service: AsyncMock, dispatcher_recorder) -> None:
    fake_service.handle.return_value = (
        AnswerResponse(system_completion_percentage=0),
        RecalcSignal(parameter_codes=frozenset(), pregnancy_flipped=True),
    )
    response = client.post(URL, params={"questionCode": "cq_030"}, json={"optionCodes": ["yes"]})
    assert response.status_code == 200
    assert dispatcher_recorder.calls == [(VALID_CLIENT_ID, None)]


def test_recalc_full_takes_precedence_over_parameter_codes(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder
) -> None:
    fake_service.handle.return_value = (
        AnswerResponse(system_completion_percentage=0),
        RecalcSignal(parameter_codes=frozenset({"someparam"}), pregnancy_flipped=True),
    )
    response = client.post(URL, params={"questionCode": "cq_030"}, json={"optionCodes": ["yes"]})
    assert response.status_code == 200
    # Полный пересчёт включает в себя частичный — не дублируем.
    assert dispatcher_recorder.calls == [(VALID_CLIENT_ID, None)]


def test_recalc_skipped_when_no_signal(client: TestClient, fake_service: AsyncMock, dispatcher_recorder) -> None:
    # Default fake_service.handle.return_value = (response, RecalcSignal.empty()).
    response = client.post(URL, json={})
    assert response.status_code == 200
    assert dispatcher_recorder.calls == []


def test_recalc_inherits_request_id_from_initiating_request(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder
) -> None:
    """Спека стр. 5-6: фоновый recalc должен идти с тем же requestId, что и API-запрос."""
    fake_service.handle.return_value = (
        AnswerResponse(system_completion_percentage=0),
        RecalcSignal(parameter_codes=frozenset({"q01"}), pregnancy_flipped=False),
    )
    response = client.post(URL, json={}, headers={"X-Request-ID": "trace-id-43"})
    assert response.status_code == 200
    assert dispatcher_recorder.request_ids == ["trace-id-43"]
