"""API-тесты GET /api/v1/clients/{clientId}/medical-risk — валидация, envelope, переход к сервису."""

from collections.abc import Generator
from datetime import UTC, datetime
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from src.api.v1.risk_profile.router import get_risk_profile_service
from src.api.v1.risk_profile.schemas import (
    DiseaseRisk,
    DoctorSpecialization,
    MedicalRiskResponse,
    Recommendation,
    Risk,
    RiskFactor,
    SystemInterpretationResult,
)
from src.constants import RiskLevel
from src.main import app
from src.services.risk_communication.domain.exceptions import ClientNotFoundError, SystemCodeNotFoundError
from src.services.risk_profile.domain.constants import InterpretationStatus
from tests.api.conftest import VALID_CLIENT_ID

URL = f"/api/v1/clients/{VALID_CLIENT_ID}/medical-risk"


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    mock = AsyncMock()
    app.dependency_overrides[get_risk_profile_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_profile_service, None)


def _filled_response() -> MedicalRiskResponse:
    dt = datetime(2024, 3, 25, 10, 0, tzinfo=UTC)
    return MedicalRiskResponse(
        is_pregnant=False,
        completion_percentage=62,
        last_calculation_date_time=dt,
        last_interpretation_date_time=dt,
        top_recommendations=[Recommendation(title="Консультация кардиолога")],
        system_interpretation_results=[
            SystemInterpretationResult(
                system_code="CVD",
                system_name="Сердце и сосуды",
                interpretation_status=InterpretationStatus.COMPLETED,
                interpretation_date_time=dt,
                system_completion_percentage=90,
                system_priority=1,
                doctor_specializations=[DoctorSpecialization(name="Кардиолог", code=23)],
                disease_risks=[DiseaseRisk(name="ИБС")],
                risk=Risk(
                    interpretation_date_time=dt,
                    risk_level=RiskLevel.HIGH,
                    description="desc",
                    risk_factors=[RiskFactor(title="t", details="ризонинг по фактору")],
                    recommendations=[Recommendation(title="Консультация кардиолога")],
                ),
            )
        ],
    )


# --- Happy path ---


def test_happy_path_returns_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.return_value = _filled_response()
    response = client.get(URL)
    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    assert body["systemInterpretationResults"][0]["systemCode"] == "CVD"
    assert body["systemInterpretationResults"][0]["interpretationStatus"] == "completed"
    assert body["systemInterpretationResults"][0]["interpretationDateTime"] is not None
    assert body["lastInterpretationDateTime"] is not None


def test_system_code_passed_to_service(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.return_value = _filled_response()
    client.get(URL, params={"systemCode": "MENTAL"})
    fake_service.get_medical_risk.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_code="MENTAL")


def test_no_system_code_passes_none(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.return_value = _filled_response()
    client.get(URL)
    fake_service.get_medical_risk.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_code=None)


def test_pregnant_response_shape(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.return_value = MedicalRiskResponse(
        is_pregnant=True,
        completion_percentage=100,
        last_calculation_date_time=None,
        last_interpretation_date_time=None,
        top_recommendations=None,
        system_interpretation_results=[
            SystemInterpretationResult(
                system_code="CVD",
                system_name="Сердце и сосуды",
                interpretation_status=None,
                interpretation_date_time=None,
                system_completion_percentage=100,
                system_priority=1,
                doctor_specializations=None,
                disease_risks=None,
                risk=None,
            )
        ],
    )
    body = client.get(URL).json()
    assert body["isPregnant"] is True
    assert body["completionPercentage"] == 100
    assert body["systemInterpretationResults"][0]["interpretationStatus"] is None
    assert body["systemInterpretationResults"][0]["systemCompletionPercentage"] == 100


# --- Доменные исключения ---


def test_client_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.side_effect = ClientNotFoundError(VALID_CLIENT_ID)
    response = client.get(URL)
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CLIENT_NOT_FOUND"


def test_system_code_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_medical_risk.side_effect = SystemCodeNotFoundError(["RES2"])
    response = client.get(URL, params={"systemCode": "RES2"})
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "SYSTEM_CODE_NOT_FOUND"
    assert body["error"]["message"] == "Система организма с указанным кодом не найдена."


# --- Валидация входных параметров ---


def test_invalid_client_id(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.get("/api/v1/clients/abc/medical-risk")
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "INVALID_CLIENT_ID"
    assert body["error"]["message"] == "Идентификатор клиента должен содержать от 5 до 36 символов."
    fake_service.get_medical_risk.assert_not_awaited()


def test_system_code_too_short(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.get(URL, params={"systemCode": "A"})
    assert response.status_code == 400
    fake_service.get_medical_risk.assert_not_awaited()


def test_system_code_too_long(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.get(URL, params={"systemCode": "X" * 37})
    assert response.status_code == 400
    fake_service.get_medical_risk.assert_not_awaited()


def test_unknown_query_param_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # Опечатка `systemCod` вместо `systemCode`: неизвестный query-параметр должен отвергаться 400.
    response = client.get(URL, params={"systemCod": "MENTAL"})
    assert response.status_code == 400
    fake_service.get_medical_risk.assert_not_awaited()
