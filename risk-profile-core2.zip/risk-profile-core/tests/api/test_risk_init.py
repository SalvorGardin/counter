"""API-тесты POST /api/v1/clients/{clientId}/anthropometry — валидация и envelope."""

from collections.abc import Generator
from datetime import UTC, date, datetime, timedelta
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from src.api.v1.risk_init.router import get_risk_init_service
from src.main import app
from src.services.risk_init.domain.exceptions import GenderAndBirthDateRequiredError
from tests.api.conftest import VALID_CLIENT_ID
from tests.consts import PARAMETER_CODE_BMI, PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT

URL = f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry"


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    """Подменяет RiskInitService — API-тесты не дотягиваются до реальной БД."""
    mock = AsyncMock()
    mock.save_anthropometry.return_value = set()
    app.dependency_overrides[get_risk_init_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_init_service, None)


# --- Happy path ---


def test_happy_path_returns_201(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={"heightCm": 175})
    assert response.status_code == 201
    assert response.json() == {"isSuccess": True, "error": None}
    assert fake_service.save_anthropometry.await_count == 1


_SINGLE_FIELD_PAYLOADS = [
    {"heightCm": 175},
    {"weightKg": 70},
    {"birthDate": "1990-01-01"},
    {"gender": "male"},
    # snake_case принимается наравне с camelCase (populate_by_name).
    {"height_cm": 175},
]


@pytest.mark.parametrize("payload", _SINGLE_FIELD_PAYLOADS)
def test_any_single_field_is_enough(client: TestClient, fake_service: AsyncMock, payload: dict) -> None:
    response = client.post(URL, json=payload)
    assert response.status_code == 201, response.json()


# --- Pydantic-валидация полей запроса ---


def test_empty_body_fails(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={})
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "MISSING_REQUIRED_FIELD"
    assert body["error"]["message"] == (
        "Необходимо передать хотя бы один из параметров: heightCm, weightKg, birthDate, gender."
    )
    fake_service.save_anthropometry.assert_not_awaited()


# #18: явный null трактуется как «значение не передано», должен возвращаться 400.
_EXPLICIT_NULL_PAYLOADS = [
    {"heightCm": None},
    {"weightKg": None},
    {"birthDate": None},
    {"gender": None},
    {"heightCm": None, "weightKg": None, "birthDate": None},
    # null рядом с валидным значением другого поля — тоже 400 (бессмысленный null).
    {"heightCm": None, "weightKg": 70},
    {"heightCm": 175, "weightKg": None, "birthDate": "1990-01-01", "gender": "male"},
    # Тот же запрет на snake_case-форме ключа: она принимается моделью, значит и null по ней
    # обязан отсекаться, иначе запрет обходится сменой формы записи.
    {"height_cm": None},
    {"birth_date": None},
]


@pytest.mark.parametrize("payload", _EXPLICIT_NULL_PAYLOADS)
def test_explicit_null_for_any_field_rejected(client: TestClient, fake_service: AsyncMock, payload: dict) -> None:
    response = client.post(URL, json=payload)
    assert response.status_code == 400, response.json()


# Границы роста и веса заданы включительно (ge/le). Крайние значения проверяются с обеих
# сторон: без «границу принимаем» замена ge на gt не уронила бы ни одного теста.
_ACCEPTED_MEASUREMENTS = [
    ("heightCm", 50),
    ("heightCm", 50.1),
    ("heightCm", 175),
    ("heightCm", 249.9),
    ("heightCm", 250),
    ("weightKg", 10),
    ("weightKg", 10.1),
    ("weightKg", 70),
    ("weightKg", 299.9),
    ("weightKg", 300),
]

_REJECTED_MEASUREMENTS = [
    ("heightCm", 49.9),
    ("heightCm", 49),
    ("heightCm", 0),
    ("heightCm", -175),
    ("heightCm", 250.1),
    ("heightCm", 251),
    ("weightKg", 9.9),
    ("weightKg", 9),
    ("weightKg", 0),
    ("weightKg", -70),
    ("weightKg", 300.1),
    ("weightKg", 301),
]


@pytest.mark.parametrize(("field", "value"), _ACCEPTED_MEASUREMENTS)
def test_measurement_inside_range_accepted(
    client: TestClient, fake_service: AsyncMock, field: str, value: float
) -> None:
    response = client.post(URL, json={field: value})
    assert response.status_code == 201, response.json()


@pytest.mark.parametrize(("field", "value"), _REJECTED_MEASUREMENTS)
def test_measurement_outside_range_rejected(
    client: TestClient, fake_service: AsyncMock, field: str, value: float
) -> None:
    response = client.post(URL, json={field: value})
    assert response.status_code == 400, response.json()
    fake_service.save_anthropometry.assert_not_awaited()


@pytest.mark.parametrize("value", ["male", "female"])
def test_gender_from_contract_accepted(client: TestClient, fake_service: AsyncMock, value: str) -> None:
    response = client.post(URL, json={"gender": value})
    assert response.status_code == 201, response.json()


# Значение сверяется точно: регистр и русские подписи из опросника контрактом не приняты.
@pytest.mark.parametrize("value", ["other", "Male", "MALE", "мужской", "", " male", "male "])
def test_gender_outside_contract_rejected(client: TestClient, fake_service: AsyncMock, value: str) -> None:
    response = client.post(URL, json={"gender": value})
    assert response.status_code == 400, response.json()


def _yesterday() -> date:
    return datetime.now(tz=UTC).date() - timedelta(days=1)


# #20: дата рождения строго в прошлом и не раньше 1900-01-01; обе границы включительно снизу.
_REJECTED_BIRTH_DATES = [
    "not-a-date",
    "1990-13-01",
    "1990-02-30",
    "01.01.1990",
    date(1899, 12, 31).isoformat(),
    date(1, 1, 1).isoformat(),
    date(2027, 10, 1).isoformat(),
]


@pytest.mark.parametrize("value", _REJECTED_BIRTH_DATES)
def test_birth_date_rejected(client: TestClient, fake_service: AsyncMock, value: str) -> None:
    response = client.post(URL, json={"birthDate": value})
    assert response.status_code == 400, response.json()


@pytest.mark.parametrize("shift_days", [0, 1])
def test_birth_date_today_or_future_rejected(client: TestClient, fake_service: AsyncMock, shift_days: int) -> None:
    value = datetime.now(tz=UTC).date() + timedelta(days=shift_days)
    response = client.post(URL, json={"birthDate": value.isoformat()})
    assert response.status_code == 400, value


def test_birth_date_boundaries_accepted(client: TestClient, fake_service: AsyncMock) -> None:
    for value in (date(1900, 1, 1), _yesterday()):
        response = client.post(URL, json={"birthDate": value.isoformat()})
        assert response.status_code == 201, value


def test_extra_field_forbidden(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={"heightCm": 175, "unknown": "x"})
    assert response.status_code == 400


# Длина 5..36 символов и разрешённый набор символов — общий контракт идентификатора клиента.
_INVALID_CLIENT_IDS = [
    "abc",
    "a" * 4,  # на символ короче нижней границы
    "a" * 37,  # на символ длиннее верхней
    "bad!id",
    "id with space",
    "client%00id",  # нулевой байт в percent-кодировке
    "клиент-1",
]


@pytest.mark.parametrize("client_id", _INVALID_CLIENT_IDS)
def test_invalid_client_id_rejected(client: TestClient, fake_service: AsyncMock, client_id: str) -> None:
    response = client.post(f"/api/v1/clients/{client_id}/anthropometry", json={"heightCm": 175})
    assert response.status_code == 400, response.json()
    assert response.json()["error"]["code"] == "INVALID_CLIENT_ID"
    fake_service.save_anthropometry.assert_not_awaited()


def test_invalid_client_id_message_names_the_length_limits(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post("/api/v1/clients/abc/anthropometry", json={"heightCm": 175})
    body = response.json()
    assert body["error"]["message"] == "Идентификатор клиента должен содержать от 5 до 36 символов."


# --- Доменные ошибки → envelope ---


def test_new_client_without_birth_date_and_gender_returns_400(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.save_anthropometry.side_effect = GenderAndBirthDateRequiredError
    response = client.post(URL, json={"heightCm": 175})
    assert response.status_code == 400
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "GENDER_AND_BIRTH_DATE_REQUIRED"


# --- Передача параметров в сервис ---


def test_request_body_propagates_to_service(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(URL, json={"heightCm": 175, "weightKg": 72, "birthDate": "1990-03-15", "gender": "male"})
    assert response.status_code == 201, response.text

    call_kwargs = fake_service.save_anthropometry.await_args.kwargs
    assert call_kwargs["client_id"] == VALID_CLIENT_ID
    body = call_kwargs["body"]
    assert body.height_cm == 175
    assert body.weight_kg == 72
    assert body.birth_date.isoformat() == "1990-03-15"
    assert body.gender == "male"


# --- Триггеры пересчёта (issue #29) ---


def test_recalc_dispatched_with_changed_codes(client: TestClient, fake_service: AsyncMock, dispatcher_recorder) -> None:
    fake_service.save_anthropometry.return_value = {PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT, PARAMETER_CODE_BMI}
    response = client.post(URL, json={"heightCm": 175, "weightKg": 72})
    assert response.status_code == 201
    assert dispatcher_recorder.calls == [
        (VALID_CLIENT_ID, {PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT, PARAMETER_CODE_BMI})
    ]


def test_recalc_skipped_when_no_changes(client: TestClient, fake_service: AsyncMock, dispatcher_recorder) -> None:
    fake_service.save_anthropometry.return_value = set()
    response = client.post(URL, json={"heightCm": 175})
    assert response.status_code == 201
    assert dispatcher_recorder.calls == []


def test_recalc_inherits_request_id_from_initiating_request(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder
) -> None:
    """Спека стр. 5-6 (сквозное логирование): фоновый recalc должен идти с тем же requestId,
    что и инициирующий API-запрос — иначе в Kibana обрывается цепочка."""
    fake_service.save_anthropometry.return_value = {PARAMETER_CODE_HEIGHT}
    response = client.post(URL, json={"heightCm": 175}, headers={"X-Request-ID": "trace-id-42"})
    assert response.status_code == 201
    assert dispatcher_recorder.request_ids == ["trace-id-42"]


def test_unknown_query_param_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    # У ручки нет ни одного query-параметра — любой переданный ключ должен отвергаться 400.
    response = client.post(URL, params={"foo": "bar"}, json={"heightCm": 175})
    assert response.status_code == 400
    fake_service.save_anthropometry.assert_not_awaited()
