"""Tests for POST /api/v1/testing/calculation/run endpoint."""

from collections.abc import AsyncGenerator
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi.dependencies.models import Dependant
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.calculation.router import get_calc_handler, get_calculation_session
from src.calc.domain.models import CalculationRequest
from src.main import app
from src.models.instrument import Instrument
from src.models.patient import Patient
from src.models.result import Result

URL = "/api/v1/testing/calculation/run"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

pytestmark = pytest.mark.test_internal


@pytest_asyncio.fixture
async def mock_handler() -> AsyncGenerator[AsyncMock, None]:
    handler = AsyncMock()
    handler.run = AsyncMock()
    app.dependency_overrides[get_calc_handler] = lambda: handler
    yield handler
    app.dependency_overrides.pop(get_calc_handler, None)


async def _seed_patient_and_instrument(db_session: AsyncSession, patient_id: str, instrument_code: str) -> None:
    db_session.add(Patient(patient_id=patient_id, is_pregnant=False))
    db_session.add(
        Instrument(
            code=instrument_code,
            description="Test instrument",
            type="questionnaire",
            status="active",
            diseases=None,
        )
    )
    await db_session.flush()


def _result(patient_id: str, instrument_code: str, value: Decimal | None = Decimal("3.14")) -> Result:
    return Result(
        patient_id=patient_id,
        instrument_code=instrument_code,
        value=value,
        indicator="",
        date_time=datetime(2026, 5, 13, tzinfo=UTC),
        interpretation_status="normal",
        expiration_date=datetime(2026, 6, 13, tzinfo=UTC),
        risk_level="low",
        applicability=True,
        unit=None,
    )


# --- Auth ---


async def test_missing_token_returns_401(async_client: AsyncClient, mock_handler: AsyncMock) -> None:
    response = await async_client.post(URL, json={"patients": [{"patientId": "p1"}]})
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient, mock_handler: AsyncMock) -> None:
    response = await async_client.post(URL, headers=WRONG_HEADERS, json={"patients": [{"patientId": "p1"}]})
    assert response.status_code == 401


# --- Validation ---


async def test_missing_patient_ids_returns_400(
    async_client: AsyncClient, mock_handler: AsyncMock, auth_headers: dict[str, str]
) -> None:
    response = await async_client.post(URL, headers=auth_headers, json={})
    assert response.status_code == 400


# --- Calculation invocation ---


async def test_calc_handler_is_called_with_patient_ids(
    async_client: AsyncClient, mock_handler: AsyncMock, auth_headers: dict[str, str]
) -> None:
    await async_client.post(
        URL,
        headers=auth_headers,
        json={"patients": [{"patientId": "p1"}, {"patientId": "p2"}]},
    )
    mock_handler.run.assert_awaited_once_with(
        [CalculationRequest(patient_id="p1"), CalculationRequest(patient_id="p2")]
    )


async def test_duplicate_patient_items_are_combined_into_one_scope(
    async_client: AsyncClient, mock_handler: AsyncMock, auth_headers: dict[str, str]
) -> None:
    await async_client.post(
        URL,
        headers=auth_headers,
        json={
            "patients": [
                {"patientId": "p1", "instrumentCode": "BCRAT"},
                {"patientId": "p1", "instrumentCode": "SCORE2"},
                {"patientId": "p1", "instrumentCode": "BCRAT"},
            ]
        },
    )

    mock_handler.run.assert_awaited_once_with(
        [CalculationRequest(patient_id="p1", instrument_codes=frozenset({"BCRAT", "SCORE2"}))]
    )


# --- Results grouped by patient ---


async def test_patients_with_results_are_grouped(
    async_client: AsyncClient, mock_handler: AsyncMock, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(Patient(patient_id="p2", is_pregnant=False))
    db_session.add(Instrument(code="FINDRISC", description="x", type="questionnaire", status="active", diseases=None))
    await db_session.flush()
    db_session.add(_result("p1", "SCORE2"))
    db_session.add(_result("p1", "FINDRISC"))
    db_session.add(_result("p2", "SCORE2"))
    await db_session.flush()

    response = await async_client.post(
        URL,
        headers=auth_headers,
        json={"patients": [{"patientId": "p1"}, {"patientId": "p2"}]},
    )

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 2
    p1 = next(item for item in data if item["patientId"] == "p1")
    assert len(p1["results"]) == 2
    assert {r["instrumentCode"] for r in p1["results"]} == {"SCORE2", "FINDRISC"}
    p2 = next(item for item in data if item["patientId"] == "p2")
    assert len(p2["results"]) == 1


async def test_patient_with_no_results_gets_empty_list(
    async_client: AsyncClient, mock_handler: AsyncMock, auth_headers: dict[str, str]
) -> None:
    response = await async_client.post(
        URL,
        headers=auth_headers,
        json={"patients": [{"patientId": "p1"}, {"patientId": "p2"}]},
    )

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 2
    assert all(item["results"] == [] for item in data)


async def test_empty_patient_ids_returns_empty_list(
    async_client: AsyncClient, mock_handler: AsyncMock, auth_headers: dict[str, str]
) -> None:
    response = await async_client.post(URL, headers=auth_headers, json={"patients": []})

    assert response.status_code == 200
    assert response.json() == []
    mock_handler.run.assert_not_awaited()


async def test_value_is_serialized_as_string(
    async_client: AsyncClient, mock_handler: AsyncMock, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(_result("p1", "SCORE2", Decimal("3.140000")))
    await db_session.flush()

    response = await async_client.post(URL, headers=auth_headers, json={"patients": [{"patientId": "p1"}]})

    assert response.status_code == 200
    value = response.json()[0]["results"][0]["value"]
    assert isinstance(value, str)


async def test_null_value_is_preserved(
    async_client: AsyncClient, mock_handler: AsyncMock, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(_result("p1", "SCORE2", None))
    await db_session.flush()

    response = await async_client.post(URL, headers=auth_headers, json={"patients": [{"patientId": "p1"}]})

    assert response.status_code == 200
    assert response.json()[0]["results"][0]["value"] is None


async def test_response_preserves_all_result_fields(
    async_client: AsyncClient, mock_handler: AsyncMock, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(_result("p1", "SCORE2"))
    await db_session.flush()

    response = await async_client.post(URL, headers=auth_headers, json={"patients": [{"patientId": "p1"}]})

    assert response.status_code == 200
    r = response.json()[0]["results"][0]
    assert isinstance(r["resultId"], int)
    assert r["instrumentCode"] == "SCORE2"
    assert r["interpretationStatus"] == "normal"
    assert r["riskLevel"] == "low"
    assert r["applicability"] is True
    assert r["indicator"] == ""
    assert r["unit"] is None


# --- GET /results ---

RESULTS_URL = "/api/v1/testing/calculation/results"


async def test_get_results_missing_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(RESULTS_URL, params={"patientId": "p1"})
    assert response.status_code == 401


async def test_get_results_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(RESULTS_URL, headers=WRONG_HEADERS, params={"patientId": "p1"})
    assert response.status_code == 401


async def test_get_results_missing_patient_id_returns_400(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.get(RESULTS_URL, headers=auth_headers)
    assert response.status_code == 400


async def test_get_results_returns_empty_list_when_no_rows(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.get(RESULTS_URL, headers=auth_headers, params={"patientId": "p-missing"})
    assert response.status_code == 200
    assert response.json() == []


async def test_get_results_returns_rows_for_patient(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(Instrument(code="FINDRISC", description="x", type="questionnaire", status="active", diseases=None))
    await db_session.flush()
    db_session.add(_result("p1", "SCORE2"))
    db_session.add(_result("p1", "FINDRISC"))
    await db_session.flush()

    response = await async_client.get(RESULTS_URL, headers=auth_headers, params={"patientId": "p1"})

    assert response.status_code == 200
    data = response.json()
    assert {row["instrumentCode"] for row in data} == {"SCORE2", "FINDRISC"}


async def test_get_results_does_not_leak_other_patients(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    await _seed_patient_and_instrument(db_session, "p1", "SCORE2")
    db_session.add(Patient(patient_id="p2", is_pregnant=False))
    await db_session.flush()
    db_session.add(_result("p1", "SCORE2"))
    db_session.add(_result("p2", "SCORE2"))
    await db_session.flush()

    response = await async_client.get(RESULTS_URL, headers=auth_headers, params={"patientId": "p1"})

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["instrumentCode"] == "SCORE2"


def _routes(container: object) -> list[Any]:
    """Плоский список роутов: включённые роутеры FastAPI держит вложенными, а не разворачивает.

    Вложенный роутер приходит обёрткой `_IncludedRouter` без собственного пути; сами роуты лежат
    в `original_router`, и вложенность повторяется на каждом уровне `include_router`.
    """
    flat: list[Any] = []
    for route in getattr(container, "routes", ()):
        if getattr(route, "path", None) is not None:
            flat.append(route)
        flat.extend(_routes(getattr(route, "original_router", route)))
    return flat


def _dependency_calls(dependant: Dependant) -> set[object]:
    """Все зависимости роута, включая вложенные: FastAPI разворачивает их деревом."""
    calls: set[object] = set()
    for sub in dependant.dependencies:
        calls.add(sub.call)
        calls |= _dependency_calls(sub)
    return calls


def test_run_resolves_its_calculation_session_from_the_calculation_runtime() -> None:
    """Запуск расчёта пишет результаты, а у API-процесса логин профильный.

    Профилю на `results`, `interpretations` и статусах выдан только `SELECT, DELETE` через
    представления, поэтому на запросной сессии первый же апсерт упёрся бы в 42501. Проверяется
    разрешённое дерево зависимостей роута, а не аннотация: подмена сессии обратно на запросную
    обязана падать здесь.
    """
    route = next(r for r in _routes(app) if getattr(r, "path", None) == URL)
    assert get_calculation_session in _dependency_calls(route.dependant)
