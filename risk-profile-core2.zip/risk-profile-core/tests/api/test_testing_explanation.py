"""API-тесты маршрутов объяснения: авторизация, неизвестный пациент, отсутствие при выключенном сборе."""

import os
import subprocess
import sys
from pathlib import Path

import pytest
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.patient import Patient

URL = "/api/v1/testing/explanation"
UNMATCHED_URL = f"{URL}/unmatched-risk-factors"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

pytestmark = pytest.mark.test_internal

_REPO_ROOT = Path(__file__).resolve().parents[2]

# Проба выполняется в ОТДЕЛЬНОМ процессе: регистрация маршрутов решается при импорте
# `src.api.v1.testing.router`, и в текущем процессе флаг уже прочитан.
_FLAG_OFF_PROBE = """
import sys

from fastapi.testclient import TestClient

from src.main import app

paths = [path for path in app.openapi()["paths"] if "explanation" in path]
assert paths == [], paths
# Без контекстного менеджера: lifespan собирал бы резидентные каталоги и полез в БД, а проверяемое
# свойство — маршрутизация, которой БД не нужна.
client = TestClient(app)
assert client.get("/api/v1/testing/explanation?patientId=whoever").status_code == 404
# Модули читающего слоя при выключенном флаге не импортируются вовсе.
assert not [name for name in sys.modules if name.startswith("src.explanation")]
print("PROBE_OK")
"""

_FLAG_ON_PROBE = """
from src.main import app

paths = {path for path in app.openapi()["paths"]}
assert "/api/v1/testing/explanation" in paths, sorted(paths)
assert "/api/v1/testing/explanation/unmatched-risk-factors" in paths, sorted(paths)
assert "/api/v1/testing/calculation-statuses" in paths, sorted(paths)
print("PROBE_OK")
"""


def _run_probe(source: str, tmp_path: Path, *, collection_enabled: bool) -> None:
    probe = tmp_path / "probe.py"
    probe.write_text(source)
    env = {
        **os.environ,
        "RISK_MODEL_CALC_STATUS_COLLECTION_ENABLED": "true" if collection_enabled else "false",
        "PYTHONPATH": str(_REPO_ROOT),
    }
    result = subprocess.run(  # noqa: S603
        [sys.executable, str(probe)],
        env=env,
        cwd=_REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, f"stdout={result.stdout}\nstderr={result.stderr}"
    assert "PROBE_OK" in result.stdout


# --- Авторизация ---


async def test_missing_token_returns_401(async_client: AsyncClient, diagnostic_routes: None) -> None:
    response = await async_client.get(URL, params={"patientId": "whoever"})
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient, diagnostic_routes: None) -> None:
    response = await async_client.get(URL, params={"patientId": "whoever"}, headers=WRONG_HEADERS)
    assert response.status_code == 401


async def test_unmatched_missing_token_returns_401(async_client: AsyncClient, diagnostic_routes: None) -> None:
    response = await async_client.get(UNMATCHED_URL, params={"patientId": "whoever", "systemCode": "CVD"})
    assert response.status_code == 401


# --- Неизвестный пациент и неизвестная система ---


async def test_unknown_patient_returns_404(
    async_client: AsyncClient, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    response = await async_client.get(URL, params={"patientId": "no-such-patient"}, headers=auth_headers)
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "CLIENT_NOT_FOUND"


async def test_unmatched_unknown_patient_returns_404(
    async_client: AsyncClient, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    response = await async_client.get(
        UNMATCHED_URL, params={"patientId": "no-such-patient", "systemCode": "CVD"}, headers=auth_headers
    )
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "CLIENT_NOT_FOUND"


async def test_unmatched_requires_system_code(
    async_client: AsyncClient, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    response = await async_client.get(UNMATCHED_URL, params={"patientId": "whoever"}, headers=auth_headers)
    assert response.status_code == 400


# --- Регистрация под флагом сбора ---


def test_routes_absent_when_collection_disabled(tmp_path: Path) -> None:
    _run_probe(_FLAG_OFF_PROBE, tmp_path, collection_enabled=False)


def test_routes_present_when_collection_enabled(tmp_path: Path) -> None:
    _run_probe(_FLAG_ON_PROBE, tmp_path, collection_enabled=True)


# --- Успешное чтение ---


async def test_explanation_returns_catalog_shaped_body(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    """Пациент без единого расчёта: ответ приходит целиком из каталога, а не пустым.

    Диагностическая карточка обязана показывать полный состав систем и инструментов с явным
    исходом по каждому: пустой список читался бы как «инструментов нет», а не «не считалось».
    """
    db_session.add(Patient(patient_id="explanation-patient", is_pregnant=False))
    await db_session.flush()

    response = await async_client.get(URL, params={"patientId": "explanation-patient"}, headers=auth_headers)

    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    assert body["systems"], "ответ пуст: системы каталога не попали в состав"
    instruments = [item for system in body["systems"] for item in system["instruments"]]
    assert instruments, "ответ пуст: инструменты каталога не попали в состав"
    assert all(system["explanationStateText"] for system in body["systems"])


async def test_unmatched_risk_factors_returns_items_for_known_system(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    """Пересчёт несработавших факторов — отдельный маршрут с собственным телом ответа.

    Он отвечает на другой вопрос («сработало бы сейчас»), поэтому проверяется отдельно от карточки
    случая: общая схема ответа их различий не ловит.
    """
    db_session.add(Patient(patient_id="unmatched-patient", is_pregnant=False))
    await db_session.flush()

    response = await async_client.get(
        UNMATCHED_URL,
        params={"patientId": "unmatched-patient", "systemCode": "CVD"},
        headers=auth_headers,
    )

    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    assert isinstance(body["items"], list)
