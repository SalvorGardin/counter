"""API-тесты POST /api/v2/clients/{clientId}/questions/answers.

v2 отличается от v1 только флагом `complete_on_requested_system_done`, который роутер прокидывает
в сервис. Валидация/envelope общие с v1 (см. test_risk_communication.py) — здесь проверяем маршрут,
прокидывание флага в обеих версиях и что общая валидация продолжает действовать под v2.
"""

from collections.abc import Generator
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from src.api.risk_communication_common import get_risk_communication_service
from src.api.v1.risk_communication.schemas import AnswerResponse
from src.main import app
from src.services.risk_communication.domain.exceptions import ClientNotFoundError
from src.services.risk_communication.domain.models import RecalcSignal
from tests.api.conftest import VALID_CLIENT_ID

V2_URL = f"/api/v2/clients/{VALID_CLIENT_ID}/questions/answers"
V1_URL = f"/api/v1/clients/{VALID_CLIENT_ID}/questions/answers"


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    """Подменяет RiskCommunicationService (общая зависимость v1/v2) — тесты не дотягиваются до БД."""
    mock = AsyncMock()
    mock.handle.return_value = (AnswerResponse(system_completion_percentage=100), RecalcSignal.empty())
    app.dependency_overrides[get_risk_communication_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_communication_service, None)


def test_v2_route_resolves_and_returns_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(V2_URL, params={"systemCode": "CVD"}, json={})
    assert response.status_code == 200
    assert response.json()["systemCompletionPercentage"] == 100


def test_v2_passes_complete_flag_true(client: TestClient, fake_service: AsyncMock) -> None:
    client.post(V2_URL, params={"questionCode": "cvd-q", "systemCode": "CVD"}, json={"optionCodes": ["a1"]})
    call_kwargs = fake_service.handle.await_args.kwargs
    assert call_kwargs["complete_on_requested_system_done"] is True
    assert call_kwargs["system_code"] == "CVD"
    assert call_kwargs["question_code"] == "cvd-q"


def test_v1_passes_complete_flag_false(client: TestClient, fake_service: AsyncMock) -> None:
    # Гарантия, что версии не схлопнулись: v1 продолжает передавать False.
    client.post(V1_URL, params={"questionCode": "cvd-q", "systemCode": "CVD"}, json={"optionCodes": ["a1"]})
    call_kwargs = fake_service.handle.await_args.kwargs
    assert call_kwargs["complete_on_requested_system_done"] is False


def test_v2_shares_validation_rejects_unknown_query_param(client: TestClient, fake_service: AsyncMock) -> None:
    # Общая валидация действует и под v2: опечатка `systemCod` → 400, сервис не вызывается.
    response = client.post(V2_URL, params={"systemCod": "CVD"}, json={})
    assert response.status_code == 400
    fake_service.handle.assert_not_awaited()


@pytest.mark.parametrize("system_code", ["a", "x" * 37])
def test_v2_rejects_system_code_out_of_bounds(client: TestClient, fake_service: AsyncMock, system_code: str) -> None:
    # systemCode ограничен 2..36 символами (src.api.schemas.SystemCodeQuery). Нарушение границ под v2
    # должно давать контрактный 400 (RequestValidationError → validation_exception_handler), не 422,
    # и не доходить до сервиса. Граница min=2 (не 3, как можно ошибочно взять из questionCode).
    response = client.post(V2_URL, params={"systemCode": system_code}, json={})
    assert response.status_code == 400
    assert response.json()["isSuccess"] is False
    fake_service.handle.assert_not_awaited()


def test_v2_client_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    # v2-роут разделяет глобальные exception-хендлеры: доменная ошибка приходит контрактным envelope,
    # а не голым 500. Гарантия, что новый маршрут подключён к тем же обработчикам, что и v1.
    fake_service.handle.side_effect = ClientNotFoundError(VALID_CLIENT_ID)
    response = client.post(V2_URL, params={"systemCode": "CVD"}, json={})
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CLIENT_NOT_FOUND"
