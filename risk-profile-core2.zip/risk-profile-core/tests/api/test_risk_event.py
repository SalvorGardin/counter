"""API-тесты POST /api/v1/clients/{clientId}/medical-risk/events/{eventType}."""

from collections.abc import Generator
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from src.api.v1.risk_event.router import get_risk_event_service
from src.calc.dispatcher import get_dispatcher
from src.main import app
from src.services.risk_communication.domain.exceptions import ClientNotFoundError
from src.services.risk_event.domain.exceptions import SystemCodeNotFoundError, SystemCodeRequiredError
from tests.api.conftest import VALID_CLIENT_ID, DispatcherRecorder

BASE = f"/api/v1/clients/{VALID_CLIENT_ID}/medical-risk/events"

# Полный пересчёт: ни одной формы области у команды нет.
FULL_RECALC = (VALID_CLIENT_ID, None)


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    mock = AsyncMock()
    mock.handle_risk_calculation.return_value = None
    mock.handle_pregnancy_end.return_value = None
    mock.handle_answers_reset.return_value = None
    app.dependency_overrides[get_risk_event_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_event_service, None)


# --- Happy path ---


def test_risk_calculation_happy_path(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(f"{BASE}/risk-calculation")
    assert response.status_code == 202
    assert response.json() == {"isSuccess": True, "error": None}
    fake_service.handle_risk_calculation.assert_awaited_once_with(client_id=VALID_CLIENT_ID)


def test_pregnancy_end_happy_path(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(f"{BASE}/pregnancy-end")
    assert response.status_code == 202
    assert response.json() == {"isSuccess": True, "error": None}
    fake_service.handle_pregnancy_end.assert_awaited_once_with(client_id=VALID_CLIENT_ID)


def test_answers_reset_happy_path_multiple_codes(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.post(
        f"{BASE}/answers-reset",
        params=[("systemCode", "MENTAL"), ("systemCode", "CVD")],
    )
    assert response.status_code == 202
    assert response.json() == {"isSuccess": True, "error": None}
    fake_service.handle_answers_reset.assert_awaited_once_with(
        client_id=VALID_CLIENT_ID, system_codes=["MENTAL", "CVD"]
    )


# --- Доменные исключения ---


def test_client_not_found_returns_404(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Клиента нет — 404 и ни одной команды: полный пересчёт ставится только после его проверки."""
    fake_service.handle_risk_calculation.side_effect = ClientNotFoundError(VALID_CLIENT_ID)
    response = client.post(f"{BASE}/risk-calculation")
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CLIENT_NOT_FOUND"
    assert dispatcher_recorder.calls == []


def test_system_code_not_found_returns_404(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    fake_service.handle_answers_reset.side_effect = SystemCodeNotFoundError(["UNKNOWN"])
    response = client.post(f"{BASE}/answers-reset", params={"systemCode": "UNKNOWN"})
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "SYSTEM_CODE_NOT_FOUND"
    assert dispatcher_recorder.calls == []


def test_answers_reset_without_system_code_returns_400(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    fake_service.handle_answers_reset.side_effect = SystemCodeRequiredError()
    response = client.post(f"{BASE}/answers-reset")
    assert response.status_code == 400
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "SYSTEM_CODE_REQUIRED"
    fake_service.handle_answers_reset.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_codes=None)
    assert dispatcher_recorder.calls == []


# --- Валидация входных параметров ---


def test_invalid_client_id_too_short(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post("/api/v1/clients/abc/medical-risk/events/risk-calculation")
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "INVALID_CLIENT_ID"
    assert body["error"]["message"] == "Идентификатор клиента должен содержать от 5 до 36 символов."
    fake_service.handle_risk_calculation.assert_not_awaited()
    assert dispatcher_recorder.calls == []


def test_invalid_event_type(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post(f"{BASE}/unknown-event")
    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "INVALID_EVENT_TYPE"
    assert body["error"]["message"] == (
        "Недопустимый тип события. Допустимые значения: risk-calculation, pregnancy-end, answers-reset."
    )
    fake_service.handle_risk_calculation.assert_not_awaited()
    fake_service.handle_pregnancy_end.assert_not_awaited()
    fake_service.handle_answers_reset.assert_not_awaited()
    assert dispatcher_recorder.calls == []


def test_invalid_system_code_too_short(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post(f"{BASE}/answers-reset", params={"systemCode": "A"})
    assert response.status_code == 400
    fake_service.handle_answers_reset.assert_not_awaited()
    assert dispatcher_recorder.calls == []


def test_invalid_system_code_too_long(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post(f"{BASE}/answers-reset", params={"systemCode": "X" * 37})
    assert response.status_code == 400
    fake_service.handle_answers_reset.assert_not_awaited()
    assert dispatcher_recorder.calls == []


# --- Триггеры пересчёта ---


def test_risk_calculation_dispatches_full_recalc(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post(f"{BASE}/risk-calculation")
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_answers_reset_dispatches_full_recalc(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Сброс одной системы: ровно одна команда, и она полная."""
    response = client.post(f"{BASE}/answers-reset", params={"systemCode": "MENTAL"})
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_answers_reset_dispatches_one_full_recalc_for_several_systems(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Две системы в запросе — та же одна полная команда, а не по команде на систему."""
    response = client.post(
        f"{BASE}/answers-reset",
        params=[("systemCode", "MENTAL"), ("systemCode", "CVD")],
    )
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_answers_reset_dispatches_full_recalc_regardless_of_handler_result(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Область команды не зависит ни от чего, кроме самого факта события.

    Обработчик отдаёт роутеру значение, которого тот не читает. Смотри роутер на возврат — и
    область могла бы получиться разной, например у пациентки с признаком беременности и без него
    или у системы без записей в `systems_instruments`. Здесь команда одна и та же, полная.
    """
    fake_service.handle_answers_reset.return_value = AsyncMock()
    response = client.post(f"{BASE}/answers-reset", params={"systemCode": "MENTAL"})
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_pregnancy_end_dispatches_full_recalc(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    response = client.post(f"{BASE}/pregnancy-end")
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_pregnancy_end_dispatches_full_recalc_regardless_of_handler_result(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """То же для pregnancy-end: снимался признак беременности или нет, команда одна и полная."""
    fake_service.handle_pregnancy_end.return_value = AsyncMock()
    response = client.post(f"{BASE}/pregnancy-end")
    assert response.status_code == 202
    assert dispatcher_recorder.calls == [FULL_RECALC]


def test_recalc_is_scheduled_after_the_service_returns(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Команда ставится после возврата сервиса — тот к этому моменту уже очистил диагностику.

    Пересчёт идёт в отдельной сессии и не должен ни видеть незафиксированный сброс, ни быть
    обогнанным очисткой `calculation_statuses` и диагностики интерпретации этого же запроса.
    """
    order: list[str] = []

    async def _handle_answers_reset(*, client_id: str, system_codes: list[str] | None) -> None:  # noqa: ARG001
        order.append("service returned")

    async def _dispatch(patient_id: str, parameter_codes: set[str] | None) -> None:
        order.append("recalc scheduled")
        await dispatcher_recorder(patient_id, parameter_codes)

    fake_service.handle_answers_reset.side_effect = _handle_answers_reset
    app.dependency_overrides[get_dispatcher] = lambda: _dispatch

    response = client.post(
        f"{BASE}/answers-reset", params={"systemCode": "MENTAL"}, headers={"X-Request-ID": "trace-id-265"}
    )

    assert response.status_code == 202
    assert order == ["service returned", "recalc scheduled"]
    assert dispatcher_recorder.calls == [FULL_RECALC]
    # Фоновая задача обёрнута with_request_context — команда несёт requestId исходного запроса.
    assert dispatcher_recorder.request_ids == ["trace-id-265"]


def test_recalc_inherits_request_id_from_initiating_request(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    """Спека стр. 5-6: фоновый recalc должен идти с тем же requestId, что и API-запрос."""
    response = client.post(f"{BASE}/risk-calculation", headers={"X-Request-ID": "trace-id-44"})
    assert response.status_code == 202
    assert dispatcher_recorder.request_ids == ["trace-id-44"]


def test_unknown_query_param_rejected(
    client: TestClient, fake_service: AsyncMock, dispatcher_recorder: DispatcherRecorder
) -> None:
    # Опечатка `systemCod` вместо `systemCode`: неизвестный query-параметр должен отвергаться 400.
    response = client.post(f"{BASE}/answers-reset", params={"systemCod": "MENTAL"})
    assert response.status_code == 400
    fake_service.handle_answers_reset.assert_not_awaited()
    assert dispatcher_recorder.calls == []
