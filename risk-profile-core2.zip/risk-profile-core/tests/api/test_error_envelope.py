"""Глобальный обработчик ошибок валидации: 400 + envelope формата вики."""

from fastapi.testclient import TestClient

from tests.api.conftest import VALID_CLIENT_ID


def test_validation_returns_400_not_422(client: TestClient) -> None:
    response = client.post(
        f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry",
        json={"heightCm": 999},  # вне диапазона
    )
    assert response.status_code == 400


def test_envelope_shape(client: TestClient) -> None:
    response = client.post(
        f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry",
        json={"heightCm": 999},
    )
    body = response.json()
    assert body["isSuccess"] is False
    assert set(body.keys()) == {"isSuccess", "error"}
    assert set(body["error"].keys()) == {"code", "message"}
    assert isinstance(body["error"]["code"], str)
    assert isinstance(body["error"]["message"], str)


def test_envelope_lengths(client: TestClient) -> None:
    response = client.post(
        f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry",
        json={"heightCm": 999},
    )
    body = response.json()
    assert len(body["error"]["code"]) <= 100
    assert len(body["error"]["message"]) <= 255


def test_code_starts_with_invalid(client: TestClient) -> None:
    response = client.post(
        f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry",
        json={"heightCm": 999},
    )
    assert response.json()["error"]["code"].startswith("INVALID_")


def test_exact_code_for_known_field(client: TestClient) -> None:
    """Ловит регрессии в _error_code() — без этого фикс «убрать body» сломает контракт молча."""
    response = client.post(
        f"/api/v1/clients/{VALID_CLIENT_ID}/anthropometry",
        json={"heightCm": 999},
    )
    assert response.json()["error"]["code"] == "INVALID_HEIGHTCM"


def test_unhandled_route_returns_404_envelope(client: TestClient) -> None:
    response = client.get("/api/v1/no-such-route")
    assert response.status_code == 404
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "HTTP_404"


def test_openapi_has_no_422(client: TestClient) -> None:
    spec = client.get("/openapi.json").json()
    api_paths = {p: ops for p, ops in spec["paths"].items() if p.startswith("/api/v1/")}
    assert api_paths, "no /api/v1 paths in openapi"
    for path, ops in api_paths.items():
        for method, op in ops.items():
            assert "422" not in op.get("responses", {}), f"422 found in {method.upper()} {path}"


def test_openapi_has_400(client: TestClient) -> None:
    spec = client.get("/openapi.json").json()
    for path, ops in spec["paths"].items():
        if not path.startswith("/api/v1/"):
            continue
        for method, op in ops.items():
            assert "400" in op.get("responses", {}), f"400 missing in {method.upper()} {path}"


def test_openapi_client_id_keeps_constraints(client: TestClient) -> None:
    """clientId валидируется зависимостью (а не pydantic-констрейнтом), но OpenAPI обязан и дальше
    показывать minLength/maxLength/pattern — через json_schema_extra. См. INVALID_CLIENT_ID."""
    spec = client.get("/openapi.json").json()
    op = spec["paths"]["/api/v1/clients/{clientId}/medical-risk"]["get"]
    client_id_param = next(p for p in op["parameters"] if p["name"] == "clientId")
    schema = client_id_param["schema"]
    assert schema["minLength"] == 5
    assert schema["maxLength"] == 36
    assert schema["pattern"] == r"^[A-Za-z0-9_-]+$"
