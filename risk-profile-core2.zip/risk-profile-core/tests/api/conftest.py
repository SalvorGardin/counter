"""Shared fixtures for API tests."""

from collections.abc import AsyncGenerator, Generator
from types import MappingProxyType

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx2 import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.dispatcher import get_dispatcher
from src.infra.catalog.base import Catalog
from src.infra.catalog.http import HttpCatalog
from src.infra.database import get_calc_catalog, get_http_catalog, get_interpretation_catalog, get_session
from src.logger import request_id_var
from src.main import app
from tests.catalog_builder import CATALOG_TABLE_NAMES
from tests.conftest import make_calc_catalog, make_http_catalog, make_interpretation_catalog

VALID_CLIENT_ID = "client-123"

_EMPTY_HTTP_CATALOG = HttpCatalog(Catalog(MappingProxyType({table: () for table in CATALOG_TABLE_NAMES})))


@pytest.fixture
def diagnostic_routes() -> Generator[None, None, None]:
    """Регистрирует роуты статусов расчёта и объяснения на время теста.

    В боевой сборке они регистрируются при импорте `src.api.v1.testing.router` под флагом сбора, а
    флаг в тест-процессе выключен: включить его глобально нельзя — тогда коллекторы начали бы писать
    диагностику на своих сессиях в фиктивную БД во всех остальных тестах. Само правило регистрации
    под флагом проверяется отдельным процессом (tests/api/test_testing_explanation.py).
    """
    from src.api.v1.testing.calc_status.router import router as calc_status_router  # noqa: PLC0415
    from src.api.v1.testing.explanation.router import router as explanation_router  # noqa: PLC0415

    registered = len(app.router.routes)
    app.include_router(calc_status_router)
    app.include_router(explanation_router)
    app.openapi_schema = None
    try:
        yield
    finally:
        # Приложение — модульный синглтон, общий для всех API-тестов: добавленные роуты снимаем,
        # иначе они протекли бы в тесты, проверяющие состав схемы.
        del app.router.routes[registered:]
        app.openapi_schema = None


class DispatcherRecorder:
    """Стаб для get_dispatcher в API-тестах: запоминает вызовы, не лезет в БД.

    Дополнительно фиксирует значение request_id_var в момент вызова — нужно для тестов
    проверки сквозного логирования (see [[project_logging_compliance]]: фоновые задачи
    должны видеть тот же requestId, что и API-запрос-инициатор)."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, set[str] | None]] = []
        self.request_ids: list[str] = []

    async def __call__(self, patient_id: str, parameter_codes: set[str] | None) -> None:
        self.calls.append((patient_id, parameter_codes))
        self.request_ids.append(request_id_var.get())


@pytest.fixture
def dispatcher_recorder() -> Generator[DispatcherRecorder, None, None]:
    """Записывает вызовы dispatch_recalc, не вызывая реальный CalcHandler."""
    recorder = DispatcherRecorder()
    app.dependency_overrides[get_dispatcher] = lambda: recorder
    try:
        yield recorder
    finally:
        app.dependency_overrides.pop(get_dispatcher, None)


@pytest.fixture
def client(dispatcher_recorder: DispatcherRecorder) -> Generator[TestClient, None, None]:
    # The synchronous client deliberately does not run lifespan. Most API contract tests replace
    # the service; validation-only cases still resolve its dependencies before rejecting the body.
    app.dependency_overrides[get_http_catalog] = lambda: _EMPTY_HTTP_CATALOG
    try:
        yield TestClient(app)
    finally:
        app.dependency_overrides.pop(get_http_catalog, None)


@pytest_asyncio.fixture
async def async_client(
    db_session: AsyncSession, dispatcher_recorder: DispatcherRecorder
) -> AsyncGenerator[AsyncClient, None]:
    async def _override() -> AsyncGenerator[AsyncSession, None]:
        yield db_session

    # AsyncClient over ASGITransport never runs the app's lifespan, so app.state.catalogs
    # (normally built once in main.py's lifespan) is never set. Build it from the same seeded
    # db_session instead of touching app.state, mirroring the get_session override above.
    catalog = await make_calc_catalog(db_session)
    interpretation_catalog = await make_interpretation_catalog(db_session)
    http_catalog = await make_http_catalog(db_session)
    # make_calc_catalog/make_interpretation_catalog read through db_session and therefore open its
    # implicit transaction. Close that test-owned read boundary explicitly before request services
    # enter their own session.begin() scopes; make_http_catalog never mutates the caller's session.
    await db_session.rollback()
    app.dependency_overrides[get_session] = _override
    app.dependency_overrides[get_calc_catalog] = lambda: catalog
    app.dependency_overrides[get_interpretation_catalog] = lambda: interpretation_catalog
    app.dependency_overrides[get_http_catalog] = lambda: http_catalog
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.pop(get_session, None)
    app.dependency_overrides.pop(get_calc_catalog, None)
    app.dependency_overrides.pop(get_interpretation_catalog, None)
    app.dependency_overrides.pop(get_http_catalog, None)
