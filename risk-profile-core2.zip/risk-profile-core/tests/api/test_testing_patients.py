"""Tests for /api/v1/testing/patients CRUD and export endpoints."""

import io
import json
import zipfile

import pytest
from httpx2 import AsyncClient
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.patient import Patient

URL = "/api/v1/testing/patients"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

pytestmark = pytest.mark.test_internal

# --- Auth ---


async def test_missing_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL)
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL, headers=WRONG_HEADERS)
    assert response.status_code == 401


# --- List ---


async def test_list_patients_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(Patient(patient_id="p1", is_pregnant=False))
    db_session.add(Patient(patient_id="p2", is_pregnant=True))
    await db_session.flush()

    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 2
    patient_ids = {item["patientId"] for item in data}
    assert patient_ids == {"p1", "p2"}


async def test_list_patients_empty(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    assert response.json() == []


# --- Get single ---


async def test_get_patient_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(Patient(patient_id="p1", is_pregnant=True))
    await db_session.flush()

    response = await async_client.get(f"{URL}/p1", headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    assert data["patientId"] == "p1"
    assert data["isPregnant"] is True


async def test_get_patient_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(f"{URL}/unknown", headers=auth_headers)
    assert response.status_code == 404


# --- Export ---


async def test_export_patient_returns_zip_with_empty_related_files(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(Patient(patient_id="export-patient", is_pregnant=None))
    db_session.add(Patient(patient_id="other-patient", is_pregnant=True))
    await db_session.flush()

    response = await async_client.get(f"{URL}/export-patient/export", headers=auth_headers)

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"
    assert response.headers["content-disposition"] == 'attachment; filename="patient-export-patient-data.zip"'
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        assert archive.namelist() == [
            "patients.json",
            "patients_parameters.json",
            "interpretations.json",
            "results.json",
        ]
        patient_rows = json.loads(archive.read("patients.json"))
        assert len(patient_rows) == 1
        assert patient_rows[0]["patient_id"] == "export-patient"
        assert patient_rows[0]["is_pregnant"] is None
        assert json.loads(archive.read("patients_parameters.json")) == []
        assert json.loads(archive.read("interpretations.json")) == []
        assert json.loads(archive.read("results.json")) == []
    assert await db_session.scalar(select(func.count()).select_from(Patient)) == 2


async def test_export_patient_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(f"{URL}/unknown/export", headers=auth_headers)
    assert response.status_code == 404


async def test_export_patient_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(f"{URL}/p1/export", headers=WRONG_HEADERS)
    assert response.status_code == 401


# --- Create ---


async def test_create_patient_returns_201(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.post(URL, headers=auth_headers, json={"patientId": "p-new", "isPregnant": False})

    assert response.status_code == 201
    data = response.json()
    assert data["patientId"] == "p-new"
    assert data["isPregnant"] is False
    assert isinstance(data["uniqueId"], int)


async def test_create_patient_missing_patient_id_returns_400(
    async_client: AsyncClient, auth_headers: dict[str, str]
) -> None:
    response = await async_client.post(URL, headers=auth_headers, json={"isPregnant": False})
    assert response.status_code == 400


# --- Update ---


async def test_update_patient_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(Patient(patient_id="p1", is_pregnant=False))
    await db_session.flush()

    response = await async_client.put(f"{URL}/p1", headers=auth_headers, json={"isPregnant": True})

    assert response.status_code == 200
    assert response.json()["isPregnant"] is True


async def test_update_patient_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.put(f"{URL}/unknown", headers=auth_headers, json={"isPregnant": True})
    assert response.status_code == 404


# --- Delete ---


async def test_delete_patient_returns_204(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(Patient(patient_id="p1", is_pregnant=False))
    await db_session.flush()

    response = await async_client.delete(f"{URL}/p1", headers=auth_headers)

    assert response.status_code == 204


async def test_delete_patient_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.delete(f"{URL}/unknown", headers=auth_headers)
    assert response.status_code == 404
