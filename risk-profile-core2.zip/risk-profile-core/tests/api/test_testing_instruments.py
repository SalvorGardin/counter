"""Tests for the read-only /api/v1/testing/instruments endpoints."""

import pytest
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.instrument import Instrument

URL = "/api/v1/testing/instruments"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

pytestmark = pytest.mark.test_internal


def _instrument(code: str = "SCORE2", diseases: list[str] | None = None) -> Instrument:
    return Instrument(
        code=code,
        description="Cardiovascular risk",
        type="questionnaire",
        status="active",
        diseases=diseases,
    )


# --- Auth ---


async def test_missing_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL)
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient) -> None:
    response = await async_client.get(URL, headers=WRONG_HEADERS)
    assert response.status_code == 401


# --- List ---


async def test_list_instruments_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(_instrument("SCORE2"))
    db_session.add(_instrument("FINDRISC"))
    await db_session.flush()

    response = await async_client.get(URL, headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    codes = {item["code"] for item in data}
    assert {"SCORE2", "FINDRISC"}.issubset(codes)
    # Ручка отдаёт справочник целиком, а не только строки теста. Точного числа тут нет намеренно:
    # оно принадлежит сидам миграций, меняется при каждой перезаливке справочника и превращает
    # тест ручки в копию их содержимого.
    assert len(data) > 2


# --- Get single ---


async def test_get_instrument_returns_200(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    db_session.add(_instrument("SCORE2"))
    await db_session.flush()

    response = await async_client.get(f"{URL}/SCORE2", headers=auth_headers)

    assert response.status_code == 200
    data = response.json()
    assert data["code"] == "SCORE2"
    assert data["status"] == "active"
    assert data["diseases"] is None


async def test_get_instrument_returns_disease_codes_as_stored(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str]
) -> None:
    """Справочник отдаётся как есть: колонка хранит `diseases.code`, разворачивания в название нет."""
    db_session.add(_instrument("SCORE2", diseases=["infarction_ischemic_stroke"]))
    await db_session.flush()

    response = await async_client.get(f"{URL}/SCORE2", headers=auth_headers)

    assert response.status_code == 200
    assert response.json()["diseases"] == ["infarction_ischemic_stroke"]


async def test_get_instrument_not_found_returns_404(async_client: AsyncClient, auth_headers: dict[str, str]) -> None:
    response = await async_client.get(f"{URL}/UNKNOWN", headers=auth_headers)
    assert response.status_code == 404


@pytest.mark.parametrize(("method", "path"), [("post", URL), ("put", f"{URL}/SCORE2"), ("delete", f"{URL}/SCORE2")])
async def test_mutating_methods_are_not_allowed(
    async_client: AsyncClient, auth_headers: dict[str, str], method: str, path: str
) -> None:
    response = await async_client.request(method, path, headers=auth_headers, json={})
    assert response.status_code == 405
