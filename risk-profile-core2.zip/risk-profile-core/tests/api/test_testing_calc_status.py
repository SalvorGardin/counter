"""API-тесты GET /api/v1/testing/calculation-statuses: авторизация, полнота каталога, 404."""

import pytest
from httpx2 import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.patient import Patient

URL = "/api/v1/testing/calculation-statuses"
WRONG_HEADERS = {"X-Test-Api-Key": "wrong"}

pytestmark = pytest.mark.test_internal


async def test_missing_token_returns_401(async_client: AsyncClient, diagnostic_routes: None) -> None:
    response = await async_client.get(URL, params={"patientId": "whoever"})
    assert response.status_code == 401


async def test_wrong_token_returns_401(async_client: AsyncClient, diagnostic_routes: None) -> None:
    response = await async_client.get(URL, params={"patientId": "whoever"}, headers=WRONG_HEADERS)
    assert response.status_code == 401


async def test_unknown_patient_returns_404(
    async_client: AsyncClient, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    response = await async_client.get(URL, params={"patientId": "no-such-patient"}, headers=auth_headers)
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "CLIENT_NOT_FOUND"


async def test_catalog_is_covered_with_not_started(
    async_client: AsyncClient, db_session: AsyncSession, auth_headers: dict[str, str], diagnostic_routes: None
) -> None:
    db_session.add(Patient(patient_id="calc-status-patient", is_pregnant=False))
    await db_session.flush()

    response = await async_client.get(URL, params={"patientId": "calc-status-patient"}, headers=auth_headers)

    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    # Строк сбора у пациента нет — каталог всё равно приходит целиком, каждый инструмент с явным
    # исходом, а не пустым местом.
    assert body["items"], "ответ пуст: каталог инструментов не попал в состав"
    assert {item["status"] for item in body["items"]} == {"not_started"}
    assert all(item["instrumentDescription"] is not None for item in body["items"])
    # Порядок детерминированный: ответ обязан совпадать между вызовами.
    repeated = await async_client.get(URL, params={"patientId": "calc-status-patient"}, headers=auth_headers)
    assert [item["instrumentCode"] for item in repeated.json()["items"]] == [
        item["instrumentCode"] for item in body["items"]
    ]
