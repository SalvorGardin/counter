"""API-тесты GET /api/v1/clients/{clientId}/medical-risk/examinations — envelope, коды ошибок, переход к сервису."""

import json
import logging
import uuid
from collections.abc import Generator
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient
from httpx2 import AsyncClient
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_profile.router import get_risk_profile_service
from src.api.v1.risk_profile.schemas import ExaminationAnalyses, ExaminationsResponse, SystemExaminations
from src.constants import RiskLevel
from src.infra.database import get_http_catalog
from src.main import app
from src.services.risk_communication.domain.exceptions import ClientNotFoundError, SystemCodeNotFoundError
from src.services.risk_profile.domain.constants import ExaminationType
from src.services.risk_profile.domain.exceptions import (
    ClientGenderNotFoundError,
    ExaminationCategoryInvalidError,
    GenderNotFoundReason,
)
from tests.api.conftest import VALID_CLIENT_ID
from tests.conftest import LogSink, make_http_catalog
from tests.factories import Factory, unique_id

URL = f"/api/v1/clients/{VALID_CLIENT_ID}/medical-risk/examinations"

ANALYSIS_CODE = uuid.uuid4()
EXTENDED_ANALYSIS_CODE = uuid.uuid4()
DIAGNOSTIC_CODE = uuid.uuid4()


@pytest.fixture
def fake_service() -> Generator[AsyncMock, None, None]:
    mock = AsyncMock()
    app.dependency_overrides[get_risk_profile_service] = lambda: mock
    try:
        yield mock
    finally:
        app.dependency_overrides.pop(get_risk_profile_service, None)


def _filled_response(analyses: ExaminationAnalyses | None = None) -> ExaminationsResponse:
    return ExaminationsResponse(
        system_examinations=[
            SystemExaminations(
                system_code="CVD",
                system_name="Сердце и сосуды",
                analyses=analyses
                or ExaminationAnalyses(basic=[ANALYSIS_CODE], extended=[ANALYSIS_CODE, EXTENDED_ANALYSIS_CODE]),
                diagnostics=[DIAGNOSTIC_CODE],
            )
        ]
    )


def test_happy_path_returns_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    """Конверт ответа, `systemCode`, `systemName` и `diagnostics` не изменились, а `analyses`
    приходит объектом с пакетами `basic` и `extended` из строк UUID."""
    fake_service.get_examinations.return_value = _filled_response()

    response = client.get(URL)

    assert response.status_code == 200
    body = response.json()
    assert body["isSuccess"] is True
    assert body["error"] is None
    item = body["systemExaminations"][0]
    assert (item["systemCode"], item["systemName"]) == ("CVD", "Сердце и сосуды")
    assert item["analyses"] == {
        "basic": [str(ANALYSIS_CODE)],
        "extended": [str(ANALYSIS_CODE), str(EXTENDED_ANALYSIS_CODE)],
    }
    assert item["diagnostics"] == [str(DIAGNOSTIC_CODE)]


def test_empty_packages_stay_arrays_in_the_body(client: TestClient, fake_service: AsyncMock) -> None:
    """Система без лабораторных анализов отдаёт `basic` и `extended` пустыми массивами: ключи из
    тела не исчезают и значением `null` не приходят."""
    fake_service.get_examinations.return_value = _filled_response(ExaminationAnalyses(basic=[], extended=[]))

    item = client.get(URL).json()["systemExaminations"][0]

    assert item["analyses"] == {"basic": [], "extended": []}


@pytest.mark.parametrize(
    "packages",
    [
        {"basic": None, "extended": [str(ANALYSIS_CODE)]},
        {"basic": [str(ANALYSIS_CODE)], "extended": None},
        {"basic": [str(ANALYSIS_CODE)]},
        {"extended": [str(ANALYSIS_CODE)]},
    ],
    ids=["basic-null", "extended-null", "extended-missing", "basic-missing"],
)
def test_packages_are_required_and_not_nullable(packages: dict[str, list[str] | None]) -> None:
    """Пакеты обязательны: ни `null`, ни отсутствие ключа модель ответа не принимает — пустой
    перечень не подменяется отсутствием значения."""
    with pytest.raises(ValidationError):
        ExaminationAnalyses.model_validate(packages)


def test_empty_response_keeps_the_array(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_examinations.return_value = ExaminationsResponse(system_examinations=[])

    body = client.get(URL).json()

    assert body["systemExaminations"] == []


def test_system_code_passed_to_service(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_examinations.return_value = _filled_response()

    client.get(URL, params={"systemCode": "MENTAL"})

    fake_service.get_examinations.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_code="MENTAL")


def test_no_system_code_passes_none(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_examinations.return_value = _filled_response()

    client.get(URL)

    fake_service.get_examinations.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_code=None)


@pytest.mark.parametrize("system_code", ["", "A", "X" * 37])
def test_system_code_outside_the_length_bounds_returns_404_envelope(
    client: TestClient, fake_service: AsyncMock, system_code: str
) -> None:
    """Формат проверяется зависимостью — до сервиса, а значит и до поиска клиента."""
    response = client.get(URL, params={"systemCode": system_code})

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "SYSTEM_CODE_NOT_FOUND"
    fake_service.get_examinations.assert_not_awaited()


def test_client_not_found_returns_404_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_examinations.side_effect = ClientNotFoundError(VALID_CLIENT_ID)

    response = client.get(URL)

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "CLIENT_NOT_FOUND"


@pytest.mark.parametrize("system_code", ["RES2", "X" * 36])
def test_system_code_unknown_to_the_catalog_returns_404_envelope(
    client: TestClient, fake_service: AsyncMock, system_code: str
) -> None:
    """Прошедшее формат значение доходит до сервиса, и 404 отдаёт уже он."""
    fake_service.get_examinations.side_effect = SystemCodeNotFoundError([system_code])

    response = client.get(URL, params={"systemCode": system_code})

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "SYSTEM_CODE_NOT_FOUND"
    fake_service.get_examinations.assert_awaited_once_with(client_id=VALID_CLIENT_ID, system_code=system_code)


def test_invalid_client_id(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.get("/api/v1/clients/abc/medical-risk/examinations")

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "INVALID_CLIENT_ID"
    fake_service.get_examinations.assert_not_awaited()


def test_unknown_query_param_rejected(client: TestClient, fake_service: AsyncMock) -> None:
    response = client.get(URL, params={"systemCod": "MENTAL"})

    assert response.status_code == 400
    fake_service.get_examinations.assert_not_awaited()


def test_client_gender_not_found_returns_500_envelope(client: TestClient, fake_service: AsyncMock) -> None:
    fake_service.get_examinations.side_effect = ClientGenderNotFoundError(
        VALID_CLIENT_ID, reason=GenderNotFoundReason.MISSING, gender_value=None
    )

    response = client.get(URL)

    assert response.status_code == 500
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"]["code"] == "CLIENT_GENDER_NOT_FOUND"
    assert body["error"]["message"] == "Не удалось определить пол клиента."


def test_client_gender_not_found_logs_reason_and_masks_value(
    client: TestClient, fake_service: AsyncMock, captured_app_logs: LogSink
) -> None:
    """Событие несёт причину и клиента открыто, а само значение пола — только под маской: ни в
    контексте вывода, ни в тексте исключения из трассировки его быть не должно."""
    fake_service.get_examinations.side_effect = ClientGenderNotFoundError(
        VALID_CLIENT_ID, reason=GenderNotFoundReason.UNRECOGNIZED, gender_value="Иное"
    )

    client.get(URL)

    message = next(msg for msg in captured_app_logs.messages() if msg.startswith("CLIENT_GENDER_NOT_FOUND"))
    assert captured_app_logs.context_of(message) == {
        "client_id": VALID_CLIENT_ID,
        "reason": GenderNotFoundReason.UNRECOGNIZED,
        "gender_value": "Иное",
    }
    lines = captured_app_logs.output().splitlines()
    entry = next(json.loads(line) for line in lines if "CLIENT_GENDER_NOT_FOUND" in line)
    assert entry["context"]["gender_value"] == "***"
    assert entry["context"]["reason"] == "unrecognized"
    assert "Иное" not in entry["context"]["exception"]
    record = next(record for record in captured_app_logs.records if record.getMessage() == message)
    assert record.levelno == logging.ERROR


def test_examination_category_invalid_returns_internal_error_envelope(
    client: TestClient, fake_service: AsyncMock
) -> None:
    """Рассогласованный справочник наружу деталей не отдаёт — общий envelope внутренней ошибки."""
    fake_service.get_examinations.side_effect = ExaminationCategoryInvalidError("CVD", "d1", ANALYSIS_CODE, None)

    response = client.get(URL)

    assert response.status_code == 500
    body = response.json()
    assert body["isSuccess"] is False
    assert body["error"] == {"code": "INTERNAL_ERROR", "message": "Internal server error"}


async def test_examination_category_invalid_logs_client_from_path(
    async_client: AsyncClient, db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Через реальный маршрут: `client_id` события берётся из path-параметра запроса, остальные
    поля — из исключения; наружу уходит общий envelope внутренней ошибки."""
    pid = unique_id("client-category")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.disease_examination(disease_code=disease_code, examination_code=analysis, category=None)
    await db_session.commit()
    # Каталог фикстуры собран до сидинга; связь с пустой категорией видна только новому снимку.
    http_catalog = await make_http_catalog(db_session)
    app.dependency_overrides[get_http_catalog] = lambda: http_catalog

    response = await async_client.get(f"/api/v1/clients/{pid}/medical-risk/examinations")

    assert response.status_code == 500
    assert response.json()["error"]["code"] == "INTERNAL_ERROR"
    message = next(msg for msg in captured_app_logs.messages() if msg.startswith("EXAMINATION_CATEGORY_INVALID"))
    assert captured_app_logs.context_of(message) == {
        "client_id": pid,
        "system_code": system_code,
        "disease_code": disease_code,
        "examination_code": str(analysis),
        "category": None,
    }
    lines = captured_app_logs.output().splitlines()
    entry = next(json.loads(line) for line in lines if "EXAMINATION_CATEGORY_INVALID" in line)
    assert disease_code not in entry["context"]["exception"]
    record = next(record for record in captured_app_logs.records if record.getMessage() == message)
    assert record.levelno == logging.ERROR


def test_openapi_describes_analyses_as_two_required_uuid_packages(client: TestClient) -> None:
    """Схема метода собирается из модели ответа: `analyses` описан объектом с обязательными
    `basic` и `extended` — массивами строк формата UUID, а модель пары «идентификатор и
    категория» из компонентов схемы исчезла."""
    spec = client.get("/openapi.json").json()
    schemas = spec["components"]["schemas"]
    analyses_ref = schemas["SystemExaminations"]["properties"]["analyses"]["$ref"]
    analyses = schemas[analyses_ref.rsplit("/", 1)[-1]]

    assert sorted(analyses["required"]) == ["basic", "extended"]
    for package in ("basic", "extended"):
        assert analyses["properties"][package] == {
            "type": "array",
            "items": {"type": "string", "format": "uuid"},
            "title": package.capitalize(),
        }
    assert "ExaminationAnalysis" not in schemas


def test_openapi_system_code_keeps_bounds(client: TestClient) -> None:
    """Границы контракта объявлены через json_schema_extra, как у clientId: применённые
    pydantic'ом, они дали бы 400, а по контракту значение вне справочника — 404."""
    spec = client.get("/openapi.json").json()
    op = spec["paths"]["/api/v1/clients/{clientId}/medical-risk/examinations"]["get"]
    system_code_param = next(p for p in op["parameters"] if p["name"] == "systemCode")
    schema = system_code_param["schema"]

    assert schema["minLength"] == 2
    assert schema["maxLength"] == 36
