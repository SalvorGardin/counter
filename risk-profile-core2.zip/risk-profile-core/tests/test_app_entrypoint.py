"""Точка входа процесса app: `python -m src` (`src/__main__.py`).

Порядок старта — контракт, а не деталь реализации: в multiprocess-режиме prometheus_client процесс
открывает mmap-файлы метрик уже при импорте `src.metrics`, поэтому точка входа обязана очистить
директорию раньше, чем в её процессе загрузится приложение или метрики. Полноту выдачи `/metrics`
при одном воркере проверяет `tests/test_metrics_endpoint.py`; здесь — сам запуск: что загружено к
старту uvicorn и с какими параметрами он стартует.
"""

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest
import uvicorn

import src.__main__ as entrypoint
from src.config import settings
from src.metrics_multiproc import MULTIPROC_ENV
from tests.conftest import LogSink

_REPO_ROOT = Path(__file__).resolve().parent.parent

_PROFILER_NOTICE = "profiler enabled: forcing single uvicorn worker"

# Вызовы `uvicorn.run`: позиционные аргументы и именованные.
_UvicornCalls = list[tuple[tuple[Any, ...], dict[str, Any]]]

# Мастер uvicorn при нескольких воркерах. Точку входа импортирует и запускает свежий интерпретатор:
# в процессе pytest метрики давно загружены. Подменённый `uvicorn.run` снимает состояние процесса в
# момент вызова; отчёт уходит в файл, потому что stdout занят журналом процесса.
_MASTER_START = """
import importlib, json, os, sys

WATCHED = ("src.main", "src.metrics", "prometheus_client")
report = {}

entrypoint = importlib.import_module("src.__main__")
report["loaded_after_import"] = [name for name in WATCHED if name in sys.modules]

import uvicorn


def snapshot(app, **kwargs):
    report["loaded_at_uvicorn_run"] = [name for name in WATCHED if name in sys.modules]
    report["files_at_uvicorn_run"] = sorted(os.listdir(os.environ["PROMETHEUS_MULTIPROC_DIR"]))
    report["workers"] = kwargs["workers"]


uvicorn.run = snapshot
entrypoint.main()
with open(sys.argv[1], "w", encoding="utf-8") as fh:
    json.dump(report, fh)
"""


def test_master_cleans_directory_without_loading_app_or_metrics(tmp_path: Path) -> None:
    """При нескольких воркерах приложение и метрики загружают воркеры, уже после очистки, а мастер
    запросов не обслуживает. Сам он их не загружает — ни при импорте точки входа, ни до старта
    uvicorn: иначе открыл бы файлы метрик раньше очистки и держал бы в памяти ненужное ему
    приложение. Файл прошлого запуска к старту uvicorn уже удалён.
    """
    mp_dir = tmp_path / "prometheus-multiproc"
    mp_dir.mkdir()
    (mp_dir / "counter_1.db").write_bytes(b"previous run")
    report_path = tmp_path / "report.json"
    env = {
        **os.environ,
        MULTIPROC_ENV: str(mp_dir),
        "RISK_MODEL_WORKERS": "4",
        "RISK_MODEL_PROFILER__ENABLED": "false",
    }
    result = subprocess.run(  # noqa: S603
        [sys.executable, "-c", _MASTER_START, str(report_path)],
        env=env,
        cwd=_REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, f"stdout={result.stdout}\nstderr={result.stderr}"

    assert json.loads(report_path.read_text(encoding="utf-8")) == {
        "loaded_after_import": [],
        "loaded_at_uvicorn_run": [],
        "files_at_uvicorn_run": [],
        "workers": 4,
    }


@pytest.fixture
def uvicorn_calls(monkeypatch: pytest.MonkeyPatch) -> _UvicornCalls:
    """Вместо запуска сервера запоминает, с чем uvicorn был бы запущен."""
    calls: _UvicornCalls = []
    monkeypatch.setattr(uvicorn, "run", lambda *args, **kwargs: calls.append((args, kwargs)))
    # Single-process режим, как во всём наборе: очищать нечего.
    monkeypatch.delenv(MULTIPROC_ENV, raising=False)
    return calls


def test_main_starts_uvicorn_with_launch_settings(
    uvicorn_calls: _UvicornCalls, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Хост, порт, число воркеров и таймаут остановки — из настроек; цикл событий — uvloop;
    access-лог uvicorn выключен: запросы журналирует своя middleware (`request completed`).
    Приложение передаётся импорт-строкой — её требует запуск с несколькими воркерами."""
    monkeypatch.setattr(settings.profiler, "enabled", False)
    monkeypatch.setattr(settings, "host", "10.0.0.7")
    monkeypatch.setattr(settings, "port", 9123)
    monkeypatch.setattr(settings, "workers", 3)
    monkeypatch.setattr(settings, "shutdown_timeout", 17)

    entrypoint.main()

    assert uvicorn_calls == [
        (
            ("src.main:app",),
            {
                "host": "10.0.0.7",
                "port": 9123,
                "workers": 3,
                "loop": "uvloop",
                "access_log": False,
                "timeout_graceful_shutdown": 17,
            },
        )
    ]


def test_profiler_forces_single_worker(
    uvicorn_calls: _UvicornCalls,
    monkeypatch: pytest.MonkeyPatch,
    captured_app_logs: LogSink,
) -> None:
    """yappi копит статистику per-process: при нескольких воркерах `/api/v1/debug/profile` отдавал
    бы данные случайного процесса. Форс виден в журнале вместе с настроенным числом воркеров."""
    monkeypatch.setattr(settings.profiler, "enabled", True)
    monkeypatch.setattr(settings, "workers", 4)

    entrypoint.main()

    assert [kwargs["workers"] for _, kwargs in uvicorn_calls] == [1]
    assert captured_app_logs.messages().count(_PROFILER_NOTICE) == 1
    assert captured_app_logs.context_of(_PROFILER_NOTICE) == {"configured_workers": 4}


def test_main_reports_legacy_db_env_once(
    uvicorn_calls: _UvicornCalls,
    monkeypatch: pytest.MonkeyPatch,
    captured_app_logs: LogSink,
) -> None:
    """О прежних переменных БД сообщает точка входа — один раз на запуск: в lifespan сообщение
    повторилось бы в каждом воркере."""
    monkeypatch.setenv("RISK_MODEL_DB_URL", "postgresql+asyncpg://db/legacy")

    entrypoint.main()

    assert captured_app_logs.messages().count("legacy database env variables are ignored") == 1


def test_application_module_refuses_to_start_the_server() -> None:
    """`python -m src.main` — модуль приложения, а не команда запуска: к своему `__main__` он уже
    загрузил метрики. Команда обязана отказать с правильной командой в сообщении, а не выйти с кодом
    0, после которого оркестратор молча перезапускал бы контейнер по кругу."""
    # Порт 0 — эфемерный: если отказ пропадёт и сервер всё-таки стартует, он не займёт чужой порт.
    result = subprocess.run(  # noqa: S603
        [sys.executable, "-m", "src.main"],
        env={**os.environ, "RISK_MODEL_PORT": "0"},
        cwd=_REPO_ROOT,
        capture_output=True,
        text=True,
        timeout=120,
    )

    assert result.returncode == 1, f"stdout={result.stdout}\nstderr={result.stderr}"
    assert result.stderr.rstrip().endswith("python -m src"), result.stderr
