"""Тесты HTTP-метрик входящих запросов (risk_profile_core_http_request_duration_seconds).

Фокус — контракт лейблов и защита от кардинальности (ручка /metrics неавторизована, лейблы =
поверхность атаки): `path` — только шаблон роута/префикс маунта, `method` — белый список,
скрытые роуты не раскрываются, пробы не наблюдаются. См. требования безопасности T2 в
docs/spec-prometheus-metrics.md.
"""

from fastapi.testclient import TestClient
from prometheus_client.parser import text_string_to_metric_families

from src.main import app
from src.metrics import render

_METRIC = "risk_profile_core_http_request_duration_seconds"

client = TestClient(app)
# Отдельный клиент, чтобы 500-й ответ вернулся телом, а не пробросился исключением в тест:
# ServerErrorMiddleware после отправки ответа ВСЕГДА re-raise'ит исходное исключение.
boom_client = TestClient(app, raise_server_exceptions=False)


# Роуты только для тестов метрик. Добавляются к общему app (роутер видит их сразу): обычный
# видимый — под проверку status=500, скрытый — под проверку схлопывания include_in_schema=False.
@app.get("/__metrics_boom__")
def _metrics_boom() -> dict[str, str]:
    raise RuntimeError("boom for metrics test")


@app.get("/__metrics_hidden__", include_in_schema=False)
def _metrics_hidden() -> dict[str, str]:
    return {"ok": "1"}


def _count_labels() -> list[dict[str, str]]:
    """Лейбл-сеты всех `_count`-семплов гистограммы из текущей выдачи /metrics."""
    labels: list[dict[str, str]] = []
    for family in text_string_to_metric_families(render().decode()):
        if family.name != _METRIC:
            continue
        labels += [sample.labels for sample in family.samples if sample.name.endswith("_count")]
    return labels


def _combos() -> set[tuple[str, str, str]]:
    """Множество (path, method, status) в текущей выдаче."""
    return {(lbl["path"], lbl["method"], lbl["status"]) for lbl in _count_labels()}


def test_parameterized_route_labeled_as_template_not_raw() -> None:
    """Параметризованный роут → лейбл path — шаблон, а не сырой путь с id (даже на 401)."""
    client.get("/api/v1/testing/patients/zzz-raw-id-987")
    labels = _count_labels()
    paths = {lbl["path"] for lbl in labels}
    assert "/api/v1/testing/patients/{patient_id}" in paths
    assert "/api/v1/testing/patients/zzz-raw-id-987" not in paths
    # сырого id не должно быть НИ в одном лейбле
    assert not any("zzz-raw-id-987" in lbl["path"] for lbl in labels)


def test_trailing_slash_still_matches_template() -> None:
    """StripTrailingSlash (внутренний слой) снимает слеш до роутинга → шаблон, не unmatched."""
    client.get("/api/v1/testing/patients/abc/")
    assert "/api/v1/testing/patients/{patient_id}" in {lbl["path"] for lbl in _count_labels()}


def test_unmatched_urls_collapse_and_do_not_grow_cardinality() -> None:
    """N разных мусорных URL одним методом → один и тот же лейбл-сет path=unmatched (не N)."""
    before = {(lbl["method"], lbl["status"]) for lbl in _count_labels() if lbl["path"] == "unmatched"}
    for i in range(6):
        client.get(f"/no-such/garbage/{i}/leaf-{i}")
    after = {(lbl["method"], lbl["status"]) for lbl in _count_labels() if lbl["path"] == "unmatched"}
    new = after - before
    # 6 разных URL c GET → максимум одна новая комбинация (GET, 404), не шесть.
    assert len(new) <= 1, new
    assert all(method == "GET" for method, _ in new)


def test_nonstandard_methods_collapse_to_other() -> None:
    """Метод вне белого списка (в т.ч. длинный) → лейбл method='other', а не сырое значение."""
    for method in ("PROPFIND", "QUERY", "M" * 80):
        client.request(method, "/no-such/method-probe")
    labels = _count_labels()
    methods = {lbl["method"] for lbl in labels}
    assert "other" in methods
    for weird in ("PROPFIND", "QUERY"):
        assert weird not in methods
    # длинный метод не осел рядом
    assert not any(len(lbl["method"]) > len("OPTIONS") for lbl in labels)


def test_method_url_cross_product_does_not_grow_cardinality() -> None:
    """Контракт кардинальности (спека T2 🔒): N мусорных URL × M нестандартных методов → число
    НОВЫХ лейбл-сетов ограничено (unmatched × {GET|other}), а не N×M. Оба ключа сразу — не по
    отдельности, как в тестах выше."""
    before = _combos()
    methods = ("GET", "PROPFIND", "QUERY", "PROPPATCH", "Z" * 60)
    for method in methods:
        for i in range(8):
            client.request(method, f"/no-route/{method}/{i}/leaf")
    new = _combos() - before
    for path, method, _status in new:
        assert path == "unmatched", (path, method)
        assert method in {"GET", "other"}, (path, method)
    # 5 методов × 8 URL = 40 запросов, но новых комбинаций — единицы (метод схлопнут, URL → unmatched).
    assert len(new) <= 4, new


def test_hidden_route_collapsed_to_other() -> None:
    """include_in_schema=False роут не раскрывается лейблом path через неавторизованный /metrics."""
    client.get("/__metrics_hidden__")
    paths = {lbl["path"] for lbl in _count_labels()}
    assert "/__metrics_hidden__" not in paths
    assert ("other", "GET", "200") in _combos()


def test_static_mount_labeled_as_mount_prefix() -> None:
    """Статика /questionnaire/* → один лейбл path='/questionnaire', а не путь до файла."""
    client.get("/questionnaire/index.html")
    paths = {lbl["path"] for lbl in _count_labels()}
    assert "/questionnaire" in paths
    assert "/questionnaire/index.html" not in paths


def test_unhandled_exception_observed_as_500() -> None:
    """Роут, бросивший исключение → наблюдение со status='500'."""
    response = boom_client.get("/__metrics_boom__")
    assert response.status_code == 500
    assert ("/__metrics_boom__", "GET", "500") in _combos()


def test_probe_paths_not_observed() -> None:
    """Пробы и сам /metrics в гистограмму не попадают."""
    client.get("/health")
    client.get("/metrics")
    paths = {lbl["path"] for lbl in _count_labels()}
    assert "/health" not in paths
    assert "/metrics" not in paths
    assert "/" not in paths
