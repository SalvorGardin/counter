"""Регресс-проверки для scripts/check_logger_info.py."""

from __future__ import annotations

import importlib.util
import subprocess  # nosec B404
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT_PATH = REPO_ROOT / "scripts" / "check_logger_info.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("check_logger_info", SCRIPT_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _make_repo(tmp_path: Path, files: dict[str, str | bytes]) -> Path:
    """Собирает мини-репозиторий с src/ и scripts/ в tmp_path для изолированного сканирования.

    Ключи files — пути относительно tmp_path (например, "src/foo.py"); значения — содержимое
    (str — UTF-8 текст; bytes — сырые байты для проверки non-UTF-8 кейса)."""
    for rel, content in files.items():
        path = tmp_path / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            path.write_bytes(content)
        else:
            path.write_text(content, encoding="utf-8")
    return tmp_path


def test_passes_on_current_repo() -> None:
    """Базовая страховка: текущий develop не содержит запрещённых паттернов."""
    result = subprocess.run(  # nosec B603
        [sys.executable, str(SCRIPT_PATH)],
        capture_output=True,
        text=True,
        check=False,
        cwd=str(REPO_ROOT),
    )
    assert result.returncode == 0, result.stdout + result.stderr


@pytest.mark.parametrize(
    ("source", "expected_fragment"),
    [
        pytest.param('logger.info("nope")\n', "logger.info", id="logger-info"),
        pytest.param('logging.info("nope")\n', "logging.info", id="logging-info"),
        # logger.log(logging.INFO, ...) — обход через generic-API.
        pytest.param('logger.log(logging.INFO, "sneaky")\n', None, id="logger-log-logging-info-constant"),
        # logger.log(20, ...) — обход через сырое число.
        pytest.param('logger.log(20, "raw")\n', None, id="logger-log-numeric-constant"),
    ],
)
def test_scan_detects_info_call(tmp_path: Path, source: str, expected_fragment: str | None) -> None:
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text(source, encoding="utf-8")

    violations = mod._scan_file(f)

    assert len(violations) == 1
    if expected_fragment is not None:
        assert expected_fragment in violations[0][1]


@pytest.mark.parametrize(
    "source",
    [
        # Закомментированная строка — не нарушение.
        pytest.param('# logger.info("docstring example, not real call")\n', id="comment"),
        # business(...) / notice(...) — каноничные хелперы, не должны триггерить линтер.
        pytest.param(
            'business("event", context={"k": "v"})\nnotice("event", context={"k": "v"})\n',
            id="business-and-notice-helpers",
        ),
        # logger.warning/.error/.critical — допустимые уровни, не INFO.
        pytest.param(
            'logger.warning("w")\nlogger.error("e")\nlogger.critical("c")\nlogger.debug("d")\n',
            id="non-info-levels",
        ),
    ],
)
def test_scan_ignores_allowed_source(tmp_path: Path, source: str) -> None:
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text(source, encoding="utf-8")

    assert mod._scan_file(f) == []


def test_scan_skips_non_utf8_file_with_warn(tmp_path: Path, capsys) -> None:
    """Non-UTF-8 байты (proto-stub / битый checkout) не должны крашить линтер."""
    mod = _load_module()
    f = tmp_path / "x.py"
    # 0xFF — невалидная стартовая байт-последовательность для UTF-8.
    f.write_bytes(b"\xff\xfe garbage \xff bytes\n")
    violations = mod._scan_file(f)
    assert violations == []
    captured = capsys.readouterr()
    assert "non-UTF-8" in captured.err


def test_scan_function_detects_violation_in_isolated_repo(tmp_path: Path) -> None:
    """End-to-end через scan(repo_root) на изолированном tmp_path — не пишем в реальный src/.

    Это и страховка от регрессии скрипта (нарушение реально ловится), и защита от того,
    что параллельный xdist-прогон или прерванный test killer оставит мусор в живом checkout'е."""
    mod = _load_module()
    fake_root = _make_repo(
        tmp_path,
        {
            "src/bad.py": 'from src.logger import logger\nlogger.info("bad")\n',
            "src/ok.py": 'from src.logger import business\nbusiness("ok")\n',
        },
    )
    findings = mod.scan(fake_root)
    assert len(findings) == 1
    assert "src/bad.py" in findings[0]
    assert "logger.info" in findings[0]


def test_scan_function_respects_allowlist(tmp_path: Path) -> None:
    """src/logger.py — в allowlist, нарушения внутри не считаются."""
    mod = _load_module()
    fake_root = _make_repo(
        tmp_path,
        {
            "src/logger.py": 'import logging\nlogger.log(logging.INFO, "ok")\n',
        },
    )
    findings = mod.scan(fake_root)
    assert findings == []


def test_subprocess_returns_zero_on_clean_isolated_repo(tmp_path: Path) -> None:
    """Запуск скрипта как процесса на чистом репозитории — exit 0.

    Дополняет test_passes_on_current_repo: убеждаемся что сама CLI-точка возвращает 0,
    даже если живой репозиторий вдруг кто-то загрязнит."""
    fake_root = _make_repo(
        tmp_path,
        {
            "src/ok.py": 'from src.logger import business\nbusiness("ok")\n',
        },
    )
    # Локальная копия скрипта в tmp — чтобы Path(__file__).parent.parent резолвился в fake_root.
    (fake_root / "scripts").mkdir(exist_ok=True)
    script_copy = fake_root / "scripts" / "check_logger_info.py"
    script_copy.write_bytes(SCRIPT_PATH.read_bytes())
    result = subprocess.run(  # nosec B603
        [sys.executable, str(script_copy)],
        capture_output=True,
        text=True,
        check=False,
        cwd=str(fake_root),
    )
    assert result.returncode == 0, result.stdout + result.stderr
