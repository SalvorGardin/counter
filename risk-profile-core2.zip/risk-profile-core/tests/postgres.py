"""Отдельный PostgreSQL для каждого стенда: Docker локально, процесс на CI без Docker."""

import os
import secrets
import socket
import subprocess
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory

from sqlalchemy.engine import URL
from testcontainers.postgres import PostgresContainer


@contextmanager
def postgres_server() -> Iterator[str]:
    """Выдать sync URL свежего кластера и остановить его при выходе, в том числе при ошибке теста."""
    binaries = os.environ.get("TEST_POSTGRES_BIN")
    if not binaries:
        # Ryuk (reaper-контейнер testcontainers) отключён: на Docker Desktop его старт периодически
        # падает с "Port mapping ... port 8080 is not available" и роняет фикстуру, а следом каждый
        # тест с БД. Ryuk нужен только для дозачистки контейнеров после аварийного завершения
        # процесса — при штатном прогоне `with PostgresContainer(...)` убирает контейнер сам.
        # setdefault: Ryuk можно вернуть, выставив переменную явно. Читается лениво при старте
        # контейнера (testcontainers.core.config.ryuk_disabled — property), поэтому ставим до `with`.
        os.environ.setdefault("TESTCONTAINERS_RYUK_DISABLED", "true")
        with PostgresContainer("postgres:16-alpine") as container:
            yield container.get_connection_url()
        return

    with TemporaryDirectory(prefix="risk-test-postgres-") as directory:
        root = Path(directory)
        data = root / "data"
        password = secrets.token_urlsafe(24)
        password_file = root / "password"
        password_file.write_text(password, encoding="utf-8")
        password_file.chmod(0o600)
        subprocess.run(
            [
                str(Path(binaries) / "initdb"),
                "-D",
                str(data),
                "--username=test",
                f"--pwfile={password_file}",
                "--auth-host=scram-sha-256",
                "--auth-local=scram-sha-256",
                "--encoding=UTF8",
                "--no-locale",
            ],
            check=True,
        )
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            port = listener.getsockname()[1]
        server_log = root / "server.log"
        pg_ctl = [str(Path(binaries) / "pg_ctl"), "-D", str(data), "-w", "-t", "30"]
        try:
            started = subprocess.run(
                [*pg_ctl, "-l", str(server_log), "-o", f"-h 127.0.0.1 -p {port} -k ''", "start"],
                check=False,
            )
            if started.returncode != 0:
                # Лог сервера лежит во временном каталоге и удалится вместе с ним: причину сбоя
                # отдаём в тексте ошибки, иначе на CI останется только код возврата pg_ctl.
                log = server_log.read_text(encoding="utf-8", errors="replace") if server_log.exists() else ""
                raise RuntimeError(f"PostgreSQL не запустился, pg_ctl вернул {started.returncode}. Лог сервера:\n{log}")
            yield URL.create(
                "postgresql+psycopg2",
                username="test",
                password=password,
                host="127.0.0.1",
                port=port,
                database="postgres",
            ).render_as_string(hide_password=False)
        finally:
            if (data / "postmaster.pid").exists():
                subprocess.run([*pg_ctl, "-m", "immediate", "stop"], check=True)
