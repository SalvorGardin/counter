"""Regression tests for test-suite collection rules."""

from __future__ import annotations

import os
import subprocess  # nosec B404
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]


def _run_collection(args: list[str], *, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(  # noqa: S603
        [sys.executable, "-m", "pytest", *args, "-o", "addopts="],
        cwd=_REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=120,
    )


def test_not_db_selection_excludes_transitive_database_fixtures(tmp_path: Path) -> None:
    sample = tmp_path / "test_sample.py"
    sample.write_text(
        """
import pytest


@pytest.fixture
def db_resource(postgres_url: str) -> str:
    return postgres_url


@pytest.fixture
def migration_container() -> object:
    return object()


def test_uses_db(db_resource: str) -> None:
    assert db_resource


def test_uses_migration_db(migration_container: object) -> None:
    assert migration_container


def test_without_db() -> None:
    pass
""",
        encoding="utf-8",
    )
    env = {
        **os.environ,
        "PYTHONPATH": str(_REPO_ROOT),
        "RISK_MODEL_TESTING_API_ENABLED": "false",
    }

    result = _run_collection(
        [
            str(sample),
            "--rootdir",
            str(tmp_path),
            "-p",
            "tests.conftest",
            "--collect-only",
            "-q",
            "-m",
            "not db",
        ],
        env=env,
    )

    output = result.stdout + result.stderr
    assert result.returncode == 0, output
    assert "test_sample.py::test_without_db" in output
    assert "test_sample.py::test_uses_db" not in output
    assert "test_sample.py::test_uses_migration_db" not in output


def test_not_db_selection_has_no_database_root_fixture_in_repository(tmp_path: Path) -> None:
    guard_plugin = tmp_path / "collection_guard.py"
    guard_plugin.write_text(
        """
import pytest


@pytest.hookimpl(trylast=True)
def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    db_fixtures = {"migration_container", "postgres_url"}
    offenders = [item.nodeid for item in items if db_fixtures.intersection(getattr(item, "fixturenames", ()))]
    if offenders:
        raise pytest.UsageError("DB tests selected by 'not db': " + ", ".join(offenders))
""",
        encoding="utf-8",
    )
    env = {
        **os.environ,
        "PYTHONPATH": os.pathsep.join((str(tmp_path), str(_REPO_ROOT))),
        "RISK_MODEL_TESTING_API_ENABLED": "true",
    }

    result = _run_collection(
        [
            "tests",
            "--collect-only",
            "-q",
            "-m",
            "not db",
            "--ignore=tests/migrations",
            "-p",
            "collection_guard",
        ],
        env=env,
    )

    assert result.returncode == 0, result.stdout + result.stderr
