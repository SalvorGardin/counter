"""Контракты образа, которые не проверяет ничто другое: CI образ не собирает.

Образ обязан содержать файлы, которые сервис по умолчанию читает из рабочей директории. Файлы
лежат в корне репозитория, поэтому тесты и запуск из рабочей копии проходят и без них в образе —
отсутствие всплывает только в контейнере, отказом старта процесса. Команда образа по умолчанию
обязана запускать процесс app через его точку входа.
"""

import json
import re
from pathlib import Path

import pytest

from src.config import Settings

_DOCKERFILE = Path(__file__).resolve().parent.parent / "docker" / "Dockerfile"


def _copied_sources() -> set[str]:
    sources: set[str] = set()
    for line in _DOCKERFILE.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\s*COPY\s+(.+)\s+\S+\s*$", line)
        if match:
            sources.update(match.group(1).split())
    return sources


@pytest.mark.parametrize(
    "path",
    [Settings.model_fields["calculation_version_file"].default, "version.json"],
    ids=["calculation-version", "version"],
)
def test_runtime_file_is_copied_into_image(path: str) -> None:
    assert path in _copied_sources(), f"{path} is read at runtime but docker/Dockerfile does not COPY it"


def _default_command() -> list[str]:
    commands = [
        line.removeprefix("CMD").strip()
        for line in _DOCKERFILE.read_text(encoding="utf-8").splitlines()
        if line.startswith("CMD")
    ]
    assert len(commands) == 1, commands
    return json.loads(commands[0])


def test_default_command_starts_app_through_entry_point() -> None:
    """`python -m src` (src/__main__.py) чистит multiprocess-директорию метрик до загрузки
    приложения; `python -m src.main` сервер не запускает вовсе. Прежняя команда в образе означала
    бы контейнер, который не поднимается."""
    assert _default_command() == ["python", "-m", "src"]
