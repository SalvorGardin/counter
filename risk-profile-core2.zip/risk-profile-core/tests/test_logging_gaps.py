"""Регресс-тесты для базового логирования сервиса.

Покрывают точки, которые исторически отсутствовали и были закрыты пачкой фиксов:
integrity-error → warning, lifespan service starting/stopping с версией, probe-пути
не шумят NOTICE-ом, MonologFilter уважает settings.log_level, dispatcher алертит при
недоступной Kafka, handle_answers_reset логирует перед raise, kafka admin debug-логирует
гонку TopicAlreadyExists. Каждый тест — страховка от регрессии конкретного места."""

import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.exc import IntegrityError

from src.api.errors import integrity_error_handler
from src.logger import NOTICE


@pytest.fixture(autouse=True)
def _stub_startup_db_access(monkeypatch: pytest.MonkeyPatch) -> None:
    """lifespan строит каталоги через catalog_builder (своя сессия БД + заморозка heap) и
    сверяет логин рантайма с БД; эти тесты про логи и гоняют lifespan без БД вовсе."""
    monkeypatch.setattr("src.main.catalog_builder", AsyncMock(return_value=MagicMock()))
    monkeypatch.setattr("src.main.verify_runtime_login", AsyncMock())


# ---------------------------------------------------------------------------
# Fix 1 (P1-1) — integrity_error_handler logs warning
# ---------------------------------------------------------------------------


async def test_integrity_error_handler_logs_warning() -> None:
    """integrity_error_handler must emit a WARNING log with the underlying DB error."""
    orig = Exception("duplicate key value violates unique constraint")
    exc = IntegrityError("INSERT", {}, orig)
    with patch("src.api.errors.logger") as mock_logger:
        response = await integrity_error_handler(None, exc)  # ty: ignore[invalid-argument-type]
    assert response.status_code == 409
    mock_logger.warning.assert_called_once()
    assert "integrity error" in mock_logger.warning.call_args[0][0]


# ---------------------------------------------------------------------------
# Fix 2 (P1-2) — lifespan emits notice on startup and shutdown
# ---------------------------------------------------------------------------


def _lifespan_mocks():
    return (
        patch("src.main.init_kafka_producer", new_callable=AsyncMock),
        patch("src.main.init_cvd_client", new_callable=AsyncMock),
        patch("src.main.shutdown_cvd_client", new_callable=AsyncMock),
        patch("src.main.shutdown_kafka_producer", new_callable=AsyncMock),
        patch("src.main.shutdown_primary_runtime", new_callable=AsyncMock),
    )


async def test_lifespan_logs_service_starting() -> None:
    """Lifespan context manager must notice 'service starting' before yielding."""
    import src.main as main_module

    p1, p2, p3, p4, p5 = _lifespan_mocks()
    with p1, p2, p3, p4, p5, patch("src.main.notice") as mock_notice:
        async with main_module.lifespan(main_module.app):
            pass
        main_module._is_shutting_down = False

    messages = [c[0][0] for c in mock_notice.call_args_list]
    assert any("service starting" in m for m in messages)


async def test_lifespan_logs_service_stopping() -> None:
    """Lifespan context manager must notice 'service stopping' in the finally block."""
    import src.main as main_module

    p1, p2, p3, p4, p5 = _lifespan_mocks()
    with p1, p2, p3, p4, p5, patch("src.main.notice") as mock_notice:
        async with main_module.lifespan(main_module.app):
            pass
        main_module._is_shutting_down = False

    messages = [c[0][0] for c in mock_notice.call_args_list]
    assert any("service stopping" in m for m in messages)


async def test_lifespan_includes_version_in_startup_notice() -> None:
    """Startup notice must carry a 'version' key so rollbacks are visible in logs."""
    import src.main as main_module

    p1, p2, p3, p4, p5 = _lifespan_mocks()
    with p1, p2, p3, p4, p5, patch("src.main.notice") as mock_notice:
        async with main_module.lifespan(main_module.app):
            pass
        main_module._is_shutting_down = False

    starting_calls = [c for c in mock_notice.call_args_list if "service starting" in c[0][0]]
    assert starting_calls, "no 'service starting' notice found"
    ctx = starting_calls[0][1].get("context") or starting_calls[0][0][1]
    assert "version" in ctx


# ---------------------------------------------------------------------------
# Fix 3 (P1-3) — probe paths skip request-completed notice
# ---------------------------------------------------------------------------


def test_probe_path_does_not_emit_request_completed_notice() -> None:
    """Requests to /health must NOT produce a NOTICE-level 'request completed' log."""
    from src.main import app

    with patch("src.main.notice") as mock_notice:
        with TestClient(app) as client:
            client.get("/health")

    request_completed = [c for c in mock_notice.call_args_list if c[0][0] == "request completed"]
    assert not request_completed


def test_non_probe_path_emits_request_completed_notice() -> None:
    """Regular API requests must still produce a NOTICE-level 'request completed' log."""
    from src.main import app

    with patch("src.main.notice") as mock_notice:
        with TestClient(app) as client:
            client.get("/openapi.json")

    request_completed = [c for c in mock_notice.call_args_list if c[0][0] == "request completed"]
    assert request_completed


# ---------------------------------------------------------------------------
# Fix 4 (P1-4) — MonologFilter respects settings.log_level threshold
# ---------------------------------------------------------------------------


def test_monolog_filter_suppresses_notice_when_level_set_to_warning() -> None:
    """When log_level='WARNING', NOTICE-level records must be filtered out."""
    import src.config as config_module
    from src.logger import MonologFilter, debug_enabled_var

    mock_settings = type("S", (), {"log_level": "WARNING"})()
    f = MonologFilter()
    token = debug_enabled_var.set(False)
    try:
        with patch.object(config_module, "settings", mock_settings):
            notice_record = logging.LogRecord("app", NOTICE, "", 0, "test", (), None)
            warning_record = logging.LogRecord("app", logging.WARNING, "", 0, "test", (), None)
            assert not f.filter(notice_record)
            assert f.filter(warning_record)
    finally:
        debug_enabled_var.reset(token)


def test_monolog_filter_default_threshold_allows_notice() -> None:
    """Default log_level='NOTICE' must pass NOTICE-level records."""
    import src.config as config_module
    from src.logger import MonologFilter, debug_enabled_var

    mock_settings = type("S", (), {"log_level": "NOTICE"})()
    f = MonologFilter()
    token = debug_enabled_var.set(False)
    try:
        with patch.object(config_module, "settings", mock_settings):
            notice_record = logging.LogRecord("app", NOTICE, "", 0, "test", (), None)
            assert f.filter(notice_record)
    finally:
        debug_enabled_var.reset(token)


# ---------------------------------------------------------------------------
# Fix 5 (P2-5) — dispatcher raises an alert when kafka enabled but producer unavailable
# ---------------------------------------------------------------------------


async def test_dispatch_recalc_alerts_when_kafka_enabled_but_unavailable() -> None:
    """When kafka.enabled=True but producer not started, dispatcher must alert (no inline fallback)."""
    from src.calc.dispatcher import dispatch_recalc
    from src.infra.kafka.exceptions import KafkaInitError

    mock_kafka_settings = type("K", (), {"enabled": True})()
    mock_settings = type("S", (), {"kafka": mock_kafka_settings})()

    with (
        patch("src.calc.dispatcher.get_kafka_producer", side_effect=KafkaInitError("not init")),
        patch("src.calc.dispatcher.settings", mock_settings),
        patch("src.calc.dispatcher.alert") as mock_alert,
    ):
        await dispatch_recalc("patient-123", None)

    mock_alert.assert_called()
    msg = mock_alert.call_args[0][0]
    assert "kafka" in msg.lower()


# ---------------------------------------------------------------------------
# Fix 6 (P2-6) — SystemCodeRequiredError is preceded by a notice log
# ---------------------------------------------------------------------------


async def test_handle_answers_reset_logs_before_raising_when_system_codes_missing() -> None:
    """handle_answers_reset must emit a notice before raising SystemCodeRequiredError."""
    from src.services.risk_event.domain.exceptions import SystemCodeRequiredError
    from src.services.risk_event.service import RiskEventService

    service = RiskEventService(session=None, catalog=None)  # ty: ignore[invalid-argument-type]
    with patch("src.services.risk_event.service.notice") as mock_notice:
        with pytest.raises(SystemCodeRequiredError):
            await service.handle_answers_reset("client-123", None)

    mock_notice.assert_called()


# ---------------------------------------------------------------------------
# Fix 7 (P2-9) — TopicAlreadyExistsError race is logged at debug
# ---------------------------------------------------------------------------


async def test_kafka_admin_logs_debug_on_topic_already_exists_race() -> None:
    """ensure_topics must log a DEBUG message when it loses a concurrent-create race."""
    from aiokafka.errors import TopicAlreadyExistsError

    from src.config import KafkaSettings
    from src.infra.kafka.admin import ensure_topics

    kafka_settings = KafkaSettings(
        enabled=True,
        bootstrap_servers="localhost:9092",
        security_protocol="PLAINTEXT",
    )

    mock_admin = AsyncMock()
    mock_admin.start = AsyncMock()
    mock_admin.list_topics = AsyncMock(return_value=set())
    mock_admin.create_topics = AsyncMock(side_effect=TopicAlreadyExistsError())
    mock_admin.close = AsyncMock()

    with (
        patch("src.infra.kafka.admin.AIOKafkaAdminClient", return_value=mock_admin),
        patch("src.infra.kafka.admin.logger") as mock_logger,
    ):
        await ensure_topics(kafka_settings, ["test-topic"])

    mock_logger.debug.assert_called()
    msg = mock_logger.debug.call_args[0][0]
    assert "already exist" in msg or "race" in msg
