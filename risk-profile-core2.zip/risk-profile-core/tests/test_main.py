"""Tests for Risk Model Service."""

import uuid

import pytest
from fastapi.testclient import TestClient

import src.main as _main_module
from src.calc.version import calculation_version
from src.main import app
from tests.conftest import LogSink

client = TestClient(app)


@pytest.fixture(autouse=True)
def _reset_shutdown_flag() -> None:
    """Сбрасываем модульный флаг перед каждым тестом.

    TestClient не запускает lifespan в non-context-manager режиме, поэтому
    startup-сброс _is_shutting_down = False в lifespan не срабатывает.
    Флаг может быть оставлен в True тестами, которые напрямую запускают lifespan
    (например, test_logging_gaps.py), поэтому сбрасываем явно.
    """
    _main_module._is_shutting_down = False


def test_greet_status() -> None:
    """Greeting endpoint returns 200."""
    response = client.get("/")
    assert response.status_code == 200


def test_greet_body() -> None:
    """Greeting endpoint returns expected message."""
    response = client.get("/")
    assert response.json() == {"message": "Привет от Risk Model Service!"}


@pytest.mark.parametrize(
    ("path", "expected_status"),
    [("/readiness", "ready"), ("/liveness", "alive")],
)
def test_probe_returns_200_with_its_status(path: str, expected_status: str) -> None:
    response = client.get(path)
    assert response.status_code == 200
    assert response.json() == {"status": expected_status}


def test_health_reports_catalog_build_time() -> None:
    """`/health` отдаёт метку сборки каталога: по ней видно, что процесс перечитал справочники,
    а не просто поднялся со старым каталогом в RAM (см. src/workers/restarter.py)."""
    _main_module.app.state.catalog_loaded_at = "2026-09-08T12:00:00+00:00"
    try:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {
            "status": "ok",
            "catalog_loaded_at": "2026-09-08T12:00:00+00:00",
            "calculation_version": calculation_version(),
        }
    finally:
        del _main_module.app.state.catalog_loaded_at


def test_health_reports_null_catalog_build_time_before_lifespan() -> None:
    """До прогона lifespan каталога ещё нет — проба обязана отвечать 200, а не падать на атрибуте."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["catalog_loaded_at"] is None


def test_health_reports_calculation_version() -> None:
    """Версия расчёта стоит в пробе рядом с меткой каталога: по ней снаружи проверяется, что
    раскат завершён и реестр версий штампует уже новый релиз."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["calculation_version"] == calculation_version()


def test_health_survives_unavailable_calculation_version(monkeypatch: pytest.MonkeyPatch) -> None:
    """Проба обязана отвечать всегда: недоступная версия отдаётся как null, а не как 500."""
    monkeypatch.setattr(_main_module.settings, "calculation_version_file", "no-such-version.json")
    calculation_version.cache_clear()
    try:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["calculation_version"] is None
    finally:
        calculation_version.cache_clear()


def test_readiness_shutting_down() -> None:
    """Readiness returns 503 once _is_shutting_down flag is set."""
    import src.main as main_module  # noqa: PLC0415

    main_module._is_shutting_down = True
    try:
        response = client.get("/readiness")
        assert response.status_code == 503
        assert response.json() == {"status": "shutting_down"}
    finally:
        main_module._is_shutting_down = False


# --- Нормализация хвостового слеша у /api/* (StripTrailingSlashMiddleware) ---


def test_api_trailing_slash_reaches_handler_without_redirect() -> None:
    """POST на /api/*-путь со слешем должен попасть в хендлер, а НЕ получить 307 (который на
    POST за прокси/в Postman оборачивается «404»). 400 = тело дошло до валидации ручки."""
    response = client.post(
        "/api/v1/clients/c-1/anthropometry/",
        json={"heightCm": 10},  # вне ge=50 → доменная ошибка ИМЕННО от хендлера, не редирект
        follow_redirects=False,
    )
    assert response.status_code == 400
    # Тот же результат, что и без слеша — нормализация прозрачна.
    baseline = client.post("/api/v1/clients/c-1/anthropometry", json={"heightCm": 10})
    assert baseline.status_code == 400


def test_api_multiple_trailing_slashes_normalized() -> None:
    """Несколько хвостовых слешей тоже снимаются (rstrip), а не множат 404."""
    response = client.get("/api/v1/clients/c-1/medical-risk///", follow_redirects=False)
    assert response.status_code != 307


def test_api_trailing_slash_logged_as_sent_by_client() -> None:
    """Логирующая мидлварь внешняя: в "request completed" path остаётся РОВНО как прислал
    клиент (со слешем), хотя роутер уже получил нормализованный путь."""
    from unittest.mock import patch

    with patch("src.main.notice") as mock_notice:
        client.post("/api/v1/clients/c-1/anthropometry/", json={"heightCm": 10}, follow_redirects=False)
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert len(completed) == 1
    ctx = completed[0].kwargs["context"]
    assert ctx["path"] == "/api/v1/clients/c-1/anthropometry/"
    assert ctx["status_code"] == 400  # и при этом запрос реально обработан, не отредиректен


def test_non_api_trailing_slash_left_to_default_behaviour() -> None:
    """Скоуп — только /api/*: у пробы хвостовой слеш не нормализуем (дефолтный 307),
    чтобы не задеть статический mount /questionnaire, где слеш значим."""
    response = client.get("/health/", follow_redirects=False)
    assert response.status_code == 307


def test_x_enable_debug_header_accepted() -> None:
    """X-Enable-Debug header does not break requests."""
    response = client.get("/health", headers={"X-Enable-Debug": "true"})
    assert response.status_code == 200


def test_authorization_header_accepted() -> None:
    """Authorization header does not break requests."""
    response = client.get("/health", headers={"Authorization": "Bearer token123"})
    assert response.status_code == 200


def test_x_enable_debug_various_values_accepted() -> None:
    """X-Enable-Debug принимает разные truthy-значения без ошибок."""
    for value in ("true", "1", "yes", "false", ""):
        response = client.get("/health", headers={"X-Enable-Debug": value})
        assert response.status_code == 200


def test_is_debug_enabled_accepts_only_whitelisted_truthy_values() -> None:
    """Граница доверия: truthy = только "1"/"true"/"yes" (case-insensitive). Всё остальное → False.

    Это решает две задачи: (1) гейтит локальный debug-режим; (2) даёт middleware канонический
    "true"/"" для проброса в downstream — длинные пэйлоады и инъекции из X-Enable-Debug
    не уходят в headers Kafka/httpx2 (контекст: ревью MR-D)."""
    from src.main import _is_debug_enabled  # noqa: PLC0415

    # Truthy whitelist + кейс-инсенситивность.
    for v in ("1", "true", "yes", "TRUE", "Yes"):
        assert _is_debug_enabled(v) is True, v

    # Любые другие значения — False, в т.ч. мусор / килобайтный пэйлоад / "false".
    for v in ("", "false", "no", "0", "tru", "yess", "x" * 10_000 + "<script>"):
        assert _is_debug_enabled(v) is False, v[:30]


def test_x_request_id_from_header_echoed() -> None:
    """Входящий X-Request-ID сохраняется и возвращается в ответе без изменений."""
    incoming = "client-correlation-42"
    response = client.get("/health", headers={"X-Request-ID": incoming})
    assert response.status_code == 200
    assert response.headers["X-Request-ID"] == incoming


def test_x_request_id_generated_when_absent() -> None:
    """Без входящего X-Request-ID сервис генерирует валидный UUID4 и возвращает его в ответе."""
    response = client.get("/health")
    assert response.status_code == 200
    generated = response.headers["X-Request-ID"]
    assert uuid.UUID(generated).version == 4


# --- Дамп тела и заголовков запроса в "request completed" ---


def test_request_completed_includes_body_and_headers() -> None:
    """QA-решение (06.2026): тело и заголовки входящего запроса логируются всегда;
    маскирование по env-списку делает MonologFormatter, middleware кладёт сырые данные."""
    from unittest.mock import patch

    with patch("src.main.notice") as mock_notice:
        response = client.post(
            "/api/v1/clients/c-1/questions/answers",
            json={"questionCode": "sq_010", "answer": "5"},
            headers={"X-Custom": "v1"},
        )
    assert response.status_code in (400, 404, 422, 500)  # без БД важен только факт логирования
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert len(completed) == 1
    ctx = completed[0].kwargs["context"]
    assert ctx["status_code"] == response.status_code
    assert ctx["request_body"] == {"questionCode": "sq_010", "answer": "5"}
    assert ctx["request_headers"]["x-custom"] == "v1"
    assert ctx["method"] == "POST"
    # url логируется С ХОСТОМ (scheme://host/path), path остаётся без хоста.
    assert ctx["path"] == "/api/v1/clients/c-1/questions/answers"
    assert ctx["url"] == "http://testserver/api/v1/clients/c-1/questions/answers"


def test_request_completed_includes_response_body() -> None:
    """Тело ответа логируется симметрично телу запроса (жалоба тестера 06.2026): JSON-ответ
    ручки виден в context.response_body как структура, и это РОВНО то, что получил клиент
    (доказывает, что пересборка ответа после вычитки body_iterator его не исказила)."""
    from unittest.mock import patch

    with patch("src.main.notice") as mock_notice:
        response = client.post(
            "/api/v1/clients/c-1/questions/answers",
            json={"questionCode": "sq_010", "answer": "5"},
        )
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert len(completed) == 1
    ctx = completed[0].kwargs["context"]
    # JSON-ответ (error envelope) распарсен в dict — не строка, не маркер; равен телу у клиента.
    assert isinstance(ctx["response_body"], dict)
    assert ctx["response_body"] == response.json()


def test_request_completed_empty_body_logged_as_none() -> None:
    from unittest.mock import patch

    with patch("src.main.notice") as mock_notice:
        client.get("/api/v1/clients/c-1/medical-risk")  # GET без тела (не probe-путь)
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert len(completed) == 1
    assert completed[0].kwargs["context"]["request_body"] is None


def test_probe_paths_do_not_dump_body() -> None:
    """Probe-пути остаются на DEBUG без дампа — не шумят в NOTICE."""
    from unittest.mock import patch

    with patch("src.main.notice") as mock_notice:
        client.get("/health")
    assert not [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]


def test_downstream_handler_still_reads_body_after_middleware_dump() -> None:
    """Middleware читает body до call_next — Starlette должен отдать его хендлеру повторно
    (контракт _CachedRequest). Валидационный 400 по полю тела доказывает, что тело дошло."""
    response = client.post(
        "/api/v1/clients/c-1/anthropometry",
        json={"heightCm": 10},  # вне диапазона ge=50 → pydantic-ошибка ИМЕННО по телу
    )
    assert response.status_code == 400


def test_secret_header_masked_end_to_end(captured_app_logs: LogSink) -> None:
    """Сквозной тест реального шва (middleware → notice → FingersCrossed → Formatter → stream):
    секретные заголовки и тело выходят в JSON-строку лога замаскированными."""
    import json as _json

    client.post(
        "/api/v1/clients/c-1/questions/answers",
        json={"answer": "5"},
        headers={"Authorization": "Bearer real-token-value", "X-Test-Api-Key": "k" * 16},
    )
    out = captured_app_logs.output()
    completed = [ln for ln in out.splitlines() if '"request completed"' in ln]
    assert completed, "request completed must be emitted to stream"
    entry = _json.loads(completed[-1])
    # blob-поля выходят одной JSON-строкой (см. logger._BLOB_CONTEXT_KEYS) — парсим обратно.
    assert isinstance(entry["context"]["request_body"], str)
    assert isinstance(entry["context"]["request_headers"], str)
    # response_body проходит тот же blob-путь форматтера — на проводе это строка, не объект.
    assert isinstance(entry["context"]["response_body"], str)
    rh = _json.loads(entry["context"]["request_headers"])
    rb = _json.loads(entry["context"]["request_body"])
    assert rh["authorization"] == "***"
    assert rh["x-test-api-key"] == "***"
    assert rb["answer"] == "***"  # дефолтный маск-лист
    assert "real-token-value" not in out


async def test_client_disconnect_during_body_read_degrades_to_none() -> None:
    """Обрыв клиента при чтении тела не роняет middleware — request_body становится None."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from starlette.requests import ClientDisconnect

    from src.main import request_middleware

    request = MagicMock()
    request.headers = {}
    request.url.path = "/api/v1/clients/c-1/questions/answers"
    request.method = "POST"
    request.body = AsyncMock(side_effect=ClientDisconnect())
    response = MagicMock()
    response.status_code = 200
    response.headers = {}
    call_next = AsyncMock(return_value=response)

    with patch("src.main.notice") as mock_notice:
        result = await request_middleware(request, call_next)

    assert result is response
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert completed[0].kwargs["context"]["request_body"] is None


def _request_mock(headers: dict[str, str]):
    """MagicMock-запрос для unit-тестов middleware (не probe-путь, POST)."""
    from unittest.mock import MagicMock

    request = MagicMock()
    request.headers = headers
    request.url.path = "/api/v1/clients/c-1/questions/answers"
    request.method = "POST"
    return request


async def test_unexpected_body_read_error_degrades_to_marker() -> None:
    """Неожиданный сбой чтения тела (повторное ревью !99): запрос не падает, в request_body
    идёт маркер, сбой виден в логе как warning — регресс к молчаливому глотанию или
    к пробросу исключения сквозь middleware провалит этот тест."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from src.main import request_middleware

    request = _request_mock({"content-length": "5"})
    request.body = AsyncMock(side_effect=RuntimeError("broken stream"))
    response = MagicMock()
    response.status_code = 200
    response.headers = {}
    call_next = AsyncMock(return_value=response)

    with patch("src.main.notice") as mock_notice, patch("src.main.logger") as mock_logger:
        result = await request_middleware(request, call_next)

    assert result is response
    mock_logger.warning.assert_called_once()
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    # dict-маркер, не строка: единый тип поля для ES (иначе Kibana type=conflict).
    assert completed[0].kwargs["context"]["request_body"] == {"_omitted": "body read error"}


async def test_oversized_declared_body_is_not_read_at_all() -> None:
    """Content-Length сверх лимита (повторное ревью !99): тело НЕ читается — request.body()
    буферит всё тело в RAM, и без guard'а клиент без авторизации выедает память
    гигабайтным POST. В лог идёт тот же маркер, что у body_for_log для сверхлимита."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from src.config import settings
    from src.main import request_middleware

    request = _request_mock({"content-length": str(10**9)})
    request.body = AsyncMock()
    response = MagicMock()
    response.status_code = 200
    response.headers = {}
    call_next = AsyncMock(return_value=response)

    with patch("src.main.notice") as mock_notice:
        result = await request_middleware(request, call_next)

    assert result is response
    request.body.assert_not_called()
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    expected = {"_omitted": f"{10**9} bytes > {settings.log_body_max_bytes} cap"}
    assert completed[0].kwargs["context"]["request_body"] == expected


async def test_chunked_body_without_content_length_is_not_read() -> None:
    """Тело без Content-Length (chunked): размер не узнать не читая — не читаем, маркер."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from src.main import request_middleware

    request = _request_mock({"transfer-encoding": "chunked"})
    request.body = AsyncMock()
    response = MagicMock()
    response.status_code = 200
    response.headers = {}
    call_next = AsyncMock(return_value=response)

    with patch("src.main.notice") as mock_notice:
        result = await request_middleware(request, call_next)

    assert result is response
    request.body.assert_not_called()
    completed = [c for c in mock_notice.call_args_list if c.args[0] == "request completed"]
    assert completed[0].kwargs["context"]["request_body"] == {"_omitted": "no content-length (chunked)"}


async def test_request_body_for_log_is_always_dict_or_none() -> None:
    """Контракт типа для ES на уровне middleware-хелпера: при любом сценарии (валидное тело,
    маркеры guard'а, ошибка, обрыв) request_body — dict|None, никогда строка. Иначе
    context.request_body разъезжается по типам между индексами → Kibana type=conflict
    (реальная жалоба тестера, 06.2026)."""
    from unittest.mock import AsyncMock, patch

    from starlette.requests import ClientDisconnect

    from src.main import _request_body_for_log

    scenarios = [
        ({"content-length": "8"}, AsyncMock(return_value=b'{"a": 1}')),  # норм JSON
        ({"content-length": "not-a-number"}, AsyncMock()),  # битый Content-Length
        ({"content-length": str(10**9)}, AsyncMock()),  # сверхлимит
        ({"transfer-encoding": "chunked"}, AsyncMock()),  # chunked
        ({"content-length": "5"}, AsyncMock(side_effect=RuntimeError("x"))),  # ошибка чтения
        ({"content-length": "5"}, AsyncMock(side_effect=ClientDisconnect())),  # обрыv
    ]
    with patch("src.main.logger"):
        for headers, body_mock in scenarios:
            request = _request_mock(headers)
            request.body = body_mock
            result = await _request_body_for_log(request)
            assert result is None or isinstance(result, dict), f"{headers} -> {type(result).__name__}"


# --- Дамп тела ответа в "request completed" (_response_body_for_log) ---


def _fake_response(body: bytes, headers: dict[str, str], status_code: int = 200):
    """Имитация _StreamingResponse от call_next: одноразовый async body_iterator + raw_headers."""
    from unittest.mock import MagicMock

    from starlette.datastructures import Headers

    async def _gen():
        yield body

    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = Headers(headers)
    resp.raw_headers = [(k.lower().encode(), v.encode()) for k, v in headers.items()]
    resp.body_iterator = _gen()
    return resp


async def test_response_body_buffered_and_replayed_for_json() -> None:
    """JSON-ответ в пределах лимита: тело распарсено для лога, а одноразовый body_iterator
    переустановлен на повтор прочитанного — клиент получает РОВНО те же байты."""
    from src.main import _response_body_for_log

    payload = b'{"isSuccess": true, "error": null}'
    resp = _fake_response(payload, {"content-length": str(len(payload)), "content-type": "application/json"})
    out, logged = await _response_body_for_log(resp)

    assert logged == {"isSuccess": True, "error": None}
    assert out is resp  # тот же объект (заголовки/фон/info на месте), переустановлен лишь итератор
    replayed = b"".join([chunk async for chunk in out.body_iterator])
    assert replayed == payload


async def test_response_body_non_bytes_chunk_replayed_not_buffered() -> None:
    """pathsend FileResponse с JSON Content-Type: среди чанков — ASGI-dict, его нельзя
    скормить b"".join. Тело не логируем (маркер), но поток проигрываем БЕЗ искажения —
    и dict, и bytes доходят до клиента в исходном порядке."""
    from unittest.mock import MagicMock

    from starlette.datastructures import Headers

    from src.main import _response_body_for_log

    pathsend = {"type": "http.response.pathsend", "path": "/srv/file.json"}

    async def _gen():
        yield pathsend
        yield b"tail"

    resp = MagicMock()
    resp.status_code = 200
    resp.headers = Headers({"content-length": "100", "content-type": "application/json"})
    resp.body_iterator = _gen()

    out, logged = await _response_body_for_log(resp)
    assert out is resp
    assert logged == {"_omitted": "non-buffered streaming response"}
    replayed = [chunk async for chunk in out.body_iterator]
    assert replayed == [pathsend, b"tail"]  # порядок и dict-сообщение сохранены


async def test_response_body_marker_when_no_content_length() -> None:
    """Стрим без Content-Length: не буферим (размер неизвестен), response отдаём нетронутым."""
    from unittest.mock import MagicMock

    from src.main import _response_body_for_log

    resp = MagicMock()
    resp.headers = {}  # ни Content-Length, ни Content-Type
    out, logged = await _response_body_for_log(resp)
    assert out is resp
    assert logged == {"_omitted": "no content-length (streaming response)"}


async def test_response_body_marker_when_oversized() -> None:
    """Тело сверх лимита: маркер тот же, что у запроса; итератор не читаем."""
    from unittest.mock import MagicMock

    from src.config import settings
    from src.main import _response_body_for_log

    resp = MagicMock()
    resp.headers = {"content-length": str(10**9), "content-type": "application/json"}
    out, logged = await _response_body_for_log(resp)
    assert out is resp
    assert logged == {"_omitted": f"{10**9} bytes > {settings.log_body_max_bytes} cap"}


async def test_response_body_marker_for_non_json() -> None:
    """Не-JSON ответ (StaticFiles/JS/бинарь): не буферим — защита от pathsend в body_iterator."""
    from unittest.mock import MagicMock

    from src.main import _response_body_for_log

    resp = MagicMock()
    resp.headers = {"content-length": "10", "content-type": "text/html; charset=utf-8"}
    out, logged = await _response_body_for_log(resp)
    assert out is resp
    assert logged == {"_omitted": "non-JSON response, content-type=text/html; charset=utf-8"}


async def test_response_body_marker_for_invalid_content_length() -> None:
    from unittest.mock import MagicMock

    from src.main import _response_body_for_log

    resp = MagicMock()
    resp.headers = {"content-length": "not-a-number", "content-type": "application/json"}
    out, logged = await _response_body_for_log(resp)
    assert out is resp
    assert logged == {"_omitted": "invalid content-length"}


async def test_response_body_read_error_replays_what_was_read(caplog: pytest.LogCaptureFixture) -> None:
    """Поток оборвался на середине: клиент получает уже прочитанные чанки, а не пустое тело.

    Итератор ответа одноразовый — прочитанное из него исчезает. Если сбой логирования оставит
    его «выпитым», сбой обзервабилити превратится в испорченный ответ реальному клиенту.
    """
    import logging  # noqa: PLC0415
    from unittest.mock import MagicMock  # noqa: PLC0415

    from starlette.datastructures import Headers  # noqa: PLC0415

    from src.main import _response_body_for_log  # noqa: PLC0415

    async def _gen():
        yield b'{"isSuccess":'
        raise ConnectionResetError("upstream gone")

    resp = MagicMock()
    resp.status_code = 200
    resp.headers = Headers({"content-length": "40", "content-type": "application/json"})
    resp.body_iterator = _gen()

    with caplog.at_level(logging.WARNING, logger="app"):
        out, logged = await _response_body_for_log(resp)

    assert out is resp
    assert logged == {"_omitted": "body read error"}
    assert [chunk async for chunk in out.body_iterator] == [b'{"isSuccess":']
    assert "failed to read response body for logging" in caplog.text
