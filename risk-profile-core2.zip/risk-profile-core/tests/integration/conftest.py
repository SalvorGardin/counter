# Integration fixtures are provided by tests/conftest.py (postgres_url, db_session).
