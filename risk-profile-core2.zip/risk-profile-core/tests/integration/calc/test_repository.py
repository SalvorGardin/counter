from dataclasses import replace
from datetime import timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import (
    FormulaResult,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from src.calc.infra.repository import CalcRepository
from src.constants import ResultInterpretationStatus
from tests.factories import Factory


async def _seed(factory: Factory, param_code: str, instrument_code: str) -> tuple[str, str, str]:
    patient_id = await factory.patient()
    await factory.parameter(param_code)
    await factory.instrument(instrument_code)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code, is_required=True)
    return patient_id, param_code, instrument_code


def _make_result(patient_id: str, instrument_code: str, score: float = 1.5) -> FormulaResult:
    return FormulaResult(
        instrument_code=instrument_code,
        patient_id=patient_id,
        value=score,
        unit=InstrumentsUnits.SPILLBERGER_HANIN,
        risk_level=InstrumentsRiskLevel.LOW,
        applicability=True,
        interpretation_status=ResultInterpretationStatus.READY,
        expiration_delta=timedelta(days=36500),
        indicator=InstrumentsIndicators.SPILLBERGER_HANIN_PERSONAL,
    )


class TestSingleResultBatch:
    async def test_inserts_result_row(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P1", "UR_I1")
        await db_session.commit()

        async with db_session.begin():
            await CalcRepository(db_session).upsert_results_batch([_make_result(patient_id, instrument_code, 1.5)])

        r = await db_session.execute(
            text("SELECT value FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        assert float(r.scalar_one()) == pytest.approx(1.5)

    async def test_upsert_overwrites_on_conflict(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P2", "UR_I2")
        await db_session.commit()
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 1.0)])
        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 2.5)])

        r = await db_session.execute(
            text("SELECT value FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        rows = r.all()
        assert len(rows) == 1
        assert float(rows[0].value) == pytest.approx(2.5)

    async def test_each_upsert_appends_to_history(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P3", "UR_I3")
        await db_session.commit()
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 1.0)])
        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 2.5)])

        r = await db_session.execute(
            text(
                "SELECT value FROM results_history WHERE patient_id = :pid "
                "AND instrument_code = :icode ORDER BY result_history_id"
            ),
            {"pid": patient_id, "icode": instrument_code},
        )
        history_rows = r.all()
        assert len(history_rows) == 2
        assert float(history_rows[0].value) == pytest.approx(1.0)
        assert float(history_rows[1].value) == pytest.approx(2.5)

    async def test_re_upsert_with_nan_score_writes_history_each_time(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P5", "UR_I5")
        await db_session.commit()
        repo = CalcRepository(db_session)
        nan_result = _make_result(patient_id, instrument_code, float("nan"))

        async with db_session.begin():
            await repo.upsert_results_batch([nan_result])
        async with db_session.begin():
            await repo.upsert_results_batch([nan_result])

        r = await db_session.execute(
            text("SELECT value FROM results_history WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        assert len(r.all()) == 2

    async def test_re_upsert_with_same_value_writes_history_each_time(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P4", "UR_I4")
        await db_session.commit()
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 3.0)])
        async with db_session.begin():
            await repo.upsert_results_batch([_make_result(patient_id, instrument_code, 3.0)])

        r = await db_session.execute(
            text("SELECT value FROM results_history WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        assert len(r.all()) == 2

        r = await db_session.execute(
            text("SELECT value FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        rows = r.all()
        assert len(rows) == 1
        assert float(rows[0].value) == pytest.approx(3.0)

    async def test_applicability_true_stored_as_bool(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P6", "UR_I6")
        await db_session.commit()

        async with db_session.begin():
            await CalcRepository(db_session).upsert_results_batch([_make_result(patient_id, instrument_code)])

        r = await db_session.execute(
            text("SELECT applicability FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        value = r.scalar_one()
        assert value is True
        assert type(value) is bool

    async def test_applicability_false_stored_as_bool(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P7", "UR_I7")
        await db_session.commit()
        result = _make_result(patient_id, instrument_code)
        result = replace(result, applicability=False)

        async with db_session.begin():
            await CalcRepository(db_session).upsert_results_batch([result])

        r = await db_session.execute(
            text("SELECT applicability FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        value = r.scalar_one()
        assert value is False
        assert type(value) is bool

    async def test_applicability_change_writes_both_values_to_history(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, instrument_code = await _seed(factory, "UR_P8", "UR_I8")
        await db_session.commit()
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch([replace(_make_result(patient_id, instrument_code), applicability=True)])
        async with db_session.begin():
            await repo.upsert_results_batch([replace(_make_result(patient_id, instrument_code), applicability=False)])

        r = await db_session.execute(
            text(
                "SELECT applicability FROM results_history"
                " WHERE patient_id = :pid AND instrument_code = :icode"
                " ORDER BY result_history_id"
            ),
            {"pid": patient_id, "icode": instrument_code},
        )
        rows = r.all()
        assert len(rows) == 2
        assert rows[0].applicability is True
        assert rows[1].applicability is False


class TestUpsertResultsBatch:
    @staticmethod
    async def _seed_two_instruments(session: AsyncSession, factory: Factory) -> tuple[str, str, str]:
        """One patient with two distinct instruments, both result-eligible."""
        patient_id, _, instrument_a = await _seed(factory, "BR_P1", "BR_IA")
        await factory.instrument("BR_IB")
        await session.commit()
        return patient_id, instrument_a, "BR_IB"

    async def test_batch_inserts_all_result_rows(self, db_session: AsyncSession, factory: Factory):
        patient_id, instrument_a, instrument_b = await self._seed_two_instruments(db_session, factory)
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch(
                [
                    _make_result(patient_id, instrument_a, 1.0),
                    _make_result(patient_id, instrument_b, 2.0),
                ]
            )

        r = await db_session.execute(
            text("SELECT instrument_code, value FROM results WHERE patient_id = :pid ORDER BY instrument_code"),
            {"pid": patient_id},
        )
        rows = r.all()
        assert len(rows) == 2
        assert {row.instrument_code for row in rows} == {instrument_a, instrument_b}

    async def test_batch_appends_all_to_history(self, db_session: AsyncSession, factory: Factory):
        patient_id, instrument_a, instrument_b = await self._seed_two_instruments(db_session, factory)
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch(
                [
                    _make_result(patient_id, instrument_a, 1.0),
                    _make_result(patient_id, instrument_b, 2.0),
                ]
            )

        r = await db_session.execute(
            text("SELECT instrument_code FROM results_history WHERE patient_id = :pid"),
            {"pid": patient_id},
        )
        assert len(r.all()) == 2

    async def test_batch_shares_single_timestamp(self, db_session: AsyncSession, factory: Factory):
        # The accepted design: one now() per batch — all rows share date_time/expiration_date.
        patient_id, instrument_a, instrument_b = await self._seed_two_instruments(db_session, factory)
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch(
                [
                    _make_result(patient_id, instrument_a, 1.0),
                    _make_result(patient_id, instrument_b, 2.0),
                ]
            )

        r = await db_session.execute(
            text("SELECT DISTINCT date_time FROM results WHERE patient_id = :pid"),
            {"pid": patient_id},
        )
        assert len(r.all()) == 1

    async def test_duplicate_key_in_batch_keeps_last_and_records_both_in_history(
        self, db_session: AsyncSession, factory: Factory
    ):
        """Дубль (patient, instrument, indicator) внутри одной пачки не ломает upsert.

        Пачка пишется одним `INSERT .. ON CONFLICT DO UPDATE`, а Postgres запрещает задеть одну
        строку дважды в пределах такого стейтмента («cannot affect row a second time»). Репозиторий
        схлопывает дубли, сохраняя прежнюю семантику последовательных upsert'ов: выигрывает
        последний. В history (аудит) обе записи остаются.
        """
        patient_id, instrument_a, _ = await self._seed_two_instruments(db_session, factory)
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch(
                [
                    _make_result(patient_id, instrument_a, 1.0),
                    _make_result(patient_id, instrument_a, 2.0),
                ]
            )

        r = await db_session.execute(
            text("SELECT value FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_a},
        )
        rows = r.all()
        assert len(rows) == 1
        assert float(rows[0].value) == pytest.approx(2.0)

        r = await db_session.execute(
            text(
                "SELECT value FROM results_history WHERE patient_id = :pid"
                " AND instrument_code = :icode ORDER BY result_history_id"
            ),
            {"pid": patient_id, "icode": instrument_a},
        )
        assert [float(row.value) for row in r.all()] == [pytest.approx(1.0), pytest.approx(2.0)]

    async def test_empty_batch_is_noop(self, db_session: AsyncSession, factory: Factory):
        patient_id, _, _ = await self._seed_two_instruments(db_session, factory)
        repo = CalcRepository(db_session)

        async with db_session.begin():
            await repo.upsert_results_batch([])

        r = await db_session.execute(
            text("SELECT count(*) FROM results WHERE patient_id = :pid"),
            {"pid": patient_id},
        )
        assert r.scalar_one() == 0
