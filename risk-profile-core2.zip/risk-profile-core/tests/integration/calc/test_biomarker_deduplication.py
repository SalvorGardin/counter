"""Сквозные проверки выбора одного представления биомаркера в рамках инструмента."""

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest, InstrumentsCodes
from src.calc.infra.cvd_client import CvdClient
from src.constants import ANSWER_NO, ANSWER_YES, GENDER_MALE
from tests.conftest import LogSink
from tests.factories import Factory, unique_id
from tests.integration.calc.conftest import CalcHandlerFactory

BIOMARKER_KR = "biomarker_kr"
FORM_CVD = "form_cvd"
SYSTEM_CVD = "CVD"
_EXCLUDED_NOTICE = "calc.biomarker_duplicates: excluded"


def _excluded_codes(logs: LogSink, instrument_code: str) -> list[str]:
    """Коды, вытесненные отсевом из выборки инструмента, — по notice-записи расчёта."""
    codes: list[str] = []
    for record in logs.records:
        context = getattr(record, "log_context", {})
        if record.getMessage() == _EXCLUDED_NOTICE and context.get("instrument_code") == instrument_code:
            codes.extend(context["excluded_parameter_codes"])
    return sorted(codes)


async def _result_rows(session: AsyncSession, patient_id: str, instrument_code: str) -> list[Any]:
    rows = await session.execute(
        text(
            "SELECT disease_code, value, risk_level, date_time FROM results"
            " WHERE patient_id = :patient_id AND instrument_code = :instrument_code"
            " ORDER BY disease_code NULLS FIRST"
        ),
        {"patient_id": patient_id, "instrument_code": instrument_code},
    )
    return list(rows.all())


async def _history_count(session: AsyncSession, patient_id: str, instrument_code: str) -> int:
    count = await session.scalar(
        text(
            "SELECT count(*) FROM results_history WHERE patient_id = :patient_id AND instrument_code = :instrument_code"
        ),
        {"patient_id": patient_id, "instrument_code": instrument_code},
    )
    return int(count or 0)


async def test_biomarker_clinrec_uses_only_freshest_unit(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    now = datetime.now(tz=UTC)
    await factory.answer(
        patient_id=patient_id,
        parameter_code="biomarker_96_28",
        value="60",
        date_time=now - timedelta(days=1),
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code="biomarker_96_14",
        value="100",
        date_time=now,
    )
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({BIOMARKER_KR}))])

    # 60 мг/дл сработало бы по порогу >= 50, но оно старее 100 мг/л, которое ниже порога > 500.
    assert await _result_rows(db_session, patient_id, BIOMARKER_KR) == []


async def test_value_and_flag_targets_do_not_displace_each_other(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    source_code = unique_id("biomarker_source")
    value_code = unique_id("biomarker_value")
    flag_code = unique_id("biomarker_flag")
    question_code = unique_id("question")
    option_code = unique_id("option")
    factor_code = unique_id("risk_factor")

    for parameter_code in (source_code, value_code, flag_code):
        await factory.parameter(parameter_code)
        await factory.link_parameter(
            instrument_code=FORM_CVD,
            parameter_code=parameter_code,
            is_required=False,
        )
    await factory.question(question_code)
    await factory.option(
        option_code,
        question_code=question_code,
        parameter_code=flag_code,
        value=ANSWER_YES,
    )
    await factory.biomarker(parameter_code=source_code)
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_code,
        parameter_code=value_code,
        mapping_type="value",
    )
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_code,
        parameter_code=flag_code,
        mapping_type="flag",
        operator="gte",
        value_num=Decimal("1"),
        option_code=option_code,
    )
    await factory.parameter_score(
        parameter_code=flag_code,
        system_code=SYSTEM_CVD,
        value=ANSWER_YES,
        score=Decimal("10"),
    )
    await factory.risk_factor(
        factor_code,
        system_code=SYSTEM_CVD,
        parameter_code=flag_code,
        param_value=ANSWER_YES,
    )

    now = datetime.now(tz=UTC)
    await factory.answer(patient_id=patient_id, parameter_code=value_code, value="1", date_time=now)
    await factory.answer(
        patient_id=patient_id,
        parameter_code=source_code,
        value="2",
        date_time=now - timedelta(minutes=1),
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code=flag_code,
        value=ANSWER_YES,
        date_time=now - timedelta(minutes=2),
    )
    await factory.answer_instrument_params(patient_id=patient_id, instrument_code=FORM_CVD)
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({FORM_CVD}))])

    rows = await _result_rows(db_session, patient_id, FORM_CVD)
    assert len(rows) == 1
    assert (float(rows[0].value), rows[0].risk_level) == (pytest.approx(10.0), "high")
    risk_factors = await db_session.scalar(
        text(
            "SELECT risk_factors_code FROM interpretations"
            " WHERE patient_id = :patient_id AND system_code = :system_code"
        ),
        {"patient_id": patient_id, "system_code": SYSTEM_CVD},
    )
    assert risk_factors is not None
    assert factor_code in risk_factors


async def _form_cvd_patient_with_skipped_units(
    factory: Factory, *, lipoprotein_nmol_at: datetime, skipped_at: datetime
) -> str:
    """Пациент со значением липопротеина (a) в нмоль/л и пропусками по остальным единицам."""
    patient_id = await factory.patient()
    await factory.answer(
        patient_id=patient_id, parameter_code="lipoprotein_a_nmol", value="150", date_time=lipoprotein_nmol_at
    )
    for parameter_code in ("lipoprotein_a", "lipoprotein_a_mg_l", "lipoprotein_a_gl"):
        await factory.answer(patient_id=patient_id, parameter_code=parameter_code, value="", date_time=skipped_at)
    await factory.answer_instrument_params(patient_id=patient_id, instrument_code=FORM_CVD)
    return patient_id


async def test_skipped_answer_does_not_displace_value_of_same_biomarker(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    """Пропуск вопроса в выборку не входит: более поздний пропуск не вытесняет значение другой единицы."""
    now = datetime.now(tz=UTC)
    skipped_later = await _form_cvd_patient_with_skipped_units(
        factory, lipoprotein_nmol_at=now - timedelta(days=1), skipped_at=now
    )
    skipped_earlier = await _form_cvd_patient_with_skipped_units(
        factory, lipoprotein_nmol_at=now, skipped_at=now - timedelta(days=1)
    )
    await db_session.commit()

    handler = await calc_handler()
    await handler.run(
        [
            CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({FORM_CVD}))
            for patient_id in (skipped_later, skipped_earlier)
        ]
    )

    later_rows = await _result_rows(db_session, skipped_later, FORM_CVD)
    earlier_rows = await _result_rows(db_session, skipped_earlier, FORM_CVD)
    assert len(later_rows) == len(earlier_rows) == 1
    assert later_rows[0].value == earlier_rows[0].value
    risk_factors = await db_session.scalar(
        text(
            "SELECT risk_factors_code FROM interpretations"
            " WHERE patient_id = :patient_id AND system_code = :system_code"
        ),
        {"patient_id": skipped_later, "system_code": SYSTEM_CVD},
    )
    assert risk_factors is not None
    assert "fr_lipoprotein_a" in risk_factors


async def test_interpretation_uses_instrument_scopes_and_deduplicates_factor_code(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    await factory.answer(patient_id=patient_id, parameter_code="lipoprotein_a", value="40")
    await factory.answer(patient_id=patient_id, parameter_code="biomarker_96_28", value="60")
    await factory.answer_instrument_params(patient_id=patient_id, instrument_code=FORM_CVD)
    await db_session.commit()

    handler = await calc_handler()
    await handler.run(
        [
            CalculationRequest(
                patient_id=patient_id,
                instrument_codes=frozenset({FORM_CVD, BIOMARKER_KR}),
            )
        ]
    )

    risk_factors = await db_session.scalar(
        text(
            "SELECT risk_factors_code FROM interpretations"
            " WHERE patient_id = :patient_id AND system_code = :system_code"
        ),
        {"patient_id": patient_id, "system_code": SYSTEM_CVD},
    )
    assert risk_factors is not None
    assert risk_factors.count("fr_lipoprotein_a") == 1


# Значение риска, которым отвечает подменённый cvd-сервис.
_AIRI_RISK_VALUE = 10.0
# Полный вход airi_ssz; липопротеин(а) — обязательный параметр этого калькулятора.
_AIRI_ANSWERS = {
    "age": "55",
    "atherosclerosis": ANSWER_NO,
    "bmi": "25.6",
    "diabetes": ANSWER_NO,
    "family_acute_cvd": ANSWER_NO,
    "family_hypercholesterolemia": ANSWER_NO,
    "gender": GENDER_MALE,
    "hdl": "1.53",
    "ldl": "3.4",
    "lipid_lowering_meds": ANSWER_NO,
    "lipoprotein_a": "40",
    "systolic_bp": "120",
}


async def _airi_patient(factory: Factory, *, answered_at: datetime) -> str:
    patient_id = await factory.patient()
    for parameter_code, value in _AIRI_ANSWERS.items():
        await factory.answer(
            patient_id=patient_id,
            parameter_code=parameter_code,
            value=value,
            date_time=answered_at,
        )
    return patient_id


async def _airi_lipoprotein_sent_to_cvd(calc_handler: CalcHandlerFactory, patient_id: str) -> float:
    """Считает airi_ssz подменённым cvd-клиентом и отдаёт липопротеин(а) из его единственного вызова."""
    cvd = MagicMock(spec=CvdClient)
    cvd.calculate = AsyncMock(return_value=_AIRI_RISK_VALUE)
    handler = await calc_handler(cvd_client=cvd)
    await handler.run(
        [
            CalculationRequest(
                patient_id=patient_id,
                instrument_codes=frozenset({InstrumentsCodes.AIRI_SSZ}),
            )
        ]
    )

    cvd.calculate.assert_awaited_once()
    await_args = cvd.calculate.await_args
    assert await_args is not None
    return float(await_args.args[0]["lipoproteinA"])


async def test_airi_keeps_required_lipoprotein_from_its_own_instrument(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    now = datetime.now(tz=UTC)
    patient_id = await _airi_patient(factory, answered_at=now - timedelta(minutes=1))
    # Этот более свежий параметр относится к form_cvd, но не к airi_ssz.
    await factory.answer(
        patient_id=patient_id,
        parameter_code="lipoprotein_a_mg_l",
        value="100",
        date_time=now,
    )
    await db_session.commit()

    lipoprotein_a = await _airi_lipoprotein_sent_to_cvd(calc_handler, patient_id)

    assert lipoprotein_a == pytest.approx(40.0)
    rows = await _result_rows(db_session, patient_id, InstrumentsCodes.AIRI_SSZ)
    assert len(rows) == 1
    assert float(rows[0].value) == pytest.approx(_AIRI_RISK_VALUE)


async def test_required_parameter_outlives_fresher_optional_unit_of_same_biomarker(
    db_session: AsyncSession,
    calc_handler: CalcHandlerFactory,
    factory: Factory,
    captured_app_logs: LogSink,
) -> None:
    """Обязательный параметр калькулятора не вытесняется свежим повтором того же биомаркера.

    Более свежая запись другой единицы измерения связана с тем же калькулятором как
    необязательная: из выборки уходит она, а расчёт идёт по значению обязательного параметра.
    """
    now = datetime.now(tz=UTC)
    patient_id = await _airi_patient(factory, answered_at=now - timedelta(minutes=1))
    await factory.link_parameter(
        instrument_code=InstrumentsCodes.AIRI_SSZ,
        parameter_code="lipoprotein_a_mg_l",
        is_required=False,
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code="lipoprotein_a_mg_l",
        value="100",
        date_time=now,
    )
    await db_session.commit()

    lipoprotein_a = await _airi_lipoprotein_sent_to_cvd(calc_handler, patient_id)

    assert lipoprotein_a == pytest.approx(40.0)
    assert _excluded_codes(captured_app_logs, InstrumentsCodes.AIRI_SSZ) == ["lipoprotein_a_mg_l"]
    rows = await _result_rows(db_session, patient_id, InstrumentsCodes.AIRI_SSZ)
    assert len(rows) == 1
    assert float(rows[0].value) == pytest.approx(_AIRI_RISK_VALUE)


async def test_equal_timestamps_choose_smallest_id_and_repeat_is_no_op(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    date_time = datetime.now(tz=UTC)
    # Первая вставка получает меньший patient_parameter_id и должна победить при равном времени.
    await factory.answer(
        patient_id=patient_id,
        parameter_code="biomarker_96_28",
        value="60",
        date_time=date_time,
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code="biomarker_96_14",
        value="100",
        date_time=date_time,
    )
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({BIOMARKER_KR}))])
    rows_after_first = await _result_rows(db_session, patient_id, BIOMARKER_KR)
    history_after_first = await _history_count(db_session, patient_id, BIOMARKER_KR)
    assert len(rows_after_first) == 1
    assert rows_after_first[0].disease_code == "dyslipidemia"
    assert float(rows_after_first[0].value) == pytest.approx(1.0)

    producer = MagicMock()
    producer.send_background = MagicMock()
    handler = await calc_handler(kafka_producer=producer)
    outcome = await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({BIOMARKER_KR}))])

    assert BIOMARKER_KR not in outcome.processed_codes
    assert await _result_rows(db_session, patient_id, BIOMARKER_KR) == rows_after_first
    assert await _history_count(db_session, patient_id, BIOMARKER_KR) == history_after_first
    assert producer.send_background.call_args_list == []
