"""Клинрек-расчёт собирается из мигрированной БД, а не только из синтетического каталога.

Остальные тесты `biomarker_kr` описывают свой срез справочника: один параметр, один фактор,
одна группа заболеваний. Они зелёные и при пустом сиде, потому что своё же и проверяют.
Здесь проверяется противоположное — что справочник, залитый миграциями, доходит до расчёта
целиком: инструмент маршрутизируется по типу, параметры-биомаркеры связаны с ним, а у каждого
фактора с биомаркерным условием есть группа заболеваний с баллом 3 (и наоборот). Разорвись
любая из этих связей в следующей перезаливке справочника — расчёт молча перестал бы находить
факторы, ни одна строка результата не появилась бы, и ошибки в логе тоже.
"""

from sqlalchemy.ext.asyncio import AsyncSession

from src.constants import BIOMARKER_CLINREC_INSTRUMENT_CODE, BIOMARKER_PARAMETER_PREFIX
from src.infra.catalog.calc import CalcCatalog
from tests.conftest import make_calc_catalog


async def _catalog(db_session: AsyncSession) -> CalcCatalog:
    return await make_calc_catalog(db_session)


async def test_seeded_instrument_is_routed_to_the_clinrec_branch(db_session: AsyncSession) -> None:
    catalog = await _catalog(db_session)

    assert list(catalog.biomarker_clinrec_configs) == [BIOMARKER_CLINREC_INSTRUMENT_CODE]
    # Тип `biomarker_kr` не должен попадать ни в формульную ветку, ни в список «нечем считать».
    assert BIOMARKER_CLINREC_INSTRUMENT_CODE not in catalog.formula_configs
    assert BIOMARKER_CLINREC_INSTRUMENT_CODE not in catalog.unsupported_calc_codes


async def test_seeded_biomarker_parameters_reach_the_instrument(db_session: AsyncSession) -> None:
    catalog = await _catalog(db_session)

    assert catalog.biomarker_parameter_codes, "сид не связал ни одного параметра-биомаркера с инструментом"
    assert all(code.startswith(BIOMARKER_PARAMETER_PREFIX) for code in catalog.biomarker_parameter_codes)


async def test_seeded_factors_have_both_condition_and_disease(db_session: AsyncSession) -> None:
    """Фактор считается только при обеих связях: биомаркерное условие и балл 3 по группе.

    Односторонняя связь — тихая дыра: условие без балла не даёт группе ничего, балл без условия
    не срабатывает никогда.
    """
    catalog = await _catalog(db_session)

    with_conditions = set(catalog.biomarker_triggers_by_factor)
    with_diseases = set(catalog.clinrec_diseases_by_factor)

    assert with_conditions, "сид не дал ни одного фактора с условием по биомаркеру"
    assert with_conditions - with_diseases == set()
    assert with_diseases - with_conditions == set()


async def test_seeded_diseases_of_clinrec_factors_have_a_system(db_session: AsyncSession) -> None:
    """`diseases.system_code` — единственная связь строки результата с системой организма."""
    catalog = await _catalog(db_session)

    scored = {code for codes in catalog.clinrec_diseases_by_factor.values() for code in codes}
    assert scored
    assert all(catalog.system_code_by_disease.get(code) for code in scored)
