"""Сквозной расчёт `biomarker_kr`: параметры → результат и история → интерпретация → `done`.

Полный путь, а не только домен: инструмент маршрутизируется по типу, строка пишется в разрезе
группы заболеваний, событие расчёта несёт все системы инструмента, а интерпретация запускается
только по системе изменившейся группы.
"""

from typing import Any
from unittest.mock import MagicMock

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest
from src.config import settings
from tests.consts import BIOMARKER_CLINREC_INSTRUMENT_CODE
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory

BIOMARKER_KR = BIOMARKER_CLINREC_INSTRUMENT_CODE
LDL = "biomarker_ldl"
FACTOR = "rf_ldl_e2e"


@pytest.fixture
async def clinrec_setup(db_session: AsyncSession, factory: Factory) -> dict[str, str]:
    """Пациент, инструмент двух систем, группа заболеваний первой системы и её клинрек-фактор."""
    patient_id = await factory.patient()
    own_system = await factory.system()
    other_system = await factory.system()
    await factory.biomarker_clinrec_instrument()
    await factory.link_system_instrument(system_code=own_system, instrument_code=BIOMARKER_KR)
    await factory.link_system_instrument(system_code=other_system, instrument_code=BIOMARKER_KR)
    disease_code = await factory.disease(system_code=own_system, description="Инфаркт")
    await factory.parameter(LDL)
    await factory.link_parameter(instrument_code=BIOMARKER_KR, parameter_code=LDL, is_required=False)
    await factory.risk_factor(
        FACTOR,
        system_code=own_system,
        parameter_code=LDL,
        description="ЛПНП повышен",
        param_value="Повышен",
    )
    await factory.risk_factor_score(risk_factor_code=FACTOR, disease_code=disease_code)
    await db_session.commit()
    return {
        "patient_id": patient_id,
        "own_system": own_system,
        "other_system": other_system,
        "disease_code": disease_code,
    }


async def _results(session: AsyncSession, patient_id: str) -> list[Any]:
    rows = await session.execute(
        text(
            "SELECT disease_code, indicator, value, unit, risk_level, applicability, interpretation_status"
            " FROM results WHERE patient_id = :pid AND instrument_code = :i ORDER BY disease_code"
        ),
        {"pid": patient_id, "i": BIOMARKER_KR},
    )
    return list(rows.all())


async def _history_count(session: AsyncSession, patient_id: str) -> int:
    rows = await session.execute(
        text("SELECT count(*) FROM results_history WHERE patient_id = :pid AND instrument_code = :i"),
        {"pid": patient_id, "i": BIOMARKER_KR},
    )
    return int(rows.scalar_one())


async def _interpretation(session: AsyncSession, patient_id: str, system_code: str) -> Any:
    rows = await session.execute(
        text(
            "SELECT risk_level, diseases, risk_factors_code FROM interpretations"
            " WHERE patient_id = :pid AND system_code = :s"
        ),
        {"pid": patient_id, "s": system_code},
    )
    return rows.one_or_none()


def _calculation_events(producer: MagicMock) -> list[dict[str, Any]]:
    return [
        call.kwargs["value"]
        for call in producer.send_background.call_args_list
        if call.kwargs["value"]["messageType"] == "calculation"
    ]


def _interpretation_events(producer: MagicMock) -> list[dict[str, Any]]:
    return [
        call.kwargs["value"]
        for call in producer.send_background.call_args_list
        if call.kwargs["value"]["messageType"] == "interpretation"
    ]


async def test_full_path_from_parameter_to_done(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()

    producer = MagicMock()
    producer.send_background = MagicMock()
    handler = await calc_handler(kafka_producer=producer)
    outcome = await handler.run([CalculationRequest(patient_id=patient_id)])

    assert BIOMARKER_KR in outcome.processed_codes
    rows = await _results(db_session, patient_id)
    assert len(rows) == 1
    assert rows[0].disease_code == clinrec_setup["disease_code"]
    assert rows[0].indicator == "Количество сработавших факторов риска на 3 балла"
    assert rows[0].unit == "фактор риска"
    assert (float(rows[0].value), rows[0].risk_level, rows[0].applicability) == (pytest.approx(1.0), "high", True)
    assert await _history_count(db_session, patient_id) == 1

    # Событие расчёта несёт ВСЕ системы инструмента, а интерпретация — только систему группы.
    events = _calculation_events(producer)
    assert len(events) == 1
    assert sorted(events[0]["systemCodes"]) == sorted([clinrec_setup["own_system"], clinrec_setup["other_system"]])
    assert _interpretation_events(producer)[0]["systemCodes"] == [clinrec_setup["own_system"]]

    interpretation = await _interpretation(db_session, patient_id, clinrec_setup["own_system"])
    assert interpretation is not None
    assert interpretation.risk_level == "high"
    # Клинрек-источник кладёт в interpretations.diseases код группы, а не её описание.
    assert interpretation.diseases == [clinrec_setup["disease_code"]]
    assert interpretation.risk_factors_code == [FACTOR]
    # Интерпретация системы записана — строка результата закрыта.
    assert (await _results(db_session, patient_id))[0].interpretation_status == "done"
    # Система, к которой группа не относится, не интерпретировалась.
    assert await _interpretation(db_session, patient_id, clinrec_setup["other_system"]) is None


async def test_unchanged_repeat_is_a_full_no_op(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id)])
    history_after_first = await _history_count(db_session, patient_id)

    producer = MagicMock()
    producer.send_background = MagicMock()
    handler = await calc_handler(kafka_producer=producer)
    outcome = await handler.run([CalculationRequest(patient_id=patient_id)])

    assert BIOMARKER_KR not in outcome.processed_codes
    assert await _history_count(db_session, patient_id) == history_after_first
    assert producer.send_background.call_args_list == []
    # Строка осталась прежней, включая уже проставленный статус интерпретации.
    assert (await _results(db_session, patient_id))[0].interpretation_status == "done"


async def test_disappeared_risk_clears_the_row_and_the_interpretation(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()
    await (await calc_handler()).run([CalculationRequest(patient_id=patient_id)])

    # Ответ пациента перезаписывается, а не добавляется второй строкой: у пары
    # «пациент × параметр» она одна.
    await db_session.execute(
        text("UPDATE patients_parameters SET value = 'Норма' WHERE patient_id = :pid AND parameter_code = :p"),
        {"pid": patient_id, "p": LDL},
    )
    await db_session.commit()
    outcome = await (await calc_handler()).run([CalculationRequest(patient_id=patient_id)])

    assert BIOMARKER_KR in outcome.processed_codes
    rows = await _results(db_session, patient_id)
    assert (rows[0].value, rows[0].unit, rows[0].risk_level, rows[0].applicability) == (None, None, None, False)
    assert rows[0].interpretation_status == "not_required"
    interpretation = await _interpretation(db_session, patient_id, clinrec_setup["own_system"])
    assert interpretation.risk_level is None
    assert interpretation.diseases is None
    assert interpretation.risk_factors_code is None


async def test_pregnancy_clears_existing_rows_only(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()
    await (await calc_handler()).run([CalculationRequest(patient_id=patient_id)])

    await db_session.execute(
        text("UPDATE patients SET is_pregnant = true WHERE patient_id = :pid"), {"pid": patient_id}
    )
    await db_session.commit()
    await (await calc_handler()).run([CalculationRequest(patient_id=patient_id)])

    rows = await _results(db_session, patient_id)
    assert (rows[0].value, rows[0].applicability, rows[0].risk_level, rows[0].interpretation_status) == (
        None,
        False,
        None,
        "not_required",
    )

    # У беременной без единой существующей строки новых групп не появляется.
    other_patient = await factory.patient(is_pregnant=True)
    await factory.answer(patient_id=other_patient, parameter_code=LDL, value="Повышен")
    await db_session.commit()
    await (await calc_handler()).run([CalculationRequest(patient_id=other_patient)])
    assert await _results(db_session, other_patient) == []


async def test_partial_recalculation_scoped_to_the_instrument(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({BIOMARKER_KR}))])
    assert len(await _results(db_session, patient_id)) == 1

    # Запрос по чужому инструменту клинрек-строк не трогает.
    handler = await calc_handler()
    outcome = await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({"score_2"}))])
    assert BIOMARKER_KR not in outcome.processed_codes
    assert await _history_count(db_session, patient_id) == 1


async def test_two_patients_are_independent(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    first = clinrec_setup["patient_id"]
    second = await factory.patient()
    await factory.answer(patient_id=first, parameter_code=LDL, value="Повышен")
    await factory.answer(patient_id=second, parameter_code=LDL, value="Норма")
    await db_session.commit()

    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=first), CalculationRequest(patient_id=second)])

    assert len(await _results(db_session, first)) == 1
    assert await _results(db_session, second) == []


async def test_topic_of_published_events(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, clinrec_setup: dict[str, str]
) -> None:
    patient_id = clinrec_setup["patient_id"]
    await factory.answer(patient_id=patient_id, parameter_code=LDL, value="Повышен")
    await db_session.commit()

    producer = MagicMock()
    producer.send_background = MagicMock()
    handler = await calc_handler(kafka_producer=producer)
    await handler.run([CalculationRequest(patient_id=patient_id)])

    for call in producer.send_background.call_args_list:
        assert call.kwargs["topic"] == settings.kafka.topics.risk_calculation
        assert call.kwargs["key"] == patient_id
