"""End-to-end tests for the BCRAT (Gail model) formula.

The instrument and its parameters are seeded by migration 0045; no manual
instrument setup is needed here.  Tests cover: low-risk profile, high-risk
profile, and inapplicability conditions (breast_cancer / hodgkins_lymphoma /
brca_mutation).
"""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import (
    CalculationRequest,
    InstrumentsCodes,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory


def _pcr(patient_id: str) -> CalculationRequest:
    return CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({InstrumentsCodes.BCRAT}))


async def _insert_bcrat_params(factory: Factory, patient_id: str, values: dict[str, str]) -> None:
    for code, value in values.items():
        await factory.answer(patient_id=patient_id, parameter_code=code, value=value)


async def _get_bcrat_row(session: AsyncSession, patient_id: str):
    r = await session.execute(
        text(
            "SELECT value, unit, risk_level, applicability, indicator, interpretation_status"
            " FROM results WHERE patient_id = :pid AND instrument_code = :icode"
        ),
        {"pid": patient_id, "icode": InstrumentsCodes.BCRAT.value},
    )
    return r.one()


_LOW_RISK = {
    PARAMETER_CODE_GENDER: GENDER_FEMALE,
    PARAMETER_CODE_AGE: "45",
    "breast_cancer": "Нет",
    "hodgkins_lymphoma": "Нет",
    "brca_mutation": "Нет",
    "age_menarche": "12-13 лет",
    "breast_biopsies_count": "Нет",
    "breast_atypical_hyperplasia": "Нет / Не знаю",
    "age_first_birth": "20-24 года",
    "family_breast_cancer": "Таких нет",
}

_HIGH_RISK = {
    PARAMETER_CODE_GENDER: GENDER_FEMALE,
    PARAMETER_CODE_AGE: "60",
    "breast_cancer": "Нет",
    "hodgkins_lymphoma": "Нет",
    "brca_mutation": "Нет",
    "age_menarche": "<12 лет",
    "breast_biopsies_count": "Более двух раз",
    "breast_atypical_hyperplasia": "Да",
    "age_first_birth": "Родов не было",
    "family_breast_cancer": "Две и более",
}


class TestBcratEndToEnd:
    async def test_low_risk_profile_writes_expected_result(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
    ) -> None:
        patient_id = await factory.patient()
        await _insert_bcrat_params(factory, patient_id, _LOW_RISK)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        row = await _get_bcrat_row(db_session, patient_id)
        # age=45 → baseline=0.584; age_menarche=12-13 → 1.1; biopsies=Нет (age<50) → 1.0, atyp_hyper ignored → 1.0
        # age_first_birth/family: "20-24"/"0 rels" → 1.24
        expected_value = 1.1 * 1.0 * 1.24 * 1.0 * 0.584
        assert float(row.value) == pytest.approx(expected_value, rel=1e-3)
        assert row.unit == InstrumentsUnits.BCRAT.value
        assert row.risk_level == InstrumentsRiskLevel.LOW.value
        assert row.applicability is True
        assert row.indicator == InstrumentsIndicators.BCRAT.value
        assert row.interpretation_status == "done"

    async def test_high_risk_profile_writes_high_risk_level(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
    ) -> None:
        patient_id = await factory.patient()
        await _insert_bcrat_params(factory, patient_id, _HIGH_RISK)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        row = await _get_bcrat_row(db_session, patient_id)
        # age=60 → baseline=1.018; age_menarche=<12 → 1.21; biopsies=2+ (age≥50) → 1.62
        # atyp_hyper=Да → 1.82; age_first_birth/family: "Родов не было"/"2+ rels" → 4.91
        expected_value = 1.21 * 1.62 * 4.91 * 1.82 * 1.018
        assert float(row.value) == pytest.approx(expected_value, rel=1e-3)
        assert row.risk_level == InstrumentsRiskLevel.HIGH.value
        assert row.applicability is True

    @pytest.mark.parametrize("exclusion_code", ["breast_cancer", "hodgkins_lymphoma", "brca_mutation"])
    async def test_exclusion_yes_marks_result_not_required(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        factory: Factory,
        exclusion_code: str,
    ) -> None:
        patient_id = await factory.patient()
        await _insert_bcrat_params(factory, patient_id, {**_LOW_RISK, exclusion_code: "Да"})
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        row = await _get_bcrat_row(db_session, patient_id)
        assert row.value is None
        assert row.applicability is False
        assert row.interpretation_status == "not_required"
