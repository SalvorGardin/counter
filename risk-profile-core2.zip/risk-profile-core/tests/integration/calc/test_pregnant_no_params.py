"""Failing test: pregnant patient with zero patient_parameters must still receive inapplicable results.

Root cause: grouped is built only from patient_parameters rows. A patient with no rows
is never inserted into grouped, so the outer `for patient_id, patient_values in grouped.items()`
loop never processes them. Bug 2's fix (skeleton InstrumentInput for pregnant patients with
missing required params) therefore never fires — the patient is invisible to the handler.

Fix needed in handler: iterate over all patient_ids from the input, not only those present
in grouped.
"""

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest, InstrumentsCodes
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory


async def _get_result_rows(session: AsyncSession, patient_id: str, instrument_code: str):
    r = await session.execute(
        text(
            "SELECT applicability, interpretation_status"
            " FROM results WHERE patient_id = :pid AND instrument_code = :icode"
        ),
        {"pid": patient_id, "icode": instrument_code},
    )
    return r.all()


class TestPregnantPatientNoParams:
    async def test_stai_produces_inapplicable_results_for_pregnant_patient_with_no_params(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory
    ) -> None:
        """Pregnant patient with zero patient_parameters rows must get inapplicable STAI results.

        STAI returns 2 results (situational + personal anxiety). Both must appear with
        applicability=False and interpretation_status='not_required'.
        """
        patient_id = await factory.patient(is_pregnant=True)
        # No patient_parameters rows at all
        await db_session.commit()

        handler = await calc_handler()
        await handler.run(
            [
                CalculationRequest(
                    patient_id=patient_id,
                    instrument_codes=frozenset({InstrumentsCodes.SPILLBERGER_HANIN}),
                )
            ]
        )

        rows = await _get_result_rows(db_session, patient_id, InstrumentsCodes.SPILLBERGER_HANIN)
        assert len(rows) == 2, f"Expected 2 inapplicable results, got {len(rows)}"
        for applicability, status in rows:
            assert applicability is False
            assert status == "not_required"
