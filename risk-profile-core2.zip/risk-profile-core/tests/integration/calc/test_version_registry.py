"""Реестр версий расчёта: штамп, когорта и бутстрап уже посчитанных пациентов.

Предмет проверки — свойства, на которых держится массовый пересчёт: строка на пациента одна,
когорта определяется несовпадением версии, а отсутствие строки выводит пациента из когорты.
"""

import importlib.util
from datetime import datetime
from pathlib import Path
from types import ModuleType

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.infra.version_registry import VersionRegistry
from tests.factories import Factory, unique_id

_MIGRATION_PATH = (
    Path(__file__).resolve().parents[3]
    / "migrations"
    / "versions"
    / "0147_create_patient_calculation_versions_3b1f7c9d4e2a.py"
)


def _load_migration() -> ModuleType:
    spec = importlib.util.spec_from_file_location("migration_0147", _MIGRATION_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


migration = _load_migration()


async def _rows_of(session: AsyncSession, patient_id: str) -> list[tuple[str, datetime]]:
    result = await session.execute(
        sa.text("SELECT calculation_version, calculated_at FROM patient_calculation_versions WHERE patient_id = :pid"),
        {"pid": patient_id},
    )
    return [(row[0], row[1]) for row in result]


class TestStamp:
    async def test_stamp_creates_the_patient_row(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = await factory.patient(patient_id=unique_id("vr"))
        await db_session.commit()

        async with db_session.begin():
            await VersionRegistry(db_session).stamp(patient_id, "7")

        assert [version for version, _ in await _rows_of(db_session, patient_id)] == ["7"]

    async def test_repeated_stamp_updates_the_row_instead_of_adding_a_second(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        """Строка на пациента одна: вторая строка сломала бы и когорту, и её размер."""
        patient_id = await factory.patient(patient_id=unique_id("vr"))
        await db_session.commit()
        registry = VersionRegistry(db_session)

        async with db_session.begin():
            await registry.stamp(patient_id, "7")
        async with db_session.begin():
            await registry.stamp(patient_id, "8")

        assert [version for version, _ in await _rows_of(db_session, patient_id)] == ["8"]

    async def test_stamp_moves_the_calculation_time(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = await factory.patient(patient_id=unique_id("vr"))
        await db_session.commit()
        registry = VersionRegistry(db_session)

        async with db_session.begin():
            await registry.stamp(patient_id, "7")
        first = (await _rows_of(db_session, patient_id))[0][1]
        await db_session.rollback()  # чтение открыло транзакцию, следующий begin её не потерпит
        async with db_session.begin():
            await registry.stamp(patient_id, "8")
        second = (await _rows_of(db_session, patient_id))[0][1]

        assert second > first


class TestCohort:
    async def test_cohort_holds_only_patients_of_another_version(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        stale = await factory.patient(patient_id=unique_id("vr-stale"))
        current = await factory.patient(patient_id=unique_id("vr-current"))
        await db_session.commit()
        registry = VersionRegistry(db_session)
        async with db_session.begin():
            await registry.stamp(stale, "6")
            await registry.stamp(current, "7")

        page = await registry.cohort_page("7", after=None, limit=100)

        assert stale in page
        assert current not in page

    async def test_patient_without_a_row_stays_out_of_the_cohort(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        """Отсутствие строки означает «не считался никогда»: массовый пересчёт обновляет уже
        посчитанные профили и первичный расчёт не порождает."""
        never_calculated = await factory.patient(patient_id=unique_id("vr-never"))
        await db_session.commit()

        page = await VersionRegistry(db_session).cohort_page("7", after=None, limit=1000)

        assert never_calculated not in page

    async def test_keyset_pagination_walks_the_cohort_without_repeats(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        prefix = unique_id("vr-page")
        expected = sorted([await factory.patient(patient_id=f"{prefix}-{i}") for i in range(3)])
        await db_session.commit()
        registry = VersionRegistry(db_session)
        async with db_session.begin():
            for patient_id in expected:
                await registry.stamp(patient_id, "6")

        walked: list[str] = []
        cursor: str | None = None
        while True:
            page = await registry.cohort_page("7", after=cursor, limit=2)
            if not page:
                break
            walked.extend(patient_id for patient_id in page if patient_id.startswith(prefix))
            cursor = page[-1]

        assert walked == expected

    async def test_cohort_size_counts_the_stale_rows(self, db_session: AsyncSession, factory: Factory) -> None:
        version = unique_id("ver")
        before = await VersionRegistry(db_session).cohort_size(version)
        patient_id = await factory.patient(patient_id=unique_id("vr-size"))
        await db_session.commit()
        async with db_session.begin():
            await VersionRegistry(db_session).stamp(patient_id, "6")

        assert await VersionRegistry(db_session).cohort_size(version) == before + 1

    async def test_cohort_sample_is_drawn_at_random_from_the_cohort(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        """Первая страница в установившемся режиме — ровно устойчиво сбойные пациенты, и проверочный
        батч из неё не получил бы ни одного штампа. Выборка обязана ходить по всей когорте."""
        version = unique_id("current")
        prefix = unique_id("vr-sample")
        patients = [await factory.patient(patient_id=f"{prefix}-{index:02d}") for index in range(20)]
        await db_session.commit()
        registry = VersionRegistry(db_session)
        async with db_session.begin():
            for patient_id in patients:
                await registry.stamp(patient_id, "6")
        cohort = set(await registry.cohort_page(version, after=None, limit=100_000))

        draws = [await registry.cohort_sample(version, limit=1) for _ in range(30)]

        assert all(len(draw) == 1 and draw[0] in cohort for draw in draws)
        assert len({draw[0] for draw in draws}) > 1

    async def test_stamps_of_reports_version_and_time_of_stamped_patients_only(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        stamped = await factory.patient(patient_id=unique_id("vr-stamps"))
        bare = await factory.patient(patient_id=unique_id("vr-bare"))
        await db_session.commit()
        registry = VersionRegistry(db_session)
        async with db_session.begin():
            await registry.stamp(stamped, "7")

        stamps = await registry.stamps_of([stamped, bare])

        assert set(stamps) == {stamped}
        assert stamps[stamped].version == "7"
        assert stamps[stamped].calculated_at == (await _rows_of(db_session, stamped))[0][1]


class TestBootstrap:
    async def test_bootstrap_fills_a_row_per_calculated_patient(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        """Реестр создаётся пустым, а пустая строка выводит пациента из когорты — без бутстрапа
        ни один уже посчитанный пациент в прогон не попал бы вовсе."""
        instrument_code = unique_id("VR_I")[:30]
        await factory.instrument(instrument_code)
        patients = [await factory.patient(patient_id=unique_id("vr-boot")) for _ in range(2)]
        for patient_id in patients:
            await factory.result(patient_id=patient_id, instrument_code=instrument_code)
        # Строки, которые поставил бы расчёт, убираем: бутстрап проверяется на чистом реестре.
        await db_session.execute(
            sa.text("DELETE FROM risk_calculation.patient_calculation_versions WHERE patient_id = ANY(:ids)"),
            {"ids": patients},
        )
        await db_session.commit()

        async with db_session.begin():
            await db_session.execute(sa.text(migration.BOOTSTRAP_SQL))

        for patient_id in patients:
            assert [version for version, _ in await _rows_of(db_session, patient_id)] == [migration.BOOTSTRAP_VERSION]

    async def test_bootstrap_is_idempotent(self, db_session: AsyncSession, factory: Factory) -> None:
        """upgrade → downgrade → upgrade не должен задваивать строки: ключ пациента их и не
        задвоит, но повторный прогон обязан пройти без ошибки."""
        instrument_code = unique_id("VR_I")[:30]
        await factory.instrument(instrument_code)
        patient_id = await factory.patient(patient_id=unique_id("vr-boot"))
        await factory.result(patient_id=patient_id, instrument_code=instrument_code)
        await db_session.commit()

        async with db_session.begin():
            await db_session.execute(sa.text(migration.BOOTSTRAP_SQL))
            await db_session.execute(sa.text(migration.BOOTSTRAP_SQL))

        assert len(await _rows_of(db_session, patient_id)) == 1

    async def test_bootstrap_leaves_an_already_stamped_patient_alone(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        """Пациент, которого уже успел проштамповать расчёт, заглушкой не перекрывается:
        иначе бутстрап вернул бы в когорту свежепосчитанный профиль."""
        instrument_code = unique_id("VR_I")[:30]
        await factory.instrument(instrument_code)
        patient_id = await factory.patient(patient_id=unique_id("vr-boot"))
        await factory.result(patient_id=patient_id, instrument_code=instrument_code)
        await db_session.commit()
        async with db_session.begin():
            await VersionRegistry(db_session).stamp(patient_id, "7")

        async with db_session.begin():
            await db_session.execute(sa.text(migration.BOOTSTRAP_SQL))

        assert [version for version, _ in await _rows_of(db_session, patient_id)] == ["7"]
