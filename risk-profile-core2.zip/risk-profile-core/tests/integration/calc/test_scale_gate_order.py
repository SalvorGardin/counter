"""Порядок гейтов у шкал bdi/stai: возраст проверяется раньше полноты ответов (issue #172).

* `age < 18` → «не применимо»: заглушка с applicability=false / not_required, независимо от того,
  отвечал ли пациент на вопросы шкалы (у общего порядка проверок нехватка обязательных параметров
  отсекала бы раньше, и записи бы не было вовсе).
* `age >= 18` и нет хотя бы одного ответа шкалы → калькулятор пропускается целиком: записей в
  results нет, публиковать в risk-calculation нечего.

Соседние инварианты (нет ответа / нет возраста → 0 записей) пиновались раньше в
test_bdi_missing_required_param.py и test_stai_missing_age.py — здесь они не дублируются.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest, InstrumentsCodes
from tests.consts import PARAMETER_CODE_AGE
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory

_STAI_ANSWER = "Нет, это не так"  # балл 1 по любому пункту

# instrument_code → сколько строк results даёт шкала (у stai два показателя)
_SCALE_ROW_COUNT: dict[str, int] = {
    InstrumentsCodes.BECK_DEPRESSION: 1,
    InstrumentsCodes.SPILLBERGER_HANIN: 2,
}


async def _scale_answers(session: AsyncSession, instrument_code: str) -> dict[str, str]:
    """Валидный полный набор ответов шкалы: parameter_code → значение из справочника."""
    if instrument_code == InstrumentsCodes.SPILLBERGER_HANIN:
        return {f"stai{i}": _STAI_ANSWER for i in range(1, 41)}
    # BDI считает балл по тексту ответа из options (суффикс кода _01 → балл 0).
    rows = await session.execute(
        text(
            "SELECT o.parameter_code, o.value FROM options o"
            " JOIN questions q ON q.code = o.question_code"
            " WHERE q.code LIKE 'BDI%' AND o.code LIKE '%_01'"
        )
    )
    answers = {parameter_code: value for parameter_code, value in rows.all()}
    assert len(answers) == 21, answers
    return answers


async def _insert_patient(factory: Factory, age: str) -> str:
    patient_id = await factory.patient()
    await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_AGE, value=age)
    return patient_id


async def _results(session: AsyncSession, patient_id: str, instrument_code: str) -> list[tuple[bool, str]]:
    rows = await session.execute(
        text(
            "SELECT applicability, interpretation_status FROM results"
            " WHERE patient_id = :pid AND instrument_code = :icode"
        ),
        {"pid": patient_id, "icode": instrument_code},
    )
    return [(applicability, status) for applicability, status in rows.all()]


async def _run(calc_handler: CalcHandlerFactory, patient_id: str, instrument_code: str) -> None:
    handler = await calc_handler()
    await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({instrument_code}))])


@pytest.mark.parametrize("instrument_code", list(_SCALE_ROW_COUNT))
class TestScaleGateOrder:
    async def test_underage_without_answers_yields_inapplicable_stub(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="17")
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        results = await _results(db_session, patient_id, instrument_code)
        assert len(results) == _SCALE_ROW_COUNT[instrument_code]
        assert all(row == (False, "not_required") for row in results)

    async def test_underage_with_full_answers_yields_inapplicable_stub(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="17")
        for code, answer in (await _scale_answers(db_session, instrument_code)).items():
            await factory.answer(patient_id=patient_id, parameter_code=code, value=answer)
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        results = await _results(db_session, patient_id, instrument_code)
        assert len(results) == _SCALE_ROW_COUNT[instrument_code]
        assert all(row == (False, "not_required") for row in results)

    async def test_adult_boundary_18_without_answers_creates_no_row(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="18")
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        assert await _results(db_session, patient_id, instrument_code) == []

    async def test_adult_boundary_18_with_full_answers_is_calculated(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="18")
        for code, answer in (await _scale_answers(db_session, instrument_code)).items():
            await factory.answer(patient_id=patient_id, parameter_code=code, value=answer)
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        results = await _results(db_session, patient_id, instrument_code)
        assert len(results) == _SCALE_ROW_COUNT[instrument_code]
        assert all(row == (True, "done") for row in results)

    async def test_adult_missing_one_answer_creates_no_row(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="40")
        answers = await _scale_answers(db_session, instrument_code)
        del answers[next(iter(answers))]
        for code, answer in answers.items():
            await factory.answer(patient_id=patient_id, parameter_code=code, value=answer)
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        assert await _results(db_session, patient_id, instrument_code) == []

    async def test_adult_with_full_answers_is_calculated(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, instrument_code: str
    ) -> None:
        patient_id = await _insert_patient(factory, age="40")
        for code, answer in (await _scale_answers(db_session, instrument_code)).items():
            await factory.answer(patient_id=patient_id, parameter_code=code, value=answer)
        await db_session.commit()

        await _run(calc_handler, patient_id, instrument_code)

        results = await _results(db_session, patient_id, instrument_code)
        assert len(results) == _SCALE_ROW_COUNT[instrument_code]
        # «ready» после расчёта, «done» — после интерпретации, которую CalcHandler дёргает следом.
        assert all(row == (True, "done") for row in results)
