from collections.abc import Sequence
from datetime import UTC, date, datetime, timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import (
    InstrumentDefinition,
    PatientParameterRow,
    QuestionnaireEligibility,
    QuestionnaireScoreRow,
)
from src.calc.domain.questionnaire_registry import GATED_QUESTIONNAIRE_CODES
from src.calc.infra.reader import CalcReader
from src.models.instrument import Instrument
from tests.conftest import make_calc_catalog
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_AGE, PARAMETER_CODE_BIRTHDATE, PARAMETER_CODE_GENDER
from tests.factories import Factory


def _birthdate_for_age(age: int) -> str:
    """ISO-дата рождения, дающая ровно `age` лет на сегодня (возрастные conditions считают от неё).

    1 января: день рождения к любой дате прогона уже прошёл, поэтому возраст равен разнице лет
    — без завязки на текущий месяц и без високосных краёв.
    """
    return date(datetime.now(tz=UTC).year - age, 1, 1).isoformat()


async def _seed(factory: Factory, param_code: str, instrument_code: str) -> tuple[str, str, str]:
    patient_id = await factory.patient()
    await factory.parameter(param_code)
    await factory.instrument(instrument_code)
    await factory.answer(patient_id=patient_id, parameter_code=param_code, value="yes")
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code, is_required=True)
    return patient_id, param_code, instrument_code


class TestLoadPatientSnapshot:
    async def test_returns_matching_row(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        param_code = "LP_P1"
        date_time = datetime(2026, 1, 2, 3, 4, tzinfo=UTC)
        await factory.parameter(param_code)
        await factory.instrument("LP_I1")
        await factory.answer(patient_id=patient_id, parameter_code=param_code, value="yes", date_time=date_time)
        await factory.link_parameter(instrument_code="LP_I1", parameter_code=param_code, is_required=True)
        await db_session.commit()

        snapshot = await CalcReader(db_session, await make_calc_catalog(db_session)).load_patient_snapshot([patient_id])
        rows = snapshot.rows

        assert len(rows) == 1
        row = rows[0]
        assert isinstance(row, PatientParameterRow)
        assert row.patient_id == patient_id
        assert row.parameter_code == param_code
        assert row.value == "yes"
        assert row.date_time == date_time
        assert row.patient_parameter_id > 0
        assert snapshot.patient_data == {patient_id: False}

    async def test_keeps_null_is_pregnant_as_none(self, db_session: AsyncSession, factory: Factory):
        """NULL не схлопывается в False: eligibility считает cq_030 отвеченным по IS NOT NULL."""
        patient_id = await factory.patient(is_pregnant=None)
        await db_session.commit()

        snapshot = await CalcReader(db_session, await make_calc_catalog(db_session)).load_patient_snapshot([patient_id])

        assert snapshot.rows == []
        assert snapshot.patient_data == {patient_id: None}

    async def test_reads_several_patients_in_one_call(self, db_session: AsyncSession, factory: Factory):
        """Один запрос на всю пачку: и строки, и беременность каждого пациента."""
        with_params, param_code, _ = await _seed(factory, "LP_P2", "LP_I2")
        without_params = await factory.patient(is_pregnant=True)
        await db_session.commit()

        reader = CalcReader(db_session, await make_calc_catalog(db_session))
        snapshot = await reader.load_patient_snapshot([with_params, without_params])

        assert [(r.patient_id, r.parameter_code) for r in snapshot.rows] == [(with_params, param_code)]
        assert snapshot.patient_data == {with_params: False, without_params: True}

    async def test_excludes_expired_rows(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        await factory.parameter("LP_EXP")
        past = datetime.now(tz=UTC) - timedelta(days=1)
        await factory.answer(patient_id=patient_id, parameter_code="LP_EXP", value="val", expiration_date=past)
        await db_session.commit()

        snapshot = await CalcReader(db_session, await make_calc_catalog(db_session)).load_patient_snapshot([patient_id])

        assert snapshot.rows == []
        # Фильтр параметров живёт в условии LEFT JOIN, а не в WHERE: пациент, у которого все
        # параметры отсеялись, обязан остаться в patient_data — его беременность нужна eligibility.
        assert snapshot.patient_data == {patient_id: False}

    async def test_excludes_null_value_rows(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        await factory.parameter("LP_NULL")
        await factory.answer(patient_id=patient_id, parameter_code="LP_NULL", value=None)
        await db_session.commit()

        snapshot = await CalcReader(db_session, await make_calc_catalog(db_session)).load_patient_snapshot([patient_id])

        assert snapshot.rows == []
        assert snapshot.patient_data == {patient_id: False}

    async def test_returns_empty_for_unknown_patient(self, db_session: AsyncSession):
        snapshot = await CalcReader(db_session, await make_calc_catalog(db_session)).load_patient_snapshot(["999999"])
        assert snapshot.rows == []
        assert snapshot.patient_data == {}


class TestInstrumentConfigs:
    async def test_returns_instrument_to_params_mapping(self, db_session: AsyncSession, factory: Factory):
        _, param_code, instrument_code = await _seed(factory, "LI_P1", "LI_I1")
        await db_session.commit()

        configs = (await make_calc_catalog(db_session)).instrument_configs

        assert instrument_code in configs
        assert isinstance(configs[instrument_code], InstrumentDefinition)
        assert param_code in configs[instrument_code].required_parameter_codes

    async def test_excludes_inactive_instruments(self, db_session: AsyncSession, factory: Factory):
        await factory.parameter("LI_P2")
        await factory.instrument("LI_INACTIVE", status="inactive")
        await factory.link_parameter(instrument_code="LI_INACTIVE", parameter_code="LI_P2", is_required=True)
        await db_session.commit()

        configs = (await make_calc_catalog(db_session)).instrument_configs

        assert "LI_INACTIVE" not in configs


class TestInstrumentCodesForParameters:
    async def test_returns_mapped_instruments(self, db_session: AsyncSession, factory: Factory):
        _, param_code, instrument_code = await _seed(factory, "LIP_P1", "LIP_I1")
        await db_session.commit()

        result = (await make_calc_catalog(db_session)).instrument_codes_for_parameters({param_code})

        assert result == {instrument_code}

    async def test_empty_input_returns_empty(self, db_session: AsyncSession):
        result = (await make_calc_catalog(db_session)).instrument_codes_for_parameters(set())

        assert result == set()

    async def test_unknown_parameter_returns_empty(self, db_session: AsyncSession):
        result = (await make_calc_catalog(db_session)).instrument_codes_for_parameters({"NEVER_EXISTED_XYZ"})

        assert result == set()

    async def test_inactive_instrument_excluded(self, db_session: AsyncSession, factory: Factory):
        await factory.parameter("LIP_P2")
        await factory.instrument("LIP_INACTIVE", status="inactive")
        await factory.link_parameter(instrument_code="LIP_INACTIVE", parameter_code="LIP_P2", is_required=True)
        await db_session.commit()

        result = (await make_calc_catalog(db_session)).instrument_codes_for_parameters({"LIP_P2"})

        assert result == set()


async def _seed_questionnaire(
    factory: Factory,
    *,
    param_code: str,
    instrument_code: str,
    system_code: str,
    patient_value: str,
    option_score: float,
) -> str:
    patient_id = await factory.patient()
    await factory.parameter(param_code)
    await factory.instrument(instrument_code, type=Instrument.TYPE_QUESTIONNAIRE)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code, is_required=True)
    await factory.system(system_code)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
    await factory.parameter_score(
        parameter_code=param_code, system_code=system_code, value=patient_value, score=option_score
    )
    await factory.answer(patient_id=patient_id, parameter_code=param_code, value=patient_value)
    return patient_id


async def _build_scores(session: AsyncSession, patient_id: str) -> list[QuestionnaireScoreRow]:
    """STEP-1/2/4 баллы через боевой путь: одно чтение + расчёт в памяти (см. CalcHandler._load).

    `build_questionnaire_scores` — чистая функция от загруженных строк и каталога, поэтому тесты
    остаются интеграционными ровно там, где это важно: сиды идут в БД, а на вход подаются те же
    самые `load_patient_snapshot`, что и в проде.
    """
    reader = CalcReader(session, await make_calc_catalog(session))
    snapshot = await reader.load_patient_snapshot([patient_id])
    return reader.build_questionnaire_scores(snapshot.rows)


class TestBuildQuestionnaireScores:
    async def test_returns_summed_score_for_one_parameter(self, db_session: AsyncSession, factory: Factory):
        patient_id = await _seed_questionnaire(
            factory,
            param_code="QS_P1",
            instrument_code="QS_I1",
            system_code="QS_SYS1",
            patient_value="Да",
            option_score=2.0,
        )
        await db_session.commit()

        rows = await _build_scores(db_session, patient_id)

        assert len(rows) == 1
        assert isinstance(rows[0], QuestionnaireScoreRow)
        assert rows[0].patient_id == patient_id
        assert rows[0].instrument_code == "QS_I1"
        assert rows[0].score == pytest.approx(2.0)

    async def test_sums_scores_for_multiple_parameters_on_same_instrument(
        self, db_session: AsyncSession, factory: Factory
    ):
        patient_id = await factory.patient()
        await factory.instrument("QS_I2", type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.system("QS_SYS2")
        await factory.link_system_instrument(system_code="QS_SYS2", instrument_code="QS_I2")
        for i, score in enumerate([1.0, 2.0, 0.5], start=1):
            pcode = f"QS_P2_{i}"
            await factory.parameter(pcode)
            await factory.link_parameter(instrument_code="QS_I2", parameter_code=pcode, is_required=True)
            await factory.parameter_score(parameter_code=pcode, system_code="QS_SYS2", value="Да", score=score)
            await factory.answer(patient_id=patient_id, parameter_code=pcode, value="Да")
        await db_session.commit()

        rows = await _build_scores(db_session, patient_id)

        qs_i2_rows = [r for r in rows if r.instrument_code == "QS_I2"]
        assert len(qs_i2_rows) == 1
        assert qs_i2_rows[0].score == pytest.approx(3.5)

    async def test_excludes_expired_patient_parameters(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        await factory.parameter("QS_EXP")
        await factory.instrument("QS_I_EXP", type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_parameter(instrument_code="QS_I_EXP", parameter_code="QS_EXP", is_required=True)
        await factory.question("Q_QS_EXP", type="single", group_code=0, question_text="")
        await factory.option("OPT_QS_EXP", question_code="Q_QS_EXP", parameter_code="QS_EXP")
        past = datetime.now(tz=UTC) - timedelta(days=1)
        await factory.answer(patient_id=patient_id, parameter_code="QS_EXP", value="Да", expiration_date=past)
        await db_session.commit()

        rows = await _build_scores(db_session, patient_id)

        assert not any(r.instrument_code == "QS_I_EXP" for r in rows)

    async def test_returns_empty_for_unknown_patient(self, db_session: AsyncSession):
        rows = await _build_scores(db_session, "999999")
        assert rows == []


async def _seed_questionnaire_instrument(factory: Factory, *, instrument_code: str, param_codes: Sequence[str]) -> str:
    """Опросник со своими обязательными параметрами — без вопросов и опций.

    Параметр без строки в `options` в знаменатель гейта не попадает: это ровно то, что
    проверяют тесты ниже.
    """
    await factory.instrument(instrument_code, type=Instrument.TYPE_QUESTIONNAIRE)
    for param_code in param_codes:
        await factory.parameter(param_code)
        await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code, is_required=True)
    return instrument_code


class TestBuildQuestionnaireEligibility:
    """STEP 3: единственное условие — Y/X ≥ 0.5 по вопросам СИСТЕМЫ инструмента."""

    @staticmethod
    async def _load(session: AsyncSession, patient_ids: list[str]) -> dict[tuple[str, str], QuestionnaireEligibility]:
        """Прогон как в CalcHandler._load: одно чтение снимка и расчёт в памяти.

        Сам гейт в БД не ходит, но тест остаётся интеграционным там, где это важно: сиды идут в
        реальную схему, а на вход подаётся ровно тот же `load_patient_snapshot`, что и в проде.
        """
        reader = CalcReader(session, await make_calc_catalog(session))
        snapshot = await reader.load_patient_snapshot(patient_ids)
        return reader.build_questionnaire_eligibility(patient_ids, snapshot.rows, snapshot.patient_data)

    async def test_counts_applicable_and_progressed_questions(self, db_session: AsyncSession, factory: Factory):
        """X/Y считаются целыми вопросами системы инструмента."""
        patient_id = await factory.patient()
        icode = "ELG_I1"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        # 3 questions on the instrument: 2 answered, 1 not.
        await factory.question_with_options("ELG_Q1", ["ELG_N1"], instrument_code=icode)
        await factory.question_with_options("ELG_Q2", ["ELG_N2"], instrument_code=icode)
        await factory.question_with_options("ELG_Q3", ["ELG_N3"], instrument_code=icode)
        await factory.answer_question(patient_id=patient_id, question_code="ELG_Q1")
        await factory.answer_question(patient_id=patient_id, question_code="ELG_Q2")
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert isinstance(elig, QuestionnaireEligibility)
        assert elig.applicable_questions == 3
        assert elig.progressed_questions == 2

    async def test_multi_parameter_question_needs_every_parameter(self, db_session: AsyncSession, factory: Factory):
        """Вопрос пишет два параметра; отвечен только один → в числитель не идёт."""
        patient_id = await factory.patient()
        icode = "ELG_MULTI"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_QM", ["ELG_M1", "ELG_M2"], instrument_code=icode)
        await factory.answer(patient_id=patient_id, parameter_code="ELG_M1", value="Да")
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 1
        assert elig.progressed_questions == 0

    async def test_question_of_other_gender_is_out_of_the_denominator(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        icode = "ELG_GENDER"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_QG_ANY", ["ELG_G_ANY"], instrument_code=icode)
        await factory.question_with_options(
            "ELG_QG_F",
            ["ELG_G_FEMALE"],
            instrument_code=icode,
            conditions=[("except", PARAMETER_CODE_GENDER, GENDER_MALE, None, None)],
        )
        await factory.answer_question(patient_id=patient_id, question_code="ELG_QG_ANY")
        await factory.answer_all_general_params(patient_id=patient_id, values={PARAMETER_CODE_GENDER: GENDER_MALE})
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 1  # женский вопрос выпал из X
        assert elig.progressed_questions == 1

    async def test_question_out_of_age_range_is_out_of_the_denominator(
        self, db_session: AsyncSession, factory: Factory
    ):
        patient_id = await factory.patient()
        icode = "ELG_AGE"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_QA_ANY", ["ELG_A_ANY"], instrument_code=icode)
        await factory.question_with_options(
            "ELG_QA_OLD",
            ["ELG_A_OLD"],
            instrument_code=icode,
            conditions=[("age", PARAMETER_CODE_AGE, None, 45, 100)],
        )
        await factory.answer_question(patient_id=patient_id, question_code="ELG_QA_ANY")
        young = datetime.now(tz=UTC).date().replace(year=datetime.now(tz=UTC).year - 30).isoformat()
        await factory.answer_all_general_params(patient_id=patient_id, values={PARAMETER_CODE_BIRTHDATE: young})
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 1  # возрастной вопрос выпал из X
        assert elig.progressed_questions == 1

    async def test_hidden_question_is_auto_credited(self, db_session: AsyncSession, factory: Factory):
        """Вопрос, скрытый `except` по не-gender параметру, входит в X и засчитывается в Y без ответа."""
        patient_id = await factory.patient()
        icode = "ELG_HIDDEN"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_QH_ANY", ["ELG_H_ANY"], instrument_code=icode)
        await factory.parameter("ELG_H_TRIGGER")
        await factory.question_with_options(
            "ELG_QH_BRANCH",
            ["ELG_H_BRANCH"],
            instrument_code=icode,
            conditions=[("except", "ELG_H_TRIGGER", "Нет", None, None)],
        )
        await factory.answer_question(patient_id=patient_id, question_code="ELG_QH_ANY")
        await factory.answer(patient_id=patient_id, parameter_code="ELG_H_TRIGGER", value="Нет")
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 2
        assert elig.progressed_questions == 2  # ELG_QH_BRANCH зачтён скрытым, хотя ответа нет

    async def test_except_condition_on_unanswered_parameter_is_not_credited(
        self, db_session: AsyncSession, factory: Factory
    ):
        patient_id = await factory.patient()
        icode = "ELG_NOTRIGGER"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_QN_ANY", ["ELG_N_ANY"], instrument_code=icode)
        await factory.parameter("ELG_N_TRIGGER")
        await factory.question_with_options(
            "ELG_QN_BRANCH",
            ["ELG_N_BRANCH"],
            instrument_code=icode,
            conditions=[("except", "ELG_N_TRIGGER", "Нет", None, None)],
        )
        await factory.answer_question(patient_id=patient_id, question_code="ELG_QN_ANY")
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 2
        assert elig.progressed_questions == 1

    async def test_unanswered_general_data_does_not_block(self, db_session: AsyncSession, factory: Factory):
        """Пациент ответил на вопрос системы, но ни на один «общий» (is_pregnant IS NULL).

        Отдельного гейта «Общие данные отвечены целиком» больше нет: «общие» вопросы влияют на
        счёт только если их параметр входит в систему через `instruments_parameters`.
        """
        patient_id = await factory.patient(is_pregnant=None)
        icode = "ELG_I2"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG2_Q1", ["ELG2_N1"], instrument_code=icode)
        await factory.answer_question(patient_id=patient_id, question_code="ELG2_Q1")
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 1
        assert elig.progressed_questions == 1

    async def test_question_of_a_sibling_instrument_of_the_same_system_counts(
        self, db_session: AsyncSession, factory: Factory
    ):
        """Пул строится по СИСТЕМЕ: вопрос соседнего по системе инструмента входит в X."""
        patient_id = await factory.patient()
        icode = "ELG_SYS_FORM"
        sibling = "ELG_SYS_CALC"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        system_code = await factory.link_system(instrument_code=icode)
        await factory.instrument(sibling)
        await factory.link_system(instrument_code=sibling, system_code=system_code)
        await factory.question_with_options("ELG_SYS_Q1", ["ELG_SYS_N1"], instrument_code=icode)
        await factory.question_with_options("ELG_SYS_Q2", ["ELG_SYS_N2"], instrument_code=sibling)
        await factory.answer_question(patient_id=patient_id, question_code="ELG_SYS_Q1")
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 2  # вопрос соседа по системе тоже в знаменателе
        assert elig.progressed_questions == 1

    async def test_general_data_question_counts_in_the_denominator(self, db_session: AsyncSession, factory: Factory):
        """«Общий» вопрос (group_code=1) больше не исключается — он такой же вопрос системы."""
        patient_id = await factory.patient()
        icode = "ELG_GEN"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("ELG_GEN_Q1", ["ELG_GEN_N1"], instrument_code=icode)
        await factory.question_with_options("ELG_GEN_Q2", ["ELG_GEN_N2"], instrument_code=icode, group_code=1)
        await factory.answer_question(patient_id=patient_id, question_code="ELG_GEN_Q1")
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 2
        assert elig.progressed_questions == 1  # «общий» вопрос не отвечен — как любой другой

    @pytest.mark.parametrize(
        ("is_pregnant", "expected_progressed"),
        [(False, 2), (None, 1)],
        ids=["answered", "unanswered"],
    )
    async def test_pregnancy_question_is_credited_from_patients_table(
        self, db_session: AsyncSession, factory: Factory, is_pregnant: bool | None, expected_progressed: int
    ):
        """Ответ на cq_030 лежит в `patients.is_pregnant`, а не в `patients_parameters`.

        Если параметр беременности входит в систему, вопрос попадает в X — и засчитывается в Y
        по факту непустого `patients.is_pregnant` (как в заполненности Risk-profile).
        """
        patient_id = await factory.patient(is_pregnant=is_pregnant)
        icode = "ELG_PREG"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.link_parameter(instrument_code=icode, parameter_code="is_pregnant", is_required=False)
        await factory.question_with_options("ELG_PREG_Q1", ["ELG_PREG_N1"], instrument_code=icode)
        await factory.answer_question(patient_id=patient_id, question_code="ELG_PREG_Q1")
        # cq_030 не применим мужчинам (`except` gender=Мужской) и пациентам 50+ (`age` 1–49) —
        # пациентке 30 лет он применим. Дата рождения нужна: без неё возрастное условие
        # не проходит и вопрос выпадает из X.
        await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_FEMALE)
        await factory.answer(
            patient_id=patient_id, parameter_code=PARAMETER_CODE_BIRTHDATE, value=_birthdate_for_age(30)
        )
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 2  # свой вопрос + cq_030 через параметр is_pregnant
        assert elig.progressed_questions == expected_progressed

    async def test_patient_who_answered_nothing_has_no_entry(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        icode = "ELG_I3"
        await _seed_questionnaire_instrument(factory, instrument_code=icode, param_codes=["ELG3_N1"])
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        assert (patient_id, icode) not in result

    async def test_instrument_without_questions_has_zero_applicable(self, db_session: AsyncSession, factory: Factory):
        """Параметр инструмента, не привязанный ни к одному вопросу через options, в X не попадает."""
        patient_id = await factory.patient()
        icode = "ELG_I5"
        await _seed_questionnaire_instrument(factory, instrument_code=icode, param_codes=["ELG5_N1", "ELG5_ORPHAN"])
        await factory.answer(patient_id=patient_id, parameter_code="ELG5_N1", value="Да")
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.applicable_questions == 0
        assert elig.progressed_questions == 0

    async def test_required_counts_reflect_answered_required_params(self, db_session: AsyncSession, factory: Factory):
        """required_total = instrument's is_required params; required_answered = those the patient answered."""
        patient_id = await factory.patient()
        icode = "ELG_REQ"
        # 3 required params (seed helper sets is_required=true): 2 answered, 1 not
        await _seed_questionnaire_instrument(factory, instrument_code=icode, param_codes=["REQ_N1", "REQ_N2", "REQ_N3"])
        await factory.answer(patient_id=patient_id, parameter_code="REQ_N1", value="Да")
        await factory.answer(patient_id=patient_id, parameter_code="REQ_N2", value="Нет")
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        elig = result[(patient_id, icode)]
        assert elig.required_total == 3
        assert elig.required_answered == 2

    async def test_expired_answers_excluded(self, db_session: AsyncSession, factory: Factory):
        patient_id = await factory.patient()
        icode = "ELG_I4"
        await _seed_questionnaire_instrument(factory, instrument_code=icode, param_codes=["ELG4_N1"])
        past = datetime.now(tz=UTC) - timedelta(days=1)
        await factory.answer(patient_id=patient_id, parameter_code="ELG4_N1", value="Да", expiration_date=past)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        assert (patient_id, icode) not in result

    async def test_general_only_answers_create_no_gated_eligibility_entry(
        self, db_session: AsyncSession, factory: Factory
    ):
        """Гейтящиеся инструменты не линкуют «общие» параметры через instruments_parameters
        (реальный сид), поэтому ответы только на «Общие данные» не создают ни одной их записи
        eligibility: пайплайн answer-driven — инструмент без ответов не считается вовсе, и
        required-guard для такого пациента не срабатывает (ревью !156).
        """
        patient_id = await factory.patient()
        await factory.answer_all_general_params(patient_id=patient_id)
        await db_session.commit()

        result = await self._load(db_session, [patient_id])

        gated_entries = {key for key in result if key[1] in GATED_QUESTIONNAIRE_CODES}
        assert gated_entries == set()

    async def test_real_catalog_question_shared_between_gated_instruments(self, db_session: AsyncSession):
        """Пин по реальному сиду: вопрос о питании sq_1150 (параметр food) принадлежит сразу
        нескольким гейтящимся инструментам и участвует в X/Y каждого (ревью !156).
        """
        cat = await make_calc_catalog(db_session)

        assert "sq_1150" in cat.question_codes_by_instrument["form_gi"]
        assert "sq_1150" in cat.question_codes_by_instrument["form_blood"]


class TestActualityBoundary:
    """Ревью !156: критерий актуальности `value IS NOT NULL AND expiration_date >= now()` един
    для параметров формул, суммы баллов опросников и гейта STEP 3.

    `now()` в Postgres — transaction_timestamp: внутри одной транзакции константа. Строка с
    `expiration_date = now()`, вставленная и прочитанная БЕЗ commit между ними, детерминированно
    ложится ровно на границу: `>=` её видит, прежний `>` в SQL баллов — не видел.

    После переноса баллов и гейта в память единство критерия держится конструкцией: оба шага
    считаются из одного и того же снимка `load_patient_snapshot`, второго фильтра больше нет.
    Тест остаётся сторожем этого среза — граничная строка обязана быть в нём.
    """

    async def test_row_expiring_exactly_now_is_visible_to_scores_gate_and_formulas_alike(
        self, db_session: AsyncSession, factory: Factory
    ):
        patient_id = await factory.patient()
        icode = "NOW_I1"
        await factory.instrument(icode, type=Instrument.TYPE_QUESTIONNAIRE)
        await factory.link_system(instrument_code=icode)
        await factory.question_with_options("NOW_Q1", ["NOW_P1"], instrument_code=icode)
        # Системная привязка нужна: без systems_instruments инструмент не даёт целей начисления.
        await factory.system("NOW_SYS")
        await factory.link_system_instrument(system_code="NOW_SYS", instrument_code=icode)
        await db_session.commit()

        # Граница: expiration_date = now() этой транзакции; commit до чтений намеренно НЕТ.
        await db_session.execute(
            text(
                "INSERT INTO patients_parameters (patient_id, parameter_code, value, source,"
                " expiration_date)"
                " VALUES (:pid, 'NOW_P1', 'Да', 'test', now())"
            ),
            {"pid": patient_id},
        )
        reader = CalcReader(db_session, await make_calc_catalog(db_session))

        snapshot = await reader.load_patient_snapshot([patient_id])
        rows = snapshot.rows
        assert [r.parameter_code for r in rows] == ["NOW_P1"]  # формулы строку видят

        scores = reader.build_questionnaire_scores(rows)
        assert any(r.instrument_code == icode for r in scores)  # сумма баллов — тоже

        elig = reader.build_questionnaire_eligibility([patient_id], rows, snapshot.patient_data)
        assert elig[(patient_id, icode)].progressed_questions == 1  # и гейт засчитывает вопрос
