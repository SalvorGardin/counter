"""Фикстуры calc-тестов.

`stub_formula` патчит доменный класс, который тесты хендлера как раз и оркестрируют.
Это осознанное отступление от «мокать на швах»: предмет проверки здесь — порядок вызовов,
батчинг и откат, а не арифметика конкретной формулы. Тесты самих формул живут в
tests/unit/calc/domain/ и ничего не патчат.
"""

from collections.abc import Awaitable, Callable, Iterator
from datetime import timedelta
from unittest.mock import patch

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.formula import Formula
from src.calc.domain.models import (
    FormulaResult,
    InstrumentInput,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from src.calc.handler import CalcHandler
from src.config import settings
from src.constants import ResultInterpretationStatus
from tests.conftest import make_calc_catalog, make_interpretation_catalog, open_formula_registry
from tests.factories import Factory
from tests.integration.calc.bulk_recalc_support import seed_stale_cohort

# Фабрика хендлера, которую отдаёт фикстура `calc_handler`.
CalcHandlerFactory = Callable[..., Awaitable[CalcHandler]]


@pytest.fixture
def run_settings(monkeypatch: pytest.MonkeyPatch) -> Callable[..., None]:
    """Small, fast bulk-recalc limits shared by producer and producer-to-consumer tests."""

    def _apply(**overrides: object) -> None:
        defaults = {
            "enabled": True,
            "batch_size": 2,
            "pause_seconds": 0.0,
            "time_budget_seconds": 60.0,
            "canary_size": 2,
            "canary_timeout_seconds": 0.3,
            "canary_poll_interval_seconds": 0.05,
            "query_timeout_seconds": 5.0,
        }
        for name, value in (defaults | overrides).items():
            monkeypatch.setattr(settings.bulk_recalc, name, value)

    return _apply


@pytest.fixture
def seed_cohort(factory: Factory, db_session: AsyncSession) -> Callable[..., Awaitable[list[str]]]:
    """Create patients with committed registry stamps for a bulk-recalc scenario."""

    async def _seed(size: int, *, version: str = "previous") -> list[str]:
        return await seed_stale_cohort(factory, db_session, size, version=version)

    return _seed


def always_applicable(self: Formula, input: InstrumentInput) -> bool:  # noqa: ARG001, A002
    """Публичные имена: пара тестов подменяет формулу по-своему и переиспользует эти тела."""
    return True


def stub_result(self: Formula, input: InstrumentInput) -> FormulaResult:  # noqa: ARG001, A002
    return FormulaResult(
        instrument_code=input.instrument_code,
        patient_id=input.patient_id,
        value=0.0,
        unit=InstrumentsUnits.BCRAT,
        risk_level=InstrumentsRiskLevel.LOW,
        applicability=True,
        interpretation_status=ResultInterpretationStatus.READY,
        expiration_delta=timedelta(days=365),
        indicator=InstrumentsIndicators.BCRAT,
    )


def stub_result_list(self: Formula, input: InstrumentInput) -> list[FormulaResult]:  # noqa: ARG001, A002
    """Формула, возвращающая несколько показателей: так считает шкала Спилбергера — Ханина."""
    return [
        FormulaResult(
            instrument_code=input.instrument_code,
            patient_id=input.patient_id,
            value=35.0,
            unit=InstrumentsUnits.SPILLBERGER_HANIN,
            risk_level=InstrumentsRiskLevel.MEDIUM,
            applicability=True,
            interpretation_status=ResultInterpretationStatus.READY,
            expiration_delta=timedelta(days=365),
            indicator=InstrumentsIndicators.SPILLBERGER_HANIN_SITUATION,
        ),
        FormulaResult(
            instrument_code=input.instrument_code,
            patient_id=input.patient_id,
            value=41.0,
            unit=InstrumentsUnits.SPILLBERGER_HANIN,
            risk_level=InstrumentsRiskLevel.MEDIUM,
            applicability=True,
            interpretation_status=ResultInterpretationStatus.READY,
            expiration_delta=timedelta(days=365),
            indicator=InstrumentsIndicators.SPILLBERGER_HANIN_PERSONAL,
        ),
    ]


@pytest.fixture
def stub_formula() -> Iterator[None]:
    """Формула всегда применима и возвращает фиксированный результат.

    Фикстура, а не модульный кортеж patch-объектов: context manager одноразовый, поэтому
    один общий кортеж отработал бы ровно в одном тесте, а во втором упал бы на входе.
    """
    with (
        open_formula_registry(),
        patch.object(Formula, "is_applicable", always_applicable),
        patch.object(Formula, "calculate", stub_result),
    ):
        yield


@pytest.fixture
def stub_formula_list() -> Iterator[None]:
    """То же, но формула отдаёт список результатов — по показателю на строку."""
    with (
        open_formula_registry(),
        patch.object(Formula, "is_applicable", always_applicable),
        patch.object(Formula, "calculate", stub_result_list),
    ):
        yield


@pytest_asyncio.fixture
async def calc_handler(db_session: AsyncSession) -> CalcHandlerFactory:
    """Фабрика хендлера: вызывать ПОСЛЕ сидов теста.

    Каталог читается из БД, поэтому кэшировать его между тестами нельзя — каждый тест
    засевает свои справочные строки, и хендлер обязан их видеть.
    """

    async def _make(**kwargs: object) -> CalcHandler:
        kwargs.setdefault("interpretation_catalog", await make_interpretation_catalog(db_session))
        return CalcHandler(db_session, await make_calc_catalog(db_session), **kwargs)  # ty: ignore[invalid-argument-type]

    return _make
