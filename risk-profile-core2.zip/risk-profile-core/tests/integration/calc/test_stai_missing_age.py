"""STAI calculation must be skipped entirely when 'age' is absent or null.

Migration 0045 made 'age' a required parameter for STAI (was optional in 0043).
Before that change: age absent → is_applicable() returned False → make_dummy() wrote
2 records with applicability=False. Expected: no records at all.
After migration 0045: age absent → InstrumentInput.build() returns None → handler skips.
"""

from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest, InstrumentsCodes
from tests.consts import PARAMETER_CODE_AGE
from tests.db_assertions import DbRead
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory

_STAI_ANSWER = "Нет, это не так"
_STAI_REQUIRED_PARAMS = [f"stai{i}" for i in range(1, 41)]


async def _insert_stai_answers(factory: Factory, patient_id: str) -> None:
    for code in _STAI_REQUIRED_PARAMS:
        await factory.answer(patient_id=patient_id, parameter_code=code, value=_STAI_ANSWER)


class TestStaiSkipsWhenAgeMissing:
    async def test_no_result_when_age_row_is_absent(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        """All 40 STAI answers present, no age row — no result must be created."""
        patient_id = await factory.patient()
        await _insert_stai_answers(factory, patient_id)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run(
            [
                CalculationRequest(
                    patient_id=patient_id,
                    instrument_codes=frozenset({InstrumentsCodes.SPILLBERGER_HANIN}),
                )
            ]
        )

        assert (
            await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.SPILLBERGER_HANIN) == 0
        )

    async def test_no_result_when_age_value_is_null(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        """All 40 STAI answers present, age row exists with value=NULL — no result must be created."""
        patient_id = await factory.patient()
        await _insert_stai_answers(factory, patient_id)
        await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_AGE, value=None)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run(
            [
                CalculationRequest(
                    patient_id=patient_id,
                    instrument_codes=frozenset({InstrumentsCodes.SPILLBERGER_HANIN}),
                )
            ]
        )

        assert (
            await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.SPILLBERGER_HANIN) == 0
        )
