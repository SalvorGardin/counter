"""Флаг `RISK_MODEL_STEP_TIMINGS_ENABLED`: сбор замеров идёт только при включённом флаге и никогда
не влияет на сам расчёт.

Прогоняем один и тот же SCORE2-диспатч дважды (флаг выключен / включён) и сверяем, что результат в
БД одинаковый, а sink заполняется только во втором случае. Сбор — внутренняя, не боевая поверхность,
поэтому модуль под `test_internal`; правило пропуска (tests/conftest.py) гасит весь маркер по
`RISK_MODEL_TESTING_API_ENABLED`, а не по `RISK_MODEL_STEP_TIMINGS_ENABLED`.
"""

import dataclasses

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import CalculationRequest, InstrumentsCodes
from src.calc.timings import StepTimings
from src.config import settings
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_AGE, PARAMETER_CODE_GENDER
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory

pytestmark = pytest.mark.test_internal

# Женщина 45 лет без факторов риска — минимальный набор параметров, на котором SCORE2 считается
# (тот же, что в test_formula_e2e.TestScore2EndToEnd).
_SCORE2_PARAMS = {
    PARAMETER_CODE_AGE: "45",
    PARAMETER_CODE_GENDER: GENDER_FEMALE,
    "smoking": "Нет",
    "systolic_bp": "120",
    "total_cholesterol": "4.0",
    "ldl": "2.0",
    "hdl": "1.0",
    "atherosclerosis": "Нет",
    "diabetes": "Нет",
    "family_hypercholesterolemia": "Нет",
}


async def _seed_patient(session: AsyncSession, factory: Factory) -> str:
    patient_id = await factory.patient()
    for code, value in _SCORE2_PARAMS.items():
        await factory.answer(patient_id=patient_id, parameter_code=code, value=value)
    await session.commit()
    return patient_id


async def _score2_value(session: AsyncSession, patient_id: str) -> float:
    r = await session.execute(
        text("SELECT value FROM results WHERE patient_id = :pid AND instrument_code = :icode"),
        {"pid": patient_id, "icode": InstrumentsCodes.SCORE2},
    )
    return float(r.scalar_one())


def _all_durations(timings: StepTimings) -> list[float]:
    """Все float-поля дерева замеров, включая вложенные (load / interpretation / interpretation.load)."""
    values: list[float] = []
    stack: list[object] = [timings]
    while stack:
        obj = stack.pop()
        for f in dataclasses.fields(obj):  # ty: ignore[invalid-argument-type]
            value = getattr(obj, f.name)
            if dataclasses.is_dataclass(value):
                stack.append(value)
            elif isinstance(value, float):
                values.append(value)
    return values


async def test_disabled_flag_collects_nothing_and_still_calculates(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(settings, "step_timings_enabled", False)
    patient_id = await _seed_patient(db_session, factory)
    timings = StepTimings()

    handler = await calc_handler()
    await handler.run(
        [CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({InstrumentsCodes.SCORE2}))],
        timings=timings,
    )

    # Расчёт отработал как обычно — флаг гасит только замеры.
    assert await _score2_value(db_session, patient_id) == pytest.approx(1.2, abs=0.05)
    # Sink передан: `ran` отмечает вход в хендлер, но ни один шаг не замерен.
    assert timings.enabled is False
    assert timings.ran is True
    assert _all_durations(timings) == pytest.approx([0.0] * len(_all_durations(timings)))


async def test_enabled_flag_fills_the_sink(
    db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(settings, "step_timings_enabled", True)
    patient_id = await _seed_patient(db_session, factory)
    timings = StepTimings()

    handler = await calc_handler()
    await handler.run(
        [CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({InstrumentsCodes.SCORE2}))],
        timings=timings,
    )

    assert await _score2_value(db_session, patient_id) == pytest.approx(1.2, abs=0.05)
    assert timings.enabled is True
    assert timings.ran is True
    # Шаги, которые на этом пути гарантированно выполняются (остальные могут быть честными нулями).
    assert timings.load_ms > 0.0
    assert timings.load.parameters_ms > 0.0
    assert timings.upsert_ms > 0.0
