"""Продюсер массового пересчёта: когорта, проверка раската, ограничения прогона и его исход.

Kafka подменяется продюсером-накопителем: предмет проверки — что именно и по каким пациентам
публикуется, а доставка в брокер покрыта тестами самого продюсера. Реестр и когорта — настоящие,
в базе: на них держится и возобновляемость прогона, и его самозавершение.
"""

import asyncio
import contextlib
import os
import signal
from collections.abc import Mapping
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock

import pytest
import sqlalchemy as sa
from sqlalchemy.exc import InterfaceError, OperationalError, ProgrammingError
from sqlalchemy.ext.asyncio import AsyncSession

import src.workers.bulk_recalc as bulk_recalc
from src.calc.infra.version_registry import VersionRegistry
from src.calc.recalc_message import decode_command
from src.config import settings
from src.constants import KAFKA_HEADER_REQUEST_ID
from tests.conftest import LogSink
from tests.factories import Factory, unique_id
from tests.integration.calc.bulk_recalc_support import seed_stale_cohort as _cohort

_VERSION = "test-current"


class FakeProducer:
    """Собирает опубликованное вместо брокера."""

    def __init__(self) -> None:
        self.messages: list[tuple[str, dict[str, Any]]] = []
        self.headers: list[dict[str, str]] = []

    async def send(
        self, *, topic: str, value: dict[str, Any], key: str | None = None, headers: dict[str, str] | None = None
    ) -> None:
        self.messages.append((key or "", value))
        self.headers.append(headers or {})

    def commands(self) -> list:
        return [decode_command(value) for _, value in self.messages]


class WorkerLikeProducer(FakeProducer):
    """Продюсер, за которым стоит воркер: пересчитав команду, он штампует реестр своей версией.

    Воркер текущей версии — так выглядит завершённый раскат со стороны продюсера прогона.
    `per_patient` задаёт исход по отдельным пациентам: версию другого воркера (раскат не
    завершён) либо `None` — пересчёт упал, и реестр не тронут. `admitted` — сколько первых
    команд воркер допустит к расчёту: остальные политика допуска отбросила (закрытый фон).
    """

    def __init__(
        self,
        session: AsyncSession,
        version: str,
        per_patient: Mapping[str, str | None] | None = None,
        *,
        admitted: int | None = None,
    ) -> None:
        super().__init__()
        self._session = session
        self._version = version
        self._per_patient = per_patient or {}
        self._admitted = admitted

    async def send(
        self, *, topic: str, value: dict[str, Any], key: str | None = None, headers: dict[str, str] | None = None
    ) -> None:
        await super().send(topic=topic, value=value, key=key, headers=headers)
        if self._admitted is not None and len(self.messages) > self._admitted:
            return
        version = self._per_patient.get(value["clientId"], self._version)
        if version is not None:
            # Без собственной транзакции: сессия у теста и у прогона одна, и штамп обязан быть
            # виден следующему чтению реестра в ней же.
            await VersionRegistry(self._session).stamp(value["clientId"], version)


class TransactionProbingProducer(FakeProducer):
    """Запоминает, открыта ли транзакция сессии прогона в момент публикации каждой команды."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__()
        self._session = session
        self.in_transaction: list[bool] = []

    async def send(
        self, *, topic: str, value: dict[str, Any], key: str | None = None, headers: dict[str, str] | None = None
    ) -> None:
        self.in_transaction.append(self._session.in_transaction())
        await super().send(topic=topic, value=value, key=key, headers=headers)


@pytest.fixture
def patched_session(db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch):
    """Продюсер открывает собственную сессию — уводим её на тестовую."""

    @contextlib.asynccontextmanager
    async def _factory():
        yield db_session

    monkeypatch.setattr(bulk_recalc, "get_primary_runtime", lambda: SimpleNamespace(session_factory=_factory))


def _run_for(db_session: AsyncSession, producer: FakeProducer) -> bulk_recalc.BulkRecalcRun:
    return bulk_recalc.BulkRecalcRun(db_session, producer, _VERSION)  # ty: ignore[invalid-argument-type]


class TestPublishing:
    async def test_every_cohort_patient_gets_exactly_one_full_recalc_command(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        run_settings()
        patients = await _cohort(factory, db_session, 3)
        producer = FakeProducer()

        walk = await _run_for(db_session, producer).walk_cohort()

        assert walk.stopped_by_time_budget is False
        mine = [command for command in producer.commands() if command.patient_id in patients]
        assert sorted(command.patient_id for command in mine) == patients
        assert walk.published >= len(patients)
        assert all(command.parameter_codes is None for command in mine)

    async def test_commands_carry_the_background_marker_and_the_patient_key(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Ключ — идентификатор пациента: команды одного пациента идут в одну партицию, поэтому
        фоновая не обгоняет пользовательскую."""
        run_settings()
        patients = await _cohort(factory, db_session, 1)
        producer = FakeProducer()

        await _run_for(db_session, producer).walk_cohort()

        published = [(key, value) for key, value in producer.messages if key in patients]
        assert published
        for key, value in published:
            assert value["clientId"] == key
            assert value["background"] is True

    async def test_every_command_carries_its_own_request_id(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Общий на прогон `x-request-id` слил бы в логах воркера все его пересчёты в один
        `requestId`, и судьбу отдельного пациента по логам было бы не разобрать."""
        run_settings()
        await _cohort(factory, db_session, 3)
        producer = FakeProducer()

        await _run_for(db_session, producer).walk_cohort()

        request_ids = [headers[KAFKA_HEADER_REQUEST_ID] for headers in producer.headers]
        assert len(request_ids) >= 3
        assert len(set(request_ids)) == len(request_ids)

    async def test_patient_of_the_current_version_is_not_published(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        run_settings()
        current = (await _cohort(factory, db_session, 1, version=_VERSION))[0]
        producer = FakeProducer()

        await _run_for(db_session, producer).walk_cohort()

        assert current not in [key for key, _ in producer.messages]

    async def test_no_transaction_is_held_while_commands_are_published(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Прогон длится до часа: транзакция, открытая первым чтением реестра и не закрытая до
        конца, держала бы снапшот и горизонт `xmin` всё это время."""
        run_settings()
        await _cohort(factory, db_session, 3)
        producer = TransactionProbingProducer(db_session)

        await _run_for(db_session, producer).walk_cohort()

        assert producer.messages
        assert not any(producer.in_transaction)


class TestRunLimits:
    async def test_run_stops_at_the_time_ceiling_and_leaves_the_rest_to_the_next_run(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        run_settings(batch_size=1, pause_seconds=0.05, time_budget_seconds=0.06)
        await _cohort(factory, db_session, 3)
        producer = FakeProducer()

        walk = await _run_for(db_session, producer).walk_cohort()

        assert walk.stopped_by_time_budget is True
        assert walk.published >= 1

    async def test_exhausted_cohort_ends_the_walk(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        run_settings()
        await _cohort(factory, db_session, 2)
        producer = FakeProducer()

        walk = await _run_for(db_session, producer).walk_cohort()

        assert walk.stopped_by_time_budget is False

    async def test_disabled_run_publishes_nothing(
        self, run_settings, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
    ) -> None:
        """Выключатель — штатный способ остановить прогон, поэтому процесс завершается успешно."""
        run_settings(enabled=False)
        monkeypatch.setattr(bulk_recalc, "verify_runtime_login", lambda *a, **kw: pytest.fail("до БД дойти не должно"))

        assert await bulk_recalc._run(_VERSION) == bulk_recalc._EXIT_OK
        assert f"{bulk_recalc._NAME}: disabled by configuration, nothing published" in captured_app_logs.messages()

    async def test_run_without_kafka_is_reported_as_not_run(
        self, run_settings, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
    ) -> None:
        """Публиковать некуда: молчаливый успешный прогон выглядел бы выполненной работой."""
        run_settings()
        monkeypatch.setattr(settings.kafka, "enabled", False)
        monkeypatch.setattr(bulk_recalc, "verify_runtime_login", lambda *a, **kw: pytest.fail("DB must not be queried"))

        assert await bulk_recalc._run(_VERSION) == bulk_recalc._EXIT_NOT_RUN
        message = f"{bulk_recalc._NAME}: kafka is disabled, the run cannot publish commands"
        record = next(record for record in captured_app_logs.records if record.getMessage() == message)
        assert record.levelname == "ALERT"

    async def test_hung_registry_query_is_cut_by_the_query_timeout(
        self, db_session: AsyncSession, run_settings, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Потолок времени прогона проверяется между пачками: без таймаута зависший запрос не дал
        бы до этой проверки дойти."""
        run_settings(query_timeout_seconds=0.05)

        async def _hang(*_args: object, **_kwargs: object) -> list[str]:
            await asyncio.sleep(10)
            return []

        monkeypatch.setattr(VersionRegistry, "cohort_page", _hang)

        with pytest.raises(TimeoutError):
            await _run_for(db_session, FakeProducer()).walk_cohort()

    @pytest.mark.usefixtures("no_primary_runtime")
    @pytest.mark.parametrize(
        "error",
        [
            TimeoutError(),
            OperationalError("SELECT 1", {}, Exception("gone")),
            InterfaceError("SELECT 1", {}, Exception("gone")),
        ],
        ids=["timeout", "operational-error", "interface-error"],
    )
    async def test_failed_registry_query_ends_the_run_as_not_run(
        self, error: Exception, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
    ) -> None:
        async def _fail(_version: str) -> int:
            raise error

        monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: _VERSION)
        monkeypatch.setattr(bulk_recalc, "_run", _fail)

        assert await bulk_recalc._main() == bulk_recalc._EXIT_NOT_RUN
        message = f"{bulk_recalc._NAME}: registry query failed or timed out"
        context = captured_app_logs.context_of(message)
        assert context["version"] == _VERSION
        record = next(record for record in captured_app_logs.records if record.getMessage() == message)
        assert record.levelname == "ERROR"
        assert record.exc_info is not None

    @pytest.mark.usefixtures("no_primary_runtime")
    @pytest.mark.parametrize(
        ("error", "expected_message", "expected_exit"),
        [
            (TimeoutError(), "registry query failed or timed out", bulk_recalc._EXIT_NOT_RUN),
            (OperationalError("SELECT 1", {}, Exception("gone")), "registry query failed or timed out", 1),
            (InterfaceError("SELECT 1", {}, Exception("gone")), "registry query failed or timed out", 1),
            (ProgrammingError("SELECT 1", {}, Exception("bad schema")), "run failed unexpectedly", None),
        ],
        ids=["timeout", "connection-lost", "interface-lost", "bad-schema"],
    )
    async def test_registry_failure_after_start_closes_the_session_and_preserves_cohort(
        self,
        error: Exception,
        expected_message: str,
        expected_exit: int | None,
        db_session: AsyncSession,
        seed_cohort,
        run_settings,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        run_settings()
        patients = await seed_cohort(3)
        original_cohort_page = VersionRegistry.cohort_page

        async def _fail(self: VersionRegistry, *_args: object, **_kwargs: object) -> list[str]:
            await self._session.execute(sa.text("SELECT 1"))
            raise error

        class TrackingSession(AsyncSession):
            closed_by_context = False

            async def close(self) -> None:
                await super().close()
                self.closed_by_context = True

        sessions: list[TrackingSession] = []

        def _session_factory() -> TrackingSession:
            session = TrackingSession(db_session.bind, join_transaction_mode="create_savepoint")
            sessions.append(session)
            return session

        monkeypatch.setattr(VersionRegistry, "cohort_page", _fail)
        monkeypatch.setattr(
            bulk_recalc.BulkRecalcRun, "probe_rollout", AsyncMock(return_value=bulk_recalc.RolloutProbe.COMPLETE)
        )
        monkeypatch.setattr(
            bulk_recalc, "get_primary_runtime", lambda: SimpleNamespace(session_factory=_session_factory)
        )
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", FakeProducer)
        monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: _VERSION)
        monkeypatch.setattr(bulk_recalc, "_run", bulk_recalc._publish_cohort)

        if expected_exit is None:
            with pytest.raises(type(error)):
                await bulk_recalc._main()
        else:
            assert await bulk_recalc._main() == expected_exit
        assert len(sessions) == 1 and sessions[0].closed_by_context
        assert not sessions[0].in_transaction()
        registry = VersionRegistry(db_session)
        assert set(patients).issubset(set(await original_cohort_page(registry, _VERSION, after=None, limit=100)))
        message = f"{bulk_recalc._NAME}: {expected_message}"
        record = next(record for record in captured_app_logs.records if record.getMessage() == message)
        assert record.levelname == "ERROR" and record.exc_info is not None

    @pytest.mark.usefixtures("no_primary_runtime")
    async def test_permanent_registry_error_is_not_reported_as_a_timeout(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Ошибка в самом запросе повторным запуском не лечится: она падает своим исключением, а не
        уходит в журнал под видом зависшего или оборванного обращения к реестру."""

        async def _fail(_version: str) -> int:
            raise ProgrammingError("SELECT 1", {}, Exception("column does not exist"))

        monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: _VERSION)
        monkeypatch.setattr(bulk_recalc, "_run", _fail)

        with pytest.raises(ProgrammingError):
            await bulk_recalc._main()


class TestRolloutCheck:
    async def test_canary_is_published_as_background_commands(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Пересчёты проверочного батча — работа прогона, а не пользователя: в метриках воркера они
        обязаны идти рядами `source="background"` и не разбавлять пользовательский SLI."""
        run_settings()
        await _cohort(factory, db_session, 2)
        producer = FakeProducer()

        await _run_for(db_session, producer).probe_rollout()

        assert producer.messages
        assert all(value["background"] is True for _, value in producer.messages)

    async def test_canary_recalculated_by_the_current_version_means_the_rollout_is_complete(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        run_settings()
        await _cohort(factory, db_session, 2)
        producer = WorkerLikeProducer(db_session, _VERSION)

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.COMPLETE

    async def test_canary_recalculated_by_the_previous_version_means_the_rollout_is_incomplete(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Воркер прошлой версии тоже штампует реестр — своей версией, но со свежим
        `calculated_at`. По этому сдвигу незавершённый раскат виден явно."""
        run_settings()
        await _cohort(factory, db_session, 2)
        producer = WorkerLikeProducer(db_session, "previous")

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.INCOMPLETE

    async def test_one_updated_replica_does_not_pass_the_probe(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Выход по первому штампу текущей версии пропустил бы раскат, в котором обновлена только
        одна реплика из нескольких."""
        run_settings(canary_size=1000)
        stale, *_ = await _cohort(factory, db_session, 3)
        producer = WorkerLikeProducer(db_session, _VERSION, per_patient={stale: "previous"})

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.INCOMPLETE

    async def test_persistently_failing_patient_does_not_block_the_probe(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Сбойный пациент из когорты не выходит; проверка раската на нём застревать не должна."""
        run_settings(canary_size=1000)
        failing, *_ = await _cohort(factory, db_session, 3)
        producer = WorkerLikeProducer(db_session, _VERSION, per_patient={failing: None})

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.COMPLETE

    async def test_canary_nobody_recalculated_is_reported_as_such(
        self, db_session: AsyncSession, factory: Factory, run_settings
    ) -> None:
        """Ни одного штампа — это не «раскат не завершён»: о версии воркеров батч ничего не сказал."""
        run_settings()
        await _cohort(factory, db_session, 2)
        producer = FakeProducer()

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.NOT_RECALCULATED

    async def test_empty_cohort_needs_no_canary(self, db_session: AsyncSession, factory: Factory, run_settings) -> None:
        run_settings()
        await _cohort(factory, db_session, 1, version=_VERSION)
        producer = FakeProducer()

        assert await _run_for(db_session, producer).probe_rollout() is bulk_recalc.RolloutProbe.COMPLETE


class TestRunObservability:
    async def test_cohort_size_is_measured_in_and_out(
        self,
        db_session: AsyncSession,
        factory: Factory,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        run_settings()
        await _cohort(factory, db_session, 4)
        # Раскат завершён: за продюсером стоит воркер текущей версии.
        producer = WorkerLikeProducer(db_session, _VERSION)
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)

        assert await bulk_recalc._publish_cohort(_VERSION) == bulk_recalc._EXIT_OK

        context = captured_app_logs.context_of(f"{bulk_recalc._NAME}: complete")
        # Вход замеряется после проверочного батча — иначе когорта уменьшалась бы всегда, просто
        # за счёт него, и «прогон ничего не добился» не сработало бы никогда.
        assert int(context["cohort_size_in"]) >= 1  # ty: ignore[invalid-argument-type]
        assert int(context["cohort_size_out"]) >= 0  # ty: ignore[invalid-argument-type]
        assert int(context["published"]) >= 1  # ty: ignore[invalid-argument-type]
        assert context["version"] == _VERSION
        assert context["cohort_size_at_start"] == 4
        assert context["canary_published"] == settings.bulk_recalc.canary_size

    async def test_cohort_drained_by_the_canary_is_visible_in_the_summary(
        self,
        db_session: AsyncSession,
        factory: Factory,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        """Когорту не больше `canary_size` проверочный батч забирает целиком, и обходу публиковать
        нечего. Итоговая запись обязана показать, что работа всё же была, а не одни нули."""
        run_settings(canary_size=10)
        await _cohort(factory, db_session, 4)
        producer = WorkerLikeProducer(db_session, _VERSION)
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)

        assert await bulk_recalc._publish_cohort(_VERSION) == bulk_recalc._EXIT_OK

        context = captured_app_logs.context_of(f"{bulk_recalc._NAME}: complete")
        assert context["cohort_size_at_start"] == 4
        assert context["canary_published"] == 4
        assert context["published"] == 0
        assert context["cohort_size_in"] == 0
        assert context["cohort_size_out"] == 0

    async def test_run_that_changed_nothing_raises_an_alert(
        self,
        db_session: AsyncSession,
        factory: Factory,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        """Остаток не уменьшился — грубый запасной признак: авторитетны счётчики допуска
        на стороне воркера, но молчать о таком прогоне нельзя."""
        run_settings()
        await _cohort(factory, db_session, 4)
        # Раскат завершён (проверочный батч штампуется), но дальше фоновые команды никто не считает:
        # так выглядит голодание фона — когорта не тает, и молчать об этом нельзя.
        producer = WorkerLikeProducer(db_session, _VERSION, admitted=settings.bulk_recalc.canary_size)
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)

        assert await bulk_recalc._publish_cohort(_VERSION) == bulk_recalc._EXIT_OK

        message = f"{bulk_recalc._NAME}: cohort did not shrink"
        record = next(record for record in captured_app_logs.records if record.getMessage() == message)
        assert record.levelname == "ALERT"
        complete = captured_app_logs.context_of(f"{bulk_recalc._NAME}: complete")
        assert isinstance(complete["cohort_size_in"], int)
        assert isinstance(complete["cohort_size_out"], int)
        assert complete["cohort_size_out"] >= complete["cohort_size_in"]

    async def test_empty_cohort_ends_the_run_successfully(
        self,
        db_session: AsyncSession,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        run_settings()
        producer = FakeProducer()
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)
        version = unique_id("nobody-has-this")

        assert await bulk_recalc._publish_cohort(version) == bulk_recalc._EXIT_OK

        assert producer.messages == []

    async def test_incomplete_rollout_ends_the_run_as_not_run(
        self,
        db_session: AsyncSession,
        factory: Factory,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        run_settings()
        patients = await _cohort(factory, db_session, 3)
        producer = WorkerLikeProducer(db_session, "previous")
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)

        assert await bulk_recalc._publish_cohort(_VERSION) == bulk_recalc._EXIT_NOT_RUN

        message = f"{bulk_recalc._NAME}: rollout is incomplete, the run is aborted"
        record = next(record for record in captured_app_logs.records if record.getMessage() == message)
        assert record.levelname == "ALERT"
        assert len(producer.messages) == settings.bulk_recalc.canary_size
        assert f"{bulk_recalc._NAME}: batch published" not in captured_app_logs.messages()
        assert set(patients).issubset(
            set(await VersionRegistry(db_session).cohort_page(_VERSION, after=None, limit=100))
        )

    async def test_unrecalculated_canary_ends_the_run_with_its_own_alert(
        self,
        db_session: AsyncSession,
        factory: Factory,
        run_settings,
        patched_session,
        monkeypatch: pytest.MonkeyPatch,
        captured_app_logs: LogSink,
    ) -> None:
        """Диагноз «раскат не завершён» здесь был бы ложным: когорта из одних сбойных пациентов
        выглядит так же, как стоящие воркеры, и ни то, ни другое не про версию."""
        run_settings()
        patients = await _cohort(factory, db_session, 3)
        producer = FakeProducer()
        monkeypatch.setattr(bulk_recalc, "get_kafka_producer", lambda: producer)

        assert await bulk_recalc._publish_cohort(_VERSION) == bulk_recalc._EXIT_NOT_RUN

        messages = captured_app_logs.messages()
        assert f"{bulk_recalc._NAME}: no canary patient was recalculated, the run is aborted" in messages
        assert f"{bulk_recalc._NAME}: rollout is incomplete, the run is aborted" not in messages
        assert f"{bulk_recalc._NAME}: batch published" not in messages
        assert len(producer.messages) == settings.bulk_recalc.canary_size
        assert set(patients).issubset(
            set(await VersionRegistry(db_session).cohort_page(_VERSION, after=None, limit=100))
        )
        context = captured_app_logs.context_of(
            f"{bulk_recalc._NAME}: no canary patient was recalculated, the run is aborted"
        )
        assert context["version"] == _VERSION
        cohort_size = context["cohort_size"]
        assert isinstance(cohort_size, int) and cohort_size >= 2
        record = next(
            record
            for record in captured_app_logs.records
            if record.getMessage() == f"{bulk_recalc._NAME}: no canary patient was recalculated, the run is aborted"
        )
        assert record.levelname == "ALERT"


class TestAbnormalEnd:
    """Прогон, оборванный не штатным исходом, обязан оставить ERROR в журнале: без него в журнале
    остаются только `starting` и последний `batch published`, и оборванный прогон не отличить
    от идущего."""

    @pytest.mark.usefixtures("no_primary_runtime")
    @pytest.mark.parametrize("signum", [signal.SIGTERM, signal.SIGINT])
    async def test_signal_ends_the_run_with_an_error_record(
        self, signum: signal.Signals, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
    ) -> None:
        started = asyncio.Event()

        async def _hang(_version: str) -> int:
            started.set()
            await asyncio.Event().wait()
            return bulk_recalc._EXIT_OK

        async def _interrupt() -> None:
            await started.wait()
            os.kill(os.getpid(), signum)

        monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: _VERSION)
        monkeypatch.setattr(bulk_recalc, "_run", _hang)

        interrupter = asyncio.create_task(_interrupt())
        exit_code = await asyncio.wait_for(bulk_recalc._main(), timeout=5)
        await interrupter

        assert exit_code == 128 + signum
        message = f"{bulk_recalc._NAME}: interrupted by signal, the run is incomplete"
        assert captured_app_logs.context_of(message) == {"signal": signum.name, "version": _VERSION}
        record = next(r for r in captured_app_logs.records if r.getMessage() == message)
        assert record.levelname == "ERROR"

    @pytest.mark.usefixtures("no_primary_runtime")
    async def test_unexpected_error_is_logged_and_propagated(
        self, monkeypatch: pytest.MonkeyPatch, captured_app_logs: LogSink
    ) -> None:
        """Непредвиденная ошибка не маскируется под штатный исход: она уходит наружу своим
        исключением, но сначала — в журнал с трассировкой, иначе в Kibana её не увидеть."""

        async def _fail(_version: str) -> int:
            raise ProgrammingError("SELECT 1", {}, Exception("column does not exist"))

        monkeypatch.setattr(bulk_recalc, "require_calculation_version", lambda: _VERSION)
        monkeypatch.setattr(bulk_recalc, "_run", _fail)

        with pytest.raises(ProgrammingError):
            await bulk_recalc._main()

        message = f"{bulk_recalc._NAME}: run failed unexpectedly"
        record = next(r for r in captured_app_logs.records if r.getMessage() == message)
        assert record.levelname == "ERROR"
        assert record.exc_info is not None
