"""Handler orchestration tests — formula/questionnaire logic is stubbed.

Real instrument codes are only used when make_dummy or is_pregnant flows
must run without patching (because those paths dispatch through _REGISTRY).
All other tests use fake instrument codes that carry only the one param needed,
so InstrumentInput.build always succeeds for that param and skips for everything
else already in the migration-seeded DB.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.exceptions import FormulaCalculationError, QuestionnaireCalculationError
from src.calc.domain.formula import Formula
from src.calc.domain.models import (
    CalculationRequest,
    FormulaResult,
    InstrumentInput,
    InstrumentsCodes,
    QuestionnaireScoreRow,
)
from src.calc.domain.questionnaire import QuestionnaireCalculator
from src.calc.infra.repository import CalcRepository
from src.calc.outcomes import CalcRunResult
from src.config import settings
from src.exceptions import NonRetriableDbError
from src.interpretation.handler import InterpretationHandler
from src.logger import debug_enabled_var
from tests.conftest import LogSink, open_formula_registry
from tests.db_assertions import DbRead
from tests.factories import Factory
from tests.integration.calc.conftest import CalcHandlerFactory, always_applicable, stub_result


def _pcr(patient_id: str, instrument_code: str | None = None) -> CalculationRequest:
    return CalculationRequest(
        patient_id=patient_id,
        instrument_codes=None if instrument_code is None else frozenset({instrument_code}),
    )


# ── Stubs ─────────────────────────────────────────────────────────────────────


def _operational_error() -> OperationalError:
    return OperationalError("stmt", {}, Exception("transient"))


def _integrity_error() -> IntegrityError:
    return IntegrityError("stmt", {}, Exception("constraint"))


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _seed_fake(factory: Factory, instrument_code: str, param_code: str) -> None:
    """Seed a single-param fake instrument (not in migrations).

    Без системы: инструмент нужен только как носитель одного параметра, а строка
    systems_instruments поменяла бы знаменатель гейта опросников.
    """
    await factory.instrument_with_params(instrument_code, required=[param_code], in_system=False)


# ── Happy path ────────────────────────────────────────────────────────────────


class TestHappyPath:
    async def test_upserts_result_for_one_patient_one_instrument(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_HP1", "HP1_P")
        await factory.answer(patient_id=patient_id, parameter_code="HP1_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.result_value(patient_id=patient_id, instrument_code="T_HP1") == pytest.approx(0.0)

    async def test_upserts_results_for_multiple_patients(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_a = await factory.patient()
        patient_b = await factory.patient()
        await _seed_fake(factory, "T_HP2", "HP2_P")
        await factory.answer(patient_id=patient_a, parameter_code="HP2_P", value="a")
        await factory.answer(patient_id=patient_b, parameter_code="HP2_P", value="b")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_a), _pcr(patient_b)])

        assert await db_read.result_value(patient_id=patient_a, instrument_code="T_HP2") == pytest.approx(0.0)
        assert await db_read.result_value(patient_id=patient_b, instrument_code="T_HP2") == pytest.approx(0.0)


# ── Skipping ──────────────────────────────────────────────────────────────────


class TestSkipping:
    async def test_skips_when_patient_has_no_matching_parameter(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_SKP1", "SKP1_P")
        # no patients_parameters row
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_SKP1") == 0

    async def test_skips_when_parameter_value_is_null(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_SKP2", "SKP2_P")
        await factory.answer(patient_id=patient_id, parameter_code="SKP2_P", value=None)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_SKP2") == 0

    async def test_skips_when_parameter_value_is_empty_string(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_SKP3", "SKP3_P")
        await factory.answer(patient_id=patient_id, parameter_code="SKP3_P", value="")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_SKP3") == 0

    async def test_pregnant_with_missing_required_params_still_writes_dummy(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # BCRAT is in _REGISTRY; instruments exist from migration; patient has NO params.
        # Handler creates a skeleton InstrumentInput for pregnant patients with missing params
        # and calls make_dummy, which must write a not_required row.
        patient_id = await factory.patient(is_pregnant=True)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.BCRAT)])

        row = await db_read.result_row(patient_id=patient_id, instrument_code=InstrumentsCodes.BCRAT)
        assert row is not None
        assert row.applicability is False
        assert row.interpretation_status == "not_required"


# ── Instrument code filter ────────────────────────────────────────────────────


class TestInstrumentCodeFilter:
    async def test_filter_runs_only_specified_instrument(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_FLT_A", "FLT_A_P")
        await _seed_fake(factory, "T_FLT_B", "FLT_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="FLT_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="FLT_B_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, "T_FLT_A")])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_FLT_A") == 1
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_FLT_B") == 0

    async def test_filter_multi_code_same_patient_runs_both(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_MC_A", "MC_A_P")
        await _seed_fake(factory, "T_MC_B", "MC_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="MC_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="MC_B_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, "T_MC_A"), _pcr(patient_id, "T_MC_B")])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_MC_A") == 1
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_MC_B") == 1

    async def test_duplicate_patient_ids_are_processed_once(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_DUP", "DUP_P")
        await factory.answer(patient_id=patient_id, parameter_code="DUP_P", value="v")
        await db_session.commit()

        real_upsert = CalcRepository.upsert_results_batch
        upserted = 0

        async def counting(self, results):
            nonlocal upserted
            upserted += sum(1 for r in results if r.instrument_code == "T_DUP")
            return await real_upsert(self, results)

        with (
            patch.object(CalcRepository, "upsert_results_batch", counting),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id), _pcr(patient_id)])

        assert upserted == 1


# ── Isolation ─────────────────────────────────────────────────────────────────


class TestIsolation:
    async def test_patient_with_no_applicable_instruments_does_not_block_others(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_no_params = await factory.patient()
        patient_with_params = await factory.patient()
        await _seed_fake(factory, "T_ISO", "ISO_P")
        await factory.answer(patient_id=patient_with_params, parameter_code="ISO_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_no_params), _pcr(patient_with_params)])

        assert await db_read.count_results(patient_id=patient_no_params, instrument_code="T_ISO") == 0
        assert await db_read.result_value(patient_id=patient_with_params, instrument_code="T_ISO") == pytest.approx(0.0)


# ── Pregnancy ─────────────────────────────────────────────────────────────────


class TestPregnancy:
    async def test_pregnant_patient_gets_dummy_result(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # SCORE2 is in _REGISTRY; instrument exists from migration; no patient params needed.
        patient_id = await factory.patient(is_pregnant=True)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.SCORE2)])

        row = await db_read.result_row(patient_id=patient_id, instrument_code=InstrumentsCodes.SCORE2)
        assert row is not None
        assert row.value is None
        assert row.applicability is False
        assert row.interpretation_status == "not_required"

    async def test_non_pregnant_patient_gets_calculated_result(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_id = await factory.patient(is_pregnant=False)
        await _seed_fake(factory, "T_PRG_C", "PRG_C_P")
        await factory.answer(patient_id=patient_id, parameter_code="PRG_C_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.result_value(patient_id=patient_id, instrument_code="T_PRG_C") == pytest.approx(0.0)


# ── Result preservation on skip ──────────────────────────────────────────────


class TestResultPreservation:
    async def test_unpregnant_recalc_preserves_not_required(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        """A not_required written while pregnant must survive once the patient is no longer
        pregnant and the instrument is still uncomputable (missing required params). The row
        will be overwritten by a real result when the patient re-answers."""
        from sqlalchemy import text

        # Pregnant, no params → BCRAT is forced to not_required via make_dummy.
        patient_id = await factory.patient(is_pregnant=True)
        await db_session.commit()
        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.BCRAT)])
        row = await db_read.result_row(patient_id=patient_id, instrument_code=InstrumentsCodes.BCRAT)
        assert row is not None
        assert row.interpretation_status == "not_required"

        # No longer pregnant, still no params → the not_required row is preserved.
        await db_session.execute(
            text("UPDATE patients SET is_pregnant = false WHERE patient_id = :pid"), {"pid": patient_id}
        )
        await db_session.commit()
        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.BCRAT)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.BCRAT) == 1

    async def test_recalc_keeps_result_when_calculation_fails(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        """A transient calc failure (params present, calculate raises) must NOT drop the prior
        result. Clearing is reserved for deterministic skips, never for failures."""
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_KEEP", "KEEP_P")
        await factory.answer(patient_id=patient_id, parameter_code="KEEP_P", value="v")
        await db_session.commit()

        # First run computes a real (stubbed) result.
        handler = await calc_handler()
        await handler.run([_pcr(patient_id, "T_KEEP")])
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_KEEP") == 1

        # Second run: calculate raises (param still present → input is not None → not a skip).
        def _boom(self, input):  # noqa: ARG001
            raise FormulaCalculationError("T_KEEP", ValueError("boom"))

        with (
            patch.object(Formula, "calculate", _boom),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, "T_KEEP")])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_KEEP") == 1

    async def test_skipped_instrument_preserves_existing_result(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        """When an instrument can't compute (required params expired), its previous result
        must be preserved — not deleted — so the risk profile keeps showing the last known risk."""
        from sqlalchemy import text

        patient_id = await factory.patient()
        await _seed_fake(factory, "T_CLR_INT", "CLR_INT_P")
        await factory.link_system_instrument(system_code="ENDO", instrument_code="T_CLR_INT")
        await factory.answer(patient_id=patient_id, parameter_code="CLR_INT_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, "T_CLR_INT")])
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_CLR_INT") == 1

        await db_session.execute(
            text(
                "UPDATE patients_parameters SET expiration_date = now() - interval '1 day'"
                " WHERE patient_id = :pid AND parameter_code = 'CLR_INT_P'"
            ),
            {"pid": patient_id},
        )
        await db_session.commit()

        with patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock) as mock_run:
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, "T_CLR_INT")])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_CLR_INT") == 1
        # Skipped instrument produces no result → its system (ENDO) is not "affected", so interpretation
        # is NOT re-run. The previously computed interpretation is intentionally kept stale (issue #111):
        # re-running would recompute risk from absent data and overwrite the last known profile.
        mock_run.assert_not_awaited()


# ── Per-patient batching ──────────────────────────────────────────────────────


class TestPerPatientBatching:
    async def test_one_batch_call_per_patient(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        # Two instruments for one patient must flush in a single upsert_results_batch call.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_BATCH_A", "BATCH_A_P")
        await _seed_fake(factory, "T_BATCH_B", "BATCH_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="BATCH_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="BATCH_B_P", value="v")
        await db_session.commit()

        real_upsert = CalcRepository.upsert_results_batch
        calls: list[int] = []

        async def recording(self, results):
            calls.append(len(results))
            return await real_upsert(self, results)

        with (
            patch.object(CalcRepository, "upsert_results_batch", recording),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, "T_BATCH_A"), _pcr(patient_id, "T_BATCH_B")])

        assert calls == [2]
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_BATCH_A") == 1
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_BATCH_B") == 1

    async def test_batch_combines_formula_and_questionnaire(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        # A patient's formula result and questionnaire result land in the SAME batch.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_CMB_F", "CMB_F_P")
        await factory.answer(patient_id=patient_id, parameter_code="CMB_F_P", value="v")
        await _seed_questionnaire(factory, InstrumentsCodes.CVD, "CMB_CVD_SYS", [("CMB_CVD_P", "Да", 5.0)])
        await factory.answer(patient_id=patient_id, parameter_code="CMB_CVD_P", value="Да")
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD)
        await db_session.commit()

        real_upsert = CalcRepository.upsert_results_batch
        batches: list[set[str]] = []

        async def recording(self, results):
            batches.append({r.instrument_code for r in results})
            return await real_upsert(self, results)

        with (
            patch.object(CalcRepository, "upsert_results_batch", recording),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, "T_CMB_F"), _pcr(patient_id, InstrumentsCodes.CVD)])

        assert len(batches) == 1
        assert batches[0] == {"T_CMB_F", InstrumentsCodes.CVD}


# ── Formula list result ───────────────────────────────────────────────────────


class TestFormulaListResult:
    async def test_formula_returning_list_writes_multiple_results(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula_list: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_LST", "LST_P")
        await factory.answer(patient_id=patient_id, parameter_code="LST_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_LST") == 2


# ── Error paths ───────────────────────────────────────────────────────────────


class TestErrorPaths:
    async def test_formula_calculate_error_is_caught_skipped_continues(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_CE_A", "CE_A_P")
        await _seed_fake(factory, "T_CE_B", "CE_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="CE_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="CE_B_P", value="v")
        await db_session.commit()

        def selective_calculate(self, input: InstrumentInput) -> FormulaResult:
            if input.instrument_code == "T_CE_A":
                raise FormulaCalculationError(input.instrument_code, ValueError("boom"))
            return stub_result(self, input)

        with (
            open_formula_registry(),
            patch.object(Formula, "is_applicable", always_applicable),
            patch.object(Formula, "calculate", selective_calculate),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_CE_A") == 0
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_CE_B") == 1

    async def test_formula_make_dummy_error_is_caught_skipped_continues(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # Pregnant patient; instruments exist from migration (no seeding needed).
        # Patching make_dummy: BCRAT raises, everything else uses real make_dummy.
        patient_id = await factory.patient(is_pregnant=True)
        await db_session.commit()

        real_make_dummy = Formula.make_dummy

        def selective_make_dummy(self, input: InstrumentInput):
            if input.instrument_code == InstrumentsCodes.BCRAT:
                raise FormulaCalculationError(input.instrument_code, ValueError("boom"))
            return real_make_dummy(self, input)

        with patch.object(Formula, "make_dummy", selective_make_dummy):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, InstrumentsCodes.BCRAT), _pcr(patient_id, InstrumentsCodes.SCORE2)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.BCRAT) == 0
        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.SCORE2) == 1

    async def test_questionnaire_calculation_error_is_caught_skipped_continues(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_questionnaire(factory, InstrumentsCodes.CVD, "QE_CVD_SYS", [("QE_CVD_P", "Да", 5.0)])
        await _seed_questionnaire(factory, InstrumentsCodes.ONCO, "QE_ONCO_SYS", [("QE_ONCO_P", "Да", 3.0)])
        await factory.answer(patient_id=patient_id, parameter_code="QE_CVD_P", value="Да")
        await factory.answer(patient_id=patient_id, parameter_code="QE_ONCO_P", value="Да")
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD)
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.ONCO)
        await db_session.commit()

        real_calculate = QuestionnaireCalculator.calculate

        def selective_error(self, row: QuestionnaireScoreRow) -> FormulaResult:
            if row.instrument_code == InstrumentsCodes.CVD:
                raise QuestionnaireCalculationError(row.instrument_code, ValueError("boom"))
            return real_calculate(self, row)

        with patch.object(QuestionnaireCalculator, "calculate", selective_error):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD) == 0
        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.ONCO) == 1


# ── Questionnaire filter ──────────────────────────────────────────────────────


class TestQuestionnaireFilter:
    async def test_questionnaire_instrument_code_filter_limits_results(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        patient_id = await factory.patient()
        await _seed_questionnaire(factory, InstrumentsCodes.CVD, "QF_CVD_SYS", [("QF_CVD_P", "Да", 5.0)])
        await _seed_questionnaire(factory, InstrumentsCodes.ONCO, "QF_ONCO_SYS", [("QF_ONCO_P", "Да", 3.0)])
        await factory.answer(patient_id=patient_id, parameter_code="QF_CVD_P", value="Да")
        await factory.answer(patient_id=patient_id, parameter_code="QF_ONCO_P", value="Да")
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD)
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.ONCO)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.CVD)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD) == 1
        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.ONCO) == 0


# ── Failure isolation (retry) ─────────────────────────────────────────────────


class TestFailureIsolation:
    async def test_retriable_error_then_success_writes_result(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        # The retry executor reruns the whole per-patient batch; the second attempt commits it.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_RET", "RET_P")
        await factory.answer(patient_id=patient_id, parameter_code="RET_P", value="v")
        await db_session.commit()

        real_upsert = CalcRepository.upsert_results_batch
        attempts = 0

        async def flaky(self, results):
            nonlocal attempts
            attempts += 1
            if attempts == 1:
                raise _operational_error()
            return await real_upsert(self, results)

        with (
            patch.object(CalcRepository, "upsert_results_batch", flaky),
            patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id)])

        assert attempts == 2
        assert await db_read.result_value(patient_id=patient_id, instrument_code="T_RET") == pytest.approx(0.0)

    async def test_retriable_error_exhausted_rolls_back_whole_patient_batch(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        # All-or-nothing per patient: when the batch upsert exhausts retries, NONE of the
        # patient's instruments are written (the accepted per-dispatch isolation trade-off).
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_FAIL_A", "FAIL_A_P")
        await _seed_fake(factory, "T_FAIL_B", "FAIL_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="FAIL_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="FAIL_B_P", value="v")
        await db_session.commit()

        async def always_fail(self, results):
            raise _operational_error()

        with (
            patch.object(CalcRepository, "upsert_results_batch", always_fail),
            patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_FAIL_A") == 0
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_FAIL_B") == 0

    async def test_non_retriable_error_does_not_retry_and_rolls_back_batch(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        # Non-retriable failure: the batch is attempted once (no retry), the whole patient's batch
        # is rolled back, and the error leaves `run` instead of being absorbed as a per-patient
        # miss — a permanent fault (constraint/schema/permission) repeats on every remaining
        # patient, so it must surface with a traceback rather than inflate `failed` silently.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_NR_A", "NR_A_P")
        await _seed_fake(factory, "T_NR_B", "NR_B_P")
        await factory.answer(patient_id=patient_id, parameter_code="NR_A_P", value="v")
        await factory.answer(patient_id=patient_id, parameter_code="NR_B_P", value="v")
        await db_session.commit()

        attempts = 0

        async def always_fail(self, results):
            nonlocal attempts
            attempts += 1
            raise _integrity_error()

        with (
            patch.object(CalcRepository, "upsert_results_batch", always_fail),
            pytest.raises(NonRetriableDbError),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_id)])

        assert attempts == 1
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_NR_A") == 0
        assert await db_read.count_results(patient_id=patient_id, instrument_code="T_NR_B") == 0


class TestRunOutcome:
    """Единый исход различает записанные, пропущенные и упавшие инструменты."""

    async def test_stats_report_failed_batch(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_ST_F", "ST_F_P")
        await factory.answer(patient_id=patient_id, parameter_code="ST_F_P", value="v")
        await db_session.commit()

        async def always_fail(self, results):
            raise _operational_error()

        with (
            patch.object(CalcRepository, "upsert_results_batch", always_fail),
            patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()),
        ):
            handler = await calc_handler()
            outcome = await handler.run([_pcr(patient_id, "T_ST_F")])

        assert outcome.processed_codes == []
        assert outcome.failed > 0
        assert outcome.processed == 0

    async def test_stats_report_written_results(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_ST_OK", "ST_OK_P")
        await factory.answer(patient_id=patient_id, parameter_code="ST_OK_P", value="v")
        await db_session.commit()

        handler = await calc_handler()
        outcome = await handler.run([_pcr(patient_id, "T_ST_OK")])

        assert outcome == CalcRunResult(processed_codes=["T_ST_OK"], processed=1)

    async def test_failure_for_one_patient_does_not_block_next_patient(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        db_read: DbRead,
    ) -> None:
        # Cross-patient isolation: each patient gets its own batch/transaction, so one
        # patient's DB failure must not roll back another patient's results. The failure has to be
        # transient — a permanent one would repeat on every remaining patient, so the run aborts
        # instead of isolating it (see test_non_retriable_error_does_not_retry_and_rolls_back_batch).
        patient_a = await factory.patient()
        patient_b = await factory.patient()
        await _seed_fake(factory, "T_PI", "PI_P")
        await factory.answer(patient_id=patient_a, parameter_code="PI_P", value="v")
        await factory.answer(patient_id=patient_b, parameter_code="PI_P", value="v")
        await db_session.commit()

        real_upsert = CalcRepository.upsert_results_batch
        seen_patients: list[str] = []

        async def selective(self, results):
            patient_ids = {r.patient_id for r in results}
            seen_patients.extend(patient_ids)
            if patient_a in patient_ids:
                raise _operational_error()
            return await real_upsert(self, results)

        with (
            patch.object(CalcRepository, "upsert_results_batch", selective),
            patch("src.infra.db_retry.asyncio.sleep", new=AsyncMock()),
        ):
            handler = await calc_handler()
            await handler.run([_pcr(patient_a), _pcr(patient_b)])

        assert await db_read.count_results(patient_id=patient_a, instrument_code="T_PI") == 0
        assert await db_read.result_value(patient_id=patient_b, instrument_code="T_PI") == pytest.approx(0.0)


# ── Questionnaire eligibility gate (step 3) ───────────────────────────────────


class TestQuestionnaireEligibilityGate:
    async def test_gated_instrument_failing_gate_is_skipped(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # form_gi is gated; the answered param belongs to no question, so every question of the
        # GI system stays unanswered → Y/X = 0 → gate fails
        patient_id = await factory.patient()
        await _seed_questionnaire(
            factory,
            InstrumentsCodes.GI,
            "GATE_GI_SYS",
            [("GATE_GI_N", "Да", 5.0)],
        )
        await factory.answer(patient_id=patient_id, parameter_code="GATE_GI_N", value="Да")
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.GI)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.GI) == 0

    async def test_gated_instrument_passing_gate_is_calculated(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # form_uro is gated; patient answered all general params + 100% of form_uro's real
        # catalog params → Y/X = 1 ≥ 0.5, result row is written (score = 0 since no
        # parameter_scores are seeded; coalesce → 0, still a valid calculation).
        patient_id = await factory.patient()
        await factory.answer_all_general_params(patient_id=patient_id)
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.URO)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.URO)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.URO) == 1

    async def test_non_gated_instrument_ignores_gate(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, factory: Factory, db_read: DbRead
    ) -> None:
        # form_cvd is NOT gated; nothing else answered, still calculates
        patient_id = await factory.patient()
        await _seed_questionnaire(
            factory,
            InstrumentsCodes.CVD,
            "GATE_CVD_SYS",
            [("GATE_CVD_N", "Да", 5.0)],
        )
        await factory.answer(patient_id=patient_id, parameter_code="GATE_CVD_N", value="Да")
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD)
        await db_session.commit()

        handler = await calc_handler()
        await handler.run([_pcr(patient_id, InstrumentsCodes.CVD)])

        assert await db_read.count_results(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD) == 1


# ── Kafka publish ─────────────────────────────────────────────────────────────


class TestKafkaPublish:
    async def test_publish_calls_send_background_not_send(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        # Ensures _publish uses fire-and-forget send_background, not the awaitable send,
        # so Kafka I/O never blocks the calculation loop.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_KFK", "KFK_P")
        await factory.answer(patient_id=patient_id, parameter_code="KFK_P", value="v")
        await db_session.commit()

        mock_producer = MagicMock()
        mock_producer.send_background = MagicMock()

        handler = await calc_handler(kafka_producer=mock_producer)
        await handler.run([_pcr(patient_id, "T_KFK")])

        mock_producer.send_background.assert_called_once()
        call_kwargs = mock_producer.send_background.call_args.kwargs
        assert call_kwargs["key"] == patient_id
        assert call_kwargs["topic"] == settings.kafka.topics.risk_calculation
        assert call_kwargs["value"]["clientId"] == patient_id
        assert call_kwargs["value"]["messageType"] == "calculation"

    async def test_publishes_interpretation_message_after_run_for(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        # §5.3: после интерпретации публикуется отдельное сообщение с messageType=interpretation
        # и systemCodes — кодами систем, по которым интерпретация реально посчитана.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_KFK_I", "KFK_I_P")
        await factory.link_system_instrument(system_code="ENDO", instrument_code="T_KFK_I")
        await factory.answer(patient_id=patient_id, parameter_code="KFK_I_P", value="v")
        await db_session.commit()

        mock_producer = MagicMock()
        mock_producer.send_background = MagicMock()

        with (
            patch.object(
                InterpretationHandler,
                "run_for",
                new_callable=AsyncMock,
                return_value={"ENDO": object()},
            ),
        ):
            handler = await calc_handler(kafka_producer=mock_producer)
            await handler.run([_pcr(patient_id, "T_KFK_I")])

        interp_calls = [
            c
            for c in mock_producer.send_background.call_args_list
            if c.kwargs["value"]["messageType"] == "interpretation"
        ]
        assert len(interp_calls) == 1
        call_kwargs = interp_calls[0].kwargs
        assert call_kwargs["key"] == patient_id
        assert call_kwargs["topic"] == settings.kafka.topics.risk_calculation
        assert call_kwargs["value"]["clientId"] == patient_id
        assert call_kwargs["value"]["systemCodes"] == ["ENDO"]

    async def test_no_interpretation_publish_when_run_for_returns_empty(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        # Защита от пустого systemCodes: контракт risk-calculation требует ≥1 элемент.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_KFK_E", "KFK_E_P")
        await factory.link_system_instrument(system_code="ENDO", instrument_code="T_KFK_E")
        await factory.answer(patient_id=patient_id, parameter_code="KFK_E_P", value="v")
        await db_session.commit()

        mock_producer = MagicMock()
        mock_producer.send_background = MagicMock()

        with (
            patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock, return_value={}),
        ):
            handler = await calc_handler(kafka_producer=mock_producer)
            await handler.run([_pcr(patient_id, "T_KFK_E")])

        interp_calls = [
            c
            for c in mock_producer.send_background.call_args_list
            if c.kwargs["value"]["messageType"] == "interpretation"
        ]
        assert interp_calls == []

    async def test_no_interpretation_publish_when_run_for_raises(
        self, db_session: AsyncSession, calc_handler: CalcHandlerFactory, stub_formula: None, factory: Factory
    ) -> None:
        # Падение интерпретации не должно приводить к Kafka-сообщению о ней.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_KFK_F", "KFK_F_P")
        await factory.link_system_instrument(system_code="ENDO", instrument_code="T_KFK_F")
        await factory.answer(patient_id=patient_id, parameter_code="KFK_F_P", value="v")
        await db_session.commit()

        mock_producer = MagicMock()
        mock_producer.send_background = MagicMock()

        with (
            patch.object(
                InterpretationHandler,
                "run_for",
                new_callable=AsyncMock,
                side_effect=RuntimeError("boom"),
            ),
        ):
            handler = await calc_handler(kafka_producer=mock_producer)
            await handler.run([_pcr(patient_id, "T_KFK_F")])

        interp_calls = [
            c
            for c in mock_producer.send_background.call_args_list
            if c.kwargs["value"]["messageType"] == "interpretation"
        ]
        assert interp_calls == []


# ── Debug logging e2e (regression guard for MonologLogger) ─────────────────────


def _never_applicable(self, input: InstrumentInput) -> bool:  # noqa: ARG001
    return False


class TestDebugLoggingE2E:
    """End-to-end logging contract through the real CalcHandler + MonologLogger pipeline.

    Pins the observable behaviour under both X-Enable-Debug states so a future change to
    MonologFilter / FingersCrossedHandler (or the per-call debug guards in the handler)
    can't silently drop diagnostics or leak DEBUG into prod:

      * NOTICE run milestones (calc.run: started/complete) are emitted ALWAYS.
      * DEBUG diagnostics surface ONLY when debug is enabled (X-Enable-Debug).
    """

    @pytest.mark.parametrize("debug_on", [True, False])
    async def test_formula_attempt_debug_follows_debug_flag(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        stub_formula: None,
        factory: Factory,
        captured_app_logs: LogSink,
        debug_on: bool,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_DBG_ATT", "DBG_ATT_P")
        await factory.answer(patient_id=patient_id, parameter_code="DBG_ATT_P", value="v")
        await db_session.commit()

        tok = debug_enabled_var.set(debug_on)
        try:
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, "T_DBG_ATT")])
        finally:
            debug_enabled_var.reset(tok)

        messages = captured_app_logs.messages()
        # NOTICE milestones are emitted regardless of debug state.
        assert "calc.run: started" in messages
        assert "calc.run: complete" in messages

        if debug_on:
            assert "calc.formula: attempt" in messages
            ctx = captured_app_logs.context_of("calc.formula: attempt")
            assert ctx["instrument_code"] == "T_DBG_ATT"
            assert ctx["patient_id"] == patient_id
        else:
            assert "calc.formula: attempt" not in messages

    @pytest.mark.parametrize("debug_on", [True, False])
    async def test_formula_inapplicable_debug_follows_debug_flag(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        factory: Factory,
        captured_app_logs: LogSink,
        debug_on: bool,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_DBG_INA", "DBG_INA_P")
        await factory.answer(patient_id=patient_id, parameter_code="DBG_INA_P", value="v")
        await db_session.commit()

        tok = debug_enabled_var.set(debug_on)
        try:
            with (
                open_formula_registry(),
                patch.object(Formula, "is_applicable", _never_applicable),
                patch.object(Formula, "make_dummy", stub_result),
            ):
                handler = await calc_handler()
                await handler.run([_pcr(patient_id, "T_DBG_INA")])
        finally:
            debug_enabled_var.reset(tok)

        messages = captured_app_logs.messages()
        if debug_on:
            assert "calc.formula: inapplicable" in messages
            # reason is computed only for the debug log — it must still be present in context.
            ctx = captured_app_logs.context_of("calc.formula: inapplicable")
            assert ctx["instrument_code"] == "T_DBG_INA"
            assert ctx["reason"]  # non-empty reason string
        else:
            assert "calc.formula: inapplicable" not in messages

    @pytest.mark.parametrize("debug_on", [True, False])
    async def test_missing_required_param_debug_follows_debug_flag(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        factory: Factory,
        captured_app_logs: LogSink,
        debug_on: bool,
    ) -> None:
        # Patient has no value for the required param → InstrumentInput.build returns a rejection
        # and emits the (guarded) "calc.input: missing required parameters" debug from models.py.
        patient_id = await factory.patient()
        await _seed_fake(factory, "T_DBG_MIS", "DBG_MIS_P")
        # deliberately no insert_patient_param
        await db_session.commit()

        tok = debug_enabled_var.set(debug_on)
        try:
            with open_formula_registry():
                handler = await calc_handler()
                await handler.run([_pcr(patient_id, "T_DBG_MIS")])
        finally:
            debug_enabled_var.reset(tok)

        messages = captured_app_logs.messages()
        if debug_on:
            assert "calc.input: missing required parameters" in messages
            ctx = captured_app_logs.context_of("calc.input: missing required parameters")
            assert ctx["instrument_code"] == "T_DBG_MIS"
            # Список целиком, а не первый недостающий код: он же уходит в причину отказа.
            assert ctx["parameter_codes"] == ["DBG_MIS_P"]
        else:
            assert "calc.input: missing required parameters" not in messages

    @pytest.mark.parametrize("debug_on", [True, False])
    async def test_questionnaire_attempt_debug_follows_debug_flag(
        self,
        db_session: AsyncSession,
        calc_handler: CalcHandlerFactory,
        factory: Factory,
        captured_app_logs: LogSink,
        debug_on: bool,
    ) -> None:
        patient_id = await factory.patient()
        await _seed_questionnaire(factory, InstrumentsCodes.CVD, "DBG_Q_SYS", [("DBG_Q_P", "Да", 5.0)])
        await factory.answer(patient_id=patient_id, parameter_code="DBG_Q_P", value="Да")
        await factory.answer_instrument_params(patient_id=patient_id, instrument_code=InstrumentsCodes.CVD)
        await db_session.commit()

        tok = debug_enabled_var.set(debug_on)
        try:
            handler = await calc_handler()
            await handler.run([_pcr(patient_id, InstrumentsCodes.CVD)])
        finally:
            debug_enabled_var.reset(tok)

        messages = captured_app_logs.messages()
        assert "calc.run: started" in messages
        assert "calc.run: complete" in messages
        if debug_on:
            assert "calc.questionnaire: attempt" in messages
            ctx = captured_app_logs.context_of("calc.questionnaire: attempt")
            assert ctx["instrument_code"] == InstrumentsCodes.CVD
            assert ctx["patient_id"] == patient_id
        else:
            assert "calc.questionnaire: attempt" not in messages


# ── Questionnaire seed helpers ─────────────────────────────────────────────────


async def _seed_questionnaire(
    factory: Factory,
    instrument_code: str,
    system_code: str,
    params: list[tuple[str, str, float]],
) -> None:
    # Migration seeds questionnaire instruments with type "form"; force "questionnaire"
    # so load_questionnaire_scores join condition succeeds.
    await factory.make_questionnaire(instrument_code)
    rang = 1_000_000 + sum(ord(c) * (i + 1) for i, c in enumerate(system_code))
    await factory.system(system_code, description=system_code, rang=rang)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
    for param_code, value, score in params:
        await factory.parameter(param_code)
        await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code)
        await factory.parameter_score(parameter_code=param_code, system_code=system_code, value=value, score=score)
