"""Сбор статусов расчёта на настоящей БД: грань строки, изоляция транзакций, деградация.

Почему тут своя сессия, а не общая фикстура `db_session`: коллектор пишет ОТДЕЛЬНОЙ транзакцией
на СОБСТВЕННОЙ сессии — это и есть проверяемое свойство. Данные, лежащие в незакоммиченной
транзакции чужой сессии, ему не видны (и FK на пациента не сойдётся), поэтому сиды здесь
коммитятся по-настоящему, а за собой тест убирает сам (`committed_session_factory`).
"""

import logging
from collections.abc import AsyncGenerator, Callable, Iterator
from contextlib import contextmanager
from datetime import timedelta
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.calc.domain.formula import Formula
from src.calc.domain.models import (
    CalcReasonCode,
    CalcStatus,
    CalculationRequest,
    FormulaResult,
    InstrumentInput,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from src.calc.handler import CalcHandler
from src.calc.status_collector import CalcStatusCollector
from src.config import settings
from src.constants import ResultInterpretationStatus
from src.exceptions import RetriableDbError
from src.infra.db_retry import TransactionalRetryExecutor
from tests.conftest import PHYSICAL_CONNECT_ARGS, make_calc_catalog, make_interpretation_catalog, open_formula_registry
from tests.factories import Factory

# Единый префикс синтетических кодов: по нему же идёт уборка, чтобы соседние тесты не увидели
# инструментов этого модуля в своём каталоге.
PREFIX = "T_ST_"

# Уборка за тестом: сначала строки пациентов (по списку созданных), затем синтетический
# каталог (по префиксу кодов). Порядок продиктован FK RESTRICT — иначе `patients` не удалить.
_CLEANUP_BY_PATIENT = (
    "DELETE FROM calculation_statuses WHERE patient_id = ANY(:pids)",
    "DELETE FROM results_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM results WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients_parameters_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients_parameters WHERE patient_id = ANY(:pids)",
    "DELETE FROM interpretations WHERE patient_id = ANY(:pids)",
    "DELETE FROM interpretations_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients WHERE patient_id = ANY(:pids)",
)

_CLEANUP_CATALOG = (
    f"DELETE FROM instruments_parameters WHERE instrument_code LIKE '{PREFIX}%'",
    f"DELETE FROM instruments_parameters WHERE parameter_code LIKE '{PREFIX}%'",
    f"DELETE FROM parameters WHERE code LIKE '{PREFIX}%'",
    f"DELETE FROM systems_instruments WHERE instrument_code LIKE '{PREFIX}%'",
    f"DELETE FROM instruments WHERE code LIKE '{PREFIX}%'",
)


@pytest.fixture
def created_patients() -> list[str]:
    return []


@pytest_asyncio.fixture
async def committed_session_factory(
    postgres_url: str, created_patients: list[str]
) -> AsyncGenerator[async_sessionmaker[AsyncSession], None]:
    """Фабрика сессий, которые ДЕЙСТВИТЕЛЬНО коммитят, плюс уборка за тестом.

    Незакоммиченные данные коллектору не видны (у него своя сессия), поэтому изоляция «всё в
    откатываемой транзакции» здесь не работает — за собой убираем явно.
    """
    engine = create_async_engine(postgres_url, connect_args=PHYSICAL_CONNECT_ARGS)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        yield factory
    finally:
        async with factory() as session:
            for statement in _CLEANUP_BY_PATIENT:
                await session.execute(text(statement), {"pids": created_patients})
            for statement in _CLEANUP_CATALOG:
                await session.execute(text(statement))
            await session.commit()
        await engine.dispose()


@pytest_asyncio.fixture
async def session(
    committed_session_factory: async_sessionmaker[AsyncSession],
) -> AsyncGenerator[AsyncSession, None]:
    async with committed_session_factory() as s:
        yield s


@pytest.fixture
def factory(session: AsyncSession) -> Factory:
    """Фабрики поверх коммитящей сессии этого модуля.

    Общая фикстура `factory` привязана к `db_session`, который откатывается и коммитов наружу
    не отдаёт; коллектор статусов ходит своей сессией и незакоммиченного не увидит.
    """
    return Factory(session)


@pytest.fixture
def collection_on(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)


@pytest.fixture
def collection_off(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)


# ── Сиды и утилиты ────────────────────────────────────────────────────────────


async def _insert_patient(factory: Factory, created: list[str]) -> str:
    patient_id = await factory.patient()
    created.append(patient_id)
    return patient_id


async def _answer(factory: Factory, patient_id: str, parameter_code: str, value: str = "1") -> None:
    await factory.answer(patient_id=patient_id, parameter_code=parameter_code, value=value)


async def _statuses(session: AsyncSession, patient_id: str) -> dict[str, dict[str, Any]]:
    result = await session.execute(
        text(
            "SELECT instrument_code, status, reason_code, missing_parameter_codes,"
            " applicable_questions, progressed_questions, date_time"
            " FROM calculation_statuses WHERE patient_id = :pid"
        ),
        {"pid": patient_id},
    )
    return {row.instrument_code: dict(row._mapping) for row in result.all()}


async def _status_row_count(session: AsyncSession, patient_id: str, *, synthetic_only: bool = True) -> int:
    """Число строк статусов пациента. По умолчанию — только по синтетическим инструментам:
    полный пересчёт обходит и все настоящие инструменты сида, и их строки к делу не относятся."""
    clause = f" AND instrument_code LIKE '{PREFIX}%'" if synthetic_only else ""
    result = await session.execute(
        text(f"SELECT COUNT(*) FROM calculation_statuses WHERE patient_id = :pid{clause}"),
        {"pid": patient_id},
    )
    return result.scalar_one()


def _stub_result(input: InstrumentInput, value: float = 1.0) -> FormulaResult:
    return FormulaResult(
        instrument_code=input.instrument_code,
        patient_id=input.patient_id,
        value=value,
        unit=InstrumentsUnits.BCRAT,
        risk_level=InstrumentsRiskLevel.LOW,
        applicability=True,
        interpretation_status=ResultInterpretationStatus.READY,
        expiration_delta=timedelta(days=30),
        indicator=InstrumentsIndicators.BCRAT,
    )


def _two_indicator_results(input: InstrumentInput) -> list[FormulaResult]:
    """Инструмент с двумя показателями — как stai (ситуативная и личная тревожность)."""
    return [
        FormulaResult(
            instrument_code=input.instrument_code,
            patient_id=input.patient_id,
            value=value,
            unit=InstrumentsUnits.SPILLBERGER_HANIN,
            risk_level=InstrumentsRiskLevel.MEDIUM,
            applicability=True,
            interpretation_status=ResultInterpretationStatus.READY,
            expiration_delta=timedelta(days=30),
            indicator=indicator,
        )
        for value, indicator in (
            (35.0, InstrumentsIndicators.SPILLBERGER_HANIN_SITUATION),
            (41.0, InstrumentsIndicators.SPILLBERGER_HANIN_PERSONAL),
        )
    ]


@contextmanager
def _stubbed_formula(calculate: Callable[[InstrumentInput], Any]) -> Iterator[None]:
    """Патчит Formula так, чтобы синтетический код считался (в _REGISTRY его нет).

    Вместе с формулой открывается и реестр формул: каталог маршрутизирует инструмент типа `calc`
    в формульный pipeline только по зарегистрированному коду, а синтетического кода там нет.
    """
    with (
        open_formula_registry(),
        patch.object(Formula, "is_applicable", lambda self, input: True),
        patch.object(Formula, "calculate", lambda self, input: calculate(input)),
    ):
        yield


async def _run(
    session: AsyncSession,
    session_factory: async_sessionmaker[AsyncSession],
    requests: list[CalculationRequest],
    *,
    kafka: MagicMock | None = None,
) -> Any:
    handler = CalcHandler(
        session,
        await make_calc_catalog(session),
        kafka_producer=kafka,
        interpretation_catalog=await make_interpretation_catalog(session),
        status_collector=CalcStatusCollector(session_factory=session_factory),
    )
    return await handler.run(requests)


# ── Тесты ─────────────────────────────────────────────────────────────────────


class TestGrainAndUpsert:
    async def test_two_indicator_instrument_yields_exactly_one_row(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        code = f"{PREFIX}TWO"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()

        with _stubbed_formula(_two_indicator_results):
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])

        rows = await _statuses(session, patient_id)
        assert rows[code]["status"] == CalcStatus.CALCULATED.value
        assert rows[code]["reason_code"] is None
        assert await _status_row_count(session, patient_id) == 1

    async def test_recalculation_updates_the_row_without_duplicating_it(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        code = f"{PREFIX}UPS"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await session.commit()

        # Первый прогон: параметра нет → недостаточно данных. Реестр формул открыт и здесь:
        # без него синтетический код не дошёл бы до расчёта вовсе.
        with open_formula_registry():
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])
        before = (await _statuses(session, patient_id))[code]
        assert before["reason_code"] == CalcReasonCode.MISSING_REQUIRED_PARAMETERS.value

        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()
        with _stubbed_formula(_stub_result):
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])

        after = (await _statuses(session, patient_id))[code]
        assert await _status_row_count(session, patient_id) == 1, "пересчёт обязан обновлять строку, а не дублировать"
        assert after["status"] == CalcStatus.CALCULATED.value
        assert after["reason_code"] is None
        assert after["date_time"] > before["date_time"]


class TestPartialRecalculation:
    async def test_only_the_requested_instrument_is_touched(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        kept, requested = f"{PREFIX}KEEP", f"{PREFIX}REQ"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(kept, required=[f"{PREFIX}PK"], in_system=False)
        await factory.instrument_with_params(requested, required=[f"{PREFIX}PR"], in_system=False)
        await session.commit()

        await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])
        before = await _statuses(session, patient_id)
        assert {kept, requested} <= set(before)

        await _run(
            session,
            committed_session_factory,
            [CalculationRequest(patient_id=patient_id, instrument_codes=frozenset({requested}))],
        )
        after = await _statuses(session, patient_id)
        assert after[kept]["date_time"] == before[kept]["date_time"], "строка не запрошенного инструмента не трогается"
        assert after[requested]["date_time"] > before[requested]["date_time"]


class TestTransactionIsolation:
    async def test_status_write_failure_leaves_results_committed(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        code = f"{PREFIX}ISO"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()

        # Ломаем ИМЕННО запись статусов: снимаем грань, на которой строится upsert — он уходит в
        # БД и падает, результаты к этому моменту уже закоммичены. Таблица теперь общая на всю
        # тестовую сессию (создаётся один раз миграцией), поэтому constraint возвращаем в finally
        # — иначе следующий тест унаследует поломанную схему.
        await session.execute(
            text(
                "ALTER TABLE risk_calculation.calculation_statuses DROP CONSTRAINT IF EXISTS "
                "uq_calculation_statuses_patient_id_instrument_code"
            )
        )
        await session.commit()
        try:
            with caplog.at_level(logging.ERROR, logger="app"), _stubbed_formula(_stub_result):
                processed = await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])
        finally:
            await session.execute(
                text(
                    "ALTER TABLE risk_calculation.calculation_statuses ADD CONSTRAINT "
                    "uq_calculation_statuses_patient_id_instrument_code UNIQUE (patient_id, instrument_code)"
                )
            )
            await session.commit()

        assert processed.processed_codes == [code], "пересчёт обязан завершиться штатно"
        result = await session.execute(
            text("SELECT COUNT(*) FROM results WHERE patient_id = :pid AND instrument_code = :code"),
            {"pid": patient_id, "code": code},
        )
        assert result.scalar_one() == 1, "результаты остаются закоммиченными"
        assert [r for r in caplog.records if r.levelno >= logging.ERROR], "сбой записи не проглатывается"

    async def test_rolled_back_result_batch_writes_no_statuses(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        code = f"{PREFIX}RB"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()

        async def _fail(self, operation, *args, **kwargs):  # noqa: ANN001, ARG001
            raise RetriableDbError("upsert failed", attempts=3, cause=Exception("db is down"))

        with _stubbed_formula(_stub_result), patch.object(TransactionalRetryExecutor, "run", _fail):
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])

        assert await _status_row_count(session, patient_id, synthetic_only=False) == 0, (
            "статусы описывали бы расчёт, которого нет в results"
        )

    async def test_one_patients_rollback_does_not_affect_another_in_the_same_batch(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        code = f"{PREFIX}ISO2"
        failing_id = await _insert_patient(factory, created_patients)
        ok_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, failing_id, f"{PREFIX}P")
        await _answer(factory, ok_id, f"{PREFIX}P")
        await session.commit()

        real_run = TransactionalRetryExecutor.run

        async def _fail_for_one_patient(
            self: TransactionalRetryExecutor, operation: Any, results: Any, *args: Any, **kwargs: Any
        ) -> Any:
            if any(r.patient_id == failing_id for r in results):
                raise RetriableDbError("upsert failed", attempts=3, cause=Exception("db is down"))
            return await real_run(self, operation, results, *args, **kwargs)

        with _stubbed_formula(_stub_result), patch.object(TransactionalRetryExecutor, "run", _fail_for_one_patient):
            processed = await _run(
                session,
                committed_session_factory,
                [CalculationRequest(patient_id=failing_id), CalculationRequest(patient_id=ok_id)],
            )

        assert processed.processed_codes == [code], "второй пациент обязан посчитаться, несмотря на откат первого"
        assert await _status_row_count(session, failing_id, synthetic_only=False) == 0, (
            "статусы упавшего пациента описывали бы расчёт, которого нет в results"
        )
        ok_row = (await _statuses(session, ok_id))[code]
        assert ok_row["status"] == CalcStatus.CALCULATED.value, "откат одного пациента не должен трогать другого"


class TestFlagEquivalence:
    """Состояние флага не наблюдается ни в results, ни в Kafka, ни в счётчиках."""

    @staticmethod
    async def _seed(session: AsyncSession, factory: Factory, created_patients: list[str]) -> tuple[str, list[str]]:
        patient_id = await _insert_patient(factory, created_patients)
        calculated, skipped = f"{PREFIX}EQ_OK", f"{PREFIX}EQ_SKIP"
        await factory.instrument_with_params(calculated, required=[f"{PREFIX}PE"], in_system=False)
        await factory.instrument_with_params(skipped, required=[f"{PREFIX}PS"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}PE")
        await session.commit()
        return patient_id, [calculated, skipped]

    @staticmethod
    async def _snapshot(session: AsyncSession, patient_id: str) -> list[tuple[Any, ...]]:
        result = await session.execute(
            text(
                "SELECT instrument_code, indicator, value, risk_level, applicability, interpretation_status"
                " FROM results WHERE patient_id = :pid ORDER BY instrument_code, indicator"
            ),
            {"pid": patient_id},
        )
        return [tuple(row) for row in result.all()]

    async def test_results_kafka_and_stats_are_identical(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        patient_id, (calculated, _skipped) = await self._seed(session, factory, created_patients)

        observed = []
        for enabled in (False, True):
            monkeypatch.setattr(settings, "calc_status_collection_enabled", enabled)
            kafka = MagicMock()
            with caplog.at_level(logging.INFO, logger="app"), _stubbed_formula(_stub_result):
                caplog.clear()
                processed = await _run(
                    session, committed_session_factory, [CalculationRequest(patient_id=patient_id)], kafka=kafka
                )
                # Лог и типизированный исход должны содержать одинаковые счётчики.
                # `log_context` кладёт в запись сам логгер через extra — в стабах LogRecord его нет.
                stats = next(
                    r.__dict__["log_context"] for r in caplog.records if r.getMessage() == "calc.run: complete"
                )
            observed.append(
                (
                    processed,
                    await self._snapshot(session, patient_id),
                    [call.kwargs for call in kafka.send_background.call_args_list],
                    stats,
                )
            )

        off, on = observed
        assert off[0].processed_codes == on[0].processed_codes == [calculated]
        assert off[1] == on[1], "строки results обязаны совпасть при обоих состояниях флага"
        assert off[2] == on[2], "сообщения risk_calculation обязаны совпасть"
        assert off[3] == on[3], f"счётчики CalcRunResult разошлись: {off[3]} != {on[3]}"

        # И только при включённом флаге появляются строки статусов.
        assert await _status_row_count(session, patient_id) == 2, "по обоим синтетическим инструментам"

    async def test_disabled_flag_writes_nothing(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_off: None,
    ) -> None:
        patient_id, _codes = await self._seed(session, factory, created_patients)
        with _stubbed_formula(_stub_result):
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])
        assert await _status_row_count(session, patient_id) == 0


class TestNoPersonalData:
    async def test_saved_rows_carry_neither_answers_nor_exception_text(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        code = f"{PREFIX}PII"
        secret_answer = "глюкоза-14.7-Иванов"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P", value=secret_answer)
        await session.commit()

        def _boom(input: InstrumentInput) -> FormulaResult:
            from src.calc.domain.exceptions import FormulaCalculationError

            raise FormulaCalculationError(input.instrument_code, ValueError(f"bad value {secret_answer}"))

        with _stubbed_formula(_boom):
            await _run(session, committed_session_factory, [CalculationRequest(patient_id=patient_id)])

        row = (await _statuses(session, patient_id))[code]
        assert row["reason_code"] == CalcReasonCode.CALCULATION_ERROR.value
        assert secret_answer not in str(row), "ни значение ответа, ни текст исключения не сохраняются"
        assert row["missing_parameter_codes"] is None


class TestNoCostWhenDisabled:
    """Выключенный сбор не добавляет ни запросов к БД, ни времени в шаг `upsert`."""

    async def test_disabled_collection_never_touches_the_database(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_off: None,
    ) -> None:
        code = f"{PREFIX}NOCOST"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()

        opened: list[object] = []

        def _factory() -> object:
            opened.append(object())
            raise AssertionError("при выключенном сборе сессия не создаётся")

        # Каталог собирается ВНУТРИ открытого реестра: маршрут инструмента решается на сборке.
        with _stubbed_formula(_stub_result):
            handler = CalcHandler(
                session,
                await make_calc_catalog(session),
                interpretation_catalog=await make_interpretation_catalog(session),
                status_collector=CalcStatusCollector(session_factory=_factory),  # ty: ignore[invalid-argument-type]
            )
            outcome = await handler.run([CalculationRequest(patient_id=patient_id)])
            assert outcome.processed_codes == [code]
        assert opened == []

    @pytest.mark.test_internal
    async def test_status_write_stays_outside_the_upsert_step(
        self,
        session: AsyncSession,
        factory: Factory,
        created_patients: list[str],
        committed_session_factory: async_sessionmaker[AsyncSession],
        collection_on: None,
    ) -> None:
        """Запись статусов идёт ПОСЛЕ того, как результаты пациента уже переданы в БД.

        Проверяем порядком вызовов, а не задержкой: `TransactionalRetryExecutor.run` (шаг
        `upsert`) обязан завершиться раньше, чем коллектор откроет свою сессию на flush — иначе
        flush жил бы внутри транзакции результатов, чего быть не должно (см. handler.py).
        """
        calls: list[str] = []
        real_run = TransactionalRetryExecutor.run

        async def _tracking_run(self: TransactionalRetryExecutor, operation: Any, *args: Any, **kwargs: Any) -> Any:
            result = await real_run(self, operation, *args, **kwargs)
            calls.append("upsert_done")
            return result

        class _TrackingFactory:
            def __call__(self) -> "_TrackingFactory":
                return self

            async def __aenter__(self) -> "_TrackingFactory":
                calls.append("flush_start")
                return self

            async def __aexit__(self, *exc: object) -> bool:
                return False

            async def execute(self, statement: Any, params: Any = None) -> None:
                return None

            async def commit(self) -> None:
                return None

        code = f"{PREFIX}STEP"
        patient_id = await _insert_patient(factory, created_patients)
        await factory.instrument_with_params(code, required=[f"{PREFIX}P"], in_system=False)
        await _answer(factory, patient_id, f"{PREFIX}P")
        await session.commit()

        # Каталог собирается ВНУТРИ открытого реестра: маршрут инструмента решается на сборке
        # каталога, а не на вызове расчёта.
        with _stubbed_formula(_stub_result):
            handler = CalcHandler(
                session,
                await make_calc_catalog(session),
                interpretation_catalog=await make_interpretation_catalog(session),
                status_collector=CalcStatusCollector(session_factory=_TrackingFactory()),  # ty: ignore[invalid-argument-type]
            )
            with patch.object(TransactionalRetryExecutor, "run", _tracking_run):
                await handler.run([CalculationRequest(patient_id=patient_id)])

        assert calls == ["upsert_done", "flush_start"], f"запись статусов утекла в шаг upsert: {calls}"
