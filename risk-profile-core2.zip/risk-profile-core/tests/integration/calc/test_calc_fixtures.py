"""Контракт фикстур calc: стаб формулы переиспользуется, хендлер собирается после сидов."""

from src.calc.domain.formula import Formula
from src.calc.domain.models import InstrumentInput
from src.calc.handler import CalcHandler
from tests.factories import Factory

# Стаб игнорирует вход, но сигнатуру уважаем: тип входа — часть контракта формулы.
_ANY_INPUT = InstrumentInput(
    instrument_code="I",
    patient_id="p",
    is_pregnant=False,
    params={},
    required_parameter_codes=(),
)


class TestStubFormulaIsReusable:
    """Две функции в одном классе: `_STUB` как кортеж context manager'ов падал бы на второй."""

    def test_first_use(self, stub_formula: None) -> None:
        assert Formula().is_applicable(_ANY_INPUT) is True

    def test_second_use(self, stub_formula: None) -> None:
        assert Formula().is_applicable(_ANY_INPUT) is True


async def test_calc_handler_sees_rows_seeded_before_the_call(factory: Factory, calc_handler) -> None:
    """Каталог строится из БД, поэтому фикстура обязана читать её ПОСЛЕ сидов теста."""
    icode = await factory.instrument_with_params(required=["T_HP1"])
    handler = await calc_handler()
    assert isinstance(handler, CalcHandler)
    assert icode in handler._catalog.instrument_configs
