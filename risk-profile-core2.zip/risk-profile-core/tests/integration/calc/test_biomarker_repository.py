"""Запись результатов с группой заболеваний: ключ, история и атомарность батча."""

from datetime import timedelta
from typing import Any

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.models import (
    FormulaResult,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from src.calc.infra.repository import CalcRepository
from src.constants import ResultInterpretationStatus, RiskLevel
from tests.consts import BIOMARKER_CLINREC_INSTRUMENT_CODE
from tests.factories import Factory

BIOMARKER_KR = BIOMARKER_CLINREC_INSTRUMENT_CODE


async def _seed(factory: Factory) -> tuple[str, str, str]:
    patient_id = await factory.patient()
    await factory.biomarker_clinrec_instrument()
    system_code = await factory.system()
    first = await factory.disease(system_code=system_code)
    second = await factory.disease(system_code=system_code)
    return patient_id, first, second


def _disease_result(
    patient_id: str,
    disease_code: str,
    *,
    value: float | None = 1.0,
    risk_level: RiskLevel | None = InstrumentsRiskLevel.HIGH,
    applicability: bool = True,
    instrument_code: str = BIOMARKER_KR,
) -> FormulaResult:
    return FormulaResult(
        instrument_code=instrument_code,
        patient_id=patient_id,
        value=value,
        unit=InstrumentsUnits.BIOMARKER_CLINREC if applicability else None,
        risk_level=risk_level,
        applicability=applicability,
        interpretation_status=(
            ResultInterpretationStatus.READY if applicability else ResultInterpretationStatus.NOT_REQUIRED
        ),
        expiration_delta=timedelta(days=36500),
        indicator=InstrumentsIndicators.BIOMARKER_CLINREC,
        disease_code=disease_code,
    )


async def _rows(session: AsyncSession, patient_id: str) -> list[Any]:
    result = await session.execute(
        text(
            "SELECT disease_code, value, risk_level, applicability FROM results"
            " WHERE patient_id = :pid ORDER BY disease_code"
        ),
        {"pid": patient_id},
    )
    return list(result.all())


async def _history_count(session: AsyncSession, patient_id: str, disease_code: str) -> int:
    result = await session.execute(
        text("SELECT count(*) FROM results_history WHERE patient_id = :pid AND disease_code = :d"),
        {"pid": patient_id, "d": disease_code},
    )
    return int(result.scalar_one())


async def test_disease_codes_are_independent_rows(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first, second = await _seed(factory)
    await db_session.commit()

    async with db_session.begin():
        await CalcRepository(db_session).upsert_results_batch(
            [_disease_result(patient_id, first), _disease_result(patient_id, second)]
        )

    rows = await _rows(db_session, patient_id)
    assert [row.disease_code for row in rows] == sorted([first, second])


async def test_changed_group_overwrites_only_its_own_row(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first, second = await _seed(factory)
    await db_session.commit()
    repo = CalcRepository(db_session)

    async with db_session.begin():
        await repo.upsert_results_batch([_disease_result(patient_id, first), _disease_result(patient_id, second)])
    async with db_session.begin():
        await repo.upsert_results_batch(
            [_disease_result(patient_id, first, value=None, risk_level=None, applicability=False)]
        )

    rows = {row.disease_code: row for row in await _rows(db_session, patient_id)}
    assert (rows[first].value, rows[first].applicability) == (None, False)
    assert (float(rows[second].value), rows[second].applicability) == (pytest.approx(1.0), True)
    # По одной записи истории на каждое переданное состояние: у обновлённой группы их две.
    assert await _history_count(db_session, patient_id, first) == 2
    assert await _history_count(db_session, patient_id, second) == 1


async def test_ordinary_result_keeps_its_empty_disease_code_key(db_session: AsyncSession, factory: Factory) -> None:
    """`NULLS NOT DISTINCT`: строки без группы конфликтуют между собой по остальным колонкам."""
    patient_id = await factory.patient()
    await factory.instrument("ORD_I", type="calc")
    await db_session.commit()
    repo = CalcRepository(db_session)

    ordinary = _disease_result(patient_id, disease_code=None, instrument_code="ORD_I")  # ty: ignore[invalid-argument-type]
    async with db_session.begin():
        await repo.upsert_results_batch([ordinary])
    async with db_session.begin():
        await repo.upsert_results_batch([_disease_result(patient_id, None, value=2.0, instrument_code="ORD_I")])  # ty: ignore[invalid-argument-type]

    rows = await _rows(db_session, patient_id)
    assert len(rows) == 1
    assert float(rows[0].value) == pytest.approx(2.0)


async def test_duplicate_key_within_one_batch_collapses_to_the_last(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first, _ = await _seed(factory)
    await db_session.commit()

    async with db_session.begin():
        await CalcRepository(db_session).upsert_results_batch(
            [_disease_result(patient_id, first, value=1.0), _disease_result(patient_id, first, value=None)]
        )

    rows = await _rows(db_session, patient_id)
    assert len(rows) == 1
    assert rows[0].value is None
    # История append-only: схлопывание касается только `results`.
    assert await _history_count(db_session, patient_id, first) == 2


async def test_mixed_batch_rolls_back_atomically(db_session: AsyncSession, factory: Factory) -> None:
    """Ошибка одной строки откатывает весь батч пациента, включая уже записанные группы."""
    patient_id, first, _ = await _seed(factory)
    await factory.instrument("ORD_OK", type="calc")
    await db_session.commit()

    broken = _disease_result(patient_id, "DISEASE_THAT_DOES_NOT_EXIST")
    with pytest.raises(Exception):  # noqa: B017 — важна не сама ошибка FK, а откат батча
        async with db_session.begin():
            await CalcRepository(db_session).upsert_results_batch(
                [
                    _disease_result(patient_id, first),
                    _disease_result(patient_id, None, instrument_code="ORD_OK"),  # ty: ignore[invalid-argument-type]
                    broken,
                ]
            )

    assert await _rows(db_session, patient_id) == []
