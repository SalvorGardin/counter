"""Запись запланированных параметров биомаркеров в `patients_parameters`."""

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import ServiceRuntime
from src.emr_biomarkers.domain.planning import ParameterWrite
from src.emr_biomarkers.infra.repository import EmrBiomarkersRepository
from tests.db_assertions import DbRead
from tests.factories import Factory, unique_id

# Файл проверяет путь консюмера ЭМК: модели профиля должны адресовать представления
# `risk_ehr`, где обычный INSERT уходит в триггер архивации. На физической таблице тот же
# код был бы просто вставкой и ничего бы не доказал.
pytestmark = pytest.mark.db_role(ServiceRuntime.EHR)

_MOMENT = datetime(2026, 7, 20, 8, 30, tzinfo=UTC)


def _write(parameter_code: str, *, value: str = "3.6", external_id: int = 845231) -> ParameterWrite:
    return ParameterWrite(
        parameter_code=parameter_code,
        value=value,
        external_id=external_id,
        date_time=_MOMENT,
        expiration_date=_MOMENT + timedelta(days=365),
    )


async def test_write_fills_all_contract_fields(db_session: AsyncSession, factory: Factory, db_read: DbRead) -> None:
    patient_id = await factory.patient()
    parameter_code = await factory.parameter(unique_id("biomarker"))

    await EmrBiomarkersRepository(db_session).apply_writes(patient_id=patient_id, writes=[_write(parameter_code)])

    row = await db_read.answer_columns(patient_id=patient_id, parameter_code=parameter_code)
    assert row is not None
    assert row["value"] == "3.6"
    assert row["source"] == "EMR"
    assert row["external_id"] == 845231
    assert row["date_time"] == _MOMENT
    assert row["expiration_date"] == _MOMENT + timedelta(days=365)


async def test_fraction_of_second_survives_the_round_trip(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Доля секунды сохраняется и читается без потерь.

    От этого зависят правило свежести и признак дубля: они сравнивают входящий момент
    с сохранённым строгим `>` и на равенство. Если бы колонка усекала доли, повторная доставка
    того же биомаркера каждый раз выглядела бы свежее записи и множила версии в истории.
    """
    patient_id = await factory.patient()
    parameter_code = await factory.parameter(unique_id("biomarker"))
    moment = _MOMENT.replace(microsecond=123_456)

    await EmrBiomarkersRepository(db_session).apply_writes(
        patient_id=patient_id,
        writes=[
            ParameterWrite(
                parameter_code=parameter_code,
                value="3.6",
                external_id=845231,
                date_time=moment,
                expiration_date=moment + timedelta(days=365),
            )
        ],
    )

    row = await db_read.answer_columns(patient_id=patient_id, parameter_code=parameter_code)
    assert row is not None
    assert row["date_time"] == moment
    assert row["expiration_date"] == moment + timedelta(days=365)


async def test_ten_digit_external_id_fits(db_session: AsyncSession, factory: Factory, db_read: DbRead) -> None:
    """Контракт разрешает `id` длиной до 10 цифр — колонка обязана его вместить."""
    patient_id = await factory.patient()
    parameter_code = await factory.parameter(unique_id("biomarker"))

    await EmrBiomarkersRepository(db_session).apply_writes(
        patient_id=patient_id, writes=[_write(parameter_code, external_id=9_999_999_999)]
    )

    row = await db_read.answer_columns(patient_id=patient_id, parameter_code=parameter_code)
    assert row is not None
    assert row["external_id"] == 9_999_999_999


async def test_previous_version_goes_to_history(db_session: AsyncSession, factory: Factory, db_read: DbRead) -> None:
    patient_id = await factory.patient()
    parameter_code = await factory.parameter(unique_id("biomarker"))
    repository = EmrBiomarkersRepository(db_session)
    await repository.apply_writes(patient_id=patient_id, writes=[_write(parameter_code)])

    await repository.apply_writes(
        patient_id=patient_id, writes=[_write(parameter_code, value="4.2", external_id=845232)]
    )

    current = await db_read.answer_columns(patient_id=patient_id, parameter_code=parameter_code)
    assert current is not None
    assert (current["value"], current["external_id"]) == ("4.2", 845232)
    history = await db_read.answer_history(patient_id=patient_id, parameter_code=parameter_code)
    assert [(row["value"], row["external_id"]) for row in history] == [("3.6", 845231)]


async def test_writes_of_one_message_land_in_their_own_rows(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    patient_id = await factory.patient()
    biomarker_parameter = await factory.parameter(unique_id("biomarker"))
    question_parameter = await factory.parameter(unique_id("PARAM"))

    await EmrBiomarkersRepository(db_session).apply_writes(
        patient_id=patient_id,
        writes=[_write(biomarker_parameter), _write(question_parameter, value="Да")],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=biomarker_parameter) == "3.6"
    assert await db_read.answer(patient_id=patient_id, parameter_code=question_parameter) == "Да"


async def _rows_in_write_order(session: AsyncSession, patient_id: str) -> list[tuple[str, str | None]]:
    """Строки параметров пациента в порядке создания: `patient_parameter_id` — счётчик вставок."""
    rows = await session.execute(
        text(
            "SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"
            " ORDER BY patient_parameter_id"
        ),
        {"pid": patient_id},
    )
    return [(row.parameter_code, row.value) for row in rows.all()]


async def test_writes_apply_in_ascending_parameter_code_order(db_session: AsyncSession, factory: Factory) -> None:
    """Записи сообщения применяются по возрастанию `parameter_code`, а не в порядке сообщения.

    Порядок захвата строк `patients_parameters` — общий со сбросом параметров (правило —
    `src/infra/patients_parameters.py`), и разойдись они, сообщение с биомаркерами и сброс по
    пересекающемуся набору параметров могли бы заблокироваться взаимно. Коды в плане идут по
    убыванию, поэтому порядок вставки виден по `patient_parameter_id`; значения проверяются вместе
    с ним — сортировка меняет порядок захвата строк, а не то, что попадает в каждую.
    """
    patient_id = await factory.patient()
    prefix = unique_id("biomarker")
    lower_code = await factory.parameter(f"{prefix}_a")
    higher_code = await factory.parameter(f"{prefix}_b")

    await EmrBiomarkersRepository(db_session).apply_writes(
        patient_id=patient_id,
        writes=[_write(higher_code, value="9.9"), _write(lower_code, value="1.1")],
    )

    assert await _rows_in_write_order(db_session, patient_id) == [(lower_code, "1.1"), (higher_code, "9.9")]
