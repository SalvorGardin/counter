"""Чтение пациента и текущих параметров обработкой биомаркеров.

Справочные строки проверяются тестами `EmrBiomarkersCatalog`: SQL-reader этого пути работает
только с состоянием пациента.
"""

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import ServiceRuntime
from src.emr_biomarkers.infra.reader import EmrBiomarkersReader
from tests.factories import Factory, unique_id

# Файл проверяет путь консюмера ЭМК: модели профиля должны адресовать представления
# `risk_ehr`, где обычный INSERT уходит в триггер архивации. На физической таблице тот же
# код был бы просто вставкой и ничего бы не доказал.
pytestmark = pytest.mark.db_role(ServiceRuntime.EHR)


async def test_patient_exists(db_session: AsyncSession, factory: Factory) -> None:
    patient_id = await factory.patient()
    reader = EmrBiomarkersReader(db_session)

    assert await reader.patient_exists(patient_id) is True
    assert await reader.patient_exists(unique_id("NOBODY")) is False


async def test_empty_code_list_does_not_query(db_session: AsyncSession) -> None:
    reader = EmrBiomarkersReader(db_session)
    assert await reader.load_stored_parameters("nobody", []) == {}


async def test_stored_parameters_include_expired_rows(db_session: AsyncSession, factory: Factory) -> None:
    """Просроченная запись читается наравне с актуальной: свежесть считается по дате, а не по сроку."""
    patient_id = await factory.patient()
    fresh = await factory.parameter(unique_id("PARAM"))
    expired = await factory.parameter(unique_id("PARAM"))
    other = await factory.parameter(unique_id("PARAM"))
    moment = datetime.now(tz=UTC) - timedelta(days=2)
    await factory.answer(patient_id=patient_id, parameter_code=fresh, value="3.6", date_time=moment)
    await factory.answer(patient_id=patient_id, parameter_code=expired, value="1.0", date_time=moment)
    await factory.expire_answer(patient_id=patient_id, parameter_code=expired)
    await factory.answer(patient_id=patient_id, parameter_code=other, value="нужен не он", date_time=moment)

    stored = await EmrBiomarkersReader(db_session).load_stored_parameters(patient_id, [fresh, expired])

    assert set(stored) == {fresh, expired}
    assert stored[fresh].value == "3.6"
    assert stored[fresh].date_time == moment
    assert stored[expired].expiration_date < datetime.now(tz=UTC)


async def test_stored_parameters_of_other_patient_are_not_read(db_session: AsyncSession, factory: Factory) -> None:
    parameter_code = await factory.parameter(unique_id("PARAM"))
    mine = await factory.patient()
    theirs = await factory.patient()
    await factory.answer(patient_id=theirs, parameter_code=parameter_code, value="3.6")

    assert await EmrBiomarkersReader(db_session).load_stored_parameters(mine, [parameter_code]) == {}
