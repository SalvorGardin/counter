"""Сквозные сценарии обработки сообщения топика `emr-biomarkers` на реальной базе.

Проверяются шаги 2 и 4–7 контракта целиком: поиск пациента, сверка со справочником, запись
параметра-биомаркера, заполнение параметра опросника по разметке и заказ пересчёта.

Обработка открывает собственную сессию (в воркере запросной нет), поэтому фабрика сессий отдаёт
сессию теста: отдельное соединение не увидело бы засеянных строк.
"""

import contextlib
import re
from collections.abc import AsyncIterator, Iterator, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import ServiceRuntime
from src.emr_biomarkers.domain.constants import EmrBiomarkerErrorCode
from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.processing import EmrBiomarkersProcessor, ProcessingReport
from src.infra.catalog.base import load_catalog
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from tests.catalog_builder import make_catalog
from tests.db_assertions import DbRead
from tests.factories import Factory, unique_biomarker_code, unique_id

# Файл проверяет путь консюмера ЭМК: модели профиля должны адресовать представления
# `risk_ehr`, где обычный INSERT уходит в триггер архивации. На физической таблице тот же
# код был бы просто вставкой и ничего бы не доказал.
pytestmark = pytest.mark.db_role(ServiceRuntime.EHR)

_UNIT_CODE = 169
_NOW = datetime.now(tz=UTC)
_REFERENCE_SQL = re.compile(
    r"\b(?:from|join|update|into)\s+(?:\w+\.)?"
    r"(?:biomarkers|biomarker_parameter_mappings|parameters|options)\b",
    re.IGNORECASE,
)


@pytest.fixture
def session_factory(db_session: AsyncSession) -> Any:
    """Фабрика сессий обработки: отдаёт сессию теста (она в savepoint-режиме, и её записи видны
    только на её же соединении)."""

    @contextlib.asynccontextmanager
    async def _factory() -> AsyncIterator[AsyncSession]:
        yield db_session

    return _factory


@pytest.fixture
def dispatch() -> AsyncMock:
    """Заказ пересчёта: публикация команды подменяется — топик здесь не поднимается."""
    return AsyncMock()


@pytest.fixture
def processor(session_factory: Any, dispatch: AsyncMock) -> EmrBiomarkersProcessor:
    return EmrBiomarkersProcessor(session_factory, EmrBiomarkersCatalog(make_catalog()), dispatch)


def _biomarker(
    *,
    biomarker_code: int,
    value: str = "3.6",
    external_id: int = 845231,
    unit_code: int | None = _UNIT_CODE,
    date_time: datetime | str | None = None,
    operation_type: str = "save",
) -> EmrBiomarker:
    return EmrBiomarker.model_validate(
        {
            "id": external_id,
            "biomarkerCode": biomarker_code,
            "operationType": operation_type,
            "name": "Холестерин ЛПНП",
            "unit": None if unit_code is None else "ммоль/л",
            "unitCode": unit_code,
            "value": value,
            "dateTime": date_time if date_time is not None else _NOW - timedelta(days=1),
        }
    )


async def _catalog_biomarker(
    factory: Factory,
    *,
    validity_days: int = 365,
    unit_code: int | None = _UNIT_CODE,
    biomarker_type: str = "quantitative",
    status: str = "active",
) -> tuple[int, str]:
    """Заводит параметр и строку справочника под него. Отдаёт (код биомаркера, код параметра)."""
    parameter_code = await factory.parameter(unique_id("biomarker"), validity_days=validity_days, status=status)
    code = await factory.biomarker(parameter_code=parameter_code, unit_code=unit_code, type=biomarker_type)
    return code, parameter_code


async def _process(
    processor: EmrBiomarkersProcessor,
    db_session: AsyncSession,
    client_id: str,
    biomarkers: Sequence[EmrBiomarker],
) -> ProcessingReport:
    """Фиксирует сиды, строит стартовый снимок и прогоняет обработку поверх своей транзакции."""
    await db_session.commit()
    processor._catalog = EmrBiomarkersCatalog(await load_catalog(db_session))
    await db_session.commit()
    return await processor.process(client_id, biomarkers)


@contextlib.contextmanager
def _record_sql(session: AsyncSession) -> Iterator[list[str]]:
    statements: list[str] = []
    bind = session.sync_session.bind
    assert bind is not None

    def before_cursor_execute(_conn, _cursor, statement, _parameters, _context, _executemany) -> None:
        statements.append(statement)

    event.listen(bind, "before_cursor_execute", before_cursor_execute)
    try:
        yield statements
    finally:
        event.remove(bind, "before_cursor_execute", before_cursor_execute)


async def test_message_writes_parameters_and_orders_one_recalc(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    patient_id = await factory.patient()
    first_code, first_parameter = await _catalog_biomarker(factory)
    second_code, second_parameter = await _catalog_biomarker(factory)

    report = await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=first_code, value="3,6"), _biomarker(biomarker_code=second_code, value="6.4")],
    )

    assert report.completed is True
    assert await db_read.answer(patient_id=patient_id, parameter_code=first_parameter) == "3.6"
    assert await db_read.answer(patient_id=patient_id, parameter_code=second_parameter) == "6.4"
    dispatch.assert_awaited_once_with(patient_id, {first_parameter, second_parameter})


async def test_message_path_issues_no_reference_sql(
    db_session: AsyncSession,
    factory: Factory,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, _parameter_code = await _catalog_biomarker(factory)
    await db_session.commit()
    processor._catalog = EmrBiomarkersCatalog(await load_catalog(db_session))
    await db_session.commit()

    with _record_sql(db_session) as statements:
        report = await processor.process(patient_id, [_biomarker(biomarker_code=biomarker_code)])

    assert report.completed is True
    assert statements
    assert not [statement for statement in statements if _REFERENCE_SQL.search(statement)]


async def test_unknown_client_stops_the_message(
    db_session: AsyncSession,
    factory: Factory,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    biomarker_code, parameter_code = await _catalog_biomarker(factory)

    report = await _process(processor, db_session, unique_id("NOBODY"), [_biomarker(biomarker_code=biomarker_code)])

    assert report.error_code == EmrBiomarkerErrorCode.CLIENT_NOT_FOUND
    assert report.written_parameters == ()
    dispatch.assert_not_awaited()


async def test_delete_operation_is_not_processed(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, parameter_code = await _catalog_biomarker(factory)

    report = await _process(
        processor, db_session, patient_id, [_biomarker(biomarker_code=biomarker_code, operation_type="delete")]
    )

    assert report.completed is True
    assert report.skips == ()
    assert await db_read.answer(patient_id=patient_id, parameter_code=parameter_code) is None
    dispatch.assert_not_awaited()


async def test_unknown_biomarker_is_reported_and_nothing_written(
    db_session: AsyncSession,
    factory: Factory,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    patient_id = await factory.patient()

    report = await _process(processor, db_session, patient_id, [_biomarker(biomarker_code=unique_biomarker_code())])

    assert [skip.error.code for skip in report.skips] == [EmrBiomarkerErrorCode.UNKNOWN_BIOMARKER]
    assert report.written_parameters == ()
    dispatch.assert_not_awaited()


async def test_multi_unit_biomarker_fills_its_own_parameters(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code = unique_biomarker_code()
    first_parameter = await factory.parameter(unique_id("biomarker"))
    second_parameter = await factory.parameter(unique_id("biomarker"))
    await factory.biomarker(parameter_code=first_parameter, biomarker_code=biomarker_code, unit_code=_UNIT_CODE)
    await factory.biomarker(parameter_code=second_parameter, biomarker_code=biomarker_code, unit_code=10)

    await _process(
        processor,
        db_session,
        patient_id,
        [
            _biomarker(biomarker_code=biomarker_code, value="3.6", unit_code=_UNIT_CODE, external_id=1),
            _biomarker(biomarker_code=biomarker_code, value="139.2", unit_code=10, external_id=2),
        ],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=first_parameter) == "3.6"
    assert await db_read.answer(patient_id=patient_id, parameter_code=second_parameter) == "139.2"


async def test_repeated_message_changes_nothing(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    """Повторная доставка того же сообщения идемпотентна: ни записи, ни второй команды пересчёта."""
    patient_id = await factory.patient()
    biomarker_code, parameter_code = await _catalog_biomarker(factory)
    message = [_biomarker(biomarker_code=biomarker_code)]
    await _process(processor, db_session, patient_id, message)

    second = await processor.process(patient_id, message)

    assert second.written_parameters == ()
    assert second.recalc_requested is False
    assert dispatch.await_count == 1
    assert await db_read.count_answer_history(patient_id=patient_id, parameter_code=parameter_code) == 0


async def test_expired_value_does_not_replace_actual_record(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, parameter_code = await _catalog_biomarker(factory, validity_days=30)
    await factory.answer(
        patient_id=patient_id,
        parameter_code=parameter_code,
        value="3.0",
        source="EMR",
        date_time=_NOW - timedelta(days=400),
    )

    report = await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, date_time=_NOW - timedelta(days=200))],
    )

    assert report.written_parameters == ()
    assert await db_read.answer(patient_id=patient_id, parameter_code=parameter_code) == "3.0"
    dispatch.assert_not_awaited()


async def test_expired_value_is_written_when_no_actual_record(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, parameter_code = await _catalog_biomarker(factory, validity_days=30)

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, date_time=_NOW - timedelta(days=200))],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=parameter_code) == "3.6"
    expiration = await db_read.answer_expiration(patient_id=patient_id, parameter_code=parameter_code)
    assert expiration is not None
    assert expiration < _NOW


async def test_value_mapping_fills_question_parameter(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    dispatch: AsyncMock,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory)
    target_parameter = await factory.parameter(unique_id("PARAM"), validity_days=3650)
    await factory.question(type="numeric")
    await factory.biomarker_mapping(biomarker_parameter_code=source_parameter, parameter_code=target_parameter)

    await _process(processor, db_session, patient_id, [_biomarker(biomarker_code=biomarker_code, value="3.6")])

    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) == "3.6"
    source_expiration = await db_read.answer_expiration(patient_id=patient_id, parameter_code=source_parameter)
    target_expiration = await db_read.answer_expiration(patient_id=patient_id, parameter_code=target_parameter)
    assert source_expiration is not None and target_expiration is not None
    # Срок жизни — свойство параметра, а не источника значения: у цели он свой, десятилетний.
    assert target_expiration > source_expiration
    dispatch.assert_awaited_once_with(patient_id, {source_parameter, target_parameter})


async def test_flag_mapping_writes_option_value(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory, unit_code=None, biomarker_type="qualitative")
    target_parameter = await factory.parameter(unique_id("PARAM"))
    question = await factory.question()
    option = await factory.option(question_code=question, parameter_code=target_parameter, value="Да")
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_parameter,
        parameter_code=target_parameter,
        mapping_type="flag",
        operator="eq",
        value_text="Обнаружен",
        option_code=option,
    )

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, value="Обнаружен", unit_code=None)],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=source_parameter) == "Обнаружен"
    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) == "Да"


async def test_flag_mapping_leaves_question_unanswered_when_normal(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory)
    target_parameter = await factory.parameter(unique_id("PARAM"))
    question = await factory.question()
    option = await factory.option(question_code=question, parameter_code=target_parameter, value="Да")
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_parameter,
        parameter_code=target_parameter,
        mapping_type="flag",
        operator="gt",
        value_num=Decimal("5.0"),
        option_code=option,
    )

    await _process(processor, db_session, patient_id, [_biomarker(biomarker_code=biomarker_code, value="3.6")])

    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) is None


async def test_skipped_question_is_overwritten_by_biomarker(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    """Пропуск вопроса запирал бы параметр на весь его срок жизни, хотя данные в ЭМК есть."""
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory)
    target_parameter = await factory.parameter(unique_id("PARAM"), validity_days=3650)
    await factory.answer(
        patient_id=patient_id, parameter_code=target_parameter, value="", source="FORM", date_time=_NOW
    )
    await factory.biomarker_mapping(biomarker_parameter_code=source_parameter, parameter_code=target_parameter)

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, date_time=_NOW - timedelta(days=10))],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) == "3.6"


async def test_answer_newer_than_biomarker_is_kept(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory)
    target_parameter = await factory.parameter(unique_id("PARAM"), validity_days=3650)
    await factory.answer(
        patient_id=patient_id, parameter_code=target_parameter, value="1.0", source="FORM", date_time=_NOW
    )
    await factory.biomarker_mapping(biomarker_parameter_code=source_parameter, parameter_code=target_parameter)

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, date_time=_NOW - timedelta(days=10))],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) == "1.0"


async def test_timezone_aware_biomarker_keeps_newer_form_answer(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    """Приоритет использует абсолютный момент, а не локальные часы из `dateTime`."""
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory)
    target_parameter = await factory.parameter(unique_id("PARAM"), validity_days=3650)
    await factory.answer(
        patient_id=patient_id,
        parameter_code=target_parameter,
        value="1.0",
        source="FORM",
        date_time=datetime(2026, 7, 20, 6, 0, tzinfo=UTC),
    )
    await factory.biomarker_mapping(biomarker_parameter_code=source_parameter, parameter_code=target_parameter)

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, date_time="2026-07-20T08:30:00+03:00")],
    )

    biomarker_row = await db_read.answer_columns(patient_id=patient_id, parameter_code=source_parameter)
    assert biomarker_row is not None
    assert biomarker_row["date_time"] == datetime(2026, 7, 20, 5, 30, tzinfo=UTC)
    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) == "1.0"


async def test_inactive_parameter_skips_biomarker(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
) -> None:
    patient_id = await factory.patient()
    biomarker_code, parameter_code = await _catalog_biomarker(factory, status="inactive")

    report = await _process(processor, db_session, patient_id, [_biomarker(biomarker_code=biomarker_code)])

    assert [skip.error.code for skip in report.skips] == [EmrBiomarkerErrorCode.PARAMETER_NOT_ACTIVE]
    assert await db_read.answer(patient_id=patient_id, parameter_code=parameter_code) is None


async def test_inapplicable_mapping_row_is_skipped_with_a_warning(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    processor: EmrBiomarkersProcessor,
    captured_app_logs: Any,
) -> None:
    """Числовой оператор у качественного источника — дефект справочника, а не данных пациента:
    строка разметки пропускается, биомаркер сохраняется."""
    patient_id = await factory.patient()
    biomarker_code, source_parameter = await _catalog_biomarker(factory, unit_code=None, biomarker_type="qualitative")
    target_parameter = await factory.parameter(unique_id("PARAM"))
    question = await factory.question()
    option = await factory.option(question_code=question, parameter_code=target_parameter, value="Да")
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_parameter,
        parameter_code=target_parameter,
        mapping_type="flag",
        operator="gt",
        value_num=Decimal("5.0"),
        option_code=option,
    )

    await _process(
        processor,
        db_session,
        patient_id,
        [_biomarker(biomarker_code=biomarker_code, value="Обнаружен", unit_code=None)],
    )

    assert await db_read.answer(patient_id=patient_id, parameter_code=source_parameter) == "Обнаружен"
    assert await db_read.answer(patient_id=patient_id, parameter_code=target_parameter) is None
    assert "emr.biomarkers: mapping skipped" in captured_app_logs.messages()
