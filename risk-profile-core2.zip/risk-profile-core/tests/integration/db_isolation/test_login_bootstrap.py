"""Выдача отдельных логинов: заводится и обновляется только названный, пароли остальных не меняются.

Сценарий из деплоя: релиз добавил логин, а пароли уже работающих рантаймов лежат только в их
конфигах. Полная выдача перезаписала бы их все, выборочная обязана их не тронуть.

Прогон идёт в отдельном кластере PostgreSQL: тесты меняют пароли логинов, на которых держится сессионный стенд.
"""

import asyncio
import secrets
from collections.abc import Generator

import pytest
from pydantic import SecretStr
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.exc import OperationalError

from src.infra.db_bootstrap import (
    MissingMigrationRoleError,
    RoleCredentials,
    bootstrap_logins_at_url,
    bootstrap_roles_at_url,
)
from src.infra.db_schemas import BULK_RECALC_ROLE, MIGRATION_ROLE, PROFILE_ROLE
from tests.postgres import postgres_server

pytestmark = pytest.mark.db


@pytest.fixture
def admin_url() -> Generator[str, None, None]:
    with postgres_server() as url:
        yield url


def _can_log_in(admin_url: str, role: str, password: str) -> bool:
    url = make_url(admin_url).set(username=role, password=password)
    engine = create_engine(url)
    try:
        with engine.connect() as connection:
            return connection.execute(text("SELECT current_user")).scalar_one() == role
    except OperationalError:  # отказ во входе и есть проверяемый исход
        return False
    finally:
        engine.dispose()


def _password() -> str:
    return secrets.token_urlsafe(24)


def test_creates_a_missing_login_that_can_connect(admin_url: str) -> None:
    password = _password()

    asyncio.run(bootstrap_logins_at_url(admin_url, {BULK_RECALC_ROLE: SecretStr(password)}))

    assert _can_log_in(admin_url, BULK_RECALC_ROLE, password)


def test_updates_only_the_requested_login(admin_url: str) -> None:
    profile_password, bulk_password = _password(), _password()
    credentials = RoleCredentials(
        profile=SecretStr(profile_password),
        calculation=SecretStr(_password()),
        ehr=SecretStr(_password()),
        bulk_recalc=SecretStr(bulk_password),
        migrations=SecretStr(_password()),
    )
    asyncio.run(bootstrap_roles_at_url(admin_url, credentials, legacy_owner=make_url(admin_url).username))
    rotated = _password()

    asyncio.run(bootstrap_logins_at_url(admin_url, {BULK_RECALC_ROLE: SecretStr(rotated)}))

    assert _can_log_in(admin_url, BULK_RECALC_ROLE, rotated)
    assert not _can_log_in(admin_url, BULK_RECALC_ROLE, bulk_password)
    assert _can_log_in(admin_url, PROFILE_ROLE, profile_password)


def test_refuses_to_create_the_migration_login_without_the_full_bootstrap(admin_url: str) -> None:
    """Заведённый поодиночке миграционный логин остался бы без членства во владельцах схем."""
    with pytest.raises(MissingMigrationRoleError):
        asyncio.run(bootstrap_logins_at_url(admin_url, {MIGRATION_ROLE: SecretStr(_password())}))

    assert not _can_log_in(admin_url, MIGRATION_ROLE, "anything")
