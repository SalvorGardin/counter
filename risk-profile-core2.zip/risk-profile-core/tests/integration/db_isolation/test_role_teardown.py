"""Снятие ролей при откате: роли исчезают, объекты с данными — нет.

`DROP OWNED BY` отзывает права и УДАЛЯЕТ объекты роли одной командой, поэтому проверяется не
только результат («ролей не осталось»), но и оба предохранителя: отказ, пока схемы сервисов на
месте, и отказ, пока роль хоть чем-то владеет.

Прогон идёт в отдельном кластере PostgreSQL: тесты снимают роли, на которых держится сессионный стенд.
"""

import asyncio
import secrets
from collections.abc import Generator

import pytest
from alembic import command
from alembic.config import Config
from pydantic import SecretStr
from sqlalchemy import Engine, create_engine, text
from sqlalchemy.engine.url import make_url

from src.infra.db_bootstrap import (
    ApplicationSchemasPresentError,
    RoleCredentials,
    RoleOwnsObjectsError,
    bootstrap_roles_at_url,
    drop_roles_at_url,
)
from src.infra.db_schemas import LOGIN_ROLES, MIGRATION_ROLE, SCHEMA_OWNER_ROLES
from tests.postgres import postgres_server

pytestmark = pytest.mark.db

_BEFORE_ISOLATION = "15c247ec61bb"
_ALL_ROLES = (*LOGIN_ROLES, MIGRATION_ROLE, *sorted(set(SCHEMA_OWNER_ROLES.values())))


@pytest.fixture(scope="module")
def admin_url() -> Generator[str, None, None]:
    with postgres_server() as url:
        yield url


def _config(url: str) -> Config:
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", url)
    return config


@pytest.fixture(scope="module")
def upgraded(admin_url: str) -> str:
    """БД в форме стенда: таблицы до изоляции созданы прежним владельцем, изоляцию накатили миграции.

    Цепочка до изоляции гонится админским логином намеренно. На стенде таблицы и `alembic_version`
    принадлежат прежнему общему логину, и именно его откат находит как владельца для возврата.
    Прогони её `risk_migrations` — он остался бы владельцем всего, и снятие ролей уперлось бы в
    собственную проверку, как и должно.
    """
    password = secrets.token_urlsafe(24)
    credentials = RoleCredentials(
        profile=SecretStr(secrets.token_urlsafe(24)),
        calculation=SecretStr(secrets.token_urlsafe(24)),
        ehr=SecretStr(secrets.token_urlsafe(24)),
        bulk_recalc=SecretStr(secrets.token_urlsafe(24)),
        migrations=SecretStr(password),
    )
    asyncio.run(bootstrap_roles_at_url(admin_url, credentials, legacy_owner=make_url(admin_url).username))
    command.upgrade(_config(admin_url), _BEFORE_ISOLATION)

    migration_url = (
        make_url(admin_url).set(username=MIGRATION_ROLE, password=password).render_as_string(hide_password=False)
    )
    command.upgrade(_config(migration_url), "head")
    return migration_url


@pytest.fixture(scope="module")
def downgraded(upgraded: str, admin_url: str) -> str:
    """Откат выполнен: таблицы вернулись в public, схем сервисов больше нет.

    Перед откатом воспроизводится шаг оператора из `deploy/DEPLOY.txt`: членство в прежнем
    владельце возвращается с правом `SET ROLE`. Выдача оставляет его без этого права, а
    `ALTER TABLE ... OWNER TO` при смене владельца требует именно его.
    """
    legacy_owner = make_url(admin_url).username
    restore = create_engine(admin_url)
    try:
        with restore.begin() as connection:
            connection.execute(text(f'GRANT "{legacy_owner}" TO {MIGRATION_ROLE} WITH SET TRUE'))
    finally:
        restore.dispose()

    command.downgrade(_config(upgraded), _BEFORE_ISOLATION)
    return upgraded


@pytest.fixture(scope="module")
def admin_engine(admin_url: str) -> Generator[Engine, None, None]:
    created = create_engine(admin_url)
    yield created
    created.dispose()


def _existing_roles(engine: Engine) -> set[str]:
    with engine.connect() as connection:
        return set(
            connection.execute(
                text("SELECT rolname FROM pg_roles WHERE rolname = ANY(:roles)"), {"roles": list(_ALL_ROLES)}
            )
            .scalars()
            .all()
        )


def test_refuses_to_drop_roles_while_the_service_schemas_exist(
    upgraded: str, admin_url: str, admin_engine: Engine
) -> None:
    """Первый предохранитель: до отката схемами владеют роли, и снятие удалило бы данные."""
    with pytest.raises(ApplicationSchemasPresentError, match="risk_profile"):
        asyncio.run(drop_roles_at_url(admin_url))

    assert _existing_roles(admin_engine) == set(_ALL_ROLES), "отказ обязан не тронуть ни одной роли"


def test_refuses_to_drop_a_role_that_still_owns_an_object(
    downgraded: str, admin_url: str, admin_engine: Engine
) -> None:
    """Второй предохранитель: забытый `ALTER TABLE ... OWNER TO` оставляет таблицу за миграциями."""
    with admin_engine.begin() as connection:
        connection.execute(text("CREATE TABLE public.teardown_probe (id int)"))
        connection.execute(text(f"ALTER TABLE public.teardown_probe OWNER TO {MIGRATION_ROLE}"))
    try:
        with pytest.raises(RoleOwnsObjectsError, match="teardown_probe"):
            asyncio.run(drop_roles_at_url(admin_url))
        assert _existing_roles(admin_engine) == set(_ALL_ROLES)
    finally:
        with admin_engine.begin() as connection:
            connection.execute(text("DROP TABLE public.teardown_probe"))


def test_drops_every_role_after_the_downgrade(downgraded: str, admin_url: str, admin_engine: Engine) -> None:
    """Целевой сценарий: после отката роли снимаются, а вернувшиеся в public таблицы остаются."""
    with admin_engine.connect() as connection:
        patients_before = connection.execute(text("SELECT count(*) FROM public.patients")).scalar_one()

    asyncio.run(drop_roles_at_url(admin_url))

    assert _existing_roles(admin_engine) == set()
    with admin_engine.connect() as connection:
        assert connection.execute(text("SELECT count(*) FROM public.patients")).scalar_one() == patients_before

    # Повторный запуск — не ошибка: снятие ролей идемпотентно, как и их выдача.
    asyncio.run(drop_roles_at_url(admin_url))
