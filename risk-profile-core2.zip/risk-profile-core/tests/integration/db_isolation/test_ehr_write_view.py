"""Контролируемая запись параметра из ЭМК через `risk_ehr.patients_parameters`.

Консюмер ЭМК шлёт обычный INSERT; архивацию прежнего значения, upsert и валидацию делает
`INSTEAD OF INSERT`-триггер в транзакции вызывающего. Тесты гоняют этот путь под настоящим
логином `risk_ehr_app`, поэтому заодно доказывают, что ни таблиц профиля, ни их
последовательностей у консюмера нет.
"""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, ProgrammingError
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, AsyncSession

from src.infra.db_schemas import EHR_ROLE
from src.infra.patients_parameters import archive_and_upsert_patient_parameter
from tests.factories import Factory, unique_id
from tests.integration.db_isolation.test_permission_matrix import _sqlstate

_INSERT = text(
    "INSERT INTO risk_ehr.patients_parameters"
    " (patient_id, parameter_code, value, source, external_id, expiration_date, date_time)"
    " VALUES (:pid, :code, :value, :source, :external_id, :expiration, :dt)"
)
_LIVE = text(
    "SELECT value, source, external_id FROM risk_profile.patients_parameters"
    " WHERE patient_id = :pid AND parameter_code = :code"
)
_HISTORY = text(
    "SELECT value, source FROM risk_profile.patients_parameters_history"
    " WHERE patient_id = :pid AND parameter_code = :code ORDER BY patient_parameter_history_id"
)

_INSUFFICIENT_PRIVILEGE = "42501"


def _payload(patient_id: str, parameter_code: str, value: str, external_id: int, source: str = "EMR") -> dict:
    now = datetime.now(tz=UTC)
    return {
        "pid": patient_id,
        "code": parameter_code,
        "value": value,
        "source": source,
        "external_id": external_id,
        "expiration": now + timedelta(days=30),
        "dt": now,
    }


async def test_first_write_inserts_without_history(
    ehr_conn: AsyncConnection, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    patient_id, parameter_code = committed_patient

    await ehr_conn.execute(_INSERT, _payload(patient_id, parameter_code, "4.2", 100))
    await ehr_conn.commit()

    live = (await db_session.execute(_LIVE, {"pid": patient_id, "code": parameter_code})).all()
    assert [(row.value, row.source, row.external_id) for row in live] == [("4.2", "EMR", 100)]
    assert (await db_session.execute(_HISTORY, {"pid": patient_id, "code": parameter_code})).all() == []


async def test_replacement_archives_the_previous_value_atomically(
    ehr_conn: AsyncConnection, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    patient_id, parameter_code = committed_patient
    await ehr_conn.execute(_INSERT, _payload(patient_id, parameter_code, "4.2", 100))
    await ehr_conn.commit()

    await ehr_conn.execute(_INSERT, _payload(patient_id, parameter_code, "5.1", 101))
    await ehr_conn.commit()

    live = (await db_session.execute(_LIVE, {"pid": patient_id, "code": parameter_code})).all()
    assert [(row.value, row.external_id) for row in live] == [("5.1", 101)]
    history = (await db_session.execute(_HISTORY, {"pid": patient_id, "code": parameter_code})).all()
    assert [row.value for row in history] == ["4.2"]


async def test_trigger_writes_the_same_row_as_the_helper(
    ehr_conn: AsyncConnection, engine: AsyncEngine, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    """Копия правила записи в БД не разъехалась с оригиналом на Python.

    `risk_ehr.write_patient_parameter()` заморожена в теле миграции 0146 и правки
    `archive_and_upsert_patient_parameter` не подтягивает. Здесь обе реализации проходят один и
    тот же сценарий «значение, затем замена» на двух пациентах, и строки сравниваются целиком.
    Набор колонок сторожит `tests/unit/infra/test_ehr_write_trigger_parity.py`; этот тест —
    про поведение: что именно уезжает в историю и что остаётся живым.

    Пациент хелпера живёт в собственной транзакции и убирается до выхода из теста: держать его
    строки в незакоммиченной транзакции `db_session` нельзя — внешние ключи на пациента и на
    справочник параметров блокируют удаление тех же родительских строк в уборке
    `committed_patient`, а та идёт на другом соединении и раньше отката `db_session`.
    """
    patient_id, parameter_code = committed_patient
    first, second = _payload(patient_id, parameter_code, "4.2", 100), _payload(patient_id, parameter_code, "5.1", 101)

    for payload in (first, second):
        await ehr_conn.execute(_INSERT, payload)
        await ehr_conn.commit()

    helper_patient_id = unique_id("helper")
    async with _helper_patient(engine, helper_patient_id):
        for payload in (first, second):
            await _write_through_helper(engine, helper_patient_id, parameter_code, payload)

        trigger_rows = await _written_rows(db_session, patient_id, parameter_code)
        helper_rows = await _written_rows(db_session, helper_patient_id, parameter_code)
        assert trigger_rows == helper_rows


@asynccontextmanager
async def _helper_patient(engine: AsyncEngine, patient_id: str) -> AsyncIterator[None]:
    """Закоммиченный пациент под запись хелпером и уборка за ним на выходе."""
    async with engine.connect() as connection:
        session = AsyncSession(connection, expire_on_commit=False)
        await Factory(session).patient(patient_id=patient_id)
        await session.commit()
    try:
        yield
    finally:
        async with engine.begin() as connection:
            for table in (
                "risk_profile.patients_parameters_history",
                "risk_profile.patients_parameters",
                "risk_profile.patients",
            ):
                await connection.execute(text(f"DELETE FROM {table} WHERE patient_id = :pid"), {"pid": patient_id})


async def _write_through_helper(engine: AsyncEngine, patient_id: str, parameter_code: str, payload: dict) -> None:
    """Один вызов хелпера в собственной транзакции — ровно как его зовёт прикладной слой."""
    async with engine.connect() as connection:
        session = AsyncSession(connection, expire_on_commit=False)
        await archive_and_upsert_patient_parameter(
            session,
            patient_id=patient_id,
            parameter_code=parameter_code,
            value=payload["value"],
            source=payload["source"],
            external_id=payload["external_id"],
            expiration_date=payload["expiration"],
            date_time=payload["dt"],
        )
        await session.commit()


_WRITTEN = text(
    "SELECT value, source, external_id, expiration_date, date_time, false AS archived"
    "  FROM risk_profile.patients_parameters WHERE patient_id = :pid AND parameter_code = :code"
    " UNION ALL "
    "SELECT value, source, external_id, expiration_date, date_time, true AS archived"
    "  FROM risk_profile.patients_parameters_history WHERE patient_id = :pid AND parameter_code = :code"
    " ORDER BY archived, date_time, value"
)


async def _written_rows(db_session: AsyncSession, patient_id: str, parameter_code: str) -> list[tuple]:
    """Живая строка и история одним набором: расхождение любой из двух половин видно сразу."""
    result = await db_session.execute(_WRITTEN, {"pid": patient_id, "code": parameter_code})
    return [tuple(row) for row in result.all()]


async def test_unknown_patient_is_rejected_and_nothing_is_written(
    ehr_conn: AsyncConnection, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    _, parameter_code = committed_patient
    stranger = unique_id("nobody")

    with pytest.raises(IntegrityError):
        await ehr_conn.execute(_INSERT, _payload(stranger, parameter_code, "4.2", 102))
    await ehr_conn.rollback()

    assert (await db_session.execute(_LIVE, {"pid": stranger, "code": parameter_code})).all() == []
    assert (await db_session.execute(_HISTORY, {"pid": stranger, "code": parameter_code})).all() == []


async def test_foreign_source_is_rejected(
    ehr_conn: AsyncConnection, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    """Представление принимает только значения из ЭМК: чужим источником через него не пройти."""
    patient_id, parameter_code = committed_patient

    with pytest.raises(IntegrityError):
        await ehr_conn.execute(_INSERT, _payload(patient_id, parameter_code, "4.2", 103, source="QUESTIONNAIRE"))
    await ehr_conn.rollback()

    assert (await db_session.execute(_LIVE, {"pid": patient_id, "code": parameter_code})).all() == []


async def test_failed_write_leaves_no_history_row(
    ehr_conn: AsyncConnection, db_session: AsyncSession, committed_patient: tuple[str, str]
) -> None:
    """Архивация и upsert — одна операция: отказ на второй половине отменяет первую."""
    patient_id, parameter_code = committed_patient
    await ehr_conn.execute(_INSERT, _payload(patient_id, parameter_code, "4.2", 104))
    await ehr_conn.commit()

    # Несуществующий параметр: строка не пройдёт внешний ключ уже после копии в историю.
    with pytest.raises(IntegrityError):
        await ehr_conn.execute(_INSERT, _payload(patient_id, unique_id("MISSING"), "9.9", 105))
    await ehr_conn.rollback()

    history = (await db_session.execute(_HISTORY, {"pid": patient_id, "code": parameter_code})).all()
    assert history == [], "откат обязан унести и архивную строку"


async def test_ehr_login_has_no_access_to_the_underlying_sequence(ehr_conn: AsyncConnection) -> None:
    """Прав на последовательность у консюмера нет — id выдаёт триггер от имени владельца."""
    with pytest.raises(ProgrammingError) as error:
        await ehr_conn.execute(text("SELECT nextval('risk_profile.patients_parameters_patient_parameter_id_seq')"))
    assert _sqlstate(error.value) == _INSUFFICIENT_PRIVILEGE
    await ehr_conn.rollback()


async def test_ehr_login_has_no_execute_right_on_the_trigger_function(ehr_conn: AsyncConnection) -> None:
    """Функция достижима только через триггер представления: прямого права вызова у логина нет.

    Проверяем ACL, а не сам вызов: триггерную функцию нельзя вызвать выражением в принципе,
    и такой тест падал бы по другой причине, ничего не сказав про права.
    """
    granted = (
        await ehr_conn.execute(
            text("SELECT has_function_privilege(:role, 'risk_ehr.write_patient_parameter()', 'EXECUTE')"),
            {"role": EHR_ROLE},
        )
    ).scalar_one()
    assert granted is False
    await ehr_conn.rollback()
