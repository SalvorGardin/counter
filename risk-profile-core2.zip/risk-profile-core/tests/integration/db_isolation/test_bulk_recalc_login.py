"""Границы логина продюсера массового пересчёта.

Продюсер выбирает когорту устаревших профилей — для этого ему нужно ровно одно право: чтение
реестра версий расчёта. Под логином расчёта он получил бы заодно право переписать результаты
любого пациента, поэтому роль своя, и здесь проверяется, что она действительно узкая.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.exc import ProgrammingError
from sqlalchemy.ext.asyncio import AsyncConnection

from src.infra.db_schemas import CALCULATION_SCHEMA, PROFILE_SCHEMA

pytestmark = pytest.mark.db

_REGISTRY = f"{CALCULATION_SCHEMA}.patient_calculation_versions"


async def _allowed(connection: AsyncConnection, statement: str) -> None:
    await connection.execute(text(f"EXPLAIN {statement}"))


async def _denied(connection: AsyncConnection, statement: str) -> None:
    with pytest.raises(ProgrammingError, match="permission denied|does not exist"):
        await connection.execute(text(f"EXPLAIN {statement}"))
    await connection.rollback()


async def test_producer_reads_the_version_registry(bulk_recalc_conn: AsyncConnection) -> None:
    await _allowed(bulk_recalc_conn, f"SELECT patient_id FROM {_REGISTRY}")


async def test_producer_cannot_write_the_version_registry(bulk_recalc_conn: AsyncConnection) -> None:
    """Реестр пишет расчёт: продюсер, проставляющий версии сам, объявил бы сделанной работу,
    которой не было."""
    await _denied(bulk_recalc_conn, f"DELETE FROM {_REGISTRY}")
    await _denied(bulk_recalc_conn, f"UPDATE {_REGISTRY} SET calculation_version = 'x'")


async def test_producer_cannot_touch_results_or_interpretations(bulk_recalc_conn: AsyncConnection) -> None:
    for table in ("results", "interpretations", "results_history", "interpretations_history"):
        await _denied(bulk_recalc_conn, f"SELECT * FROM {CALCULATION_SCHEMA}.{table}")
        await _denied(bulk_recalc_conn, f"DELETE FROM {CALCULATION_SCHEMA}.{table}")


async def test_producer_cannot_read_patient_data(bulk_recalc_conn: AsyncConnection) -> None:
    """Когорта — это список идентификаторов, и ответы пациента продюсеру не нужны ни для чего."""
    for table in ("patients", "patients_parameters"):
        await _denied(bulk_recalc_conn, f"SELECT * FROM {PROFILE_SCHEMA}.{table}")
