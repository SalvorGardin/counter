"""Подключения под настоящими рантайм-логинами стенда.

Границу прав можно проверить только под теми же логинами, что и в проде: суперпользователь
кластера прошёл бы любую проверку и доказал бы ровно ничего. Соединения отдельные от
`db_session` (у того своя транзакция суперпользователя), поэтому тесты пишут коммитами и
сами убирают за собой по уникальному `patient_id`.
"""

from collections.abc import AsyncGenerator
from dataclasses import dataclass

import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, AsyncSession, create_async_engine

from src.infra.db_schemas import BULK_RECALC_ROLE, CALCULATION_ROLE, EHR_ROLE, PROFILE_ROLE
from tests.factories import Factory, unique_id


async def _connect(url: str) -> AsyncGenerator[AsyncConnection, None]:
    engine = create_async_engine(url)
    try:
        async with engine.connect() as connection:
            yield connection
    finally:
        await engine.dispose()


@pytest_asyncio.fixture(loop_scope="session")
async def profile_conn(runtime_db_urls) -> AsyncGenerator[AsyncConnection, None]:
    async for connection in _connect(runtime_db_urls.async_url(PROFILE_ROLE)):
        yield connection


@pytest_asyncio.fixture(loop_scope="session")
async def calculation_conn(runtime_db_urls) -> AsyncGenerator[AsyncConnection, None]:
    async for connection in _connect(runtime_db_urls.async_url(CALCULATION_ROLE)):
        yield connection


@pytest_asyncio.fixture(loop_scope="session")
async def ehr_conn(runtime_db_urls) -> AsyncGenerator[AsyncConnection, None]:
    async for connection in _connect(runtime_db_urls.async_url(EHR_ROLE)):
        yield connection


@pytest_asyncio.fixture(loop_scope="session")
async def bulk_recalc_conn(runtime_db_urls) -> AsyncGenerator[AsyncConnection, None]:
    """Логин продюсера массового пересчёта: ему выдано только чтение реестра версий."""
    async for connection in _connect(runtime_db_urls.async_url(BULK_RECALC_ROLE)):
        yield connection


@pytest_asyncio.fixture(loop_scope="session")
async def runtime_conns(
    profile_conn: AsyncConnection,
    calculation_conn: AsyncConnection,
    ehr_conn: AsyncConnection,
) -> dict[str, AsyncConnection]:
    """Все три логина разом: параметризовать тест именами async-фикстур pytest не даёт."""
    return {PROFILE_ROLE: profile_conn, CALCULATION_ROLE: calculation_conn, EHR_ROLE: ehr_conn}


@pytest_asyncio.fixture(loop_scope="session")
async def committed_patient(engine: AsyncEngine) -> AsyncGenerator[tuple[str, str], None]:
    """Пациент и параметр, ЗАКОММИЧЕННЫЕ в БД: их должно быть видно с другого соединения.

    Обычный `db_session` живёт в савпоинте внутри отката — его `commit()` наружу ничего не
    отдаёт, и подключение под логином ЭМК этих строк не увидело бы. Здесь нужна настоящая
    транзакция, поэтому за собой убираем сами.
    """
    patient_id, parameter_code = unique_id("ehr"), unique_id("PRM")
    async with engine.connect() as connection:
        session = AsyncSession(connection, expire_on_commit=False)
        factory = Factory(session)
        await factory.patient(patient_id=patient_id)
        await factory.parameter(code=parameter_code)
        await session.commit()
    try:
        yield patient_id, parameter_code
    finally:
        async with engine.begin() as connection:
            # Порядок от зависимых к родителю: внешние ключи на пациента стоят с RESTRICT.
            for statement in (
                "DELETE FROM risk_calculation.risk_factor_matches WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.interpretation_statuses WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.calculation_statuses WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.interpretations_history WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.interpretations WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.results_history WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.results WHERE patient_id = :pid",
                "DELETE FROM risk_profile.patients_parameters_history WHERE patient_id = :pid",
                "DELETE FROM risk_profile.patients_parameters WHERE patient_id = :pid",
                "DELETE FROM risk_profile.patients WHERE patient_id = :pid",
            ):
                await connection.execute(text(statement), {"pid": patient_id})
            await connection.execute(
                text("DELETE FROM catalog.parameters WHERE code = :code"), {"code": parameter_code}
            )


@dataclass(frozen=True)
class ArchivalCase:
    """Посчитанное пациенту: по паре строк результатов и интерпретаций, одну из каждой архивируем."""

    patient_id: str
    archived_instrument: str
    kept_instrument: str
    archived_system: str
    kept_system: str


@pytest_asyncio.fixture(loop_scope="session")
async def committed_archival_case(engine: AsyncEngine) -> AsyncGenerator[ArchivalCase, None]:
    """Результаты и интерпретации, ЗАКОММИЧЕННЫЕ суперпользователем стенда.

    Профильный логин собрать эту сцену не может: писать в расчётные таблицы ему не положено, а
    справочники доступны только на чтение. Поэтому arrange идёт отдельным соединением и коммитом
    — иначе архивация с соединения `risk_profile_app` не увидела бы ни одной строки.
    """
    case = ArchivalCase(
        patient_id=unique_id("arch"),
        archived_instrument=unique_id("INS"),
        kept_instrument=unique_id("INS"),
        archived_system=unique_id("SYS"),
        kept_system=unique_id("SYS"),
    )
    async with engine.connect() as connection:
        session = AsyncSession(connection, expire_on_commit=False)
        factory = Factory(session)
        await factory.patient(patient_id=case.patient_id)
        for instrument, indicator in ((case.archived_instrument, "a"), (case.kept_instrument, "b")):
            await factory.instrument(instrument)
            await factory.result(patient_id=case.patient_id, instrument_code=instrument, indicator=indicator)
        for system, risk_level in ((case.archived_system, "high"), (case.kept_system, "low")):
            await factory.system(system)
            await factory.interpretation(patient_id=case.patient_id, system_code=system, risk_level=risk_level)
        await session.commit()
    try:
        yield case
    finally:
        async with engine.begin() as connection:
            for statement in (
                "DELETE FROM risk_calculation.results_history WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.results WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.interpretations_history WHERE patient_id = :pid",
                "DELETE FROM risk_calculation.interpretations WHERE patient_id = :pid",
                "DELETE FROM risk_profile.patients WHERE patient_id = :pid",
            ):
                await connection.execute(text(statement), {"pid": case.patient_id})
            await connection.execute(
                text("DELETE FROM catalog.instruments WHERE code = ANY(:codes)"),
                {"codes": [case.archived_instrument, case.kept_instrument]},
            )
            await connection.execute(
                text("DELETE FROM catalog.systems WHERE code = ANY(:codes)"),
                {"codes": [case.archived_system, case.kept_system]},
            )
