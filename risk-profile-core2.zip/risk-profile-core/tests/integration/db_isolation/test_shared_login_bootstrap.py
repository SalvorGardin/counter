"""Выдача общего логина: право переключиться в рантайм-логины без наследования их прав.

Прогон идёт в отдельном кластере PostgreSQL: полный бутстрап перезаписывает пароли логинов, на которых
держится сессионный стенд.
"""

import asyncio
import secrets
from collections.abc import Generator

import pytest
from pydantic import SecretStr
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url

from src.infra.db_bootstrap import RoleCredentials, SharedLoginRefusedError, bootstrap_roles_at_url
from src.infra.db_schemas import (
    BULK_RECALC_ROLE,
    CALCULATION_ROLE,
    EHR_ROLE,
    MIGRATION_ROLE,
    PROFILE_ROLE,
    PROFILE_SCHEMA,
    SCHEMA_OWNER_ROLES,
)
from tests.postgres import postgres_server

pytestmark = pytest.mark.db

# Членство общего логина: какие роли, с какими опциями (PostgreSQL 16: inherit_option, set_option).
_MEMBERSHIPS = text("""
    SELECT granted.rolname, m.inherit_option, m.set_option, m.admin_option
      FROM pg_auth_members AS m
      JOIN pg_roles AS granted ON granted.oid = m.roleid
      JOIN pg_roles AS member ON member.oid = m.member
     WHERE member.rolname = :member
     ORDER BY granted.rolname
""")


@pytest.fixture
def admin_url() -> Generator[str, None, None]:
    with postgres_server() as url:
        yield url


def _credentials() -> RoleCredentials:
    return RoleCredentials(
        profile=SecretStr(secrets.token_urlsafe(24)),
        calculation=SecretStr(secrets.token_urlsafe(24)),
        ehr=SecretStr(secrets.token_urlsafe(24)),
        bulk_recalc=SecretStr(secrets.token_urlsafe(24)),
        migrations=SecretStr(secrets.token_urlsafe(24)),
    )


def _bootstrap(admin_url: str, credentials: RoleCredentials, shared_login: str | None) -> None:
    asyncio.run(
        bootstrap_roles_at_url(
            admin_url, credentials, legacy_owner=make_url(admin_url).username, shared_login=shared_login
        )
    )


def _memberships(admin_url: str, member: str) -> list[tuple[str, bool, bool, bool]]:
    engine = create_engine(admin_url)
    try:
        with engine.connect() as connection:
            return [tuple(row) for row in connection.execute(_MEMBERSHIPS, {"member": member})]
    finally:
        engine.dispose()


def _role_exists(admin_url: str, role: str) -> bool:
    engine = create_engine(admin_url)
    try:
        with engine.connect() as connection:
            return connection.execute(
                text("SELECT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :role)"), {"role": role}
            ).scalar_one()
    finally:
        engine.dispose()


def test_shared_login_can_switch_to_other_runtime_logins_without_inheriting(admin_url: str) -> None:
    """Повторный прогон ничего не добавляет и не ломает: выдача идемпотентна."""
    credentials = _credentials()

    _bootstrap(admin_url, credentials, shared_login=PROFILE_ROLE)
    _bootstrap(admin_url, credentials, shared_login=PROFILE_ROLE)

    assert _memberships(admin_url, PROFILE_ROLE) == [
        (BULK_RECALC_ROLE, False, True, False),
        (CALCULATION_ROLE, False, True, False),
        (EHR_ROLE, False, True, False),
    ]


def test_runtime_logins_get_no_membership_without_a_shared_login(admin_url: str) -> None:
    _bootstrap(admin_url, _credentials(), shared_login=None)

    assert _memberships(admin_url, PROFILE_ROLE) == []


@pytest.mark.parametrize("shared_login", [MIGRATION_ROLE, SCHEMA_OWNER_ROLES[PROFILE_SCHEMA], "risk_no_such_login"])
def test_forbidden_shared_login_is_refused_without_changes(admin_url: str, shared_login: str) -> None:
    """Отказ — до изменений или в той же транзакции: ни ролей, ни членства после него нет."""
    with pytest.raises(SharedLoginRefusedError, match=shared_login):
        _bootstrap(admin_url, _credentials(), shared_login=shared_login)

    assert not _role_exists(admin_url, PROFILE_ROLE)
    assert not _role_exists(admin_url, MIGRATION_ROLE)
