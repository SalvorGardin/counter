"""Процесс отказывается стартовать под чужим логином БД.

Роль и карту схем объявляет точка входа, логин приносит строка подключения из переменной роли.
Это два независимых значения, и совпадать они обязаны: карта только переименовывает объекты в
запросе, границу между сервисами держат права логина. Подставленный по ошибке
`deploy/db/migrations.env` поднял бы API под `risk_migrations` — членом всех ролей-владельцев,
видящим все физические таблицы мимо изоляции, — и ничего бы не упало заметным образом.
"""

import pytest
from pydantic import SecretStr
from sqlalchemy.ext.asyncio import create_async_engine

from src.config import ServiceRuntime
from src.infra.database import (
    ServiceRuntimeMismatchError,
    init_primary_runtime,
    shutdown_primary_runtime,
    verify_runtime_login,
)
from src.infra.db_schemas import BULK_RECALC_ROLE, CALCULATION_ROLE, EHR_ROLE, MIGRATION_ROLE, PROFILE_ROLE

pytestmark = pytest.mark.db

_EXPECTED = {
    ServiceRuntime.PROFILE: PROFILE_ROLE,
    ServiceRuntime.CALCULATION: CALCULATION_ROLE,
    ServiceRuntime.EHR: EHR_ROLE,
    ServiceRuntime.BULK_RECALC: BULK_RECALC_ROLE,
}


@pytest.mark.parametrize("runtime", list(_EXPECTED))
async def test_each_runtime_accepts_its_own_login(runtime: ServiceRuntime, runtime_db_urls) -> None:
    engine = create_async_engine(runtime_db_urls.async_url(_EXPECTED[runtime]))
    try:
        await verify_runtime_login(engine, runtime)
    finally:
        await engine.dispose()


async def test_the_migration_login_is_rejected_by_every_runtime(runtime_db_urls) -> None:
    """Именно тот случай, ради которого проверка и нужна: чужой env-файл вместо своего."""
    engine = create_async_engine(runtime_db_urls.async_url(MIGRATION_ROLE))
    try:
        for runtime in _EXPECTED:
            with pytest.raises(ServiceRuntimeMismatchError, match=MIGRATION_ROLE):
                await verify_runtime_login(engine, runtime)
    finally:
        await engine.dispose()


async def test_a_runtime_is_rejected_under_another_runtimes_login(runtime_db_urls) -> None:
    engine = create_async_engine(runtime_db_urls.async_url(CALCULATION_ROLE))
    try:
        with pytest.raises(ServiceRuntimeMismatchError, match=PROFILE_ROLE):
            await verify_runtime_login(engine, ServiceRuntime.PROFILE)
    finally:
        await engine.dispose()


async def test_the_bulk_recalc_producer_is_rejected_under_the_calculation_login(runtime_db_urls) -> None:
    """Логин расчёта дал бы продюсеру прогона право переписать результаты любого пациента —
    ровно то, ради чего у роли собственный логин."""
    engine = create_async_engine(runtime_db_urls.async_url(CALCULATION_ROLE))
    try:
        with pytest.raises(ServiceRuntimeMismatchError, match=BULK_RECALC_ROLE):
            await verify_runtime_login(engine, ServiceRuntime.BULK_RECALC)
    finally:
        await engine.dispose()


@pytest.mark.usefixtures("no_primary_runtime")
async def test_own_variable_holding_another_identitys_login_is_rejected(runtime_db_urls, monkeypatch) -> None:
    """`RISK_MODEL_EHR_DB_URL` с логином профиля: консюмер ЭМК падает на старте, называя переменную."""
    monkeypatch.setattr("src.config.settings.ehr_db_url", SecretStr(runtime_db_urls.async_url(PROFILE_ROLE)))
    runtime = init_primary_runtime(ServiceRuntime.EHR)
    try:
        with pytest.raises(ServiceRuntimeMismatchError, match="RISK_MODEL_EHR_DB_URL"):
            await verify_runtime_login(runtime.engine, ServiceRuntime.EHR)
    finally:
        await shutdown_primary_runtime()


@pytest.mark.usefixtures("no_primary_runtime")
async def test_legacy_url_with_the_profile_login_does_not_affect_the_ehr_consumer(runtime_db_urls, monkeypatch) -> None:
    """Прежняя общая переменная в пуле пода больше не читается: консюмер ЭМК идёт по своей."""
    monkeypatch.setenv("RISK_MODEL_DB_URL", runtime_db_urls.async_url(PROFILE_ROLE))
    monkeypatch.setenv("RISK_MODEL_SERVICE_RUNTIME", "profile")
    monkeypatch.setattr("src.config.settings.ehr_db_url", SecretStr(runtime_db_urls.async_url(EHR_ROLE)))
    runtime = init_primary_runtime(ServiceRuntime.EHR)
    try:
        await verify_runtime_login(runtime.engine, ServiceRuntime.EHR)
    finally:
        await shutdown_primary_runtime()
