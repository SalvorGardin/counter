"""Матрица прав рантайм-логинов: что каждому разрешено и что ему обязана запретить БД.

Тесты ходят под настоящими логинами (`risk_profile_app`, `risk_calculation_app`, `risk_ehr_app`),
а не под суперпользователем кластера: иначе они доказывали бы обратное утверждаемому.
Разрешённые операции проверяются планированием запроса (`EXPLAIN`) там, где выполнение писало бы
данные, — право доступа проверяется до исполнения плана и никаких строк при этом не появляется.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, ProgrammingError
from sqlalchemy.ext.asyncio import AsyncConnection

from src.infra.db_schemas import (
    CALCULATION_LOCAL_VIEWS,
    CALCULATION_SCHEMA,
    CALCULATION_TABLES,
    CATALOG_SCHEMA,
    EHR_SCHEMA,
    PROFILE_LOCAL_VIEWS,
    PROFILE_SCHEMA,
    PROFILE_TABLES,
    RUNTIME_ROLES,
)
from tests.factories import unique_id

_INSUFFICIENT_PRIVILEGE = "42501"


def _sqlstate(error: DBAPIError) -> str | None:
    """Код ошибки PostgreSQL. `orig` у DBAPIError типизирован как Optional — достаём аккуратно."""
    return getattr(error.orig, "sqlstate", None)


async def _allowed(connection: AsyncConnection, statement: str) -> None:
    """План строится → права есть. Откат обязателен: EXPLAIN уже открыл транзакцию."""
    await connection.execute(text(f"EXPLAIN {statement}"))
    await connection.rollback()


async def _denied(connection: AsyncConnection, statement: str) -> None:
    with pytest.raises(ProgrammingError) as error:
        await connection.execute(text(f"EXPLAIN {statement}"))
    assert _sqlstate(error.value) == _INSUFFICIENT_PRIVILEGE, f"ожидали отказ в правах на: {statement}"
    await connection.rollback()


# ---------------------------------------------------------------- профильный логин


@pytest.mark.parametrize("table", PROFILE_TABLES)
async def test_profile_writes_its_own_tables(profile_conn: AsyncConnection, table: str) -> None:
    await _allowed(profile_conn, f"SELECT * FROM {PROFILE_SCHEMA}.{table}")
    await _allowed(profile_conn, f"DELETE FROM {PROFILE_SCHEMA}.{table}")


@pytest.mark.parametrize("view", sorted(PROFILE_LOCAL_VIEWS))
async def test_profile_reaches_calculated_data_only_through_its_views(profile_conn: AsyncConnection, view: str) -> None:
    operations = PROFILE_LOCAL_VIEWS[view]
    if "SELECT" in operations:
        await _allowed(profile_conn, f"SELECT * FROM {PROFILE_SCHEMA}.{view}")
    if "DELETE" in operations:
        await _allowed(profile_conn, f"DELETE FROM {PROFILE_SCHEMA}.{view}")
    # Та же таблица напрямую в чужой схеме — отказ, независимо от прав на представление.
    await _denied(profile_conn, f"SELECT * FROM {CALCULATION_SCHEMA}.{view}")


async def test_profile_cannot_delete_through_history_views(profile_conn: AsyncConnection) -> None:
    """История принимает только вставку: удалять архив профиль не должен уметь вовсе."""
    for view in ("results_history", "interpretations_history"):
        await _denied(profile_conn, f"DELETE FROM {PROFILE_SCHEMA}.{view}")
        await _denied(profile_conn, f"SELECT * FROM {PROFILE_SCHEMA}.{view}")


# Вставка в историю — единственная операция, которую нельзя проверить планом. `EXPLAIN` сверяет
# права на представление и на этом останавливается, а `nextval()` в DEFAULT ключа исполняется
# только при настоящей вставке — и проверяет USAGE на последовательности у ТЕКУЩЕГО пользователя,
# а не у владельца представления. Поэтому здесь запрос выполняется и откатывается.
_ARCHIVE_PATIENT = text(f"INSERT INTO {PROFILE_SCHEMA}.patients (patient_id) VALUES (:pid)")
_ARCHIVE_INSERTS = (
    text(
        f"INSERT INTO {PROFILE_SCHEMA}.results_history"
        " (instrument_code, patient_id, indicator, date_time, interpretation_status,"
        " expiration_date, applicability)"
        " SELECT code, :pid, 'archived', now(), 'done', now(), true FROM catalog.instruments LIMIT 1"
    ),
    text(
        f"INSERT INTO {PROFILE_SCHEMA}.interpretations_history (system_code, patient_id, date_time)"
        " SELECT code, :pid, now() FROM catalog.systems LIMIT 1"
    ),
)


async def test_profile_really_inserts_into_history_views(profile_conn: AsyncConnection) -> None:
    """Архивация под профильным логином доходит до строки в истории, а не только до плана запроса."""
    patient_id = unique_id("seq")
    await profile_conn.execute(_ARCHIVE_PATIENT, {"pid": patient_id})
    for statement in _ARCHIVE_INSERTS:
        result = await profile_conn.execute(statement, {"pid": patient_id})
        assert result.rowcount == 1
    await profile_conn.rollback()


# ---------------------------------------------------------------- логин расчёта


@pytest.mark.parametrize("table", CALCULATION_TABLES)
async def test_calculation_writes_its_own_tables(calculation_conn: AsyncConnection, table: str) -> None:
    await _allowed(calculation_conn, f"SELECT * FROM {CALCULATION_SCHEMA}.{table}")
    await _allowed(calculation_conn, f"DELETE FROM {CALCULATION_SCHEMA}.{table}")


@pytest.mark.parametrize("view", CALCULATION_LOCAL_VIEWS)
async def test_calculation_reads_patient_data_only_through_its_views(
    calculation_conn: AsyncConnection, view: str
) -> None:
    await _allowed(calculation_conn, f"SELECT * FROM {CALCULATION_SCHEMA}.{view}")
    # Представление даёт только чтение: правка данных пациента — не дело расчёта.
    await _denied(calculation_conn, f"DELETE FROM {CALCULATION_SCHEMA}.{view}")
    await _denied(calculation_conn, f"SELECT * FROM {PROFILE_SCHEMA}.{view}")


# ---------------------------------------------------------------- логин ЭМК


async def test_ehr_reads_through_its_views_only(ehr_conn: AsyncConnection) -> None:
    await _allowed(ehr_conn, f"SELECT * FROM {EHR_SCHEMA}.patients")
    await _allowed(ehr_conn, f"SELECT * FROM {EHR_SCHEMA}.patients_parameters")
    await _denied(ehr_conn, f"SELECT * FROM {PROFILE_SCHEMA}.patients")
    await _denied(ehr_conn, f"SELECT * FROM {PROFILE_SCHEMA}.patients_parameters")
    await _denied(ehr_conn, f"SELECT * FROM {PROFILE_SCHEMA}.patients_parameters_history")


async def test_ehr_cannot_update_or_delete_patient_parameters(ehr_conn: AsyncConnection) -> None:
    """Контракт представления — только вставка: правку и удаление БД обязана отвергнуть."""
    await _denied(ehr_conn, f"DELETE FROM {EHR_SCHEMA}.patients_parameters")
    await _denied(ehr_conn, f"UPDATE {EHR_SCHEMA}.patients_parameters SET value = 'x'")
    await _denied(ehr_conn, f"DELETE FROM {EHR_SCHEMA}.patients")


async def test_ehr_sees_nothing_of_the_calculation_schema(ehr_conn: AsyncConnection) -> None:
    await _denied(ehr_conn, f"SELECT * FROM {CALCULATION_SCHEMA}.results")


# ---------------------------------------------------------------- общий каталог


@pytest.mark.parametrize("role", RUNTIME_ROLES)
async def test_every_runtime_reads_catalogs_directly(role: str, runtime_conns: dict[str, AsyncConnection]) -> None:
    connection = runtime_conns[role]
    await _allowed(connection, f"SELECT * FROM {CATALOG_SCHEMA}.parameters")
    await _allowed(connection, f"SELECT * FROM {CATALOG_SCHEMA}.instruments")


@pytest.mark.parametrize("role", RUNTIME_ROLES)
async def test_no_runtime_may_change_a_catalog(role: str, runtime_conns: dict[str, AsyncConnection]) -> None:
    connection = runtime_conns[role]
    await _denied(connection, f"DELETE FROM {CATALOG_SCHEMA}.parameters")
    await _denied(connection, f"UPDATE {CATALOG_SCHEMA}.parameters SET description = 'x'")
    await _denied(connection, f"INSERT INTO {CATALOG_SCHEMA}.doctors (code, description) VALUES (999999, 'x')")


# ---------------------------------------------------------------- отсутствие права менять схему


@pytest.mark.parametrize("role", RUNTIME_ROLES)
@pytest.mark.parametrize("schema", [PROFILE_SCHEMA, CALCULATION_SCHEMA, EHR_SCHEMA, CATALOG_SCHEMA])
async def test_no_runtime_may_create_objects_in_an_application_schema(
    role: str, schema: str, runtime_conns: dict[str, AsyncConnection]
) -> None:
    connection = runtime_conns[role]
    with pytest.raises(ProgrammingError) as error:
        await connection.execute(text(f"CREATE TABLE {schema}.intruder (id integer)"))
    assert _sqlstate(error.value) == _INSUFFICIENT_PRIVILEGE
    await connection.rollback()


@pytest.mark.parametrize("role", RUNTIME_ROLES)
async def test_no_runtime_may_create_a_schema_or_a_role(role: str, runtime_conns: dict[str, AsyncConnection]) -> None:
    connection = runtime_conns[role]
    for statement in ("CREATE SCHEMA intruder", "CREATE ROLE intruder LOGIN"):
        with pytest.raises(ProgrammingError) as error:
            await connection.execute(text(statement))
        assert _sqlstate(error.value) == _INSUFFICIENT_PRIVILEGE
        await connection.rollback()
