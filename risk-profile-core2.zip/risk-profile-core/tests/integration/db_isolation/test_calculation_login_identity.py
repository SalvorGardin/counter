"""Расчёт в процессе API целиком идёт под логином расчёта, а не под логином процесса.

Таких путей два: инлайн-пересчёт при выключенной Kafka и синхронный запуск из testing-API
(`POST /testing/calculation/run`). Оба открывают не одну транзакцию: после коммита результатов
свои сессии открывают сбор статусов расчёта и сбор причин интерпретации вместе со сработавшими
факторами. Любая из них, взятая по умолчанию, ушла бы в БД под профильным логином — а ему на
таблицы расчёта выдан только `SELECT, DELETE` через представления.

Тесты записывают `current_user` КАЖДОЙ выданной сессии и требуют, чтобы все они были расчётными.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from src.calc import dispatcher
from src.calc.domain.models import CalculationRequest
from src.infra.catalog.builder import build_catalogs
from src.infra.database import create_calculation_runtime
from src.infra.db_schemas import CALCULATION_ROLE, CALCULATION_SCHEMA

pytestmark = pytest.mark.db


class _IdentityRecordingFactory:
    """Обёртка над фабрикой расчёта: на каждой выданной сессии спрашивает `current_user`."""

    def __init__(self, inner: async_sessionmaker[AsyncSession]) -> None:
        self._inner = inner
        self.identities: list[str] = []

    def __call__(self) -> "_RecordingSessionContext":
        return _RecordingSessionContext(self._inner(), self.identities)


class _RecordingSessionContext:
    def __init__(self, session_context, identities: list[str]) -> None:
        self._session_context = session_context
        self._identities = identities

    async def __aenter__(self) -> AsyncSession:
        session = await self._session_context.__aenter__()
        self._identities.append((await session.execute(text("SELECT current_user"))).scalar_one())
        return session

    async def __aexit__(self, *exc_info: object) -> None:
        await self._session_context.__aexit__(*exc_info)


@pytest.fixture
async def recording_calculation_runtime(runtime_db_urls, monkeypatch: pytest.MonkeyPatch):
    from pydantic import SecretStr

    runtime = create_calculation_runtime(SecretStr(runtime_db_urls.async_url(CALCULATION_ROLE)))
    recorder = _IdentityRecordingFactory(runtime.session_factory)
    monkeypatch.setattr(
        dispatcher,
        "init_calculation_runtime",
        lambda: type("_Runtime", (), {"session_factory": recorder})(),
    )
    yield recorder
    await runtime.dispose()


async def test_inline_recalc_uses_the_calculation_login_in_every_transaction(
    recording_calculation_runtime: _IdentityRecordingFactory,
    committed_patient: tuple[str, str],
    engine: AsyncEngine,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    patient_id, _ = committed_patient
    # Kafka выключена — работает инлайн-ветка; сбор диагностики включён, иначе его транзакции
    # не открылись бы вовсе и утверждение о них было бы пустым.
    monkeypatch.setattr(dispatcher.settings.kafka, "enabled", False)
    monkeypatch.setattr(dispatcher.settings, "calc_status_collection_enabled", True)

    await dispatcher.dispatch_recalc(patient_id, None)

    identities = recording_calculation_runtime.identities
    assert identities, "инлайн-ветка обязана открыть хотя бы одну сессию"
    assert set(identities) == {CALCULATION_ROLE}, f"нерасчётные личности в графе пересчёта: {set(identities)}"


async def test_inline_recalc_writes_diagnostics_under_the_calculation_login(
    recording_calculation_runtime: _IdentityRecordingFactory,
    committed_patient: tuple[str, str],
    engine: AsyncEngine,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Вспомогательные транзакции не просто открылись под нужной ролью — они реально записали."""
    patient_id, _ = committed_patient
    monkeypatch.setattr(dispatcher.settings.kafka, "enabled", False)
    monkeypatch.setattr(dispatcher.settings, "calc_status_collection_enabled", True)

    await dispatcher.dispatch_recalc(patient_id, None)

    async with engine.connect() as connection:
        statuses = (
            await connection.execute(
                text(f"SELECT count(*) FROM {CALCULATION_SCHEMA}.calculation_statuses WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).scalar_one()
    assert statuses > 0, "сбор статусов расчёта должен был записать строки своей транзакцией"
    # Больше одной сессии — значит после основной транзакции открывались собственные.
    assert len(recording_calculation_runtime.identities) > 1


async def test_testing_calculation_endpoint_runs_under_the_calculation_login(
    recording_calculation_runtime: _IdentityRecordingFactory,
    committed_patient: tuple[str, str],
    engine: AsyncEngine,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Запуск расчёта из testing-API пишет результаты, а у API-процесса логин профильный.

    Зависимости роутера собираются здесь руками: поднимать приложение целиком ради одной сессии
    не нужно, а проверяется именно то, откуда роутер берёт сессию и фабрику сессий.
    """
    from src.api.v1.testing.calculation import router as calculation_router

    monkeypatch.setattr(calculation_router, "init_calculation_runtime", dispatcher.init_calculation_runtime)
    monkeypatch.setattr(dispatcher.settings, "calc_status_collection_enabled", True)

    patient_id, _ = committed_patient
    sessions = calculation_router.get_calculation_session()
    session = await anext(sessions)
    catalogs = await build_catalogs(session)
    handler = calculation_router.get_calc_handler(session, catalogs.calc, catalogs.interpretation)
    try:
        await handler.run([CalculationRequest(patient_id=patient_id, instrument_codes=None)])
    finally:
        await sessions.aclose()

    identities = recording_calculation_runtime.identities
    assert identities, "эндпоинт обязан открыть хотя бы одну сессию"
    assert set(identities) == {CALCULATION_ROLE}, f"нерасчётные личности в графе расчёта: {set(identities)}"
