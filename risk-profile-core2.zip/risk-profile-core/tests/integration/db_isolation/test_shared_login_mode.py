"""Режим общего логина: процессы подключаются под одним логином и сразу переключаются в свой.

Стенд тестирования подключает все процессы под логином API. Консюмеры при этом обязаны работать
ровно с правами своих рантайм-логинов: не шире (права общего логина не наследуются) и не уже
(`verify_runtime_login` видит логин роли и проходит без изменений).

Членство общему логину выдаётся тем же полным бутстрапом, что и на стенде (`--shared-login`),
и снимается после модуля: остальные тесты работают со стендом, где логины не связаны.
"""

from collections.abc import AsyncGenerator

import pytest
import pytest_asyncio
from asyncpg.exceptions import InsufficientPrivilegeError
from pydantic import SecretStr
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.exc import ProgrammingError
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, create_async_engine

from src.config import ServiceRuntime
from src.infra.database import (
    RUNTIME_IDENTITIES,
    ServiceRuntimeMismatchError,
    create_database_runtime,
    verify_runtime_login,
)
from src.infra.db_bootstrap import RoleCredentials, bootstrap_roles_at_url
from src.infra.db_schemas import (
    BULK_RECALC_ROLE,
    CALCULATION_ROLE,
    CALCULATION_SCHEMA,
    EHR_ROLE,
    EHR_SCHEMA,
    MIGRATION_ROLE,
    PROFILE_ROLE,
    PROFILE_SCHEMA,
)

pytestmark = pytest.mark.db

_INSUFFICIENT_PRIVILEGE = "42501"


@pytest_asyncio.fixture(scope="module", loop_scope="session")
async def shared_profile_login(runtime_db_urls) -> AsyncGenerator[str, None]:
    """Логин API становится общим: повторный полный бутстрап с `shared_login`, пароли прежние."""
    passwords = runtime_db_urls.passwords
    credentials = RoleCredentials(
        profile=passwords[PROFILE_ROLE],
        calculation=passwords[CALCULATION_ROLE],
        ehr=passwords[EHR_ROLE],
        bulk_recalc=passwords[BULK_RECALC_ROLE],
        migrations=passwords[MIGRATION_ROLE],
    )
    admin_url = runtime_db_urls.base_sync_url
    await bootstrap_roles_at_url(
        admin_url, credentials, legacy_owner=make_url(admin_url).username, shared_login=PROFILE_ROLE
    )
    try:
        yield runtime_db_urls.async_url(PROFILE_ROLE)
    finally:
        engine = create_engine(admin_url)
        try:
            with engine.begin() as connection:
                connection.execute(
                    text(f"REVOKE {CALCULATION_ROLE}, {EHR_ROLE}, {BULK_RECALC_ROLE} FROM {PROFILE_ROLE}")
                )
        finally:
            engine.dispose()


@pytest.fixture
def assume_runtime_role(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("src.infra.database.settings.db_assume_runtime_role", True)


def _runtime_engine(runtime: ServiceRuntime, url: str) -> AsyncEngine:
    return create_database_runtime(RUNTIME_IDENTITIES[runtime], SecretStr(url)).engine


async def _current_user(engine: AsyncEngine) -> str:
    async with engine.connect() as connection:
        return (await connection.execute(text("SELECT current_user"))).scalar_one()


async def _allowed(connection: AsyncConnection, statement: str) -> None:
    """План строится → права есть. Право проверяется до исполнения плана, строк не появляется."""
    await connection.execute(text(f"EXPLAIN {statement}"))
    await connection.rollback()


async def _denied(connection: AsyncConnection, statement: str) -> None:
    with pytest.raises(ProgrammingError) as error:
        await connection.execute(text(f"EXPLAIN {statement}"))
    assert getattr(error.value.orig, "sqlstate", None) == _INSUFFICIENT_PRIVILEGE, statement
    await connection.rollback()


@pytest.mark.usefixtures("assume_runtime_role")
@pytest.mark.parametrize("runtime", [ServiceRuntime.EHR, ServiceRuntime.CALCULATION])
async def test_consumer_under_the_api_login_passes_the_login_check(
    shared_profile_login: str, runtime: ServiceRuntime
) -> None:
    engine = _runtime_engine(runtime, shared_profile_login)
    try:
        await verify_runtime_login(engine, runtime)
        assert await _current_user(engine) == RUNTIME_IDENTITIES[runtime].login
    finally:
        await engine.dispose()


@pytest.mark.usefixtures("assume_runtime_role")
async def test_ehr_consumer_under_the_api_login_has_exactly_the_ehr_privileges(shared_profile_login: str) -> None:
    engine = _runtime_engine(ServiceRuntime.EHR, shared_profile_login)
    try:
        async with engine.connect() as connection:
            await _allowed(connection, f"SELECT * FROM {EHR_SCHEMA}.patients")
            await _allowed(
                connection,
                f"INSERT INTO {EHR_SCHEMA}.patients_parameters SELECT * FROM {EHR_SCHEMA}.patients_parameters",
            )
            await _denied(connection, f"DELETE FROM {EHR_SCHEMA}.patients_parameters")
            # Права профиля, под логином которого процесс подключился, консюмеру не достаются.
            await _denied(connection, f"SELECT * FROM {PROFILE_SCHEMA}.patients")
            await _denied(connection, f"SELECT * FROM {CALCULATION_SCHEMA}.results")
    finally:
        await engine.dispose()


@pytest.mark.usefixtures("assume_runtime_role")
async def test_calculation_consumer_under_the_api_login_has_exactly_the_calculation_privileges(
    shared_profile_login: str,
) -> None:
    engine = _runtime_engine(ServiceRuntime.CALCULATION, shared_profile_login)
    try:
        async with engine.connect() as connection:
            await _allowed(connection, f"DELETE FROM {CALCULATION_SCHEMA}.results")
            await _allowed(connection, f"SELECT * FROM {CALCULATION_SCHEMA}.patients")
            await _denied(connection, f"SELECT * FROM {PROFILE_SCHEMA}.patients")
            await _denied(connection, f"DELETE FROM {PROFILE_SCHEMA}.patients_parameters")
            await _denied(connection, f"SELECT * FROM {EHR_SCHEMA}.patients")
    finally:
        await engine.dispose()


async def test_shared_login_without_switching_has_none_of_the_other_privileges(shared_profile_login: str) -> None:
    """`INHERIT FALSE`: членство даёт право переключиться, а не права рантаймов."""
    engine = create_async_engine(shared_profile_login)
    try:
        async with engine.connect() as connection:
            await _denied(connection, f"DELETE FROM {CALCULATION_SCHEMA}.results")
            await _denied(connection, f"SELECT * FROM {CALCULATION_SCHEMA}.patients")
            await _denied(connection, f"SELECT * FROM {EHR_SCHEMA}.patients")
    finally:
        await engine.dispose()


@pytest.mark.usefixtures("assume_runtime_role")
async def test_login_without_membership_cannot_start(runtime_db_urls) -> None:
    """Флаг включён, а членства нет: соединение отклоняется, и ошибка называет роль."""
    engine = _runtime_engine(ServiceRuntime.EHR, runtime_db_urls.async_url(BULK_RECALC_ROLE))
    try:
        # Отказ приходит при открытии соединения, до SQLAlchemy-обёртки: исключение драйвера.
        with pytest.raises(InsufficientPrivilegeError, match=f'permission denied to set role "{EHR_ROLE}"'):
            await verify_runtime_login(engine, ServiceRuntime.EHR)
    finally:
        await engine.dispose()


async def test_mode_disabled_rejects_a_foreign_login(shared_profile_login: str, monkeypatch) -> None:
    """Без флага сессия остаётся под логином подключения, даже если членство выдано."""
    monkeypatch.setattr("src.infra.database.settings.db_assume_runtime_role", False)
    engine = _runtime_engine(ServiceRuntime.EHR, shared_profile_login)
    try:
        with pytest.raises(ServiceRuntimeMismatchError, match=PROFILE_ROLE):
            await verify_runtime_login(engine, ServiceRuntime.EHR)
    finally:
        await engine.dispose()


@pytest.mark.usefixtures("assume_runtime_role")
async def test_role_survives_rollback_and_pool_reuse(shared_profile_login: str) -> None:
    """Роль задана при открытии соединения, вне транзакции: откат её не снимает."""
    engine = _runtime_engine(ServiceRuntime.EHR, shared_profile_login)
    try:
        async with engine.connect() as connection:
            backend_pid = (await connection.execute(text("SELECT pg_backend_pid()"))).scalar_one()
            await connection.rollback()
            assert (await connection.execute(text("SELECT current_user"))).scalar_one() == EHR_ROLE
        # То же соединение, выданное пулом повторно: серверный процесс тот же.
        async with engine.connect() as connection:
            reused_pid, session_user, current_user = (
                await connection.execute(text("SELECT pg_backend_pid(), session_user, current_user"))
            ).one()
        assert reused_pid == backend_pid
        assert (session_user, current_user) == (PROFILE_ROLE, EHR_ROLE)
    finally:
        await engine.dispose()
