"""Архивация и удаление посчитанного идут через профильные представления, одной транзакцией.

Профильный процесс не имеет прав на физические таблицы расчёта: и `DELETE ... RETURNING`, и
последующая вставка в историю адресуют представления в `risk_profile`. Боевой `RiskEventWriter`
гоняется под настоящим логином `risk_profile_app` (`profile_conn`) — адресация представлений
без прав доказывала бы половину утверждения: суперпользователь стенда проходит любую проверку,
и отказ на `nextval()` в истории прошёл бы мимо такого теста.

Арранж и ассерты идут отдельным соединением суперпользователя: профильному логину не положено
ни писать в расчётные таблицы, ни читать историю (`results_history` выдан только INSERT).
"""

import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError, ProgrammingError
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, AsyncSession

from src.config import ServiceRuntime
from src.infra.db_schemas import PROFILE_SCHEMA_MAP
from src.services.risk_event.infra.writer import RiskEventWriter
from tests.factories import Factory, unique_id
from tests.integration.db_isolation.conftest import ArchivalCase
from tests.integration.db_isolation.test_permission_matrix import _sqlstate

# Маркер нужен тестам на `db_session`: без карты схем модели расчёта адресовали бы физические
# таблицы мимо представлений. Тесты на `profile_conn` карту ставят себе сами.
pytestmark = pytest.mark.db_role(ServiceRuntime.PROFILE)


async def _profile_session(connection: AsyncConnection) -> AsyncSession:
    """Сессия профильного рантайма: тот же логин и та же карта схем, что в API-процессе."""
    mapped = await connection.execution_options(schema_translate_map=dict(PROFILE_SCHEMA_MAP))
    return AsyncSession(mapped, expire_on_commit=False)


_RESULT_HISTORY = text(
    "SELECT instrument_code, value, indicator FROM risk_calculation.results_history"
    " WHERE patient_id = :pid ORDER BY instrument_code"
)
_LIVE_RESULTS = text("SELECT count(*) FROM risk_calculation.results WHERE patient_id = :pid")
_INTERPRETATION_HISTORY = text(
    "SELECT system_code, risk_level FROM risk_calculation.interpretations_history WHERE patient_id = :pid"
)
_LIVE_INTERPRETATIONS = text("SELECT count(*) FROM risk_calculation.interpretations WHERE patient_id = :pid")


async def test_results_archival_moves_exactly_the_deleted_rows(
    profile_conn: AsyncConnection, engine: AsyncEngine, committed_archival_case: ArchivalCase
) -> None:
    case = committed_archival_case
    session = await _profile_session(profile_conn)

    deleted = await RiskEventWriter(session).archive_and_delete_results(case.patient_id, [case.archived_instrument])
    await session.commit()

    assert deleted == 1
    async with engine.connect() as conn:
        history = (await conn.execute(_RESULT_HISTORY, {"pid": case.patient_id})).all()
        live = (await conn.execute(_LIVE_RESULTS, {"pid": case.patient_id})).scalar_one()
    assert [(row.instrument_code, row.indicator) for row in history] == [(case.archived_instrument, "a")]
    # Не тронутый инструмент остаётся живым: удаление адресное.
    assert live == 1


async def test_interpretations_archival_moves_exactly_the_deleted_rows(
    profile_conn: AsyncConnection, engine: AsyncEngine, committed_archival_case: ArchivalCase
) -> None:
    case = committed_archival_case
    session = await _profile_session(profile_conn)

    deleted = await RiskEventWriter(session).archive_and_delete_interpretations(case.patient_id, [case.archived_system])
    await session.commit()

    assert deleted == 1
    async with engine.connect() as conn:
        history = (await conn.execute(_INTERPRETATION_HISTORY, {"pid": case.patient_id})).all()
        live = (await conn.execute(_LIVE_INTERPRETATIONS, {"pid": case.patient_id})).scalar_one()
    assert [(row.system_code, row.risk_level) for row in history] == [(case.archived_system, "high")]
    assert live == 1


async def test_archival_rolls_back_deletion_when_history_insert_fails(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Удаление и вставка в историю — одна транзакция: сбой второй половины отменяет первую.

    Единственный тест файла на сессии суперпользователя: сломать вставку нужно DDL по расчётной
    таблице, а `CREATE`/`ALTER` в чужой схеме профильному логину не положены — тем же отказом
    в правах и упал бы арранж. Проверяется здесь граница транзакции, а не граница прав.
    """
    patient_id = await factory.patient(patient_id=unique_id("arch"))
    instrument_code = await factory.instrument(unique_id("INS"))
    await factory.result(patient_id=patient_id, instrument_code=instrument_code, value=1.5, indicator="a")
    await db_session.commit()

    writer = RiskEventWriter(db_session)
    # Ломаем именно вставку в историю: NOT NULL на колонке, которую архивация обязана заполнить.
    await db_session.execute(
        text("ALTER TABLE risk_calculation.results_history ALTER COLUMN indicator SET DEFAULT NULL")
    )
    await db_session.execute(
        text("ALTER TABLE risk_calculation.results_history ADD CONSTRAINT ck_archival_probe CHECK (indicator <> 'a')")
    )

    with pytest.raises(DBAPIError):
        await writer.archive_and_delete_results(patient_id, [instrument_code])
    await db_session.rollback()

    # Ни удаления, ни архива: строка на месте, история пуста.
    assert (await db_session.execute(_LIVE_RESULTS, {"pid": patient_id})).scalar_one() == 1
    assert (await db_session.execute(_RESULT_HISTORY, {"pid": patient_id})).all() == []


async def test_profile_login_reads_calculated_data_only_with_its_schema_map(
    profile_conn: AsyncConnection,
) -> None:
    """Карта схем — не косметика: без неё та же ORM-модель упирается в отказ в правах.

    С профильной картой `Result` адресует `risk_profile.results` (представление, SELECT выдан),
    без карты — физическую `risk_calculation.results`, куда профильному логину хода нет.
    """
    from src.models.result import Result

    statement = select(Result.result_id).limit(1)

    mapped = await profile_conn.execution_options(schema_translate_map=dict(PROFILE_SCHEMA_MAP))
    await mapped.execute(statement)
    await profile_conn.rollback()

    unmapped = await profile_conn.execution_options(schema_translate_map=None)
    with pytest.raises(ProgrammingError) as error:
        await unmapped.execute(statement)
    assert _sqlstate(error.value) == "42501"
    await profile_conn.rollback()
