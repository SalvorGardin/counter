"""Форма локальных представлений совпадает с формой их физического источника.

Представления перечисляют колонки явно (`SELECT *` замёрз бы на форме момента создания), поэтому
добавленная в таблицу колонка в представление сама не попадёт. Расхождение проявилось бы уже в
рантайме: репозиторий сервиса-потребителя запросил бы колонку, которой в его представлении нет.
Тест ловит это на уровне схемы — до того, как код доедет до неё.
"""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.db_schemas import (
    CALCULATION_LOCAL_VIEWS,
    CALCULATION_SCHEMA,
    EHR_LOCAL_VIEWS,
    EHR_SCHEMA,
    PROFILE_LOCAL_VIEWS,
    PROFILE_SCHEMA,
)

_COLUMNS = text(
    "SELECT column_name, data_type, is_nullable FROM information_schema.columns"
    " WHERE table_schema = :schema AND table_name = :name ORDER BY ordinal_position"
)

# (схема представления, имя, схема физического источника)
_VIEWS = (
    [
        pytest.param(CALCULATION_SCHEMA, name, PROFILE_SCHEMA, id=f"calculation-{name}")
        for name in CALCULATION_LOCAL_VIEWS
    ]
    + [pytest.param(PROFILE_SCHEMA, name, CALCULATION_SCHEMA, id=f"profile-{name}") for name in PROFILE_LOCAL_VIEWS]
    + [pytest.param(EHR_SCHEMA, name, PROFILE_SCHEMA, id=f"ehr-{name}") for name in EHR_LOCAL_VIEWS]
)


async def _columns(session: AsyncSession, schema: str, name: str) -> dict[str, str]:
    """Имя колонки → тип. Порядок не сравниваем намеренно.

    Физический порядок колонок — это история ALTER-ов (добавленная позже колонка встаёт в конец),
    а представление перечисляет их в порядке модели. Значение имеет состав и типы: SQL сервисов
    всегда называет колонки, позиционных обращений в нём нет.
    """
    rows = await session.execute(_COLUMNS, {"schema": schema, "name": name})
    return {row.column_name: row.data_type for row in rows}


@pytest.mark.parametrize(("view_schema", "name", "source_schema"), _VIEWS)
async def test_view_columns_match_the_physical_table(
    db_session: AsyncSession, view_schema: str, name: str, source_schema: str
) -> None:
    view = await _columns(db_session, view_schema, name)
    source = await _columns(db_session, source_schema, name)

    assert source, f"{source_schema}.{name}: физической таблицы нет"
    assert view == source, f"{view_schema}.{name} разошлось с {source_schema}.{name}"


async def test_every_declared_view_exists() -> None:
    """Константы и БД описывают один и тот же набор — иначе грант ушёл бы в несуществующий объект."""
    assert set(CALCULATION_LOCAL_VIEWS) == {"patients", "patients_parameters"}
    assert set(EHR_LOCAL_VIEWS) == {"patients", "patients_parameters"}


async def test_declared_views_are_present_in_the_database(db_session: AsyncSession) -> None:
    rows = await db_session.execute(
        text("SELECT table_schema, table_name FROM information_schema.views WHERE table_schema = ANY(:schemas)"),
        {"schemas": [PROFILE_SCHEMA, CALCULATION_SCHEMA, EHR_SCHEMA]},
    )
    found = {(row.table_schema, row.table_name) for row in rows}

    expected = (
        {(CALCULATION_SCHEMA, name) for name in CALCULATION_LOCAL_VIEWS}
        | {(PROFILE_SCHEMA, name) for name in PROFILE_LOCAL_VIEWS}
        | {(EHR_SCHEMA, name) for name in EHR_LOCAL_VIEWS}
    )
    assert found == expected
