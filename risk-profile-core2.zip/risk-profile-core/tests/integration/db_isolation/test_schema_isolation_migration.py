"""Миграция изоляции схем на пустой и на заполненной БД.

Прогон идёт в отдельном кластере PostgreSQL и по двум дорогам сразу: установка «с нуля» и апгрейд БД,
в которой уже есть данные. Обе обязаны дать одинаковое размещение объектов, а апгрейд — ещё и
сохранить строки: таблицы переносятся `ALTER TABLE ... SET SCHEMA`, без копирования.

Тест тяжёлый (два полных прогона цепочки), поэтому у него свой кластер PostgreSQL и своя область
видимости: сессионный стенд из tests/conftest.py уже мигрирован и второй дороги не даёт.
"""

import asyncio
import secrets
from collections.abc import Generator

import pytest
from alembic import command
from alembic.config import Config
from pydantic import SecretStr
from sqlalchemy import Connection, Engine, create_engine, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.exc import DBAPIError

from src.infra.db_bootstrap import RoleCredentials, bootstrap_roles_at_url
from src.infra.db_schemas import (
    APPLICATION_SCHEMAS,
    CALCULATION_SCHEMA,
    CALCULATION_TABLES,
    CATALOG_SCHEMA,
    CATALOG_TABLES,
    EHR_SCHEMA,
    MIGRATION_ROLE,
    PROFILE_SCHEMA,
    PROFILE_TABLES,
    RUNTIME_ROLES,
    SCHEMA_OWNER_ROLES,
)
from tests.postgres import postgres_server

pytestmark = pytest.mark.db

# Ревизия прямо перед изоляцией схем: до неё все таблицы лежат в public.
#
# Именно предшественник, а не «какая-нибудь ревизия раньше»: между снимком счётчиков и накатом
# изоляции не должно быть НИ ОДНОЙ чужой миграции. Перезаливка справочников (0145) меняет число
# строк в `parameters`/`instruments`, и снимок, взятый до неё, сравнивал бы сохранность данных
# при переносе с количеством из другой эпохи справочника.
_BEFORE_ISOLATION = "15c247ec61bb"
# Сама изоляция схем. Сохранность строк сверяется на ней, а не на head: перезаливки справочников
# после изоляции законно меняют число строк в `parameters`/`instruments`.
_ISOLATION = "7918bbab2957"

_EXPECTED_PLACEMENT = (
    {name: PROFILE_SCHEMA for name in PROFILE_TABLES}
    | {name: CALCULATION_SCHEMA for name in CALCULATION_TABLES}
    | {name: CATALOG_SCHEMA for name in CATALOG_TABLES}
)


def _alembic_config(url: str) -> Config:
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", url)
    return config


def _migration_url(sync_url: str, password: str) -> str:
    return make_url(sync_url).set(username="risk_migrations", password=password).render_as_string(hide_password=False)


@pytest.fixture(scope="module")
def migration_admin_url() -> Generator[str, None, None]:
    with postgres_server() as url:
        yield url


@pytest.fixture(scope="module")
def migration_url(migration_admin_url: str) -> str:
    sync_url = migration_admin_url
    password = secrets.token_urlsafe(24)
    credentials = RoleCredentials(
        profile=SecretStr(secrets.token_urlsafe(24)),
        calculation=SecretStr(secrets.token_urlsafe(24)),
        ehr=SecretStr(secrets.token_urlsafe(24)),
        bulk_recalc=SecretStr(secrets.token_urlsafe(24)),
        migrations=SecretStr(password),
    )
    asyncio.run(bootstrap_roles_at_url(sync_url, credentials, legacy_owner=make_url(sync_url).username))
    return _migration_url(sync_url, password)


@pytest.fixture(scope="module")
def engine(migration_url: str) -> Generator[Engine, None, None]:
    created = create_engine(migration_url)
    yield created
    created.dispose()


def _placement(connection: Connection) -> dict[str, str]:
    rows = connection.execute(
        text("SELECT schemaname, tablename FROM pg_tables WHERE schemaname = ANY(:schemas)"),
        {"schemas": list(APPLICATION_SCHEMAS)},
    )
    return {row.tablename: row.schemaname for row in rows}


def _owners(connection: Connection) -> dict[str, set[str]]:
    rows = connection.execute(
        text("SELECT schemaname, tableowner FROM pg_tables WHERE schemaname = ANY(:schemas)"),
        {"schemas": list(APPLICATION_SCHEMAS)},
    )
    owners: dict[str, set[str]] = {}
    for row in rows:
        owners.setdefault(row.schemaname, set()).add(row.tableowner)
    return owners


def _table_owner(connection: Connection, qualified_table: str) -> str:
    schema, table = qualified_table.split(".")
    return connection.execute(
        text("SELECT tableowner FROM pg_tables WHERE schemaname = :schema AND tablename = :table"),
        {"schema": schema, "table": table},
    ).scalar_one()


def _has_privilege(connection: Connection, role: str, qualified_table: str, privilege: str) -> bool:
    return connection.execute(
        text("SELECT has_table_privilege(:role, :table, :privilege)"),
        {"role": role, "table": qualified_table, "privilege": privilege},
    ).scalar_one()


def _count(connection: Connection, qualified_table: str) -> int:
    return connection.execute(text(f"SELECT count(*) FROM {qualified_table}")).scalar_one()  # noqa: S608


@pytest.fixture(scope="module")
def upgraded(engine: Engine, migration_url: str) -> dict[str, dict[str, int]]:
    """Апгрейд заполненной БД: сначала цепочка до изоляции, потом сама изоляция, потом остаток до head.

    Возвращает число строк по таблицам ДО и сразу ПОСЛЕ переноса — по ним проверяется сохранность данных.
    """
    config = _alembic_config(migration_url)
    command.upgrade(config, _BEFORE_ISOLATION)

    with engine.begin() as connection:
        connection.execute(text("INSERT INTO patients (patient_id, is_pregnant) VALUES ('migration-probe', false)"))
        before = {
            "patients": _count(connection, "public.patients"),
            "parameters": _count(connection, "public.parameters"),
            "instruments": _count(connection, "public.instruments"),
        }

    command.upgrade(config, _ISOLATION)
    with engine.connect() as connection:
        after = {
            "patients": _count(connection, f"{PROFILE_SCHEMA}.patients"),
            "parameters": _count(connection, f"{CATALOG_SCHEMA}.parameters"),
            "instruments": _count(connection, f"{CATALOG_SCHEMA}.instruments"),
        }

    command.upgrade(config, "head")
    return {"before": before, "after": after}


def test_populated_upgrade_moves_every_table_to_its_owner_schema(
    engine: Engine, upgraded: dict[str, dict[str, int]]
) -> None:
    with engine.connect() as connection:
        assert _placement(connection) == _EXPECTED_PLACEMENT
        # В public остаётся только служебная таблица alembic.
        leftovers = connection.execute(
            text("SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename")
        ).scalars()
        assert list(leftovers) == ["alembic_version"]


def test_populated_upgrade_preserves_every_row(engine: Engine, upgraded: dict[str, dict[str, int]]) -> None:
    assert upgraded["after"] == upgraded["before"]
    with engine.connect() as connection:
        probe = connection.execute(
            text(f"SELECT is_pregnant FROM {PROFILE_SCHEMA}.patients WHERE patient_id = 'migration-probe'")
        ).scalar_one()
        assert probe is False


def test_tables_belong_to_their_schema_owner(engine: Engine, upgraded: dict[str, dict[str, int]]) -> None:
    with engine.connect() as connection:
        owners = _owners(connection)
    for schema, expected_owner in SCHEMA_OWNER_ROLES.items():
        if schema == EHR_SCHEMA:
            continue  # своих таблиц у схемы ЭМК нет — только представления
        assert owners[schema] == {expected_owner}


def test_every_catalog_table_is_readable_by_every_runtime(engine: Engine, upgraded: dict[str, dict[str, int]]) -> None:
    """Справочники общие: любой рантайм обязан читать любую таблицу каталога."""
    with engine.connect() as connection:
        for table in CATALOG_TABLES:
            for role in RUNTIME_ROLES:
                assert _has_privilege(connection, role, f"{CATALOG_SCHEMA}.{table}", "SELECT"), (
                    f"{role} не читает {CATALOG_SCHEMA}.{table}"
                )


def test_a_new_table_needs_owner_and_grants_from_its_own_migration(
    engine: Engine, upgraded: dict[str, dict[str, int]]
) -> None:
    """Права на новую таблицу выдаёт только её собственная миграция — автоматики здесь нет.

    `ALTER DEFAULT PRIVILEGES FOR ROLE <владелец>` распространяется исключительно на объекты,
    которые создал сам этот владелец. Объекты создаёт `risk_migrations`, и его членство во
    владельце в расчёт не идёт: таблица достаётся создателю, грантов на ней нет. Право `CREATE`
    на схеме проверяется иначе и членство учитывает — поэтому создание проходит, а владельцем
    таблица оказывается не тот.

    Тест держит рецепт, без которого следующая таблица справочника встретит рантаймы отказом 42501.
    """
    probe = f"{CATALOG_SCHEMA}.default_privileges_probe"
    with engine.begin() as connection:
        connection.execute(text(f"CREATE TABLE {probe} (code text PRIMARY KEY)"))
    try:
        with engine.connect() as connection:
            assert _table_owner(connection, probe) == MIGRATION_ROLE
            granted = [role for role in RUNTIME_ROLES if _has_privilege(connection, role, probe, "SELECT")]
            assert granted == [], "молча выданные права означали бы, что таблицу можно не грантовать"

        # То, что обязана сделать сама миграция: переназначить владельца и выдать права явно.
        with engine.begin() as connection:
            connection.execute(text(f"ALTER TABLE {probe} OWNER TO {SCHEMA_OWNER_ROLES[CATALOG_SCHEMA]}"))
            connection.execute(text(f"GRANT SELECT ON {probe} TO {', '.join(RUNTIME_ROLES)}"))

        with engine.connect() as connection:
            assert _table_owner(connection, probe) == SCHEMA_OWNER_ROLES[CATALOG_SCHEMA]
            for role in RUNTIME_ROLES:
                assert _has_privilege(connection, role, probe, "SELECT")
    finally:
        with engine.begin() as connection:
            connection.execute(text(f"DROP TABLE IF EXISTS {probe}"))


def test_constraints_indexes_and_defaults_survive_the_move(engine: Engine, upgraded: dict[str, dict[str, int]]) -> None:
    with engine.connect() as connection:
        foreign_keys = connection.execute(
            text(
                "SELECT count(*) FROM pg_constraint c JOIN pg_class t ON t.oid = c.conrelid"
                " JOIN pg_namespace n ON n.oid = t.relnamespace"
                " WHERE c.contype = 'f' AND n.nspname = ANY(:schemas)"
            ),
            {"schemas": list(APPLICATION_SCHEMAS)},
        ).scalar_one()
        assert foreign_keys > 0, "внешние ключи не должны исчезнуть при переносе"

        # Кросс-схемная ссылка расчёта на пациента — та самая, ради которой ключи и сохраняются.
        cross_schema = connection.execute(
            text(
                "SELECT count(*) FROM pg_constraint c"
                " JOIN pg_class child ON child.oid = c.conrelid"
                " JOIN pg_namespace child_ns ON child_ns.oid = child.relnamespace"
                " JOIN pg_class parent ON parent.oid = c.confrelid"
                " JOIN pg_namespace parent_ns ON parent_ns.oid = parent.relnamespace"
                " WHERE c.contype = 'f' AND child_ns.nspname = :calculation AND parent_ns.nspname = :profile"
            ),
            {"calculation": CALCULATION_SCHEMA, "profile": PROFILE_SCHEMA},
        ).scalar_one()
        assert cross_schema > 0

        unique_index = connection.execute(
            text(
                "SELECT indexname FROM pg_indexes WHERE schemaname = :schema AND tablename = 'patients_parameters'"
                " AND indexname = 'uq_patients_parameters_patient_id_parameter_code'"
            ),
            {"schema": PROFILE_SCHEMA},
        ).scalar_one_or_none()
        assert unique_index is not None

        default = connection.execute(
            text(
                "SELECT column_default FROM information_schema.columns"
                " WHERE table_schema = :schema AND table_name = 'patients_parameters' AND column_name = 'date_time'"
            ),
            {"schema": PROFILE_SCHEMA},
        ).scalar_one()
        assert default is not None and "now()" in default


def test_owned_sequences_move_with_their_tables(engine: Engine, upgraded: dict[str, dict[str, int]]) -> None:
    with engine.connect() as connection:
        sequence = connection.execute(
            text("SELECT pg_get_serial_sequence(:table, 'patient_parameter_id')"),
            {"table": f"{PROFILE_SCHEMA}.patients_parameters"},
        ).scalar_one()
        assert sequence.startswith(f"{PROFILE_SCHEMA}.")


def test_the_migration_login_cannot_become_the_legacy_table_owner(
    migration_admin_url: str, engine: Engine, upgraded: dict[str, dict[str, int]]
) -> None:
    """Членство в прежнем владельце выдано без `SET ROLE`: иначе миграции получили бы суперпользователя.

    Прежний владелец таблиц в `public` — админский логин кластера, ровно как `POSTGRES_USER` на
    стенде. Переносить таблицы унаследованных прав хватает, а перевоплощаться в него — нет.
    """
    legacy_owner = make_url(migration_admin_url).username
    with engine.connect() as connection:
        granted_with_set = connection.execute(
            text("""
                SELECT m.set_option
                  FROM pg_auth_members AS m
                  JOIN pg_roles AS granted ON granted.oid = m.roleid
                  JOIN pg_roles AS member ON member.oid = m.member
                 WHERE member.rolname = :migration_role AND granted.rolname = :legacy_owner
            """),
            {"migration_role": MIGRATION_ROLE, "legacy_owner": legacy_owner},
        ).scalar_one()
        assert granted_with_set is False

    with engine.connect() as connection, pytest.raises(DBAPIError, match="permission denied to set role"):
        connection.execute(text(f"SET ROLE {legacy_owner}"))


def test_downgrade_returns_tables_to_public_without_losing_rows(
    engine: Engine, upgraded: dict[str, dict[str, int]]
) -> None:
    """Откат идёт последним: он разбирает состояние, на котором держатся тесты выше."""
    config = _alembic_config(str(engine.url.render_as_string(hide_password=False)))
    # Откатываем до ревизии ПЕРЕД изоляцией, а не на один шаг: после изоляции в цепочке появились
    # свои миграции, и `-1` снимал бы теперь верхнюю из них, а не саму изоляцию. Сначала снимаем
    # их до изоляции: их откат законно меняет справочники, а сверяется только откат самой изоляции.
    command.downgrade(config, _ISOLATION)
    with engine.connect() as connection:
        before_downgrade = {
            "patients": _count(connection, f"{PROFILE_SCHEMA}.patients"),
            "parameters": _count(connection, f"{CATALOG_SCHEMA}.parameters"),
        }
    command.downgrade(config, _BEFORE_ISOLATION)

    with engine.connect() as connection:
        remaining = connection.execute(
            text("SELECT count(*) FROM information_schema.schemata WHERE schema_name = ANY(:schemas)"),
            {"schemas": list(APPLICATION_SCHEMAS)},
        ).scalar_one()
        assert remaining == 0, "схемы обязаны исчезнуть вместе с представлениями и триггером"
        assert _count(connection, "public.patients") == before_downgrade["patients"]
        assert _count(connection, "public.parameters") == before_downgrade["parameters"]
        probe = connection.execute(
            text("SELECT is_pregnant FROM public.patients WHERE patient_id = 'migration-probe'")
        ).scalar_one()
        assert probe is False
        # Права PUBLIC на схему public возвращаются к исходным, а не расширяются: до миграции
        # у PUBLIC был только USAGE, и откат не место для выдачи права заводить объекты.
        privileges = connection.execute(
            text(
                "SELECT has_schema_privilege('public', 'public', 'USAGE') AS usage,"
                " has_schema_privilege('public', 'public', 'CREATE') AS create_"
            )
        ).one()
        assert privileges.usage is True
        assert privileges.create_ is False

    # Возвращаем стенд в целевое состояние: повторный апгрейд обязан пройти после отката.
    command.upgrade(config, "head")
    with engine.connect() as connection:
        assert _placement(connection) == _EXPECTED_PLACEMENT


def test_fresh_installation_matches_the_upgraded_layout(postgres_url: str, engine: Engine) -> None:
    """Установка «с нуля» и апгрейд дают одно размещение — иначе стенды разъедутся между собой.

    Сессионный стенд из tests/conftest.py мигрирован на пустой БД, поэтому он и есть «с нуля».
    """
    fresh = create_engine(make_url(postgres_url).set(drivername="postgresql+psycopg2").render_as_string(False))
    try:
        with fresh.connect() as connection:
            fresh_placement = _placement(connection)
            fresh_views = connection.execute(
                text(
                    "SELECT table_schema, table_name FROM information_schema.views"
                    " WHERE table_schema = ANY(:schemas) ORDER BY table_schema, table_name"
                ),
                {"schemas": list(APPLICATION_SCHEMAS)},
            ).all()
    finally:
        fresh.dispose()

    with engine.connect() as connection:
        upgraded_views = connection.execute(
            text(
                "SELECT table_schema, table_name FROM information_schema.views"
                " WHERE table_schema = ANY(:schemas) ORDER BY table_schema, table_name"
            ),
            {"schemas": list(APPLICATION_SCHEMAS)},
        ).all()

    assert fresh_placement == _EXPECTED_PLACEMENT
    assert fresh_views == upgraded_views
