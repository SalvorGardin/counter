"""Оба способа запуска сохраняют границы кластеров, проверку пароля и остановку при ошибке."""

import secrets

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.exc import OperationalError

from tests.postgres import postgres_server

pytestmark = pytest.mark.db


def test_postgres_servers_are_isolated_authenticated_and_stopped() -> None:
    with pytest.raises(RuntimeError, match="test failure"):
        with postgres_server() as first_url, postgres_server() as second_url:
            first = create_engine(first_url)
            second = create_engine(second_url)
            wrong_password = create_engine(make_url(first_url).set(password=secrets.token_urlsafe(24)))
            try:
                with first.begin() as connection:
                    assert 160000 <= int(connection.execute(text("SHOW server_version_num")).scalar_one()) < 170000
                    connection.execute(text("CREATE ROLE ci_isolation_probe"))
                with second.connect() as connection:
                    assert not connection.execute(
                        text("SELECT EXISTS (SELECT FROM pg_roles WHERE rolname = 'ci_isolation_probe')")
                    ).scalar_one()
                with pytest.raises(OperationalError):
                    wrong_password.connect()
                raise RuntimeError("test failure")
            finally:
                first.dispose()
                second.dispose()
                wrong_password.dispose()

    stopped = create_engine(first_url, connect_args={"connect_timeout": 2})
    try:
        with pytest.raises(OperationalError):
            stopped.connect()
    finally:
        stopped.dispose()
