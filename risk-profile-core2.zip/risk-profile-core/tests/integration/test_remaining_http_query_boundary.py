import re
from collections.abc import Iterator
from contextlib import contextmanager
from unittest.mock import AsyncMock

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_init.schemas import AnthropometryRequest
from src.constants import RiskLevel
from src.services.risk_communication.domain.constants import COMMON_SYSTEM_CODE
from src.services.risk_event.service import RiskEventService
from src.services.risk_init.service import RiskInitService
from src.services.risk_profile.domain.constants import ExaminationCategory, ExaminationType
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import make_http_catalog
from tests.consts import GENDER_MALE, PARAMETER_CODE_GENDER
from tests.factories import Factory, unique_id

_REFERENCE_SQL = re.compile(
    r"\b(?:from|join|update|into)\s+(?:\w+\.)?"
    r"(?:conditions|disease_examinations|diseases|doctors|examinations|instruments|instruments_parameters|"
    r"options|parameter_scores|parameters|questions|recommendations|recommended_doctors|risk_factors|systems|"
    r"system_checkup_examinations|systems_instruments)\b",
    re.IGNORECASE,
)


@contextmanager
def _record_sql(session: AsyncSession) -> Iterator[list[str]]:
    statements: list[str] = []
    bind = session.sync_session.bind
    assert bind is not None

    def before_cursor_execute(_conn, _cursor, statement, _parameters, _context, _executemany) -> None:
        statements.append(statement)

    event.listen(bind, "before_cursor_execute", before_cursor_execute)
    try:
        yield statements
    finally:
        event.remove(bind, "before_cursor_execute", before_cursor_execute)


def _assert_no_reference_sql(statements: list[str]) -> None:
    assert statements
    assert not [statement for statement in statements if _REFERENCE_SQL.search(statement)]


async def test_risk_profile_issues_no_reference_sql(db_session: AsyncSession, factory: Factory) -> None:
    patient_id = unique_id("profile-query-boundary")
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)

    with _record_sql(db_session) as statements:
        await RiskProfileService(db_session, catalog).get_medical_risk(client_id=patient_id, system_code=None)

    _assert_no_reference_sql(statements)


async def test_risk_profile_examinations_issues_no_reference_sql(db_session: AsyncSession, factory: Factory) -> None:
    """Пациент проходит обе ветки подбора — исследования группы и общий чек-ап, — чтобы под
    запись SQL попали чтения interpretations и patients_parameters, а не только patients."""
    patient_id = unique_id("examinations-query-boundary")
    disease_system = await factory.system()
    checkup_system = await factory.system()
    disease_code = await factory.disease(system_code=disease_system)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_MALE)
    await factory.interpretation(
        patient_id=patient_id, system_code=disease_system, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.interpretation(
        patient_id=patient_id, system_code=checkup_system, risk_level=RiskLevel.MEDIUM, diseases=[]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )
    await factory.system_checkup_examination(system_code=checkup_system, examination_code=checkup)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)

    with _record_sql(db_session) as statements:
        response = await RiskProfileService(db_session, catalog).get_examinations(
            client_id=patient_id, system_code=None
        )

    assert {item.system_code for item in response.system_examinations} == {disease_system, checkup_system}
    _assert_no_reference_sql(statements)


async def test_risk_event_answers_reset_issues_no_reference_sql(db_session: AsyncSession, factory: Factory) -> None:
    patient_id = unique_id("event-query-boundary")
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)
    system_code = next(row.code for row in catalog.ordered_systems if row.code != COMMON_SYSTEM_CODE)
    statuses = AsyncMock()
    reasons = AsyncMock()

    with _record_sql(db_session) as statements:
        await RiskEventService(db_session, catalog, statuses, reasons).handle_answers_reset(
            client_id=patient_id, system_codes=[system_code]
        )

    _assert_no_reference_sql(statements)


async def test_risk_init_issues_no_reference_sql(db_session: AsyncSession, factory: Factory) -> None:
    patient_id = unique_id("init-query-boundary")
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)

    with _record_sql(db_session) as statements:
        await RiskInitService(db_session, catalog).save_anthropometry(
            client_id=patient_id, body=AnthropometryRequest(weight_kg=70)
        )

    _assert_no_reference_sql(statements)
