"""Фильтры `any_of` / `none_of` на пустой последовательности отбирают то же, что `IN` / `NOT IN`.

Докстринги `src/infra/sql.py` опираются на это равенство: часть вызывающих (`load_results_for_patients`,
читалки `ExplanationReader`) отдаёт последовательность в фильтр без проверки на пустоту, и подмена
`IN` на `= ANY` не имеет права поменять там выборку. Проверяется на настоящем Postgres: истинность
`= ANY('{}')` и `!= ALL('{}')` — свойство сервера, компиляцией его не подтвердить.
"""

from sqlalchemy import literal, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.sql import any_of, none_of


async def test_any_of_on_empty_sequence_matches_nothing_like_in(db_session: AsyncSession) -> None:
    value = literal("a")
    assert await db_session.scalar(select(any_of(value, []))) is False
    assert await db_session.scalar(select(value.in_([]))) is False


async def test_none_of_on_empty_sequence_matches_everything_like_not_in(db_session: AsyncSession) -> None:
    value = literal("a")
    assert await db_session.scalar(select(none_of(value, []))) is True
    assert await db_session.scalar(select(value.notin_([]))) is True


async def test_any_of_and_none_of_are_complementary_on_a_non_empty_sequence(db_session: AsyncSession) -> None:
    value = literal("a")
    assert await db_session.scalar(select(any_of(value, ["a", "b"]))) is True
    assert await db_session.scalar(select(none_of(value, ["a", "b"]))) is False
    assert await db_session.scalar(select(any_of(value, ["b"]))) is False
    assert await db_session.scalar(select(none_of(value, ["b"]))) is True
