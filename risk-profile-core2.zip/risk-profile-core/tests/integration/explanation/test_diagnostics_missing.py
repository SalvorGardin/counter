"""Отсутствие таблиц сбора диагностики и пустые входные наборы кодов у читателя объяснения.

Ответ объяснения собирается из каталога, поэтому пропавшая таблица сбора не должна ронять
эндпоинт: читатель откатывает транзакцию (иначе Postgres перевёл бы её в aborted state и каждый
следующий SELECT в этой сессии упал бы на InFailedSqlTransaction) и поднимает доменную ошибку,
а сервис гасит её в `diagnostics_available = False`.
"""

from collections.abc import Awaitable, Callable, Mapping
from uuid import uuid4

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.explanation.domain.exceptions import DiagnosticsTableMissingError
from src.explanation.infra.reader import ExplanationReader
from src.explanation.service import ExplanationService
from tests.conftest import LogSink, make_calc_catalog, make_http_catalog, make_interpretation_catalog
from tests.factories import Factory

PREFIX = "T_DIAG_"


async def _service(session: AsyncSession) -> ExplanationService:
    return ExplanationService(
        session,
        await make_http_catalog(session),
        await make_calc_catalog(session),
        await make_interpretation_catalog(session),
    )


# Таблицы сбора физически принадлежат схеме расчёта.
_CALCULATION_SCHEMA = "risk_calculation"


async def _drop_diagnostics_table(session: AsyncSession, table: str) -> None:
    """Уносит таблицу сбора из видимости запроса — как незалитая миграция сбора на стенде.

    Внутри транзакции теста: реального DDL за её пределы не выходит, а первый же откат внутри
    читателя возвращает таблицу на место.
    """
    await session.execute(text(f"ALTER TABLE {_CALCULATION_SCHEMA}.{table} RENAME TO {table}_hidden"))
    await session.flush()


@pytest.mark.asyncio
async def test_missing_calc_statuses_table_degrades_instead_of_failing(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    patient_id = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=patient_id)
    service = await _service(db_session)
    await _drop_diagnostics_table(db_session, "calculation_statuses")

    response = await service.explain_case(patient_id)

    assert response.diagnostics_available is False
    # Состав ответа определяет каталог, а не сбор: системы и их инструменты на месте.
    assert response.systems, "системы каталога пропали из ответа вместе со сбором"
    instruments = [item for system in response.systems for item in system.instruments]
    assert instruments, "инструменты каталога пропали из ответа вместе со сбором"
    assert all(item.instrument_name for item in instruments)
    assert all(system.explanation_state_text for system in response.systems)
    assert "explanation: diagnostics table is missing, reading it is skipped" in captured_app_logs.messages()


@pytest.mark.asyncio
async def test_reader_reports_which_diagnostics_table_is_missing(db_session: AsyncSession, factory: Factory) -> None:
    """Ошибка называет таблицу: без этого разбор инцидента на стенде начинается с угадывания."""
    patient_id = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=patient_id)
    await _drop_diagnostics_table(db_session, "risk_factor_matches")

    with pytest.raises(DiagnosticsTableMissingError) as exc_info:
        await ExplanationReader(db_session).get_risk_factor_matches(patient_id, ["SYS"])

    assert "risk_factor_matches" in str(exc_info.value)


@pytest.mark.asyncio
async def test_missing_table_rollback_keeps_session_usable(db_session: AsyncSession, factory: Factory) -> None:
    """После отката сессия жива: следующий SELECT проходит, а не падает на InFailedSqlTransaction."""
    patient_id = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=patient_id)
    reader = ExplanationReader(db_session)
    await _drop_diagnostics_table(db_session, "interpretation_statuses")

    with pytest.raises(DiagnosticsTableMissingError):
        await reader.get_interpretation_statuses(patient_id, ["SYS"])

    assert await db_session.scalar(text("SELECT 1")) == 1


_EMPTY_INPUT_READS: dict[str, Callable[[ExplanationReader], Awaitable[Mapping[str, object]]]] = {
    "get_calc_statuses": lambda reader: reader.get_calc_statuses("p", []),
    "get_interpretation_statuses": lambda reader: reader.get_interpretation_statuses("p", []),
    "get_risk_factor_matches": lambda reader: reader.get_risk_factor_matches("p", []),
    "get_result_times": lambda reader: reader.get_result_times("p", []),
    "get_instrument_names": lambda reader: reader.get_instrument_names([]),
    "get_parameter_names": lambda reader: reader.get_parameter_names([]),
}


@pytest.mark.asyncio
@pytest.mark.parametrize("method_name", sorted(_EMPTY_INPUT_READS))
async def test_empty_codes_short_circuit_without_query(db_session: AsyncSession, method_name: str) -> None:
    """Пустой набор кодов не превращается в `IN ()` — читатель отвечает пустой картой сам.

    Проверяется и на таблицах сбора: их отсутствие не должно быть видно, пока спрашивать нечего.
    """
    for table in ("calculation_statuses", "interpretation_statuses", "risk_factor_matches"):
        await _drop_diagnostics_table(db_session, table)

    assert await _EMPTY_INPUT_READS[method_name](ExplanationReader(db_session)) == {}
