"""Пересчёт несработавших факторов и второй источник §4.3 — клинрек-факторы биомаркеров.

Диагностика обязана отбирать факторы теми же двумя блоками, что и интерпретация. Пропусти второй,
и фактор, который интерпретация ВКЛЮЧИЛА по биомаркеру, ответ покажет несработавшим (или, что хуже,
умолчит о нём) — на инструменте, которым разбирают результат, это стоит дороже, чем выглядит.
"""

from uuid import uuid4

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.explanation.schemas import UnmatchedRiskFactorsResponse
from src.explanation.service import ExplanationService
from tests.conftest import make_calc_catalog, make_http_catalog, make_interpretation_catalog
from tests.consts import BIOMARKER_CLINREC_INSTRUMENT_CODE
from tests.factories import Factory

PREFIX = "T_EXPL_KR_"
RF_CLINREC = f"{PREFIX}RF_LDL"
RF_FOREIGN_TRIGGER = f"{PREFIX}RF_LDL_FOREIGN"


class Case:
    """Засеянный клинрек-случай: пациент, система, группа заболеваний и показатель-биомаркер."""

    def __init__(self, patient_id: str, system_code: str, disease_code: str, parameter_code: str) -> None:
        self.patient_id = patient_id
        self.system_code = system_code
        self.disease_code = disease_code
        self.parameter_code = parameter_code


@pytest_asyncio.fixture
async def case(db_session: AsyncSession, factory: Factory) -> Case:
    """Клинрек-фактор с баллом 3 и БЕЗ строки `parameter_scores`.

    Оценки по паре «показатель × система» нет намеренно: первый источник факторов такое условие
    не отбирает, поэтому единственный, кто может поднять фактор, — второй. Ответ пациента и строку
    результата группы кладёт сам тест: именно ими сценарии и различаются.
    """
    patient_id = await factory.patient()
    system_code = await factory.system(description="Клинрек-система")
    other_system_code = await factory.system(description="Соседняя система")
    await factory.biomarker_clinrec_instrument()
    await factory.link_system_instrument(system_code=system_code, instrument_code=BIOMARKER_CLINREC_INSTRUMENT_CODE)
    parameter_code = f"biomarker_{uuid4().hex[:8]}"
    await factory.parameter(parameter_code, description="ЛПНП")
    await factory.link_parameter(
        instrument_code=BIOMARKER_CLINREC_INSTRUMENT_CODE, parameter_code=parameter_code, is_required=False
    )
    disease_code = await factory.disease(system_code=system_code, description="Группа заболеваний")

    await factory.risk_factor(
        RF_CLINREC,
        parameter_code=parameter_code,
        system_code=system_code,
        description="ЛПНП повышен",
        reasoning="Клиническое обоснование по ЛПНП",
        param_value="Да",
    )
    await factory.risk_factor_score(risk_factor_code=RF_CLINREC, disease_code=disease_code, score=3)

    # Тот же фактор, но его условие заведено по соседней системе: клинрек-отбор `system_code`
    # триггера не фильтрует (§4.3, шаг 1б.3), а выборка факторов системы такую строку не отдаёт.
    await factory.risk_factor(
        RF_FOREIGN_TRIGGER,
        parameter_code=parameter_code,
        system_code=other_system_code,
        description="ЛПНП повышен (условие соседней системы)",
        param_value="Да",
    )
    await factory.link_risk_factor_system(
        risk_factor_code=RF_FOREIGN_TRIGGER, system_code=system_code, reasoning="Обоснование в этой системе"
    )
    await factory.risk_factor_score(risk_factor_code=RF_FOREIGN_TRIGGER, disease_code=disease_code, score=3)

    await db_session.flush()
    return Case(patient_id, system_code, disease_code, parameter_code)


async def _recompute(db_session: AsyncSession, case: Case) -> UnmatchedRiskFactorsResponse:
    service = ExplanationService(
        db_session,
        await make_http_catalog(db_session),
        await make_calc_catalog(db_session),
        await make_interpretation_catalog(db_session),
    )
    return await service.recompute_unmatched_risk_factors(patient_id=case.patient_id, system_code=case.system_code)


async def _answer(factory: Factory, case: Case, value: str) -> None:
    await factory.answer(patient_id=case.patient_id, parameter_code=case.parameter_code, value=value)


async def _applicable_group(factory: Factory, case: Case, *, applicability: bool) -> None:
    await factory.result(
        patient_id=case.patient_id,
        instrument_code=BIOMARKER_CLINREC_INSTRUMENT_CODE,
        disease_code=case.disease_code,
        risk_level="high",
        applicability=applicability,
        interpretation_status="done",
    )


async def test_factor_raised_by_the_clinrec_source_is_not_reported_as_unmatched(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    await _answer(factory, case, "Да")
    await _applicable_group(factory, case, applicability=True)
    await db_session.flush()

    response = await _recompute(db_session, case)

    assert not [item for item in response.items if item.risk_factor_code == RF_CLINREC]


async def test_foreign_system_trigger_is_taken_from_the_clinrec_source(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    """Условие второго блока может стоять на триггере соседней системы (§4.3, шаг 1б.3).

    Выборка факторов системы такую строку не отдаёт вовсе, поэтому её появление в разборе — прямое
    доказательство, что кандидаты второго источника в него попали. Ответ подобран несовпадающим:
    сработавшее условие ушло бы из ответа, и проверять было бы нечего.
    """
    await _answer(factory, case, "Нет")
    await _applicable_group(factory, case, applicability=True)
    await db_session.flush()

    response = await _recompute(db_session, case)

    assert {item.reason_code for item in response.items if item.risk_factor_code == RF_FOREIGN_TRIGGER} == {
        "operator_mismatch"
    }


async def test_condition_of_an_applicable_group_is_judged_by_its_operator(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    """Ответ, не попадающий в условие, при применимой группе — обычное несрабатывание по оператору."""
    await _answer(factory, case, "Нет")
    await _applicable_group(factory, case, applicability=True)
    await db_session.flush()

    response = await _recompute(db_session, case)

    assert {item.reason_code for item in response.items if item.risk_factor_code == RF_CLINREC} == {"operator_mismatch"}


async def test_biomarker_condition_without_an_applicable_group_reports_the_clinrec_gate(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    """Строка группы неприменима — второй источник до проверки условия не доходит.

    Причина обязана называть именно этот вход: ответ пациента в условие как раз попадает, и
    `operator_mismatch` был бы прямой ложью.
    """
    await _answer(factory, case, "Да")
    await _applicable_group(factory, case, applicability=False)
    await db_session.flush()

    response = await _recompute(db_session, case)

    assert {item.reason_code for item in response.items if item.risk_factor_code == RF_CLINREC} == {
        "clinrec_disease_not_applicable"
    }
