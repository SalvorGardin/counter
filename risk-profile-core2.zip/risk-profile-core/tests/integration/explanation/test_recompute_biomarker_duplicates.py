"""Пересчёт несработавших факторов на показателе, вытесненном повтором того же биомаркера.

Значение, вытесненное более свежим значением биомаркера в другой единице измерения, в отбор не
попадает, но пациент его дал. Причина «показатель не отвечен» была бы ложью, поэтому у такого
кандидата своя причина, а ответ пациента показывается как есть.
"""

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from uuid import uuid4

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.explanation.schemas import UnmatchedRiskFactorsResponse
from src.explanation.service import ExplanationService
from tests.conftest import make_calc_catalog, make_http_catalog, make_interpretation_catalog
from tests.factories import Factory, unique_id

ANSWER_YES = "Да"
ANSWER_NO = "Нет"


@dataclass(frozen=True)
class Case:
    patient_id: str
    system_code: str
    risk_factor_code: str
    old_parameter_code: str


@pytest_asyncio.fixture
async def case(db_session: AsyncSession, factory: Factory) -> Case:
    """Два параметра одного биомаркера в разных единицах в одном инструменте системы.

    Условие фактора и оценка заведены на параметре старой единицы; свежее значение пришло в новой.
    """
    patient_id = await factory.patient()
    system_code = await factory.system(description="Система")
    instrument_code = await factory.instrument(unique_id("form"), type="form")
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)

    old_source, new_source = f"biomarker_{uuid4().hex[:8]}", f"biomarker_{uuid4().hex[:8]}"
    old_parameter, new_parameter = unique_id("unit_old"), unique_id("unit_new")
    for parameter_code in (old_source, new_source, old_parameter, new_parameter):
        await factory.parameter(parameter_code)
    biomarker_code = await factory.biomarker(parameter_code=old_source, unit_code=1)
    await factory.biomarker(parameter_code=new_source, biomarker_code=biomarker_code, unit_code=2)
    await factory.biomarker_mapping(biomarker_parameter_code=old_source, parameter_code=old_parameter)
    await factory.biomarker_mapping(biomarker_parameter_code=new_source, parameter_code=new_parameter)
    for parameter_code in (old_parameter, new_parameter):
        await factory.link_parameter(instrument_code=instrument_code, parameter_code=parameter_code, is_required=False)

    risk_factor_code = unique_id("RF_UNIT")
    await factory.parameter_score(
        parameter_code=old_parameter, system_code=system_code, value=ANSWER_YES, score=Decimal("1")
    )
    await factory.risk_factor(
        risk_factor_code, system_code=system_code, parameter_code=old_parameter, param_value=ANSWER_YES
    )

    now = datetime.now(tz=UTC)
    await factory.answer(
        patient_id=patient_id, parameter_code=old_parameter, value=ANSWER_YES, date_time=now - timedelta(days=1)
    )
    await factory.answer(patient_id=patient_id, parameter_code=new_parameter, value=ANSWER_NO, date_time=now)
    await db_session.flush()
    return Case(patient_id, system_code, risk_factor_code, old_parameter)


async def _recompute(db_session: AsyncSession, case: Case) -> UnmatchedRiskFactorsResponse:
    service = ExplanationService(
        db_session,
        await make_http_catalog(db_session),
        await make_calc_catalog(db_session),
        await make_interpretation_catalog(db_session),
    )
    return await service.recompute_unmatched_risk_factors(patient_id=case.patient_id, system_code=case.system_code)


async def test_displaced_parameter_reports_duplicate_reason_with_patient_answer(
    db_session: AsyncSession, case: Case
) -> None:
    response = await _recompute(db_session, case)

    assert [
        (item.reason_code, item.answer) for item in response.items if item.risk_factor_code == case.risk_factor_code
    ] == [("parameter_excluded_as_duplicate", ANSWER_YES)]


async def test_parameter_kept_in_another_instrument_of_the_system_is_checked(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    """Вытесненный в одном инструменте параметр, оставшийся в выборке другого, проверяется условием."""
    other_instrument = await factory.instrument(unique_id("form"), type="form")
    await factory.link_system_instrument(system_code=case.system_code, instrument_code=other_instrument)
    await factory.link_parameter(
        instrument_code=other_instrument, parameter_code=case.old_parameter_code, is_required=False
    )
    await db_session.flush()

    response = await _recompute(db_session, case)

    assert not [item for item in response.items if item.risk_factor_code == case.risk_factor_code]
