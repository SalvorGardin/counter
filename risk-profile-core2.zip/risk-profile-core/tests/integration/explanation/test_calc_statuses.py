"""Статусы расчёта по пациенту на настоящей БД: состав ответа, детали причин, привязка к системам.

Сервис работает на переданной сессии `db_session`, поэтому синтетический каталог виден ему
незакоммиченным и откатывается вместе с тестом. Резидентный каталог собирается ПОСЛЕ сидов — как на
проде после миграций.
"""

import logging
from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.calc_status.schemas import CalcStatusInstrument
from src.calc.domain.models import CalcReasonCode, CalcStatus
from src.explanation.domain.constants import OUTCOME_NOT_STARTED
from src.explanation.status_service import CalcStatusService
from tests.conftest import LogSink, make_calc_catalog
from tests.factories import Factory

PREFIX = "T_CST_"
SYSTEM_A = f"{PREFIX}SYS_A"
SYSTEM_B = f"{PREFIX}SYS_B"

P_ONE = f"{PREFIX}p_one"
P_TWO = f"{PREFIX}p_two"

I_CALCULATED = f"{PREFIX}calculated"
I_MISSING_PARAMS = f"{PREFIX}missing"
I_GATED = f"{PREFIX}gated"
I_UNTOUCHED = f"{PREFIX}untouched"
I_TWO_SYSTEMS = f"{PREFIX}two_systems"
I_OUTSIDE = f"{PREFIX}outside"
I_INACTIVE = f"{PREFIX}inactive"

RECORDED_AT = datetime.now(tz=UTC) - timedelta(minutes=5)


@pytest_asyncio.fixture
async def patient_id(db_session: AsyncSession, factory: Factory) -> str:
    pid = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=pid)
    await factory.system(SYSTEM_A, description="Система А")
    await factory.system(SYSTEM_B, description="Система Б")
    await factory.parameter(P_ONE, description="Показатель один")
    await factory.parameter(P_TWO, description="Показатель два")

    await factory.instrument_with_params(
        I_CALCULATED, description="Рассчитанный", required=[P_ONE], system_code=SYSTEM_A, create_parameters=False
    )
    await factory.instrument_with_params(
        I_MISSING_PARAMS, description="Без параметров", required=[P_ONE], system_code=SYSTEM_A, create_parameters=False
    )
    await factory.instrument_with_params(
        I_GATED, description="Гейтированный", required=[P_ONE], system_code=SYSTEM_A, create_parameters=False
    )
    await factory.instrument_with_params(
        I_UNTOUCHED, description="Не посещался", required=[P_ONE], system_code=SYSTEM_A, create_parameters=False
    )
    await factory.instrument_with_params(
        I_TWO_SYSTEMS, description="В двух системах", required=[P_TWO], system_code=SYSTEM_A, create_parameters=False
    )
    await factory.link_system_instrument(system_code=SYSTEM_B, instrument_code=I_TWO_SYSTEMS)
    await factory.instrument_with_params(
        I_OUTSIDE, description="Вне систем", required=[P_TWO], create_parameters=False, in_system=False
    )
    await factory.instrument_with_params(
        I_INACTIVE, required=[P_TWO], status="inactive", in_system=False, create_parameters=False
    )

    await factory.calc_status(
        patient_id=pid, instrument_code=I_CALCULATED, status=CalcStatus.CALCULATED.value, date_time=RECORDED_AT
    )
    await factory.calc_status(
        patient_id=pid,
        instrument_code=I_MISSING_PARAMS,
        status=CalcStatus.INSUFFICIENT_DATA.value,
        reason_code=CalcReasonCode.MISSING_REQUIRED_PARAMETERS.value,
        date_time=RECORDED_AT,
        missing_parameter_codes=[P_ONE, P_TWO],
    )
    await factory.calc_status(
        patient_id=pid,
        instrument_code=I_GATED,
        status=CalcStatus.INSUFFICIENT_DATA.value,
        reason_code=CalcReasonCode.NOT_ENOUGH_ANSWERS.value,
        date_time=RECORDED_AT,
        applicable_questions=9,
        progressed_questions=3,
    )
    return pid


async def _items(db_session: AsyncSession, patient_id: str) -> dict[str, CalcStatusInstrument]:
    catalog = await make_calc_catalog(db_session)
    service = CalcStatusService(db_session, catalog)
    return {item.instrument_code: item for item in await service.get_statuses(patient_id)}


class TestOutcomes:
    async def test_saved_outcomes_are_returned_as_is(self, db_session: AsyncSession, patient_id: str) -> None:
        items = await _items(db_session, patient_id)

        calculated = items[I_CALCULATED]
        assert calculated.status == CalcStatus.CALCULATED.value
        assert calculated.reason_code is None
        assert calculated.instrument_description == "Рассчитанный"
        assert calculated.date_time is not None

        missing = items[I_MISSING_PARAMS]
        assert missing.status == CalcStatus.INSUFFICIENT_DATA.value
        assert missing.reason_code == CalcReasonCode.MISSING_REQUIRED_PARAMETERS.value
        # Коды параметров уходят наружу списком кодов: формулировок вопросов эндпоинт не строит.
        assert missing.missing_parameter_codes == [P_ONE, P_TWO]
        assert missing.applicable_questions is None

    async def test_question_counters_belong_to_their_reason(self, db_session: AsyncSession, patient_id: str) -> None:
        gated = (await _items(db_session, patient_id))[I_GATED]

        assert gated.reason_code == CalcReasonCode.NOT_ENOUGH_ANSWERS.value
        assert (gated.progressed_questions, gated.applicable_questions) == (3, 9)
        assert not gated.missing_parameter_codes

    async def test_instrument_without_row_is_not_started(self, db_session: AsyncSession, patient_id: str) -> None:
        untouched = (await _items(db_session, patient_id))[I_UNTOUCHED]

        assert untouched.status == OUTCOME_NOT_STARTED
        assert untouched.reason_code is None
        assert untouched.missing_parameter_codes is None
        assert untouched.applicable_questions is None
        assert untouched.progressed_questions is None
        assert untouched.date_time is None

    async def test_inactive_instrument_is_absent(self, db_session: AsyncSession, patient_id: str) -> None:
        assert I_INACTIVE not in await _items(db_session, patient_id)


class TestSystemBinding:
    async def test_instrument_in_two_systems_is_one_item(self, db_session: AsyncSession, patient_id: str) -> None:
        item = (await _items(db_session, patient_id))[I_TWO_SYSTEMS]

        assert sorted(item.system_codes) == sorted([SYSTEM_A, SYSTEM_B])

    async def test_instrument_outside_systems_keeps_empty_list(self, db_session: AsyncSession, patient_id: str) -> None:
        item = (await _items(db_session, patient_id))[I_OUTSIDE]

        assert item.system_codes == []


class TestMissingTableDegradation:
    async def test_missing_table_returns_whole_catalog_not_started(
        self, db_session: AsyncSession, patient_id: str, captured_app_logs: LogSink
    ) -> None:
        # DDL идёт в транзакцию теста и откатывается вместе с ней. Читатель на отсутствующей таблице
        # откатывает сессию (PostgreSQL прерывает транзакцию) — сиды пропадают, поэтому каталог
        # собирается заранее и проверки идут по уже полученному ответу.
        catalog = await make_calc_catalog(db_session)
        # CASCADE: на таблицу опирается профильное представление risk_profile.calculation_statuses.
        # DDL всё равно откатывается вместе с транзакцией теста.
        await db_session.execute(text("DROP TABLE risk_calculation.calculation_statuses CASCADE"))
        service = CalcStatusService(db_session, catalog)

        items = await service.get_statuses(patient_id)

        assert items, "каталог обязан прийти целиком"
        assert {item.status for item in items} == {OUTCOME_NOT_STARTED}
        errors = [record for record in captured_app_logs.records if record.levelno >= logging.ERROR]
        assert len(errors) == 1, "отсутствие диагностической таблицы — одна ERROR-строка, не 500"

    async def test_other_db_error_is_not_masked(self, db_session: AsyncSession, patient_id: str) -> None:
        catalog = await make_calc_catalog(db_session)
        # Ошибка, не связанная с отсутствием таблицы: колонку, которую читает запрос, убираем.
        await db_session.execute(text("ALTER TABLE risk_calculation.calculation_statuses DROP COLUMN status CASCADE"))
        service = CalcStatusService(db_session, catalog)

        with pytest.raises(Exception) as exc_info:  # noqa: PT011 - тип драйвера здесь не важен
            await service.get_statuses(patient_id)

        assert OUTCOME_NOT_STARTED not in str(exc_info.value)
