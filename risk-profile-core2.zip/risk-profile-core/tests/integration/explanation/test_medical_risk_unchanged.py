"""Оценка медицинских рисков не зависит от флага сбора диагностических данных.

Флаг включает сбор и читающие маршруты, а внешний контракт клиента обязан остаться прежним: иначе
включение диагностики на стенде меняло бы то, что проверяющий сравнивает с ожиданием.

Система, инструмент и фактор риска берутся из настоящего справочника, а не сидятся: у систем
ограничен допустимый приоритет, и синтетическая система выпала бы за его границы.
"""

from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import settings
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import make_http_catalog
from tests.factories import Factory

PREFIX = "T_MRU_"
DOCTOR_CODE = 9931

NOW = datetime.now(tz=UTC)


async def test_medical_risk_response_is_identical_under_both_flag_states(
    db_session: AsyncSession, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    row = (
        await db_session.execute(
            text(
                "SELECT rft.trigger_code, rft.system_code, rf.code, rft.parameter_code, rf.modifiability,"
                "       rft.value_text AS param_value, rft.min_value AS min_param_value,"
                "       rft.max_value AS max_param_value, si.instrument_code"
                " FROM risk_factors rf"
                " JOIN risk_factor_triggers rft ON rft.risk_factor_code = rf.code"
                " JOIN systems_instruments si ON si.system_code = rft.system_code"
                " WHERE rft.operator IN ('eq', 'between')"
                " ORDER BY rft.trigger_code LIMIT 1"
            )
        )
    ).one()
    patient_id = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=patient_id)
    await factory.doctor(code=DOCTOR_CODE, description="Специалист")
    await factory.answer(patient_id=patient_id, parameter_code=row.parameter_code, value="30")
    await factory.result(
        patient_id=patient_id,
        instrument_code=row.instrument_code,
        date_time=NOW - timedelta(minutes=10),
        indicator="result",
        value=1,
        risk_level="high",
        interpretation_status="done",
    )
    disease_code = await factory.disease(f"{PREFIX}{uuid4()}", description="Заболевание", system_code=row.system_code)
    await factory.interpretation(
        patient_id=patient_id,
        system_code=row.system_code,
        risk_level="high",
        diseases=[disease_code],
        risk_factors_code=[row.code],
        doctors_code=[str(DOCTOR_CODE)],
        date_time=NOW - timedelta(minutes=5),
    )
    # Диагностические строки на месте: при включённом флаге они есть в базе, и ответ обязан их не
    # заметить — читающий слой отдельный, а внешний контракт их не касается.
    await factory.calc_status(
        patient_id=patient_id, instrument_code=row.instrument_code, status="calculated", date_time=NOW
    )
    await factory.interpretation_status(patient_id=patient_id, system_code=row.system_code, date_time=NOW)
    await factory.risk_factor_match(
        patient_id=patient_id,
        system_code=row.system_code,
        trigger_code=row.trigger_code,
        code=row.code,
        parameter_code=row.parameter_code,
        date_time=NOW,
        modifiability=row.modifiability,
        param_value=row.param_value,
        min_param_value=row.min_param_value,
        max_param_value=row.max_param_value,
    )

    # Сиды открыли транзакцию сессии через autobegin, а `get_medical_risk` открывает свой скоуп
    # `session.begin()` — на уже начатой сессии это InvalidRequestError. Коммит закрывает сидовую
    # транзакцию: при join_transaction_mode="create_savepoint" он релизит savepoint, строки остаются
    # во внешней транзакции фикстуры и откатываются вместе с ней.
    await db_session.commit()

    service = RiskProfileService(db_session, await make_http_catalog(db_session))
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)
    without_collection = (await service.get_medical_risk(client_id=patient_id, system_code=None)).model_dump()
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)
    with_collection = (await service.get_medical_risk(client_id=patient_id, system_code=None)).model_dump()

    assert without_collection["system_interpretation_results"], "случай обязан содержать интерпретированную систему"
    assert with_collection == without_collection
