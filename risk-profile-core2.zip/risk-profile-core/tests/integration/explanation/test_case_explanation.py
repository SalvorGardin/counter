"""Объяснение одного случая на настоящей БД: полнота состава, готовность, перевод кодов, пересчёт.

Синтетический каталог кладётся в общую сессию `db_session` и откатывается вместе с ней; резидентные
каталоги собираются ПОСЛЕ сидов, как на проде — после миграций и сидов.
"""

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.explanation.schemas import (
    CaseExplanationResponse,
    InstrumentExplanation,
    RiskFactorExplanation,
    SystemExplanation,
)
from src.explanation.domain.constants import InstrumentExplanationState, SystemExplanationState
from src.explanation.service import ExplanationService
from src.interpretation.domain.models import InterpretationReasonCode
from tests.conftest import make_calc_catalog, make_http_catalog, make_interpretation_catalog
from tests.factories import Factory

PREFIX = "T_EXPL_"
SYSTEM = f"{PREFIX}SYS"
SYSTEM_NAME = "Тестовая система"

P_BMI = f"{PREFIX}bmi"
P_SMOKE = f"{PREFIX}smoke"
P_PRESSURE = f"{PREFIX}pressure"
P_FOREIGN = f"{PREFIX}foreign"

I_CALCULATED = f"{PREFIX}calculated"
I_INSUFFICIENT = f"{PREFIX}insufficient"
I_PENDING = f"{PREFIX}pending"
I_STALE = f"{PREFIX}stale"
I_UNTOUCHED = f"{PREFIX}untouched"
I_NOT_CALCULATED = f"{PREFIX}notcalc"
I_OUTSIDE = f"{PREFIX}outside"

RF_BMI = f"{PREFIX}RF_BMI"
RF_SMOKE = f"{PREFIX}RF_SMOKE"
RF_PRESSURE = f"{PREFIX}RF_PRESSURE"
RF_FOREIGN = f"{PREFIX}RF_FOREIGN"

DOCTOR_CODE = 9917
DOCTOR_NAME = "Тестовый специалист"

DISEASE = f"{PREFIX}hypertension"
DISEASE_NAME = "Гипертония"


# Два бакета ИМТ различаются только диапазоном — естественный ключ триггера без суррогатного id.
BMI_REPRESENTATIVE = ("30", "40")
BMI_SUPERSEDED = ("25", "35")


class Case:
    """Идентификаторы засеянного случая, нужные проверкам."""

    def __init__(self, patient_id: str, seeded_at: datetime) -> None:
        self.patient_id = patient_id
        self.seeded_at = seeded_at


@pytest_asyncio.fixture
async def case(db_session: AsyncSession, factory: Factory) -> Case:
    seeded_at = datetime.now(tz=UTC)
    just_now = seeded_at - timedelta(seconds=2)
    long_ago = seeded_at - timedelta(hours=1)
    patient_id = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=patient_id)
    await factory.system(SYSTEM, description=SYSTEM_NAME)
    await factory.doctor(code=DOCTOR_CODE, description=DOCTOR_NAME)
    await factory.disease(DISEASE, description=DISEASE_NAME, system_code=SYSTEM)

    await factory.parameter(P_BMI, description="Индекс массы тела")
    await factory.parameter(P_SMOKE, description="Курение")
    await factory.parameter(P_PRESSURE, description="Артериальное давление")
    await factory.parameter(P_FOREIGN, description="Показатель вне системы")

    await factory.instrument_with_params(
        I_CALCULATED, description="Рассчитанный", required=[P_BMI], system_code=SYSTEM, create_parameters=False
    )
    await factory.instrument_with_params(
        I_INSUFFICIENT, description="Без данных", required=[P_PRESSURE], system_code=SYSTEM, create_parameters=False
    )
    await factory.instrument_with_params(
        I_PENDING, description="Свежий результат", required=[P_BMI], system_code=SYSTEM, create_parameters=False
    )
    await factory.instrument_with_params(
        I_STALE, description="Давний результат", required=[P_BMI], system_code=SYSTEM, create_parameters=False
    )
    await factory.instrument_with_params(
        I_UNTOUCHED, description="Не начат", required=[P_PRESSURE], system_code=SYSTEM, create_parameters=False
    )
    await factory.instrument_with_params(
        I_NOT_CALCULATED, description="Не считался", required=[P_SMOKE], system_code=SYSTEM, create_parameters=False
    )
    # Без строки systems_instruments: инструмент вне систем должен остаться в ответе.
    await factory.instrument_with_params(
        I_OUTSIDE, description="Вне систем", required=[P_FOREIGN], create_parameters=False, in_system=False
    )

    # Ответы пациента: ИМТ 31, курение «Нет», давление не отвечено.
    await factory.answer(patient_id=patient_id, parameter_code=P_BMI, value="31")
    await factory.answer(patient_id=patient_id, parameter_code=P_SMOKE, value="Нет")
    await factory.answer(patient_id=patient_id, parameter_code=P_FOREIGN, value="Да")

    await factory.result(
        patient_id=patient_id,
        instrument_code=I_CALCULATED,
        date_time=long_ago,
        indicator="result",
        value=1,
        risk_level="high",
        interpretation_status="done",
    )
    await factory.result(
        patient_id=patient_id,
        instrument_code=I_PENDING,
        date_time=just_now,
        indicator="result",
        value=1,
        risk_level="high",
        interpretation_status="done",
    )
    await factory.result(
        patient_id=patient_id,
        instrument_code=I_STALE,
        date_time=long_ago,
        indicator="result",
        value=1,
        risk_level="high",
        interpretation_status="done",
    )

    await factory.calc_status(
        patient_id=patient_id,
        instrument_code=I_CALCULATED,
        status="calculated",
        date_time=long_ago + timedelta(seconds=1),
    )
    await factory.calc_status(
        patient_id=patient_id,
        instrument_code=I_INSUFFICIENT,
        status="insufficient_data",
        reason_code="missing_required_parameters",
        missing_parameter_codes=[P_PRESSURE],
        date_time=long_ago,
    )

    await factory.interpretation(
        patient_id=patient_id,
        system_code=SYSTEM,
        risk_level="high",
        diseases=[DISEASE],
        risk_factors_code=[RF_BMI, RF_SMOKE],
        doctors_code=[str(DOCTOR_CODE)],
        date_time=long_ago,
    )
    await factory.interpretation_status(
        patient_id=patient_id,
        system_code=SYSTEM,
        date_time=long_ago + timedelta(seconds=1),
        doctors=("empty", InterpretationReasonCode.NO_REFERENCE_ROW.value),
    )

    # Справочник факторов: два бакета одного кода по ИМТ, курение, давление и посторонний показатель.
    representative_trigger_code = (
        await factory.risk_factor(
            RF_BMI,
            parameter_code=P_BMI,
            system_code=SYSTEM,
            description="Повышенный индекс массы тела",
            reasoning="Клиническое обоснование по ИМТ",
            min_param_value=BMI_REPRESENTATIVE[0],
            max_param_value=BMI_REPRESENTATIVE[1],
        )
    ).trigger
    # Второй бакет того же фактора — только триггер: строка risk_factors уже заведена выше.
    superseded_trigger_code = await factory.risk_factor_trigger(
        code=RF_BMI,
        parameter_code=P_BMI,
        system_code=SYSTEM,
        min_param_value=BMI_SUPERSEDED[0],
        max_param_value=BMI_SUPERSEDED[1],
    )
    await factory.risk_factor(
        RF_SMOKE,
        parameter_code=P_SMOKE,
        system_code=SYSTEM,
        description="Курение",
        reasoning="Клиническое обоснование по курению",
        param_value="Да",
    )
    await factory.risk_factor(
        RF_PRESSURE, parameter_code=P_PRESSURE, system_code=SYSTEM, description="Повышенное давление", param_value="Да"
    )
    await factory.risk_factor(
        RF_FOREIGN,
        parameter_code=P_FOREIGN,
        system_code=SYSTEM,
        description="Фактор по постороннему показателю",
        param_value="Да",
    )

    # Сработавшие факторы прошлого прогона: оба бакета ИМТ (один вытеснил другой) и курение,
    # ответ на которое пациент с тех пор поменял.
    await factory.risk_factor_match(
        patient_id=patient_id,
        system_code=SYSTEM,
        trigger_code=representative_trigger_code,
        code=RF_BMI,
        parameter_code=P_BMI,
        min_param_value=BMI_REPRESENTATIVE[0],
        max_param_value=BMI_REPRESENTATIVE[1],
        date_time=long_ago + timedelta(seconds=1),
    )
    await factory.risk_factor_match(
        patient_id=patient_id,
        system_code=SYSTEM,
        trigger_code=superseded_trigger_code,
        code=RF_BMI,
        parameter_code=P_BMI,
        min_param_value=BMI_SUPERSEDED[0],
        max_param_value=BMI_SUPERSEDED[1],
        is_representative=False,
        date_time=long_ago + timedelta(seconds=1),
    )
    old_smoke_trigger_code = (
        await factory.risk_factor(
            f"{RF_SMOKE}_OLD",
            parameter_code=P_SMOKE,
            system_code=SYSTEM,
            description="Курение (прошлый бакет)",
            param_value="Да",
        )
    ).trigger
    await factory.risk_factor_match(
        patient_id=patient_id,
        system_code=SYSTEM,
        trigger_code=old_smoke_trigger_code,
        code=RF_SMOKE,
        parameter_code=P_SMOKE,
        param_value="Да",
        date_time=long_ago + timedelta(seconds=1),
    )

    # Оценки заведены по курению и давлению; у ИМТ строки под условие нет — признак неполноты
    # справочника, и одновременно условие, которое первый источник факторов не отбирает вовсе.
    await factory.parameter_score(parameter_code=P_SMOKE, system_code=SYSTEM, score=Decimal("1"), value="Нет")
    await factory.parameter_score(parameter_code=P_PRESSURE, system_code=SYSTEM, score=Decimal("2"), value="Да")
    await db_session.flush()
    return Case(patient_id, seeded_at)


async def _service(db_session: AsyncSession) -> ExplanationService:
    return ExplanationService(
        db_session,
        await make_http_catalog(db_session),
        await make_calc_catalog(db_session),
        await make_interpretation_catalog(db_session),
    )


def _system(response: CaseExplanationResponse) -> SystemExplanation:
    systems = [item for item in response.systems if item.system_code == SYSTEM]
    assert systems, "система засеянного случая отсутствует в ответе"
    return systems[0]


def _instrument(system: SystemExplanation, code: str) -> InstrumentExplanation:
    items = [item for item in system.instruments if item.instrument_code == code]
    assert items, f"инструмент {code} отсутствует в ответе"
    return items[0]


def _factor(system: SystemExplanation, code: str, *, min_value: str, max_value: str) -> RiskFactorExplanation:
    items = [
        item
        for item in system.risk_factors
        if item.risk_factor_code == code
        and (item.condition.min_value, item.condition.max_value) == (min_value, max_value)
    ]
    assert items, f"триггер {code} [{min_value}, {max_value}] отсутствует в ответе"
    return items[0]


# --- Полнота состава ---


async def test_instrument_without_collected_row_is_present(db_session: AsyncSession, case: Case) -> None:
    response = await (await _service(db_session)).explain_case(case.patient_id)
    system = _system(response)
    codes = {item.instrument_code for item in system.instruments}
    assert {I_CALCULATED, I_INSUFFICIENT, I_PENDING, I_STALE, I_UNTOUCHED, I_NOT_CALCULATED} <= codes


async def test_instrument_outside_systems_is_present(db_session: AsyncSession, case: Case) -> None:
    response = await (await _service(db_session)).explain_case(case.patient_id)
    assert I_OUTSIDE in {item.instrument_code for item in response.instruments_outside_systems}


async def test_three_absent_row_cases_are_distinguishable(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    assert _instrument(system, I_UNTOUCHED).explanation_state == InstrumentExplanationState.QUESTIONNAIRE_NOT_STARTED
    assert _instrument(system, I_NOT_CALCULATED).explanation_state == InstrumentExplanationState.NOT_CALCULATED
    assert _instrument(system, I_STALE).explanation_state == InstrumentExplanationState.MISSING


# --- Готовность ---


async def test_fresh_result_without_explanation_reports_pending(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    pending = _instrument(system, I_PENDING)
    assert pending.explanation_state == InstrumentExplanationState.PENDING
    # Именно сообщение о подготовке, а не отсутствие причины.
    assert "готовится" in pending.explanation_state_text
    assert pending.reason_code is None


async def test_stale_explanation_is_marked_as_previous_run(db_session: AsyncSession, case: Case) -> None:
    # Результат перезаписан позже строки сбора — объяснение относится к прошлому прогону.
    await db_session.execute(
        text("UPDATE results SET date_time = :dt WHERE patient_id = :pid AND instrument_code = :i"),
        {"dt": case.seeded_at, "pid": case.patient_id, "i": I_CALCULATED},
    )
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    calculated = _instrument(system, I_CALCULATED)
    assert calculated.explanation_state == InstrumentExplanationState.PREVIOUS_RUN
    assert "прогону" in calculated.explanation_state_text
    # Объяснение прошлого прогона не теряется, но за актуальное не выдаётся.
    assert calculated.status == "calculated"


async def test_matching_explanation_is_reported_as_matches(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    assert system.explanation_state == SystemExplanationState.MATCHES
    assert _instrument(system, I_CALCULATED).explanation_state == InstrumentExplanationState.MATCHES


# --- Перевод кодов ---


async def test_reference_names_replace_codes(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    assert system.system_name == SYSTEM_NAME

    insufficient = _instrument(system, I_INSUFFICIENT)
    assert insufficient.instrument_name == "Без данных"
    assert [item.name for item in insufficient.missing_parameters] == ["Артериальное давление"]
    # Код причины сохраняется рядом с формулировкой.
    assert insufficient.reason_code == "missing_required_parameters"
    assert insufficient.reason_text is not None
    parameters = {item.code: item for item in _instrument(system, I_CALCULATED).parameters}
    assert parameters[P_BMI].name == "Индекс массы тела"
    assert parameters[P_BMI].required is True
    assert parameters[P_BMI].answer == "31"

    assert [doctor.name for doctor in system.doctors] == [DOCTOR_NAME]
    assert [(item.code, item.name) for item in system.diseases] == [(DISEASE, DISEASE_NAME)]
    assert system.doctors_reason.reason_code == InterpretationReasonCode.NO_REFERENCE_ROW.value
    assert system.doctors_reason.reason_text is not None


async def test_status_without_blocking_detail_returns_empty_list(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))

    assert system.blocking_instruments == []


async def test_status_written_before_rule_change_keeps_blocking_instruments(
    db_session: AsyncSession, case: Case
) -> None:
    """Строка, записанная до отказа от обнуления заболеваний, объясняется как сохранена, до перезаписи."""
    await db_session.execute(
        text(
            "UPDATE interpretation_statuses SET diseases_status = 'empty', diseases_reason_code = :reason,"
            " blocking_instrument_codes = :blocking WHERE patient_id = :pid AND system_code = :system"
        ),
        {
            "reason": InterpretationReasonCode.BLOCKED_BY_OTHER_INSTRUMENTS.value,
            "blocking": [I_CALCULATED],
            "pid": case.patient_id,
            "system": SYSTEM,
        },
    )

    system = _system(await (await _service(db_session)).explain_case(case.patient_id))

    assert system.diseases_reason.reason_code == InterpretationReasonCode.BLOCKED_BY_OTHER_INSTRUMENTS.value
    assert system.diseases_reason.reason_text is not None
    assert [item.code for item in system.blocking_instruments] == [I_CALCULATED]
    assert system.blocking_instruments[0].name == "Рассчитанный"


async def test_risk_factor_carries_reasoning(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    bmi = _factor(system, RF_BMI, min_value=BMI_REPRESENTATIVE[0], max_value=BMI_REPRESENTATIVE[1])
    assert bmi.name == "Повышенный индекс массы тела"
    assert bmi.reasoning == "Клиническое обоснование по ИМТ"
    assert bmi.parameter_name == "Индекс массы тела"


# --- Ответ пациента рядом с сохранённым условием ---


async def test_condition_and_current_answer_are_shown_together(db_session: AsyncSession, case: Case) -> None:
    bmi = _factor(
        _system(await (await _service(db_session)).explain_case(case.patient_id)),
        RF_BMI,
        min_value=BMI_REPRESENTATIVE[0],
        max_value=BMI_REPRESENTATIVE[1],
    )
    assert (bmi.condition.min_value, bmi.condition.max_value) == BMI_REPRESENTATIVE
    assert bmi.answer == "31"
    assert bmi.answer_matches_condition is True
    assert bmi.modifiability == "modifiable"


async def test_changed_answer_is_reported_as_divergence(db_session: AsyncSession, case: Case) -> None:
    # Курение сработало по условию «Да», а текущий ответ пациента — «Нет».
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    smoke = next(item for item in system.risk_factors if item.risk_factor_code == RF_SMOKE)
    assert smoke.condition.value_text == "Да"
    assert smoke.answer == "Нет"
    assert smoke.answer_matches_condition is False


# --- Дедупликация и внутренние величины ---


async def test_superseded_factor_is_visible(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    bmi_rows = {
        (item.condition.min_value, item.condition.max_value): item
        for item in system.risk_factors
        if item.risk_factor_code == RF_BMI
    }
    assert set(bmi_rows) == {BMI_REPRESENTATIVE, BMI_SUPERSEDED}
    assert bmi_rows[BMI_REPRESENTATIVE].is_representative is True
    assert bmi_rows[BMI_SUPERSEDED].is_representative is False


async def test_score_reference_gap_is_reported_without_numbers(db_session: AsyncSession, case: Case) -> None:
    system = _system(await (await _service(db_session)).explain_case(case.patient_id))
    # По ИМТ строки в справочнике оценок нет — неполнота справочника; по курению есть.
    bmi = _factor(system, RF_BMI, min_value=BMI_REPRESENTATIVE[0], max_value=BMI_REPRESENTATIVE[1])
    assert bmi.score_reference_incomplete is True
    smoke = next(item for item in system.risk_factors if item.risk_factor_code == RF_SMOKE)
    assert smoke.score_reference_incomplete is False


async def test_response_has_no_internal_ranking_values(db_session: AsyncSession, case: Case) -> None:
    response = await (await _service(db_session)).explain_case(case.patient_id)
    forbidden = {"score", "weight", "rank", "rang", "position", "priority"}
    assert not _keys(response.model_dump(by_alias=True)) & forbidden


# --- Пересчёт несработавших факторов ---


async def test_recompute_reports_reason_per_candidate(db_session: AsyncSession, case: Case) -> None:
    response = await (await _service(db_session)).recompute_unmatched_risk_factors(
        patient_id=case.patient_id, system_code=SYSTEM
    )
    by_code = {item.risk_factor_code: item for item in response.items}

    # Ожидаемый, но не сработавший фактор: давление не отвечено.
    assert by_code[RF_PRESSURE].reason_code == "parameter_not_answered"
    assert by_code[RF_PRESSURE].reason_text
    # Курение: ответ есть, в условие не попадает.
    assert by_code[RF_SMOKE].reason_code == "operator_mismatch"
    assert by_code[RF_SMOKE].answer == "Нет"
    # Посторонний показатель: к системе не относится.
    assert by_code[RF_FOREIGN].reason_code == "parameter_not_in_system"
    # ИМТ: ответ 31 попадает в оба бакета (30–40 и 25–35), но оценки по паре «показатель × система»
    # нет, и первый источник факторов такое условие не отбирает — сработавшим его показать нельзя.
    assert {item.reason_code for item in response.items if item.risk_factor_code == RF_BMI} == {
        "parameter_score_missing"
    }


async def test_recompute_is_marked_as_current_data(db_session: AsyncSession, case: Case) -> None:
    response = await (await _service(db_session)).recompute_unmatched_risk_factors(
        patient_id=case.patient_id, system_code=SYSTEM
    )
    assert response.recomputed_on_current_data is True
    assert response.recomputed_at >= case.seeded_at


async def test_recompute_writes_nothing(db_session: AsyncSession, case: Case) -> None:
    before = await _diagnostic_row_counts(db_session, case.patient_id)
    await (await _service(db_session)).recompute_unmatched_risk_factors(patient_id=case.patient_id, system_code=SYSTEM)
    assert await _diagnostic_row_counts(db_session, case.patient_id) == before


# --- Признак доступности сбора ---


async def test_diagnostics_available_does_not_depend_on_collected_rows(
    db_session: AsyncSession, factory: Factory, case: Case
) -> None:
    """Признак отвечает про сбор в базе, а не про наличие строк у пациента.

    У пациента без единой строки диагностики (сбор только включили, либо диагностика перезалита
    миграцией 0120) признак остаётся истинным: иначе «сбора нет» и «по пациенту ещё не считали»
    пришли бы одним значением, а читающая сторона различает их по `explanationState`.
    """
    empty_patient = f"{PREFIX}{uuid4()}"
    await factory.patient(patient_id=empty_patient)
    await db_session.flush()
    assert await _diagnostic_row_counts(db_session, empty_patient) == (0, 0, 0)

    response = await (await _service(db_session)).explain_case(empty_patient)

    assert response.diagnostics_available is True


async def _diagnostic_row_counts(session: AsyncSession, patient_id: str) -> tuple[int, int, int]:
    counts = []
    for table in ("calculation_statuses", "interpretation_statuses", "risk_factor_matches"):
        row = await session.execute(
            text(f"SELECT count(*) FROM {table} WHERE patient_id = :pid"),  # noqa: S608
            {"pid": patient_id},
        )
        counts.append(row.scalar_one())
    return counts[0], counts[1], counts[2]


def _keys(value: Any) -> set[str]:
    """Все ключи ответа, включая вложенные: тест внутренних величин смотрит на весь документ."""
    if isinstance(value, dict):
        return {str(key) for key in value} | {key for item in value.values() for key in _keys(item)}
    if isinstance(value, list):
        return {key for item in value for key in _keys(item)}
    return set()
