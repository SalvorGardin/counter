"""End-to-end интеграционные тесты рекомендованных исследований.

Справочники исследований сеются тестом: содержимое засеянных миграциями строк меняется вместе
с каталогом, а проверяются здесь правила подбора, а не наполнение справочника.
"""

import logging
from collections.abc import Callable

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.constants import RiskLevel
from src.services.risk_communication.domain.exceptions import ClientNotFoundError, SystemCodeNotFoundError
from src.services.risk_profile.domain.constants import ExaminationCategory, ExaminationType
from src.services.risk_profile.domain.exceptions import ClientGenderNotFoundError, GenderNotFoundReason
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import LogSink, make_http_catalog
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_GENDER
from tests.factories import Factory, unique_id, unique_rang


async def _make_service(session: AsyncSession) -> RiskProfileService:
    """Фиксирует засеянные строки и отдаёт сервис на каталоге, собранном по ним."""
    await session.commit()
    return RiskProfileService(session, await make_http_catalog(session))


async def _seed_gender(factory: Factory, patient_id: str, gender: str) -> None:
    await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_GENDER, value=gender)


def _record_of(logs: LogSink, message: str) -> logging.LogRecord:
    return next(record for record in logs.records if record.getMessage() == message)


@pytest.mark.asyncio
async def test_disease_group_examinations_are_returned(db_session: AsyncSession, factory: Factory) -> None:
    """Группа берётся из `interpretations.diseases` кодом справочника; чек-ап не добавляется."""
    pid = unique_id("p")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    diagnostic = await factory.examination(examination_type=ExaminationType.INSTRUMENTAL)
    checkup_only = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.EXTENDED
    )
    await factory.disease_examination(disease_code=disease_code, examination_code=diagnostic)
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup_only)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    item = response.system_examinations[0]
    assert item.system_code == system_code
    assert item.analyses.basic == []
    assert item.analyses.extended == [analysis]
    assert item.diagnostics == [diagnostic]


@pytest.mark.asyncio
async def test_two_groups_fill_both_packages_without_repeats(db_session: AsyncSession, factory: Factory) -> None:
    """Исследования двух групп одной системы объединяются: базовый пакет — базовые анализы,
    расширенный — полный набор анализов системы. Анализ, пришедший по двум группам как `extended`
    и `basic`, учитывается базовым, и внутри каждого пакета UUID не повторяются."""
    pid = unique_id("p")
    system_code = await factory.system()
    first_group = await factory.disease(system_code=system_code)
    second_group = await factory.disease(system_code=system_code)
    basic_analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    extended_analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    shared_analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    diagnostic = await factory.examination(examination_type=ExaminationType.INSTRUMENTAL)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid,
        system_code=system_code,
        risk_level=RiskLevel.HIGH,
        diseases=[first_group, second_group],
    )
    await factory.disease_examination(
        disease_code=first_group, examination_code=basic_analysis, category=ExaminationCategory.BASIC
    )
    await factory.disease_examination(
        disease_code=first_group, examination_code=shared_analysis, category=ExaminationCategory.EXTENDED
    )
    await factory.disease_examination(disease_code=first_group, examination_code=diagnostic)
    await factory.disease_examination(
        disease_code=second_group, examination_code=extended_analysis, category=ExaminationCategory.EXTENDED
    )
    await factory.disease_examination(
        disease_code=second_group, examination_code=shared_analysis, category=ExaminationCategory.BASIC
    )
    await factory.disease_examination(disease_code=second_group, examination_code=diagnostic)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    analyses = response.system_examinations[0].analyses
    # Порядок UUID контрактом не зафиксирован, поэтому состав сверяется множествами, а
    # дедупликация — длиной перечня.
    assert set(analyses.basic) == {basic_analysis, shared_analysis}
    assert set(analyses.extended) == {basic_analysis, extended_analysis, shared_analysis}
    assert len(analyses.basic) == 2
    assert len(analyses.extended) == 3
    assert response.system_examinations[0].diagnostics == [diagnostic]


@pytest.mark.asyncio
async def test_checkup_is_filtered_by_client_gender(db_session: AsyncSession, factory: Factory) -> None:
    """Групп нет → общий чек-ап: строки без пола и строки пола клиента, а лабораторные анализы
    чек-апа входят только в базовый пакет, расширенный остаётся пустым."""
    pid = unique_id("p")
    system_code = await factory.system()
    common = await factory.examination(examination_type=ExaminationType.LABORATORY)
    female_only = await factory.examination(examination_type=ExaminationType.LABORATORY)
    male_only = await factory.examination(examination_type=ExaminationType.INSTRUMENTAL)
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    await factory.interpretation(patient_id=pid, system_code=system_code, risk_level=RiskLevel.MEDIUM, diseases=[])
    await factory.system_checkup_examination(system_code=system_code, examination_code=common)
    await factory.system_checkup_examination(
        system_code=system_code, examination_code=female_only, gender=GENDER_FEMALE
    )
    await factory.system_checkup_examination(system_code=system_code, examination_code=male_only, gender=GENDER_MALE)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    item = response.system_examinations[0]
    assert item.analyses.basic == [common]
    assert item.analyses.extended == []
    assert item.diagnostics == [male_only]


@pytest.mark.asyncio
@pytest.mark.parametrize("link_inactive_examination", [False, True])
async def test_group_without_active_examinations_falls_back_to_checkup(
    db_session: AsyncSession, factory: Factory, link_inactive_examination: bool
) -> None:
    """Группа сопоставлена, но подходящих исследований у неё нет — ни одной связи либо
    единственная связь ведёт на неактивное исследование: система идёт по пути общего чек-апа."""
    pid = unique_id("p")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    if link_inactive_examination:
        inactive = await factory.examination(examination_type=ExaminationType.LABORATORY, status="inactive")
        await factory.disease_examination(
            disease_code=disease_code, examination_code=inactive, category=ExaminationCategory.BASIC
        )
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    item = response.system_examinations[0]
    assert item.analyses.basic == [checkup]
    assert item.analyses.extended == []
    assert item.diagnostics == []


@pytest.mark.asyncio
async def test_group_with_an_active_examination_keeps_the_checkup_out(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Хватает одной группы с активным исследованием: чек-ап не добавляется, а связь на
    неактивное исследование в ответ не попадает."""
    pid = unique_id("p")
    system_code = await factory.system()
    inactive_group = await factory.disease(system_code=system_code)
    active_group = await factory.disease(system_code=system_code)
    inactive = await factory.examination(examination_type=ExaminationType.LABORATORY, status="inactive")
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    await factory.interpretation(
        patient_id=pid,
        system_code=system_code,
        risk_level=RiskLevel.HIGH,
        diseases=[inactive_group, active_group],
    )
    await factory.disease_examination(
        disease_code=inactive_group, examination_code=inactive, category=ExaminationCategory.BASIC
    )
    await factory.disease_examination(
        disease_code=active_group, examination_code=analysis, category=ExaminationCategory.EXTENDED
    )
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    item = response.system_examinations[0]
    assert item.analyses.basic == []
    assert item.analyses.extended == [analysis]
    assert item.diagnostics == []


@pytest.mark.asyncio
async def test_disease_group_of_another_system_is_selected(db_session: AsyncSession, factory: Factory) -> None:
    """Принадлежность группы системе интерпретации не проверяется: код группы уникален глобально,
    а состав групп системы определяет алгоритм интерпретации, не подбор."""
    pid = unique_id("p")
    system_code = await factory.system()
    other_system_code = await factory.system()
    disease_code = await factory.disease(system_code=other_system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    item = response.system_examinations[0]
    assert item.system_code == system_code
    assert item.analyses.basic == [analysis]


@pytest.mark.asyncio
async def test_unknown_disease_code_falls_back_to_checkup(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Код вне справочника пропускается с предупреждением; система идёт по пути общего чек-апа."""
    pid = unique_id("p")
    system_code = await factory.system()
    other_system_code = await factory.system()
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    unknown_code = unique_id("missing-disease")
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_FEMALE)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[unknown_code]
    )
    # Вторая интерпретация того же клиента: с одной строкой в таблице утверждение об
    # interpretation_id прошло бы при любом идентификаторе в событии.
    await factory.interpretation(
        patient_id=pid, system_code=other_system_code, risk_level=RiskLevel.LOW, diseases=[unknown_code]
    )
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    assert response.system_examinations[0].analyses.basic == [checkup]
    interpretation_id = (
        await db_session.execute(
            text("SELECT interpretation_id FROM interpretations WHERE patient_id = :pid AND system_code = :s"),
            {"pid": pid, "s": system_code},
        )
    ).scalar_one()
    message = next(msg for msg in captured_app_logs.messages() if msg.startswith("DISEASE_MAPPING_NOT_FOUND"))
    assert captured_app_logs.context_of(message) == {
        "client_id": pid,
        "system_code": system_code,
        "disease_value": unknown_code,
        "interpretation_id": interpretation_id,
    }
    assert _record_of(captured_app_logs, message).levelno == logging.WARNING


@pytest.mark.asyncio
async def test_system_without_checkup_rows_is_omitted(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Незаполненный чек-ап — предупреждение в журнале, а не ошибка клиенту."""
    pid = unique_id("p")
    system_code = await factory.system()
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    await factory.interpretation(patient_id=pid, system_code=system_code, risk_level=RiskLevel.MEDIUM, diseases=None)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    assert response.system_examinations == []
    message = next(msg for msg in captured_app_logs.messages() if msg.startswith("SYSTEM_CHECKUP_NOT_CONFIGURED"))
    assert captured_app_logs.context_of(message) == {"client_id": pid, "system_code": system_code}
    assert _record_of(captured_app_logs, message).levelno == logging.WARNING


@pytest.mark.asyncio
async def test_low_risk_system_is_skipped(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.LOW, diseases=[disease_code]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    assert response.system_examinations == []


@pytest.mark.asyncio
async def test_pregnant_returns_empty(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid, is_pregnant=True)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    assert response.system_examinations == []


@pytest.mark.asyncio
@pytest.mark.parametrize("is_pregnant", [False, True])
async def test_common_system_code_returns_empty(db_session: AsyncSession, factory: Factory, is_pregnant: bool) -> None:
    """COMMON заканчивает подбор и сам по себе, и в паре с беременностью."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=is_pregnant)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code="COMMON")

    assert response.system_examinations == []


@pytest.mark.asyncio
async def test_unknown_client_is_rejected_before_the_common_system_code(db_session: AsyncSession) -> None:
    """Клиент ищется раньше разбора systemCode: несуществующему клиенту COMMON пустого ответа
    не даёт."""
    service = await _make_service(db_session)

    with pytest.raises(ClientNotFoundError):
        await service.get_examinations(client_id=unique_id("missing-client"), system_code="COMMON")


@pytest.mark.asyncio
async def test_unknown_client_raises(db_session: AsyncSession) -> None:
    service = await _make_service(db_session)

    with pytest.raises(ClientNotFoundError):
        await service.get_examinations(client_id=unique_id("missing-client"), system_code=None)


@pytest.mark.asyncio
@pytest.mark.parametrize("is_pregnant", [False, True])
@pytest.mark.parametrize(
    "make_missing_code",
    [lambda _seeded: unique_id("missing-system"), lambda seeded: seeded.lower()],
    ids=["absent", "other-case"],
)
async def test_unknown_system_code_raises_before_the_pregnancy_branch(
    db_session: AsyncSession,
    factory: Factory,
    make_missing_code: Callable[[str], str],
    is_pregnant: bool,
) -> None:
    """systemCode сверяется со справочником раньше признака беременности, а сверка точная:
    код засеянной системы в другом регистре тоже не находится."""
    pid = unique_id("p")
    system_code = await factory.system()
    await factory.patient(patient_id=pid, is_pregnant=is_pregnant)

    service = await _make_service(db_session)

    with pytest.raises(SystemCodeNotFoundError):
        await service.get_examinations(client_id=pid, system_code=make_missing_code(system_code))


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("answer", "expired", "reason"),
    [
        (None, False, GenderNotFoundReason.MISSING),
        (GENDER_MALE, True, GenderNotFoundReason.EXPIRED),
        ("Иное", False, GenderNotFoundReason.UNRECOGNIZED),
    ],
)
async def test_gender_is_required_only_on_the_checkup_path(
    db_session: AsyncSession, factory: Factory, answer: str | None, expired: bool, reason: GenderNotFoundReason
) -> None:
    """Пол нужен только общему чек-апу, и причина отказа разводит «не задавали», «протух», «вне словаря»."""
    pid = unique_id("p")
    system_code = await factory.system()
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    if answer is not None:
        await _seed_gender(factory, pid, answer)
    if expired:
        await factory.expire_answer(patient_id=pid, parameter_code=PARAMETER_CODE_GENDER)
    await factory.interpretation(patient_id=pid, system_code=system_code, risk_level=RiskLevel.MEDIUM, diseases=[])
    await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    with pytest.raises(ClientGenderNotFoundError) as exc_info:
        await service.get_examinations(client_id=pid, system_code=system_code)

    error = exc_info.value
    assert (error.client_id, error.reason, error.gender_value) == (pid, reason, answer)


@pytest.mark.asyncio
async def test_gender_is_required_when_any_system_needs_the_checkup(db_session: AsyncSession, factory: Factory) -> None:
    """Пола нет, а чек-ап нужен хотя бы одной системе ответа — по шагу 8 контракта выполнение
    запроса прекращается: система, закрытая исследованиями групп, ответа не спасает."""
    pid = unique_id("p")
    covered_system = await factory.system()
    checkup_system = await factory.system()
    disease_code = await factory.disease(system_code=covered_system)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=covered_system, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.interpretation(patient_id=pid, system_code=checkup_system, risk_level=RiskLevel.MEDIUM, diseases=[])
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )
    await factory.system_checkup_examination(system_code=checkup_system, examination_code=checkup)

    service = await _make_service(db_session)

    with pytest.raises(ClientGenderNotFoundError):
        await service.get_examinations(client_id=pid, system_code=None)


@pytest.mark.asyncio
async def test_gender_is_not_read_when_groups_cover_the_system(db_session: AsyncSession, factory: Factory) -> None:
    """Все системы ответа закрыты исследованиями групп — ответ отдаётся и без заданного пола."""
    pid = unique_id("p")
    system_code = await factory.system()
    disease_code = await factory.disease(system_code=system_code)
    analysis = await factory.examination(examination_type=ExaminationType.LABORATORY)
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[disease_code]
    )
    await factory.disease_examination(
        disease_code=disease_code, examination_code=analysis, category=ExaminationCategory.BASIC
    )

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=system_code)

    assert response.system_examinations[0].analyses.basic == [analysis]


@pytest.mark.asyncio
async def test_systems_are_ordered_by_rang(db_session: AsyncSession, factory: Factory) -> None:
    """Порядок задаёт `systems.rang`: система с большим рангом создана первой и идёт второй."""
    pid = unique_id("p")
    low, high = sorted((unique_rang(), unique_rang()))
    first = await factory.system(rang=high)
    second = await factory.system(rang=low)
    await factory.patient(patient_id=pid)
    await _seed_gender(factory, pid, GENDER_MALE)
    for system_code in (first, second):
        checkup = await factory.examination(examination_type=ExaminationType.LABORATORY)
        await factory.interpretation(patient_id=pid, system_code=system_code, risk_level=RiskLevel.HIGH, diseases=[])
        await factory.system_checkup_examination(system_code=system_code, examination_code=checkup)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=None)

    assert [item.system_code for item in response.system_examinations] == [second, first]


@pytest.mark.asyncio
async def test_read_path_leaves_no_open_transaction(db_session: AsyncSession, factory: Factory) -> None:
    """Клиент без интерпретаций получает пустой ответ, а скоуп запроса закрывается COMMIT'ом,
    а не откатом на закрытии сессии."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)

    service = await _make_service(db_session)
    response = await service.get_examinations(client_id=pid, system_code=None)

    assert response.system_examinations == []
    assert db_session.in_transaction() is False
