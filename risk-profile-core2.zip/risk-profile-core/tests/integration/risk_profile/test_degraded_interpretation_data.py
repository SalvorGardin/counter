"""Плохие данные продюсера интерпретации не должны ломать чтение medical-risk.

Три деградации read-эндпоинта: нечисловой код врача, рекомендация неизвестной группы и
интерпретация с `risk_level IS NULL` при непустом тексте. Во всех трёх случаях контракт один —
ответ 200 предсказуемой формы, а не 500 и не молчаливый пропуск без следа в логах.
"""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.catalog.http import HttpCatalog
from src.services.risk_profile.domain.doctors import resolve_doctor_specs
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import LogSink, make_http_catalog
from tests.factories import Factory, now_utc, unique_doctor_code, unique_id

_SYSTEM = "CVD"
_BAD_DOCTOR_CODE = "кардиолог"


async def _make_catalog(session: AsyncSession) -> HttpCatalog:
    await session.commit()
    return await make_http_catalog(session)


async def _make_service(session: AsyncSession) -> RiskProfileService:
    return RiskProfileService(session, await _make_catalog(session))


@pytest.mark.asyncio
async def test_non_integer_doctor_code_is_skipped_with_warning(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """`doctors.code` — integer, `interpretations.doctors_code` — text[]. Нечисловой элемент
    пропускается, остальные врачи доезжают до ответа."""
    pid = unique_id("p")
    doc_code = unique_doctor_code()
    await factory.patient(patient_id=pid)
    await factory.doctor(code=doc_code, description="Кардиолог")
    await factory.interpretation(
        patient_id=pid,
        system_code=_SYSTEM,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now_utc(),
        doctors_code=[_BAD_DOCTOR_CODE, str(doc_code)],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=_SYSTEM)

    item = response.system_interpretation_results[0]
    assert item.doctor_specializations is not None
    assert [spec.code for spec in item.doctor_specializations] == [doc_code]
    assert "non-integer doctor code in interpretations.doctors_code" in captured_app_logs.messages()


@pytest.mark.asyncio
async def test_resolve_doctor_specs_skips_non_integer_code(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Тот же контракт у раскодировки кодов: её зовёт и объяснение, где интерпретации те же самые."""
    doc_code = unique_doctor_code()
    await factory.doctor(code=doc_code, description="Кардиолог")
    catalog = await _make_catalog(db_session)

    doctors = resolve_doctor_specs(catalog.doctors, {_BAD_DOCTOR_CODE, str(doc_code)})

    assert set(doctors) == {str(doc_code)}
    assert "non-integer doctor code in interpretations.doctors_code" in captured_app_logs.messages()


@pytest.mark.asyncio
async def test_resolve_doctor_specs_returns_empty_map_when_every_code_is_bad(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Ни одного пригодного кода — пустая карта."""
    catalog = await _make_catalog(db_session)

    assert resolve_doctor_specs(catalog.doctors, {_BAD_DOCTOR_CODE}) == {}


@pytest.mark.asyncio
async def test_recommendation_of_unknown_group_is_dropped(db_session: AsyncSession, factory: Factory) -> None:
    """Группа рекомендации не `common_group` и не `risk_factor_group` — строка не попадает в ответ.

    Ответ пациенту собирается только из известных групп: новая группа в справочнике должна
    сначала получить смысл в коде, а до тех пор её содержимое показывать нельзя.
    """
    pid = unique_id("p")
    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid,
        system_code=_SYSTEM,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now_utc(),
    )
    await factory.recommendation(recommendations_group="common_group", system_code=_SYSTEM, name="Известная группа")
    await factory.recommendation(
        recommendations_group="experimental_group", system_code=_SYSTEM, name="Неизвестная группа"
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=_SYSTEM)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert [rec.title for rec in item.risk.recommendations] == ["Известная группа"]


@pytest.mark.asyncio
async def test_null_risk_level_with_text_completes_with_null_risk(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Текст есть, уровня риска нет — статус `completed`, но `risk` пустой.

    Отдать текст без уровня значило бы показать пациенту вывод, которого модель не сделала;
    противоречие данных остаётся в логах как warning.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid,
        system_code=_SYSTEM,
        risk_level=None,
        text_value="Текст без уровня риска",
        date_time=now_utc(),
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=_SYSTEM)

    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "completed"
    assert item.risk is None
    assert item.interpretation_date_time is not None
    assert (
        "interpretation has NULL risk_level but non-null text — returning completed with risk=null"
        in captured_app_logs.messages()
    )
