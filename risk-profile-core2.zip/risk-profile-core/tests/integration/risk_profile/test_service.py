"""End-to-end integration-тесты RiskProfileService.

Сидинг идёт через text() (как в risk_communication) — быстро и наглядно.
Источники данных полностью изменены под новый алгоритм интерпретации (issue #50):
diseases / risk_factors_code / doctors_code читаются прямо из `interpretations`,
recommendations отбираются по группам risk_factor_group + common_group.
"""

from datetime import timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.services.risk_communication.domain.exceptions import ClientNotFoundError, SystemCodeNotFoundError
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import make_http_catalog
from tests.consts import GENDER_MALE, PARAMETER_CODE_BIRTHDATE, PARAMETER_CODE_GENDER
from tests.factories import Factory, now_utc, unique_doctor_code, unique_id


async def _make_service(session: AsyncSession) -> RiskProfileService:
    """Фиксирует засеянные строки и отдаёт сервис.

    Сидинг идёт по той же сессии и открывает на ней транзакцию, а `get_medical_risk` заводит
    свою через `session.begin()` — без коммита это «A transaction is already begun on this
    Session». Тот же приём, что в интеграционных тестах risk_communication: commit после сидинга
    оставляет сервису ту же форму транзакции, что и в проде.
    """
    await session.commit()
    return RiskProfileService(session, await make_http_catalog(session))


@pytest.mark.asyncio
async def test_read_path_leaves_no_open_transaction(db_session: AsyncSession, factory: Factory) -> None:
    """Успешное чтение закрывает свою транзакцию, а не оставляет её закрытию сессии.

    Оставленная открытой autobegin-транзакция откатывается при закрытии сессии, то есть каждое
    успешное чтение попадало бы в pg_stat_database.xact_rollback. Пин держит форму «BEGIN … COMMIT»
    на горячем read-эндпоинте.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)

    service = await _make_service(db_session)
    await service.get_medical_risk(client_id=pid, system_code=None)

    assert db_session.in_transaction() is False


@pytest.mark.asyncio
async def test_client_not_found_raises(db_session: AsyncSession) -> None:
    service = await _make_service(db_session)
    with pytest.raises(ClientNotFoundError):
        await service.get_medical_risk(client_id="absent-client", system_code=None)


@pytest.mark.asyncio
async def test_unknown_system_code_raises(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    await factory.patient(patient_id=pid)

    service = await _make_service(db_session)
    with pytest.raises(SystemCodeNotFoundError):
        await service.get_medical_risk(client_id=pid, system_code=unique_id("missing-system"))


@pytest.mark.asyncio
async def test_common_system_code_returns_empty(db_session: AsyncSession, factory: Factory) -> None:
    """systemCode=COMMON — псевдо-система, исключённая из per-system выдачи: 200 с пустым
    списком, а НЕ 404. Фиксируем продуктовое решение, чтобы валидация unknown-кода его не задела.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code="COMMON")

    assert response.system_interpretation_results == []
    # Нет применимых вопросов (systems пуст) → пустой знаменатель → 100 (шаг 6 wiki).
    assert response.completion_percentage == 100


@pytest.mark.asyncio
async def test_pregnant_returns_100_no_risk_data(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "CVD"
    await factory.patient(patient_id=pid, is_pregnant=True)

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert response.is_pregnant is True
    assert response.completion_percentage == 100
    assert response.last_calculation_date_time is None
    assert response.last_interpretation_date_time is None
    assert response.top_recommendations is None
    assert len(response.system_interpretation_results) == 1
    item = response.system_interpretation_results[0]
    assert item.system_code == sys_code
    assert item.interpretation_status is None
    assert item.system_completion_percentage == 100
    assert item.risk is None


@pytest.mark.asyncio
async def test_no_interpretation_returns_not_enough_data(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "ONCO"
    param_code = unique_id("p")
    instr_code = unique_id("i")
    q_code = unique_id("q")

    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.instrument(code=instr_code)
    await factory.link_parameter(instrument_code=instr_code, parameter_code=param_code)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr_code)
    await factory.question(code=q_code, group_code=1, is_skippable=True)
    # Вариант связывает вопрос с параметром системы (релевантность вариант→инструмент→система):
    # вопрос применим и не отвечён → applicable=1, progressed=0 → 0%.
    await factory.option(code=unique_id("o"), question_code=q_code, parameter_code=param_code, value=None)

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert len(response.system_interpretation_results) == 1
    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "not enough data"
    assert item.interpretation_date_time is None
    assert item.risk is None
    assert item.doctor_specializations is None
    assert item.disease_risks is None
    assert response.completion_percentage == 0
    assert item.system_completion_percentage == 0


@pytest.mark.asyncio
async def test_completed_high_reads_all_from_interpretations(db_session: AsyncSession, factory: Factory) -> None:
    """interpretation.diseases + .risk_factors_code + .doctors_code → диагностики/факторы/врачи."""
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    doc_code = unique_doctor_code()
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    # parameter_code на risk_factors остался обязательным в схеме — задаём заглушку.
    param_code = unique_id("p")
    await factory.parameter(code=param_code)

    # Заболевания хранятся кодами, наружу уходят названия из справочника; третий элемент —
    # повтор первого кода, дедупликация обязана оставить одно вхождение.
    disease_a = await factory.disease(unique_id("dis"), description="Болезнь A", system_code=sys_code)
    disease_b = await factory.disease(unique_id("dis"), description="Болезнь B", system_code=sys_code)

    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now,
        diseases=[disease_a, disease_b, disease_a],
        risk_factors_code=[rf_code],
        doctors_code=[str(doc_code)],
    )
    await factory.risk_factor(
        rf_code,
        system_code=sys_code,
        description="Курение",
        reasoning="Курение повышает нагрузку на сердце и сосуды.",
        param_value="yes",
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Отказ от курения",
        text_value="...",
    )
    await factory.doctor(code=doc_code, description="Кардиолог")

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "completed"
    assert item.interpretation_date_time is not None
    assert item.risk is not None
    assert item.risk.risk_level == "high"
    assert item.risk.description == "Высокий риск"
    assert item.risk.risk_factors is not None
    assert [rf.title for rf in item.risk.risk_factors] == ["Курение"]
    assert [rf.details for rf in item.risk.risk_factors] == ["Курение повышает нагрузку на сердце и сосуды."]
    assert [r.title for r in item.risk.recommendations] == ["Отказ от курения"]
    assert item.doctor_specializations is not None
    assert item.doctor_specializations[0].name == "Кардиолог"
    assert item.doctor_specializations[0].code == doc_code
    assert item.disease_risks is not None
    assert [d.name for d in item.disease_risks] == ["Болезнь A", "Болезнь B"]
    assert response.last_interpretation_date_time is not None
    assert response.top_recommendations is not None
    assert response.top_recommendations[0].title == "Отказ от курения"


@pytest.mark.asyncio
async def test_risk_factors_preserve_order_and_include_non_modifiable(
    db_session: AsyncSession, factory: Factory
) -> None:
    """#128: riskFactors[] включает факторы любой modifiability (с reasoning → details),
    но risk_factor_group-рекомендации по-прежнему отбираются только по модифицируемым.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_b = unique_id("rfb")
    rf_a = unique_id("rfa")
    rf_unmod = unique_id("rfu")
    rf_absent = unique_id("rfx")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="medium",
        text_value="x",
        date_time=now,
        # порядок ровно такой; absent — отсутствует в risk_factors, unmod — не modifiable.
        risk_factors_code=[rf_b, rf_unmod, rf_a, rf_absent],
    )
    await factory.risk_factor(rf_b, system_code=sys_code, description="B", reasoning="reason")
    await factory.risk_factor(rf_a, system_code=sys_code, description="A", reasoning="reason")
    await factory.risk_factor(
        rf_unmod, system_code=sys_code, description="U", modifiability="non_modifiable", reasoning="почему U"
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group", risk_factors_code=rf_a, system_code=sys_code, name="Рекомендация A"
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_unmod,
        system_code=sys_code,
        name="Рекомендация U",
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert item.risk.risk_factors is not None
    # немодифицируемый U больше не отбрасывается, порядок — как в risk_factors_code.
    assert [rf.title for rf in item.risk.risk_factors] == ["B", "U", "A"]
    assert [rf.details for rf in item.risk.risk_factors] == ["reason", "почему U", "reason"]
    # рекомендации — только по модифицируемым факторам: «Рекомендация U» отфильтрована,
    # причём и в per-system recommendations, и в topRecommendations (шаг 7).
    assert [r.title for r in item.risk.recommendations] == ["Рекомендация A"]
    assert response.top_recommendations is not None
    assert [r.title for r in response.top_recommendations] == ["Рекомендация A"]


@pytest.mark.asyncio
async def test_risk_factor_filtered_by_system_code_and_reasoning_in_details(
    db_session: AsyncSession, factory: Factory
) -> None:
    """#96: фактор отбирается по code И system_code; reasoning уходит в details.

    Один и тот же код есть только у фактора текущей системы (code UNIQUE). Фактор с тем же
    кодом, но привязанный к другой системе, в ответ не попадает.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    other_sys = "ENDO"
    rf_match = unique_id("rf")
    rf_other = unique_id("rfo")
    param_code = unique_id("p")
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now,
        # оба кода присутствуют в интерпретации CVD, но rf_other принадлежит системе ENDO.
        risk_factors_code=[rf_match, rf_other],
    )
    await factory.risk_factor(
        rf_match,
        system_code=sys_code,
        description="Повышенное АД",
        reasoning="АД выше нормы повышает нагрузку на сердце и сосуды.",
    )
    await factory.risk_factor(
        rf_other, system_code=other_sys, description="Избыточный вес", reasoning="не должен попасть в систему CVD"
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert item.risk.risk_factors is not None
    # rf_other отфильтрован по system_code, остаётся только фактор системы CVD.
    assert [rf.title for rf in item.risk.risk_factors] == ["Повышенное АД"]
    assert [rf.details for rf in item.risk.risk_factors] == ["АД выше нормы повышает нагрузку на сердце и сосуды."]


@pytest.mark.asyncio
async def test_risk_factor_without_reasoning_returned_with_null_details(
    db_session: AsyncSession, factory: Factory
) -> None:
    """#96 интерим (до досева reasoning): фактор с NULL reasoning всё равно отдаётся.

    reasoning ещё может быть NULL (бэкофилл не прошёл) — фактор не отбрасываем, иначе
    потеряли бы и его рекомендации. Отсутствующий reasoning → riskFactors[].details = null.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_ok = unique_id("rf")
    rf_no_reason = unique_id("rfnr")
    param_code = unique_id("p")
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now,
        risk_factors_code=[rf_ok, rf_no_reason],
    )
    await factory.risk_factor(rf_ok, system_code=sys_code, description="Полный", reasoning="ок")
    # system_code задан (NOT NULL), но reasoning=NULL (частичный бэкофилл) — фактор отдаётся, details=null.
    await factory.risk_factor(rf_no_reason, system_code=sys_code, description="Без ризонинга", reasoning=None)

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert item.risk.risk_factors is not None
    assert [rf.title for rf in item.risk.risk_factors] == ["Полный", "Без ризонинга"]
    assert [rf.details for rf in item.risk.risk_factors] == ["ок", None]


@pytest.mark.asyncio
async def test_low_risk_returns_only_common_group_and_null_factors(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "RESP"
    rf_code = unique_id("rf")
    doc_code = unique_doctor_code()
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    # FK от recommendations к risk_factors — нужно вставить even если фактор не активируется.
    await factory.risk_factor(rf_code, system_code=sys_code, reasoning="reason")
    disease_code = await factory.disease(unique_id("dis"), description="Апноэ сна", system_code=sys_code)

    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="low",
        text_value="Низкий риск",
        date_time=now,
        diseases=[disease_code],
        risk_factors_code=None,
        # вики: low → risk_factors_code = null
        doctors_code=[str(doc_code)],
    )
    await factory.doctor(code=doc_code, description="Пульмонолог")
    # risk_factor_group рекомендация — НЕ должна попасть, т.к. matched_codes пустой.
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="should-not-appear",
    )
    await factory.recommendation(
        recommendations_group="common_group", system_code=sys_code, name="Ежегодная флюорография"
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert item.risk.risk_level == "low"
    assert item.risk.risk_factors is None
    assert [r.title for r in item.risk.recommendations] == ["Ежегодная флюорография"]
    assert item.doctor_specializations is not None
    assert item.doctor_specializations[0].name == "Пульмонолог"
    assert item.disease_risks is not None
    assert [d.name for d in item.disease_risks] == ["Апноэ сна"]


@pytest.mark.asyncio
async def test_disease_code_outside_the_catalog_is_dropped(db_session: AsyncSession, factory: Factory) -> None:
    """Код, которого нет в справочнике, не доходит до ответа: в поле названия это был бы сам код."""
    pid = unique_id("p")
    sys_code = "URO"
    now = now_utc()

    await factory.patient(patient_id=pid)
    known = await factory.disease(unique_id("dis"), description="Почечная недостаточность", system_code=sys_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="Высокий риск",
        date_time=now,
        diseases=[known, unique_id("gone")],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.disease_risks is not None
    assert [d.name for d in item.disease_risks] == ["Почечная недостаточность"]


@pytest.mark.asyncio
async def test_medium_recommendations_union_of_both_groups(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "ENDO"
    rf_code = unique_id("rf")
    other_rf = unique_id("rfx")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="medium",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, description="Избыточный вес", reasoning="reason")
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Контроль уровня глюкозы",
    )
    # risk_factor_group по другому фактору — не должна попасть.
    await factory.risk_factor(other_rf, system_code=sys_code, description="other", reasoning="reason")
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=other_rf,
        system_code=sys_code,
        name="should-not-appear",
    )
    await factory.recommendation(recommendations_group="common_group", system_code=sys_code, name="Питание")

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    titles = sorted(r.title for r in item.risk.recommendations)
    assert titles == ["Контроль уровня глюкозы", "Питание"]


@pytest.mark.asyncio
async def test_common_params_count_but_common_not_in_response(db_session: AsyncSession, factory: Factory) -> None:
    """COMMON system feeds completion math but is excluded from the response systems list.

    With migrations 0058/0059 there is a real COMMON system + form_common instrument seeded
    by the catalog, so we only verify the structural property (COMMON filtered out, GI present).
    A precise completion_percentage assertion isn't deterministic against the real catalog.
    """
    pid = unique_id("p")
    sys_code = "GI"
    common_param = unique_id("cp")
    sys_param = unique_id("sp")
    common_instr = unique_id("ci")
    sys_instr = unique_id("si")
    common_q = unique_id("cq")
    sys_q = unique_id("sq")
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.parameter(code=common_param)
    await factory.parameter(code=sys_param)
    await factory.instrument(code=common_instr)
    await factory.instrument(code=sys_instr)
    await factory.link_parameter(instrument_code=common_instr, parameter_code=common_param)
    await factory.link_parameter(instrument_code=sys_instr, parameter_code=sys_param)
    await factory.link_system_instrument(system_code="COMMON", instrument_code=common_instr)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=sys_instr)
    await factory.question(code=common_q, group_code=1, is_skippable=True)
    await factory.question(code=sys_q, group_code=1, is_skippable=True)
    await factory.option(code=unique_id("co"), question_code=common_q, parameter_code=common_param, value=None)
    await factory.option(code=unique_id("so"), question_code=sys_q, parameter_code=sys_param, value=None)
    await factory.answer(
        patient_id=pid,
        parameter_code=common_param,
        value="yes",
        expiration_date=now + timedelta(days=30),
        source="test-seed",
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=None)

    codes = {s.system_code for s in response.system_interpretation_results}
    assert sys_code in codes
    assert "COMMON" not in codes


@pytest.mark.asyncio
async def test_completed_with_null_risk_level_returns_all_null(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "ENDO"
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level=None,
        text_value=None,
        date_time=now,
        diseases=["ignored-when-risk-null"],
        doctors_code=["999"],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "completed"
    assert item.interpretation_date_time is not None
    # Вики: risk_level=null → все три null, даже если в interpretations есть значения.
    assert item.risk is None
    assert item.doctor_specializations is None
    assert item.disease_risks is None


@pytest.mark.asyncio
async def test_completed_with_null_text_returns_doctors_and_diseases(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Bug #62: risk_level задан, text=NULL → doctors/diseases отдаются, risk с description=""."""
    pid = unique_id("p")
    sys_code = "CVD"
    doc_code = unique_doctor_code()
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.doctor(code=doc_code, description="Кардиолог")
    disease_code = await factory.disease(
        unique_id("dis"), description="Инфаркт и ишемический инсульт", system_code=sys_code
    )
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value=None,
        date_time=now,
        diseases=[disease_code],
        doctors_code=[str(doc_code)],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "completed"
    assert item.interpretation_date_time is not None
    assert item.disease_risks is not None
    assert [d.name for d in item.disease_risks] == ["Инфаркт и ишемический инсульт"]
    assert item.doctor_specializations is not None
    assert item.doctor_specializations[0].name == "Кардиолог"
    assert item.doctor_specializations[0].code == doc_code
    # risk_level задан → risk-объект собираем всегда; при text=NULL description="".
    assert item.risk is not None
    assert item.risk.risk_level == "high"
    assert item.risk.description == ""


@pytest.mark.asyncio
async def test_null_text_with_risk_factors_yields_top_recommendations(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Bug #62 follow-up: text=NULL с risk_factors_code → recommendations попадают в top."""
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.risk_factor(
        rf_code, system_code=sys_code, description="Курение", param_value="yes", reasoning="reason"
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Отказ от курения",
        text_value="...",
    )
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value=None,
        date_time=now,
        risk_factors_code=[rf_code],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    # risk-объект собирается даже без text (description=""); top_recommendations тоже наполняется.
    assert item.risk is not None
    assert item.risk.description == ""
    assert response.top_recommendations is not None
    assert [r.title for r in response.top_recommendations] == ["Отказ от курения"]


@pytest.mark.asyncio
async def test_last_calculation_dt_from_results(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    sys_code = "CVD"
    instr_code = unique_id("i")
    param_code = unique_id("p")
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.instrument(code=instr_code)
    await factory.link_parameter(instrument_code=instr_code, parameter_code=param_code)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr_code)
    earlier = now - timedelta(hours=2)
    latest = now - timedelta(minutes=10)
    await factory.result(
        patient_id=pid,
        instrument_code=instr_code,
        value="1.0",
        date_time=earlier,
        expiration_date=now + timedelta(days=30),
    )

    # Второй инструмент с NULL value (более позднее время) — игнорируется фильтром value IS NOT NULL.
    instr_null = unique_id("inull")
    await factory.instrument(code=instr_null)
    await factory.link_parameter(instrument_code=instr_null, parameter_code=param_code)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr_null)
    await factory.result(
        patient_id=pid, instrument_code=instr_null, value=None, date_time=now, expiration_date=now + timedelta(days=30)
    )

    # Третий инструмент с самым поздним валидным результатом — ожидаем именно его в last_calculation_dt.
    instr2 = unique_id("i2")
    await factory.instrument(code=instr2)
    await factory.link_parameter(instrument_code=instr2, parameter_code=param_code)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr2)
    await factory.result(
        patient_id=pid, instrument_code=instr2, value="2.0", date_time=latest, expiration_date=now + timedelta(days=30)
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert response.last_calculation_date_time is not None
    assert abs((response.last_calculation_date_time - latest).total_seconds()) < 1


@pytest.mark.asyncio
async def test_top_recommendations_dedup_and_limit(db_session: AsyncSession, factory: Factory) -> None:
    pid = unique_id("p")
    now = now_utc()
    param_code = unique_id("p")

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)

    # 6 каталожных систем (уже созданы миграцией), rang по возрастанию.
    # "X" в трёх системах с наименьшим rang → будет первым после сортировки по rang.
    rec_names = ["X", "X", "X", "Y", "Z", "W"]
    catalog_systems = ["CVD", "ONCO", "ENDO", "RESP", "NEURO", "REPROD"]
    for scode, name in zip(catalog_systems, rec_names, strict=True):
        # code уникален → у каждого фактора ровно одна система; на это и опирается отбор по system_code.
        rf_code = unique_id("rf")
        await factory.risk_factor(rf_code, system_code=scode, reasoning="reason")
        await factory.interpretation(
            patient_id=pid,
            system_code=scode,
            risk_level="medium",
            text_value="x",
            date_time=now,
            risk_factors_code=[rf_code],
        )
        await factory.recommendation(
            recommendations_group="risk_factor_group", risk_factors_code=rf_code, system_code=scode, name=name
        )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=None)

    assert response.top_recommendations is not None
    titles = [r.title for r in response.top_recommendations]
    assert len(titles) == 4  # X, Y, Z, W → дедуп по имени
    assert titles[0] == "X"
    assert set(titles) == {"X", "Y", "Z", "W"}


@pytest.mark.asyncio
async def test_top_recommendations_prefers_risk_factor_over_common(db_session: AsyncSession, factory: Factory) -> None:
    """У high-системы есть и risk_factor_group, и common_group рекомендации.

    risk_factor_group идёт первым в topRecommendations, common_group добивает хвост до 5
    (шаг 7.2) — но НЕ выше risk_factor-выдачи.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, description="Курение", reasoning="reason")
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Отказ от курения",
    )
    await factory.recommendation(
        recommendations_group="common_group", system_code=sys_code, name="Регулярная физическая активность"
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    # В risk.recommendations конкретной системы — обе группы.
    assert sorted(r.title for r in item.risk.recommendations) == [
        "Отказ от курения",
        "Регулярная физическая активность",
    ]
    # В topRecommendations — risk_factor_group первым, common_group добивает хвост.
    assert response.top_recommendations is not None
    assert [r.title for r in response.top_recommendations] == [
        "Отказ от курения",
        "Регулярная физическая активность",
    ]


@pytest.mark.asyncio
async def test_top_recommendations_partial_rf_group_coverage_supplemented_by_common(
    db_session: AsyncSession,
    factory: Factory,
) -> None:
    """Две high-системы, risk_factor_group рекомендацию даёт только одна.

    risk_factor-рекомендация CVD идёт первой, а common_group второй системы (ONCO) добивает
    хвост до лимита (шаг 7.2): топ = [rf CVD, common ONCO].
    """
    pid = unique_id("p")
    rf_cvd = unique_id("rf")
    rf_onco = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)

    # CVD (rang меньше) — даёт risk_factor_group рекомендацию.
    await factory.interpretation(
        patient_id=pid, system_code="CVD", risk_level="high", text_value="x", date_time=now, risk_factors_code=[rf_cvd]
    )
    await factory.risk_factor(rf_cvd, system_code="CVD", reasoning="reason")
    await factory.recommendation(
        recommendations_group="risk_factor_group", risk_factors_code=rf_cvd, system_code="CVD", name="Отказ от курения"
    )

    # ONCO — high, есть фактор, но НЕТ risk_factor_group рекомендации; только common_group.
    # Он не должен подмешаться в топ, пока rf-пул CVD непуст.
    await factory.interpretation(
        patient_id=pid,
        system_code="ONCO",
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_onco],
    )
    await factory.risk_factor(rf_onco, system_code="ONCO", reasoning="reason")
    await factory.recommendation(
        recommendations_group="common_group", system_code="ONCO", name="Регулярная диспансеризация"
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=None)

    assert response.top_recommendations is not None
    assert [r.title for r in response.top_recommendations] == [
        "Отказ от курения",
        "Регулярная диспансеризация",
    ]


@pytest.mark.asyncio
async def test_fully_answered_patient_returns_100_cq030_not_relevant_to_real_systems(
    db_session: AsyncSession,
    factory: Factory,
) -> None:
    """Полностью отвеченный пациент → 100% и per-system, и глобально; cq_030 не тянет % вниз.

    ВНИМАНИЕ (что этот тест НЕ проверяет): воркэраунд cq_030 (is_pregnant IS NOT NULL → вопрос
    считается пройденным) здесь не участвует. По новой релевантности вариант→инструмент→система
    вопрос cq_030 привязан только к COMMON (его единственный параметр is_pregnant входит лишь в
    инструмент form_common, а тот — только в систему COMMON), а COMMON исключён из систем ответа
    medical-risk. Значит cq_030 не попадает ни в один знаменатель, и 100% вышло бы при любом
    is_pregnant (в т.ч. без воркэраунда). Сам воркэраунд закреплён юнитами
    (test_completion.py::test_cq030_progressed_when_is_pregnant_not_null); на medical-risk он
    вообще не наблюдаем — живёт только в questions/answers, когда расчётная система COMMON.

    Ценность теста: реальный каталог, полностью отвеченный пациент — ни один вопрос не остаётся
    applicable-но-непройденным, поэтому и система (CVD), и глобальный процент = 100.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    # is_pregnant=False — пациент ответил «нет» на cq_030 (флаг хранится в patients, не в parameters).
    await factory.patient(patient_id=pid, is_pregnant=False)
    await factory.answer_all_real_question_params(patient_id=pid, exclude={"is_pregnant"})
    await db_session.commit()

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert response.completion_percentage == 100
    item = response.system_interpretation_results[0]
    assert item.system_code == sys_code
    assert item.system_completion_percentage == 100


# --- шаг 4: applicable/progressed по вопросам (пол/возраст → знаменатель, прочие except → числитель) ---
# Переиспользуем реальную систему CVD (systems.rang UNIQUE занят реальными 0–13, а systemPriority в
# ответе ≤13, поэтому synthetic-система невозможна) + clear_system_instruments для изоляции: считаем
# только по вопросам теста. Вопрос относится к системе через свой вариант (options.parameter_code →
# instruments_parameters → systems_instruments).


async def _wire_system_question(
    db_session: AsyncSession,
    factory: Factory,
    *,
    system_code: str,
    instrument_code: str,
    question_code: str,
    param_code: str,
) -> None:
    """Заводит вопрос с одним вариантом, чей параметр относится к инструменту системы."""
    await factory.parameter(code=param_code)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=param_code)
    await factory.question(code=question_code, group_code=1, is_skippable=True)
    await factory.option(code=unique_id("o"), question_code=question_code, parameter_code=param_code, value=None)


@pytest.mark.asyncio
async def test_gender_condition_filters_denominator(db_session: AsyncSession, factory: Factory) -> None:
    """except gender=<пол пациента> исключает вопрос из applicable (знаменателя), а не зачитывает
    его в числитель: незакрытый gender-исключённый вопрос не тянет процент вниз."""
    pid = unique_id("p")
    sys_code = "CVD"
    instr = unique_id("i")
    exp = now_utc() + timedelta(days=30)

    await factory.patient(patient_id=pid)
    await factory.unlink_system_instruments(system_code=sys_code)
    await factory.instrument(code=instr)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr)
    await factory.answer(
        patient_id=pid, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_MALE, expiration_date=exp, source="test-seed"
    )

    # Отвеченный вопрос — единственный applicable.
    p_answered = unique_id("pa")
    await _wire_system_question(
        db_session,
        factory,
        system_code=sys_code,
        instrument_code=instr,
        question_code=unique_id("qa"),
        param_code=p_answered,
    )
    await factory.answer(patient_id=pid, parameter_code=p_answered, value="Да", expiration_date=exp, source="test-seed")

    # Незакрытый вопрос, исключённый по полу — не должен попасть в знаменатель.
    q_gender = unique_id("qg")
    p_gender_q = unique_id("pg")
    await _wire_system_question(
        db_session, factory, system_code=sys_code, instrument_code=instr, question_code=q_gender, param_code=p_gender_q
    )
    await factory.condition(
        type="except", question_code=q_gender, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_MALE
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    # applicable={qa}, progressed={qa} → 100. Если бы gender не фильтровал — было бы 1/2=50.
    assert response.system_interpretation_results[0].system_completion_percentage == 100
    assert response.completion_percentage == 100


@pytest.mark.asyncio
async def test_age_condition_filters_denominator(db_session: AsyncSession, factory: Factory) -> None:
    """type='age' вне диапазона исключает вопрос из applicable (знаменателя)."""
    pid = unique_id("p")
    sys_code = "CVD"
    instr = unique_id("i")
    exp = now_utc() + timedelta(days=30)

    await factory.patient(patient_id=pid)
    await factory.unlink_system_instruments(system_code=sys_code)
    await factory.instrument(code=instr)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr)
    await factory.answer(
        patient_id=pid,
        parameter_code=PARAMETER_CODE_BIRTHDATE,
        value="1990-01-01",
        expiration_date=exp,
        source="test-seed",
    )

    p_answered = unique_id("pa")
    await _wire_system_question(
        db_session,
        factory,
        system_code=sys_code,
        instrument_code=instr,
        question_code=unique_id("qa"),
        param_code=p_answered,
    )
    await factory.answer(patient_id=pid, parameter_code=p_answered, value="Да", expiration_date=exp, source="test-seed")

    # Незакрытый вопрос с недостижимым возрастным диапазоном → исключён из знаменателя.
    q_age = unique_id("qage")
    p_age_q = unique_id("page")
    await _wire_system_question(
        db_session, factory, system_code=sys_code, instrument_code=instr, question_code=q_age, param_code=p_age_q
    )
    await factory.condition(
        type="age", question_code=q_age, parameter_code=PARAMETER_CODE_BIRTHDATE, min_age=200, value=""
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert response.system_interpretation_results[0].system_completion_percentage == 100


@pytest.mark.asyncio
async def test_non_gender_except_auto_credits_numerator(db_session: AsyncSession, factory: Factory) -> None:
    """except с parameter_code != gender, срабатывающий у пациента, скрывает вопрос показа →
    незакрытый вопрос зачитывается в progressed (числитель)."""
    pid = unique_id("p")
    sys_code = "CVD"
    instr = unique_id("i")
    exp = now_utc() + timedelta(days=30)

    await factory.patient(patient_id=pid)
    await factory.unlink_system_instruments(system_code=sys_code)
    await factory.instrument(code=instr)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr)

    # Управляющий параметр show-условия — у пациента значение совпадает с conditions.value → скрыт.
    control = unique_id("ctrl")
    await factory.parameter(code=control)
    await factory.answer(patient_id=pid, parameter_code=control, value="Нет", expiration_date=exp, source="test-seed")

    q_hidden = unique_id("qh")
    p_hidden = unique_id("ph")
    await _wire_system_question(
        db_session, factory, system_code=sys_code, instrument_code=instr, question_code=q_hidden, param_code=p_hidden
    )
    # p_hidden НЕ отвечен, но вопрос скрыт условием → progressed.
    await factory.condition(type="except", question_code=q_hidden, parameter_code=control, value="Нет")

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    # applicable={qh}, progressed={qh} (авто-зачёт) → 100.
    assert response.system_interpretation_results[0].system_completion_percentage == 100


@pytest.mark.asyncio
async def test_partial_completion_floors_progressed_over_applicable(db_session: AsyncSession, factory: Factory) -> None:
    """Два применимых вопроса, один отвечён → floor(1/2×100)=50."""
    pid = unique_id("p")
    sys_code = "CVD"
    instr = unique_id("i")
    exp = now_utc() + timedelta(days=30)

    await factory.patient(patient_id=pid)
    await factory.unlink_system_instruments(system_code=sys_code)
    await factory.instrument(code=instr)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr)

    p_answered = unique_id("pa")
    await _wire_system_question(
        db_session,
        factory,
        system_code=sys_code,
        instrument_code=instr,
        question_code=unique_id("qa"),
        param_code=p_answered,
    )
    await factory.answer(patient_id=pid, parameter_code=p_answered, value="Да", expiration_date=exp, source="test-seed")

    p_open = unique_id("po")
    await _wire_system_question(
        db_session,
        factory,
        system_code=sys_code,
        instrument_code=instr,
        question_code=unique_id("qo"),
        param_code=p_open,
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    assert response.system_interpretation_results[0].system_completion_percentage == 50
    assert response.completion_percentage == 50


# --- risk.recommendations: дедупликация по name (title) ---
# Переиспользуем реальную систему CVD (systems.rang UNIQUE и ≤13 в схеме, свободного rang нет)
# + clear_catalog_recommendations для чистой выборки — тот же приём, что в тесте обеих групп выше.


@pytest.mark.asyncio
async def test_recommendations_ordered_risk_factor_group_before_common(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Happy path: при разных name дедупликация ничего не удаляет, порядок — risk_factor_group → common_group.

    common_group вставляется ПЕРВОЙ — доказываем, что порядок задаёт группа, а не порядок вставки/БД.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, reasoning="reason")
    await factory.recommendation(recommendations_group="common_group", system_code=sys_code, name="Общая рекомендация")
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Рекомендация по фактору",
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert [r.title for r in item.risk.recommendations] == [
        "Рекомендация по фактору",
        "Общая рекомендация",
    ]


@pytest.mark.asyncio
async def test_recommendations_dedup_same_name_across_risk_factors(db_session: AsyncSession, factory: Factory) -> None:
    """Крит. 1: несколько risk_factor_code с одинаковым name → одна запись (кейс CVD: 4 кода → одна рек.)."""
    pid = unique_id("p")
    sys_code = "CVD"
    rf1 = unique_id("rf")
    rf2 = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf1, rf2],
    )
    await factory.risk_factor(rf1, system_code=sys_code, reasoning="reason")
    await factory.risk_factor(rf2, system_code=sys_code, reasoning="reason")
    for rf in (rf1, rf2):
        await factory.recommendation(
            recommendations_group="risk_factor_group",
            risk_factors_code=rf,
            system_code=sys_code,
            name="Контроль артериального давления",
            text_value="Следите за давлением",
        )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert [r.title for r in item.risk.recommendations] == ["Контроль артериального давления"]


@pytest.mark.asyncio
async def test_recommendations_dedup_prefers_risk_factor_group_over_common(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Крит. 2: совпадение name между risk_factor_group и common_group → побеждает risk_factor_group.

    У групп разный text — проверяем не только схлопывание, но и КАКАЯ запись осталась (details).
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, reasoning="reason")
    await factory.recommendation(
        recommendations_group="common_group",
        system_code=sys_code,
        name="Здоровый образ жизни",
        text_value="общий текст",
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Здоровый образ жизни",
        text_value="текст фактора",
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    recs = item.risk.recommendations
    assert [r.title for r in recs] == ["Здоровый образ жизни"]
    assert recs[0].details == "текст фактора"


@pytest.mark.asyncio
async def test_recommendations_dedup_identical_duplicate_rows(db_session: AsyncSession, factory: Factory) -> None:
    """Крит. 3: дублирующиеся строки для одной пары (risk_factor_code, system_code) → одна запись.

    В таблице recommendations нет уникального ключа на (risk_factors_code, system_code) — дубли возможны.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, reasoning="reason")
    for _ in range(2):
        await factory.recommendation(
            recommendations_group="risk_factor_group",
            risk_factors_code=rf_code,
            system_code=sys_code,
            name="Бережное отношение к суставам",
            text_value="текст",
        )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert [r.title for r in item.risk.recommendations] == ["Бережное отношение к суставам"]


@pytest.mark.asyncio
async def test_recommendations_dedup_within_common_group(db_session: AsyncSession, factory: Factory) -> None:
    """Sad path: дубли name внутри common_group (без сопоставленных факторов) тоже схлопываются."""
    pid = unique_id("p")
    sys_code = "CVD"
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.interpretation(
        patient_id=pid, system_code=sys_code, risk_level="high", text_value="x", date_time=now, risk_factors_code=None
    )
    for _ in range(2):
        await factory.recommendation(
            recommendations_group="common_group",
            system_code=sys_code,
            name="Диспансеризация раз в год",
            text_value="текст",
        )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    assert [r.title for r in item.risk.recommendations] == ["Диспансеризация раз в год"]


@pytest.mark.asyncio
async def test_recommendations_dedup_keeps_earliest_inserted_on_name_clash(
    db_session: AsyncSession, factory: Factory
) -> None:
    """При одинаковом name внутри группы остаётся первое вхождение — самая ранняя строка.

    Строки одноимённые, но с разным text; выбор детерминирован за счёт сортировки по
    recommendation_id в HttpCatalog.recommendations_by_system.
    """
    pid = unique_id("p")
    sys_code = "CVD"
    rf_code = unique_id("rf")
    param_code = unique_id("p")
    now = now_utc()

    await factory.clear_recommendations()
    await factory.patient(patient_id=pid)
    await factory.parameter(code=param_code)
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        risk_factors_code=[rf_code],
    )
    await factory.risk_factor(rf_code, system_code=sys_code, reasoning="reason")
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Контроль давления",
        text_value="ранний текст",
    )
    await factory.recommendation(
        recommendations_group="risk_factor_group",
        risk_factors_code=rf_code,
        system_code=sys_code,
        name="Контроль давления",
        text_value="поздний текст",
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.risk is not None
    recs = item.risk.recommendations
    assert [r.title for r in recs] == ["Контроль давления"]
    assert recs[0].details == "ранний текст"


@pytest.mark.asyncio
async def test_doctor_specializations_dedup_duplicate_codes(db_session: AsyncSession, factory: Factory) -> None:
    """Повторяющиеся doctors_code в интерпретации схлопываются в одну специализацию (keep-first)."""
    pid = unique_id("p")
    sys_code = "CVD"
    doc_code = unique_doctor_code()
    now = now_utc()

    await factory.patient(patient_id=pid)
    await factory.doctor(code=doc_code, description="Кардиолог")
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        risk_level="high",
        text_value="x",
        date_time=now,
        doctors_code=[str(doc_code), str(doc_code)],
    )

    service = await _make_service(db_session)
    response = await service.get_medical_risk(client_id=pid, system_code=sys_code)

    item = response.system_interpretation_results[0]
    assert item.doctor_specializations is not None
    assert [d.code for d in item.doctor_specializations] == [doc_code]
