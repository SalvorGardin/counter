"""Испорченные значения в `patients_parameters` при сохранении антропометрии.

`_read_float` и `_read_date` глотают `ValueError` и возвращают None. Последствие — не исключение,
а неверное решение о пересчёте: «предыдущего роста нет» отменяет пересчёт ИМТ, «предыдущей
birthDate нет» наоборот заставляет переписать актуальный возраст. Поэтому тесты проверяют не
возврат хелпера, а получившееся поведение антропометрии.
"""

from datetime import date, timedelta
from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_init.schemas import AnthropometryRequest
from src.models.patient_parameter import PatientParameter
from src.models.patient_parameter_history import PatientParameterHistory
from src.services.risk_init.domain.constants import (
    AGE_PARAMETER_CODE,
    BIRTHDATE_PARAMETER_CODE,
    BMI_PARAMETER_CODE,
    HEIGHT_PARAMETER_CODE,
    WEIGHT_PARAMETER_CODE,
)
from src.services.risk_init.service import RiskInitService
from tests.conftest import LogSink, make_http_catalog
from tests.factories import Factory, now_utc


async def _make_service(session: AsyncSession) -> RiskInitService:
    await session.commit()
    return RiskInitService(session, await make_http_catalog(session))


async def _value_of(session: AsyncSession, patient_id: str, code: str) -> str | None:
    row = await session.scalar(
        select(PatientParameter).where(
            PatientParameter.patient_id == patient_id,
            PatientParameter.parameter_code == code,
        )
    )
    return None if row is None else row.value


async def _history_values(session: AsyncSession, patient_id: str, code: str) -> list[str | None]:
    rows = await session.scalars(
        select(PatientParameterHistory).where(
            PatientParameterHistory.patient_id == patient_id,
            PatientParameterHistory.parameter_code == code,
        )
    )
    return [row.value for row in rows.all()]


@pytest.mark.asyncio
async def test_non_numeric_height_suppresses_bmi_recompute(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Нечисловой рост читается как «роста нет» — ИМТ не пересчитывается вообще.

    Вес в запросе изменился — при исправном росте это гарантированный пересчёт ИМТ. Здесь же
    ИМТ остаётся прежним, и единственный внешний признак расхождения — warning.
    """
    client_id = f"c_{uuid4().hex[:8]}"
    await factory.patient(patient_id=client_id)
    actual = now_utc() + timedelta(days=30)
    await factory.answer(
        patient_id=client_id, parameter_code=HEIGHT_PARAMETER_CODE, value="abc", expiration_date=actual
    )
    await factory.answer(patient_id=client_id, parameter_code=WEIGHT_PARAMETER_CODE, value="70", expiration_date=actual)
    await factory.answer(patient_id=client_id, parameter_code=BMI_PARAMETER_CODE, value="22.86", expiration_date=actual)
    service = await _make_service(db_session)

    changed = await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=80))

    assert BMI_PARAMETER_CODE not in changed
    assert await _value_of(db_session, client_id, BMI_PARAMETER_CODE) == "22.86"
    assert await _history_values(db_session, client_id, BMI_PARAMETER_CODE) == []
    assert "patient_parameter value is not numeric" in captured_app_logs.messages()
    assert captured_app_logs.context_of("patient_parameter value is not numeric")["parameter_code"] == (
        HEIGHT_PARAMETER_CODE
    )


@pytest.mark.asyncio
async def test_non_iso_birthdate_forces_age_rewrite(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Не-ISO birthDate читается как «прежней даты нет» — возраст переписывается, хоть и актуален.

    Повторная присылка той же даты рождения обязана оставить актуальный возраст нетронутым;
    испорченное хранимое значение ломает это сравнение, и строка возраста уходит в history.
    """
    client_id = f"c_{uuid4().hex[:8]}"
    await factory.patient(patient_id=client_id)
    actual = now_utc() + timedelta(days=30)
    await factory.answer(
        patient_id=client_id, parameter_code=BIRTHDATE_PARAMETER_CODE, value="15-03-1990", expiration_date=actual
    )
    await factory.answer(patient_id=client_id, parameter_code=AGE_PARAMETER_CODE, value="36", expiration_date=actual)
    service = await _make_service(db_session)

    changed = await service.save_anthropometry(
        client_id=client_id, body=AnthropometryRequest(birth_date=date(1990, 3, 15))
    )

    assert AGE_PARAMETER_CODE in changed
    assert await _history_values(db_session, client_id, AGE_PARAMETER_CODE) == ["36"]
    assert "patient_parameter value is not iso date" in captured_app_logs.messages()
    assert captured_app_logs.context_of("patient_parameter value is not iso date")["parameter_code"] == (
        BIRTHDATE_PARAMETER_CODE
    )
