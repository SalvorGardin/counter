"""Тест RiskInitRepository.has_actual_patient_parameter.

Задача (#48) просила «один юнит на repo», но репозиторий — это тонкая обёртка над SQLAlchemy-сессией,
а конвенция проекта (.claude/rules/testing.md) запрещает мокать БД, которую можно поднять локально.
Поэтому это db-маркированный тест против реальной БД, а не изолированный unit с моком сессии.
"""

from datetime import timedelta

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.services.risk_init.domain.constants import BMI_PARAMETER_CODE, HEIGHT_PARAMETER_CODE
from src.services.risk_init.infra.repository import RiskInitRepository
from tests.conftest import make_http_catalog
from tests.factories import Factory, now_utc, unique_id


class TestHasActualPatientParameter:
    async def test_returns_true_when_parameter_is_actual(self, db_session: AsyncSession, factory: Factory) -> None:
        client_id = unique_id("c")
        await factory.patient(patient_id=client_id)
        await factory.answer(
            patient_id=client_id,
            parameter_code=BMI_PARAMETER_CODE,
            value="22.5",
            expiration_date=now_utc() + timedelta(days=30),
            source="test-seed",
        )

        repo = RiskInitRepository(db_session)

        assert await repo.has_actual_patient_parameter(client_id, BMI_PARAMETER_CODE) is True

    async def test_returns_false_when_parameter_absent(self, db_session: AsyncSession, factory: Factory) -> None:
        client_id = unique_id("c")
        await factory.patient(patient_id=client_id)

        repo = RiskInitRepository(db_session)

        # параметр для пациента не записан → актуальной записи нет
        assert await repo.has_actual_patient_parameter(client_id, HEIGHT_PARAMETER_CODE) is False

    async def test_returns_false_when_parameter_soft_invalidated(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        # Строка есть, но expiration_date в прошлом (состояние после risk-event answers-reset):
        # для калькуляторов такой параметр не актуален → должен считаться отсутствующим.
        client_id = unique_id("c")
        await factory.patient(patient_id=client_id)
        await factory.answer(
            patient_id=client_id,
            parameter_code=BMI_PARAMETER_CODE,
            value="22.5",
            expiration_date=now_utc() - timedelta(days=1),
            source="test-seed",
        )

        repo = RiskInitRepository(db_session)

        assert await repo.has_actual_patient_parameter(client_id, BMI_PARAMETER_CODE) is False


class TestParametersValidity:
    """Источник срока годности параметра (#160). Раньше его читал `RiskInitRepository`
    собственным SELECT'ом, теперь — `HttpCatalog.parameters`; контракт не изменился:
    validity_period берётся из справочника `parameters`, а отсутствующий в справочнике код даёт
    None, что `RiskInitService._upsert` трактует как «нет срока» (design D4)."""

    async def test_returns_validity_for_known_code(self, db_session: AsyncSession) -> None:
        # height засеян миграциями — каталог обязан отдать ровно то значение, что лежит в parameters.
        expected = (
            await db_session.execute(
                text("SELECT validity_period FROM parameters WHERE code = :c"), {"c": HEIGHT_PARAMETER_CODE}
            )
        ).scalar_one()

        catalog = await make_http_catalog(db_session)

        assert catalog.parameters[HEIGHT_PARAMETER_CODE].validity_period == expected

    async def test_absent_code_is_missing_from_the_index(self, db_session: AsyncSession) -> None:
        catalog = await make_http_catalog(db_session)

        assert catalog.parameters.get("__no_such_parameter__") is None
