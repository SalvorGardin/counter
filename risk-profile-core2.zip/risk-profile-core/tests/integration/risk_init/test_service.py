"""End-to-end integration-тесты RiskInitService.

Срок жизни параметров сервис берёт из БД `parameters.validity_period` (после #160/#21 — единый
источник для risk-init, risk-communication, risk-event; in-memory таблица validity.py удалена).
Шесть кодов антропометрии уже засеяны миграциями, а `insert_parameter` идёт через
`ON CONFLICT (code) DO NOTHING` — то есть его дефолтные 30 дней НЕ перезаписывают засеянные
значения, и сервис читает именно миграционные (напр. height — 10 лет). Поэтому тесты, где
важен конкретный срок, сверяются с фактическим `validity_period` из БД, а не с литералом.
"""

from datetime import UTC, date, datetime, timedelta
from types import SimpleNamespace
from uuid import uuid4

import pytest
from sqlalchemy import func, select, text, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_init.schemas import AnthropometryRequest
from src.models.patient import Patient
from src.models.patient_parameter import PatientParameter
from src.models.patient_parameter_history import PatientParameterHistory
from src.services.risk_communication.domain.expiration import compute_expiration
from src.services.risk_init.domain.age import compute_age
from src.services.risk_init.domain.constants import (
    AGE_PARAMETER_CODE,
    ANSWER_SOURCE_EMR,
    BIRTHDATE_PARAMETER_CODE,
    BMI_PARAMETER_CODE,
    GENDER_PARAMETER_CODE,
    HEIGHT_PARAMETER_CODE,
    WEIGHT_PARAMETER_CODE,
)
from src.services.risk_init.domain.exceptions import GenderAndBirthDateRequiredError
from src.services.risk_init.service import RiskInitService
from tests.conftest import make_http_catalog
from tests.consts import GENDER_FEMALE, GENDER_MALE
from tests.factories import Factory, now_utc


async def _close_seed_transaction(session: AsyncSession) -> None:
    """Закрывает savepoint от сидов теста.

    Антропометрические параметры (height/weight/birthdate/gender/bmi/age) заведены сидами
    миграций, поэтому сеять их не нужно. Коммит нужен сам по себе: `service.save_anthropometry`
    начинает собственную транзакцию и без него упала бы на «transaction already begun».
    """
    await session.commit()


async def _seed_existing_patient(session: AsyncSession, factory: Factory, patient_id: str) -> None:
    await factory.patient(patient_id=patient_id)
    await session.commit()


def _new_client_id() -> str:
    return f"c_{uuid4().hex[:8]}"


async def _get_parameter(session: AsyncSession, patient_id: str, code: str) -> PatientParameter | None:
    return await session.scalar(
        select(PatientParameter).where(
            PatientParameter.patient_id == patient_id,
            PatientParameter.parameter_code == code,
        )
    )


async def _get_history(session: AsyncSession, patient_id: str, code: str) -> list[PatientParameterHistory]:
    rows = await session.scalars(
        select(PatientParameterHistory).where(
            PatientParameterHistory.patient_id == patient_id,
            PatientParameterHistory.parameter_code == code,
        )
    )
    return list(rows.all())


async def _soft_invalidate(session: AsyncSession, patient_id: str, *codes: str) -> None:
    """Имитирует soft-invalidate из risk-event answers-reset: строки остаются, expiration_date в прошлом."""
    await session.execute(
        update(PatientParameter)
        .where(
            PatientParameter.patient_id == patient_id,
            PatientParameter.parameter_code.in_(codes),
        )
        .values(expiration_date=func.now() - timedelta(days=1))
    )
    await session.commit()


async def _make_service(session: AsyncSession) -> RiskInitService:
    await session.commit()
    return RiskInitService(session, await make_http_catalog(session))


class TestNewClient:
    async def test_creates_patient_and_parameters(self, db_session: AsyncSession) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(height_cm=175, weight_kg=72, birth_date=date(1990, 3, 15), gender="male"),
        )

        patient = await db_session.scalar(select(Patient).where(Patient.patient_id == client_id))
        assert patient is not None
        # gender=male в этом запросе сбрасывает is_pregnant в False (Risk-init, шаг 4).
        assert patient.is_pregnant is False

        expected_age = str(compute_age(date(1990, 3, 15), now_utc().date()))
        for code, expected in {
            HEIGHT_PARAMETER_CODE: "175",
            WEIGHT_PARAMETER_CODE: "72",
            BIRTHDATE_PARAMETER_CODE: "1990-03-15",
            GENDER_PARAMETER_CODE: GENDER_MALE,
            BMI_PARAMETER_CODE: "23.51",
            AGE_PARAMETER_CODE: expected_age,
        }.items():
            row = await _get_parameter(db_session, client_id, code)
            assert row is not None, code
            assert row.value == expected
            assert row.source == ANSWER_SOURCE_EMR
            assert row.date_time is not None, code

    async def test_female_is_persisted_as_russian_literal(self, db_session: AsyncSession) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="female"),
        )

        row = await _get_parameter(db_session, client_id, GENDER_PARAMETER_CODE)
        assert row is not None
        assert row.value == GENDER_FEMALE

    async def test_missing_birth_date_for_new_client_raises(self, db_session: AsyncSession) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        service = await _make_service(db_session)

        with pytest.raises(GenderAndBirthDateRequiredError):
            await service.save_anthropometry(
                client_id=client_id,
                body=AnthropometryRequest(height_cm=175, gender="male"),
            )

    async def test_missing_gender_for_new_client_raises(self, db_session: AsyncSession) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        service = await _make_service(db_session)

        with pytest.raises(GenderAndBirthDateRequiredError):
            await service.save_anthropometry(
                client_id=client_id,
                body=AnthropometryRequest(height_cm=175, birth_date=date(1990, 3, 15)),
            )

    async def test_male_sets_is_pregnant_false_for_new_patient(self, db_session: AsyncSession) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="male"),
        )

        patient = await db_session.scalar(select(Patient).where(Patient.patient_id == client_id))
        assert patient is not None
        assert patient.is_pregnant is False

    async def test_male_gender_only_request_sets_false(self, db_session: AsyncSession, factory: Factory) -> None:
        # Запрос только с gender для существующего пациента: хотя бы одно поле передано,
        # is_pregnant выставляется в False.
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)  # сидится с is_pregnant=False по умолчанию
        service = await _make_service(db_session)

        changed = await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(gender="male"),
        )

        patient = await db_session.scalar(select(Patient).where(Patient.patient_id == client_id))
        assert patient is not None
        assert patient.is_pregnant is False
        # is_pregnant не параметр — пересчёт планируется по самому gender.
        assert GENDER_PARAMETER_CODE in changed

    async def test_male_overrides_previous_pregnant_true(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await factory.patient(patient_id=client_id, is_pregnant=True)
        await db_session.commit()
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(gender="male"),
        )

        patient = await db_session.scalar(select(Patient).where(Patient.patient_id == client_id))
        assert patient is not None
        assert patient.is_pregnant is False

    async def test_female_does_not_touch_is_pregnant(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await factory.patient(patient_id=client_id, is_pregnant=None)
        await db_session.commit()
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="female"),
        )

        patient = await db_session.scalar(select(Patient).where(Patient.patient_id == client_id))
        assert patient is not None
        assert patient.is_pregnant is None


class TestExistingClient:
    async def test_partial_update_writes_only_provided_fields(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=70))

        assert (await _get_parameter(db_session, client_id, WEIGHT_PARAMETER_CODE)) is not None
        assert (await _get_parameter(db_session, client_id, HEIGHT_PARAMETER_CODE)) is None
        # ИМТ не считается, пока нет роста.
        assert (await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)) is None

    async def test_existing_parameter_is_archived_on_overwrite(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=70))
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=72))

        current = await _get_parameter(db_session, client_id, WEIGHT_PARAMETER_CODE)
        assert current is not None and current.value == "72"
        history = await _get_history(db_session, client_id, WEIGHT_PARAMETER_CODE)
        assert len(history) == 1
        assert history[0].value == "70"
        # Архивная запись сохранила свой date_time; актуальная строка получила более поздний (>=) момент записи.
        assert history[0].date_time is not None
        assert current.date_time >= history[0].date_time

    async def test_new_client_does_not_need_birth_date_when_patient_exists(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=70))

    async def test_gender_update_overwrites_with_russian_literal(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id, body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="male")
        )
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(gender="female"))

        current = await _get_parameter(db_session, client_id, GENDER_PARAMETER_CODE)
        assert current is not None and current.value == GENDER_FEMALE
        history = await _get_history(db_session, client_id, GENDER_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == GENDER_MALE

    async def test_gender_resent_unchanged_is_idempotent(self, db_session: AsyncSession, factory: Factory) -> None:
        # Регрессия: повторное сохранение того же gender не должно «дважды маппиться» (например, "Мужской" → KeyError).
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(
            client_id=client_id, body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="male")
        )
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(gender="male"))

        current = await _get_parameter(db_session, client_id, GENDER_PARAMETER_CODE)
        assert current is not None and current.value == GENDER_MALE


class TestBmi:
    async def test_bmi_computed_when_both_present(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None
        assert bmi.value == "23.51"

    async def test_bmi_recomputed_when_height_changes(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=180))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None and bmi.value == "22.22"
        history = await _get_history(db_session, client_id, BMI_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == "23.51"

    async def test_bmi_recomputed_when_weight_changes(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=80))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None and bmi.value == "26.12"
        # Старый ИМТ ушёл в history.
        history = await _get_history(db_session, client_id, BMI_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == "23.51"

    async def test_bmi_not_recomputed_when_height_and_weight_resent_unchanged(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))
        # Повторный запрос с теми же height/weight — ИМТ не пересчитывается, history не растёт.
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None and bmi.value == "23.51"
        history = await _get_history(db_session, client_id, BMI_PARAMETER_CODE)
        assert history == []

    async def test_bmi_recomputed_when_invalidated_and_resent_unchanged(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        # Bug #136: после answers-reset (CVD/ENDO) bmi/height/weight инвалидированы (expiration_date в прошлом),
        # но строки остались. Повторный ввод ТЕХ ЖЕ роста/веса должен вернуть ИМТ в актуальное состояние.
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))
        await _soft_invalidate(db_session, client_id, HEIGHT_PARAMETER_CODE, WEIGHT_PARAMETER_CODE, BMI_PARAMETER_CODE)
        # Те же height/weight — раньше ИМТ не пересчитывался и оставался протухшим (баг), теперь пересчитывается.
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None and bmi.value == "23.51"
        # ИМТ снова актуален (expiration_date в будущем) и виден калькуляторам.
        assert bmi.expiration_date > now_utc()
        # Инвалидированная строка ушла в history — подтверждает, что произошла реальная перезапись.
        history = await _get_history(db_session, client_id, BMI_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == "23.51"

    async def test_bmi_not_recomputed_when_no_change(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(height_cm=175, weight_kg=72))
        # Второй запрос без height/weight — ИМТ остаётся прежним, history не растёт.
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(gender="male"))

        bmi = await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)
        assert bmi is not None and bmi.value == "23.51"
        history = await _get_history(db_session, client_id, BMI_PARAMETER_CODE)
        assert history == []

    async def test_bmi_not_computed_without_height(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=72))

        assert (await _get_parameter(db_session, client_id, BMI_PARAMETER_CODE)) is None


class TestAge:
    async def test_age_computed_when_birth_date_present(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        birth = date(1990, 3, 15)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))

        age = await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)
        assert age is not None
        assert age.value == str(compute_age(birth, now_utc().date()))

    async def test_age_recomputed_when_birth_date_changes(self, db_session: AsyncSession, factory: Factory) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        first = date(1990, 3, 15)
        second = date(2000, 3, 15)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=first))
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=second))

        age = await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)
        assert age is not None and age.value == str(compute_age(second, now_utc().date()))
        history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == str(compute_age(first, now_utc().date()))

    async def test_age_not_recomputed_when_birth_date_resent_unchanged(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        birth = date(1990, 3, 15)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))
        # Повторный запрос с той же birth_date — возраст не пересчитывается, history не растёт.
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))

        age = await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)
        assert age is not None and age.value == str(compute_age(birth, now_utc().date()))
        history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
        assert history == []

    async def test_age_recomputed_when_invalidated_and_birth_date_resent_unchanged(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        # Симметрично Bug #136: протухший (soft-invalidated) возраст при повторной присылке той же
        # birthDate должен вернуться в актуальное состояние, а не остаться невидимым для калькуляторов.
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        birth = date(1990, 3, 15)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))
        await _soft_invalidate(db_session, client_id, AGE_PARAMETER_CODE)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))

        age = await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)
        assert age is not None and age.value == str(compute_age(birth, now_utc().date()))
        assert age.expiration_date > now_utc()
        history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
        assert len(history) == 1 and history[0].value == str(compute_age(birth, now_utc().date()))

    async def test_age_not_recomputed_when_birth_date_absent_in_request(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        birth = date(1990, 3, 15)
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(birth_date=birth))
        # Запрос без birth_date — расчёт возраста не запускается (см. вики, шаг 4: гейт «передан birthDate»).
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=72))

        age = await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)
        assert age is not None and age.value == str(compute_age(birth, now_utc().date()))
        history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
        assert history == []

    async def test_age_not_computed_for_existing_patient_without_birth_date_in_request(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)

        # Существующий пациент без сохранённого age; запрос без birth_date — age не вычисляется.
        await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=72))

        assert (await _get_parameter(db_session, client_id, AGE_PARAMETER_CODE)) is None


async def _db_validity_period(session: AsyncSession, code: str) -> datetime:
    """Фактический parameters.validity_period из БД (значения засеяны миграциями, #160 их не менял)."""
    return (
        await session.execute(text("SELECT validity_period FROM parameters WHERE code = :code"), {"code": code})
    ).scalar_one()


class TestValidityFromDb:
    """Срок жизни берётся из `parameters.validity_period` (БД), а не из удалённой in-memory таблицы."""

    async def test_expiration_computed_from_db_validity_like_risk_communication(self, db_session: AsyncSession) -> None:
        # Задача 4.3 / spec «Срок жизни берётся из справочника»: expiration_date height, назначенный
        # risk-init, равен now + (parameters.validity_period[height] − epoch) — ровно то, что дал бы
        # risk-communication (обе стороны зовут compute_expiration с одним и тем же значением из БД).
        # Срок берём из реального сида (после #160 height живёт 10 лет, а не 5 из удалённой таблицы) —
        # тест не зашивает число, а сверяется с тем, что реально лежит в `parameters`.
        await _close_seed_transaction(db_session)  # commit закрывает savepoint; сами значения — из миграций
        client_id = _new_client_id()
        service = await _make_service(db_session)

        before = datetime.now(tz=UTC)
        await service.save_anthropometry(
            client_id=client_id,
            body=AnthropometryRequest(height_cm=175, weight_kg=72, birth_date=date(1990, 3, 15), gender="male"),
        )
        after = datetime.now(tz=UTC)

        db_validity = await _db_validity_period(db_session, HEIGHT_PARAMETER_CODE)
        row = await _get_parameter(db_session, client_id, HEIGHT_PARAMETER_CODE)
        assert row is not None
        # Точный `now` сервиса недоступен, поэтому проверяем попадание в окно [before, after].
        assert compute_expiration(before, db_validity) <= row.expiration_date <= compute_expiration(after, db_validity)

    async def test_missing_validity_in_catalog_raises_and_writes_nothing(
        self, db_session: AsyncSession, factory: Factory, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        await _close_seed_transaction(db_session)
        client_id = _new_client_id()
        await _seed_existing_patient(db_session, factory, client_id)
        service = await _make_service(db_session)
        parameters = dict(service._catalog.parameters)
        parameters.pop(WEIGHT_PARAMETER_CODE)
        monkeypatch.setattr(service, "_catalog", SimpleNamespace(parameters=parameters))

        with pytest.raises(RuntimeError, match=WEIGHT_PARAMETER_CODE):
            await service.save_anthropometry(client_id=client_id, body=AnthropometryRequest(weight_kg=70))

        assert (await _get_parameter(db_session, client_id, WEIGHT_PARAMETER_CODE)) is None
