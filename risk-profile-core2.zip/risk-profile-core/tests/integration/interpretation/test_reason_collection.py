"""Сбор причин интерпретации на настоящей БД: содержимое строк, изоляция, деградация.

Почему тут своя сессия, а не общая фикстура `db_session`: коллектор пишет ОТДЕЛЬНОЙ транзакцией
на СОБСТВЕННОЙ сессии — это и есть проверяемое свойство. Данные, лежащие в незакоммиченной
транзакции чужой сессии, ему не видны (и FK на пациента не сойдётся), поэтому сиды здесь
коммитятся по-настоящему, а за собой тест убирает сам (`committed_session_factory`).

Таблицы `interpretation_statuses` и `risk_factor_matches` создаёт миграция безусловно (ревизия
0118) — они существуют на тестовой базе независимо от состояния флага, отдельно поднимать их не
нужно.
"""

import logging
from collections.abc import AsyncGenerator
from decimal import Decimal
from typing import Any
from unittest.mock import patch

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.config import settings
from src.interpretation.domain.models import InterpretationReasonCode, ValueStatus
from src.interpretation.handler import InterpretationHandler
from src.interpretation.infra.repository import InterpretationRepository
from src.interpretation.persistence import InterpretationWriter
from src.interpretation.reason_collector import InterpretationReasonCollector
from tests.conftest import PHYSICAL_CONNECT_ARGS, make_interpretation_catalog
from tests.factories import Factory

# Единый префикс синтетических кодов: по нему же идёт уборка, чтобы соседние тесты не увидели
# инструментов этого модуля в своём каталоге.
PREFIX = "T_IR_"
SYSTEM = "ENDO"
AGE_PARAM = f"{PREFIX}age"

# Уборка за тестом: сначала строки пациентов (по списку созданных), затем синтетический
# каталог (по префиксу кодов). Порядок продиктован FK RESTRICT — иначе `patients` не удалить.
_CLEANUP_BY_PATIENT = (
    "DELETE FROM risk_factor_matches WHERE patient_id = ANY(:pids)",
    "DELETE FROM interpretation_statuses WHERE patient_id = ANY(:pids)",
    "DELETE FROM results_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM results WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients_parameters_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients_parameters WHERE patient_id = ANY(:pids)",
    "DELETE FROM interpretations WHERE patient_id = ANY(:pids)",
    "DELETE FROM interpretations_history WHERE patient_id = ANY(:pids)",
    "DELETE FROM patients WHERE patient_id = ANY(:pids)",
)

_CLEANUP_CATALOG = (
    f"DELETE FROM risk_factor_triggers WHERE risk_factor_code LIKE '{PREFIX}%'",
    f"DELETE FROM risk_factor_systems WHERE risk_factor_code LIKE '{PREFIX}%'",
    f"DELETE FROM risk_factors WHERE code LIKE '{PREFIX}%'",
    f"DELETE FROM parameter_scores WHERE parameter_code LIKE '{PREFIX}%'",
    f"DELETE FROM instruments_parameters WHERE instrument_code LIKE '{PREFIX}%'",
    f"DELETE FROM instruments_parameters WHERE parameter_code LIKE '{PREFIX}%'",
    f"DELETE FROM parameters WHERE code LIKE '{PREFIX}%'",
    f"DELETE FROM systems_instruments WHERE instrument_code LIKE '{PREFIX}%'",
    f"DELETE FROM instruments WHERE code LIKE '{PREFIX}%'",
    f"DELETE FROM systems WHERE code LIKE '{PREFIX}%'",
)


@pytest.fixture
def created_patients() -> list[str]:
    return []


@pytest_asyncio.fixture
async def committed_session_factory(
    postgres_url: str, created_patients: list[str]
) -> AsyncGenerator[async_sessionmaker[AsyncSession], None]:
    """Фабрика сессий, которые ДЕЙСТВИТЕЛЬНО коммитят, плюс уборка за тестом."""
    engine = create_async_engine(postgres_url, connect_args=PHYSICAL_CONNECT_ARGS)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        yield session_factory
    finally:
        async with session_factory() as session:
            for statement in _CLEANUP_BY_PATIENT:
                await session.execute(text(statement), {"pids": created_patients})
            for statement in _CLEANUP_CATALOG:
                await session.execute(text(statement))
            await session.commit()
        await engine.dispose()


@pytest.fixture
def collection_on(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)


@pytest.fixture
def collection_off(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)


async def _seed_patient(
    session_factory: async_sessionmaker[AsyncSession],
    created_patients: list[str],
    *,
    risk_level: str = "high",
    diseases: list[str] | None = None,
    instrument_code: str = f"{PREFIX}findrisk",
) -> str:
    """Пациент с одним результатом в ENDO — минимальный вход прогона интерпретации."""
    async with session_factory() as session:
        factory = Factory(session)
        patient_id = await factory.patient()
        created_patients.append(patient_id)
        await factory.instrument_with_params(instrument_code, required=[], in_system=False)
        await factory.set_instrument_diseases(instrument_code=instrument_code, diseases=diseases)
        await factory.link_system_instrument(system_code=SYSTEM, instrument_code=instrument_code)
        await factory.result(patient_id=patient_id, instrument_code=instrument_code, risk_level=risk_level)
        await session.commit()
    return patient_id


async def _seed_answered_age(
    session_factory: async_sessionmaker[AsyncSession], patient_id: str, *, value: str = "70"
) -> None:
    """Отвеченный параметр возраста, привязанный к инструменту системы (кандидатам нужен параметр)."""
    async with session_factory() as session:
        factory = Factory(session)
        # Инструмент уже создан `_seed_patient` — здесь к нему только добавляется параметр.
        await factory.parameter(AGE_PARAM)
        await factory.link_parameter(instrument_code=f"{PREFIX}findrisk", parameter_code=AGE_PARAM, is_required=False)
        await factory.answer(patient_id=patient_id, parameter_code=AGE_PARAM, value=value)
        await factory.parameter_score(parameter_code=AGE_PARAM, system_code=SYSTEM, score=2, min_value=0, max_value=200)
        await session.commit()


async def _seed_risk_factors(
    session_factory: async_sessionmaker[AsyncSession], codes: list[str], *, system_code: str = SYSTEM
) -> list[int]:
    """Строки справочника, каждая со своим бакетом: одинаковые нарушили бы естественный ключ.

    Бакеты подобраны так, чтобы все они накрывали ответ пациента (70) — иначе строки одного кода
    не сработали бы вместе, а именно это и проверяет дедупликация.
    """
    ids: dict[str, int] = {}
    async with session_factory() as session:
        factory = Factory(session)
        for index, code in enumerate(codes):
            bucket = {
                "parameter_code": AGE_PARAM,
                "system_code": system_code,
                "min_param_value": str(60 + index),
                "max_param_value": str(100 + index),
            }
            if code in ids:
                # Повтор кода в списке — ещё один бакет того же фактора, а не второй фактор.
                await factory.risk_factor_trigger(code=code, **bucket)
            else:
                ids[code] = (await factory.risk_factor(code, **bucket)).risk_factor_id
        await session.commit()
    return [ids[code] for code in codes]


async def _run(
    session_factory: async_sessionmaker[AsyncSession], patient_id: str, system_code: str = SYSTEM
) -> dict[str, Any]:
    """Прогон по системе с коллектором на тестовой базе.

    Коллектор получает ту же фабрику, что и сиды: по умолчанию он ходил бы в боевой движок
    приложения, а не в тестовую базу.
    """
    async with session_factory() as session:
        handler = InterpretationHandler(
            session,
            catalog=await make_interpretation_catalog(session),
            reason_collector=InterpretationReasonCollector(session_factory=session_factory),
        )
        return await handler.run_for(patient_id, [system_code])


async def _fetch_status(session_factory: async_sessionmaker[AsyncSession], patient_id: str) -> dict[str, Any] | None:
    async with session_factory() as session:
        row = (
            await session.execute(
                text("SELECT * FROM interpretation_statuses WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).mappings()
        return dict(row.one_or_none() or {}) or None


async def _fetch_matches(session_factory: async_sessionmaker[AsyncSession], patient_id: str) -> list[dict[str, Any]]:
    async with session_factory() as session:
        rows = (
            await session.execute(
                text(
                    "SELECT * FROM risk_factor_matches WHERE patient_id = :pid"
                    " ORDER BY risk_factor_code, parameter_code, operator, value_num, min_value, max_value,"
                    " value_text, gender"
                ),
                {"pid": patient_id},
            )
        ).mappings()
        return [dict(row) for row in rows]


async def _fetch_interpretation(session_factory: async_sessionmaker[AsyncSession], patient_id: str) -> dict[str, Any]:
    async with session_factory() as session:
        row = (
            await session.execute(
                text(
                    "SELECT risk_level, diseases, risk_factors_code, doctors_code"
                    " FROM interpretations WHERE patient_id = :pid AND system_code = :sys"
                ),
                {"pid": patient_id, "sys": SYSTEM},
            )
        ).mappings()
        return dict(row.one())


class TestFlagIsNotObservable:
    async def test_disabled_collection_writes_nothing(
        self,
        collection_off: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients)

        await _run(committed_session_factory, patient_id)

        assert await _fetch_status(committed_session_factory, patient_id) is None
        assert await _fetch_matches(committed_session_factory, patient_id) == []

    async def test_interpretation_is_identical_with_and_without_collection(
        self,
        monkeypatch: pytest.MonkeyPatch,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Тот же вход при обоих состояниях флага: строка `interpretations` и возврат совпадают."""
        patient_id = await _seed_patient(committed_session_factory, created_patients, diseases=["diabetes_mellitus"])
        await _seed_answered_age(committed_session_factory, patient_id)
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1", f"{PREFIX}rf2"])

        monkeypatch.setattr(settings, "calc_status_collection_enabled", False)
        off_returned = await _run(committed_session_factory, patient_id)
        off_row = await _fetch_interpretation(committed_session_factory, patient_id)

        monkeypatch.setattr(settings, "calc_status_collection_enabled", True)
        on_returned = await _run(committed_session_factory, patient_id)
        on_row = await _fetch_interpretation(committed_session_factory, patient_id)

        assert off_row == on_row
        assert {code: value.risk_factors for code, value in off_returned.items()} == {
            code: value.risk_factors for code, value in on_returned.items()
        }
        assert off_returned.keys() == on_returned.keys()
        # Сбор при этом действительно работал — иначе тест сравнивал бы два одинаковых прогона.
        assert await _fetch_status(committed_session_factory, patient_id) is not None


class TestTaxonomy:
    async def test_all_four_results_empty_carry_their_reasons(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """У системы без результатов пусты все четыре результата, и причины у них разные."""
        async with committed_session_factory() as session:
            factory = Factory(session)
            patient_id = await factory.patient()
            created_patients.append(patient_id)
            await session.commit()

        await _run(committed_session_factory, patient_id)

        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["risk_level_status"] == ValueStatus.EMPTY.value
        assert status["risk_level_reason_code"] == InterpretationReasonCode.NO_RESULTS.value
        assert status["diseases_reason_code"] == InterpretationReasonCode.NO_MEDIUM_HIGH_RESULTS.value
        # Уровня риска у системы нет вовсе, поэтому код гейта факторов назван по самой проверке
        # (не входит в medium/high) — иначе строка утверждала бы посчитанный низкий уровень.
        assert status["risk_factors_reason_code"] == InterpretationReasonCode.RISK_LEVEL_NOT_MEDIUM_HIGH.value
        # Врачи у ENDO при пустом уровне риска берутся из строки справочника с risk_level='low',
        # поэтому этот результат как раз выдан — причины у него нет.
        assert status["doctors_status"] == ValueStatus.COMPUTED.value
        assert status["doctors_reason_code"] is None

    async def test_computed_results_have_no_reason(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients, diseases=["diabetes_mellitus"])

        await _run(committed_session_factory, patient_id)

        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["risk_level_status"] == ValueStatus.COMPUTED.value
        assert status["risk_level_reason_code"] is None
        assert status["diseases_status"] == ValueStatus.COMPUTED.value
        assert status["diseases_reason_code"] is None

    async def test_no_candidates_differs_from_no_candidate_matched(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Своя система: у ENDO кандидаты есть в справочнике, и «кандидатов нет» там не получить."""
        system = f"{PREFIX}SYS"
        instrument = f"{PREFIX}iso"
        async with committed_session_factory() as session:
            factory = Factory(session)
            patient_id = await factory.patient()
            created_patients.append(patient_id)
            await factory.instrument_with_params(instrument, required=[], optional=[AGE_PARAM], in_system=False)
            await factory.system(system)
            await factory.link_system_instrument(system_code=system, instrument_code=instrument)
            await factory.result(patient_id=patient_id, instrument_code=instrument, risk_level="high")
            await factory.answer(patient_id=patient_id, parameter_code=AGE_PARAM, value="30")
            await session.commit()

        await _run(committed_session_factory, patient_id, system)
        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["risk_factors_reason_code"] == InterpretationReasonCode.NO_CANDIDATES.value

        # Кандидат появился, но пациент в его бакет не попадает (30 вне 60..100). Кандидатом
        # первого блока условие делает строка `parameter_scores` по паре «параметр × система».
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"], system_code=system)
        async with committed_session_factory() as session:
            await Factory(session).parameter_score(
                parameter_code=AGE_PARAM, system_code=system, min_value=60, max_value=100, score=Decimal("2")
            )
            await session.commit()
        await _run(committed_session_factory, patient_id, system)
        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["risk_factors_reason_code"] == InterpretationReasonCode.NO_CANDIDATE_MATCHED.value

    async def test_other_instruments_do_not_block_diseases(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Инструменты системы без групп со средним риском больше не обнуляют подтверждённую группу."""
        patient_id = await _seed_patient(committed_session_factory, created_patients, diseases=["diabetes_mellitus"])
        async with committed_session_factory() as session:
            factory = Factory(session)
            for code in (f"{PREFIX}other1", f"{PREFIX}other2"):
                await factory.instrument_with_params(code, required=[], in_system=False)
                await factory.set_instrument_diseases(instrument_code=code, diseases=None)
                await factory.link_system_instrument(system_code=SYSTEM, instrument_code=code)
                await factory.result(patient_id=patient_id, instrument_code=code, risk_level="medium")
            await session.commit()

        await _run(committed_session_factory, patient_id)

        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["diseases_status"] == ValueStatus.COMPUTED.value
        assert status["diseases_reason_code"] is None
        assert status["blocking_instrument_codes"] is None

    async def test_significant_risk_without_groups_is_no_group_matched(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients, diseases=None)

        await _run(committed_session_factory, patient_id)

        status = await _fetch_status(committed_session_factory, patient_id)
        assert status is not None
        assert status["diseases_status"] == ValueStatus.EMPTY.value
        assert status["diseases_reason_code"] == InterpretationReasonCode.NO_GROUP_MATCHED.value
        assert status["blocking_instrument_codes"] is None

    async def test_empty_lists_are_stored_as_missing_values(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Схлопывание пустого списка сохранено: в `interpretations` отсутствующие значения."""
        patient_id = await _seed_patient(committed_session_factory, created_patients)

        await _run(committed_session_factory, patient_id)

        row = await _fetch_interpretation(committed_session_factory, patient_id)
        assert row["diseases"] is None
        assert row["risk_factors_code"] is None


class TestRiskFactorMatches:
    async def test_three_rows_of_one_code_keep_one_representative(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id)
        # Три строки справочника с одним кодом — как после расширения естественного ключа.
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"] * 3)

        await _run(committed_session_factory, patient_id)

        matches = await _fetch_matches(committed_session_factory, patient_id)
        assert len(matches) == 3
        representatives = [m for m in matches if m["is_representative"]]
        assert len(representatives) == 1
        assert len([m for m in matches if not m["is_representative"]]) == 2
        assert len({(m["min_value"], m["max_value"]) for m in matches}) == 3
        # Состав кодов в профиле от сбора не зависит: один код — одна запись.
        row = await _fetch_interpretation(committed_session_factory, patient_id)
        assert row["risk_factors_code"] == [f"{PREFIX}rf1"]

    async def test_two_codes_keep_one_representative_each(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Представители на двух кодах: их множество совпадает с `interpretations.risk_factors_code`."""
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id)
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1", f"{PREFIX}rf1", f"{PREFIX}rf2"])

        await _run(committed_session_factory, patient_id)

        matches = await _fetch_matches(committed_session_factory, patient_id)
        assert len(matches) == 3
        representatives = {m["risk_factor_code"] for m in matches if m["is_representative"]}
        assert representatives == {f"{PREFIX}rf1", f"{PREFIX}rf2"}
        row = await _fetch_interpretation(committed_session_factory, patient_id)
        assert set(row["risk_factors_code"]) == representatives
        # Вытеснена ровно одна лишняя строка кода rf1, и указывает она на представителя своего кода.
        (superseded,) = [m for m in matches if not m["is_representative"]]
        assert superseded["risk_factor_code"] == f"{PREFIX}rf1"
        assert any(m["is_representative"] and m["risk_factor_code"] == f"{PREFIX}rf1" for m in matches)

    async def test_cleanup_covers_the_run_and_spares_other_systems(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Чистка перед вставкой ограничена системами прогона и не зависит от наличия совпадений.

        Система прогона, в которой в этот раз не сработало ничего, теряет строки прошлого прогона;
        система, которой в прогоне не было, свои сохраняет — иначе диагностика по ней исчезала бы
        при интерпретации соседней системы.
        """
        other_system = f"{PREFIX}SYS2"
        other_instrument = f"{PREFIX}iso2"
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id)
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"])
        async with committed_session_factory() as session:
            factory = Factory(session)
            # AGE_PARAM уже заведён `_seed_answered_age` — второй инструмент только ссылается на него.
            await factory.instrument(other_instrument)
            await factory.link_parameter(instrument_code=other_instrument, parameter_code=AGE_PARAM, is_required=False)
            await factory.system(other_system)
            await factory.link_system_instrument(system_code=other_system, instrument_code=other_instrument)
            await factory.result(patient_id=patient_id, instrument_code=other_instrument, risk_level="high")
            await factory.parameter_score(
                parameter_code=AGE_PARAM, system_code=other_system, score=2, min_value=0, max_value=200
            )
            await session.commit()
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf2"], system_code=other_system)

        await _run(committed_session_factory, patient_id)
        await _run(committed_session_factory, patient_id, other_system)
        assert {m["system_code"] for m in await _fetch_matches(committed_session_factory, patient_id)} == {
            SYSTEM,
            other_system,
        }

        # Ответ больше не попадает ни в один бакет, но прогон идёт только по ENDO.
        async with committed_session_factory() as session:
            await session.execute(
                text("UPDATE patients_parameters SET value = '30' WHERE patient_id = :pid AND parameter_code = :p"),
                {"pid": patient_id, "p": AGE_PARAM},
            )
            await session.commit()
        await _run(committed_session_factory, patient_id)

        matches = await _fetch_matches(committed_session_factory, patient_id)
        assert [m["system_code"] for m in matches] == [other_system]
        assert matches[0]["risk_factor_code"] == f"{PREFIX}rf2"

    async def test_only_reference_data_is_stored(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Значение ответа пациента не попадает ни в одно поле — только справочник."""
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id, value="77")
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"])

        await _run(committed_session_factory, patient_id)

        (match,) = await _fetch_matches(committed_session_factory, patient_id)
        assert (match["min_value"], match["max_value"]) == (Decimal("60"), Decimal("100"))
        assert "77" not in {str(value) for value in match.values()}

    async def test_catalog_reload_is_not_blocked_by_stored_matches(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Перезаливка справочника проходит при заполненной таблице: внешних ключей на неё нет."""
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id)
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"])
        await _run(committed_session_factory, patient_id)
        assert await _fetch_matches(committed_session_factory, patient_id) != []

        async with committed_session_factory() as session:
            await session.execute(text(f"DELETE FROM risk_factor_triggers WHERE risk_factor_code LIKE '{PREFIX}%'"))
            await session.execute(text(f"DELETE FROM risk_factor_systems WHERE risk_factor_code LIKE '{PREFIX}%'"))
            await session.execute(text(f"DELETE FROM risk_factors WHERE code LIKE '{PREFIX}%'"))
            await session.commit()

        # Снимок условия пережил удаление строки справочника.
        (match,) = await _fetch_matches(committed_session_factory, patient_id)
        assert match["min_value"] == Decimal("60")

    async def test_factor_that_stopped_matching_leaves_no_stale_row(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients)
        await _seed_answered_age(committed_session_factory, patient_id)
        await _seed_risk_factors(committed_session_factory, [f"{PREFIX}rf1"])
        await _run(committed_session_factory, patient_id)
        assert len(await _fetch_matches(committed_session_factory, patient_id)) == 1

        async with committed_session_factory() as session:
            await session.execute(
                text("UPDATE patients_parameters SET value = '30' WHERE patient_id = :pid AND parameter_code = :p"),
                {"pid": patient_id, "p": AGE_PARAM},
            )
            await session.commit()
        await _run(committed_session_factory, patient_id)

        assert await _fetch_matches(committed_session_factory, patient_id) == []


class TestWriteBoundaries:
    async def test_degraded_path_writes_no_reasons(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Пачка откатилась, запись пошла по системам — причин не появляется ни по одной."""
        patient_id = await _seed_patient(committed_session_factory, created_patients)

        async def _batch_boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
            # Транзиентный сбой: только он деградирует на посистемную запись, перманентный
            # (NonRetriable) прошёл бы наружу и оборвал прогон, не дойдя до проверяемого места.
            raise OperationalError("stmt", {}, Exception("simulated batch failure"))

        with patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom):
            await _run(committed_session_factory, patient_id)

        # Интерпретация при этом сохранилась посистемным путём.
        assert await _fetch_interpretation(committed_session_factory, patient_id) is not None
        assert await _fetch_status(committed_session_factory, patient_id) is None

    async def test_failed_write_phase_leaves_no_rows_in_the_buffer(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
    ) -> None:
        """Исключение в фазе записи не оставляет накопленное в памяти хендлера.

        Хендлер живёт весь диспатч и обходит пациентов по одному, а флаш адресный: строки упавшего
        пациента записаны уже не будут и без снятия копились бы до конца обхода.
        """
        patient_id = await _seed_patient(committed_session_factory, created_patients)

        async def _batch_boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
            # Транзиентный сбой: только он деградирует на посистемную запись, перманентный
            # (NonRetriable) прошёл бы наружу и оборвал прогон, не дойдя до проверяемого места.
            raise OperationalError("stmt", {}, Exception("simulated batch failure"))

        async def _mark_boom(self: InterpretationWriter, *args: Any) -> None:  # noqa: ARG001
            raise RuntimeError("simulated mark failure")

        collector = InterpretationReasonCollector(session_factory=committed_session_factory)
        async with committed_session_factory() as session:
            handler = InterpretationHandler(
                session, catalog=await make_interpretation_catalog(session), reason_collector=collector
            )
            with (
                patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
                patch.object(InterpretationWriter, "_mark_results_done", _mark_boom),
                pytest.raises(RuntimeError, match="simulated mark failure"),
            ):
                await handler.run_for(patient_id, [SYSTEM])

        assert collector.pending() == ({}, {})

    async def test_reason_write_failure_does_not_touch_interpretations(
        self,
        collection_on: None,
        committed_session_factory: async_sessionmaker[AsyncSession],
        created_patients: list[str],
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        patient_id = await _seed_patient(committed_session_factory, created_patients, diseases=["diabetes_mellitus"])

        class _FailingSession:
            async def __aenter__(self) -> "_FailingSession":
                return self

            async def __aexit__(self, *exc: object) -> bool:
                return False

            async def execute(self, statement: Any, params: Any = None) -> None:
                raise OperationalError("stmt", {}, Exception("connection dropped"))

            async def commit(self) -> None:  # pragma: no cover - до коммита не доходит
                raise AssertionError("коммит недостижим: execute падает раньше")

        collector = InterpretationReasonCollector(session_factory=_FailingSession)  # ty: ignore[invalid-argument-type]
        with caplog.at_level(logging.ERROR, logger="app"):
            async with committed_session_factory() as session:
                handler = InterpretationHandler(
                    session, catalog=await make_interpretation_catalog(session), reason_collector=collector
                )
                returned = await handler.run_for(patient_id, [SYSTEM])

        # Прогон завершился штатно, интерпретация закоммичена, сбой ушёл в лог.
        assert SYSTEM in returned
        assert await _fetch_interpretation(committed_session_factory, patient_id) is not None
        assert await _fetch_status(committed_session_factory, patient_id) is None
        assert [r.getMessage() for r in caplog.records if r.levelno >= logging.ERROR] == [
            "interpretation.reason_collector: write failed, reasons for this patient are lost"
        ]
