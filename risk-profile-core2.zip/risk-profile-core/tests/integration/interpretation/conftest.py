"""Фикстуры интеграционных тестов интерпретации."""

from collections.abc import Awaitable, Callable

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from src.interpretation.handler import InterpretationHandler
from tests.conftest import make_interpretation_catalog

# Фабрика хендлера, которую отдаёт фикстура `interpretation_handler`.
InterpretationHandlerFactory = Callable[..., Awaitable[InterpretationHandler]]


@pytest_asyncio.fixture
async def interpretation_handler(db_session: AsyncSession) -> InterpretationHandlerFactory:
    """Фабрика хендлера: вызывать ПОСЛЕ сидов теста.

    Каталог снимается с БД, поэтому собрать его заранее нельзя — каждый тест засевает свои
    справочные строки, и хендлер обязан их видеть. По той же причине это фабрика, а не готовый
    объект: фикстура, вычисленная до тела теста, увидела бы пустой справочник.
    """

    async def _make(**kwargs: object) -> InterpretationHandler:
        kwargs.setdefault("catalog", await make_interpretation_catalog(db_session))
        return InterpretationHandler(db_session, **kwargs)  # ty: ignore[invalid-argument-type]

    return _make
