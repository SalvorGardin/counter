"""Отбор строк результата для интерпретации: группа заболеваний против связи инструмента."""

from datetime import UTC, datetime, timedelta

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.patients.dtos import ActiveParameter
from src.interpretation.computing import SystemInterpreter
from src.interpretation.domain.models import ResultRow
from src.interpretation.infra.reader import InterpretationReader
from src.interpretation.loading import LoadedInterpretationData
from src.interpretation.reason_collector import InterpretationReasonCollector
from tests.conftest import make_interpretation_catalog
from tests.consts import BIOMARKER_CLINREC_INSTRUMENT_CODE
from tests.factories import Factory, now_utc

BIOMARKER_KR = BIOMARKER_CLINREC_INSTRUMENT_CODE


async def _seed_two_systems(factory: Factory) -> tuple[str, str, str, str, str]:
    """Инструмент `biomarker_kr` в двух системах и по группе заболеваний в каждой."""
    patient_id = await factory.patient()
    first_system = await factory.system()
    second_system = await factory.system()
    await factory.biomarker_clinrec_instrument()
    await factory.link_system_instrument(system_code=first_system, instrument_code=BIOMARKER_KR)
    await factory.link_system_instrument(system_code=second_system, instrument_code=BIOMARKER_KR)
    first_disease = await factory.disease(system_code=first_system)
    second_disease = await factory.disease(system_code=second_system)
    return patient_id, first_system, second_system, first_disease, second_disease


async def test_disease_row_goes_only_to_its_own_system(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first_system, second_system, first_disease, _ = await _seed_two_systems(factory)
    await factory.result(
        patient_id=patient_id, instrument_code=BIOMARKER_KR, disease_code=first_disease, risk_level="high"
    )
    await db_session.commit()

    grouped = await InterpretationReader(db_session).get_results_for_systems(patient_id, [first_system, second_system])

    assert [row.disease_code for row in grouped[first_system]] == [first_disease]
    # Инструмент связан и со второй системой, но группа принадлежит первой — строка не размножается.
    assert grouped[second_system] == []


async def test_several_groups_of_one_instrument(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first_system, _, first_disease, _ = await _seed_two_systems(factory)
    another_disease = await factory.disease(system_code=first_system)
    for disease_code in (first_disease, another_disease):
        await factory.result(
            patient_id=patient_id, instrument_code=BIOMARKER_KR, disease_code=disease_code, risk_level="high"
        )
    await db_session.commit()

    grouped = await InterpretationReader(db_session).get_results_for_systems(patient_id, [first_system])

    assert sorted(row.disease_code for row in grouped[first_system]) == sorted([first_disease, another_disease])


async def test_ordinary_result_is_selected_by_instrument_link(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first_system, second_system, _, _ = await _seed_two_systems(factory)
    ordinary = await factory.instrument_with_params("ORD_READER", required=[], in_system=False)
    await factory.link_system_instrument(system_code=first_system, instrument_code=ordinary)
    await factory.link_system_instrument(system_code=second_system, instrument_code=ordinary)
    await factory.result(patient_id=patient_id, instrument_code=ordinary, risk_level="medium")
    await db_session.commit()

    grouped = await InterpretationReader(db_session).get_results_for_systems(patient_id, [first_system, second_system])

    # Обычный результат по-прежнему приходит в каждую систему своего инструмента.
    assert [row.instrument_code for row in grouped[first_system]] == [ordinary]
    assert [row.instrument_code for row in grouped[second_system]] == [ordinary]
    assert grouped[first_system][0].disease_code is None


async def test_ordinary_result_with_disease_code_still_uses_instrument_link(
    db_session: AsyncSession, factory: Factory
) -> None:
    patient_id, disease_system, instrument_system, disease_code, _ = await _seed_two_systems(factory)
    ordinary = await factory.instrument_with_params("ORD_WITH_DISEASE", required=[], in_system=False)
    await factory.link_system_instrument(system_code=instrument_system, instrument_code=ordinary)
    await factory.result(
        patient_id=patient_id,
        instrument_code=ordinary,
        disease_code=disease_code,
        risk_level="medium",
    )
    await db_session.commit()

    grouped = await InterpretationReader(db_session).get_results_for_systems(
        patient_id, [disease_system, instrument_system]
    )

    assert grouped[disease_system] == []
    assert [row.instrument_code for row in grouped[instrument_system]] == [ordinary]


async def test_expired_disease_row_is_not_selected(db_session: AsyncSession, factory: Factory) -> None:
    patient_id, first_system, _, first_disease, _ = await _seed_two_systems(factory)
    await factory.result(
        patient_id=patient_id,
        instrument_code=BIOMARKER_KR,
        disease_code=first_disease,
        risk_level="high",
        expiration_date=now_utc() - timedelta(days=1),
    )
    await db_session.commit()

    grouped = await InterpretationReader(db_session).get_results_for_systems(patient_id, [first_system])

    assert grouped[first_system] == []


async def test_compute_phase_issues_no_queries(db_session: AsyncSession, factory: Factory) -> None:
    """После фазы загрузки расчёт интерпретации не ходит в БД — весь справочник в каталоге."""
    patient_id, first_system, _, first_disease, _ = await _seed_two_systems(factory)
    await factory.parameter("biomarker_ldl")
    # Параметр должен быть связан с `biomarker_kr`: клинрек-источник интерпретации берёт ровно
    # тот набор биомаркеров, по которому считает расчёт (`biomarker_parameter_codes`).
    await factory.link_parameter(instrument_code=BIOMARKER_KR, parameter_code="biomarker_ldl", is_required=False)
    await factory.risk_factor(
        "rf_ldl_reader", system_code=first_system, parameter_code="biomarker_ldl", param_value="Повышен"
    )
    await factory.risk_factor_score(risk_factor_code="rf_ldl_reader", disease_code=first_disease)
    await factory.result(
        patient_id=patient_id, instrument_code=BIOMARKER_KR, disease_code=first_disease, risk_level="high"
    )
    await db_session.commit()

    catalog = await make_interpretation_catalog(db_session)
    loaded = LoadedInterpretationData(
        systems=(first_system,),
        results_by_system={
            first_system: [
                ResultRow(
                    instrument_code=BIOMARKER_KR,
                    risk_level="high",
                    applicability=True,
                    disease_code=first_disease,
                )
            ]
        },
        patient_parameters={
            "biomarker_ldl": ActiveParameter(
                "biomarker_ldl",
                "Повышен",
                datetime.now(tz=UTC) + timedelta(days=1),
                datetime.now(tz=UTC),
                1,
            )
        },
        patient_values={"biomarker_ldl": "Повышен"},
        gender=None,
        systems_by_instrument={},
    )

    statements: list[str] = []
    sync_engine = db_session.get_bind()

    def _record(conn, cursor, statement, *args) -> None:  # noqa: ANN001 — сигнатура события SQLAlchemy
        statements.append(statement)

    event.listen(sync_engine, "before_cursor_execute", _record)
    try:
        computed = SystemInterpreter(catalog, InterpretationReasonCollector()).interpret(patient_id, loaded)
    finally:
        event.remove(sync_engine, "before_cursor_execute", _record)

    assert statements == []
    assert [factor.code for factor in computed.interpretations[first_system].risk_factors] == ["rf_ldl_reader"]
