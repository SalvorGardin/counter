"""Пустые наборы кодов у читателя интерпретации не превращаются в запрос с `IN ()`.

Read-метод сначала материализует `Iterable` в список и на пустом отвечает сам. Это не
микрооптимизация: `IN ()` — синтаксическая ошибка Postgres, а SQLAlchemy подставляет вместо
пустого набора заведомо ложное условие, то есть запрос всё равно ушёл бы в БД, чтобы вернуть
пустой результат. Пустой набор здесь штатен — система без инструментов, пациент без ответов.
"""

from collections.abc import Awaitable, Callable

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.interpretation.infra.reader import InterpretationReader

_EMPTY_INPUT_READS: dict[str, Callable[[InterpretationReader], Awaitable[dict | list]]] = {
    "get_results_for_systems": lambda reader: reader.get_results_for_systems("p", []),
}

_EMPTY_RESULT: dict[str, dict | list] = {
    "get_results_for_systems": {},
}


@pytest.mark.parametrize("method_name", sorted(_EMPTY_INPUT_READS))
async def test_empty_codes_short_circuit_without_query(db_session: AsyncSession, method_name: str) -> None:
    """Пустой вход → пустая коллекция того же типа, что и на непустом входе."""
    reader = InterpretationReader(db_session)

    assert await _EMPTY_INPUT_READS[method_name](reader) == _EMPTY_RESULT[method_name]


@pytest.mark.parametrize("method_name", sorted(_EMPTY_INPUT_READS))
async def test_empty_codes_do_not_touch_the_database(
    db_session: AsyncSession, method_name: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Короткое замыкание — до обращения к сессии: запрос не отправляется вовсе."""

    async def _fail(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("пустой набор кодов не должен доходить до запроса")

    monkeypatch.setattr(db_session, "execute", _fail)
    monkeypatch.setattr(db_session, "scalars", _fail)

    await _EMPTY_INPUT_READS[method_name](InterpretationReader(db_session))


async def test_generator_input_is_consumed_once(db_session: AsyncSession) -> None:
    """Вход типизирован как `Iterable`: одноразовый генератор должен обрабатываться корректно.

    Методы материализуют его в список до проверки на пустоту — иначе непустой генератор,
    исчерпанный самой проверкой, дал бы пустой результат на непустом входе.
    """
    reader = InterpretationReader(db_session)

    assert await reader.get_results_for_systems("p", (code for code in ())) == {}
