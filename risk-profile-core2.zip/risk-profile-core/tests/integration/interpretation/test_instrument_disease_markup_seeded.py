"""Целостность разметки групп заболеваний `instruments.diseases` в справочнике после миграций.

Внешним ключом разметку не удержать — PostgreSQL не поддерживает ссылку на элементы массива, — а
справочник инструментов перезаливается сидами из административной панели. Ошибка разметки не роняет
сервис: каталог интерпретации отбрасывает такой код и пишет ошибку в журнал, а группа молча перестаёт
определяться. Поэтому оба правила разметки проверяются здесь, до выпуска:

* код группы есть в `diseases`;
* система группы (`diseases.system_code`) связана с инструментом через `systems_instruments`.
"""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.catalog.interpretation import DISEASE_CODE_SYSTEM_NOT_LINKED, DISEASE_CODE_UNKNOWN
from src.models.disease import Disease
from src.models.instrument import Instrument
from src.models.system_instrument import SystemInstrument
from tests.conftest import make_interpretation_catalog
from tests.factories import Factory


async def test_seeded_disease_codes_exist_in_catalog(db_session: AsyncSession) -> None:
    catalog_codes = set((await db_session.scalars(select(Disease.code))).all())
    rows = (await db_session.execute(select(Instrument.code, Instrument.diseases))).all()

    unknown = sorted(
        (instrument_code, code) for instrument_code, codes in rows for code in codes or () if code not in catalog_codes
    )
    assert unknown == [], f"instruments.diseases содержит коды, которых нет среди diseases.code: {unknown}"


async def test_seeded_disease_systems_are_linked_to_their_instruments(db_session: AsyncSession) -> None:
    disease_rows = (await db_session.execute(select(Disease.code, Disease.system_code))).all()
    disease_systems = {code: system_code for code, system_code in disease_rows}
    links_stmt = select(SystemInstrument.instrument_code, SystemInstrument.system_code)
    links = set((await db_session.execute(links_stmt)).all())
    rows = (await db_session.execute(select(Instrument.code, Instrument.diseases))).all()

    not_linked = sorted(
        (instrument_code, code, disease_systems[code])
        for instrument_code, codes in rows
        for code in codes or ()
        if code in disease_systems and (instrument_code, disease_systems[code]) not in links
    )
    assert not_linked == [], (
        f"система группы не связана с инструментом через systems_instruments (инструмент, код, система): {not_linked}"
    )


async def test_catalog_built_from_seed_rejects_nothing(db_session: AsyncSession) -> None:
    catalog = await make_interpretation_catalog(db_session)

    assert catalog.rejected_disease_codes == ()
    assert catalog.disease_codes_by_system_instrument, "в сиде нет ни одного инструмента с группами заболеваний"


async def test_catalog_rejects_broken_markup(db_session: AsyncSession, factory: Factory) -> None:
    """Проверка не тавтологична: ошибочная разметка в базе действительно даёт отброшенные коды."""
    await factory.instrument_with_params("markup_unknown_t", required=[], system_code="ENDO", type="calc")
    await factory.set_instrument_diseases(instrument_code="markup_unknown_t", diseases=["no_such_disease_group"])
    await factory.instrument_with_params("markup_foreign_t", required=[], system_code="ENDO", type="form")
    await factory.set_instrument_diseases(instrument_code="markup_foreign_t", diseases=["sleep_apnea"])

    catalog = await make_interpretation_catalog(db_session)

    rejected = {(item.instrument_code, item.disease_code, item.cause) for item in catalog.rejected_disease_codes}
    assert rejected == {
        ("markup_unknown_t", "no_such_disease_group", DISEASE_CODE_UNKNOWN),
        ("markup_foreign_t", "sleep_apnea", DISEASE_CODE_SYSTEM_NOT_LINKED),
    }
