"""CalcHandler триггерит InterpretationHandler как продолжение процесса."""

from datetime import timedelta
from unittest.mock import AsyncMock, patch

from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.domain.formula import Formula
from src.calc.domain.models import (
    CalculationRequest,
    FormulaResult,
    InstrumentInput,
    InstrumentsIndicators,
    InstrumentsRiskLevel,
    InstrumentsUnits,
)
from src.calc.handler import CalcHandler
from src.constants import ResultInterpretationStatus
from src.interpretation.handler import InterpretationHandler
from tests.conftest import LogSink, make_calc_catalog, make_interpretation_catalog, open_formula_registry
from tests.factories import Factory


def _always_applicable(self, input: InstrumentInput) -> bool:  # noqa: ARG001
    return True


def _stub_result(self, input: InstrumentInput) -> FormulaResult:  # noqa: ARG001
    return FormulaResult(
        instrument_code=input.instrument_code,
        patient_id=input.patient_id,
        value=0.0,
        unit=InstrumentsUnits.BCRAT,
        risk_level=InstrumentsRiskLevel.LOW,
        applicability=True,
        interpretation_status=ResultInterpretationStatus.READY,
        expiration_delta=timedelta(days=365),
        indicator=InstrumentsIndicators.BCRAT,
    )


async def _setup_calc_instrument(
    session: AsyncSession, factory: Factory, instrument_code: str, param_code: str, system_code: str
) -> str:
    patient_id = await factory.patient()
    await factory.instrument_with_params(instrument_code, required=[param_code], in_system=False)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
    await factory.answer(patient_id=patient_id, parameter_code=param_code, value="v")
    await session.commit()
    return patient_id


async def test_interpretation_called_after_calc(db_session: AsyncSession, factory: Factory) -> None:
    patient_id = await _setup_calc_instrument(db_session, factory, "T_INTERP1", "INTP1_P", "ENDO")

    with (
        # Синтетический код инструмента реестром формул не зарегистрирован — открываем реестр,
        # иначе каталог не отдаст его формульному pipeline и считать будет нечего.
        open_formula_registry(),
        patch.object(Formula, "is_applicable", _always_applicable),
        patch.object(Formula, "calculate", _stub_result),
        patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock, return_value={}) as mock_run,
    ):
        await CalcHandler(
            db_session,
            await make_calc_catalog(db_session),
            interpretation_catalog=await make_interpretation_catalog(db_session),
        ).run([CalculationRequest(patient_id=patient_id)])

    mock_run.assert_awaited_once()
    args, kwargs = mock_run.call_args
    assert args[0] == patient_id
    assert "ENDO" in args[1]
    # Параметры пациента передаются из снимка calc'а, чтобы интерпретация не перечитывала их из БД.
    parameters = kwargs["patient_parameters"]
    assert {code: parameter.value for code, parameter in parameters.items()} == {"INTP1_P": "v"}
    assert parameters["INTP1_P"].patient_parameter_id > 0


async def test_interpretation_deduped_per_system(db_session: AsyncSession, factory: Factory) -> None:
    """Два инструмента одной системы → один вызов run_for с {ENDO}."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("T_DUP_A", required=["DUP_A_P"], in_system=False)
    await factory.instrument_with_params("T_DUP_B", required=["DUP_B_P"], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="T_DUP_A")
    await factory.link_system_instrument(system_code="ENDO", instrument_code="T_DUP_B")
    await factory.answer(patient_id=patient_id, parameter_code="DUP_A_P", value="v")
    await factory.answer(patient_id=patient_id, parameter_code="DUP_B_P", value="v")
    await db_session.commit()

    with (
        # Синтетический код инструмента реестром формул не зарегистрирован — открываем реестр,
        # иначе каталог не отдаст его формульному pipeline и считать будет нечего.
        open_formula_registry(),
        patch.object(Formula, "is_applicable", _always_applicable),
        patch.object(Formula, "calculate", _stub_result),
        patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock, return_value={}) as mock_run,
    ):
        await CalcHandler(
            db_session,
            await make_calc_catalog(db_session),
            interpretation_catalog=await make_interpretation_catalog(db_session),
        ).run([CalculationRequest(patient_id=patient_id)])

    assert mock_run.await_count == 1
    args, _ = mock_run.call_args
    assert args[1] == {"ENDO"}


async def test_interpretation_failure_does_not_break_calc(
    db_session: AsyncSession, factory: Factory, captured_app_logs: LogSink
) -> None:
    """Падение интерпретации не должно ронять весь run(), но обязано логироваться на ERROR."""
    patient_id = await _setup_calc_instrument(db_session, factory, "T_INTERP_FAIL", "INTPF_P", "ENDO")

    with (
        # Синтетический код инструмента реестром формул не зарегистрирован — открываем реестр,
        # иначе каталог не отдаст его формульному pipeline и считать будет нечего.
        open_formula_registry(),
        patch.object(Formula, "is_applicable", _always_applicable),
        patch.object(Formula, "calculate", _stub_result),
        patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock, side_effect=RuntimeError("boom")),
    ):
        await CalcHandler(
            db_session,
            await make_calc_catalog(db_session),
            interpretation_catalog=await make_interpretation_catalog(db_session),
        ).run([CalculationRequest(patient_id=patient_id)])

    assert "calc.interpretation: failed" in captured_app_logs.messages()
    log_context = captured_app_logs.context_of("calc.interpretation: failed")
    assert log_context["patient_id"] == patient_id


async def test_no_successful_upsert_no_interpretation_call(db_session: AsyncSession, factory: Factory) -> None:
    """Если ни один инструмент не отработал (нет параметров пациента), interpretation не вызывается."""
    patient_id = await factory.patient()
    await db_session.commit()

    with patch.object(InterpretationHandler, "run_for", new_callable=AsyncMock) as mock_run:
        await CalcHandler(
            db_session,
            await make_calc_catalog(db_session),
            interpretation_catalog=await make_interpretation_catalog(db_session),
        ).run([CalculationRequest(patient_id=patient_id)])

    mock_run.assert_not_awaited()
