"""Пометка `done` строк по группам заболеваний — по системе группы, а не по инструменту."""

from datetime import UTC, datetime, timedelta
from typing import Any
from unittest.mock import patch

import pytest
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import AsyncSession

from src.exceptions import NonRetriableDbError, RetriableDbError
from src.infra.db_retry import TransactionalRetryExecutor
from src.interpretation.infra.repository import InterpretationRepository
from tests.consts import BIOMARKER_CLINREC_INSTRUMENT_CODE
from tests.factories import Factory
from tests.integration.interpretation.conftest import InterpretationHandlerFactory

BIOMARKER_KR = BIOMARKER_CLINREC_INSTRUMENT_CODE


async def _statuses(session: AsyncSession, patient_id: str) -> dict[str, str]:
    rows = await session.execute(
        text(
            "SELECT disease_code, interpretation_status FROM results WHERE patient_id = :pid AND instrument_code = :i"
        ),
        {"pid": patient_id, "i": BIOMARKER_KR},
    )
    return {row.disease_code: row.interpretation_status for row in rows.all()}


@pytest.fixture
async def two_systems(db_session: AsyncSession, factory: Factory) -> dict[str, str]:
    """Две системы, по группе заболеваний в каждой и по строке результата на группу."""
    patient_id = await factory.patient()
    first_system = await factory.system()
    second_system = await factory.system()
    await factory.biomarker_clinrec_instrument()
    await factory.link_system_instrument(system_code=first_system, instrument_code=BIOMARKER_KR)
    await factory.link_system_instrument(system_code=second_system, instrument_code=BIOMARKER_KR)
    first_disease = await factory.disease(system_code=first_system)
    second_disease = await factory.disease(system_code=second_system)
    for disease_code in (first_disease, second_disease):
        await factory.result(
            patient_id=patient_id,
            instrument_code=BIOMARKER_KR,
            disease_code=disease_code,
            risk_level="high",
            interpretation_status="ready",
        )
    await db_session.commit()
    return {
        "patient_id": patient_id,
        "first_system": first_system,
        "second_system": second_system,
        "first_disease": first_disease,
        "second_disease": second_disease,
    }


async def test_batch_success_marks_rows_of_written_systems(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    handler = await interpretation_handler()

    await handler.run_for(two_systems["patient_id"], [two_systems["first_system"], two_systems["second_system"]])

    assert await _statuses(db_session, two_systems["patient_id"]) == {
        two_systems["first_disease"]: "done",
        two_systems["second_disease"]: "done",
    }


async def test_system_outside_the_run_keeps_its_row_ready(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    handler = await interpretation_handler()

    await handler.run_for(two_systems["patient_id"], [two_systems["first_system"]])

    statuses = await _statuses(db_session, two_systems["patient_id"])
    assert statuses[two_systems["first_disease"]] == "done"
    # Инструмент связан и со второй системой, но её группа в этот прогон не входила.
    assert statuses[two_systems["second_disease"]] == "ready"


async def test_biomarker_mark_does_not_touch_other_instrument_with_disease_code(
    db_session: AsyncSession, factory: Factory, two_systems: dict[str, str]
) -> None:
    ordinary = await factory.instrument_with_params("ORD_DONE_SCOPE", required=[], in_system=False)
    await factory.result(
        patient_id=two_systems["patient_id"],
        instrument_code=ordinary,
        disease_code=two_systems["first_disease"],
        risk_level="medium",
        interpretation_status="ready",
    )
    await db_session.commit()

    await InterpretationRepository(db_session).mark_biomarker_results_done(
        patient_id=two_systems["patient_id"],
        system_codes=[two_systems["first_system"]],
        results_cutoff=datetime.now(tz=UTC),
    )
    await db_session.commit()

    status = await db_session.scalar(
        text("SELECT interpretation_status FROM results WHERE patient_id = :pid AND instrument_code = :instrument"),
        {"pid": two_systems["patient_id"], "instrument": ordinary},
    )
    assert status == "ready"


async def test_row_newer_than_cutoff_is_not_marked(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    """Строка, записанная параллельным расчётом уже после снимка, этим прогоном не закрывается."""
    await db_session.execute(
        text("UPDATE results SET date_time = :dt WHERE patient_id = :pid AND disease_code = :d"),
        {
            "dt": datetime.now(tz=UTC) + timedelta(minutes=5),
            "pid": two_systems["patient_id"],
            "d": two_systems["first_disease"],
        },
    )
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(two_systems["patient_id"], [two_systems["first_system"]])

    assert (await _statuses(db_session, two_systems["patient_id"]))[two_systems["first_disease"]] == "ready"


async def test_partial_success_of_the_degraded_path(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    """Пачка откатилась, одна система упала: её группа остаётся `ready`, вторая помечается."""
    failing_system = two_systems["second_system"]

    async def _batch_boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
        raise OperationalError("batch", {}, Exception("simulated batch failure"))

    real_upsert = InterpretationRepository.upsert_interpretation

    async def _one_system_boom(self: InterpretationRepository, **kwargs: Any) -> None:
        if kwargs["system_code"] == failing_system:
            raise OperationalError("system", {}, Exception("simulated system failure"))
        await real_upsert(self, **kwargs)

    handler = await interpretation_handler()
    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", _one_system_boom),
        patch("src.infra.db_retry.asyncio.sleep", new=lambda *_: _noop()),
    ):
        await handler.run_for(two_systems["patient_id"], [two_systems["first_system"], failing_system])

    statuses = await _statuses(db_session, two_systems["patient_id"])
    assert statuses[two_systems["first_disease"]] == "done"
    assert statuses[two_systems["second_disease"]] == "ready"


async def _noop() -> None:
    return None


async def test_transient_mark_failure_is_swallowed(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    """Транзиентный сбой пометки не роняет прогон: строки остаются `ready` до следующего раза."""
    real_run = TransactionalRetryExecutor.run

    async def patched_run(self: TransactionalRetryExecutor, op: Any, *args: Any, **kwargs: Any) -> Any:
        # Executor классифицирует сбой сам, поэтому подменяем уже классифицированный:
        # транзиентный роняет пачку (прогон деградирует) и затем саму пометку.
        if op.__name__ == "upsert_interpretations_batch":
            raise RetriableDbError("batch failed", cause=RuntimeError("boom"), attempts=3)
        if op.__name__ == "_mark_both":
            raise RetriableDbError("retries exhausted", cause=RuntimeError("boom"), attempts=3)
        return await real_run(self, op, *args, **kwargs)

    handler = await interpretation_handler()
    with (
        patch.object(TransactionalRetryExecutor, "run", patched_run),
        patch("src.infra.db_retry.asyncio.sleep", new=lambda *_: _noop()),
    ):
        await handler.run_for(two_systems["patient_id"], [two_systems["first_system"]])

    assert (await _statuses(db_session, two_systems["patient_id"]))[two_systems["first_disease"]] == "ready"


async def test_permanent_mark_failure_propagates(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, two_systems: dict[str, str]
) -> None:
    real_run = TransactionalRetryExecutor.run

    async def patched_run(self: TransactionalRetryExecutor, op: Any, *args: Any, **kwargs: Any) -> Any:
        if op.__name__ == "upsert_interpretations_batch":
            raise RetriableDbError("batch failed", cause=RuntimeError("boom"), attempts=3)
        if op.__name__ == "_mark_both":
            raise NonRetriableDbError("permanent mark failure", cause=RuntimeError("boom"), attempts=1)
        return await real_run(self, op, *args, **kwargs)

    handler = await interpretation_handler()
    with (
        patch.object(TransactionalRetryExecutor, "run", patched_run),
        patch("src.infra.db_retry.asyncio.sleep", new=lambda *_: _noop()),
        pytest.raises(NonRetriableDbError),
    ):
        await handler.run_for(two_systems["patient_id"], [two_systems["first_system"]])
