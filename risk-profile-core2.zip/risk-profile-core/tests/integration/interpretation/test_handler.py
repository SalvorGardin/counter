"""InterpretationHandler.run_for — end-to-end через реальную БД."""

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any
from unittest.mock import patch

import pytest
from sqlalchemy import select, text, update
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.ext.asyncio import AsyncSession

from src.exceptions import NonRetriableDbError, RetriableDbError
from src.infra.db_retry import TransactionalRetryExecutor
from src.infra.patients.dtos import ActiveParameter
from src.interpretation import persistence as persistence_module
from src.interpretation.infra.repository import InterpretationRepository
from src.models.interpretation import Interpretation
from src.models.interpretation_history import InterpretationHistory
from src.models.result import Result
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_GENDER
from tests.factories import Factory
from tests.integration.interpretation.conftest import InterpretationHandlerFactory


def _transient_db_error(label: str) -> OperationalError:
    """Сбой из `DEFAULT_RETRIABLE` — executor классифицирует его как `RetriableDbError`.

    Деградация на посистемную запись рассчитана ровно на транзиентный сбой: перманентный
    (`NonRetriableDbError`) проходит наружу и обрывает прогон пациента. Поэтому «уронить запись»
    в тестах деградации обязано быть транзиентным — на любом другом исключении executor выдал бы
    NonRetriable, и тест проверял бы обрыв прогона, а не то, ради чего написан.
    """
    return OperationalError(label, {}, Exception(label))


async def _batch_boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
    """Роняет батч-запись транзиентно, заставляя `run_for` деградировать на per-system путь.

    Штатно все системы пациента пишутся одной транзакцией (`upsert_interpretations_batch`),
    и партиальных отказов там быть не может — пачка либо вся прошла, либо вся откатилась.
    Гарантию «одна упавшая система не блокирует остальные» даёт fallback, поэтому тесты
    этой гарантии сначала роняют пачку.
    """
    raise _transient_db_error("simulated batch failure")


async def test_run_for_empty_systems(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    handler = await interpretation_handler()

    result = await handler.run_for(patient_id, [])

    assert result == {}


async def test_run_for_no_results_yields_null_level(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Если у пациента в системе вообще нет результатов, risk_level=null, diseases=null, risk_factors=[]."""
    patient_id = await factory.patient()
    handler = await interpretation_handler()

    result = await handler.run_for(patient_id, ["ENDO"])

    assert "ENDO" in result
    assert result["ENDO"].risk_level is None
    assert result["ENDO"].diseases is None
    assert result["ENDO"].risk_factors == []


async def test_endo_disease_diabetes_with_high_risk(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    await factory.instrument_with_params("findrisk_t", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="findrisk_t", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="findrisk_t")
    await factory.result(patient_id=patient_id, instrument_code="findrisk_t", risk_level="high")

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    assert result["ENDO"].risk_level == "high"
    assert result["ENDO"].diseases == ["diabetes_mellitus"]


async def test_other_significant_risk_does_not_exclude_confirmed_group(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Инструмент ENDO без групп с высоким риском не обнуляет диабет, подтверждённый findrisk."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("findrisk_other", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="findrisk_other", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="findrisk_other")
    await factory.result(patient_id=patient_id, instrument_code="findrisk_other", risk_level="medium")
    await factory.instrument_with_params("form_endo_other", required=[], in_system=False, type="form")
    await factory.link_system_instrument(system_code="ENDO", instrument_code="form_endo_other")
    await factory.result(patient_id=patient_id, instrument_code="form_endo_other", risk_level="high")

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    assert result["ENDO"].risk_level == "high"
    assert result["ENDO"].diseases == ["diabetes_mellitus"]


async def test_low_risk_skips_risk_factors(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_low", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_low")
    await factory.result(patient_id=patient_id, instrument_code="instr_low", risk_level="low")

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    assert result["ENDO"].risk_level == "low"
    assert result["ENDO"].risk_factors == []


async def test_high_risk_with_risk_factors_ranked(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Полный pipeline: §4.1 high → §4.3 ранжирование по score DESC."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_t", required=["smoking_t", "bmi_t"], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_t")
    await factory.result(patient_id=patient_id, instrument_code="instr_t", risk_level="high")

    await factory.answer(patient_id=patient_id, parameter_code="smoking_t", value="yes")
    await factory.answer(patient_id=patient_id, parameter_code="bmi_t", value="32")

    rf_smoke = await factory.risk_factor("rf_smoke", parameter_code="smoking_t", system_code="ENDO", param_value="yes")
    rf_bmi = await factory.risk_factor(
        "rf_bmi", parameter_code="bmi_t", system_code="ENDO", min_param_value="30", max_param_value="100"
    )

    await factory.parameter_score(parameter_code="smoking_t", system_code="ENDO", value="yes", score=Decimal("2"))
    await factory.parameter_score(
        parameter_code="bmi_t",
        system_code="ENDO",
        min_value=Decimal("30"),
        max_value=Decimal("100"),
        score=Decimal("5"),
    )

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    factors = result["ENDO"].risk_factors
    assert [f.code for f in factors] == ["rf_bmi", "rf_smoke"], "score DESC: bmi(5) > smoke(2)"
    assert factors[0].risk_factor_id == rf_bmi.risk_factor_id
    assert factors[1].risk_factor_id == rf_smoke.risk_factor_id


async def test_skipped_system_diseases_null(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Система не в §4.2 (например GI) → diseases=None даже при высоком risk_level."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("form_gi_t", required=[], in_system=False)
    await factory.link_system_instrument(system_code="GI", instrument_code="form_gi_t")
    await factory.result(patient_id=patient_id, instrument_code="form_gi_t", risk_level="high")

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["GI"])

    assert result["GI"].risk_level == "high"
    assert result["GI"].diseases is None


async def test_inapplicable_a_instrument_does_not_trigger_disease(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    patient_id = await factory.patient()
    await factory.instrument_with_params("findrisk_t2", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="findrisk_t2", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="findrisk_t2")
    await factory.result(patient_id=patient_id, instrument_code="findrisk_t2", risk_level="high", applicability=False)

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    assert result["ENDO"].risk_level is None
    assert result["ENDO"].diseases is None


async def test_persists_interpretation_row(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Bug #54: run_for сохраняет запись в interpretations + history."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("findrisk_persist", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="findrisk_persist", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="findrisk_persist")
    await factory.result(patient_id=patient_id, instrument_code="findrisk_persist", risk_level="high")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    row = await db_session.scalar(
        select(Interpretation).where(
            Interpretation.patient_id == patient_id,
            Interpretation.system_code == "ENDO",
        )
    )
    assert row is not None
    assert row.risk_level == "high"
    assert row.diseases == ["diabetes_mellitus"]
    assert row.date_time is not None
    assert row.text is None
    # §4.4: ENDO@high → Эндокринолог (код 41 в catalog/0039 doctors + 0080 recommended_doctors).
    assert row.doctors_code == ["41"]

    history_count = len(
        (
            await db_session.scalars(
                select(InterpretationHistory).where(
                    InterpretationHistory.patient_id == patient_id,
                    InterpretationHistory.system_code == "ENDO",
                )
            )
        ).all()
    )
    assert history_count == 1, "первый прогон должен оставить ровно одну history-запись"


async def test_persists_null_level_when_no_results(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Система без результатов всё равно фиксируется как «прогнали, данных нет»."""
    patient_id = await factory.patient()
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    row = await db_session.scalar(
        select(Interpretation).where(
            Interpretation.patient_id == patient_id,
            Interpretation.system_code == "ENDO",
        )
    )
    assert row is not None
    assert row.risk_level is None
    assert row.diseases is None
    assert row.risk_factors_code is None


async def test_one_system_upsert_failure_does_not_block_others(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Если upsert падает на одной системе, остальные всё равно сохраняются."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_partial_a", required=[], in_system=False)
    await factory.instrument_with_params("instr_partial_b", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_partial_a")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_partial_b")
    await factory.result(patient_id=patient_id, instrument_code="instr_partial_a", risk_level="high")
    await factory.result(patient_id=patient_id, instrument_code="instr_partial_b", risk_level="high")
    await db_session.commit()

    real_upsert = InterpretationRepository.upsert_interpretation

    async def flaky_upsert(self: InterpretationRepository, *, system_code: str, **kwargs: Any) -> None:
        if system_code == "ENDO":
            raise _transient_db_error("simulated db failure on ENDO")
        await real_upsert(self, system_code=system_code, **kwargs)

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", flaky_upsert),
        patch.object(persistence_module.logger, "error") as mock_err,
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO", "GI"])

    assert any(
        c.args
        and c.args[0] == "interpretation.system: upsert failed"
        and c.kwargs["extra"]["log_context"]["system_code"] == "ENDO"
        for c in mock_err.call_args_list
    ), "падение upsert по ENDO должно быть залогировано"

    endo_row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "ENDO")
    )
    assert endo_row is None, "ENDO упала — записи быть не должно"

    # history тоже должна откатиться вместе с основной записью: history.add() и
    # ON CONFLICT-insert живут в одной session.begin() в репозитории. Если эта связка
    # когда-нибудь распадётся, тест поймает leak до того, как баг доедет до прода.
    endo_history = (
        await db_session.scalars(
            select(InterpretationHistory).where(
                InterpretationHistory.patient_id == patient_id,
                InterpretationHistory.system_code == "ENDO",
            )
        )
    ).all()
    assert len(endo_history) == 0, "откат ENDO не должен оставлять history-записи"

    gi_row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "GI")
    )
    assert gi_row is not None
    assert gi_row.risk_level == "high"


async def test_text_preserved_but_doctors_refreshed_on_rerun(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """ON CONFLICT не трогает `text` (§4.5, другой маршрут), но обновляет `doctors_code` (§4.4 in-run)."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_preserve", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_preserve")
    await factory.result(patient_id=patient_id, instrument_code="instr_preserve", risk_level="high")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    # Симулируем §4.5 (text) и постороннюю запись doctors_code напрямую в БД.
    await db_session.execute(
        update(Interpretation)
        .where(Interpretation.patient_id == patient_id, Interpretation.system_code == "ENDO")
        .values(text="some clinical description", doctors_code=["12"])
    )
    await db_session.commit()

    # Перезапуск: text остаётся нетронутым, doctors_code пересчитывается §4.4 (ENDO@high → 41).
    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "ENDO")
    )
    assert row is not None
    assert row.text == "some clinical description"
    assert row.doctors_code == ["41"]
    assert row.risk_level == "high"


async def test_rerun_updates_existing_row_and_grows_history(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Повторный прогон по той же (patient, system) — UPDATE основной, +1 history."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_rerun", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="instr_rerun", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_rerun")
    await factory.result(patient_id=patient_id, instrument_code="instr_rerun", risk_level="high")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])
    await handler.run_for(patient_id, ["ENDO"])

    rows = (
        await db_session.scalars(
            select(Interpretation).where(
                Interpretation.patient_id == patient_id,
                Interpretation.system_code == "ENDO",
            )
        )
    ).all()
    assert len(rows) == 1, "uq_interpretations_patient_id_system_code должен схлопывать в одну строку"
    assert rows[0].risk_level == "high"

    history_rows = (
        await db_session.scalars(
            select(InterpretationHistory).where(
                InterpretationHistory.patient_id == patient_id,
                InterpretationHistory.system_code == "ENDO",
            )
        )
    ).all()
    assert len(history_rows) == 2, "каждый прогон должен дописывать в history"


async def test_expired_results_are_ignored(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Старая запись results с истёкшим expiration_date не должна попадать в §4.1/4.2."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_exp", required=[], in_system=False)
    await factory.set_instrument_diseases(instrument_code="instr_exp", diseases=["diabetes_mellitus"])
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_exp")
    yesterday = datetime.now(tz=UTC) - timedelta(days=1)
    await factory.result(
        patient_id=patient_id, instrument_code="instr_exp", risk_level="high", expiration_date=yesterday
    )

    handler = await interpretation_handler()
    result = await handler.run_for(patient_id, ["ENDO"])

    assert result["ENDO"].risk_level is None
    assert result["ENDO"].diseases is None


# ── interpretation_status: ready → done (bug #64) ────────────────────────────


async def _get_result_status(session: AsyncSession, patient_id: str, instrument_code: str) -> str | None:
    row = await session.execute(
        select(Result.interpretation_status).where(
            Result.patient_id == patient_id,
            Result.instrument_code == instrument_code,
        )
    )
    return row.scalar_one_or_none()


async def test_ready_results_become_done_after_interpretation(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Bug #64: после успешной интерпретации `results.interpretation_status` → 'done'."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_done_a", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_done_a")
    await factory.result(patient_id=patient_id, instrument_code="instr_done_a", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_done_a") == "done"


async def test_not_required_results_are_not_touched(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """`not_required` ставит сама формула (`make_dummy`) — интерпретация не должна перетирать его в done."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_nr", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_nr")
    await factory.result(
        patient_id=patient_id,
        instrument_code="instr_nr",
        risk_level=None,
        applicability=False,
        interpretation_status="not_required",
    )
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_nr") == "not_required"


async def test_other_patients_results_are_not_touched(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """UPDATE должен фильтровать по patient_id — соседний пациент не страдает."""
    patient_id = await factory.patient()
    other_patient_id = await factory.patient()
    await factory.instrument_with_params("instr_iso", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_iso")
    await factory.result(patient_id=patient_id, instrument_code="instr_iso", risk_level="low")
    await factory.result(patient_id=other_patient_id, instrument_code="instr_iso", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_iso") == "done"
    assert await _get_result_status(db_session, other_patient_id, "instr_iso") == "ready"


async def test_results_from_other_systems_are_not_touched(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """run_for(patient, ['ENDO']) не должен трогать results другого system_code."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_endo_only", required=[], in_system=False)
    await factory.instrument_with_params("instr_gi_only", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_endo_only")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_gi_only")
    await factory.result(patient_id=patient_id, instrument_code="instr_endo_only", risk_level="low")
    await factory.result(patient_id=patient_id, instrument_code="instr_gi_only", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_endo_only") == "done"
    assert await _get_result_status(db_session, patient_id, "instr_gi_only") == "ready"


async def test_results_written_after_cutoff_stay_ready(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Гонка: запись, обновлённая после старта interpretation, не должна помечаться done.

    Симулируем concurrent calc через patched datetime: handler видит результат с date_time
    позже своего cutoff и обязан оставить его в `ready`. Следующий прогон interpretation
    подхватит и пометит — так инвариант «done = реально учтено в interpretation» сохраняется.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_race", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_race")
    # Запись датируется будущим: с точки зрения handler это «calc, случившийся после нашего cutoff».
    future = datetime.now(tz=UTC) + timedelta(hours=1)
    await factory.result(
        patient_id=patient_id,
        instrument_code="instr_race",
        risk_level="low",
        expiration_date=future + timedelta(days=30),
        date_time=future,
    )
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    # Cutoff = "now" в начале run_for — он меньше date_time будущей записи,
    # поэтому UPDATE по условию `date_time <= cutoff` не должен задеть запись.
    assert await _get_result_status(db_session, patient_id, "instr_race") == "ready"


async def test_repeated_run_keeps_done_status(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Идемпотентность: повторный run_for оставляет уже-`done` как `done`."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_idem", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_idem")
    await factory.result(patient_id=patient_id, instrument_code="instr_idem", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_idem") == "done"


async def test_upsert_failure_skips_mark_done(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Если upsert_interpretation для системы упал, инструменты этой системы не помечаются `done`.

    Архитектурно: phase 2 не добавляет систему в `succeeded_systems`, phase 3 фильтрует
    инструмент по subset-условию → пропускает. Тест проверяет, что error логируется и
    статус результата остаётся `ready` (mark не выполнялся).
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_tx_fail", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_tx_fail")
    await factory.result(patient_id=patient_id, instrument_code="instr_tx_fail", risk_level="low")
    await db_session.commit()

    async def boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
        raise _transient_db_error("simulated upsert failure")

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", boom),
        patch.object(persistence_module.logger, "error") as mock_err,
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO"])

    assert any(c.args and c.args[0] == "interpretation.system: upsert failed" for c in mock_err.call_args_list), (
        "падение upsert должно быть залогировано через logger.error"
    )
    assert await _get_result_status(db_session, patient_id, "instr_tx_fail") == "ready"


async def test_partial_failure_marks_only_succeeded_systems(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Один system падает на upsert — её results остаются ready; results другой системы помечены done."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_partial_fail", required=[], in_system=False)
    await factory.instrument_with_params("instr_partial_ok", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_partial_fail")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_partial_ok")
    await factory.result(patient_id=patient_id, instrument_code="instr_partial_fail", risk_level="low")
    await factory.result(patient_id=patient_id, instrument_code="instr_partial_ok", risk_level="low")
    await db_session.commit()

    real_upsert = InterpretationRepository.upsert_interpretation

    async def flaky(self: InterpretationRepository, *, system_code: str, **kwargs: Any) -> None:
        if system_code == "ENDO":
            raise _transient_db_error("simulated upsert failure")
        await real_upsert(self, system_code=system_code, **kwargs)

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", flaky),
        patch.object(persistence_module.logger, "error"),
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO", "GI"])

    assert await _get_result_status(db_session, patient_id, "instr_partial_fail") == "ready"
    assert await _get_result_status(db_session, patient_id, "instr_partial_ok") == "done"


async def test_run_for_returns_only_persisted_systems(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Система, которую посчитали, но не записали, из возврата исключается.

    По возврату вызывающий публикует команду `interpretation` (см. CalcHandler._publish_interpretation),
    а она обещает потребителю строку в `interpretations`. Непосаженная система в этом обещании
    отправила бы потребителя читать прошлую интерпретацию или пустоту.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_ret_fail", required=[], in_system=False)
    await factory.instrument_with_params("instr_ret_ok", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_ret_fail")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_ret_ok")
    await factory.result(patient_id=patient_id, instrument_code="instr_ret_fail", risk_level="low")
    await factory.result(patient_id=patient_id, instrument_code="instr_ret_ok", risk_level="low")
    await db_session.commit()

    real_upsert = InterpretationRepository.upsert_interpretation

    async def flaky(self: InterpretationRepository, *, system_code: str, **kwargs: Any) -> None:
        if system_code == "ENDO":
            raise _transient_db_error("simulated upsert failure")
        await real_upsert(self, system_code=system_code, **kwargs)

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", flaky),
        patch.object(persistence_module.logger, "error"),
    ):
        handler = await interpretation_handler()
        returned = await handler.run_for(patient_id, ["ENDO", "GI"])

    assert set(returned) == {"GI"}, "ENDO посчитана, но не записана — в возврате её быть не должно"


async def test_all_systems_failing_returns_nothing(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Не записалась ни одна система — возврат пуст, и вызывающему нечего публиковать."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_none_ok", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_none_ok")
    await factory.result(patient_id=patient_id, instrument_code="instr_none_ok", risk_level="low")
    await db_session.commit()

    async def boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
        raise _transient_db_error("simulated upsert failure")

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", boom),
        patch.object(persistence_module.logger, "error"),
    ):
        handler = await interpretation_handler()
        returned = await handler.run_for(patient_id, ["ENDO"])

    assert returned == {}
    assert await _get_result_status(db_session, patient_id, "instr_none_ok") == "ready"


async def test_non_retriable_batch_failure_propagates(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Перманентный сбой пачки не деградирует на посистемную запись, а обрывает прогон пациента.

    Посистемный путь повторил бы ту же перманентную ошибку на каждой системе и выдал бы её за
    транзиентный промах; такой сбой (schema/constraint/permission) обязан подняться к вызывающему.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_nr_batch", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_nr_batch")
    await factory.result(patient_id=patient_id, instrument_code="instr_nr_batch", risk_level="low")
    await db_session.commit()

    per_system_calls = {"n": 0}
    real_upsert = InterpretationRepository.upsert_interpretation

    async def counting_upsert(self: InterpretationRepository, **kwargs: Any) -> None:
        per_system_calls["n"] += 1
        await real_upsert(self, **kwargs)

    async def permanent_boom(self: InterpretationRepository, **kwargs: Any) -> None:  # noqa: ARG001
        raise IntegrityError("stmt", {}, Exception("constraint"))

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", permanent_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", counting_upsert),
        pytest.raises(NonRetriableDbError),
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO"])

    assert per_system_calls["n"] == 0, "деградация на посистемную запись — только для транзиентного сбоя"
    assert await _get_result_status(db_session, patient_id, "instr_nr_batch") == "ready"


async def test_no_results_for_system_skips_update(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Система без results — interpretation всё равно сохраняется (null risk_level), UPDATE — no-op."""
    patient_id = await factory.patient()
    await db_session.commit()

    # Сторонний результат вне системы — убеждаемся, что mark с пустыми instrument_codes
    # не делает widespread UPDATE.
    await factory.instrument_with_params("instr_outside", required=[], in_system=False)
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_outside")
    await factory.result(patient_id=patient_id, instrument_code="instr_outside", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    assert await _get_result_status(db_session, patient_id, "instr_outside") == "ready"


async def test_shared_instrument_with_one_failing_system_stays_ready(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Инструмент, привязанный к нескольким системам — если хотя бы одна из них упала, его results
    остаются `ready`. Иначе мы потеряем сигнал «interpretation для упавшей системы не записан»:
    следующий прогон не сможет различить «всё ок» от «system X ещё не интерпретирована».
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_shared", required=[], in_system=False)
    await factory.instrument_with_params("instr_only_gi", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_shared")
    await factory.link_system_instrument(
        system_code="GI", instrument_code="instr_shared"
    )  # один инструмент → две системы
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_only_gi")  # этот только в GI
    await factory.result(patient_id=patient_id, instrument_code="instr_shared", risk_level="low")
    await factory.result(patient_id=patient_id, instrument_code="instr_only_gi", risk_level="low")
    await db_session.commit()

    real_upsert = InterpretationRepository.upsert_interpretation

    async def flaky(self: InterpretationRepository, *, system_code: str, **kwargs: Any) -> None:
        if system_code == "ENDO":
            raise _transient_db_error("ENDO upsert fails")
        await real_upsert(self, system_code=system_code, **kwargs)

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(InterpretationRepository, "upsert_interpretation", flaky),
        patch.object(persistence_module.logger, "error"),
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO", "GI"])

    # ENDO упала → instr_shared (∈ {ENDO, GI}) не полностью покрыт → ready
    assert await _get_result_status(db_session, patient_id, "instr_shared") == "ready"
    # instr_only_gi принадлежит только GI, а GI успешно отработала → done
    assert await _get_result_status(db_session, patient_id, "instr_only_gi") == "done"


async def test_batch_failure_falls_back_and_persists_all_systems(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Если батч-запись откатилась, run_for дописывает системы по одной — результат тот же.

    Проверяем именно деградацию: интерпретации всех систем на месте и результаты помечены
    `done`, хотя быстрый путь (одна транзакция на пациента) не отработал.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_fb_a", required=[], in_system=False)
    await factory.instrument_with_params("instr_fb_b", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_fb_a")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_fb_b")
    await factory.result(patient_id=patient_id, instrument_code="instr_fb_a", risk_level="high")
    await factory.result(patient_id=patient_id, instrument_code="instr_fb_b", risk_level="low")
    await db_session.commit()

    with (
        patch.object(InterpretationRepository, "upsert_interpretations_batch", _batch_boom),
        patch.object(persistence_module.logger, "error") as mock_err,
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO", "GI"])

    assert any(
        c.args and c.args[0] == "interpretation.upsert_batch: failed, falling back to per-system writes"
        for c in mock_err.call_args_list
    ), "откат пачки должен быть залогирован"

    rows = {
        row.system_code: row
        for row in (
            await db_session.scalars(select(Interpretation).where(Interpretation.patient_id == patient_id))
        ).all()
    }
    assert set(rows) == {"ENDO", "GI"}
    assert rows["ENDO"].risk_level == "high"
    assert rows["GI"].risk_level == "low"
    assert await _get_result_status(db_session, patient_id, "instr_fb_a") == "done"
    assert await _get_result_status(db_session, patient_id, "instr_fb_b") == "done"


async def test_shared_instrument_marked_done_when_all_its_systems_succeed(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Обратный случай: инструмент в нескольких системах, ВСЕ успешны → done."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_shared_ok", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_shared_ok")
    await factory.link_system_instrument(system_code="GI", instrument_code="instr_shared_ok")
    await factory.result(patient_id=patient_id, instrument_code="instr_shared_ok", risk_level="low")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO", "GI"])

    assert await _get_result_status(db_session, patient_id, "instr_shared_ok") == "done"


async def test_retriable_mark_done_failure_is_logged_and_swallowed(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """RetriableDbError из mark_results_done логируется и не пробрасывается из run_for.

    Патчим `TransactionalRetryExecutor.run` напрямую, чтобы поднять `RetriableDbError`
    без 3× retry с backoff (executor оборачивает всё, что не в DEFAULT_RETRIABLE, как
    NonRetriable — поэтому raise RetriableDbError из op'а не сработал бы). Сценарий —
    «исчерпали повторы»: handler логирует и оставляет результат `ready`, чтобы следующий
    прогон попробовал снова.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_mark_fail", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_mark_fail")
    await factory.result(patient_id=patient_id, instrument_code="instr_mark_fail", risk_level="low")
    await db_session.commit()

    real_run = TransactionalRetryExecutor.run

    async def patched_run(self, op, *args, **kwargs):
        # Пачка пишет интерпретации и помечает результаты в одной транзакции, поэтому отдельная
        # фаза mark_results_done живёт только на fallback-пути — роняем пачку, чтобы туда попасть.
        if op.__name__ == "upsert_interpretations_batch":
            raise RetriableDbError("batch failed", cause=RuntimeError("boom"), attempts=3)
        # Пометка `done` на пути деградации идёт одной транзакцией по обоим отборам —
        # по инструментам и по системам групп заболеваний (см. InterpretationWriter._mark_both).
        if op.__name__ == "_mark_both":
            raise RetriableDbError("retries exhausted", cause=RuntimeError("boom"), attempts=3)
        return await real_run(self, op, *args, **kwargs)

    with (
        patch.object(TransactionalRetryExecutor, "run", patched_run),
        patch.object(persistence_module.logger, "error") as mock_err,
    ):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO"])

    mark_done_logs = [
        c for c in mock_err.call_args_list if c.args and c.args[0] == "interpretation.mark_results_done: failed"
    ]
    assert mark_done_logs, "падение mark_results_done должно быть залогировано через logger.error"
    log_context = mark_done_logs[0].kwargs["extra"]["log_context"]
    assert log_context["patient_id"] == patient_id
    assert log_context["instrument_count"] == 1
    assert log_context["attempts"] == 3
    # Интерпретация записана успешно, статус остался ready (mark упал)
    assert await _get_result_status(db_session, patient_id, "instr_mark_fail") == "ready"


async def test_non_retriable_mark_done_failure_propagates(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """NonRetriableDbError из mark_results_done намеренно не ловится в handler — это перманентный
    баг (schema/constraint/permission), который должен подняться выше для видимости операторам.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_mark_nr", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_mark_nr")
    await factory.result(patient_id=patient_id, instrument_code="instr_mark_nr", risk_level="low")
    await db_session.commit()

    real_run = TransactionalRetryExecutor.run

    async def patched_run(self, op, *args, **kwargs):
        # Как и выше: отдельная фаза mark_results_done есть только на fallback-пути.
        if op.__name__ == "upsert_interpretations_batch":
            raise RetriableDbError("batch failed", cause=RuntimeError("boom"), attempts=3)
        # Пометка `done` на пути деградации идёт одной транзакцией по обоим отборам —
        # по инструментам и по системам групп заболеваний (см. InterpretationWriter._mark_both).
        if op.__name__ == "_mark_both":
            raise NonRetriableDbError("schema mismatch", cause=RuntimeError("permanent"), attempts=1)
        return await real_run(self, op, *args, **kwargs)

    with patch.object(TransactionalRetryExecutor, "run", patched_run), pytest.raises(NonRetriableDbError):
        handler = await interpretation_handler()
        await handler.run_for(patient_id, ["ENDO"])


async def test_history_not_touched_by_mark_done(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """results_history фиксирует только calc-события; mark_results_done в неё не пишет."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_hist", required=[], in_system=False)
    await factory.link_system_instrument(system_code="ENDO", instrument_code="instr_hist")
    await factory.result(patient_id=patient_id, instrument_code="instr_hist", risk_level="low")
    await db_session.commit()

    initial_count = await db_session.scalar(
        text("SELECT COUNT(*) FROM results_history WHERE patient_id = :pid"), {"pid": patient_id}
    )

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["ENDO"])

    final_count = await db_session.scalar(
        text("SELECT COUNT(*) FROM results_history WHERE patient_id = :pid"), {"pid": patient_id}
    )
    assert final_count == initial_count, "mark_results_done не должен трогать results_history"


async def test_reprod_doctor_by_gender(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """§4.4 REPROD: пол определяет специалиста (Женский → Гинеколог 19, Мужской → Уролог 35)."""
    female_id = await factory.patient()
    male_id = await factory.patient()
    await factory.instrument_with_params("instr_reprod", required=[], in_system=False)
    await factory.link_system_instrument(system_code="REPROD", instrument_code="instr_reprod")
    await factory.result(patient_id=female_id, instrument_code="instr_reprod", risk_level="high")
    await factory.result(patient_id=male_id, instrument_code="instr_reprod", risk_level="high")
    await factory.answer(patient_id=female_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_FEMALE)
    await factory.answer(patient_id=male_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_MALE)
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(female_id, ["REPROD"])
    handler = await interpretation_handler()
    await handler.run_for(male_id, ["REPROD"])

    female_row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == female_id, Interpretation.system_code == "REPROD")
    )
    male_row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == male_id, Interpretation.system_code == "REPROD")
    )
    assert female_row is not None and female_row.doctors_code == ["19"]
    assert male_row is not None and male_row.doctors_code == ["35"]


async def test_passed_patient_parameters_replace_the_active_params_read(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Снимок от calc'а используется вместо чтения `get_active_parameters`.

    Пол берётся из переданного словаря, а не из БД: сидим «Женский», передаём «Мужской» и ждём
    уролога. Так же ловится и обратное — что чтение из БД действительно НЕ выполняется.
    """
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_reprod_passed", required=[], in_system=False)
    await factory.link_system_instrument(system_code="REPROD", instrument_code="instr_reprod_passed")
    await factory.result(patient_id=patient_id, instrument_code="instr_reprod_passed", risk_level="high")
    await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_FEMALE)
    await db_session.commit()

    handler = await interpretation_handler()
    with patch.object(
        handler._loader._patients_reader,  # noqa: SLF001
        "get_active_parameters",
        side_effect=AssertionError("не должно читаться"),
    ):
        now = datetime.now(tz=UTC)
        await handler.run_for(
            patient_id,
            ["REPROD"],
            patient_parameters={
                PARAMETER_CODE_GENDER: ActiveParameter(
                    PARAMETER_CODE_GENDER,
                    GENDER_MALE,
                    now + timedelta(days=1),
                    now,
                    1,
                )
            },
        )

    row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "REPROD")
    )
    assert row is not None and row.doctors_code == ["35"]


async def test_falls_back_to_db_when_patient_parameters_not_passed(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """Без `patient_values` поведение прежнее — параметры читаются из БД."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_reprod_fallback", required=[], in_system=False)
    await factory.link_system_instrument(system_code="REPROD", instrument_code="instr_reprod_fallback")
    await factory.result(patient_id=patient_id, instrument_code="instr_reprod_fallback", risk_level="high")
    await factory.answer(patient_id=patient_id, parameter_code=PARAMETER_CODE_GENDER, value=GENDER_MALE)
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["REPROD"])

    row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "REPROD")
    )
    assert row is not None and row.doctors_code == ["35"]


async def test_sense_doctors_from_questionnaire(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """§4.4.1 SENSE: при medium/high онкопараметр органов чувств активирует Офтальмолога 27 и ЛОР 11."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_sense", required=[], in_system=False)
    await factory.link_system_instrument(system_code="SENSE", instrument_code="instr_sense")
    await factory.result(patient_id=patient_id, instrument_code="instr_sense", risk_level="high")
    await factory.answer(patient_id=patient_id, parameter_code="sense_cancer", value="Да")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["SENSE"])

    row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "SENSE")
    )
    assert row is not None
    assert row.doctors_code == ["27", "11"]


async def test_sense_no_doctor_when_low_risk(
    db_session: AsyncSession, interpretation_handler: InterpretationHandlerFactory, factory: Factory
) -> None:
    """§4.4.1 не срабатывает при low/null risk_level, даже если жалоба есть."""
    patient_id = await factory.patient()
    await factory.instrument_with_params("instr_sense_low", required=[], in_system=False)
    await factory.link_system_instrument(system_code="SENSE", instrument_code="instr_sense_low")
    await factory.result(patient_id=patient_id, instrument_code="instr_sense_low", risk_level="low")
    await factory.answer(patient_id=patient_id, parameter_code="vision_loss_1yr", value="Да")
    await db_session.commit()

    handler = await interpretation_handler()
    await handler.run_for(patient_id, ["SENSE"])

    row = await db_session.scalar(
        select(Interpretation).where(Interpretation.patient_id == patient_id, Interpretation.system_code == "SENSE")
    )
    assert row is not None
    assert row.doctors_code is None
