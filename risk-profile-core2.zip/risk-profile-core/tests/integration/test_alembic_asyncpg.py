"""Смоук: `alembic upgrade head` проходит под asyncpg (прод-драйвер).

Прод гоняет миграции под asyncpg (migrations/env.py: async-путь для не-psycopg2 URL), а
основной тест-харнесс (tests/conftest.py) — под psycopg2. Из-за этого asyncpg-специфичные
падения не ловились в CI и всплывали только на деплое — напр. bind str → timestamptz даёт
asyncpg DataError, тогда как psycopg2 строку коэрсит (см. регресс 0099/0100).

Тест прогоняет ВСЕ миграции с нуля под asyncpg на отдельной чистой БД в том же кластере.
Sync-функция (не async): env.py на async-пути сам делает asyncio.run(), запущенный event loop
этому помешал бы.
"""

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url

_FRESH_DB = "asyncpg_migration_smoke"


def test_upgrade_head_runs_under_asyncpg(postgres_url: str) -> None:
    base = make_url(postgres_url)  # asyncpg URL к уже мигрированной дефолтной БД кластера

    # CREATE DATABASE нельзя в транзакции — коннектимся к дефолтной БД psycopg2 в AUTOCOMMIT.
    admin_engine = create_engine(base.set(drivername="postgresql+psycopg2"), isolation_level="AUTOCOMMIT")
    try:
        with admin_engine.connect() as conn:
            conn.execute(text(f'DROP DATABASE IF EXISTS "{_FRESH_DB}"'))
            conn.execute(text(f'CREATE DATABASE "{_FRESH_DB}"'))
    finally:
        admin_engine.dispose()

    # asyncpg-URL к чистой БД → env.py уходит на async-путь (asyncpg), как в проде.
    async_url = base.set(database=_FRESH_DB).render_as_string(hide_password=False)
    cfg = Config("alembic.ini")
    cfg.set_main_option("sqlalchemy.url", async_url)
    command.upgrade(cfg, "head")  # не должно бросить DataError под asyncpg

    # Санити: миграции действительно применились на чистой БД.
    verify_engine = create_engine(base.set(drivername="postgresql+psycopg2", database=_FRESH_DB))
    try:
        with verify_engine.connect() as conn:
            birthdate_validity = conn.execute(
                text("SELECT validity_period FROM catalog.parameters WHERE code = 'birthdate'")
            ).scalar_one()
        assert birthdate_validity.year == 2069
    finally:
        verify_engine.dispose()
