"""Integration-тесты PatientsReader.

Справочники reader больше не читает — они приходят из `HttpCatalog`; его выборки по реальной БД
покрыты в tests/integration/risk_communication/test_http_catalog.py.
"""

from datetime import UTC, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.patients.reader import PatientsReader
from tests.factories import Factory, now_utc, unique_id


class TestFindPatient:
    async def test_returns_patient(self, db_session: AsyncSession, factory: Factory) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid, is_pregnant=True)
        await db_session.commit()

        result = await PatientsReader(db_session).find_patient(pid)
        assert result is not None
        assert result.patient_id == pid
        assert result.is_pregnant is True

    async def test_returns_none_when_missing(self, db_session: AsyncSession) -> None:
        assert await PatientsReader(db_session).find_patient(unique_id("missing")) is None


class TestActiveParameters:
    async def test_filters_by_value_not_null_and_not_expired(self, db_session: AsyncSession, factory: Factory) -> None:
        pid = unique_id("p")
        active_p = unique_id("pc")
        skipped_p = unique_id("pc")  # value = None — должен быть отфильтрован
        expired_p = unique_id("pc")  # expiration < now — отфильтрован
        await factory.patient(patient_id=pid)
        for code in (active_p, skipped_p, expired_p):
            await factory.parameter(code=code)
        now = now_utc()
        date_time = datetime(2026, 1, 2, 3, 4, tzinfo=UTC)
        await factory.answer(
            patient_id=pid,
            parameter_code=active_p,
            value="v",
            expiration_date=now + timedelta(days=10),
            date_time=date_time,
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=skipped_p,
            value=None,
            expiration_date=now + timedelta(days=10),
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=expired_p,
            value="v",
            expiration_date=now - timedelta(days=1),
        )
        await db_session.commit()

        result = await PatientsReader(db_session).get_active_parameters(pid)
        assert set(result.keys()) == {active_p}
        assert result[active_p].date_time == date_time
        assert result[active_p].patient_parameter_id > 0


class TestSystemParamCodesBatch:
    async def test_resolves_via_systems_instruments(self, db_session: AsyncSession, factory: Factory) -> None:
        system_code = unique_id("S")
        instrument_code = unique_id("I")
        param_codes = [unique_id("pc") for _ in range(2)]
        await factory.system(code=system_code, description="x", rang=99)
        await factory.instrument(code=instrument_code)
        await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
        for code in param_codes:
            await factory.parameter(code=code)
            await factory.link_parameter(instrument_code=instrument_code, parameter_code=code)
        await db_session.commit()

        result = await PatientsReader(db_session).get_system_param_codes_batch([system_code])
        assert result == {system_code: set(param_codes)}

    async def test_system_without_parameters_maps_to_empty_set(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        # Контракт метода: в результате есть КАЖДЫЙ запрошенный код, даже без единого параметра.
        system_code = unique_id("S")
        await factory.system(code=system_code, description="x", rang=98)
        await db_session.commit()

        assert await PatientsReader(db_session).get_system_param_codes_batch([system_code]) == {system_code: set()}

    async def test_empty_input_returns_empty_dict(self, db_session: AsyncSession) -> None:
        assert await PatientsReader(db_session).get_system_param_codes_batch([]) == {}
