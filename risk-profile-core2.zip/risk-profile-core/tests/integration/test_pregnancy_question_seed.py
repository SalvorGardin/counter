"""Вопрос о беременности cq_030 не применим пациентам 50 лет и старше (сид conditions).

Правило живёт в справочнике (`conditions`), а не в коде, и справочник целиком
перезаливается сидами из админки — поэтому проверяем именно мигрированную БД: строка
`cq_030;age;;age;1;49` должна пережить любую следующую перезаливку. Проверка идёт через
`classify_question` (тот же путь, что у заполненности Risk-profile и гейта опросников),
а не сравнением строк CSV: значение имеет поведение, а не формат записи.
"""

from datetime import UTC, datetime

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.patients.dtos import ActiveParameter
from src.services.risk_communication.domain.conditions import classify_question, question_is_visible
from src.services.risk_communication.domain.constants import BIRTHDATE_PARAMETER_CODE, GENDER_PARAMETER_CODE
from src.services.risk_communication.domain.models import ConditionView
from tests.conftest import make_http_catalog
from tests.consts import GENDER_FEMALE

_PREGNANCY_QUESTION = "cq_030"
_TODAY = datetime(2026, 8, 6, tzinfo=UTC).date()
# Дни рождения подобраны так, чтобы на _TODAY возраст был ровно 49 и ровно 50.
_BIRTHDATE_AGE_49 = "1977-01-01"
_BIRTHDATE_AGE_50 = "1976-01-01"


@pytest_asyncio.fixture
async def pregnancy_conditions(db_session: AsyncSession) -> list[ConditionView]:
    catalog = await make_http_catalog(db_session)
    return catalog.condition_views_by_question([_PREGNANCY_QUESTION]).get(_PREGNANCY_QUESTION, [])


def _female(birthdate: str) -> dict[str, ActiveParameter]:
    expiration = datetime(2099, 1, 1, tzinfo=UTC)
    return {
        GENDER_PARAMETER_CODE: ActiveParameter(GENDER_PARAMETER_CODE, GENDER_FEMALE, expiration, expiration, 1),
        BIRTHDATE_PARAMETER_CODE: ActiveParameter(BIRTHDATE_PARAMETER_CODE, birthdate, expiration, expiration, 2),
    }


async def test_pregnancy_question_applicable_under_fifty(pregnancy_conditions: list[ConditionView]) -> None:
    classification = classify_question(
        conditions=pregnancy_conditions,
        active_parameters=_female(_BIRTHDATE_AGE_49),
        today=_TODAY,
    )
    assert classification.applicable is True
    assert question_is_visible(
        conditions=pregnancy_conditions,
        active_parameters=_female(_BIRTHDATE_AGE_49),
        today=_TODAY,
    )


async def test_pregnancy_question_not_applicable_from_fifty(pregnancy_conditions: list[ConditionView]) -> None:
    """50 лет — та же не-применимость, что у мужчин: вопрос выпадает из знаменателя и не задаётся."""
    active_parameters = _female(_BIRTHDATE_AGE_50)
    classification = classify_question(
        conditions=pregnancy_conditions,
        active_parameters=active_parameters,
        today=_TODAY,
    )
    assert classification.applicable is False
    # hidden=False принципиально: авто-зачёта в числителе нет, вопроса нет и в знаменателе.
    assert classification.hidden is False
    assert not question_is_visible(
        conditions=pregnancy_conditions,
        active_parameters=active_parameters,
        today=_TODAY,
    )
