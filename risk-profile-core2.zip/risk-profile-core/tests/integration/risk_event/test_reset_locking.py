"""Блокировки строк `patients_parameters` при сбросе параметров risk-event.

Писатель захватывает строки одним `SELECT ... FOR UPDATE ORDER BY parameter_code` и утверждает
две вещи: окно между архивацией и инвалидацией закрыто (параллельная запись того же параметра
ждёт конца транзакции сброса), а порядок захвата — канонический, общий с путями записи
нескольких параметров одной транзакцией (правило — `src/infra/patients_parameters.py`).

Первое проверяется ДВУМЯ КОММИТЯЩИМИ сессиями: общая фикстура `db_session` держит всё в одной
откатываемой транзакции соединения, и второе соединение её строк не видит — ни пациента, ни
параметра, ни взятой блокировки. Поэтому сессии здесь свои, на своём engine, а данные за тестом
убирает фикстура, а не общий rollback.
"""

from collections.abc import AsyncGenerator
from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.dialects import postgresql
from sqlalchemy.exc import DBAPIError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.infra.db_schemas import PROFILE_SCHEMA
from src.infra.patients_parameters import archive_and_upsert_patient_parameter
from src.services.risk_communication.domain.constants import ANSWER_SOURCE
from src.services.risk_event.domain.constants import BODY_METRIC_PARAMETER_CODES, SYSTEM_CODE_CVD
from src.services.risk_event.infra.writer import RiskEventWriter
from src.services.risk_event.service import RiskEventService
from tests.conftest import PHYSICAL_CONNECT_ARGS, make_http_catalog
from tests.factories import Factory, unique_id

# Значение засеянной версии и значение, которое пишет вторая транзакция: по ним видно, какая
# версия осталась актуальной, а какие уехали в историю.
_SEEDED_VALUE = "5.5"
_WRITTEN_VALUE = "6.0"

# Ожидание блокировки во второй транзакции. Короткое и локальное для её транзакции: пока она
# ждёт, сброс стоит внутри обёртки над `execute` и до коммита не дойдёт.
_LOCK_TIMEOUT = "300ms"


def _future() -> datetime:
    return datetime.now(tz=UTC) + timedelta(days=10)


@pytest.fixture
def created_patients() -> list[str]:
    return []


@pytest.fixture
def created_parameters() -> list[str]:
    return []


@pytest_asyncio.fixture
async def committed_session_factory(
    postgres_url: str, created_patients: list[str], created_parameters: list[str]
) -> AsyncGenerator[async_sessionmaker[AsyncSession], None]:
    """Фабрика сессий, которые ДЕЙСТВИТЕЛЬНО коммитят, плюс уборка за тестом.

    Тем же приёмом, что `committed_session_factory` в test_status_cleanup.py: незакоммиченные
    данные второму соединению не видны, поэтому изоляция «всё в откатываемой транзакции» здесь
    не работает. Уборка — в порядке внешних ключей: версии параметра, сам параметр пациента,
    пациент, и только потом строка справочника `parameters`.
    """
    engine = create_async_engine(postgres_url, connect_args=PHYSICAL_CONNECT_ARGS)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        yield session_factory
    finally:
        async with session_factory() as session:
            await session.execute(
                text("DELETE FROM patients_parameters_history WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM patients_parameters WHERE patient_id = ANY(:pids)"), {"pids": created_patients}
            )
            await session.execute(
                text("DELETE FROM patients WHERE patient_id = ANY(:pids)"), {"pids": created_patients}
            )
            await session.execute(
                text("DELETE FROM parameters WHERE code = ANY(:codes)"), {"codes": created_parameters}
            )
            await session.commit()
        await engine.dispose()


async def _history_versions(session: AsyncSession, *, patient_id: str, parameter_code: str) -> list[tuple[Any, bool]]:
    """Версии параметра в истории по порядку архивации: значение и признак «срок уже в прошлом»."""
    rows = await session.execute(
        text(
            "SELECT value, expiration_date < now() AS invalidated FROM patients_parameters_history"
            " WHERE patient_id = :pid AND parameter_code = :code ORDER BY patient_parameter_history_id"
        ),
        {"pid": patient_id, "code": parameter_code},
    )
    return [(row.value, row.invalidated) for row in rows.all()]


async def _current_version(session: AsyncSession, *, patient_id: str, parameter_code: str) -> tuple[Any, bool]:
    """Актуальная строка параметра: значение и признак «срок уже в прошлом»."""
    row = await session.execute(
        text(
            "SELECT value, expiration_date < now() AS invalidated FROM patients_parameters"
            " WHERE patient_id = :pid AND parameter_code = :code"
        ),
        {"pid": patient_id, "code": parameter_code},
    )
    found = row.one()
    return found.value, found.invalidated


@pytest.mark.asyncio
async def test_write_of_locked_parameter_waits_for_the_reset(
    committed_session_factory: async_sessionmaker[AsyncSession],
    created_patients: list[str],
    created_parameters: list[str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Запись того же параметра во время сброса ждёт конца его транзакции и ложится ПОВЕРХ сброса.

    Сессия A выполняет сброс; обёртка над её `execute` сразу после запроса блокировки (первый
    запрос метода) запускает в сессии B запись того же параметра с ограничением ожидания
    блокировки — та обязана упасть по таймауту, а не записать значение в обход захваченной строки.
    После коммита A та же запись проходит, и в истории поверх версии, архивированной сбросом,
    ложится версия со сроком в прошлом: именно её B архивировала, найдя строку уже погашенной.
    """
    patient_id = unique_id("p")
    parameter_code = unique_id("PARAM")
    created_patients.append(patient_id)
    created_parameters.append(parameter_code)

    async with committed_session_factory() as session_a, committed_session_factory() as session_b:
        factory = Factory(session_a)
        await factory.patient(patient_id=patient_id)
        await factory.parameter(parameter_code)
        await factory.answer(
            patient_id=patient_id,
            parameter_code=parameter_code,
            value=_SEEDED_VALUE,
            source=ANSWER_SOURCE,
            expiration_date=_future(),
        )
        await session_a.commit()

        async def _write_from_second_session() -> None:
            await archive_and_upsert_patient_parameter(
                session_b,
                patient_id=patient_id,
                parameter_code=parameter_code,
                value=_WRITTEN_VALUE,
                source=ANSWER_SOURCE,
                external_id=None,
                expiration_date=_future(),
                date_time=datetime.now(tz=UTC),
            )

        # Исключение второй транзакции фиксируется, а не глотается: ассерт ниже сверяет его код.
        blocked: list[DBAPIError] = []
        executed = 0
        original_execute = session_a.execute

        async def _execute_then_write(statement: Any, *args: Any, **kwargs: Any) -> Any:
            nonlocal executed
            result = await original_execute(statement, *args, **kwargs)
            executed += 1
            if executed == 1:
                with pytest.raises(DBAPIError) as timed_out:
                    async with session_b.begin():
                        await session_b.execute(text(f"SET LOCAL lock_timeout = '{_LOCK_TIMEOUT}'"))
                        await _write_from_second_session()
                blocked.append(timed_out.value)
            return result

        monkeypatch.setattr(session_a, "execute", _execute_then_write)

        async with session_a.begin():
            invalidated = await RiskEventWriter(session_a).archive_and_invalidate_parameters(
                patient_id, parameter_codes=[parameter_code], unconditional_codes=[]
            )

        # 55P03 (lock_not_available) — отказ по `lock_timeout`, а не любой сбой записи. Код ошибки
        # у обёртки asyncpg-диалекта лежит в `sqlstate`, как и в `_execute_diagnostic`
        # (src/explanation/infra/reader.py).
        assert invalidated == 1
        assert [getattr(exc.orig, "sqlstate", None) for exc in blocked] == ["55P03"]

        async with session_b.begin():
            await _write_from_second_session()

        assert await _history_versions(session_b, patient_id=patient_id, parameter_code=parameter_code) == [
            (_SEEDED_VALUE, False),
            (_SEEDED_VALUE, True),
        ]
        assert await _current_version(session_b, patient_id=patient_id, parameter_code=parameter_code) == (
            _WRITTEN_VALUE,
            False,
        )


@pytest.mark.asyncio
async def test_answers_reset_locks_all_rows_with_one_ordered_query(
    db_session: AsyncSession, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Сброс CVD с параметром системы и антропометрией берёт блокировки ОДНИМ запросом с сортировкой.

    Два запроса на два множества кодов дали бы две партии блокировок в порядке сканирования: первая
    держала бы строку с большим `parameter_code`, пока вторая ждёт строку с меньшим. Пин считает
    запросы с `FOR UPDATE` за весь сброс и требует в SQL единственного из них сортировку по
    `parameter_code` — она и задаёт порядок, в котором PostgreSQL берёт блокировки.
    """
    patient_id = unique_id("p")
    system_parameter = unique_id("cvdp")
    instrument_code = unique_id("i")
    await factory.patient(patient_id=patient_id)
    await factory.parameter(code=system_parameter)
    await factory.instrument(code=instrument_code)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=system_parameter)
    await factory.link_system_instrument(system_code=SYSTEM_CODE_CVD, instrument_code=instrument_code)
    await factory.answer(
        patient_id=patient_id, parameter_code=system_parameter, value=_SEEDED_VALUE, expiration_date=_future()
    )
    # Антропометрия — второе множество кодов сброса. Коды из сидов миграций, своих строк
    # `parameters` для них не заводим; значения — лишь чтобы строки существовали и были актуальны.
    for code in sorted(BODY_METRIC_PARAMETER_CODES):
        await factory.answer(patient_id=patient_id, parameter_code=code, value="70", expiration_date=_future())
    await db_session.commit()
    service = RiskEventService(db_session, await make_http_catalog(db_session))

    statements: list[str] = []
    original_execute = db_session.execute

    async def _record(statement: Any, *args: Any, **kwargs: Any) -> Any:
        # Компилируем боевым диалектом: у части запросов сброса (`DELETE ... RETURNING` по
        # results/interpretations, `INSERT ... ON CONFLICT` в реконсиляции `bmi`) текста для
        # диалекта по умолчанию нет вовсе — компиляция упала бы вместо проверки.
        statements.append(str(statement.compile(dialect=postgresql.dialect())))
        return await original_execute(statement, *args, **kwargs)

    monkeypatch.setattr(db_session, "execute", _record)

    await service.handle_answers_reset(client_id=patient_id, system_codes=[SYSTEM_CODE_CVD])

    locking = [sql for sql in statements if "FOR UPDATE" in sql]
    assert len(locking) == 1
    # Таблица адресуется схемой-владельцем: запрос компилируется боевым диалектом без карты
    # трансляции схем, поэтому в тексте стоит физическое имя, а не локальное представление.
    assert f"ORDER BY {PROFILE_SCHEMA}.patients_parameters.parameter_code" in locking[0]
