"""Чистка `calculation_statuses`, `interpretation_statuses` и `risk_factor_matches` при
answers-reset/pregnancy-end.

Регрессия: `RiskEventService` удаляет `results` по затронутым инструментам и `interpretations` по
затронутым системам, поэтому строки диагностики, оставшиеся от предыдущего прогона, без явной
чистки продолжали бы молчать `status=calculated` для инструмента, у которого уже нет ни
результата, ни (после сброса) ответов, и `computed` плюс полный список сработавших факторов для
системы, у которой интерпретации уже нет вовсе. Чистка заканчивается до возврата обработчика —
иначе она могла бы обогнать пересчёт, который роутер ставит после него, и стереть уже его
диагностику.

Своя сессия и `committed_session_factory` — тем же приёмом, что и
`tests/integration/calc/test_status_collection.py`: `CalcStatusCollector.delete_for_instruments`
и `InterpretationReasonCollector.delete_for_systems` пишут ОТДЕЛЬНОЙ сессией, и незакоммиченные
данные им не видны.
"""

from collections.abc import AsyncGenerator
from datetime import UTC, datetime, timedelta

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.calc.status_collector import CalcStatusCollector
from src.config import settings
from src.interpretation.reason_collector import InterpretationReasonCollector
from src.services.risk_event.domain.constants import SYSTEM_CODE_CVD
from src.services.risk_event.service import RiskEventService
from tests.conftest import PHYSICAL_CONNECT_ARGS, make_http_catalog
from tests.factories import Factory, unique_id


@pytest.fixture
def created_patients() -> list[str]:
    return []


@pytest.fixture
def created_instruments() -> list[str]:
    return []


@pytest_asyncio.fixture
async def committed_session_factory(
    postgres_url: str, created_patients: list[str], created_instruments: list[str]
) -> AsyncGenerator[async_sessionmaker[AsyncSession], None]:
    """Фабрика сессий, которые ДЕЙСТВИТЕЛЬНО коммитят, плюс уборка за тестом.

    Незакоммиченные данные `CalcStatusCollector` не видны (у него своя сессия), поэтому
    изоляция «всё в откатываемой транзакции» здесь не работает.
    """
    engine = create_async_engine(postgres_url, connect_args=PHYSICAL_CONNECT_ARGS)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        yield session_factory
    finally:
        async with session_factory() as session:
            # Статусы — первыми: FK RESTRICT на patients/instruments не даст удалить их раньше.
            await session.execute(
                text("DELETE FROM calculation_statuses WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM risk_factor_matches WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM interpretation_statuses WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM results_history WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(text("DELETE FROM results WHERE patient_id = ANY(:pids)"), {"pids": created_patients})
            await session.execute(
                text("DELETE FROM patients_parameters_history WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM patients_parameters WHERE patient_id = ANY(:pids)"),
                {"pids": created_patients},
            )
            await session.execute(
                text("DELETE FROM systems_instruments WHERE instrument_code = ANY(:codes)"),
                {"codes": created_instruments},
            )
            await session.execute(
                text("DELETE FROM patients WHERE patient_id = ANY(:pids)"), {"pids": created_patients}
            )
            await session.execute(
                text("DELETE FROM instruments WHERE code = ANY(:codes)"), {"codes": created_instruments}
            )
            await session.commit()
        await engine.dispose()


@pytest_asyncio.fixture
async def session(
    committed_session_factory: async_sessionmaker[AsyncSession],
) -> AsyncGenerator[AsyncSession, None]:
    async with committed_session_factory() as s:
        yield s


@pytest.fixture
def factory(session: AsyncSession, factory: Factory) -> Factory:
    """Свой Factory поверх коммитящейся сессии этого модуля.

    Общая фикстура `factory` привязана к `db_session`, которая откатывается и живёт в своей
    транзакции: её записи сервис, читающий через `committed_session_factory`, не увидел бы.
    """
    return Factory(session)


@pytest.fixture
def collection_on(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", True)


@pytest.fixture
def collection_off(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "calc_status_collection_enabled", False)


async def _seed_patient_with_calculated_instrument(
    session: AsyncSession,
    factory: Factory,
    *,
    patient_id: str,
    instrument_code: str,
    system_code: str,
) -> None:
    now = datetime.now(tz=UTC)
    await factory.patient(patient_id=patient_id)
    await factory.instrument(code=instrument_code)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
    await factory.result(
        patient_id=patient_id,
        instrument_code=instrument_code,
        value="1.0",
        date_time=now,
        expiration_date=now + timedelta(days=30),
    )
    await factory.calc_status(patient_id=patient_id, instrument_code=instrument_code, status="calculated")
    await session.commit()


async def _seed_interpretation_reasons(
    session: AsyncSession, factory: Factory, *, patient_id: str, system_code: str
) -> None:
    """Строки диагностики интерпретации от предыдущего прогона: статус системы и сработавший фактор."""
    await factory.interpretation_status(patient_id=patient_id, system_code=system_code)
    # Справочник фактора не нужен: тест проверяет чистку строк диагностики, а не их происхождение.
    await factory.risk_factor_match(
        patient_id=patient_id,
        code="rf",
        system_code=system_code,
        trigger_code="seed-trigger",
        parameter_code="age",
        param_value="yes",
        factor_description="factor",
    )
    await session.commit()


async def _reason_counts(session: AsyncSession, *, patient_id: str, system_code: str) -> tuple[int, int]:
    """Число строк `interpretation_statuses` и `risk_factor_matches` по паре «пациент × система»."""
    statuses = await session.execute(
        text("SELECT COUNT(*) FROM interpretation_statuses WHERE patient_id = :pid AND system_code = :sys"),
        {"pid": patient_id, "sys": system_code},
    )
    matches = await session.execute(
        text("SELECT COUNT(*) FROM risk_factor_matches WHERE patient_id = :pid AND system_code = :sys"),
        {"pid": patient_id, "sys": system_code},
    )
    return statuses.scalar_one(), matches.scalar_one()


async def _service(
    session: AsyncSession, committed_session_factory: async_sessionmaker[AsyncSession]
) -> RiskEventService:
    """Сервис с обоими коллекторами на коммитящей фабрике: оба пишут своей сессией."""
    return RiskEventService(
        session,
        await make_http_catalog(session),
        status_collector=CalcStatusCollector(session_factory=committed_session_factory),
        reason_collector=InterpretationReasonCollector(session_factory=committed_session_factory),
    )


async def _status_count(session: AsyncSession, *, patient_id: str, instrument_code: str) -> int:
    result = await session.execute(
        text("SELECT COUNT(*) FROM calculation_statuses WHERE patient_id = :pid AND instrument_code = :instr"),
        {"pid": patient_id, "instr": instrument_code},
    )
    return result.scalar_one()


@pytest.mark.asyncio
async def test_answers_reset_deletes_stale_calculation_status(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    """Инструмент имел `calculated` от предыдущего расчёта; answers-reset сносит его результат —
    строка статуса не должна пережить это молча."""
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _status_count(session, patient_id=pid, instrument_code=instr) == 0


@pytest.mark.asyncio
async def test_pregnancy_end_deletes_stale_calculation_status(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )

    service = await _service(session, committed_session_factory)
    await service.handle_pregnancy_end(client_id=pid)

    assert await _status_count(session, patient_id=pid, instrument_code=instr) == 0


@pytest.mark.asyncio
async def test_answers_reset_leaves_status_untouched_when_collection_disabled(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_off: None,
) -> None:
    """Выключенный флаг — чистка не выполняется вовсе (симметрично записи, см. CalcStatusCollector)."""
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _status_count(session, patient_id=pid, instrument_code=instr) == 1


@pytest.mark.asyncio
async def test_answers_reset_of_unrelated_system_leaves_other_instrument_status(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    """Сброс системы S1 не должен трогать статус инструмента системы S2."""
    pid = unique_id("p")
    kept_instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(kept_instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=kept_instr, system_code="ONCO"
    )

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _status_count(session, patient_id=pid, instrument_code=kept_instr) == 1


@pytest.mark.asyncio
async def test_answers_reset_deletes_stale_interpretation_reasons(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    """Система имела причины и сработавшие факторы от предыдущей интерпретации; answers-reset
    сносит саму интерпретацию — строки диагностики не должны её пережить."""
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )
    await _seed_interpretation_reasons(session, factory, patient_id=pid, system_code=SYSTEM_CODE_CVD)

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _reason_counts(session, patient_id=pid, system_code=SYSTEM_CODE_CVD) == (0, 0)


@pytest.mark.asyncio
async def test_pregnancy_end_deletes_stale_interpretation_reasons(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )
    await _seed_interpretation_reasons(session, factory, patient_id=pid, system_code=SYSTEM_CODE_CVD)

    service = await _service(session, committed_session_factory)
    await service.handle_pregnancy_end(client_id=pid)

    assert await _reason_counts(session, patient_id=pid, system_code=SYSTEM_CODE_CVD) == (0, 0)


@pytest.mark.asyncio
async def test_answers_reset_of_unrelated_system_leaves_its_reasons(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_on: None,
) -> None:
    """Сброс системы S1 не должен трогать причины системы S2: интерпретация S2 на месте."""
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code="ONCO"
    )
    await _seed_interpretation_reasons(session, factory, patient_id=pid, system_code="ONCO")

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _reason_counts(session, patient_id=pid, system_code="ONCO") == (1, 1)


@pytest.mark.asyncio
async def test_reasons_survive_when_collection_disabled(
    session: AsyncSession,
    factory: Factory,
    created_patients: list[str],
    created_instruments: list[str],
    committed_session_factory: async_sessionmaker[AsyncSession],
    collection_off: None,
) -> None:
    """Выключенный флаг — чистка не выполняется вовсе (симметрично записи)."""
    pid = unique_id("p")
    instr = unique_id("i")
    created_patients.append(pid)
    created_instruments.append(instr)
    await _seed_patient_with_calculated_instrument(
        session, factory, patient_id=pid, instrument_code=instr, system_code=SYSTEM_CODE_CVD
    )
    await _seed_interpretation_reasons(session, factory, patient_id=pid, system_code=SYSTEM_CODE_CVD)

    service = await _service(session, committed_session_factory)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    assert await _reason_counts(session, patient_id=pid, system_code=SYSTEM_CODE_CVD) == (1, 1)
