"""risk-event при отсутствующих данных: неизвестный клиент и параметр ИМТ вне справочника.

Все три события начинаются с поиска пациента, и ни одно не имеет права молча сделать вид, что
работа выполнена: `handle_pregnancy_end` и `handle_answers_reset` возвращают bool, который роутер
читает как «нужен ли пересчёт», и `False` для несуществующего клиента был бы неотличим от
«клиент есть, менять нечего».
"""

from datetime import UTC, datetime, timedelta
from types import MappingProxyType

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.services.risk_communication.domain.exceptions import ClientNotFoundError
from src.services.risk_event.service import RiskEventService
from src.services.risk_init.domain.constants import (
    BMI_PARAMETER_CODE,
    HEIGHT_PARAMETER_CODE,
    WEIGHT_PARAMETER_CODE,
)
from tests.conftest import LogSink, make_http_catalog
from tests.db_assertions import DbRead
from tests.factories import Factory, unique_id

_SEED_HEIGHT = "175"
_SEED_WEIGHT = "72"
# Заведомо не равен compute_bmi(175, 72) = 23.51 — иначе «значение не пересчитывалось» проходило бы
# и при сработавшей реконсиляции.
_SEED_BMI = "30"
# Сброс URO гасит производный bmi, не трогая height/weight (проливка 0104) — на нём и проверяем,
# что реконсиляция останавливается по отсутствию параметра в справочнике.
_BMI_ORPHANING_SYSTEM = "URO"


def _future() -> datetime:
    return datetime.now(tz=UTC) + timedelta(days=365)


async def _make_service(session: AsyncSession) -> RiskEventService:
    await session.commit()
    return RiskEventService(session, await make_http_catalog(session))


async def test_pregnancy_end_for_unknown_client_raises(db_session: AsyncSession) -> None:
    """Событие о завершении беременности по чужому идентификатору — ошибка, а не тихий False."""
    service = await _make_service(db_session)

    with pytest.raises(ClientNotFoundError):
        await service.handle_pregnancy_end(client_id=unique_id("missing"))


async def test_answers_reset_for_unknown_client_raises(db_session: AsyncSession) -> None:
    """Сброс ответов проверяет клиента ДО проверки кодов систем.

    Порядок важен: сообщить «система не найдена» по несуществующему клиенту значило бы увести
    разбор на справочник вместо ошибочного идентификатора в запросе.
    """
    service = await _make_service(db_session)

    with pytest.raises(ClientNotFoundError):
        await service.handle_answers_reset(client_id=unique_id("missing"), system_codes=["UNKNOWN"])


async def test_bmi_reconciliation_stops_when_parameter_is_absent_from_catalog(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, captured_app_logs: LogSink
) -> None:
    """Параметра ИМТ нет в справочнике — реконсиляция не выполняется и оставляет след в логах.

    Срок жизни значения берётся только из `parameters.validity_period`; посчитать ИМТ и записать
    его без срока значило бы завести ответ, который никогда не протухнет. Пропуск при этом
    молчаливым быть не может: это дефект справочника, а не состояние пациента.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=False)
    for code, value in (
        (HEIGHT_PARAMETER_CODE, _SEED_HEIGHT),
        (WEIGHT_PARAMETER_CODE, _SEED_WEIGHT),
        (BMI_PARAMETER_CODE, _SEED_BMI),
    ):
        await factory.answer(patient_id=pid, parameter_code=code, value=value, expiration_date=_future(), source="EMR")

    service = await _make_service(db_session)
    # Так выглядит параметр, выпавший из справочника: строка помечена inactive или не залита сидом.
    without_bmi = {code: row for code, row in service._catalog.parameters.items() if code != BMI_PARAMETER_CODE}
    service._catalog.parameters = MappingProxyType(without_bmi)

    await service.handle_answers_reset(client_id=pid, system_codes=[_BMI_ORPHANING_SYSTEM])

    context = captured_app_logs.context_of("no validity_period found for parameter, skipping bmi reconciliation")
    assert context["parameter_code"] == BMI_PARAMETER_CODE
    # Значение не пересчитано, и погашенный сбросом срок жизни не восстановлен: ИМТ остаётся
    # осиротевшим — ровно то состояние, ради которого реконсиляция и делалась.
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    assert bmi_row["value"] == _SEED_BMI
    assert bmi_row["expiration_date"] < datetime.now(tz=UTC)
