"""Пустые наборы кодов у писателя risk-event не доходят до запроса.

Пустой набор здесь штатен: система без инструментов (сброс гасит только интерпретацию), пациент
без ответов по системе. Без короткого замыкания запрос всё равно ушёл бы в БД — SQLAlchemy
подставляет вместо `IN ()` заведомо ложное условие, — а `archive_and_invalidate_parameters`
открыл бы на заведомо пустом наборе ещё и отбор с `FOR UPDATE`.
"""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.services.risk_event.infra.writer import RiskEventWriter


async def test_invalidating_no_parameters_is_noop(db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch) -> None:
    """Оба множества кодов пусты — ни запроса, ни строки в history, счётчик 0.

    Короткое замыкание стоит до построения предиката отбора: иначе на заведомо пустом наборе
    ушёл бы запрос с `FOR UPDATE`. Непустое множество РЯДОМ с пустым — вход столь же штатный
    (сброс параметров систем приходит без антропометрии, сброс антропометрии — без параметров
    систем) — проверяется реальным прогоном против БД в
    tests/integration/schema/test_history_column_copy.py.
    """

    async def _fail(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("пустой набор кодов не должен доходить до запроса")

    monkeypatch.setattr(db_session, "execute", _fail)

    invalidated = await RiskEventWriter(db_session).archive_and_invalidate_parameters(
        patient_id="p", parameter_codes=[], unconditional_codes=[]
    )
    assert invalidated == 0


async def test_deleting_no_results_returns_zero(db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch) -> None:
    """Система без инструментов: удалять нечего, счётчик — 0.

    Ноль здесь возвращается тем же типом, что и на непустом входе: вызывающий пишет это число в
    лог сброса, и None вместо 0 читался бы как «шаг не выполнялся».
    """

    async def _fail(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("пустой набор кодов не должен доходить до запроса")

    monkeypatch.setattr(db_session, "execute", _fail)

    assert await RiskEventWriter(db_session).archive_and_delete_results(patient_id="p", instrument_codes=[]) == 0


async def test_deleting_no_interpretations_returns_zero(
    db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch
) -> None:
    async def _fail(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("пустой набор кодов не должен доходить до запроса")

    monkeypatch.setattr(db_session, "execute", _fail)

    assert await RiskEventWriter(db_session).archive_and_delete_interpretations(patient_id="p", system_codes=[]) == 0
