"""Сквозной сценарий #265: событие сброса → полный пересчёт → риск-профиль.

Путь настоящий и без моков расчёта: `RiskEventService` сбрасывает систему, `dispatch_recalc` при
выключенной Kafka считает весь риск-профиль в этом же процессе, а результат читается через
Risk-profile — ровно тот порядок, который выполняет роутер (`src/api/v1/risk_event/router.py`).
"""

import contextlib
from collections.abc import AsyncIterator
from datetime import timedelta
from types import SimpleNamespace

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.dispatcher import dispatch_recalc
from src.calc.domain.models import InstrumentsCodes, InstrumentsIndicators
from src.emr_biomarkers.domain.constants import BIOMARKER_SOURCE
from src.infra.kafka.exceptions import KafkaInitError
from src.services.risk_communication.domain.constants import ANSWER_SOURCE
from src.services.risk_event.domain.constants import SYSTEM_CODE_CVD
from src.services.risk_event.service import RiskEventService
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import LogSink, make_http_catalog
from tests.db_assertions import DbRead
from tests.factories import Factory, now_utc, unique_id

# Значение ответа и совпадающая с ним строка шкалы: балл 5 даёт CVD-опроснику уровень medium.
_ANSWER_VALUE = "5.55"
_ANSWER_SCORE = 5
_BIOMARKER_EXTERNAL_ID = 265_001
# Система с опросником, который делит параметр с опросником сбрасываемой системы.
_SHARING_SYSTEM_CODE = "URO"


@pytest.fixture
def patched_factory(db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch):
    """Подменяет фабрику сессий основного рантайма так, чтобы диспетчер видел писания тестовой сессии
    (она работает в savepoint-режиме; отдельный engine их не увидел бы)."""

    @contextlib.asynccontextmanager
    async def _factory() -> AsyncIterator[AsyncSession]:
        yield db_session

    def _kafka_disabled() -> None:
        raise KafkaInitError("disabled in tests")

    monkeypatch.setattr("src.calc.dispatcher.get_primary_runtime", lambda: SimpleNamespace(session_factory=_factory))
    # Инлайн-ветка берёт фабрику у рантайма расчёта, а не у рантайма процесса: подменяем и её,
    # иначе диспетчер открыл бы отдельное соединение по адресу логина расчёта и не увидел писаний
    # тестовой сессии — пересчёт упал бы, а тест читал бы пустоту как «считать было нечего».
    monkeypatch.setattr(
        "src.calc.dispatcher.init_calculation_runtime",
        lambda: SimpleNamespace(session_factory=_factory),
    )
    monkeypatch.setattr("src.calc.dispatcher.get_kafka_producer", _kafka_disabled)
    yield


async def _make_service(session: AsyncSession) -> RiskEventService:
    await session.commit()
    return RiskEventService(session, await make_http_catalog(session))


async def _detach_instrument(
    db_session: AsyncSession, factory: Factory, *, system_code: str, instrument_code: str
) -> None:
    """Инструмент остаётся единственным в системе и несёт только параметры теста.

    Связи справочника с инструмента и системы снимаются: иначе в знаменатель заполненности и в
    расчёт попали бы засеянные миграциями строки, и тест проверял бы справочник вместо своего
    сценария (транзакция теста откатывается, справочник не страдает).
    """
    await db_session.execute(
        text("DELETE FROM instruments_parameters WHERE instrument_code = :code"), {"code": instrument_code}
    )
    await db_session.execute(
        text("DELETE FROM systems_instruments WHERE instrument_code = :code"), {"code": instrument_code}
    )
    await factory.unlink_system_instruments(system_code=system_code)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)


async def _seed_single_instrument_system(
    db_session: AsyncSession, factory: Factory, *, system_code: str, instrument_code: str, parameter_code: str
) -> None:
    """Система ровно из одного инструмента-опросника с одним вопросом и одним новым параметром.

    Опросник берётся из реального кода: расчёт опросников работает по реестру инструментов, и
    синтетический код ни один pipeline не подхватит. Вопрос со своим вариантом — единственный
    применимый: знаменатель заполненности равен 1, и проверка «100» перестаёт быть проверкой
    пустого знаменателя.
    """
    await _detach_instrument(db_session, factory, system_code=system_code, instrument_code=instrument_code)
    await factory.question_with_options(unique_id("q"), [parameter_code], instrument_code=instrument_code)
    await factory.parameter_score(
        parameter_code=parameter_code, system_code=system_code, value=_ANSWER_VALUE, score=_ANSWER_SCORE
    )


async def _seed_system_sharing_parameter(
    db_session: AsyncSession, factory: Factory, *, system_code: str, instrument_code: str, parameter_code: str
) -> None:
    """Вторая система с опросником, который делит уже существующий параметр с первой.

    Ровно то, чем справочник и отличается от допущения «сброс системы ломает только её
    инструменты»: `parameter_code` связан с инструментами РАЗНЫХ систем, поэтому сброс первой
    системы отбирает вход и у опросника второй. Вопрос у неё свой — он же её знаменатель
    заполненности, — а параметр и его актуальная запись общие.
    """
    await _detach_instrument(db_session, factory, system_code=system_code, instrument_code=instrument_code)
    question_code = await factory.question(unique_id("q"), question_text="")
    await factory.option(question_code=question_code, parameter_code=parameter_code)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=parameter_code, is_required=False)
    await factory.parameter_score(
        parameter_code=parameter_code, system_code=system_code, value=_ANSWER_VALUE, score=_ANSWER_SCORE
    )


async def _seed_existing_risk(factory: Factory, *, patient_id: str, system_code: str, instrument_code: str) -> None:
    """Результат и интерпретация, накопленные до события сброса.

    Индикатор строки — тот же, что пишет расчёт опросника: иначе пересчёт добавил бы результат
    рядом, а не переписал этот, и подмена заглушкой осталась бы незамеченной.
    """
    now = now_utc()
    await factory.result(
        patient_id=patient_id,
        instrument_code=instrument_code,
        indicator=InstrumentsIndicators.QUESTIONNAIRE.value,
        value="1.0",
        date_time=now - timedelta(days=1),
        expiration_date=now + timedelta(days=30),
    )
    await factory.interpretation(
        patient_id=patient_id, system_code=system_code, date_time=now - timedelta(days=1), risk_level="high"
    )


async def _medical_risk_item(db_session: AsyncSession, *, patient_id: str, system_code: str):
    # Проверки выше читали через ту же сессию и открыли её транзакцию, а `get_medical_risk`
    # заводит собственный транзакционный скоп — закрываем прочитанное перед вызовом.
    await db_session.commit()
    response = await RiskProfileService(db_session, await make_http_catalog(db_session)).get_medical_risk(
        client_id=patient_id, system_code=system_code
    )
    assert len(response.system_interpretation_results) == 1
    return response.system_interpretation_results[0]


@pytest.mark.asyncio
async def test_answers_reset_of_system_covered_by_emr_biomarkers_restores_risk(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, patched_factory
) -> None:
    """Система целиком закрыта биомаркерами ЭМК: сброс не меняет ни одной записи параметров,
    но результат и интерпретация удалены — и пересчёт возвращает их на место."""
    pid = unique_id("p")
    instrument_code = InstrumentsCodes.CVD.value
    parameter_code = unique_id("bp")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _seed_single_instrument_system(
        db_session,
        factory,
        system_code=SYSTEM_CODE_CVD,
        instrument_code=instrument_code,
        parameter_code=parameter_code,
    )
    await factory.answer(
        patient_id=pid,
        parameter_code=parameter_code,
        value=_ANSWER_VALUE,
        source=BIOMARKER_SOURCE,
        external_id=_BIOMARKER_EXTERNAL_ID,
        expiration_date=now_utc() + timedelta(days=30),
    )
    await _seed_existing_risk(factory, patient_id=pid, system_code=SYSTEM_CODE_CVD, instrument_code=instrument_code)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    # Сброс унёс результат и интерпретацию в историю: пересчитывать есть что.
    assert await db_read.count_results(patient_id=pid, instrument_code=instrument_code) == 0
    assert await db_read.count_interpretations(patient_id=pid, system_code=SYSTEM_CODE_CVD) == 0

    await dispatch_recalc(pid, None)

    assert await db_read.count_results(patient_id=pid, instrument_code=instrument_code) == 1
    assert await db_read.count_interpretations(patient_id=pid, system_code=SYSTEM_CODE_CVD) == 1
    item = await _medical_risk_item(db_session, patient_id=pid, system_code=SYSTEM_CODE_CVD)
    assert item.interpretation_status == "completed"
    assert item.system_completion_percentage == 100


@pytest.mark.asyncio
async def test_answers_reset_of_system_answered_by_client_leaves_it_empty(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, captured_app_logs: LogSink, patched_factory
) -> None:
    """Та же система, но параметр отвечен клиентом: сброс гасит ответ, и пересчёт не находит
    данных — результата и интерпретации нет, риск-профиль пуст."""
    pid = unique_id("p")
    instrument_code = InstrumentsCodes.CVD.value
    parameter_code = unique_id("fp")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _seed_single_instrument_system(
        db_session,
        factory,
        system_code=SYSTEM_CODE_CVD,
        instrument_code=instrument_code,
        parameter_code=parameter_code,
    )
    await factory.answer(
        patient_id=pid,
        parameter_code=parameter_code,
        value=_ANSWER_VALUE,
        source=ANSWER_SOURCE,
        expiration_date=now_utc() + timedelta(days=30),
    )
    await _seed_existing_risk(factory, patient_id=pid, system_code=SYSTEM_CODE_CVD, instrument_code=instrument_code)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    await dispatch_recalc(pid, None)

    # Пересчёт действительно запускался и был полным — иначе пустой риск-профиль ниже означал бы
    # лишь то, что команды не было, и «пересчитали и писать оказалось нечего» от неё было бы не
    # отличить.
    assert captured_app_logs.context_of("calc.run_recalc: started")["parameter_codes"] is None
    assert await db_read.count_results(patient_id=pid, instrument_code=instrument_code) == 0
    assert await db_read.count_interpretations(patient_id=pid, system_code=SYSTEM_CODE_CVD) == 0
    item = await _medical_risk_item(db_session, patient_id=pid, system_code=SYSTEM_CODE_CVD)
    assert item.interpretation_status == "not enough data"
    assert item.system_completion_percentage == 0


@pytest.mark.asyncio
async def test_answers_reset_replaces_result_of_instrument_sharing_the_parameter(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, patched_factory
) -> None:
    """Сброс одной системы гасит параметр, общий с опросником ДРУГОЙ системы.

    Ту систему клиент не сбрасывал, её `results` и `interpretations` сброс не трогал — но входа у
    её опросника больше нет. Полный пересчёт заменяет его результат заглушкой, и риск-профиль
    перестаёт утверждать риск по погашенному параметру.
    """
    pid = unique_id("p")
    reset_instrument = InstrumentsCodes.CVD.value
    sharing_instrument = InstrumentsCodes.URO.value
    shared_parameter = unique_id("sp")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _seed_single_instrument_system(
        db_session,
        factory,
        system_code=SYSTEM_CODE_CVD,
        instrument_code=reset_instrument,
        parameter_code=shared_parameter,
    )
    await _seed_system_sharing_parameter(
        db_session,
        factory,
        system_code=_SHARING_SYSTEM_CODE,
        instrument_code=sharing_instrument,
        parameter_code=shared_parameter,
    )
    await factory.answer(
        patient_id=pid,
        parameter_code=shared_parameter,
        value=_ANSWER_VALUE,
        source=ANSWER_SOURCE,
        expiration_date=now_utc() + timedelta(days=30),
    )
    await _seed_existing_risk(
        factory, patient_id=pid, system_code=_SHARING_SYSTEM_CODE, instrument_code=sharing_instrument
    )
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    # Сброс сам по себе чужую систему не трогает: её результат на месте, посчитан по параметру,
    # который сброс только что погасил, и риск-профиль всё ещё показывает по ней высокий риск.
    row = await db_read.result_row(patient_id=pid, instrument_code=sharing_instrument)
    assert row is not None
    assert float(row.value) == 1.0
    before = await _medical_risk_item(db_session, patient_id=pid, system_code=_SHARING_SYSTEM_CODE)
    assert before.risk is not None
    assert before.risk.risk_level == "high"

    await dispatch_recalc(pid, None)

    # Заглушка нерассчитанного опросника (wiki «Калькуляторы и опросники» §1.4.1): показателя нет,
    # инструмент неприменим, интерпретации по нему не требуется.
    row = await db_read.result_row(patient_id=pid, instrument_code=sharing_instrument)
    assert row is not None
    assert row.value is None
    assert row.applicability is False
    assert row.interpretation_status == "not_required"
    # Интерпретация системы пересчитана вместе с результатом: строка есть, но риска в ней уже нет.
    after = await _medical_risk_item(db_session, patient_id=pid, system_code=_SHARING_SYSTEM_CODE)
    assert after.interpretation_status == "completed"
    assert after.risk is None
    assert after.system_completion_percentage == 0
