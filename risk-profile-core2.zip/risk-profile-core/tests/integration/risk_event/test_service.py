"""End-to-end integration-тесты RiskEventService."""

from datetime import UTC, datetime, timedelta
from typing import NamedTuple
from unittest.mock import AsyncMock

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.emr_biomarkers.domain.constants import BIOMARKER_SOURCE
from src.services.risk_communication.domain.constants import ANSWER_SOURCE
from src.services.risk_communication.domain.exceptions import ClientNotFoundError
from src.services.risk_communication.domain.expiration import to_timedelta
from src.services.risk_event.domain.constants import (
    BODY_METRIC_PARAMETER_CODES,
    SYSTEM_CODE_CVD,
    SYSTEM_CODE_ENDO,
)
from src.services.risk_event.domain.exceptions import SystemCodeNotFoundError
from src.services.risk_event.service import RiskEventService
from src.services.risk_init.domain.bmi import compute_bmi
from src.services.risk_init.domain.constants import (
    AGE_PARAMETER_CODE,
    ANSWER_SOURCE_EMR,
    BMI_PARAMETER_CODE,
    GENDER_PARAMETER_CODE,
    HEIGHT_PARAMETER_CODE,
    WEIGHT_PARAMETER_CODE,
)
from src.services.risk_init.domain.numbers import format_number
from src.services.risk_profile.service import RiskProfileService
from tests.conftest import make_http_catalog
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_HEIGHT
from tests.db_assertions import DbRead
from tests.factories import Factory, now_utc, unique_id


def _future() -> datetime:
    return datetime.now(tz=UTC) + timedelta(days=10)


async def _make_service(session: AsyncSession) -> RiskEventService:
    await session.commit()
    return RiskEventService(session, await make_http_catalog(session))


# Демографические параметры, привязанные к CVD/ENDO, но исключаемые из сброса (gender, age).
PRESERVED_DEMOGRAPHIC_PARAMS = [(GENDER_PARAMETER_CODE, GENDER_FEMALE), (AGE_PARAMETER_CODE, "35")]


async def _wire_system_to_parameter(
    factory: Factory, *, system_code: str, parameter_code: str, create_parameter: bool = True
) -> None:
    """systems_instruments → instruments_parameters, чтобы reader нашёл параметр для системы.

    `create_parameter=False` — для кодов из сидов миграций (gender, age): своя строка parameters
    для них не заводится, инструмент теста ссылается на справочную.
    """
    instr_code = unique_id("i")
    if create_parameter:
        await factory.parameter(code=parameter_code)
    await factory.instrument(code=instr_code)
    await factory.link_parameter(instrument_code=instr_code, parameter_code=parameter_code)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instr_code)


async def _wire_system_instrument(factory: Factory, *, system_code: str, instrument_code: str) -> None:
    """systems_instruments запись — чтобы reader нашёл инструмент системы (для удаления results)."""
    await factory.instrument(code=instrument_code)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)


# --- Базовые проверки ---


@pytest.mark.asyncio
async def test_risk_calculation_client_not_found_raises(db_session: AsyncSession) -> None:
    service = await _make_service(db_session)
    with pytest.raises(ClientNotFoundError):
        await service.handle_risk_calculation(client_id="absent-client")


@pytest.mark.asyncio
async def test_risk_calculation_existing_client_is_noop(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await factory.answer(
        patient_id=pid, parameter_code=PARAMETER_CODE_HEIGHT, value="170", expiration_date=_future(), source="test-seed"
    )
    await db_session.commit()
    service = await _make_service(db_session)

    await service.handle_risk_calculation(client_id=pid)

    # ничего не изменилось
    assert await db_read.is_pregnant(patient_id=pid) is False
    exp = await db_read.answer_expiration(patient_id=pid, parameter_code=PARAMETER_CODE_HEIGHT)
    assert exp is not None
    assert exp > datetime.now(tz=UTC)
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=PARAMETER_CODE_HEIGHT) == 0


# --- pregnancy-end ---


@pytest.mark.asyncio
async def test_pregnancy_end_invalidates_cvd_endo_and_body_metrics(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    pid = unique_id("p")
    cvd_param = unique_id("cvdp")
    endo_param = unique_id("endop")
    unrelated_param = unique_id("up")

    await factory.patient(patient_id=pid, is_pregnant=True)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_CVD, parameter_code=cvd_param)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_ENDO, parameter_code=endo_param)
    await factory.parameter(code=unrelated_param)

    future = _future()
    # cvd_param с заведомо старым date_time — проверим, что архивация переносит его «как есть».
    cvd_param_dt = datetime.now(tz=UTC) - timedelta(days=100)
    await factory.answer(
        patient_id=pid,
        parameter_code=cvd_param,
        value="42",
        expiration_date=future,
        date_time=cvd_param_dt,
        source="test-seed",
    )
    for code in (endo_param, unrelated_param):
        await factory.answer(
            patient_id=pid, parameter_code=code, value="42", expiration_date=future, source="test-seed"
        )
    # BODY_METRIC_PARAMETER_CODES заведены сидами миграций — тест только отвечает за них.
    for code in BODY_METRIC_PARAMETER_CODES:
        await factory.answer(patient_id=pid, parameter_code=code, value="x", expiration_date=future, source="test-seed")
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_pregnancy_end(client_id=pid)

    assert await db_read.is_pregnant(patient_id=pid) is False
    now = datetime.now(tz=UTC)
    # CVD/ENDO + height/weight/bmi инвалидированы
    for code in (cvd_param, endo_param, *BODY_METRIC_PARAMETER_CODES):
        exp = await db_read.answer_expiration(patient_id=pid, parameter_code=code)
        assert exp is not None and exp < now
        assert await db_read.count_answer_history(patient_id=pid, parameter_code=code) == 1
    # date_time скопирован в history без изменений (оригинальный момент записи параметра).
    archived_dt = await db_read.answer_history_date_time(patient_id=pid, parameter_code=cvd_param)
    assert archived_dt == cvd_param_dt
    # несвязанный параметр не тронут
    unrelated_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=unrelated_param)
    assert unrelated_exp is not None and unrelated_exp > now
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=unrelated_param) == 0


@pytest.mark.asyncio
@pytest.mark.parametrize(("preserved_code", "preserved_value"), PRESERVED_DEMOGRAPHIC_PARAMS)
async def test_pregnancy_end_does_not_invalidate_demographic_param(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, preserved_code: str, preserved_value: str
) -> None:
    """gender и age привязаны к CVD (form_cvd) через instruments_parameters, но завершение
    беременности не меняет ни биологический пол, ни дату рождения (age — производный от неё) →
    запись в patients_parameters остаётся актуальной."""
    pid = unique_id("p")
    cvd_param = unique_id("cvdp")

    await factory.patient(patient_id=pid, is_pregnant=True)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_CVD, parameter_code=cvd_param)
    await _wire_system_to_parameter(
        factory, system_code=SYSTEM_CODE_CVD, parameter_code=preserved_code, create_parameter=False
    )

    future = _future()
    await factory.answer(
        patient_id=pid, parameter_code=cvd_param, value="42", expiration_date=future, source="test-seed"
    )
    await factory.answer(
        patient_id=pid, parameter_code=preserved_code, value=preserved_value, expiration_date=future, source="test-seed"
    )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_pregnancy_end(client_id=pid)

    now = datetime.now(tz=UTC)
    # обычный CVD-параметр инвалидирован
    cvd_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=cvd_param)
    assert cvd_exp is not None and cvd_exp < now
    # демографический параметр остаётся актуальным и не архивируется
    preserved_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=preserved_code)
    assert preserved_exp is not None and preserved_exp > now
    history_count = await db_read.count_answer_history(patient_id=pid, parameter_code=preserved_code)
    assert history_count == 0


@pytest.mark.asyncio
async def test_pregnancy_end_keeps_null_when_patient_never_answered_cq_030(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """is_pregnant=NULL не должен превращаться в False при pregnancy-end.

    Семантика: NULL = «никогда не отвечал на cq_030». Шаги 7/11 risk-communication
    исключают cq_030 из неотвеченных параметров при IS NOT NULL — поэтому случайный
    NULL→False навсегда отнимет у пациента возможность ответить на cq_030.
    pregnancy-end сбрасывает только реальную беременность (True → False).
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=None)
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_pregnancy_end(client_id=pid)

    assert await db_read.is_pregnant(patient_id=pid) is None


@pytest.mark.asyncio
async def test_pregnancy_end_is_idempotent(db_session: AsyncSession, factory: Factory, db_read: DbRead) -> None:
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=True)
    # BODY_METRIC_PARAMETER_CODES заведены сидами миграций — тест только отвечает за них.
    for code in BODY_METRIC_PARAMETER_CODES:
        await factory.answer(
            patient_id=pid, parameter_code=code, value="x", expiration_date=_future(), source="test-seed"
        )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_pregnancy_end(client_id=pid)
    await service.handle_pregnancy_end(client_id=pid)  # повтор не должен задваивать history

    for code in BODY_METRIC_PARAMETER_CODES:
        assert await db_read.count_answer_history(patient_id=pid, parameter_code=code) == 1


# --- answers-reset ---


@pytest.mark.asyncio
async def test_answers_reset_unknown_system_raises_and_rolls_back(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    pid = unique_id("p")
    param_code = unique_id("mp")
    await factory.patient(patient_id=pid)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_CVD, parameter_code=param_code)
    await factory.answer(
        patient_id=pid, parameter_code=param_code, value="x", expiration_date=_future(), source="test-seed"
    )
    await db_session.commit()

    service = await _make_service(db_session)
    with pytest.raises(SystemCodeNotFoundError):
        await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD, "UNKNOWN"])

    # БД не изменена — параметр всё ещё активный, ничего в history нет
    exp = await db_read.answer_expiration(patient_id=pid, parameter_code=param_code)
    assert exp is not None and exp > datetime.now(tz=UTC)
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=param_code) == 0


@pytest.mark.asyncio
async def test_answers_reset_non_body_system_leaves_body_metrics_alone(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    pid = unique_id("p")
    mental_param = unique_id("mp")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _wire_system_to_parameter(factory, system_code="MENTAL", parameter_code=mental_param)
    await factory.answer(
        patient_id=pid, parameter_code=mental_param, value="m", expiration_date=_future(), source="test-seed"
    )
    # BODY_METRIC_PARAMETER_CODES заведены сидами миграций — тест только отвечает за них.
    for code in BODY_METRIC_PARAMETER_CODES:
        await factory.answer(
            patient_id=pid, parameter_code=code, value="x", expiration_date=_future(), source="test-seed"
        )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=["MENTAL"])

    now = datetime.now(tz=UTC)
    mental_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=mental_param)
    assert mental_exp is not None and mental_exp < now
    for code in BODY_METRIC_PARAMETER_CODES:
        body_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=code)
        assert body_exp is not None and body_exp > now
    assert await db_read.is_pregnant(patient_id=pid) is False


@pytest.mark.asyncio
async def test_answers_reset_non_body_system_clears_pregnancy_for_pregnant_patient(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
) -> None:
    """Беременная пациентка + answers-reset по не-CVD/ENDO системе → is_pregnant=False,
    body metrics не тронуты. Покрывает unconditional clear для не-body систем."""
    pid = unique_id("p")
    mental_param = unique_id("mp")
    await factory.patient(patient_id=pid, is_pregnant=True)
    await _wire_system_to_parameter(factory, system_code="MENTAL", parameter_code=mental_param)
    await factory.answer(
        patient_id=pid, parameter_code=mental_param, value="m", expiration_date=_future(), source="test-seed"
    )
    # BODY_METRIC_PARAMETER_CODES заведены сидами миграций — тест только отвечает за них.
    for code in BODY_METRIC_PARAMETER_CODES:
        await factory.answer(
            patient_id=pid, parameter_code=code, value="x", expiration_date=_future(), source="test-seed"
        )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=["MENTAL"])

    assert await db_read.is_pregnant(patient_id=pid) is False
    now = datetime.now(tz=UTC)
    for code in BODY_METRIC_PARAMETER_CODES:
        body_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=code)
        assert body_exp is not None and body_exp > now


@pytest.mark.asyncio
@pytest.mark.parametrize(("preserved_code", "preserved_value"), PRESERVED_DEMOGRAPHIC_PARAMS)
async def test_answers_reset_does_not_invalidate_demographic_param(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, preserved_code: str, preserved_value: str
) -> None:
    """gender и age привязаны к CVD (form_cvd) через instruments_parameters, но answers-reset
    не меняет ни биологический пол, ни дату рождения (age — производный от неё) → запись в
    patients_parameters остаётся актуальной."""
    pid = unique_id("p")
    cvd_param = unique_id("cvdp")

    await factory.patient(patient_id=pid)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_CVD, parameter_code=cvd_param)
    await _wire_system_to_parameter(
        factory, system_code=SYSTEM_CODE_CVD, parameter_code=preserved_code, create_parameter=False
    )

    future = _future()
    await factory.answer(
        patient_id=pid, parameter_code=cvd_param, value="42", expiration_date=future, source="test-seed"
    )
    await factory.answer(
        patient_id=pid, parameter_code=preserved_code, value=preserved_value, expiration_date=future, source="test-seed"
    )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    now = datetime.now(tz=UTC)
    # обычный CVD-параметр инвалидирован
    cvd_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=cvd_param)
    assert cvd_exp is not None and cvd_exp < now
    # демографический параметр остаётся актуальным и не архивируется
    preserved_exp = await db_read.answer_expiration(patient_id=pid, parameter_code=preserved_code)
    assert preserved_exp is not None and preserved_exp > now
    history_count = await db_read.count_answer_history(patient_id=pid, parameter_code=preserved_code)
    assert history_count == 0


@pytest.mark.asyncio
async def test_answers_reset_cvd_invalidates_body_metrics_and_clears_pregnancy(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
) -> None:
    pid = unique_id("p")
    cvd_param = unique_id("cvdp")
    await factory.patient(patient_id=pid, is_pregnant=True)
    await _wire_system_to_parameter(factory, system_code=SYSTEM_CODE_CVD, parameter_code=cvd_param)
    await factory.answer(
        patient_id=pid, parameter_code=cvd_param, value="c", expiration_date=_future(), source="test-seed"
    )
    # BODY_METRIC_PARAMETER_CODES заведены сидами миграций — тест только отвечает за них.
    for code in BODY_METRIC_PARAMETER_CODES:
        await factory.answer(
            patient_id=pid, parameter_code=code, value="x", expiration_date=_future(), source="test-seed"
        )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[SYSTEM_CODE_CVD])

    now = datetime.now(tz=UTC)
    assert await db_read.is_pregnant(patient_id=pid) is False
    for code in (cvd_param, *BODY_METRIC_PARAMETER_CODES):
        exp = await db_read.answer_expiration(patient_id=pid, parameter_code=code)
        assert exp is not None and exp < now
        assert await db_read.count_answer_history(patient_id=pid, parameter_code=code) == 1


# --- архивация и удаление results/interpretations (#156) ---


@pytest.mark.asyncio
async def test_answers_reset_archives_and_deletes_results_and_interpretations(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Основной сценарий #156: сброс системы S1 удаляет и архивирует её results/interpretations,
    контрольная система S2 не тронута. Проверяем перенос ВСЕХ полей — включая NULL-значения и
    исходный date_time («как есть», критерий тикета)."""
    pid = unique_id("p")
    s1, s2 = "MENTAL", "ONCO"
    s1_instr = unique_id("i1")
    s2_instr = unique_id("i2")
    await factory.patient(patient_id=pid)
    await _wire_system_instrument(factory, system_code=s1, instrument_code=s1_instr)
    await _wire_system_instrument(factory, system_code=s2, instrument_code=s2_instr)

    now = now_utc()
    result_dt = now - timedelta(days=7)
    exp = now + timedelta(days=30)
    interp_dt = now - timedelta(days=3)
    # S1-result: value=NULL (и NULL risk_level/unit по дефолту сида) — покрываем перенос NULL «как есть».
    await factory.result(patient_id=pid, instrument_code=s1_instr, value=None, date_time=result_dt, expiration_date=exp)
    await factory.result(
        patient_id=pid, instrument_code=s2_instr, value="2.5", date_time=result_dt, expiration_date=exp
    )
    # S1-интерпретация: смесь NULL (text/risk_factors_code) и не-NULL (risk_level/diseases/doctors_code).
    await factory.interpretation(
        patient_id=pid,
        system_code=s1,
        date_time=interp_dt,
        risk_level="high",
        text_value=None,
        diseases=["d1"],
        risk_factors_code=None,
        doctors_code=["1"],
    )
    await factory.interpretation(patient_id=pid, system_code=s2, date_time=interp_dt, risk_level="medium")
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[s1])

    # S1: results удалены и лежат в history со всеми полями «как есть».
    assert await db_read.count_results(patient_id=pid, instrument_code=s1_instr) == 0
    archived_results = await db_read.results_history(patient_id=pid, instrument_code=s1_instr)
    assert archived_results == [
        {
            "instrument_code": s1_instr,
            "patient_id": pid,
            "value": None,
            "indicator": "result",
            "date_time": result_dt,
            "interpretation_status": "ready",
            "expiration_date": exp,
            "risk_level": None,
            "applicability": True,
            "unit": None,
        }
    ]
    # S1: interpretation удалена и заархивирована — все поля, включая NULL и исходный date_time.
    assert await db_read.count_interpretations(patient_id=pid, system_code=s1) == 0
    archived_interp = await db_read.interpretations_history(patient_id=pid, system_code=s1)
    assert archived_interp == [
        {
            "system_code": s1,
            "patient_id": pid,
            "risk_level": "high",
            "text": None,
            "diseases": ["d1"],
            "risk_factors_code": None,
            "doctors_code": ["1"],
            "date_time": interp_dt,
        }
    ]

    # S2: results и interpretation не тронуты, в history пусто.
    assert await db_read.count_results(patient_id=pid, instrument_code=s2_instr) == 1
    assert await db_read.count_results_history(patient_id=pid, instrument_code=s2_instr) == 0
    assert await db_read.count_interpretations(patient_id=pid, system_code=s2) == 1
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=s2) == 0


@pytest.mark.asyncio
async def test_answers_reset_is_idempotent_for_results_and_interpretations(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Повторный тот же event не задваивает history: удалять уже нечего (natural idempotency)."""
    pid = unique_id("p")
    sys_code = "MENTAL"
    instr_code = unique_id("i")
    await factory.patient(patient_id=pid)
    await _wire_system_instrument(factory, system_code=sys_code, instrument_code=instr_code)

    now = now_utc()
    await factory.result(
        patient_id=pid,
        instrument_code=instr_code,
        value="1.0",
        date_time=now - timedelta(days=1),
        expiration_date=now + timedelta(days=30),
    )
    await factory.interpretation(
        patient_id=pid, system_code=sys_code, date_time=now - timedelta(days=1), risk_level="high"
    )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[sys_code])
    await service.handle_answers_reset(client_id=pid, system_codes=[sys_code])  # повтор — no-op

    assert await db_read.count_results(patient_id=pid, instrument_code=instr_code) == 0
    assert await db_read.count_results_history(patient_id=pid, instrument_code=instr_code) == 1
    assert await db_read.count_interpretations(patient_id=pid, system_code=sys_code) == 0
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=sys_code) == 1


@pytest.mark.asyncio
async def test_answers_reset_system_without_instruments_still_deletes_interpretation(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Система без systems_instruments: results трогать нечего (0 удалённых, без ошибки),
    но interpretation этой системы всё равно архивируется и удаляется."""
    pid = unique_id("p")
    sys_code = "NEURO"  # реальная система, но без привязанных инструментов у этого пациента
    await factory.patient(patient_id=pid)
    now = now_utc()
    await factory.interpretation(
        patient_id=pid, system_code=sys_code, date_time=now - timedelta(days=1), risk_level="medium"
    )
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[sys_code])

    assert await db_read.count_interpretations(patient_id=pid, system_code=sys_code) == 0
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=sys_code) == 1


@pytest.mark.asyncio
async def test_pregnancy_end_archives_and_deletes_cvd_endo_results_and_interpretations(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
) -> None:
    """pregnancy-end удаляет/архивирует results+interpretations систем CVD и ENDO безусловно
    (даже у небеременной — как и инвалидация параметров); контрольная система не тронута,
    is_pregnant остаётся False."""
    pid = unique_id("p")
    cvd_instr = unique_id("icvd")
    endo_instr = unique_id("iendo")
    onco_instr = unique_id("ionco")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _wire_system_instrument(factory, system_code=SYSTEM_CODE_CVD, instrument_code=cvd_instr)
    await _wire_system_instrument(factory, system_code=SYSTEM_CODE_ENDO, instrument_code=endo_instr)
    await _wire_system_instrument(factory, system_code="ONCO", instrument_code=onco_instr)

    now = now_utc()
    result_dt = now - timedelta(days=2)
    exp = now + timedelta(days=30)
    for instr in (cvd_instr, endo_instr, onco_instr):
        await factory.result(
            patient_id=pid, instrument_code=instr, value="1.0", date_time=result_dt, expiration_date=exp
        )
    for scode in (SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO, "ONCO"):
        await factory.interpretation(patient_id=pid, system_code=scode, date_time=result_dt, risk_level="high")
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_pregnancy_end(client_id=pid)

    assert await db_read.is_pregnant(patient_id=pid) is False
    for instr in (cvd_instr, endo_instr):
        assert await db_read.count_results(patient_id=pid, instrument_code=instr) == 0
        assert await db_read.count_results_history(patient_id=pid, instrument_code=instr) == 1
    for scode in (SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO):
        assert await db_read.count_interpretations(patient_id=pid, system_code=scode) == 0
        assert await db_read.count_interpretations_history(patient_id=pid, system_code=scode) == 1
    # Контрольная система ONCO не тронута.
    assert await db_read.count_results(patient_id=pid, instrument_code=onco_instr) == 1
    assert await db_read.count_results_history(patient_id=pid, instrument_code=onco_instr) == 0
    assert await db_read.count_interpretations(patient_id=pid, system_code="ONCO") == 1
    assert await db_read.count_interpretations_history(patient_id=pid, system_code="ONCO") == 0


@pytest.mark.asyncio
async def test_medical_risk_after_answers_reset_returns_not_enough_data(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Приёмочный критерий #156: после answers-reset риск-профиль по системе больше не показывает риск —
    interpretationStatus='not enough data', risk=None, удалённый result не учитывается в lastCalculation."""
    pid = unique_id("p")
    sys_code = "MENTAL"
    instr_code = unique_id("i")
    param_code = unique_id("mp")
    now = now_utc()

    await factory.patient(patient_id=pid, is_pregnant=False)
    await factory.parameter(code=param_code)
    await factory.instrument(code=instr_code)
    await factory.link_parameter(instrument_code=instr_code, parameter_code=param_code)
    await factory.link_system_instrument(system_code=sys_code, instrument_code=instr_code)
    await factory.result(
        patient_id=pid,
        instrument_code=instr_code,
        value="1.0",
        date_time=now - timedelta(hours=1),
        expiration_date=now + timedelta(days=30),
    )
    await factory.interpretation(
        patient_id=pid,
        system_code=sys_code,
        date_time=now - timedelta(hours=1),
        risk_level="high",
        text_value="Высокий риск",
    )
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[sys_code])

    response = await RiskProfileService(db_session, await make_http_catalog(db_session)).get_medical_risk(
        client_id=pid, system_code=sys_code
    )

    assert len(response.system_interpretation_results) == 1
    item = response.system_interpretation_results[0]
    assert item.interpretation_status == "not enough data"
    assert item.risk is None
    assert response.last_calculation_date_time is None


@pytest.mark.asyncio
async def test_answers_reset_deletes_results_of_instrument_shared_with_other_system(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
) -> None:
    """Pin-тест намеренного поведения по вики (answers-reset, шаг 8): удаляемые results берутся из
    перечня инструментов сбрасываемых систем БЕЗ вычета инструментов, шаренных с другими системами.

    Инструмент I привязан и к сбрасываемой S1, и к нетронутой S2 → его result всё равно удаляется
    и архивируется (по вхождению в systems_instruments S1). Интерпретация S2 при этом не трогается —
    удаление интерпретаций идёт строго по переданным системам, а не по инструментам.
    """
    pid = unique_id("p")
    s1, s2 = "MENTAL", "ONCO"
    shared_instr = unique_id("i")
    await factory.patient(patient_id=pid)
    # Один инструмент, привязанный к двум системам (insert_instrument однократно, две привязки).
    await factory.instrument(code=shared_instr)
    await factory.link_system_instrument(system_code=s1, instrument_code=shared_instr)
    await factory.link_system_instrument(system_code=s2, instrument_code=shared_instr)

    now = now_utc()
    await factory.result(
        patient_id=pid,
        instrument_code=shared_instr,
        value="1.0",
        date_time=now - timedelta(days=1),
        expiration_date=now + timedelta(days=30),
    )
    await factory.interpretation(patient_id=pid, system_code=s1, date_time=now - timedelta(days=1), risk_level="high")
    await factory.interpretation(patient_id=pid, system_code=s2, date_time=now - timedelta(days=1), risk_level="medium")
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[s1])

    # result шаренного инструмента удалён и заархивирован — несмотря на привязку к нетронутой S2.
    assert await db_read.count_results(patient_id=pid, instrument_code=shared_instr) == 0
    assert await db_read.count_results_history(patient_id=pid, instrument_code=shared_instr) == 1
    # интерпретация S1 удалена+заархивирована, S2 — не тронута и в history пусто.
    assert await db_read.count_interpretations(patient_id=pid, system_code=s1) == 0
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=s1) == 1
    assert await db_read.count_interpretations(patient_id=pid, system_code=s2) == 1
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=s2) == 0


# --- реконсиляция производного bmi (#139) ---
#
# Тесты идут по РЕАЛЬНОМУ справочнику из сидов миграций, а не по синтетической обвязке
# `_wire_system_to_parameter`: суть дефекта — именно в проливке 0104, где bmi привязан к
# form_uro/form_trauma, а height/weight — только к stop_bang/findrisk/form_common. Синтетика
# воспроизвела бы не тот баг.

_SEED_HEIGHT = "175"
_SEED_WEIGHT = "72"
# Заведомо НЕ равен compute_bmi(175, 72) = 23.51 — иначе проверки «значение не пересчитывалось»
# проходили бы и при сработавшей реконсиляции.
_SEED_BMI = "30"
# Системы, чей сброс гасит bmi, не трогая источники (URO → form_uro, TRAUMA → form_trauma).
# RESP в тот же список не входит: у него есть stop_bang, который несёт и height, и weight.
BMI_ORPHANING_SYSTEMS = ["URO", "TRAUMA"]


class _WrongClock:
    """Заглушка `src.services.risk_event.service.datetime` с заведомо неправильным `now()`.

    Четверть века назад — так что утечка часов приложения в запись видна невооружённым глазом:
    и `date_time`, и посчитанный от него `expiration_date` уехали бы в прошлое.
    """

    @staticmethod
    def now(tz: object = None) -> datetime:  # noqa: ARG004 — сигнатура ради совместимости с datetime
        return datetime(2000, 1, 1, tzinfo=UTC)


async def _seed_anthropometry(
    factory: Factory,
    *,
    patient_id: str,
    height: str | None = _SEED_HEIGHT,
    weight: str | None = _SEED_WEIGHT,
    bmi: str | None = _SEED_BMI,
    bmi_source: str = "EMR",
    bmi_date_time: datetime | None = None,
    sources_expiration: datetime | None = None,
) -> None:
    """height/weight/bmi пациента. insert_parameter НЕ зовём: коды уже есть в справочнике из
    сидов миграций, и нам нужен их настоящий validity_period (тест на expiration_date)."""
    expiration = sources_expiration if sources_expiration is not None else _future()
    for code, value in ((HEIGHT_PARAMETER_CODE, height), (WEIGHT_PARAMETER_CODE, weight)):
        if value is not None:
            await factory.answer(
                patient_id=patient_id, parameter_code=code, value=value, expiration_date=expiration, source="EMR"
            )
    if bmi is not None:
        await factory.answer(
            patient_id=patient_id,
            parameter_code=BMI_PARAMETER_CODE,
            value=bmi,
            expiration_date=_future(),
            source=bmi_source,
            date_time=bmi_date_time,
        )


@pytest.mark.asyncio
@pytest.mark.parametrize("system_code", BMI_ORPHANING_SYSTEMS)
async def test_answers_reset_reconciles_orphaned_bmi(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, system_code: str
) -> None:
    """Главный сценарий #139: сброс системы, гасящей только производный bmi, не оставляет
    невосстановимого состояния — bmi пересчитывается из актуальных height/weight."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[system_code])

    now = datetime.now(tz=UTC)
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    assert bmi_row["value"] == format_number(compute_bmi(float(_SEED_HEIGHT), float(_SEED_WEIGHT)))
    assert bmi_row["expiration_date"] > now
    # Источники не тронуты: они не привязаны к инструментам этой системы и не архивировались.
    for code in (HEIGHT_PARAMETER_CODE, WEIGHT_PARAMETER_CODE):
        source_row = await db_read.answer_columns(patient_id=pid, parameter_code=code)
        assert source_row is not None and source_row["expiration_date"] > now
        assert await db_read.count_answer_history(patient_id=pid, parameter_code=code) == 0
    # Реконсиляция bmi признак беременности не трогает: сброс не переводил его из true.
    assert await db_read.is_pregnant(patient_id=pid) is False


@pytest.mark.asyncio
async def test_answers_reset_archives_stale_bmi_with_original_date_time(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Перезаписываемая строка bmi уезжает в history с ОРИГИНАЛЬНЫМ date_time.

    Записей две: первую пишет инвалидация (актуальная строка), вторую — реконсиляция
    (та же строка уже с прошлым expiration_date). date_time у обеих — момент исходной записи.
    """
    pid = unique_id("p")
    original_dt = datetime.now(tz=UTC) - timedelta(days=100)
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, bmi_date_time=original_dt)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    archived = await db_read.answer_history(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert len(archived) == 2
    assert [row["date_time"] for row in archived] == [original_dt, original_dt]
    assert [row["value"] for row in archived] == [_SEED_BMI, _SEED_BMI]
    # Вторая копия — уже протухшая: именно её заменила реконсиляция.
    assert archived[1]["expiration_date"] < datetime.now(tz=UTC)


@pytest.mark.asyncio
@pytest.mark.parametrize("system_code", [SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO])
async def test_answers_reset_cvd_endo_does_not_resurrect_bmi(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, system_code: str
) -> None:
    """Сценарий #136 не сломан: CVD/ENDO гасят и источники, поэтому реконсилировать не из чего —
    bmi восстановится позже, когда клиент заново введёт рост и вес."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[system_code])

    now = datetime.now(tz=UTC)
    for code in BODY_METRIC_PARAMETER_CODES:
        row = await db_read.answer_columns(patient_id=pid, parameter_code=code)
        assert row is not None and row["expiration_date"] < now
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None and bmi_row["value"] == _SEED_BMI  # значение не пересчитывалось
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=BMI_PARAMETER_CODE) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("stale_code", [HEIGHT_PARAMETER_CODE, WEIGHT_PARAMETER_CODE])
async def test_answers_reset_skips_reconciliation_when_single_source_actual(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, stale_code: str
) -> None:
    """Один протухший источник → ИМТ считать не из чего: посчитанный из устаревшего значения
    «свежий» bmi врал бы (та же логика, что в risk_communication._derive_bmi)."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid)
    await factory.expire_answer(patient_id=pid, parameter_code=stale_code)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    assert bmi_row["value"] == _SEED_BMI
    assert bmi_row["expiration_date"] < datetime.now(tz=UTC)


@pytest.mark.asyncio
async def test_answers_reset_leaves_actual_bmi_untouched(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Система без bmi в инструментах (MENTAL → bdi/stai): строка bmi остаётся актуальной,
    реконсиляция её не перезаписывает и не плодит записей в history."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["MENTAL"])

    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    assert bmi_row["value"] == _SEED_BMI
    assert bmi_row["expiration_date"] > datetime.now(tz=UTC)
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=BMI_PARAMETER_CODE) == 0


@pytest.mark.asyncio
async def test_answers_reset_without_bmi_row_does_not_create_it(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Пациент никогда не проходил /anthropometry и не отвечал на cq_040/cq_050 — легальное
    состояние: реконсиляция чинит испорченное, а не создаёт bmi с нуля (наследовать source неоткуда)."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, bmi=None)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    assert await db_read.is_pregnant(patient_id=pid) is False
    assert await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE) is None


@pytest.mark.asyncio
@pytest.mark.parametrize(("height", "weight"), [("нет данных", _SEED_WEIGHT), (_SEED_HEIGHT, "0")])
async def test_answers_reset_skips_reconciliation_on_unparsable_sources(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, height: str, weight: str
) -> None:
    """В value лежит текст: нечисловое значение и ноль (рост — знаменатель ИМТ) не должны
    ронять событие — реконсиляция просто не выполняется."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, height=height, weight=weight)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    assert bmi_row["value"] == _SEED_BMI
    assert bmi_row["expiration_date"] < datetime.now(tz=UTC)


@pytest.mark.asyncio
@pytest.mark.parametrize("source", ["EMR", "FORM"])
async def test_answers_reset_reconciliation_keeps_source(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, source: str
) -> None:
    """Реконсиляция не меняет происхождение значения: source переносится с заменяемой строки."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, bmi_source=source)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None and bmi_row["source"] == source


@pytest.mark.asyncio
async def test_answers_reset_reconciled_bmi_expiration_comes_from_catalog(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Срок жизни — по правилу пути анкеты (#136): now + (parameters.validity_period − epoch).
    Отдельного правила для реконсиляции не заводим (расхождение сроков — Вопрос 2 #139)."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    validity = await db_read.parameter_validity(parameter_code=BMI_PARAMETER_CODE)
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    # date_time — тот же серверный now, из которого считался expiration_date.
    assert bmi_row["expiration_date"] == bmi_row["date_time"] + to_timedelta(validity)


@pytest.mark.asyncio
async def test_answers_reset_reconciliation_ignores_application_clock(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Источник времени — только серверный now() БД, часы приложения на результат не влияют.

    Регрессионный якорь, а не проверка текущего поведения: сегодня `_reconcile_bmi` вообще не
    зовёт `datetime.now`, поэтому подмена ни на что не влияет и тест зелёный. Он падает ровно
    тогда, когда кто-нибудь переключит `get_db_now()` на `datetime.now(UTC)` — расхождение часов
    приложения и БД дало бы плавающий результат относительно предиката `expiration_date > now()`,
    по которому актуальность считает SQL остальных шагов события.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()
    monkeypatch.setattr("src.services.risk_event.service.datetime", _WrongClock)

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    real_now = datetime.now(tz=UTC)
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None
    # Реконсиляция отработала так же, как без подмены.
    assert bmi_row["value"] == format_number(compute_bmi(float(_SEED_HEIGHT), float(_SEED_WEIGHT)))
    # И момент записи, и срок жизни отсчитаны от РЕАЛЬНОГО серверного времени: с часов приложения
    # date_time уехал бы в 2000 год, а expiration_date оказался бы давно протухшим.
    assert abs(bmi_row["date_time"] - real_now) < timedelta(minutes=1)
    assert bmi_row["expiration_date"] > real_now
    validity = await db_read.parameter_validity(parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row["expiration_date"] == bmi_row["date_time"] + to_timedelta(validity)


# --- ПДн в логах реконсиляции (#139) ---
#
# Рост, вес и сам ИМТ — персональные данные, и `MonologFormatter` их не спасёт: он маскирует по
# СПИСКУ ключей, а `has_height`/`bmi_reconciled` в нём не значатся. Значит инвариант держится
# только на дисциплине вызывающего, и проверять его надо по фактической полезной нагрузке.
#
# Сиды тут свои, «неокруглые»: у значений по умолчанию ("175"/"72"/"30") есть шанс совпасть
# с безобидным счётчиком вроде params_count, и тест начал бы врать в обе стороны.
_PII_HEIGHT = "177"
_PII_WEIGHT = "73.77"
_PII_STALE_BMI = "31.31"
_PII_RECONCILED_BMI = format_number(compute_bmi(float(_PII_HEIGHT), float(_PII_WEIGHT)))
_PII_VALUES = (_PII_HEIGHT, _PII_WEIGHT, _PII_STALE_BMI, _PII_RECONCILED_BMI)


def _leaf_values(value: object) -> list[object]:
    """Все листовые значения контекста — включая вложенные в списки (system_codes) и словари."""
    if isinstance(value, dict):
        return [leaf for item in value.values() for leaf in _leaf_values(item)]
    if isinstance(value, list | tuple | set):
        return [leaf for item in value for leaf in _leaf_values(item)]
    return [value]


def _assert_no_parameter_values(context: dict[str, object], values: tuple[str, ...]) -> None:
    """Ни под каким ключом — сравнение по ЗНАЧЕНИЯМ, а не по списку ожидаемых ключей.

    Список ключей проверял бы только то, что мы уже написали; появление нового поля с ПДн такой
    тест бы пропустил. Значения на входе — числовые строки, поэтому одна проверка ловит утечку
    в обоих видах.
    """
    # И строкой, и числом: значение может утечь в контекст в любом из двух видов.
    forbidden: set[object] = {*values, *(float(item) for item in values)}
    for leaf in _leaf_values(context):
        assert leaf not in forbidden, f"в log_context утекло значение параметра: {leaf!r}"
        assert str(leaf) not in forbidden, f"в log_context утекло значение параметра: {leaf!r}"


def _assert_no_anthropometry_values(context: dict[str, object]) -> None:
    """Рост, вес и ИМТ — те значения, ради которых проверка и написана."""
    _assert_no_parameter_values(context, _PII_VALUES)


def _capture_notices(monkeypatch: pytest.MonkeyPatch) -> list[tuple[str, dict[str, object]]]:
    """Перехват фактических вызовов `notice` из сервиса.

    Не caplog: логгер "app" поднят с propagate=False и до root-хендлера caplog не доходит
    (тот же приём уже применён в tests/integration/interpretation/test_calc_integration.py).
    """
    captured: list[tuple[str, dict[str, object]]] = []

    def _record(message: str, context: dict[str, object] | None = None) -> None:
        captured.append((message, context or {}))

    monkeypatch.setattr("src.services.risk_event.service.notice", _record)
    return captured


def _context_of(captured: list[tuple[str, dict[str, object]]], marker: str) -> dict[str, object]:
    matched = [context for message, context in captured if marker in message]
    assert len(matched) == 1, f"ожидалась ровно одна запись со словом {marker!r}, получено {len(matched)}"
    return matched[0]


@pytest.mark.asyncio
async def test_reconciliation_skip_log_has_flags_and_no_personal_data(
    db_session: AsyncSession, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Лог пропуска: булевы флаги наличия источников — да, значения роста/веса/ИМТ — нет."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, height=_PII_HEIGHT, weight=_PII_WEIGHT, bmi=_PII_STALE_BMI)
    await factory.expire_answer(patient_id=pid, parameter_code=WEIGHT_PARAMETER_CODE)
    await db_session.commit()
    captured = _capture_notices(monkeypatch)

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    context = _context_of(captured, "reconciliation skipped")
    assert context["has_height"] is True
    assert context["has_weight"] is False
    _assert_no_anthropometry_values(context)


@pytest.mark.asyncio
async def test_successful_reconciliation_log_has_no_bmi_value(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Лог успеха: происхождение значения (`source`) диагностически нужно, само значение — ПДн."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    await _seed_anthropometry(factory, patient_id=pid, height=_PII_HEIGHT, weight=_PII_WEIGHT, bmi=_PII_STALE_BMI)
    await db_session.commit()
    captured = _capture_notices(monkeypatch)

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=["URO"])

    # Реконсиляция действительно отработала — иначе проверять было бы нечего.
    bmi_row = await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    assert bmi_row is not None and bmi_row["value"] == _PII_RECONCILED_BMI
    _assert_no_anthropometry_values(_context_of(captured, "bmi reconciled"))
    # Итоговая сводка события отдаёт только факт починки, не значение.
    _assert_no_anthropometry_values(_context_of(captured, "answers-reset applied"))


@pytest.mark.asyncio
async def test_pregnancy_end_does_not_reconcile_bmi(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Пин-тест: pregnancy-end гасит height/weight/bmi всегда и вместе — воскрешать нечего."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=True)
    await _seed_anthropometry(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_pregnancy_end(client_id=pid)

    now = datetime.now(tz=UTC)
    for code in BODY_METRIC_PARAMETER_CODES:
        row = await db_read.answer_columns(patient_id=pid, parameter_code=code)
        assert row is not None and row["expiration_date"] < now


# --- биомаркеры ЭМК не сбрасываются (#264) ---
#
# Запись биомаркера ЭМК узнаётся по ПАРЕ условий: `source = EMR` И заполненный `external_id`.
# Одного происхождения мало — антропометрия из risk-init пишется тем же `source`, но без
# идентификатора экземпляра значения в системе-источнике, и сброс её не щадит.
#
# Значения сидов — числовые строки, «неокруглые» и не совпадающие ни с одним счётчиком события:
# по ним же проверяется, что в контекст лога не утекли значения параметров.
_BIOMARKER_EXTERNAL_ID = 90_001
_BIOMARKER_VALUE = "5.55"
_FORM_ANSWER_VALUE = "17.71"
_EMR_ANTHROPOMETRY_VALUE = "181.81"
_SEEDED_VALUES = (_BIOMARKER_VALUE, _FORM_ANSWER_VALUE, _EMR_ANTHROPOMETRY_VALUE)


class _MixedSourceSystem(NamedTuple):
    """Система из трёх параметров разного происхождения и ожидаемая строка её биомаркера ЭМК."""

    system_code: str
    form_param: str
    biomarker_param: str
    biomarker_row: dict[str, object]


async def _seed_emr_biomarker(
    factory: Factory,
    *,
    patient_id: str,
    parameter_code: str,
    external_id: int = _BIOMARKER_EXTERNAL_ID,
) -> dict[str, object]:
    """Запись биомаркера ЭМК. Возвращает строку `patients_parameters` целиком — ту, с которой
    тест сверяет её после сброса: сохранение означает неизменность ВСЕХ колонок, а не только
    актуального `expiration_date`."""
    expiration = _future()
    date_time = now_utc() - timedelta(days=3)
    await factory.answer(
        patient_id=patient_id,
        parameter_code=parameter_code,
        value=_BIOMARKER_VALUE,
        source=BIOMARKER_SOURCE,
        external_id=external_id,
        expiration_date=expiration,
        date_time=date_time,
    )
    return {
        "value": _BIOMARKER_VALUE,
        "source": BIOMARKER_SOURCE,
        "external_id": external_id,
        "expiration_date": expiration,
        "date_time": date_time,
    }


async def _seed_mixed_source_system(factory: Factory, *, patient_id: str) -> _MixedSourceSystem:
    """Система ровно из трёх параметров: ответ клиента, биомаркер ЭМК и антропометрия из ЭМК.

    Своя система, а не одна из справочника: тест сверяет числа в событии сброса, и считаться они
    должны от известного набора кодов, а не от текущего наполнения справочника. Антропометрия —
    настоящий `height`, потому что именно она и есть та запись с `source = EMR` и пустым
    `external_id`, из-за которой предикат исключения не может быть одним условием.
    """
    system_code = await factory.system(unique_id("SYS"))
    form_param = unique_id("fp")
    biomarker_param = unique_id("bp")
    for parameter_code in (form_param, biomarker_param):
        await _wire_system_to_parameter(factory, system_code=system_code, parameter_code=parameter_code)
    await _wire_system_to_parameter(
        factory, system_code=system_code, parameter_code=HEIGHT_PARAMETER_CODE, create_parameter=False
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code=form_param,
        value=_FORM_ANSWER_VALUE,
        source=ANSWER_SOURCE,
        expiration_date=_future(),
    )
    await factory.answer(
        patient_id=patient_id,
        parameter_code=HEIGHT_PARAMETER_CODE,
        value=_EMR_ANTHROPOMETRY_VALUE,
        source=ANSWER_SOURCE_EMR,
        expiration_date=_future(),
    )
    biomarker_row = await _seed_emr_biomarker(factory, patient_id=patient_id, parameter_code=biomarker_param)
    return _MixedSourceSystem(system_code, form_param, biomarker_param, biomarker_row)


@pytest.mark.asyncio
async def test_answers_reset_keeps_emr_biomarker_and_resets_other_sources(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Шаг 5 wiki: из отбора выпадают только записи биомаркеров ЭМК.

    Ответ клиента и антропометрия из ЭМК гасятся и уезжают в историю как прежде — иначе фильтр
    был бы построен по одному `source` и унёс бы из сброса рост, вес и дату рождения.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    seeded = await _seed_mixed_source_system(factory, patient_id=pid)
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[seeded.system_code])

    # Биомаркер ЭМК не изменился ни в одной колонке и в историю не попал.
    assert await db_read.answer_columns(patient_id=pid, parameter_code=seeded.biomarker_param) == seeded.biomarker_row
    assert await db_read.answer_history(patient_id=pid, parameter_code=seeded.biomarker_param) == []
    now = datetime.now(tz=UTC)
    for parameter_code, value, source in (
        (seeded.form_param, _FORM_ANSWER_VALUE, ANSWER_SOURCE),
        (HEIGHT_PARAMETER_CODE, _EMR_ANTHROPOMETRY_VALUE, ANSWER_SOURCE_EMR),
    ):
        current = await db_read.answer_columns(patient_id=pid, parameter_code=parameter_code)
        assert current is not None and current["expiration_date"] < now
        archived = await db_read.answer_history(patient_id=pid, parameter_code=parameter_code)
        assert len(archived) == 1
        assert archived[0]["value"] == value
        assert archived[0]["source"] == source
        assert archived[0]["external_id"] is None


@pytest.mark.asyncio
async def test_answers_reset_applied_log_counts_invalidated_rows(
    db_session: AsyncSession, factory: Factory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Событие называет и размер множества кодов к сбросу, и число реально погашенных записей.

    У всех трёх параметров системы есть актуальные записи, поэтому здесь разница между двумя
    числами — ровно одна сохранённая запись биомаркера ЭМК.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    seeded = await _seed_mixed_source_system(factory, patient_id=pid)
    await db_session.commit()
    captured = _capture_notices(monkeypatch)

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[seeded.system_code])

    context = _context_of(captured, "answers-reset applied")
    assert context["params_count"] == 3
    assert context["invalidated_count"] == 2
    _assert_no_parameter_values(context, _SEEDED_VALUES)


@pytest.mark.asyncio
async def test_repeated_answers_reset_leaves_emr_biomarker_intact(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Повтор события ничего не добирает: биомаркер по-прежнему актуален, а история по ответу
    клиента не задвоилась (уже погашенную строку отсекает фильтр актуальности)."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid)
    seeded = await _seed_mixed_source_system(factory, patient_id=pid)
    await db_session.commit()

    service = await _make_service(db_session)
    await service.handle_answers_reset(client_id=pid, system_codes=[seeded.system_code])
    await service.handle_answers_reset(client_id=pid, system_codes=[seeded.system_code])

    assert await db_read.answer_columns(patient_id=pid, parameter_code=seeded.biomarker_param) == seeded.biomarker_row
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=seeded.biomarker_param) == 0
    assert await db_read.count_answer_history(patient_id=pid, parameter_code=seeded.form_param) == 1


@pytest.mark.asyncio
async def test_pregnancy_end_keeps_emr_biomarkers_of_cvd_and_endo(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Шаг 3 wiki: завершение беременности гасит ответы клиента по CVD и ENDO, но не биомаркеры
    ЭМК этих систем; признак беременности снимается независимо от того, что уцелело.

    `invalidated_count` пинуется как СУММА по обоим множествам кодов сброса: два ответа клиента
    отобраны как параметры систем, `height` из ЭМК с пустым `external_id` — как антропометрия,
    которая гасится безусловно.
    """
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=True)
    biomarker_rows: dict[str, dict[str, object]] = {}
    form_params: list[str] = []
    for index, system_code in enumerate((SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO)):
        biomarker_param = unique_id("bp")
        form_param = unique_id("fp")
        for parameter_code in (biomarker_param, form_param):
            await _wire_system_to_parameter(factory, system_code=system_code, parameter_code=parameter_code)
        biomarker_rows[biomarker_param] = await _seed_emr_biomarker(
            factory, patient_id=pid, parameter_code=biomarker_param, external_id=_BIOMARKER_EXTERNAL_ID + index
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=form_param,
            value=_FORM_ANSWER_VALUE,
            source=ANSWER_SOURCE,
            expiration_date=_future(),
        )
        form_params.append(form_param)
    # Антропометрия из ЭМК: тот же `source`, что у биомаркера, но без идентификатора экземпляра —
    # её гасит безусловное множество, и именно она отличает сумму от одних параметров систем.
    await factory.answer(
        patient_id=pid,
        parameter_code=HEIGHT_PARAMETER_CODE,
        value=_EMR_ANTHROPOMETRY_VALUE,
        source=ANSWER_SOURCE_EMR,
        expiration_date=_future(),
    )
    await db_session.commit()
    captured = _capture_notices(monkeypatch)

    await (await _make_service(db_session)).handle_pregnancy_end(client_id=pid)

    for parameter_code, expected in biomarker_rows.items():
        assert await db_read.answer_columns(patient_id=pid, parameter_code=parameter_code) == expected
        assert await db_read.answer_history(patient_id=pid, parameter_code=parameter_code) == []
    now = datetime.now(tz=UTC)
    for parameter_code in form_params:
        current = await db_read.answer_columns(patient_id=pid, parameter_code=parameter_code)
        assert current is not None and current["expiration_date"] < now
        assert await db_read.count_answer_history(patient_id=pid, parameter_code=parameter_code) == 1
    assert await db_read.is_pregnant(patient_id=pid) is False
    # Два ответа клиента по параметрам систем плюс антропометрия из ЭМК; биомаркеры ЭМК —
    # единственное, что в сумму не вошло.
    context = _context_of(captured, "pregnancy-end applied")
    assert context["invalidated_count"] == 3
    _assert_no_parameter_values(context, _SEEDED_VALUES)


@pytest.mark.asyncio
@pytest.mark.parametrize("body_metric_code", sorted(BODY_METRIC_PARAMETER_CODES))
@pytest.mark.parametrize("system_code", [SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO])
async def test_answers_reset_body_metrics_ignore_emr_biomarker_origin(
    db_session: AsyncSession,
    factory: Factory,
    db_read: DbRead,
    monkeypatch: pytest.MonkeyPatch,
    system_code: str,
    body_metric_code: str,
) -> None:
    """Шаг 7 wiki: антропометрию CVD/ENDO гасит и сопоставленный на неё биомаркер ЭМК — правило
    исключения на это множество кодов не распространяется, и в историю строка уезжает со своим
    `external_id`. По каждому из трёх кодов антропометрии и по обеим системам: правило задано на
    множество кодов целиком, а сопоставление биомаркера может появиться на любой из них.

    Контрольный ответ клиента, привязанный к сбрасываемой системе, разводит множества по слагаемым:
    `invalidated_count == 2` — один отобран как параметр системы, второй как антропометрия.
    """
    pid = unique_id("p")
    control_param = unique_id("fp")
    await factory.patient(patient_id=pid)
    await _wire_system_to_parameter(factory, system_code=system_code, parameter_code=control_param)
    await factory.answer(
        patient_id=pid,
        parameter_code=control_param,
        value=_FORM_ANSWER_VALUE,
        source=ANSWER_SOURCE,
        expiration_date=_future(),
    )
    expected = await _seed_emr_biomarker(factory, patient_id=pid, parameter_code=body_metric_code)
    await db_session.commit()
    captured = _capture_notices(monkeypatch)

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[system_code])

    now = datetime.now(tz=UTC)
    current = await db_read.answer_columns(patient_id=pid, parameter_code=body_metric_code)
    assert current is not None and current["expiration_date"] < now
    assert await db_read.answer_history(patient_id=pid, parameter_code=body_metric_code) == [expected]
    control = await db_read.answer_columns(patient_id=pid, parameter_code=control_param)
    assert control is not None and control["expiration_date"] < now
    context = _context_of(captured, "answers-reset applied")
    assert context["invalidated_count"] == 2
    _assert_no_parameter_values(context, _SEEDED_VALUES)


@pytest.mark.asyncio
async def test_pregnancy_end_resets_emr_biomarker_body_metrics(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Шаг 4 wiki: рост, вес и ИМТ гасятся и при завершении беременности — все три и независимо
    от происхождения значения."""
    pid = unique_id("p")
    await factory.patient(patient_id=pid, is_pregnant=True)
    expected = {
        parameter_code: await _seed_emr_biomarker(
            factory,
            patient_id=pid,
            parameter_code=parameter_code,
            external_id=_BIOMARKER_EXTERNAL_ID + index,
        )
        for index, parameter_code in enumerate(sorted(BODY_METRIC_PARAMETER_CODES))
    }
    await db_session.commit()

    await (await _make_service(db_session)).handle_pregnancy_end(client_id=pid)

    now = datetime.now(tz=UTC)
    for parameter_code, archived_row in expected.items():
        current = await db_read.answer_columns(patient_id=pid, parameter_code=parameter_code)
        assert current is not None and current["expiration_date"] < now
        assert await db_read.answer_history(patient_id=pid, parameter_code=parameter_code) == [archived_row]


@pytest.mark.asyncio
@pytest.mark.parametrize("system_code", BMI_ORPHANING_SYSTEMS)
async def test_answers_reset_keeps_emr_biomarker_bmi_of_non_body_system(
    db_session: AsyncSession, factory: Factory, db_read: DbRead, system_code: str
) -> None:
    """`bmi` привязан справочником к инструментам этих систем, а антропометрию они не сбрасывают:
    запись идёт множеством параметров систем и, будучи биомаркером ЭМК, остаётся актуальной.

    Привязка утверждается по каталогу сервиса до сброса: отвяжи справочник `bmi` от системы — и
    тест зеленел бы вакуумно, ничего про правило исключения уже не проверяя.

    Контрольный ответ клиента по той же системе отличает сохранение от сброса, который до системы
    вообще не дошёл.
    """
    pid = unique_id("p")
    control_param = unique_id("up")
    await factory.patient(patient_id=pid)
    await _wire_system_to_parameter(factory, system_code=system_code, parameter_code=control_param)
    await factory.answer(
        patient_id=pid,
        parameter_code=control_param,
        value=_FORM_ANSWER_VALUE,
        source=ANSWER_SOURCE,
        expiration_date=_future(),
    )
    expected = await _seed_emr_biomarker(factory, patient_id=pid, parameter_code=BMI_PARAMETER_CODE)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)
    assert BMI_PARAMETER_CODE in catalog.parameter_codes_by_system[system_code]

    await RiskEventService(db_session, catalog).handle_answers_reset(client_id=pid, system_codes=[system_code])

    assert await db_read.answer_columns(patient_id=pid, parameter_code=BMI_PARAMETER_CODE) == expected
    assert await db_read.answer_history(patient_id=pid, parameter_code=BMI_PARAMETER_CODE) == []
    control = await db_read.answer_columns(patient_id=pid, parameter_code=control_param)
    assert control is not None and control["expiration_date"] < datetime.now(tz=UTC)


@pytest.mark.asyncio
async def test_answers_reset_deletes_results_when_system_is_all_emr_biomarkers(
    db_session: AsyncSession, factory: Factory, db_read: DbRead
) -> None:
    """Сброс результатов не зависит от числа погашенных параметров: у системы, целиком закрытой
    биомаркерами ЭМК, записи параметров остаются на месте, а results и interpretations всё равно
    уезжают в историю и удаляются."""
    pid = unique_id("p")
    system_code = await factory.system(unique_id("SYS"))
    instrument_code = unique_id("i")
    biomarker_param = unique_id("bp")
    await factory.patient(patient_id=pid)
    await factory.parameter(code=biomarker_param)
    await factory.instrument(code=instrument_code)
    await factory.link_parameter(instrument_code=instrument_code, parameter_code=biomarker_param)
    await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
    expected = await _seed_emr_biomarker(factory, patient_id=pid, parameter_code=biomarker_param)
    now = now_utc()
    await factory.result(
        patient_id=pid,
        instrument_code=instrument_code,
        value="1.0",
        date_time=now - timedelta(days=1),
        expiration_date=now + timedelta(days=30),
    )
    await factory.interpretation(
        patient_id=pid, system_code=system_code, date_time=now - timedelta(days=1), risk_level="high"
    )
    await db_session.commit()

    await (await _make_service(db_session)).handle_answers_reset(client_id=pid, system_codes=[system_code])

    assert await db_read.answer_columns(patient_id=pid, parameter_code=biomarker_param) == expected
    assert await db_read.answer_history(patient_id=pid, parameter_code=biomarker_param) == []
    assert await db_read.count_results(patient_id=pid, instrument_code=instrument_code) == 0
    assert await db_read.count_results_history(patient_id=pid, instrument_code=instrument_code) == 1
    assert await db_read.count_interpretations(patient_id=pid, system_code=system_code) == 0
    assert await db_read.count_interpretations_history(patient_id=pid, system_code=system_code) == 1


@pytest.mark.asyncio
async def test_answers_reset_cleans_diagnostics_before_returning(db_session: AsyncSession, factory: Factory) -> None:
    """Очистка диагностики завершена к моменту возврата — по инструментам и по системам.

    Пересчёт роутер ставит после возврата обработчика, поэтому очистка обязана закончиться раньше.
    Уйди она в фоновую задачу, она снесла бы строки диагностики, только что записанные этим
    пересчётом, — и объяснение показателя пропало бы уже после пересчёта.
    """
    pid = unique_id("p")
    system_code = await factory.system(unique_id("SYS"))
    instrument_code = unique_id("i")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await _wire_system_instrument(factory, system_code=system_code, instrument_code=instrument_code)
    await db_session.commit()
    statuses = AsyncMock()
    reasons = AsyncMock()
    service = RiskEventService(
        db_session,
        await make_http_catalog(db_session),
        status_collector=statuses,
        reason_collector=reasons,
    )

    await service.handle_answers_reset(client_id=pid, system_codes=[system_code])

    statuses.delete_for_instruments.assert_awaited_once_with(pid, {instrument_code})
    reasons.delete_for_systems.assert_awaited_once_with(pid, [system_code])


@pytest.mark.asyncio
async def test_pregnancy_end_cleans_diagnostics_before_returning(db_session: AsyncSession, factory: Factory) -> None:
    """То же для pregnancy-end: статусы — по инструментам CVD и ENDO, факторы — по самим системам.

    Инструменты справочника отвязаны от обеих систем, чтобы ожидание было набором самого теста:
    иначе оно повторяло бы связки сидов миграций.
    """
    pid = unique_id("p")
    cvd_instrument = unique_id("i")
    endo_instrument = unique_id("i")
    await factory.patient(patient_id=pid, is_pregnant=False)
    await factory.unlink_system_instruments(system_code=SYSTEM_CODE_CVD)
    await factory.unlink_system_instruments(system_code=SYSTEM_CODE_ENDO)
    await _wire_system_instrument(factory, system_code=SYSTEM_CODE_CVD, instrument_code=cvd_instrument)
    await _wire_system_instrument(factory, system_code=SYSTEM_CODE_ENDO, instrument_code=endo_instrument)
    await db_session.commit()
    statuses = AsyncMock()
    reasons = AsyncMock()
    service = RiskEventService(
        db_session,
        await make_http_catalog(db_session),
        status_collector=statuses,
        reason_collector=reasons,
    )

    await service.handle_pregnancy_end(client_id=pid)

    statuses.delete_for_instruments.assert_awaited_once_with(pid, {cvd_instrument, endo_instrument})
    reasons.delete_for_systems.assert_awaited_once_with(pid, frozenset({SYSTEM_CODE_CVD, SYSTEM_CODE_ENDO}))
