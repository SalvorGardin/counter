"""`trigger_id` в мигрированной БД идёт в порядке строк каталога.

На этом держится тай-брейк §4.3: при равных баллах очередь задаёт `trigger_id`, и он должен
воспроизводить порядок строк CSV — тот же, в котором до нормализации раздавался
`risk_factors.risk_factor_id`. Порядок ломает любая заливка, вставляющая строки не подряд
(частичный upsert, правка построчно), поэтому проверяем именно базу после миграций, а не CSV.
"""

import csv
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

_CATALOG = Path(__file__).resolve().parents[2] / "catalog"


def _latest_triggers_csv() -> Path:
    """Последний по номеру сид условий: именно он лежит в БД после `upgrade head`.

    Берём не фиксированное имя, а максимум по номеру миграции — иначе после каждой
    перезаливки справочника тест падал бы на устаревшем пути, и починка сводилась бы к
    правке константы вместо проверки самого порядка.
    """
    return max(_CATALOG.glob("*_risk_factor_triggers.csv"))


def _catalog_trigger_codes() -> list[str]:
    with _latest_triggers_csv().open(encoding="utf-8", newline="") as stream:
        return [row["trigger_code"] for row in csv.DictReader(stream, delimiter=";")]


async def test_trigger_id_order_follows_catalog_order(db_session: AsyncSession) -> None:
    rows = await db_session.execute(text("SELECT trigger_code FROM risk_factor_triggers ORDER BY trigger_id"))
    assert [code for (code,) in rows.all()] == _catalog_trigger_codes()
