"""Инвариант: risk-init и risk-communication берут срок жизни параметра из одного источника (БД).

После #160 (и закрытия #21) единственный источник срока — `parameters.validity_period`. risk-init
больше не хранит собственную in-memory таблицу: для gender/birthdate он вычисляет `expiration_date`
тем же правилом `compute_expiration(now, validity_period)`, что и путь анкеты (risk-communication).
Тест читает фактический `validity_period` из справочника (значения засеяны миграциями) и проверяет,
что записанный risk-init `expiration_date` равен тому, что дал бы risk-communication для того же
параметра, — т.е. оба пути читают из одного источника и согласованы.
"""

from datetime import UTC, date, datetime

import pytest
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_init.schemas import AnthropometryRequest
from src.models.patient_parameter import PatientParameter
from src.services.risk_communication.domain.expiration import compute_expiration
from src.services.risk_init.domain.constants import BIRTHDATE_PARAMETER_CODE, GENDER_PARAMETER_CODE
from src.services.risk_init.service import RiskInitService
from tests.conftest import make_http_catalog
from tests.factories import unique_id


@pytest.mark.parametrize("parameter_code", [BIRTHDATE_PARAMETER_CODE, GENDER_PARAMETER_CODE])
async def test_risk_init_uses_db_validity_like_risk_communication(
    db_session: AsyncSession, parameter_code: str
) -> None:
    # Параметры (birthdate/gender/age) уже засеяны миграциями — сервис читает их validity_period из БД.
    client_id = unique_id("c")
    service = RiskInitService(db_session, await make_http_catalog(db_session))

    before = datetime.now(tz=UTC)
    await service.save_anthropometry(
        client_id=client_id,
        body=AnthropometryRequest(birth_date=date(1990, 3, 15), gender="female"),
    )
    after = datetime.now(tz=UTC)

    db_validity = (
        await db_session.execute(
            text("SELECT validity_period FROM parameters WHERE code = :code"), {"code": parameter_code}
        )
    ).scalar_one()
    row = await db_session.scalar(
        select(PatientParameter).where(
            PatientParameter.patient_id == client_id,
            PatientParameter.parameter_code == parameter_code,
        )
    )
    assert row is not None
    # risk-communication для того же параметра посчитал бы ровно compute_expiration(now, db_validity).
    # Точный `now` сервиса недоступен, поэтому проверяем попадание в окно [before, after].
    assert compute_expiration(before, db_validity) <= row.expiration_date <= compute_expiration(after, db_validity)
