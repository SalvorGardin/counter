"""Bug #136: деривация ИМТ по ответам опросника на рост/вес (cq_040/cq_050).

Каталог здесь настоящий (поднимается миграциями): cq_040→height, cq_050→weight — это те самые
вопросы, которые опросник снова задаёт после answers-reset, когда height/weight теряют актуальность.
compute_bmi живёт в risk-init, поэтому до фикса ответ на них записывал рост/вес, но bmi оставался
протухшим навсегда.
"""

from datetime import timedelta

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest
from src.models.patient_parameter import PatientParameter
from src.services.risk_communication.service import RiskCommunicationService
from tests.conftest import make_http_catalog
from tests.consts import PARAMETER_CODE_BMI, PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT
from tests.factories import Factory, now_utc, unique_id

_HEIGHT_QUESTION = "cq_040"
_WEIGHT_QUESTION = "cq_050"


async def _get_param(session: AsyncSession, patient_id: str, code: str) -> PatientParameter | None:
    return await session.scalar(
        select(PatientParameter).where(
            PatientParameter.patient_id == patient_id,
            PatientParameter.parameter_code == code,
        )
    )


async def _answer(service: RiskCommunicationService, client_id: str, question_code: str, value: str) -> frozenset[str]:
    _, signal = await service.handle(
        client_id=client_id,
        question_code=question_code,
        system_code=None,
        body=AnswerRequest(answer=value),
    )
    return signal.parameter_codes


async def test_bmi_derived_when_both_height_and_weight_answered(db_session: AsyncSession, factory: Factory) -> None:
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    # Только рост: вес ещё не отвечен → ИМТ считать не из чего.
    changed = await _answer(service, client_id, _HEIGHT_QUESTION, "175")
    assert PARAMETER_CODE_HEIGHT in changed
    assert PARAMETER_CODE_BMI not in changed
    assert (await _get_param(db_session, client_id, PARAMETER_CODE_BMI)) is None
    # Чтение выше autobegin'ит транзакцию — закрываем, иначе handle() упадёт на «transaction already begun».
    await db_session.commit()

    # Вес: теперь оба актуальны → ИМТ деривируется и уходит в пересчёт.
    changed = await _answer(service, client_id, _WEIGHT_QUESTION, "72")
    assert PARAMETER_CODE_WEIGHT in changed
    assert PARAMETER_CODE_BMI in changed

    bmi = await _get_param(db_session, client_id, PARAMETER_CODE_BMI)
    assert bmi is not None
    assert bmi.value == "23.51"  # формат общий с risk-init
    assert bmi.expiration_date > now_utc()


async def test_bmi_rederived_after_answers_reset_with_same_values(db_session: AsyncSession, factory: Factory) -> None:
    """Сценарий QA из #136: risk-init → answers-reset → те же рост/вес через опросник."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    # Состояние после risk-init: height/weight/bmi актуальны.
    for code, value in ((PARAMETER_CODE_HEIGHT, "175"), (PARAMETER_CODE_WEIGHT, "72"), (PARAMETER_CODE_BMI, "23.51")):
        await factory.answer(
            patient_id=client_id,
            parameter_code=code,
            value=value,
            expiration_date=now_utc() + timedelta(days=365),
        )
    # answers-reset по CVD/ENDO: soft-invalidate — строки остаются, expiration_date в прошлом.
    await db_session.execute(
        update(PatientParameter)
        .where(
            PatientParameter.patient_id == client_id,
            PatientParameter.parameter_code.in_([PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT, PARAMETER_CODE_BMI]),
        )
        .values(expiration_date=now_utc() - timedelta(days=1))
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    # Те же самые значения — именно на этом баг и ловился.
    await _answer(service, client_id, _HEIGHT_QUESTION, "175")
    changed = await _answer(service, client_id, _WEIGHT_QUESTION, "72")

    assert PARAMETER_CODE_BMI in changed
    bmi = await _get_param(db_session, client_id, PARAMETER_CODE_BMI)
    assert bmi is not None
    assert bmi.value == "23.51"
    # Главное: ИМТ снова актуален и виден калькуляторам (до фикса оставался протухшим).
    assert bmi.expiration_date > now_utc()


async def test_bmi_recomputed_from_new_value_not_stale_one(db_session: AsyncSession, factory: Factory) -> None:
    """После сброса отвечают ДРУГОЙ вес: ИМТ обязан считаться из нового значения.

    Тесты с теми же значениями (175/72) прошли бы и при чтении устаревшего height/weight —
    здесь новое значение пинит саму деривацию, а не только факт записи строки.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    for code, value in ((PARAMETER_CODE_HEIGHT, "175"), (PARAMETER_CODE_WEIGHT, "72"), (PARAMETER_CODE_BMI, "23.51")):
        await factory.answer(
            patient_id=client_id,
            parameter_code=code,
            value=value,
            expiration_date=now_utc() + timedelta(days=365),
        )
    await db_session.execute(
        update(PatientParameter)
        .where(
            PatientParameter.patient_id == client_id,
            PatientParameter.parameter_code.in_([PARAMETER_CODE_HEIGHT, PARAMETER_CODE_WEIGHT, PARAMETER_CODE_BMI]),
        )
        .values(expiration_date=now_utc() - timedelta(days=1))
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    await _answer(service, client_id, _HEIGHT_QUESTION, "175")
    await _answer(service, client_id, _WEIGHT_QUESTION, "80")

    bmi = await _get_param(db_session, client_id, PARAMETER_CODE_BMI)
    assert bmi is not None
    assert bmi.value == "26.12"  # 80 / 1.75^2, а не залипшие 23.51
    assert bmi.expiration_date > now_utc()


async def test_bmi_derived_when_only_weight_answered_and_height_already_actual(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Рост уже актуален (из risk-init) — ответа на один вес достаточно для деривации."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await factory.answer(
        patient_id=client_id,
        parameter_code=PARAMETER_CODE_HEIGHT,
        value="175",
        expiration_date=now_utc() + timedelta(days=365),
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    changed = await _answer(service, client_id, _WEIGHT_QUESTION, "72")

    assert PARAMETER_CODE_BMI in changed
    bmi = await _get_param(db_session, client_id, PARAMETER_CODE_BMI)
    assert bmi is not None and bmi.value == "23.51"


async def test_bmi_not_derived_when_height_is_zero(db_session: AsyncSession, factory: Factory) -> None:
    """Рост в знаменателе: "0" — валидный numeric-ответ, но ИМТ из него не считается (не 500)."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    await _answer(service, client_id, _HEIGHT_QUESTION, "0")
    changed = await _answer(service, client_id, _WEIGHT_QUESTION, "72")

    assert PARAMETER_CODE_BMI not in changed
    assert (await _get_param(db_session, client_id, PARAMETER_CODE_BMI)) is None
