"""Регресс: вопрос об уровне креатинина sq_0710 после всех миграций пропускаем (is_skippable=true).

В каталоге 0096 sq_0710 шёл с is_skippable=0, из-за чего risk-communication отвечал
QuestionNotSkippableError на ответе с is_skipped=true (см. 0101_make_sq_0710_skippable). Этот тест
ловит повторную регрессию, если следующий reseed questions снова принесёт 0 из устаревшего
catalog-CSV.
"""

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


async def test_sq_0710_is_skippable(db_session: AsyncSession) -> None:
    is_skippable = (
        await db_session.execute(text("SELECT is_skippable FROM questions WHERE code = 'sq_0710'"))
    ).scalar_one()
    assert is_skippable is True
