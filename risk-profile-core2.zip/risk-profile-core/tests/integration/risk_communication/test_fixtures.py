"""Контракт сценарных фикстур risk-communication."""

from src.api.v1.risk_communication.schemas import AnswerRequest
from tests.integration.risk_communication.conftest import RcScenarioFactory


async def test_rc_scenario_returns_a_ready_to_use_context(rc_scenario: RcScenarioFactory) -> None:
    """Сценарий отдаёт засеянного пациента, вопрос и сервис одной строкой."""
    scenario = await rc_scenario(options=[("a1", "Низкий"), ("a2", "Высокий")])

    response, _ = await scenario.service.handle(
        client_id=scenario.patient_id,
        question_code=scenario.question_code,
        system_code=None,
        body=AnswerRequest(option_codes=["a2"]),
    )

    assert response.is_success is True
