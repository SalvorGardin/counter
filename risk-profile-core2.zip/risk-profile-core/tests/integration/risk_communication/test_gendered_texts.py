"""Родовые формы текстов опросников в ответе risk-communication на реальном каталоге.

Каталог интеграционной БД накачан миграциями до head, поэтому BDI и STAI несут родовые формы из
сида. Пациенту отвечены все параметры системы MENTAL, кроме параметра проверяемого вопроса, —
следующим отдаётся именно он. Пол задаётся записью `gender`, как её пишет Risk-init.
"""

from datetime import timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest, AnswerResponse
from tests.consts import GENDER_FEMALE, GENDER_MALE, PARAMETER_CODE_GENDER
from tests.factories import Factory, now_utc
from tests.integration.risk_communication.conftest import RcServiceFactory

_MENTAL = "MENTAL"
_EXPIRED = "expired-female"

_BDI1_OPTIONS = {
    GENDER_FEMALE: [
        "Я не чувствую себя расстроенной, печальной",
        "Я расстроена",
        "Я всё время расстроена и не могу от этого отключиться",
        "Я настолько расстроена и несчастлива, что не могу это выдержать",
    ],
    GENDER_MALE: [
        "Я не чувствую себя расстроенным, печальным",
        "Я расстроен",
        "Я всё время расстроен и не могу от этого отключиться",
        "Я настолько расстроен и несчастлив, что не могу это выдержать",
    ],
    None: [
        "Я не чувствую себя расстроенным(ой), печальным(ой)",
        "Я расстроен(а)",
        "Я всё время расстроен(а) и не могу от этого отключиться",
        "Я настолько расстроен(а) и несчастлив(а), что не могу это выдержать",
    ],
}
_STAI1_TEXT = {GENDER_FEMALE: "Я спокойна.", GENDER_MALE: "Я спокоен.", None: "Я спокоен(на)."}


async def _next_question(
    factory: Factory,
    db_session: AsyncSession,
    rc_service: RcServiceFactory,
    *,
    parameter_code: str,
    gender: str | None,
    v2_flag: bool,
) -> AnswerResponse:
    patient_id = await factory.patient()
    await factory.answer_system_params(patient_id=patient_id, system_code=_MENTAL, exclude={parameter_code})
    if gender is not None:
        expired = gender == _EXPIRED
        await factory.answer(
            patient_id=patient_id,
            parameter_code=PARAMETER_CODE_GENDER,
            value=GENDER_FEMALE if expired else gender,
            expiration_date=now_utc() + (timedelta(days=-1) if expired else timedelta(days=30)),
        )
    await db_session.commit()

    service = await rc_service()
    response, _ = await service.handle(
        client_id=patient_id,
        question_code=None,
        system_code=_MENTAL,
        body=AnswerRequest(),
        complete_on_requested_system_done=v2_flag,
    )
    return response


@pytest.mark.parametrize("v2_flag", [False, True], ids=["v1", "v2"])
@pytest.mark.parametrize(
    ("gender", "expected_key"),
    [(GENDER_FEMALE, GENDER_FEMALE), (GENDER_MALE, GENDER_MALE), (None, None), (_EXPIRED, None)],
    ids=["female", "male", "no-gender", "expired-gender"],
)
async def test_bdi_options_follow_patient_gender(
    db_session: AsyncSession,
    factory: Factory,
    rc_service: RcServiceFactory,
    gender: str | None,
    expected_key: str | None,
    v2_flag: bool,
) -> None:
    response = await _next_question(
        factory, db_session, rc_service, parameter_code="bdi1", gender=gender, v2_flag=v2_flag
    )

    assert response.question is not None
    assert response.question.question_code == "BDI1"
    assert response.question.options is not None
    assert [o.text for o in response.question.options] == _BDI1_OPTIONS[expected_key]


@pytest.mark.parametrize("v2_flag", [False, True], ids=["v1", "v2"])
@pytest.mark.parametrize(
    ("gender", "expected_key"),
    [(GENDER_FEMALE, GENDER_FEMALE), (GENDER_MALE, GENDER_MALE), (None, None), (_EXPIRED, None)],
    ids=["female", "male", "no-gender", "expired-gender"],
)
async def test_stai_question_text_follows_patient_gender(
    db_session: AsyncSession,
    factory: Factory,
    rc_service: RcServiceFactory,
    gender: str | None,
    expected_key: str | None,
    v2_flag: bool,
) -> None:
    response = await _next_question(
        factory, db_session, rc_service, parameter_code="stai1", gender=gender, v2_flag=v2_flag
    )

    assert response.question is not None
    assert response.question.question_code == "STAI1"
    assert response.question.text == _STAI1_TEXT[expected_key]


@pytest.mark.parametrize(("parameter_code", "question_code"), [("bdi1", "BDI1"), ("stai1", "STAI1")])
async def test_response_shape_does_not_depend_on_gender(
    db_session: AsyncSession,
    factory: Factory,
    rc_service: RcServiceFactory,
    parameter_code: str,
    question_code: str,
) -> None:
    shapes = set()
    for gender in (GENDER_FEMALE, GENDER_MALE, None):
        response = await _next_question(
            factory, db_session, rc_service, parameter_code=parameter_code, gender=gender, v2_flag=True
        )
        question = response.question
        assert question is not None
        assert question.question_code == question_code
        assert question.options is not None
        shapes.add(
            (
                question.question_code,
                question.type,
                question.is_skippable,
                tuple(o.option_code for o in question.options),
            )
        )

    assert len(shapes) == 1


async def test_female_answer_is_stored_as_neutral_value(
    db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
) -> None:
    """Пациентка видит «Я расстроена», а в ответе хранится `options.value` — ключ балла BDI."""
    patient_id = await factory.patient()
    await factory.answer(
        patient_id=patient_id,
        parameter_code=PARAMETER_CODE_GENDER,
        value=GENDER_FEMALE,
        expiration_date=now_utc() + timedelta(days=30),
    )
    await db_session.commit()

    service = await rc_service()
    await service.handle(
        client_id=patient_id,
        question_code="BDI1",
        system_code=_MENTAL,
        body=AnswerRequest(option_codes=["BDI1_02"]),
    )

    stored = (
        await db_session.execute(
            text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = 'bdi1'"),
            {"pid": patient_id},
        )
    ).scalar_one()
    assert stored == "Я расстроен(а)"
