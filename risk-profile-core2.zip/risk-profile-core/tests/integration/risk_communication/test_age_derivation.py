"""Bug #169: деривация возраста по ответу опросника на дату рождения (cq_020).

Каталог здесь настоящий (поднимается миграциями): cq_020 (type=date) → option cq_020_01 → параметр
`birthdate`, срок жизни `age` — из справочника `parameters` (#160, по текущему сиду 10 лет).
До фикса ответ на cq_020 записывал только `birthdate`: `age` не пересчитывался на пути анкеты вовсе
и оставался протухшим навсегда, хотя он is_required у большинства калькуляторов (после 0045 —
stai/bdi/bcrat/stop_bang/score_2/ckd_epi/findrisc, плюс half_frax/skf).

Ровно тот же инвариант, что и в #136 для bmi, поэтому и тесты — по образцу test_bmi_derivation.py.
"""

import logging
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, date, datetime, timedelta
from types import MappingProxyType

import pytest
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest
from src.models.patient_parameter import PatientParameter
from src.models.patient_parameter_history import PatientParameterHistory
from src.services.risk_communication.domain.constants import ANSWER_SOURCE
from src.services.risk_communication.domain.exceptions import CatalogConsistencyError, QuestionNotSkippableError
from src.services.risk_communication.domain.expiration import to_timedelta
from src.services.risk_communication.service import RiskCommunicationService
from src.services.risk_init.domain.age import compute_age
from src.services.risk_init.domain.constants import AGE_PARAMETER_CODE, BIRTHDATE_PARAMETER_CODE
from tests.conftest import make_http_catalog
from tests.factories import Factory, now_utc, unique_id

_BIRTHDATE_QUESTION = "cq_020"
# Дата «неокруглая» и намеренно не совпадающая ни с одним сидом: её строка ищется в логах
# теста на ПДн, и совпадение с чужим значением сделало бы тот тест лживым в обе стороны.
_BIRTHDATE = "1963-07-19"
_OTHER_BIRTHDATE = "1971-11-03"
# Заведомо неверный возраст в БД: пинит, что строка именно пересчитана, а не просто «есть».
_STALE_AGE = "17"


def _expected_age(birthdate: str) -> int:
    """Ожидаемое значение — по той же формуле risk-init, что использует сервис.

    Константу сюда не зашить: она менялась бы в день рождения пациента, а формула — единственный
    источник (её собственные корнер-кейсы покрыты tests/unit/risk_init/test_age.py).
    """
    return compute_age(date.fromisoformat(birthdate), datetime.now(tz=UTC).date())


async def _get_param(session: AsyncSession, patient_id: str, code: str) -> PatientParameter | None:
    return await session.scalar(
        select(PatientParameter).where(
            PatientParameter.patient_id == patient_id,
            PatientParameter.parameter_code == code,
        )
    )


async def _get_history(session: AsyncSession, patient_id: str, code: str) -> list[PatientParameterHistory]:
    rows = await session.scalars(
        select(PatientParameterHistory).where(
            PatientParameterHistory.patient_id == patient_id,
            PatientParameterHistory.parameter_code == code,
        )
    )
    return list(rows)


async def _param_snapshot(session: AsyncSession, patient_id: str, code: str) -> tuple[str, datetime, datetime]:
    """Значение + оба таймстемпа строки параметра, прочитанные СЫРЫМ SQL.

    Именно сырым: `select(PatientParameter)` для уже загруженного объекта не перечитывает атрибуты
    из БД (identity map), и снапшот «до» мог бы совпасть со снапшотом «после» просто потому, что
    это один и тот же объект — тест на отсутствие записи выродился бы в тавтологию.
    """
    row = (
        await session.execute(
            text(
                "SELECT value, date_time, expiration_date FROM patients_parameters"
                " WHERE patient_id = :pid AND parameter_code = :code"
            ),
            {"pid": patient_id, "code": code},
        )
    ).one()
    return (row.value, row.date_time, row.expiration_date)


async def _validity(session: AsyncSession, code: str) -> datetime:
    return (
        await session.execute(text("SELECT validity_period FROM parameters WHERE code = :code"), {"code": code})
    ).scalar_one()


async def _answer_date(
    service: RiskCommunicationService,
    client_id: str,
    value: str,
    question_code: str = _BIRTHDATE_QUESTION,
) -> frozenset[str]:
    _, signal = await service.handle(
        client_id=client_id,
        question_code=question_code,
        system_code=None,
        body=AnswerRequest(answer=value),
    )
    return signal.parameter_codes


async def _seed_expired(
    factory: Factory,
    *,
    patient_id: str,
    code: str,
    value: str,
    date_time: datetime,
) -> None:
    await factory.answer(
        patient_id=patient_id,
        parameter_code=code,
        value=value,
        expiration_date=now_utc() - timedelta(days=1),
        date_time=date_time,
        source="test-seed",
    )


async def test_age_recomputed_when_expired_birthdate_reanswered_with_same_date(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Сценарий QA из #169: birthdate и age просрочены, дату рождения вводят повторно ТОЙ ЖЕ."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    seeded_at = now_utc() - timedelta(days=400)
    await _seed_expired(
        factory, patient_id=client_id, code=BIRTHDATE_PARAMETER_CODE, value=_BIRTHDATE, date_time=seeded_at
    )
    await _seed_expired(factory, patient_id=client_id, code=AGE_PARAMETER_CODE, value=_STALE_AGE, date_time=seeded_at)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    changed = await _answer_date(service, client_id, _BIRTHDATE)

    # Пересчитанный возраст уходит в пересчёт риск-профиля наравне с самим ответом.
    assert BIRTHDATE_PARAMETER_CODE in changed
    assert AGE_PARAMETER_CODE in changed

    birthdate_row = await _get_param(db_session, client_id, BIRTHDATE_PARAMETER_CODE)
    assert birthdate_row is not None
    assert birthdate_row.value == _BIRTHDATE
    assert birthdate_row.expiration_date > now_utc()

    age_row = await _get_param(db_session, client_id, AGE_PARAMETER_CODE)
    assert age_row is not None
    assert age_row.value == str(_expected_age(_BIRTHDATE))
    # Главное: возраст снова актуален и виден калькуляторам (до фикса оставался протухшим).
    assert age_row.expiration_date > now_utc()

    # Срок жизни — из справочника, отдельного правила для age нет (#160: по текущему сиду 10 лет).
    validity = await _validity(db_session, AGE_PARAMETER_CODE)
    assert age_row.expiration_date == age_row.date_time + to_timedelta(validity)
    assert to_timedelta(validity) > timedelta(days=3000)

    history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
    assert len(history) == 1
    assert history[0].value == _STALE_AGE
    # В history уезжает ОРИГИНАЛЬНЫЙ момент записи, а не момент архивации.
    assert abs((history[0].date_time - seeded_at).total_seconds()) < 1


async def test_age_created_when_no_row_exists(db_session: AsyncSession, factory: Factory) -> None:
    """Строки age у пациента нет вовсе — деривация её создаёт, архивировать при этом нечего."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    changed = await _answer_date(service, client_id, _BIRTHDATE)

    assert AGE_PARAMETER_CODE in changed
    age_row = await _get_param(db_session, client_id, AGE_PARAMETER_CODE)
    assert age_row is not None
    assert age_row.value == str(_expected_age(_BIRTHDATE))
    assert age_row.expiration_date > now_utc()
    assert await _get_history(db_session, client_id, AGE_PARAMETER_CODE) == []


async def test_age_recomputed_from_new_birthdate_while_age_is_actual(
    db_session: AsyncSession, factory: Factory
) -> None:
    """Актуальность age не защищает от пересчёта, если возраст по новой дате ДРУГОЙ.

    Value-diff guard (ревью !150) отсекает только совпадение значений; здесь значения расходятся,
    поэтому пинится и сам пересчёт по НОВОЙ дате, и архивация прежней строки.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    seeded_at = now_utc() - timedelta(days=10)
    await factory.answer(
        patient_id=client_id,
        parameter_code=AGE_PARAMETER_CODE,
        value=_STALE_AGE,
        expiration_date=now_utc() + timedelta(days=365),
        date_time=seeded_at,
        source="test-seed",
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    changed = await _answer_date(service, client_id, _OTHER_BIRTHDATE)

    assert AGE_PARAMETER_CODE in changed
    age_row = await _get_param(db_session, client_id, AGE_PARAMETER_CODE)
    assert age_row is not None
    assert age_row.value == str(_expected_age(_OTHER_BIRTHDATE))
    assert age_row.expiration_date > now_utc()

    history = await _get_history(db_session, client_id, AGE_PARAMETER_CODE)
    assert len(history) == 1
    assert history[0].value == _STALE_AGE


async def test_double_submit_of_same_answer_does_not_touch_age(db_session: AsyncSession, factory: Factory) -> None:
    """Ретрай того же ответа на cq_020 при согласованных birthdate/age — полный no-op по age.

    У /answer нет идемпотентности, поэтому double-submit — обычное дело; без value-diff guard'а
    (ревью !150, #12) он перезаписывал бы строку, клал прежнюю в history и гнал холостой пересчёт
    девяти age-зависимых калькуляторов.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    seeded_at = now_utc() - timedelta(days=10)
    # Состояние «ответ уже принят»: birthdate и age актуальны и согласованы между собой.
    for code, value in ((BIRTHDATE_PARAMETER_CODE, _BIRTHDATE), (AGE_PARAMETER_CODE, str(_expected_age(_BIRTHDATE)))):
        await factory.answer(
            patient_id=client_id,
            parameter_code=code,
            value=value,
            expiration_date=now_utc() + timedelta(days=365),
            date_time=seeded_at,
            source="test-seed",
        )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))
    before = await _param_snapshot(db_session, client_id, AGE_PARAMETER_CODE)
    await db_session.commit()

    changed = await _answer_date(service, client_id, _BIRTHDATE)

    # Сам ответ записывается как обычно, а вот пересчёт по age не планируется.
    assert BIRTHDATE_PARAMETER_CODE in changed
    assert AGE_PARAMETER_CODE not in changed
    # Строка age не тронута: ни значения, ни момента записи, ни срока жизни.
    assert await _param_snapshot(db_session, client_id, AGE_PARAMETER_CODE) == before
    assert await _get_history(db_session, client_id, AGE_PARAMETER_CODE) == []


async def test_new_birthdate_with_same_computed_age_is_skipped(db_session: AsyncSession, factory: Factory) -> None:
    """Пин задокументированного расхождения с risk-init (design D1): guard сравнивает ВОЗРАСТ, не дату.

    Дата рождения меняется, но вычисленный возраст остаётся прежним. risk-init переписал бы строку
    (birthDate changed → освежил бы expiration), путь анкеты — пропускает: значение уже верное,
    а churn ради обновления срока не создаём. Инвариант age = f(birthdate) при этом не нарушен.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    today = datetime.now(tz=UTC).date()
    # Обе даты дают один и тот же возраст: день рождения в этом году уже прошёл, сдвиг на сутки
    # внутрь того же «года возраста» его не меняет.
    seeded_birthdate = today.replace(year=today.year - 40) - timedelta(days=200)
    new_birthdate = seeded_birthdate - timedelta(days=1)
    assert compute_age(seeded_birthdate, today) == compute_age(new_birthdate, today) == 40

    seeded_at = now_utc() - timedelta(days=10)
    for code, value in (
        (BIRTHDATE_PARAMETER_CODE, seeded_birthdate.isoformat()),
        (AGE_PARAMETER_CODE, "40"),
    ):
        await factory.answer(
            patient_id=client_id,
            parameter_code=code,
            value=value,
            expiration_date=now_utc() + timedelta(days=365),
            date_time=seeded_at,
            source="test-seed",
        )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))
    before = await _param_snapshot(db_session, client_id, AGE_PARAMETER_CODE)
    await db_session.commit()

    changed = await _answer_date(service, client_id, new_birthdate.isoformat())

    # Новая дата рождения записана, а строка age осталась прежней целиком.
    assert BIRTHDATE_PARAMETER_CODE in changed
    assert AGE_PARAMETER_CODE not in changed
    birthdate_row = await _get_param(db_session, client_id, BIRTHDATE_PARAMETER_CODE)
    assert birthdate_row is not None and birthdate_row.value == new_birthdate.isoformat()
    assert await _param_snapshot(db_session, client_id, AGE_PARAMETER_CODE) == before
    assert await _get_history(db_session, client_id, AGE_PARAMETER_CODE) == []


async def test_derived_age_provenance_is_form_and_answer_time(db_session: AsyncSession, factory: Factory) -> None:
    """Провенанс пересчитанного age: source = FORM (как у любой записи пути анкеты), date_time = моменту ответа."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    before = now_utc()
    await _answer_date(service, client_id, _BIRTHDATE)
    after = now_utc()

    age_row = await _get_param(db_session, client_id, AGE_PARAMETER_CODE)
    assert age_row is not None
    assert age_row.source == ANSWER_SOURCE
    assert before <= age_row.date_time <= after


async def test_future_birthdate_writes_birthdate_but_not_age(db_session: AsyncSession, factory: Factory) -> None:
    """Дата рождения из будущего: сама запись — существующее поведение границы, а age не плодим."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    future = (datetime.now(tz=UTC).date() + timedelta(days=365)).isoformat()
    changed = await _answer_date(service, client_id, future)

    # Ответ обработан успешно, birthdate записан — coerce_date_answer проверяет только формат.
    assert BIRTHDATE_PARAMETER_CODE in changed
    assert AGE_PARAMETER_CODE not in changed
    assert (await _get_param(db_session, client_id, AGE_PARAMETER_CODE)) is None


async def test_cq_020_is_not_skippable_in_current_catalog(db_session: AsyncSession, factory: Factory) -> None:
    """Почему ветку `birthdate=''` нельзя проверить на самом cq_020: он не пропускаемый.

    is_skippable=0 в каталоге → 400 QUESTION_NOT_SKIPPABLE до любой записи. Флаг правится админкой,
    поэтому ветка пустого значения всё равно должна быть покрыта — см. тест ниже.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    with pytest.raises(QuestionNotSkippableError):
        await service.handle(
            client_id=client_id,
            question_code=_BIRTHDATE_QUESTION,
            system_code=None,
            body=AnswerRequest(is_skipped=True),
        )


async def test_empty_birthdate_skips_derivation(db_session: AsyncSession, factory: Factory) -> None:
    """isSkipped пишет в birthdate пустую строку — деривации нет, протухший age не тронут."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    seeded_at = now_utc() - timedelta(days=400)
    await _seed_expired(factory, patient_id=client_id, code=AGE_PARAMETER_CODE, value=_STALE_AGE, date_time=seeded_at)
    # Пропускаемый date-вопрос на тот же параметр: cq_020 сегодня is_skippable=0 (см. тест выше).
    skippable_question = unique_id("zq")
    await factory.question(code=skippable_question, type="date", is_skippable=True, group_code=1)
    await factory.option(
        code=f"{skippable_question}_01",
        question_code=skippable_question,
        parameter_code=BIRTHDATE_PARAMETER_CODE,
        value=None,
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    _, signal = await service.handle(
        client_id=client_id,
        question_code=skippable_question,
        system_code=None,
        body=AnswerRequest(is_skipped=True),
    )

    # Ответ обработан успешно, пустое значение записано, а возраст остался как был.
    assert BIRTHDATE_PARAMETER_CODE in signal.parameter_codes
    assert AGE_PARAMETER_CODE not in signal.parameter_codes
    age_row = await _get_param(db_session, client_id, AGE_PARAMETER_CODE)
    assert age_row is not None
    assert age_row.value == _STALE_AGE
    assert age_row.expiration_date < now_utc()
    assert await _get_history(db_session, client_id, AGE_PARAMETER_CODE) == []


async def test_answer_rejected_when_age_validity_missing_in_catalog(db_session: AsyncSession, factory: Factory) -> None:
    """Нет validity_period для age → CatalogConsistencyError, ответ не сохранён целиком (bug #195).

    Состояние подменяется на шве чтения справочника, а не в БД: `parameters.validity_period` — NOT NULL,
    а удалить строку `age` мешают FK из instruments_parameters/patients_parameters.
    """
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    catalog = await make_http_catalog(db_session)
    catalog.parameters = MappingProxyType(
        {code: parameter for code, parameter in catalog.parameters.items() if code != AGE_PARAMETER_CODE}
    )
    service = RiskCommunicationService(db_session, catalog)

    with pytest.raises(CatalogConsistencyError):
        await _answer_date(service, client_id, _BIRTHDATE)

    # Деривация от ответа неотделима: транзакция откатывается целиком, birthdate тоже не записан.
    assert (await _get_param(db_session, client_id, AGE_PARAMETER_CODE)) is None
    assert (await _get_param(db_session, client_id, BIRTHDATE_PARAMETER_CODE)) is None


# --- ПДн в логах деривации (design D6) ---
#
# Дата рождения и возраст — ПДн, и MonologFormatter их здесь не спасёт: он маскирует по СПИСКУ
# ключей, а флаги вроде has_birthdate/derived в нём не значатся. Инвариант держится только на
# дисциплине вызывающего, поэтому проверяем фактическую полезную нагрузку записей.


@contextmanager
def _capture_app_logs() -> Iterator[list[logging.LogRecord]]:
    """Все записи логгера "app" за время блока.

    Не caplog: логгер поднят с propagate=False и до root-хендлера caplog не доходит (тот же приём —
    в tests/integration/risk_event/test_service.py). Свой handler ловит не только `notice`
    деривации, но и всё остальное, что сервис пишет по ходу ответа.
    """
    records: list[logging.LogRecord] = []

    class _Collector(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            records.append(record)

    app_logger = logging.getLogger("app")
    handler = _Collector(level=logging.NOTSET)
    app_logger.addHandler(handler)
    try:
        yield records
    finally:
        app_logger.removeHandler(handler)


def _leaf_values(value: object) -> list[object]:
    """Все листовые значения контекста — включая вложенные в списки (changed_params) и словари."""
    if isinstance(value, dict):
        return [leaf for item in value.values() for leaf in _leaf_values(item)]
    if isinstance(value, list | tuple | set):
        return [leaf for item in value for leaf in _leaf_values(item)]
    return [value]


def _assert_no_personal_values(records: list[logging.LogRecord], forbidden: set[object]) -> None:
    """Ни под каким ключом и ни в одном тексте сообщения — сравнение по ЗНАЧЕНИЯМ.

    Список ключей проверял бы только то, что мы уже написали; новое поле с ПДн такой тест пропустил бы.
    Сообщение (record.getMessage(), т.е. уже отрендеренный текст) проверяем ПОДСТРОЧНО: в f-string
    значение всегда встроено в окружающий текст, и проверка на равенство его бы не поймала
    (ревью !150, замечание #8).
    """
    assert records, "ожидались записи в логе — иначе проверка вырождается в тавтологию"
    for record in records:
        message = record.getMessage()
        for value in forbidden:
            assert str(value) not in message, f"в текст сообщения утекло значение ПДн: {value!r}"
        for leaf in _leaf_values(getattr(record, "log_context", {})):
            assert leaf not in forbidden, f"в log_context утекло значение ПДн: {leaf!r}"
            assert str(leaf) not in forbidden, f"в log_context утекло значение ПДн: {leaf!r}"


async def test_successful_derivation_logs_have_no_birthdate_or_age_values(
    db_session: AsyncSession, factory: Factory
) -> None:
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    with _capture_app_logs() as records:
        await _answer_date(service, client_id, _BIRTHDATE)

    age = _expected_age(_BIRTHDATE)
    _assert_no_personal_values(records, {_BIRTHDATE, str(age), age})


async def test_future_birthdate_skip_log_has_no_birthdate_or_age_values(
    db_session: AsyncSession, factory: Factory
) -> None:
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    future = (datetime.now(tz=UTC).date() + timedelta(days=365)).isoformat()
    with _capture_app_logs() as records:
        await _answer_date(service, client_id, future)

    age = _expected_age(future)
    assert age < 0
    _assert_no_personal_values(records, {future, str(age), age})


async def test_unparsable_birthdate_skip_log_has_no_birthdate_value(db_session: AsyncSession, factory: Factory) -> None:
    """Ветка пропуска по непарсибельному значению: в контексте только флаг и parameter_code."""
    client_id = unique_id("c")
    await factory.patient(patient_id=client_id, is_pregnant=False)
    skippable_question = unique_id("zq")
    await factory.question(code=skippable_question, type="date", is_skippable=True, group_code=1)
    await factory.option(
        code=f"{skippable_question}_01",
        question_code=skippable_question,
        parameter_code=BIRTHDATE_PARAMETER_CODE,
        value=None,
    )
    await db_session.commit()
    service = RiskCommunicationService(db_session, await make_http_catalog(db_session))

    with _capture_app_logs() as records:
        await service.handle(
            client_id=client_id,
            question_code=skippable_question,
            system_code=None,
            body=AnswerRequest(is_skipped=True),
        )

    skip_records = [r for r in records if "age derivation skipped" in r.getMessage()]
    assert len(skip_records) == 1
    assert getattr(skip_records[0], "log_context", {}) == {
        "parameter_code": BIRTHDATE_PARAMETER_CODE,
        "has_birthdate": True,
    }
