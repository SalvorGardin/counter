import re
from collections.abc import Iterator
from contextlib import contextmanager

import pytest
from httpx2 import AsyncClient
from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.catalog.http import HttpCatalog
from src.infra.database import get_http_catalog
from src.main import app
from src.services.risk_communication.domain.constants import (
    CHRONIC_DISEASES_QUESTION_CODE,
    MENOPAUSE_QUESTION_CODE,
    PREGNANCY_QUESTION_CODE,
)
from tests.factories import Factory, unique_id

pytest_plugins = ("tests.api.conftest",)

_REFERENCE_TABLES = (
    "conditions",
    "doctors",
    "instruments",
    "instruments_parameters",
    "options",
    "parameter_scores",
    "parameters",
    "questions",
    "recommendations",
    "recommended_doctors",
    "risk_factors",
    "systems",
    "systems_instruments",
)
_REFERENCE_SQL = re.compile(
    rf"\b(?:from|join|update|into)\s+(?:\w+\.)?(?:{'|'.join(_REFERENCE_TABLES)})\b",
    re.IGNORECASE,
)


@contextmanager
def _record_sql(session: AsyncSession) -> Iterator[list[str]]:
    statements: list[str] = []
    bind = session.sync_session.bind
    assert bind is not None

    def before_cursor_execute(_conn, _cursor, statement, _parameters, _context, _executemany) -> None:
        statements.append(statement)

    event.listen(bind, "before_cursor_execute", before_cursor_execute)
    try:
        yield statements
    finally:
        event.remove(bind, "before_cursor_execute", before_cursor_execute)


def _http_catalog() -> HttpCatalog:
    dependency = app.dependency_overrides[get_http_catalog]
    catalog = dependency()
    assert isinstance(catalog, HttpCatalog)
    return catalog


def _ordinary_option(catalog: HttpCatalog) -> tuple[str, str]:
    special = {
        PREGNANCY_QUESTION_CODE,
        MENOPAUSE_QUESTION_CODE,
        CHRONIC_DISEASES_QUESTION_CODE,
    }
    for question in catalog.ordered_questions:
        options = catalog.options_by_question.get(question.code, ())
        if question.code not in special and question.type in {"select", "boolean"} and options:
            return question.code, options[0].code
    raise AssertionError("seeded catalog has no ordinary option-based question")


@pytest.mark.parametrize("version", ["v1", "v2"])
async def test_no_answer_request_issues_no_reference_sql(
    version: str,
    async_client: AsyncClient,
    db_session: AsyncSession,
    factory: Factory,
) -> None:
    patient_id = unique_id("query-boundary")
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await db_session.commit()

    with _record_sql(db_session) as statements:
        response = await async_client.post(f"/api/{version}/clients/{patient_id}/questions/answers", json={})

    assert response.status_code == 200, response.text
    assert statements
    assert not [statement for statement in statements if _REFERENCE_SQL.search(statement)]


@pytest.mark.parametrize("version", ["v1", "v2"])
async def test_answer_request_issues_no_reference_sql(
    version: str,
    async_client: AsyncClient,
    db_session: AsyncSession,
    factory: Factory,
) -> None:
    patient_id = unique_id("query-boundary")
    await factory.patient(patient_id=patient_id, is_pregnant=False)
    await db_session.commit()
    question_code, option_code = _ordinary_option(_http_catalog())

    with _record_sql(db_session) as statements:
        response = await async_client.post(
            f"/api/{version}/clients/{patient_id}/questions/answers",
            params={"questionCode": question_code},
            json={"optionCodes": [option_code]},
        )

    assert response.status_code == 200, response.text
    assert statements
    assert not [statement for statement in statements if _REFERENCE_SQL.search(statement)]
