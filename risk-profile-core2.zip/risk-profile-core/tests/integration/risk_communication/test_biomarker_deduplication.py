"""Отсев представлений биомаркера не меняет состояние опроса пациента."""

from datetime import UTC, datetime, timedelta

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest
from tests.factories import Factory, unique_id
from tests.integration.risk_communication.conftest import RcServiceFactory


async def test_excluded_instrument_value_remains_an_answered_question(
    db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
) -> None:
    patient_id = await factory.patient()
    await factory.answer_all_real_question_params(patient_id=patient_id)

    source_code = unique_id("biomarker_source")
    value_code = unique_id("biomarker_value")
    next_code = unique_id("next_parameter")
    await factory.instrument_with_params(
        required=[source_code, value_code, next_code],
        system_code="COMMON",
    )
    answered_question = unique_id("answered_question")
    next_question = unique_id("next_question")
    await factory.question(answered_question, group_code=1, is_skippable=True)
    await factory.option(
        unique_id("answered_option"),
        question_code=answered_question,
        parameter_code=source_code,
        value="60",
    )
    await factory.question(next_question, group_code=2, is_skippable=True)
    await factory.option(
        unique_id("next_option"),
        question_code=next_question,
        parameter_code=next_code,
        value="Да",
    )
    await factory.biomarker(parameter_code=source_code)
    await factory.biomarker_mapping(
        biomarker_parameter_code=source_code,
        parameter_code=value_code,
        mapping_type="value",
    )

    now = datetime.now(tz=UTC)
    await factory.answer(
        patient_id=patient_id,
        parameter_code=source_code,
        value="60",
        date_time=now - timedelta(minutes=1),
    )
    await factory.answer(patient_id=patient_id, parameter_code=value_code, value="100", date_time=now)
    await db_session.commit()

    service = await rc_service()
    response, _ = await service.handle(
        client_id=patient_id,
        question_code=None,
        system_code="COMMON",
        body=AnswerRequest(),
    )

    assert response.question is not None
    assert response.question.question_code == next_question
    stored_count = await db_session.scalar(
        text(
            "SELECT count(*) FROM patients_parameters"
            " WHERE patient_id = :patient_id AND parameter_code IN (:source_code, :value_code)"
        ),
        {
            "patient_id": patient_id,
            "source_code": source_code,
            "value_code": value_code,
        },
    )
    assert stored_count == 2
