"""Регресс: вопрос даты рождения cq_020 после всех миграций имеет type='date', не 'numeric'.

0092 уже выставлял date, но полная перезаливка questions в 0096 затёрла его обратно в numeric
(см. 0098_fix_cq_020_birthdate_type_to_date). Этот тест ловит повторную регрессию, если следующий
reseed questions снова принесёт numeric из устаревшего catalog-CSV.
"""

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


async def test_cq_020_is_date_type(db_session: AsyncSession) -> None:
    question_type = (await db_session.execute(text("SELECT type FROM questions WHERE code = 'cq_020'"))).scalar_one()
    assert question_type == "date"
