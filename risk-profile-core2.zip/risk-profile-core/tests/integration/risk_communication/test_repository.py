"""Integration-тесты RiskCommunicationRepository."""

import asyncio
from datetime import timedelta

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.services.risk_communication.infra.repository import RiskCommunicationRepository
from tests.factories import Factory, now_utc, unique_id
from tests.integration.risk_communication.conftest import CommittedScope


class TestArchiveAndUpsertPatientParameter:
    async def test_inserts_when_no_existing_row(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = unique_id("p")
        param_code = unique_id("pc")
        await factory.patient(patient_id=patient_id)
        await factory.parameter(code=param_code)
        await db_session.commit()

        now = now_utc()
        async with db_session.begin():
            await RiskCommunicationRepository(db_session).archive_and_upsert_patient_parameter(
                patient_id=patient_id,
                parameter_code=param_code,
                value="hello",
                expiration_date=now + timedelta(days=10),
                date_time=now,
            )

        rows = (
            await db_session.execute(
                text(
                    "SELECT value, source, date_time FROM patients_parameters"
                    " WHERE patient_id = :pid AND parameter_code = :code"
                ),
                {"pid": patient_id, "code": param_code},
            )
        ).all()
        assert len(rows) == 1
        assert rows[0].value == "hello"
        assert rows[0].source == "FORM"
        assert abs((rows[0].date_time - now).total_seconds()) < 1

        history = (
            await db_session.execute(
                text("SELECT count(*) FROM patients_parameters_history WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).scalar_one()
        assert history == 0

    async def test_updates_existing_and_archives_old_value(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = unique_id("p")
        param_code = unique_id("pc")
        await factory.patient(patient_id=patient_id)
        await factory.parameter(code=param_code)
        old_exp = now_utc() + timedelta(days=5)
        old_dt = now_utc() - timedelta(days=100)  # заведомо в прошлом — отличается от нового date_time.
        await factory.answer(
            patient_id=patient_id,
            parameter_code=param_code,
            value="old",
            expiration_date=old_exp,
            date_time=old_dt,
            source="test-seed",
        )
        await db_session.commit()

        new_exp = now_utc() + timedelta(days=20)
        new_dt = now_utc()
        async with db_session.begin():
            await RiskCommunicationRepository(db_session).archive_and_upsert_patient_parameter(
                patient_id=patient_id,
                parameter_code=param_code,
                value="new",
                expiration_date=new_exp,
                date_time=new_dt,
            )

        current = (
            await db_session.execute(
                text("SELECT value, source, date_time FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).all()
        assert len(current) == 1
        assert current[0].value == "new"
        assert current[0].source == "FORM"
        # Актуальная строка получает НОВЫЙ момент записи.
        assert abs((current[0].date_time - new_dt).total_seconds()) < 1

        archived = (
            await db_session.execute(
                text("SELECT value, source, date_time FROM patients_parameters_history WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).all()
        assert len(archived) == 1
        assert archived[0].value == "old"
        assert archived[0].source == "test-seed"
        # В history сохраняется ОРИГИНАЛЬНЫЙ момент записи архивируемого значения.
        assert abs((archived[0].date_time - old_dt).total_seconds()) < 1


class TestSetPregnancy:
    async def test_updates_is_pregnant_true(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = unique_id("p")
        await factory.patient(patient_id=patient_id, is_pregnant=False)
        await db_session.commit()

        async with db_session.begin():
            await RiskCommunicationRepository(db_session).set_pregnancy(patient_id, is_pregnant=True)

        result = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).scalar_one()
        assert result is True

    async def test_updates_is_pregnant_false(self, db_session: AsyncSession, factory: Factory) -> None:
        patient_id = unique_id("p")
        await factory.patient(patient_id=patient_id, is_pregnant=True)
        await db_session.commit()

        async with db_session.begin():
            await RiskCommunicationRepository(db_session).set_pregnancy(patient_id, is_pregnant=False)

        result = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": patient_id},
            )
        ).scalar_one()
        assert result is False


class TestConcurrentUpsert:
    async def test_no_duplicate_rows_under_concurrent_insert_race(self, committed_scope: CommittedScope) -> None:
        """Two concurrent writers on the same (patient_id, parameter_code) must not produce
        duplicate rows or raise an IntegrityError — the ON CONFLICT clause must absorb the race."""
        exp = now_utc() + timedelta(days=10)

        async def upsert(value: str) -> None:
            async with AsyncSession(committed_scope.engine) as session:
                async with session.begin():
                    await RiskCommunicationRepository(session).archive_and_upsert_patient_parameter(
                        patient_id=committed_scope.patient_id,
                        parameter_code=committed_scope.parameter_code,
                        value=value,
                        expiration_date=exp,
                        date_time=now_utc(),
                    )

        await asyncio.gather(upsert("v1"), upsert("v2"))

        async with AsyncSession(committed_scope.engine) as session:
            rows = (
                await session.execute(
                    text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :code"),
                    {"pid": committed_scope.patient_id, "code": committed_scope.parameter_code},
                )
            ).all()

        assert len(rows) == 1
        assert rows[0].value in ("v1", "v2")
