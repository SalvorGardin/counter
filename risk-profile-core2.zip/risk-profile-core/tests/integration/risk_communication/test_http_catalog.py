"""HttpCatalog поверх реальной БД: те выборки справочника, что раньше делал SQL в reader'ах.

Юнит-тест tests/unit/infra/test_http_catalog.py проверяет сборку индексов на DTO в памяти. Здесь
проверяется, что каталог, собранный из настоящих таблиц, отдаёт те же поля, порядок и обработку
NULL, которые гарантировали удалённые `SELECT`-методы (`find_question`, `get_options_for_question`,
`list_systems_by_rang`, `get_questions_for_params`, `get_conditions_by_question` и остальные).
Каталог резидентный: после любой правки справочника в тесте его надо пересобрать (`make_http_catalog`).
"""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.parameter import Parameter
from tests.conftest import make_http_catalog
from tests.factories import Factory, unique_id, validity_period_for_days


async def test_make_http_catalog_preserves_callers_uncommitted_transaction(
    db_session: AsyncSession, factory: Factory
) -> None:
    parameter_code = unique_id("p-uncommitted")
    await factory.parameter(code=parameter_code)

    catalog = await make_http_catalog(db_session)

    assert parameter_code in catalog.parameters
    assert db_session.in_transaction()
    assert await db_session.scalar(select(Parameter).where(Parameter.code == parameter_code)) is not None


class TestReferenceLookups:
    async def test_exposes_every_field_order_and_null_handling_of_the_removed_selects(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        system_code = unique_id("S-catalog")
        instrument_code = unique_id("I-catalog")
        parameter_code = unique_id("p-catalog")
        question_codes = [unique_id("q-catalog"), unique_id("q-catalog")]
        option_codes = [unique_id("o-catalog"), unique_id("o-catalog")]

        await factory.system(code=system_code, description="Catalog system", rang=987_654)
        await factory.instrument(code=instrument_code)
        await factory.link_system_instrument(system_code=system_code, instrument_code=instrument_code)
        await factory.parameter(code=parameter_code, validity_days=17)
        await factory.link_parameter(instrument_code=instrument_code, parameter_code=parameter_code)
        for index, question_code in enumerate(question_codes, start=1):
            await factory.question(code=question_code, group_code=index, type="select", is_skippable=index == 2)
            # У второй опции value = NULL: колонки text в options нет, и наружу должна уйти
            # пустая строка, а не None (см. option_views_for_question).
            await factory.option(
                code=option_codes[index - 1],
                question_code=question_code,
                parameter_code=parameter_code,
                value=None if index == 2 else "yes",
            )
        await factory.condition(
            type="except", question_code=question_codes[0], parameter_code=parameter_code, value="no"
        )
        await db_session.commit()

        catalog = await make_http_catalog(db_session)

        question = catalog.question_view(question_codes[1])
        assert question is not None
        assert (question.code, question.text, question.type, question.is_skippable, question.group_code) == (
            question_codes[1],
            "вопрос",
            "select",
            True,
            2,
        )
        assert catalog.question_view(unique_id("missing")) is None

        option = catalog.option_view(option_codes[1])
        assert option is not None
        assert (option.code, option.value, option.parameter_code, option.text) == (
            option_codes[1],
            None,
            parameter_code,
            "",
        )
        assert catalog.option_views_for_question(question_codes[1]) == [option]
        assert catalog.option_view(unique_id("missing")) is None

        assert catalog.parameters[parameter_code].validity_period == validity_period_for_days(17)

        system = catalog.system_view(system_code)
        assert system is not None
        assert (system.code, system.name) == (system_code, "Catalog system")
        assert catalog.system_view(unique_id("missing")) is None

        assert set(catalog.parameter_codes_by_system[system_code]) == {parameter_code}
        assert {code: set(catalog.parameter_codes_by_question.get(code, ())) for code in question_codes} == {
            code: {parameter_code} for code in question_codes
        }
        assert [q.code for q in catalog.question_views_for_params([parameter_code])] == question_codes

        conditions = catalog.condition_views_by_question(question_codes)
        assert set(conditions) == set(question_codes)
        assert conditions[question_codes[1]] == []
        assert len(conditions[question_codes[0]]) == 1
        assert (conditions[question_codes[0]][0].type, conditions[question_codes[0]][0].value) == ("except", "no")

    async def test_questions_are_ordered_by_group_code_then_question_id(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        # Порядок шага 10: раньше его давал ORDER BY group_code, question_id в get_questions_for_params.
        parameter_code = unique_id("p-order")
        await factory.parameter(code=parameter_code)
        codes = {suffix: unique_id(f"q-{suffix}") for suffix in ("late", "early", "mid2", "mid1")}
        # Вставляем в порядке, обратном ожидаемому: group_code решает, а внутри группы — question_id
        # (порядок вставки), поэтому mid2 обязан остаться перед mid1.
        for suffix, group in (("late", 10), ("early", 1), ("mid2", 5), ("mid1", 5)):
            await factory.question(code=codes[suffix], group_code=group, is_skippable=True)
            await factory.option(
                code=unique_id("o-order"), question_code=codes[suffix], parameter_code=parameter_code, value="yes"
            )
        await db_session.commit()

        catalog = await make_http_catalog(db_session)

        assert [q.code for q in catalog.question_views_for_params([parameter_code])] == [
            codes["early"],
            codes["mid2"],
            codes["mid1"],
            codes["late"],
        ]

    async def test_options_of_a_question_are_ordered_by_option_id(
        self, db_session: AsyncSession, factory: Factory
    ) -> None:
        parameter_code = unique_id("p-opt")
        question_code = unique_id("q-opt")
        await factory.parameter(code=parameter_code)
        await factory.question(code=question_code, group_code=1, is_skippable=True)
        option_codes = [unique_id("o-opt") for _ in range(3)]
        for code in option_codes:
            await factory.option(code=code, question_code=question_code, parameter_code=parameter_code, value=code)
        await db_session.commit()

        catalog = await make_http_catalog(db_session)

        assert [o.code for o in catalog.option_views_for_question(question_code)] == option_codes

    async def test_systems_are_ordered_by_rang(self, db_session: AsyncSession, factory: Factory) -> None:
        # Порядок перебора систем в selection: раньше — ORDER BY rang ASC в list_systems_by_rang.
        # Ранги подобраны так, чтобы порядок вставки был обратен ожидаемому.
        codes = {rang: unique_id("S-rang") for rang in (987_601, 987_603, 987_602)}
        for rang, code in codes.items():
            await factory.system(code=code, description=code, rang=rang)
        await db_session.commit()

        catalog = await make_http_catalog(db_session)

        ordered = [row.code for row in catalog.ordered_systems if row.code in set(codes.values())]
        assert ordered == [codes[987_601], codes[987_602], codes[987_603]]
