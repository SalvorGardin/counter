"""Фикстуры risk-communication тестов."""

from collections.abc import AsyncIterator, Awaitable, Callable, Sequence
from dataclasses import dataclass

import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine

from src.services.risk_communication.service import RiskCommunicationService
from tests.conftest import PHYSICAL_CONNECT_ARGS, make_http_catalog
from tests.factories import Factory, unique_id

RcServiceFactory = Callable[[], Awaitable[RiskCommunicationService]]


@dataclass(frozen=True, slots=True)
class Scenario:
    """Засеянный и закоммиченный контекст одного risk-communication теста."""

    patient_id: str
    parameter_code: str
    question_code: str
    instrument_code: str
    system_code: str
    service: RiskCommunicationService


RcScenarioFactory = Callable[..., Awaitable[Scenario]]


@pytest_asyncio.fixture
async def rc_service(db_session: AsyncSession) -> RcServiceFactory:
    """Фабрика сервиса: вызывать после всех справочных сидов и commit теста."""

    async def _make() -> RiskCommunicationService:
        return RiskCommunicationService(db_session, await make_http_catalog(db_session))

    return _make


@pytest_asyncio.fixture
async def rc_scenario(factory: Factory, rc_service: RcServiceFactory, db_session: AsyncSession) -> RcScenarioFactory:
    """Пациент и один синтетический вопрос существующей системы вместе с сервисом.

    Система не создаётся: `COMMON` и остальные передаваемые коды принадлежат каталогу миграций.
    Строгие фабрики создают только уникальные строки самого сценария.
    """

    async def _make(
        *,
        options: Sequence[tuple[str, str | None]] = (),
        question_type: str = "select",
        is_skippable: bool = True,
        group_code: int = 1,
        system_code: str = "COMMON",
        answer_real_questions: bool = False,
    ) -> Scenario:
        patient_id = await factory.patient()
        if answer_real_questions:
            await factory.answer_all_real_question_params(patient_id=patient_id)

        parameter_code = unique_id("pc")
        question_code = unique_id("q")
        instrument_code = await factory.instrument_with_params(
            required=[parameter_code],
            system_code=system_code,
        )
        await factory.question(
            question_code,
            type=question_type,
            is_skippable=is_skippable,
            group_code=group_code,
        )
        for option_code, value in options:
            await factory.option(
                option_code,
                question_code=question_code,
                parameter_code=parameter_code,
                value=value,
            )

        await db_session.commit()
        return Scenario(
            patient_id=patient_id,
            parameter_code=parameter_code,
            question_code=question_code,
            instrument_code=instrument_code,
            system_code=system_code,
            service=await rc_service(),
        )

    return _make


@dataclass(frozen=True, slots=True)
class CommittedScope:
    """Пациент и параметр, закоммиченные мимо откатываемой транзакции теста.

    Отдельный engine нужен тестам, которые проверяют поведение нескольких реальных
    соединений: сессионная `factory` пишет в транзакцию теста, и её данные другие
    писатели не увидят. Обратная сторона — строки переживают тест, поэтому их удаляет
    finalizer, а не общий rollback.
    """

    engine: AsyncEngine
    patient_id: str
    parameter_code: str


@pytest_asyncio.fixture
async def committed_scope(postgres_url: str) -> AsyncIterator[CommittedScope]:
    engine = create_async_engine(postgres_url, connect_args=PHYSICAL_CONNECT_ARGS)
    patient_id = unique_id("p")
    parameter_code = unique_id("pc")

    try:
        async with AsyncSession(engine) as session:
            async with session.begin():
                setup = Factory(session)
                await setup.patient(patient_id=patient_id)
                await setup.parameter(parameter_code)

        yield CommittedScope(engine=engine, patient_id=patient_id, parameter_code=parameter_code)
    finally:
        try:
            # Порядок обратен внешним ключам: сначала строки ответов, затем их справочники.
            async with engine.begin() as conn:
                await conn.execute(
                    text("DELETE FROM patients_parameters_history WHERE patient_id = :pid"),
                    {"pid": patient_id},
                )
                await conn.execute(
                    text("DELETE FROM patients_parameters WHERE patient_id = :pid"),
                    {"pid": patient_id},
                )
                await conn.execute(text("DELETE FROM patients WHERE patient_id = :pid"), {"pid": patient_id})
                await conn.execute(text("DELETE FROM parameters WHERE code = :code"), {"code": parameter_code})
        finally:
            await engine.dispose()
