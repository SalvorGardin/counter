"""End-to-end integration-тесты RiskCommunicationService."""

from datetime import timedelta
from types import MappingProxyType

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest
from src.services.risk_communication.domain.constants import PREGNANCY_QUESTION_CODE
from src.services.risk_communication.domain.exceptions import (
    CatalogConsistencyError,
    ClientNotFoundError,
    InvalidAnswerTypeError,
    InvalidOptionCodeError,
    QuestionNotFoundError,
    QuestionNotSkippableError,
    SystemCodeNotFoundError,
)
from src.services.risk_communication.service import (
    _OPTION_CODE_NOT_PREGNANT,
    _OPTION_CODE_PREGNANT,
    MENOPAUSE_QUESTION_CODE,
    MENOPAUSE_TRUE_OPTION_CODE,
    REGULAR_MENSES_PARAM_CODE,
    RiskCommunicationService,
)
from tests.conftest import make_http_catalog
from tests.consts import GENDER_FEMALE, PARAMETER_CODE_BIRTHDATE, PARAMETER_CODE_GENDER
from tests.factories import Factory, now_utc, unique_id, unique_rang
from tests.integration.risk_communication.conftest import RcScenarioFactory, RcServiceFactory

# --- 404-сценарии ---


class TestNotFound:
    async def test_unknown_client_raises(self, db_session: AsyncSession, rc_service: RcServiceFactory) -> None:
        service = await rc_service()
        with pytest.raises(ClientNotFoundError):
            await service.handle(
                client_id=unique_id("missing"),
                question_code=None,
                system_code=None,
                body=AnswerRequest(),
            )

    async def test_unknown_question_raises(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(QuestionNotFoundError):
            await service.handle(
                client_id=pid,
                question_code="missing-question-code",
                system_code=None,
                body=AnswerRequest(answer="x"),
            )

    async def test_unknown_system_code_raises(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(SystemCodeNotFoundError):
            await service.handle(
                client_id=pid,
                question_code=None,
                system_code=unique_id("missing-system"),
                body=AnswerRequest(),
            )

    async def test_unknown_system_code_does_not_save_answer(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        """Контракт шаг 2: при несуществующем systemCode ответ не сохраняется (транзакция откатывается)."""
        scenario = await rc_scenario(options=[("a1", "Низкий"), ("a2", "Высокий")])

        with pytest.raises(SystemCodeNotFoundError):
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=unique_id("missing-system"),
                body=AnswerRequest(option_codes=["a2"]),
            )

        rows = (
            await db_session.execute(
                text("SELECT 1 FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).all()
        assert rows == []


# --- Первый вызов (без question_code) — возвращает первый COMMON-вопрос ---


class TestFirstCall:
    async def test_returns_common_question(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # Answer all real catalog group_code=1 questions first so only our synthetic remains visible.
        scenario = await rc_scenario(
            options=[("a1", "Низкий"), ("a2", "Высокий")],
            answer_real_questions=True,
        )

        response, _ = await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=None,
            system_code=None,
            body=AnswerRequest(),
        )

        assert response.is_success is True
        assert response.system_code == "COMMON"
        assert response.question is not None
        assert response.question.question_code == scenario.question_code
        assert response.question.type == "select"
        assert response.question.options is not None
        assert {o.option_code for o in response.question.options} == {"a1", "a2"}
        # Precise % isn't asserted: the real catalog inflates the universe so the number
        # is no longer a clean "0 answered / 1 unanswered".


# --- Сохранение ответов разных типов ---


class TestSaveAnswers:
    async def test_option_codes_writes_value_from_options(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        scenario = await rc_scenario(options=[("a1", "Низкий"), ("a2", "Высокий")])

        await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=scenario.question_code,
            system_code=None,
            body=AnswerRequest(option_codes=["a2"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).all()
        assert len(rows) == 1
        assert rows[0].value == "Высокий"

    async def test_numeric_answer_writes_normalized_decimal(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # numeric-вопросы хранят одну option-запись (parameter_code и validity берутся оттуда).
        scenario = await rc_scenario(
            question_type="numeric",
            options=[(unique_id("opt"), None)],
        )

        # Лидирующие и замыкающие нули не подмешиваются: "0001.500" → "1.5".
        await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=scenario.question_code,
            system_code=None,
            body=AnswerRequest(answer="0001.500"),
        )

        value = (
            await db_session.execute(
                text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).scalar_one()
        assert value == "1.5"

    async def test_numeric_answer_invalid_string_raises(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        scenario = await rc_scenario(
            question_type="numeric",
            options=[(unique_id("opt"), None)],
        )

        with pytest.raises(InvalidAnswerTypeError):
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(answer="всё хорошо"),
            )

    async def test_date_answer_stores_iso_string_as_is(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # Регрессия #47: до фикса type="date" попадал в coerce_numeric_answer и отвергал "1990-03-01".
        scenario = await rc_scenario(
            question_type="date",
            options=[(unique_id("opt"), None)],
        )

        await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=scenario.question_code,
            system_code=None,
            body=AnswerRequest(answer="1990-03-01"),
        )

        value = (
            await db_session.execute(
                text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).scalar_one()
        assert value == "1990-03-01"

    async def test_date_answer_invalid_string_raises(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # Симметрично numeric: не-ISO дата отвергается на границе (а не молча падает позже в age-условиях).
        scenario = await rc_scenario(
            question_type="date",
            options=[(unique_id("opt"), None)],
        )

        with pytest.raises(InvalidAnswerTypeError):
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(answer="14.05.1987"),
            )

    async def test_date_question_in_response_has_type_numeric_and_no_options(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # Регрессия: type="date" в БД должен возвращаться как type="numeric" в API (публичный
        # контракт не меняем) и без options (как у любого open-ended вопроса).
        scenario = await rc_scenario(
            question_type="date",
            options=[(unique_id("opt"), None)],
            answer_real_questions=True,
        )

        response, _ = await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=None,
            system_code=None,
            body=AnswerRequest(),
        )

        assert response.question is not None
        assert response.question.question_code == scenario.question_code
        assert response.question.type == "numeric"
        assert response.question.options is None

    async def test_skipped_writes_empty_string(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # При is_skipped parameter_code резолвится из options (как и для answer).
        scenario = await rc_scenario(
            options=[(unique_id("opt"), "ignored")],
        )

        await scenario.service.handle(
            client_id=scenario.patient_id,
            question_code=scenario.question_code,
            system_code=None,
            body=AnswerRequest(is_skipped=True),
        )

        value = (
            await db_session.execute(
                text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).scalar_one()
        assert value == ""

    async def test_skipped_without_options_raises_catalog_consistency(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        """Bug #195: у вопроса без option-записей parameter_code не разрешить — ответ не записать.

        Прежде такой скип отдавал 200, ничего не записав, и вопрос выдавался снова.
        """
        scenario = await rc_scenario()

        with pytest.raises(CatalogConsistencyError):
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(is_skipped=True),
            )

        count = (
            await db_session.execute(
                text("SELECT COUNT(*) FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": scenario.patient_id},
            )
        ).scalar_one()
        assert count == 0

    async def test_skipped_raises_when_not_skippable(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        scenario = await rc_scenario(
            is_skippable=False,
            options=[(unique_id("opt"), "ignored")],
        )

        with pytest.raises(QuestionNotSkippableError):
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(is_skipped=True),
            )

        count = (
            await db_session.execute(
                text("SELECT COUNT(*) FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).scalar_one()
        assert count == 0


# --- Валидация соответствия типа ответа типу вопроса (#117) ---


class TestAnswerTypeValidation:
    @pytest.mark.parametrize("question_type", ["select", "boolean", "multi"])
    async def test_answer_for_option_based_question_rejected(
        self,
        db_session: AsyncSession,
        factory: Factory,
        question_type: str,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        scenario = await rc_scenario(
            question_type=question_type,
            options=[("a1", "Низкий"), ("a2", "Высокий")],
        )

        with pytest.raises(InvalidAnswerTypeError) as exc_info:
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(answer="a2"),
            )
        assert str(exc_info.value) == (
            f"Вопрос типа {question_type} не поддерживает поле answer. Используйте optionCodes."
        )

        # Контракт шаг 3: при ошибке ответ не сохраняется (транзакция откатывается).
        rows = (
            await db_session.execute(
                text("SELECT 1 FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).all()
        assert rows == []

    async def test_option_codes_for_numeric_question_rejected(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        scenario = await rc_scenario(
            question_type="numeric",
            options=[(unique_id("opt"), None)],
        )

        with pytest.raises(InvalidAnswerTypeError) as exc_info:
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["75"]),
            )
        assert str(exc_info.value) == "Вопрос типа numeric не поддерживает поле optionCodes. Используйте answer."

        rows = (
            await db_session.execute(
                text("SELECT 1 FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).all()
        assert rows == []

    async def test_option_codes_for_date_question_rejected_with_numeric_type(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
        rc_scenario: RcScenarioFactory,
    ) -> None:
        # date — внутренний DB-тип, наружу numeric: сообщение об ошибке тоже должно говорить numeric, не date.
        scenario = await rc_scenario(
            question_type="date",
            options=[(unique_id("opt"), None)],
        )

        with pytest.raises(InvalidAnswerTypeError) as exc_info:
            await scenario.service.handle(
                client_id=scenario.patient_id,
                question_code=scenario.question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["a1"]),
            )
        assert str(exc_info.value) == "Вопрос типа numeric не поддерживает поле optionCodes. Используйте answer."

        rows = (
            await db_session.execute(
                text("SELECT 1 FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": scenario.patient_id, "pc": scenario.parameter_code},
            )
        ).all()
        assert rows == []


# --- cq_030 беременность ---


class TestPregnancyFlow:
    async def test_true_sets_is_pregnant_and_returns_100(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # cq_030 + его опции (yes/no) заведены сидом каталога — переиспользуем их.
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code="cq_030",
            system_code=None,
            body=AnswerRequest(option_codes=[_OPTION_CODE_PREGNANT]),
        )

        assert response.system_completion_percentage == 100
        assert response.question is None
        assert response.system_code is None

        is_pregnant = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).scalar_one()
        assert is_pregnant is True

    async def test_false_keeps_flow_going(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid, is_pregnant=False)
        # cq_030 (is_pregnant) is special-cased: answering "no" via the API sets the patient
        # flag but writes NO row to patients_parameters. So we must pre-answer is_pregnant
        # ourselves to make COMMON fully complete after the API call.
        await factory.answer_all_real_question_params(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code="cq_030",
            system_code=None,
            body=AnswerRequest(option_codes=["no"]),
        )

        # Беременности нет → метод проходит дальше до шага 12. Если COMMON-вопросов больше нет —
        # вернётся 100% и пустой ответ (что и есть случай с минимальным сидингом).
        is_pregnant = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).scalar_one()
        assert is_pregnant is False
        # Особый случай: ответ "no" на is_pregnant не пишется service'ом в patients_parameters
        # (source='FORM'). Pre-seeded row uses source='test-seed' — should still be the only one.
        rows = (
            await db_session.execute(
                text(
                    "SELECT count(*) FROM patients_parameters"
                    " WHERE patient_id = :pid AND parameter_code = 'is_pregnant' AND source = 'FORM'"
                ),
                {"pid": pid},
            )
        ).scalar_one()
        assert rows == 0
        assert response.system_completion_percentage == 100

    async def test_cq030_skipped_raises_not_skippable(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        """cq_030 имеет is_skippable=False в каталоге — isSkipped=true должен вернуть 400."""
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(QuestionNotSkippableError):
            await service.handle(
                client_id=pid,
                question_code="cq_030",
                system_code=None,
                body=AnswerRequest(is_skipped=True),
            )

    async def test_cq030_answer_rejected_as_boolean(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        """#117: cq_030 — boolean, поэтому answer отвергается до спец-ветки беременности.
        Раньше такой ответ молча игнорировался (notice + 200); теперь 400 INVALID_ANSWER_TYPE."""
        pid = unique_id("p")
        # Свежий, ни разу не отвечавший пациент → is_pregnant IS NULL (False = «ответил нет»).
        await factory.patient(patient_id=pid, is_pregnant=None)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(InvalidAnswerTypeError) as exc_info:
            await service.handle(
                client_id=pid,
                question_code="cq_030",
                system_code=None,
                body=AnswerRequest(answer="да"),
            )
        assert str(exc_info.value) == "Вопрос типа boolean не поддерживает поле answer. Используйте optionCodes."

        is_pregnant = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).scalar_one()
        assert is_pregnant is None

    async def test_pregnancy_does_not_change_expiration_dates(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        """Баг #101: подтверждение беременности (cq_030 → беременна) НЕ трогает expiration_date
        ни у одного параметра пациента. Не-применимость обеспечивает перерасчёт (#100), а не
        истечение параметров — иначе ответы пациентки терялись бы за время беременности.

        Регресс на удалённый шаг 4 (cap до now + 6 месяцев): параметр с expiration далеко в будущем
        раньше опускался, теперь должен остаться нетронутым."""
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # cq_030 заведён сидом каталога.
        regular = unique_id("pc")
        await factory.parameter(code=regular, validity_days=365)
        now = now_utc()
        # far заведомо дальше старого cap'а (6 мес) — именно эта строка раньше опускалась.
        far = now + timedelta(days=3650)
        await factory.answer(
            patient_id=pid,
            parameter_code=PARAMETER_CODE_BIRTHDATE,
            value="1990-01-01",
            expiration_date=far,
            source="test-seed",
        )
        await factory.answer(patient_id=pid, parameter_code=regular, value="x", expiration_date=far, source="test-seed")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code="cq_030",
            system_code=None,
            body=AnswerRequest(option_codes=[_OPTION_CODE_PREGNANT]),
        )
        assert response.system_completion_percentage == 100

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, expiration_date FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.expiration_date for r in rows}
        # Ни одна строка не изменилась — expiration_date остался исходным.
        assert (by_param[PARAMETER_CODE_BIRTHDATE] - far).total_seconds() == pytest.approx(0, abs=1)
        assert (by_param[regular] - far).total_seconds() == pytest.approx(0, abs=1)

    async def test_cq_030_offered_while_is_pregnant_is_null(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        """Зеркало исключения cq_030: пока is_pregnant IS NULL, вопрос считается неотвеченным.

        Исключение параметров cq_030 из набора неотвеченных включается только при
        is_pregnant IS NOT NULL. У пациентки, которая ещё не отвечала, набор исключений
        обязан быть пустым, иначе cq_030 не был бы задан никогда.
        """
        pid = unique_id("p")
        await factory.patient(patient_id=pid, is_pregnant=None)
        await db_session.commit()

        catalog = await make_http_catalog(db_session)
        pregnancy_params = catalog.parameter_codes_by_question.get(PREGNANCY_QUESTION_CODE, frozenset())
        assert pregnancy_params, "Каталог не связывает cq_030 ни с одним параметром — сид сломан"

        # Всё остальное отвечено, поэтому единственный видимый кандидат — cq_030.
        # Пол и дата рождения задаются явно: у cq_030 есть условия gender=Женский и age 1..49.
        await factory.answer_all_real_question_params(
            patient_id=pid,
            exclude={PARAMETER_CODE_GENDER, PARAMETER_CODE_BIRTHDATE} | set(pregnancy_params),
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=PARAMETER_CODE_GENDER,
            value=GENDER_FEMALE,
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=PARAMETER_CODE_BIRTHDATE,
            value=(now_utc() - timedelta(days=365 * 30)).date().isoformat(),
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(client_id=pid, question_code=None, system_code=None, body=AnswerRequest())

        assert response.question is not None, "Ожидался cq_030: is_pregnant IS NULL — ответа ещё не было"
        assert response.question.question_code == PREGNANCY_QUESTION_CODE

    async def test_cq_030_excluded_from_unanswered_once_is_pregnant_is_set(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        """Регрессия: после ответа «нет» на cq_030 метод не должен предложить cq_030 снова.

        Ответ на cq_030 хранится в patients.is_pregnant, а не в patients_parameters.
        До фикса шаги 7/11 считали соответствующий параметр (is_pregnant) неотвеченным и
        снова выбирали cq_030 как следующий вопрос → бесконечный цикл.
        """
        pid = unique_id("p")
        # is_pregnant=NULL — пациент ещё не отвечал на cq_030.
        await factory.patient(patient_id=pid, is_pregnant=None)
        await db_session.commit()

        service = await rc_service()
        # 1) Ответ «нет» на cq_030. patients.is_pregnant переходит NULL → False.
        first, _ = await service.handle(
            client_id=pid,
            question_code="cq_030",
            system_code=None,
            body=AnswerRequest(option_codes=[_OPTION_CODE_NOT_PREGNANT]),
        )
        is_pregnant = (
            await db_session.execute(
                text("SELECT is_pregnant FROM patients WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).scalar_one()
        await db_session.commit()
        assert is_pregnant is False
        # Безусловный assert: после ответа «нет» в каталоге всегда остаётся хотя бы один
        # неотвеченный COMMON-вопрос (демография gender/birthdate/...), и это НЕ должен быть cq_030.
        assert first.question is not None, "Ожидался следующий вопрос после ответа «нет» на cq_030"
        assert first.question.question_code != "cq_030", "Регрессия лупа: cq_030 снова выбран как следующий вопрос"

        # 2) Следующий запрос без questionCode — реальный шаг фронта за следующим вопросом.
        # До фикса именно тут возвращался cq_030 снова — луп.
        second, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=None,
            body=AnswerRequest(),
        )
        assert second.question is not None, "Ожидался следующий вопрос при повторном запросе без questionCode"
        assert second.question.question_code != "cq_030", "Регрессия лупа: cq_030 возвращается на следующем вызове"


# --- systemCode ---


class TestSystemCodeRouting:
    async def test_uses_passed_system_code_when_common_is_complete(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # Mark COMMON system fully complete by answering every param linked to a COMMON instrument.
        await factory.answer_system_params(patient_id=pid, system_code="COMMON")

        # Additional synthetic COMMON param, also already answered → COMMON 100%.
        common_param = unique_id("pc")
        common_question = unique_id("q-common")
        await factory.instrument_with_params(required=[common_param], system_code="COMMON")
        await factory.question(common_question, group_code=1, is_skippable=True)
        await factory.option(
            "a1",
            question_code=common_question,
            parameter_code=common_param,
            value="x",
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=common_param,
            value="answered",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )

        # Целевая система MENTAL, 1 параметр, не отвечен.
        mental_system = "MENTAL_TEST_" + unique_id("S")
        mental_instrument = unique_id("I")
        mental_param = unique_id("pc")
        mental_question = unique_id("q-mental")
        await factory.system(code=mental_system, description="Ментальное", rang=unique_rang())
        await factory.instrument(code=mental_instrument)
        await factory.link_system_instrument(system_code=mental_system, instrument_code=mental_instrument)
        await factory.parameter(code=mental_param)
        await factory.link_parameter(instrument_code=mental_instrument, parameter_code=mental_param)
        await factory.question(code=mental_question, group_code=1, is_skippable=True)
        await factory.option(code="m1", question_code=mental_question, parameter_code=mental_param, value="m1-val")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=mental_system,
            body=AnswerRequest(),
        )

        assert response.system_code == mental_system
        assert response.question is not None
        assert response.question.question_code == mental_question


# --- Conditions ---


class TestConditions:
    async def test_except_skips_question_when_patient_value_matches(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # Clear out catalog group_code=1 questions so only our synthetic ones drive visibility.
        await factory.answer_all_real_question_params(patient_id=pid)

        # COMMON с двумя вопросами; q-target имеет except-condition на parameter_code+value
        # — если у пациента активно записано это значение, q-target скрывается.
        prev_param = unique_id("pc")
        target_param = unique_id("pc")
        prev_q = unique_id("q-prev")
        target_q = unique_id("q-target")
        await factory.instrument_with_params(required=[prev_param], system_code="COMMON")
        await factory.question(prev_q, group_code=1, is_skippable=True)
        await factory.option(
            "opt-x",
            question_code=prev_q,
            parameter_code=prev_param,
            value="X",
        )
        await factory.instrument_with_params(required=[target_param], system_code="COMMON")
        await factory.question(target_q, group_code=2, is_skippable=True)
        await factory.option(
            "t1",
            question_code=target_q,
            parameter_code=target_param,
            value="T1",
        )
        await factory.condition(type="except", question_code=target_q, parameter_code=prev_param, value="X")
        await factory.answer(
            patient_id=pid,
            parameter_code=prev_param,
            value="X",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(client_id=pid, question_code=None, system_code=None, body=AnswerRequest())

        assert response.question is None

    async def test_age_filters_question_by_birthdate(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # Pre-answer real catalog group_code=1 questions except birthdate (test sets a teen value).
        await factory.answer_all_real_question_params(patient_id=pid, exclude={PARAMETER_CODE_BIRTHDATE})

        # COMMON: birthdate уже отвечен. И ещё один параметр с вопросом, у которого age 18..65.
        target_param = unique_id("pc")
        target_q = unique_id("q-age")
        await factory.instrument_with_params(required=[target_param], system_code="COMMON")
        await factory.question(target_q, group_code=1, is_skippable=True)
        await factory.option(
            "opt-y",
            question_code=target_q,
            parameter_code=target_param,
            value="Y",
        )
        # birthdate уже привязан сидами миграций к инструменту системы COMMON — своей строки
        # instruments_parameters тест не заводит.
        teen_birthdate = (now_utc() - timedelta(days=365 * 17)).date().isoformat()
        await factory.answer(
            patient_id=pid,
            parameter_code=PARAMETER_CODE_BIRTHDATE,
            value=teen_birthdate,
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        # age-condition использует parameter_code = birthdate (по спеке шаг 10); value не нужен.
        await factory.condition(
            type="age",
            question_code=target_q,
            parameter_code=PARAMETER_CODE_BIRTHDATE,
            min_age=18,
            max_age=65,
            value="",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(client_id=pid, question_code=None, system_code=None, body=AnswerRequest())

        assert response.question is None


# --- Прогресс ---


class TestProgress:
    async def test_half_answered_returns_50(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        # The exact 50% calculation hinges on a small question universe. With the real
        # catalog seeded, the universe is hundreds of questions. We pre-answer every catalog
        # question param, then seed exactly two synthetic COMMON questions (one answered, one
        # not) and verify the unanswered one surfaces — the test's structural intent. The
        # precise percentage assertion is relaxed (≥50, since 1 synthetic + many real answered).
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)
        p_answered = unique_id("pc")
        p_unanswered = unique_id("pc")
        q_answered = unique_id("q1")
        q_unanswered = unique_id("q2")
        icode = await factory.instrument_with_params(
            required=[p_answered],
            system_code="COMMON",
        )
        await factory.question(q_answered, group_code=1, is_skippable=True)
        await factory.option(
            "a1",
            question_code=q_answered,
            parameter_code=p_answered,
            value="A1",
        )
        await factory.parameter(code=p_unanswered)
        await factory.link_parameter(instrument_code=icode, parameter_code=p_unanswered)
        await factory.question(code=q_unanswered, group_code=2, is_skippable=True)
        await factory.option(code="b1", question_code=q_unanswered, parameter_code=p_unanswered, value="B1")
        await factory.answer(
            patient_id=pid,
            parameter_code=p_answered,
            value="A1",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(client_id=pid, question_code=None, system_code=None, body=AnswerRequest())

        assert response.question is not None
        assert response.question.question_code == q_unanswered
        assert 0 < response.system_completion_percentage < 100

    async def test_questions_completed_returns_100_and_null(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)
        # COMMON с одним параметром, уже отвечен. Других систем нет.
        param_code = unique_id("pc")
        question_code = unique_id("q")
        await factory.instrument_with_params(required=[param_code], system_code="COMMON")
        await factory.question(question_code, group_code=1, is_skippable=True)
        await factory.option(
            "a1",
            question_code=question_code,
            parameter_code=param_code,
            value="A1",
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=param_code,
            value="A1",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(client_id=pid, question_code=None, system_code=None, body=AnswerRequest())

        assert response.question is None
        assert response.system_code is None
        assert response.system_completion_percentage == 100


# --- Gate перехода COMMON → системные: пустой visibility не должен зависать ---


class TestCommonUnreachableAdvancesToSystem:
    async def test_advances_to_target_system_when_common_only_has_hidden_questions(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Сценарий бага: в COMMON остался unanswered параметр, но его единственный вопрос
        # скрыт except-condition. Раньше completion=100, опросник «завершён», per-system не задан.
        # Ожидаем: re-try пропускает COMMON и отдаёт вопрос из целевой системы (передан явно).
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)

        # Общий триггер-параметр, уже отвеченный значением "X".
        trigger_param = unique_id("trig")
        trigger_q = unique_id("q-trig")
        common_icode = await factory.instrument_with_params(
            required=[trigger_param],
            system_code="COMMON",
        )
        await factory.question(trigger_q, group_code=1, is_skippable=True)
        await factory.option(
            "x1",
            question_code=trigger_q,
            parameter_code=trigger_param,
            value="X",
        )
        await factory.answer(
            patient_id=pid,
            parameter_code=trigger_param,
            value="X",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )

        # «Недостижимый» COMMON-параметр: его вопрос скрыт except-condition по trigger=X.
        hidden_param = unique_id("hidden")
        hidden_q = unique_id("q-hidden")
        await factory.parameter(code=hidden_param)
        await factory.link_parameter(instrument_code=common_icode, parameter_code=hidden_param)
        await factory.question(code=hidden_q, group_code=1, is_skippable=True)
        await factory.option(code="h1", question_code=hidden_q, parameter_code=hidden_param, value="H1")
        await factory.condition(type="except", question_code=hidden_q, parameter_code=trigger_param, value="X")

        # Целевая система с одним видимым вопросом.
        target_system = unique_id("S-target")
        target_icode = unique_id("I-target")
        target_param = unique_id("tp")
        target_q = unique_id("q-target")
        await factory.system(code=target_system, description="Цель", rang=unique_rang())
        await factory.instrument(code=target_icode)
        await factory.link_system_instrument(system_code=target_system, instrument_code=target_icode)
        await factory.parameter(code=target_param)
        await factory.link_parameter(instrument_code=target_icode, parameter_code=target_param)
        await factory.question(code=target_q, group_code=1, is_skippable=True)
        await factory.option(code="t1", question_code=target_q, parameter_code=target_param, value="T1")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid, question_code=None, system_code=target_system, body=AnswerRequest()
        )

        assert response.question is not None
        assert response.question.question_code == target_q
        assert response.system_code == target_system

    async def test_empty_requested_system_falls_back_to_next_system(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Клиент передал system_code="CVD" уже после прохождения CVD. resolve_selection_system
        # на explicit request вернёт None. Service должен сам сделать retry без requested_system_code
        # и подобрать следующую систему — иначе клиент увидит фальшивое «опросник завершён».
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)

        # Уже «пустая» система (нет unanswered) — её и передадим как requested.
        empty_system = unique_id("S-empty")
        empty_icode = unique_id("I-empty")
        empty_param = unique_id("ep")
        await factory.system(code=empty_system, description="Пустая", rang=unique_rang())
        await factory.instrument(code=empty_icode)
        await factory.link_system_instrument(system_code=empty_system, instrument_code=empty_icode)
        await factory.parameter(code=empty_param)
        await factory.link_parameter(instrument_code=empty_icode, parameter_code=empty_param)
        await factory.answer(
            patient_id=pid,
            parameter_code=empty_param,
            value="X",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )

        # Целевая система с unanswered param и видимым вопросом — её должен подобрать fallback.
        next_system = unique_id("S-next")
        next_icode = unique_id("I-next")
        next_param = unique_id("np")
        next_q = unique_id("q-next")
        await factory.system(code=next_system, description="След.", rang=unique_rang())
        await factory.instrument(code=next_icode)
        await factory.link_system_instrument(system_code=next_system, instrument_code=next_icode)
        await factory.parameter(code=next_param)
        await factory.link_parameter(instrument_code=next_icode, parameter_code=next_param)
        await factory.question(code=next_q, group_code=1, is_skippable=True)
        await factory.option(code="n1", question_code=next_q, parameter_code=next_param, value="N1")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid, question_code=None, system_code=empty_system, body=AnswerRequest()
        )

        assert response.question is not None
        assert response.question.question_code == next_q
        assert response.system_code == next_system

    async def test_empty_requested_returns_completion_when_no_fallback(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Edge: explicit system_code на пустую систему И никаких других unanswered нет → fallback тоже
        # вернёт None. selected=None → завершение опроса, спец шаг 12: systemCompletionPercentage=100.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)

        empty_system = unique_id("S-empty")
        empty_icode = unique_id("I-empty")
        empty_param = unique_id("ep")
        await factory.system(code=empty_system, description="Пустая", rang=unique_rang())
        await factory.instrument(code=empty_icode)
        await factory.link_system_instrument(system_code=empty_system, instrument_code=empty_icode)
        await factory.parameter(code=empty_param)
        await factory.link_parameter(instrument_code=empty_icode, parameter_code=empty_param)
        await factory.answer(
            patient_id=pid,
            parameter_code=empty_param,
            value="X",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid, question_code=None, system_code=empty_system, body=AnswerRequest()
        )

        assert response.question is None
        # Ни одного видимого вопроса не осталось → завершение, 100%.
        assert response.system_completion_percentage == 100


# --- v2 (bug #132): завершение прохождения запрошенной системы вместо перехода к следующей ---


class TestV2SystemCompletion:
    async def test_completed_requested_system_returns_completion_signal(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Зеркало test_empty_requested_system_falls_back_to_next_system, но с флагом v2: пройдя CVD,
        # клиент ДОЛЖЕН получить её завершение (systemCode/question=null, %=100), а НЕ вопрос следующей
        # системы — хотя следующая система с видимым вопросом ещё существует.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)

        # Пройденная («пустая») система — её передаём как requested.
        empty_system = unique_id("S-empty")
        empty_icode = unique_id("I-empty")
        empty_param = unique_id("ep")
        await factory.system(code=empty_system, description="Пустая", rang=unique_rang())
        await factory.instrument(code=empty_icode)
        await factory.link_system_instrument(system_code=empty_system, instrument_code=empty_icode)
        await factory.parameter(code=empty_param)
        await factory.link_parameter(instrument_code=empty_icode, parameter_code=empty_param)
        await factory.answer(
            patient_id=pid,
            parameter_code=empty_param,
            value="X",
            expiration_date=now_utc() + timedelta(days=10),
            source="test-seed",
        )

        # Следующая система с unanswered param и видимым вопросом: под v1 её подобрал бы fallback,
        # под v2 её НЕ должно быть в ответе (short-circuit по запрошенной системе).
        next_system = unique_id("S-next")
        next_icode = unique_id("I-next")
        next_param = unique_id("np")
        next_q = unique_id("q-next")
        await factory.system(code=next_system, description="След.", rang=unique_rang())
        await factory.instrument(code=next_icode)
        await factory.link_system_instrument(system_code=next_system, instrument_code=next_icode)
        await factory.parameter(code=next_param)
        await factory.link_parameter(instrument_code=next_icode, parameter_code=next_param)
        await factory.question(code=next_q, group_code=1, is_skippable=True)
        await factory.option(code="n1", question_code=next_q, parameter_code=next_param, value="N1")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=empty_system,
            body=AnswerRequest(),
            complete_on_requested_system_done=True,
        )

        assert response.system_code is None
        assert response.system_name is None
        assert response.question is None
        # Per-system completion: запрошенная система пройдена → 100, несмотря на unanswered в next_system.
        assert response.system_completion_percentage == 100

    async def test_flag_does_not_fire_while_requested_system_has_questions(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Флаг влияет только на момент завершения системы. Пока у запрошенной системы есть видимый
        # вопрос — v2 отдаёт его так же, как v1 (short-circuit не срабатывает).
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # Зануляем реальный каталог (в т.ч. COMMON), иначе COMMON-перекрытие вернёт COMMON вместо target.
        await factory.answer_all_real_question_params(patient_id=pid)

        target_system = unique_id("S-target")
        target_icode = unique_id("I-target")
        target_param = unique_id("tp")
        target_q = unique_id("q-target")
        await factory.system(code=target_system, description="Целевая", rang=unique_rang())
        await factory.instrument(code=target_icode)
        await factory.link_system_instrument(system_code=target_system, instrument_code=target_icode)
        await factory.parameter(code=target_param)
        await factory.link_parameter(instrument_code=target_icode, parameter_code=target_param)
        await factory.question(code=target_q, group_code=1, is_skippable=True)
        await factory.option(code="t1", question_code=target_q, parameter_code=target_param, value="T1")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=target_system,
            body=AnswerRequest(),
            complete_on_requested_system_done=True,
        )

        assert response.system_code == target_system
        assert response.question is not None
        assert response.question.question_code == target_q

    async def test_flag_without_system_code_completes_normally(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Short-circuit завязан на `system_code is not None`. Без systemCode v2 идёт обычным
        # путём завершения (как v1): не должно быть регрессии для запросов «дай следующий вопрос».
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_all_real_question_params(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=None,
            body=AnswerRequest(),
            complete_on_requested_system_done=True,
        )

        assert response.system_code is None
        assert response.question is None
        assert response.system_completion_percentage == 100

    async def test_answering_last_question_saves_and_returns_completion(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Сквозной сценарий бага: ответ на последний вопрос системы CVD одновременно (а) сохраняется в
        # patients_parameters и (б) возвращает завершение системы.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # Зануляем реальный каталог (в т.ч. COMMON), чтобы завершение считалось по нашей системе CVD.
        await factory.answer_all_real_question_params(patient_id=pid)

        system = unique_id("S-cvd")
        icode = unique_id("I-cvd")
        param = unique_id("cp")
        question = unique_id("q-cvd")
        await factory.system(code=system, description="CVD", rang=unique_rang())
        await factory.instrument(code=icode)
        await factory.link_system_instrument(system_code=system, instrument_code=icode)
        await factory.parameter(code=param)
        await factory.link_parameter(instrument_code=icode, parameter_code=param)
        await factory.question(code=question, type="select", group_code=1, is_skippable=True)
        await factory.option(code="c1", question_code=question, parameter_code=param, value="C1")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=question,
            system_code=system,
            body=AnswerRequest(option_codes=["c1"]),
            complete_on_requested_system_done=True,
        )

        assert response.system_code is None
        assert response.question is None
        assert response.system_completion_percentage == 100

        saved = (
            await db_session.execute(
                text("SELECT value FROM patients_parameters WHERE patient_id = :pid AND parameter_code = :pc"),
                {"pid": pid, "pc": param},
            )
        ).scalar_one_or_none()
        assert saved == "C1"


# --- multi: Yes/No семантика по всем опциям вопроса ---


class TestMultiSemantics:
    async def test_multi_writes_yes_for_selected_no_for_unselected(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        # multi-вопрос с 3 опциями, каждая ссылается на свой parameter_code.
        question_code = unique_id("q-multi")
        param_a = unique_id("pa")
        param_b = unique_id("pb")
        param_c = unique_id("pc")
        await factory.parameter(code=param_a)
        await factory.parameter(code=param_b)
        await factory.parameter(code=param_c)
        # Для FK questions нужен заглушечный parameter_code (он не используется логикой save).
        dummy = unique_id("pq")
        await factory.parameter(code=dummy)
        await factory.question(code=question_code, type="multi", group_code=1, is_skippable=True)
        await factory.option(code="oa", question_code=question_code, parameter_code=param_a, value="A")
        await factory.option(code="ob", question_code=question_code, parameter_code=param_b, value="B")
        await factory.option(code="oc", question_code=question_code, parameter_code=param_c, value="C")
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code=question_code,
            system_code=None,
            body=AnswerRequest(option_codes=["oa", "oc"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        assert by_param == {param_a: "Да", param_b: "Нет", param_c: "Да"}

    async def test_multi_writes_options_in_ascending_parameter_code_order(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        """Параметры опций пишутся по возрастанию `parameter_code`, а не в порядке справочника.

        Порядок захвата строк `patients_parameters` — общий со сбросом параметров risk-event
        (правило — `src/infra/patients_parameters.py`): разойдись они, ответ на вопрос и сброс по
        пересекающемуся набору параметров могли бы заблокироваться взаимно. В справочнике коды идут
        по убыванию (порядок опций — по `option_id`, то есть по порядку вставки), поэтому порядок
        записи виден по `patient_parameter_id`. Значения проверяются вместе с ним: сортировка меняет
        порядок захвата строк, а не то, что попадает в каждую.
        """
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-multi")
        prefix = unique_id("pc")
        lower_param = f"{prefix}_a"
        higher_param = f"{prefix}_b"
        await factory.parameter(code=lower_param)
        await factory.parameter(code=higher_param)
        await factory.question(code=question_code, type="multi", group_code=1, is_skippable=True)
        higher_option = await factory.option(
            code=unique_id("o-high"), question_code=question_code, parameter_code=higher_param, value="B"
        )
        await factory.option(
            code=unique_id("o-low"), question_code=question_code, parameter_code=lower_param, value="A"
        )
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code=question_code,
            system_code=None,
            body=AnswerRequest(option_codes=[higher_option]),
        )

        rows = (
            await db_session.execute(
                text(
                    "SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"
                    " ORDER BY patient_parameter_id"
                ),
                {"pid": pid},
            )
        ).all()
        assert [(row.parameter_code, row.value) for row in rows] == [(lower_param, "Нет"), (higher_param, "Да")]

    async def test_multi_options_sharing_a_parameter_keep_catalog_order(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        """Две опции с ОДНИМ `parameter_code`: побеждает последняя по справочнику, а не по сортировке.

        Сортировка по `parameter_code` устойчива, поэтому опции с равным ключом сохраняют порядок
        справочника (`option_id`) и в строку параметра пишет последняя из них. Здесь выбрана ПЕРВАЯ
        опция, так что различить порядок можно по значению: порядок справочника даёт 'Нет' (записала
        невыбранная вторая), обратный дал бы 'Да'.
        """
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-multi")
        shared_param = unique_id("pc")
        await factory.parameter(code=shared_param)
        await factory.question(code=question_code, type="multi", group_code=1, is_skippable=True)
        first_option = await factory.option(
            code=unique_id("o-first"), question_code=question_code, parameter_code=shared_param, value="A"
        )
        await factory.option(
            code=unique_id("o-second"), question_code=question_code, parameter_code=shared_param, value="B"
        )
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code=question_code,
            system_code=None,
            body=AnswerRequest(option_codes=[first_option]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        assert [(row.parameter_code, row.value) for row in rows] == [(shared_param, "Нет")]


# --- optionCodes: код, не принадлежащий вопросу, → INVALID_OPTION_CODE, ничего не сохраняем ---


class TestInvalidOptionCode:
    async def test_multi_unknown_code_raises_and_saves_nothing(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-multi")
        param_a = unique_id("pa")
        dummy = unique_id("pq")
        await factory.parameter(code=param_a)
        await factory.parameter(code=dummy)
        await factory.question(code=question_code, type="multi", group_code=1, is_skippable=True)
        await factory.option(code="oa", question_code=question_code, parameter_code=param_a, value="A")
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(InvalidOptionCodeError):
            await service.handle(
                client_id=pid,
                question_code=question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["oa", "bogus"]),
            )

        count = await db_session.scalar(
            text("SELECT count(*) FROM patients_parameters WHERE patient_id = :pid"), {"pid": pid}
        )
        assert count == 0

    async def test_multi_without_options_raises_and_saves_nothing(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Расхождение каталога: у multi-вопроса нет опций. По шагу 3 каждый код обязан принадлежать
        # вопросу — принадлежать нечему, поэтому 400 INVALID_OPTION_CODE. Ничего не сохраняем.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-multi")
        dummy = unique_id("pq")
        await factory.parameter(code=dummy)
        await factory.question(code=question_code, type="multi", group_code=1, is_skippable=True)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(InvalidOptionCodeError):
            await service.handle(
                client_id=pid,
                question_code=question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["bogus"]),
            )

        count = await db_session.scalar(
            text("SELECT count(*) FROM patients_parameters WHERE patient_id = :pid"), {"pid": pid}
        )
        assert count == 0

    @pytest.mark.parametrize("question_type", ["select", "boolean"])
    async def test_select_boolean_unknown_code_raises_and_saves_nothing(
        self,
        db_session: AsyncSession,
        factory: Factory,
        question_type: str,
        rc_service: RcServiceFactory,
    ) -> None:
        # Bug #123: для select/boolean неизвестный код раньше молча отбрасывался (валидный сохранялся,
        # 200). Теперь — как у multi: любой чужой код → INVALID_OPTION_CODE, транзакция откатывается,
        # валидный ответ тоже не сохраняется.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-opt")
        param = unique_id("po")
        await factory.parameter(code=param)
        await factory.question(code=question_code, type=question_type, group_code=1, is_skippable=True)
        await factory.option(code="o1", question_code=question_code, parameter_code=param, value="V")
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(InvalidOptionCodeError):
            await service.handle(
                client_id=pid,
                question_code=question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["o1", "bogus"]),
            )

        count = await db_session.scalar(
            text("SELECT count(*) FROM patients_parameters WHERE patient_id = :pid"), {"pid": pid}
        )
        assert count == 0

    async def test_select_without_options_raises_and_saves_nothing(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Расхождение каталога: у select-вопроса нет опций. Как и у multi — 400 INVALID_OPTION_CODE:
        # принадлежать переданному коду нечему. Ничего не сохраняем.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-select")
        dummy = unique_id("pq")
        await factory.parameter(code=dummy)
        await factory.question(code=question_code, type="select", group_code=1, is_skippable=True)
        await db_session.commit()

        service = await rc_service()
        with pytest.raises(InvalidOptionCodeError):
            await service.handle(
                client_id=pid,
                question_code=question_code,
                system_code=None,
                body=AnswerRequest(option_codes=["bogus"]),
            )

        count = await db_session.scalar(
            text("SELECT count(*) FROM patients_parameters WHERE patient_id = :pid"), {"pid": pid}
        )
        assert count == 0


# --- answer: parameter_code берётся из options, не из questions ---


class TestParameterCodeFromOptions:
    async def test_answer_picks_first_option_by_id_when_multiple_options(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # Защитный кейс: спека («находим запись в options») предполагает одну option-строку,
        # но при разрастании каталога может оказаться несколько. Берём первую по option_id.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-num")
        dummy = unique_id("pq")
        first_param = unique_id("pfirst")
        second_param = unique_id("psecond")
        await factory.parameter(code=dummy)
        await factory.parameter(code=first_param)
        await factory.parameter(code=second_param)
        await factory.question(code=question_code, type="numeric", group_code=1, is_skippable=True)
        # Порядок вставки совпадает с возрастанием option_id (auto-increment) — первая
        # запись должна выиграть.
        await factory.option(
            code=unique_id("o-first"), question_code=question_code, parameter_code=first_param, value=None
        )
        await factory.option(
            code=unique_id("o-second"), question_code=question_code, parameter_code=second_param, value=None
        )
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code=question_code,
            system_code=None,
            body=AnswerRequest(answer="42"),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        # Записан только parameter_code первой опции, второй параметр не тронут.
        assert [r.parameter_code for r in rows] == [first_param]

    async def test_answer_uses_options_parameter_code(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)

        question_code = unique_id("q-num")
        # parameter_code в questions заведомо отличается от parameter_code в options.
        question_param = unique_id("pq")
        option_param = unique_id("po")
        await factory.parameter(code=question_param)
        await factory.parameter(code=option_param)
        await factory.question(code=question_code, type="numeric", group_code=1, is_skippable=True)
        await factory.option(code="o1", question_code=question_code, parameter_code=option_param, value=None)
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code=question_code,
            system_code=None,
            body=AnswerRequest(answer="42"),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        assert [r.parameter_code for r in rows] == [option_param]


# --- sq_0360: side-effect upsert «противоположного» параметра менопаузы ---


class TestMenopauseSideEffect:
    async def test_sq_0360_04_writes_regular_menses_none(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # sq_0360, его опции (sq_0360_01..04) и параметры regular_menses* заведены сидом каталога.
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code="sq_0360",
            system_code=None,
            body=AnswerRequest(option_codes=["sq_0360_04"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        # Основной ответ из option.value + side-effect 'none' на противоположный параметр.
        assert by_param == {"regular_menses_menopause": "Наступила менопауза", "regular_menses": "none"}

    async def test_sq_0360_01_writes_regular_menses_menopause_none(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        # sq_0360, его опции и параметры regular_menses* заведены сидом каталога.
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code="sq_0360",
            system_code=None,
            body=AnswerRequest(option_codes=["sq_0360_01"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        assert by_param == {"regular_menses": "Да", "regular_menses_menopause": "none", "menopause_onset": "none"}

    async def test_answer_rejected_when_side_effect_validity_missing_in_catalog(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        """Side-effect неотделим от ответа: откат транзакции убирает и основной ответ (bug #195).

        Срок жизни убираем только у параметра side-effect'а: основной ответ (regular_menses_menopause)
        записывается штатно, и запрос падает уже после него. Подмена на шве чтения справочника —
        `parameters.validity_period` NOT NULL, в БД такого состояния не создать.
        """
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        catalog = await make_http_catalog(db_session)
        catalog.parameters = MappingProxyType(
            {code: parameter for code, parameter in catalog.parameters.items() if code != REGULAR_MENSES_PARAM_CODE}
        )
        with pytest.raises(CatalogConsistencyError) as exc_info:
            await RiskCommunicationService(db_session, catalog).handle(
                client_id=pid,
                question_code=MENOPAUSE_QUESTION_CODE,
                system_code=None,
                body=AnswerRequest(option_codes=[MENOPAUSE_TRUE_OPTION_CODE]),
            )
        # Запрос упал именно на side-effect'е, а не на записи основного ответа.
        assert exc_info.value.parameter_code == REGULAR_MENSES_PARAM_CODE

        count = (
            await db_session.execute(
                text("SELECT COUNT(*) FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).scalar_one()
        assert count == 0


# --- cq_060: side-effect hodgkins_lymphoma='none' и breast_cancer='none' при отсутствии
#     онкологии (issue #122, #124) ---


class TestChronicDiseasesHodgkinsSideEffect:
    async def test_cq_060_without_cancer_writes_hodgkins_and_breast_none(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # cq_060 (multi) и его опции cq_060_01..08, а также параметры hodgkins_lymphoma / breast_cancer
        # заведены сидом каталога. Ответ без cq_060_05 («Злокачественные новообразования») → выводим,
        # что онкологии нет, и пишем hodgkins_lymphoma='none' И breast_cancer='none' (#124).
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code="cq_060",
            system_code=None,
            body=AnswerRequest(option_codes=["cq_060_01"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        # Основной multi-ответ пометил cancer='Нет' (опция не выбрана), а side-effect — оба онко-параметра.
        assert by_param.get("cancer") == "Нет"
        assert by_param.get("hodgkins_lymphoma") == "none"
        assert by_param.get("breast_cancer") == "none"

    async def test_cq_060_no_diseases_writes_hodgkins_and_breast_none(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # cq_060_08 «Ничего из перечисленного» — cq_060_05 не выбран, значит онкологии нет →
        # side-effect так же пишет hodgkins_lymphoma='none' и breast_cancer='none'.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code="cq_060",
            system_code=None,
            body=AnswerRequest(option_codes=["cq_060_08"]),
        )

        rows = (
            await db_session.execute(
                text(
                    "SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid "
                    "AND parameter_code IN ('hodgkins_lymphoma', 'breast_cancer')"
                ),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        assert by_param.get("hodgkins_lymphoma") == "none"
        assert by_param.get("breast_cancer") == "none"

    async def test_cq_060_with_cancer_does_not_write_onco_params(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        # cq_060_05 выбран → онкология возможна, детали спросят sq_0020/sq_0010. Side-effect
        # не должен трогать hodgkins_lymphoma / breast_cancer.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        await service.handle(
            client_id=pid,
            question_code="cq_060",
            system_code=None,
            body=AnswerRequest(option_codes=["cq_060_05"]),
        )

        rows = (
            await db_session.execute(
                text("SELECT parameter_code, value FROM patients_parameters WHERE patient_id = :pid"),
                {"pid": pid},
            )
        ).all()
        by_param = {r.parameter_code: r.value for r in rows}
        assert by_param.get("cancer") == "Да"
        assert "hodgkins_lymphoma" not in by_param
        assert "breast_cancer" not in by_param


class TestSkipCommonForMental:
    """Skip COMMON when systemCode=MENTAL.

    MENTAL and COMMON both come from the real seeded catalog: the integration DB migrates to head,
    which seeds the full reference catalog (COMMON questions like cq_010, and the MENTAL system with
    its bdi/stai questions). A fresh patient has every catalog question unanswered, so the COMMON
    overlap (cq_010) would win for ANY request unless the skip explicitly bypasses it. The tests
    therefore need no synthetic COMMON/MENTAL seeding — they exercise the real catalog directly.
    """

    @pytest.mark.parametrize("v2_flag", [False, True])
    async def test_mental_system_code_skips_common(
        self,
        db_session: AsyncSession,
        factory: Factory,
        v2_flag: bool,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code="MENTAL",
            body=AnswerRequest(),
            complete_on_requested_system_done=v2_flag,
        )

        # COMMON is skipped → first question is a real MENTAL question (bdi/stai), not a COMMON cq_0xx.
        assert response.system_code == "MENTAL"
        assert response.question is not None
        assert not response.question.question_code.startswith("cq_")

    async def test_no_system_code_still_returns_common_first(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code=None,
            body=AnswerRequest(),
        )

        # COMMON must NOT be skipped when no systemCode is given.
        assert response.system_code == "COMMON"
        assert response.question is not None

    async def test_other_system_code_still_returns_common_first(
        self,
        db_session: AsyncSession,
        factory: Factory,
        rc_service: RcServiceFactory,
    ) -> None:
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await db_session.commit()

        # A non-MENTAL requested system must NOT skip COMMON: the COMMON overlap still wins. CVD is a
        # real seeded system (step 2 rejects unknown systemCode before selection runs), so this
        # exercises the non-skip path with a valid code.
        service = await rc_service()
        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code="CVD",
            body=AnswerRequest(),
        )

        assert response.system_code == "COMMON"
        assert response.question is not None

    async def test_mental_completion_v2(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        # Exhaust MENTAL's own params (real catalog bdi/stai) while leaving COMMON UNANSWERED: only
        # the skip prevents COMMON from being returned here, so this pins the skip's effect on
        # completion. With COMMON skipped for MENTAL, the v2 flag must report completion of MENTAL
        # itself (question=null, systemCompletionPercentage=100), not bounce to a COMMON question.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_system_params(patient_id=pid, system_code="MENTAL")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code="MENTAL",
            body=AnswerRequest(),
            complete_on_requested_system_done=True,
        )

        assert response.question is None
        assert response.system_completion_percentage == 100

    async def test_mental_completion_v1_falls_back_to_common(
        self, db_session: AsyncSession, factory: Factory, rc_service: RcServiceFactory
    ) -> None:
        # Зеркало test_mental_completion_v2 для v1 (DoD #167): MENTAL исчерпан, COMMON UNANSWERED.
        # Без флага complete_on_requested_system_done handle() делает фолбэк с requested_system_code=None,
        # где skip_common уже НЕ срабатывает → COMMON-перекрытие снова выигрывает и клиент получает
        # COMMON-вопрос вместо фальшивого «всё готово». Закрепляет намеренное расхождение v1/v2.
        pid = unique_id("p")
        await factory.patient(patient_id=pid)
        await factory.answer_system_params(patient_id=pid, system_code="MENTAL")
        await db_session.commit()

        service = await rc_service()

        response, _ = await service.handle(
            client_id=pid,
            question_code=None,
            system_code="MENTAL",
            body=AnswerRequest(),
            complete_on_requested_system_done=False,
        )

        assert response.system_code == "COMMON"
        assert response.question is not None
