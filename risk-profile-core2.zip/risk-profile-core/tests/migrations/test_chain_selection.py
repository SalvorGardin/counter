"""Проверки механизма выбора цепочки миграций (старая / схлопнутая).

Механика намеренно завязана на секцию alembic.ini, а не на `-x chain=`: alembic
строит ScriptDirectory.from_config(config) ДО запуска env.py (см. alembic/command.py),
поэтому set_main_option("version_locations") внутри env.py на поиск ревизий не влияет.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from alembic.config import Config
from alembic.script import ScriptDirectory

from tests.migrations.conftest import squash_config

REPO_ROOT = Path(__file__).resolve().parents[2]


def test_everything_is_derived_from_the_cut_revision() -> None:
    # CUT_REVISION — единственная ручка: префикс, имена файлов baseline и граница хвоста
    # выводятся из неё. Разъехавшийся литерал молча схлопнул бы не то состояние.
    prefix, revision = squash_config.CUT_PREFIX, squash_config.CUT_REVISION
    cut = squash_config.cut_revision_file().name
    assert cut.startswith(f"{prefix}_") and cut.endswith(f"_{revision}.py")
    assert squash_config.BASELINE_FILENAME == f"{prefix}_squashed_baseline_{revision}.py"
    assert squash_config.BASELINE_DATA_FILENAME == f"{prefix}_{revision}_baseline.json"
    assert all(p.name[:4] > prefix for p in squash_config.tail_revision_files())


@pytest.mark.parametrize("chain", sorted(squash_config.CHAIN_DIRS))
def test_ini_section_of_each_chain_resolves_to_its_single_directory(chain: str) -> None:
    # Связка CHAIN_DIRS ↔ CHAIN_INI_SECTIONS: без неё словарь и alembic.ini расходятся
    # молча. Ровно одна директория — инвариант: две сразу дали бы два head.
    # Цепочка "new" (схлопнутая) сидит в дефолтной секции [alembic], то есть голый
    # `alembic upgrade head` едет по ней.
    cfg = Config(str(REPO_ROOT / "alembic.ini"), ini_section=squash_config.chain_ini_section(chain))
    locations = [Path(p).resolve() for p in ScriptDirectory.from_config(cfg)._version_locations]
    assert locations == [squash_config.chain_version_location(chain).resolve()]


def test_unknown_chain_is_rejected() -> None:
    with pytest.raises(ValueError, match="unknown chain"):
        squash_config.chain_version_location("squashed")
    with pytest.raises(ValueError, match="unknown chain"):
        squash_config.chain_ini_section("squashed")
