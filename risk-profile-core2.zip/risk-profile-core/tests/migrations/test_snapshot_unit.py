"""Юниты для нормализации дампа и для diff-а. Контейнер не нужен."""

from __future__ import annotations

from tests.migrations import exclusions
from tests.migrations.conftest import squash_config
from tests.migrations.snapshot import compare, normalize_schema

_RAW = """--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
SET statement_timeout = 0;
SELECT pg_catalog.set_config('search_path', '', false);

CREATE TABLE public.systems (
    id integer NOT NULL,
    code character varying NOT NULL
);

COMMENT ON TABLE public.systems IS 'справочник систем';
"""


def test_normalize_strips_header_and_set_preamble() -> None:
    out = normalize_schema(_RAW)
    assert "Dumped from database version" not in out
    assert "statement_timeout" not in out
    assert "set_config" not in out


def test_normalize_keeps_ddl_and_comments() -> None:
    # COMMENT ON обязан выживать: если нормализация его срежет, baseline потеряет
    # комментарии, тест останется зелёным, а прод уедет без них.
    out = normalize_schema(_RAW)
    assert "CREATE TABLE public.systems" in out
    assert "COMMENT ON TABLE public.systems IS 'справочник систем';" in out


def test_normalize_strips_psql_restrict_nonce() -> None:
    # pg_dump 17+ оборачивает дамп в \restrict/\unrestrict со случайным токеном:
    # он разный при каждом запуске и без нормализации дал бы вечный ложный diff.
    raw = "\\restrict 3nmiQxd8MBwVbC0oc7ZS4rGU\nCREATE TABLE public.x ();\n\\unrestrict 3nmiQxd8MBwVbC0oc7ZS4rGU\n"
    out = normalize_schema(raw)
    assert "restrict" not in out
    assert "CREATE TABLE public.x ();" in out


def test_normalize_is_idempotent() -> None:
    assert normalize_schema(normalize_schema(_RAW)) == normalize_schema(_RAW)


def test_compare_returns_none_for_identical_input() -> None:
    assert compare("a\nb\n", "a\nb\n", "old", "new") is None


def test_compare_returns_unified_diff_with_labels() -> None:
    diff = compare("a\nb\n", "a\nc\n", "chain_old", "chain_new")
    assert diff is not None
    assert "chain_old" in diff and "chain_new" in diff
    assert "-b" in diff and "+c" in diff


def test_serial_single_column_pk_is_treated_as_surrogate() -> None:
    # PK здесь называются parameter_id / doctor_id, а не id: список имён не сработал бы.
    assert squash_config.is_surrogate_pk(
        name="parameter_id",
        pk_names=frozenset({"parameter_id"}),
        server_default="nextval('parameters_parameter_id_seq'::regclass)",
        identity=False,
    )
    assert squash_config.is_surrogate_pk(
        name="doctor_id", pk_names=frozenset({"doctor_id"}), server_default=None, identity=True
    )


def test_business_keys_are_not_treated_as_surrogate() -> None:
    # patients.patient_id — строковый бизнес-ключ, по нему идут FK: он обязан сравниваться.
    assert not squash_config.is_surrogate_pk(
        name="patient_id", pk_names=frozenset({"patient_id"}), server_default=None, identity=False
    )
    # Составной PK бизнес-осмысленен целиком.
    assert not squash_config.is_surrogate_pk(
        name="code",
        pk_names=frozenset({"code", "system_code"}),
        server_default="nextval('x_seq'::regclass)",
        identity=False,
    )
    # Не-PK колонка с дефолтом от последовательности суррогатным ключом не является.
    assert not squash_config.is_surrogate_pk(
        name="counter",
        pk_names=frozenset({"code"}),
        server_default="nextval('x_seq'::regclass)",
        identity=False,
    )


def test_volatile_timestamps_are_ignored_only_where_declared() -> None:
    assert "date_time" in exclusions.ignored_columns_for("patients_parameters")
    # У справочника parameters validity_period — фиксированное значение из сида, не now().
    assert "validity_period" not in exclusions.ignored_columns_for("parameters")


def test_every_exclusion_carries_a_reason() -> None:
    # Рост списка без обоснования — сигнал, что утверждение об эквивалентности размывается.
    assert set(exclusions.IGNORED_COLUMNS) == set(exclusions.EXCLUSION_REASONS)
