"""Стенд для доказательства эквивалентности старой и схлопнутой цепочек миграций.

Один PostgresContainer на сессию, внутри две БД: chain_old и chain_new. Один сервер —
значит одинаковые версия, локаль и collation по построению, и целый класс ложных
расхождений снимается без единой строчки нормализации.
"""

from __future__ import annotations

import importlib.util
import sys
from collections.abc import Callable, Generator
from pathlib import Path
from types import ModuleType

import pytest
from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url
from testcontainers.postgres import PostgresContainer

REPO_ROOT = Path(__file__).resolve().parents[2]

OLD_DB = "chain_old"
NEW_DB = "chain_new"

# Раннер трогает только БД с этим префиксом — см. _assert_safe_target.
_TEST_DB_PREFIX = "chain_"


def load_script_module(name: str) -> ModuleType:
    """Модуль из scripts/ по имени: scripts/ не пакет, как в tests/scripts/test_check_logger_info.py.

    Регистрация в sys.modules обязательна: squash_config — единственный источник истины
    про отсечение, и два его экземпляра (один загруженный тестом, другой добытый
    `import squash_config` внутри генератора) свели бы это утверждение на нет.
    """
    if (cached := sys.modules.get(name)) is not None:
        return cached
    spec = importlib.util.spec_from_file_location(name, REPO_ROOT / "scripts" / f"{name}.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        del sys.modules[name]  # иначе следующий вызов вернёт полупустой модуль
        raise
    return module


squash_config = load_script_module("squash_config")


class AlembicRunner:
    """Гоняет одну цепочку миграций по одной БД.

    URL — psycopg2, чтобы migrations/env.py ушёл синхронной веткой: async-ветка внутри
    делает asyncio.run(), а pytest-asyncio уже держит запущенный event loop.
    """

    def __init__(self, db_name: str, chain: str, admin_url: str) -> None:
        # Директория ревизий разрешается здесь, а не при первом обращении: опечатка в
        # имени цепочки падает ValueError-ом на конструировании раннера, до всякого коннекта.
        self.version_location: Path = squash_config.chain_version_location(chain)
        self.db_name = db_name
        self.chain = chain
        self.admin_url = admin_url

    @property
    def url(self) -> str:
        return (
            make_url(self.admin_url)
            .set(drivername="postgresql+psycopg2", database=self.db_name)
            .render_as_string(hide_password=False)
        )

    def _assert_safe_target(self) -> None:
        url = make_url(self.url)
        if not self.db_name.startswith(_TEST_DB_PREFIX):
            raise RuntimeError(f"refusing to migrate {self.db_name!r}: not a {_TEST_DB_PREFIX}* test database")
        if url.port in (None, 5432):
            raise RuntimeError(f"refusing to migrate port {url.port!r}: expected a container-mapped port")

    def _config(self) -> Config:
        cfg = Config(str(REPO_ROOT / "alembic.ini"))
        cfg.set_main_option("sqlalchemy.url", self.url)
        cfg.set_main_option("version_locations", str(self.version_location))
        return cfg

    def upgrade(self, rev: str = "head") -> None:
        self._run(command.upgrade, "upgrade", rev)

    def downgrade(self, rev: str) -> None:
        self._run(command.downgrade, "downgrade", rev)

    def _run(self, action: Callable[[Config, str], None], name: str, rev: str) -> None:
        self._assert_safe_target()
        try:
            action(self._config(), rev)
        except Exception as exc:  # noqa: BLE001 — пересобираем сообщение и сразу пробрасываем
            raise RuntimeError(f"[{self.chain}] {name} to {rev} failed at {self._current_for_message()}") from exc

    def _current_for_message(self) -> str:
        """Позиция для сообщения об ошибке. Свой сбой не имеет права похоронить исходный.

        current() открывает собственный engine: отказ на уровне соединения прямо в
        except-блоке подменил бы настоящую причину падения миграции своим исключением.
        """
        try:
            return str(self.current())
        except Exception as exc:  # noqa: BLE001 — диагностика, а не путь исполнения
            return f"<unknown revision: {exc!r}>"

    def current(self) -> str | None:
        engine = create_engine(self.url)
        try:
            with engine.connect() as conn:
                exists = conn.execute(text("SELECT to_regclass('public.alembic_version')")).scalar()
                if exists is None:
                    return None
                return conn.execute(text("SELECT version_num FROM alembic_version")).scalar()
        finally:
            engine.dispose()

    def revisions_between(self, upper: str, lower: str) -> list[str]:
        """Ревизии от upper (включительно) вниз до lower (исключительно), сверху вниз."""
        script = ScriptDirectory.from_config(self._config())
        return [rev.revision for rev in script.iterate_revisions(upper, lower) if rev.revision != lower]


def recreate_chain_databases(admin_url: str) -> None:
    """Пересоздаёт обе БД с нуля."""
    engine = create_engine(admin_url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as conn:
            for db in (OLD_DB, NEW_DB):
                conn.execute(text(f'DROP DATABASE IF EXISTS "{db}"'))
                conn.execute(text(f'CREATE DATABASE "{db}"'))
    finally:
        engine.dispose()


@pytest.fixture(scope="session")
def migration_container() -> Generator[PostgresContainer, None, None]:
    # Тот же образ, что в tests/conftest.py:53 — держим версии сервера в одной точке.
    with PostgresContainer("postgres:16-alpine") as container:
        recreate_chain_databases(container.get_connection_url())
        yield container


@pytest.fixture
def clean_chain_databases(migration_container: PostgresContainer) -> None:
    """Каждый тест стартует с чистых БД.

    Контейнер сессионный (образ тянется один раз), а БД — нет: тест, начинающийся с
    upgrade(CUT) на базе, оставленной предыдущим тестом на head, молча не сделал бы ничего
    и сравнил бы два head-а вместо floor-а. Именно так и падал test_floor_equivalence.
    Пересоздание, а не downgrade to base: спуск по старой цепочке опирается на downgrade()
    миграций данных, которые никогда не исполнялись, — это отдельный источник падений.
    """
    recreate_chain_databases(migration_container.get_connection_url())


@pytest.fixture(scope="session")
def chain_runners(migration_container: PostgresContainer) -> tuple[AlembicRunner, AlembicRunner]:
    admin_url = migration_container.get_connection_url()
    return (
        AlembicRunner(db_name=OLD_DB, chain="old", admin_url=admin_url),
        AlembicRunner(db_name=NEW_DB, chain="new", admin_url=admin_url),
    )
