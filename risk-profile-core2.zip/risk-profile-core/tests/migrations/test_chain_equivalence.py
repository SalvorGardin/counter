"""Доказательство: схлопнутая цепочка приводит чистую БД в то же состояние, что старая.

Несущие утверждения — test_head_equivalence и test_floor_equivalence, их гоняет CI.
Пошаговый спуск (test_shared_tail_downgrade) — инструмент бисекции, а не независимая
проверка: выше точки отсечения обе БД выполняют ОДНИ И ТЕ ЖЕ файлы миграций, и одинаковые
миграции на эквивалентных состояниях дают эквивалентный результат, если в них нет
недетерминизма. Ценность спуска — указать, на какой ревизии разошлось, когда упало
сравнение на head. Поэтому он снимает только схему (полные дампы данных на каждом шаге —
главный источник времени прогона при низкой информационной ценности) и вынесен под
отдельный маркер migration_bisect: его запускает человек, когда head или floor упал.
    pytest -m migration_bisect -o addopts=""

Сломанный downgrade() в хвосте обязан валить этот тест громко: ради этого стенд и написан.

Дрейф прода здесь не проверяется и не требуется: стенд доказывает «старая с нуля» =
«новая с нуля», а прод контролируется и гарантированно стоит на последней ревизии.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import sqlalchemy as sa
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from testcontainers.postgres import PostgresContainer

import src.models  # noqa: F401 — регистрирует все ORM-модели в Base.metadata
from src.infra.database import Base
from src.infra.db_schemas import is_compared_schema
from tests.migrations.conftest import NEW_DB, OLD_DB, AlembicRunner, squash_config
from tests.migrations.snapshot import compare, dump_data, dump_schema

pytestmark = pytest.mark.migration_equivalence

CUT = squash_config.CUT_REVISION

_ARTIFACTS = Path(__file__).resolve().parents[2] / "artifacts" / "migration-equivalence"


def _save(name: str, content: str) -> Path:
    _ARTIFACTS.mkdir(parents=True, exist_ok=True)
    path = _ARTIFACTS / name
    path.write_text(content, encoding="utf-8")
    return path


def _assert_same(
    old: AlembicRunner,
    new: AlembicRunner,
    container: PostgresContainer,
    *,
    stage: str,
    with_data: bool,
) -> None:
    old_schema = dump_schema(container, OLD_DB)
    new_schema = dump_schema(container, NEW_DB)
    diff = compare(old_schema, new_schema, f"{OLD_DB}@{old.current()}", f"{NEW_DB}@{new.current()}")
    if diff is not None:
        left = _save(f"{stage}.schema.old.sql", old_schema)
        right = _save(f"{stage}.schema.new.sql", new_schema)
        pytest.fail(f"schema diverged at {stage}\nold={left}\nnew={right}\n\n{diff}")

    if not with_data:
        return

    old_data = dump_data(old.url)
    new_data = dump_data(new.url)
    diff = compare(old_data, new_data, f"{OLD_DB}@{old.current()}", f"{NEW_DB}@{new.current()}")
    if diff is not None:
        left = _save(f"{stage}.data.old.txt", old_data)
        right = _save(f"{stage}.data.new.txt", new_data)
        pytest.fail(f"data diverged at {stage}\nold={left}\nnew={right}\n\n{diff}")


def test_tail_files_identical() -> None:
    """Хвост в новой цепочке — побайтовая копия старого.

    Файлы хвоста физически продублированы, пока старая цепочка не удалена. Правка в
    одной копии и не в другой развалила бы всё утверждение об эквивалентности молча.
    """
    new_dir = squash_config.chain_version_location("new")
    for source in squash_config.tail_revision_files():
        copy = new_dir / source.name
        assert copy.exists(), f"{source.name} отсутствует в схлопнутой цепочке"
        assert copy.read_bytes() == source.read_bytes(), f"{source.name} разошёлся с оригиналом"


def test_head_equivalence(clean_chain_databases, chain_runners, migration_container: PostgresContainer) -> None:
    old, new = chain_runners
    old.upgrade("head")
    new.upgrade("head")
    # Head не хардкодится: важно, что обе цепочки встали на ОДНУ ревизию, а какая именно —
    # это подвижный номер, ломающий тест на любой новой миграции.
    assert old.current() == new.current()
    _assert_same(old, new, migration_container, stage="head", with_data=True)


@pytest.mark.migration_bisect
def test_shared_tail_downgrade(clean_chain_databases, chain_runners, migration_container: PostgresContainer) -> None:
    old, new = chain_runners
    old.upgrade("head")
    new.upgrade("head")
    expected = len(squash_config.tail_revision_files())
    revisions = old.revisions_between("head", CUT)
    assert len(revisions) == expected, f"ожидали {expected} ревизий хвоста, получили {revisions}"
    for revision in revisions:
        old.downgrade("-1")
        new.downgrade("-1")
        assert old.current() == new.current(), f"цепочки разъехались по позиции после отката {revision}"
        _assert_same(old, new, migration_container, stage=f"down-from-{revision}", with_data=False)


def test_floor_equivalence(clean_chain_databases, chain_runners, migration_container: PostgresContainer) -> None:
    old, new = chain_runners
    old.upgrade(CUT)
    new.upgrade(CUT)
    assert old.current() == new.current() == CUT
    _assert_same(old, new, migration_container, stage="floor", with_data=True)


def test_new_baseline_downgrades_clean(clean_chain_databases, chain_runners) -> None:
    """downgrade() самого baseline сносит схему до конца.

    Поднимаемся ровно до CUT, а не до head: спуск через хвост проверяет чужие downgrade()
    и падал бы в чужом баге, ничего не сказав про baseline — а проверяется здесь именно он.
    Спуск по хвосту — дело test_shared_tail_downgrade.
    """
    _, new = chain_runners
    new.upgrade(CUT)
    new.downgrade("base")
    engine = sa.create_engine(new.url)
    try:
        with engine.connect() as conn:
            leftovers = (
                conn.execute(
                    sa.text(
                        "SELECT tablename FROM pg_tables "
                        "WHERE schemaname = 'public' AND tablename <> 'alembic_version' "
                        "ORDER BY tablename"
                    )
                )
                .scalars()
                .all()
            )
    finally:
        engine.dispose()
    assert leftovers == [], f"downgrade to base оставил таблицы: {leftovers}"


def _include_name(name: str | None, type_: str, parent_names: dict[str, str | None]) -> bool:
    return is_compared_schema(name) if type_ == "schema" else True


def test_new_chain_matches_orm(clean_chain_databases, chain_runners) -> None:
    _, new = chain_runners
    new.upgrade("head")
    engine = sa.create_engine(new.url)
    try:
        with engine.connect() as conn:
            # include_schemas/include_name — те же, что в migrations/env.py: без них сравнение
            # видит только public и объявило бы все 35 таблиц отсутствующими.
            ctx = MigrationContext.configure(
                connection=conn,
                opts={"compare_type": True, "include_schemas": True, "include_name": _include_name},
            )
            diffs = compare_metadata(ctx, Base.metadata)
    finally:
        engine.dispose()
    assert diffs == [], f"схлопнутая цепочка разошлась с src.models: {diffs}"
