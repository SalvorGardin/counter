"""Раннер обязан отказываться работать с чем угодно, кроме тестового контейнера.

migrations/env.py:_get_db_url() откатывается на settings.migrations_db_url, если sqlalchemy.url
пуст. Тест, забывший выставить URL, накатил бы миграции на dev-базу разработчика —
поэтому проверка стоит до command.upgrade, а не после.
"""

from __future__ import annotations

import pytest

from tests.migrations.conftest import AlembicRunner

_ADMIN = "postgresql+psycopg2://test:test@localhost:49153/test"


def test_runner_builds_url_from_admin_url_and_db_name() -> None:
    runner = AlembicRunner(db_name="chain_old", chain="old", admin_url=_ADMIN)
    assert runner.url.endswith("/chain_old")
    assert "localhost:49153" in runner.url


def test_runner_rejects_db_name_outside_the_test_namespace() -> None:
    with pytest.raises(RuntimeError, match="refusing"):
        AlembicRunner(db_name="risk_model", chain="old", admin_url=_ADMIN).upgrade("head")


def test_runner_rejects_default_postgres_port() -> None:
    # 5432 — почти наверняка локальный постгрес разработчика, а не проброшенный порт контейнера.
    admin = "postgresql+psycopg2://test:test@localhost:5432/test"
    with pytest.raises(RuntimeError, match="refusing"):
        AlembicRunner(db_name="chain_old", chain="old", admin_url=admin).upgrade("head")


def test_runner_rejects_unknown_chain() -> None:
    # Опечатка в имени цепочки падает на конструировании раннера, а не при первом обращении
    # к директории ревизий: до этого момента тест успел бы дойти до реальной БД.
    with pytest.raises(ValueError, match="unknown chain"):
        AlembicRunner(db_name="chain_old", chain="squashed", admin_url=_ADMIN)
