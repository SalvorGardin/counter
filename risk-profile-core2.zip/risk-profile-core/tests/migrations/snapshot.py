"""Снимок состояния БД и его сравнение.

Схема снимается pg_dump-ом ВНУТРИ контейнера: не нужен pg_dump на хосте и исключено
расхождение версий клиента и сервера. Нормализация минимальная — шапка дампа и
SET-преамбула. Ничего семантического: если нормализация начнёт срезать смысл (COMMENT-ы,
дефолты), генератор потеряет то же самое, тест останется зелёным, а прод уедет битым.

Генератор baseline (scripts/make_squashed_baseline.py) этот модуль НЕ импортирует и
pg_dump не запускает вообще — он рендерит DDL через alembic-автогенерацию. Две
независимые дороги к одному факту, иначе ошибки взаимно погасились бы.
"""

from __future__ import annotations

import difflib
import json

from sqlalchemy import create_engine, inspect, text
from testcontainers.postgres import PostgresContainer

from src.infra.db_schemas import APPLICATION_SCHEMAS
from tests.migrations.conftest import squash_config
from tests.migrations.exclusions import ignored_columns_for

# Схемы, попадающие в снимок. `public` остаётся: там alembic_version и туда же downgrade
# возвращает физические таблицы. Без остальных снимок после 0141 сравнивал бы пустоту.
_SNAPSHOT_SCHEMAS: tuple[str, ...] = ("public", *APPLICATION_SCHEMAS)

# Предикат суррогатного ключа — общий с генератором baseline (scripts/squash_config.py):
# две копии молча разъехались бы в сторону «сгенерировано, но не сравнивается».
is_surrogate_pk = squash_config.is_surrogate_pk

# \restrict / \unrestrict — psql-мета-команды, которые pg_dump 17+ пишет вокруг дампа с
# одноразовым случайным токеном: он разный при каждом запуске и смысла не несёт.
_HEADER_PREFIXES = ("--", "SET ", "SELECT pg_catalog.set_config", "\\restrict ", "\\unrestrict ")


def normalize_schema(raw: str) -> str:
    """Срезает шапку дампа, SET-преамбулу и nonce-строки psql. Больше ничего."""
    kept = [line for line in raw.splitlines() if not line.startswith(_HEADER_PREFIXES)]
    out: list[str] = []
    for line in kept:
        if not line.strip() and (not out or not out[-1].strip()):
            continue
        out.append(line.rstrip())
    return "\n".join(out).strip() + "\n"


def dump_schema(container: PostgresContainer, db_name: str) -> str:
    exit_code, output = container.exec(
        [
            "pg_dump",
            "--schema-only",
            "--no-owner",
            "--no-acl",
            *[argument for schema in _SNAPSHOT_SCHEMAS for argument in ("-n", schema)],
            "-U",
            container.username,
            "-d",
            db_name,
        ]
    )
    if exit_code != 0:
        raise RuntimeError(f"pg_dump for {db_name} exited {exit_code}: {output.decode('utf-8', 'replace')}")
    return normalize_schema(output.decode("utf-8"))


def dump_data(url: str) -> str:
    """Данные всех таблиц: колонки без id и без волатильных, ORDER BY по всем сравниваемым.

    Сортировка именно по сравниваемым колонкам, а не по pk: id расходятся по построению,
    поэтому ORDER BY id дал бы разный порядок строк на эквивалентных данных. Полный набор
    колонок в ORDER BY детерминирован всегда — а если строки полностью совпадают, их
    взаимный порядок и не важен.
    """
    engine = create_engine(url)
    try:
        with engine.connect() as conn:
            inspector = inspect(conn)
            chunks: list[str] = []
            for schema, table in _snapshot_tables(inspector):
                ignored = ignored_columns_for(table)
                pk_names = frozenset(inspector.get_pk_constraint(table, schema=schema)["constrained_columns"])
                compared = [
                    column["name"]
                    for column in inspector.get_columns(table, schema=schema)
                    if column["name"] not in ignored
                    and not is_surrogate_pk(
                        name=column["name"],
                        pk_names=pk_names,
                        server_default=column.get("default"),
                        identity=column.get("identity") is not None,
                    )
                ]
                if not compared:
                    continue
                quoted = ", ".join(f'"{c}"' for c in compared)
                statement = text(f"SELECT {quoted} FROM {schema}.{table} ORDER BY {quoted}")
                rows = conn.execute(statement).mappings().all()
                chunks.append(f"# table {schema}.{table} ({len(rows)} rows)")
                chunks.extend(json.dumps(dict(row), sort_keys=True, ensure_ascii=False, default=str) for row in rows)
            return "\n".join(chunks) + "\n"
    finally:
        engine.dispose()


def _snapshot_tables(inspector: object) -> list[tuple[str, str]]:
    """Все таблицы снимка как пары (схема, таблица). Отсутствующая схема — пустой вклад."""
    found: list[tuple[str, str]] = []
    existing = set(inspector.get_schema_names())  # ty: ignore[unresolved-attribute]
    for schema in _SNAPSHOT_SCHEMAS:
        if schema not in existing:
            continue
        for table in sorted(inspector.get_table_names(schema=schema)):  # ty: ignore[unresolved-attribute]
            found.append((schema, table))
    return found


def compare(left: str, right: str, left_label: str, right_label: str) -> str | None:
    """Unified diff или None. Читаемость важна: этот diff и есть отчёт о падении."""
    diff = list(
        difflib.unified_diff(
            left.splitlines(keepends=True),
            right.splitlines(keepends=True),
            fromfile=left_label,
            tofile=right_label,
            n=3,
        )
    )
    return "".join(diff) if diff else None
