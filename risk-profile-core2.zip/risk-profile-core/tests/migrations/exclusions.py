"""Что НЕ сравнивается при проверке эквивалентности цепочек — и почему.

Каждая запись обязана иметь обоснование в EXCLUSION_REASONS. Рост этого списка сверх
перечисленного — сигнал, что утверждение об эквивалентности размывается, и повод
остановиться, а не дописать ещё одну строку.

Чего здесь СОЗНАТЕЛЬНО нет:
  • alembic_version — baseline переиспользует revision id миграции отсечения (см.
    scripts/squash_config.py:CUT_REVISION),
    поэтому обе цепочки в любой позиции показывают одну и ту же ревизию. Сравнивается.
"""

from __future__ import annotations

GLOBAL_EXCLUSION_REASON = (
    "Старая цепочка строит справочники повторными DELETE+INSERT (0096, 0101, 0102, 0105, "
    "0107, 0108), поэтому суррогатные ключи разрежены. Baseline вставляет финальное состояние "
    "один раз и получает сплошной 1..N. Безвредно: все FK в схеме идут по строковому code "
    "(questions.code, parameters.code, systems.code, instruments.code, doctors.code) либо по "
    "бизнес-ключу patients.patient_id, ни один — по суррогатному ключу, и наружу (API, Kafka) "
    "он не выходит."
)


IGNORED_COLUMNS: dict[str, frozenset[str]] = {
    "patients_parameters": frozenset({"date_time", "expiration_date"}),
    "patients_parameters_history": frozenset({"date_time", "expiration_date"}),
    "results": frozenset({"date_time", "expiration_date"}),
    "results_history": frozenset({"date_time", "expiration_date"}),
    "interpretations": frozenset({"date_time"}),
    "interpretations_history": frozenset({"date_time"}),
}

EXCLUSION_REASONS: dict[str, str] = {
    "patients_parameters": (
        "0110_reconcile_orphaned_bmi и 0094_heal_pregnancy_capped_expiration пишут значения "
        "от now(). 0110 лежит в общем хвосте и выполняется на обеих БД в разное время."
    ),
    "patients_parameters_history": "Архив строк, которые правит 0110 — те же now()-значения.",
    "results": "server_default=func.now() на date_time; expiration_date считается от now().",
    "results_history": "Архив results — те же now()-значения.",
    "interpretations": "date_time пишется от now() на пути расчёта.",
    "interpretations_history": "Архив interpretations — то же самое.",
}


def ignored_columns_for(table: str) -> frozenset[str]:
    """Объявленные вручную исключения. Суррогатные ключи снимает squash_config.is_surrogate_pk()."""
    return IGNORED_COLUMNS.get(table, frozenset())
