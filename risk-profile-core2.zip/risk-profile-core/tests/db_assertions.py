"""Чтения, на которых тесты строят ассерты.

Отдельный модуль от factories: arrange и assert — разные роли, и сваливание их в один
модуль даёт god-module, в котором невозможно понять, читает хелпер или пишет.
Запросы перенесены из tests/integration/risk_event/seeds.py и tests/integration/calc/_seeds.py
без изменений: задача этого модуля — собрать их в одном месте, а не переписать.
"""

from collections.abc import Mapping
from datetime import datetime
from typing import Any

from sqlalchemy import Row, text
from sqlalchemy.ext.asyncio import AsyncSession


class DbRead:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def answer(self, *, patient_id: str, parameter_code: str) -> str | None:
        row = (
            await self._session.execute(
                text(
                    "SELECT value FROM risk_profile.patients_parameters WHERE patient_id = :p AND parameter_code = :c"
                ),
                {"p": patient_id, "c": parameter_code},
            )
        ).first()
        return None if row is None else row.value

    async def answers(self, *, patient_id: str) -> dict[str, str | None]:
        rows = (
            await self._session.execute(
                text("SELECT parameter_code, value FROM risk_profile.patients_parameters WHERE patient_id = :p"),
                {"p": patient_id},
            )
        ).all()
        return {r.parameter_code: r.value for r in rows}

    async def answer_row(self, *, patient_id: str, parameter_code: str) -> Row | None:
        """Строка patients_parameters целиком — для проверок реконсиляции bmi (#139) и записи
        биомаркеров ЭМК (`external_id`)."""
        row = await self._session.execute(
            text(
                "SELECT value, source, external_id, expiration_date, date_time FROM risk_profile.patients_parameters"
                " WHERE patient_id = :pid AND parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        return row.one_or_none()

    async def count_answer_history(self, *, patient_id: str, parameter_code: str) -> int:
        row = await self._session.execute(
            text(
                "SELECT COUNT(*) FROM risk_profile.patients_parameters_history WHERE patient_id = :pid AND"
                " parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        return row.scalar_one()

    async def result_value(self, *, patient_id: str, instrument_code: str) -> float | None:
        r = await self._session.execute(
            text("SELECT value FROM risk_calculation.results WHERE patient_id = :pid AND instrument_code = :icode"),
            {"pid": patient_id, "icode": instrument_code},
        )
        row = r.one_or_none()
        return float(row.value) if row and row.value is not None else None

    async def count_results(self, *, patient_id: str, instrument_code: str) -> int:
        row = await self._session.execute(
            text("SELECT COUNT(*) FROM risk_calculation.results WHERE patient_id = :pid AND instrument_code = :code"),
            {"pid": patient_id, "code": instrument_code},
        )
        return row.scalar_one()

    async def count_results_history(self, *, patient_id: str, instrument_code: str) -> int:
        row = await self._session.execute(
            text(
                "SELECT COUNT(*) FROM risk_calculation.results_history WHERE patient_id = :pid AND instrument_code ="
                " :code"
            ),
            {"pid": patient_id, "code": instrument_code},
        )
        return row.scalar_one()

    async def count_interpretations(self, *, patient_id: str, system_code: str) -> int:
        row = await self._session.execute(
            text(
                "SELECT COUNT(*) FROM risk_calculation.interpretations WHERE patient_id = :pid AND system_code = :code"
            ),
            {"pid": patient_id, "code": system_code},
        )
        return row.scalar_one()

    async def result_row(self, *, patient_id: str, instrument_code: str) -> Row | None:
        r = await self._session.execute(
            text(
                "SELECT value, unit, risk_level, applicability, indicator, interpretation_status"
                " FROM risk_calculation.results WHERE patient_id = :pid AND instrument_code = :icode"
            ),
            {"pid": patient_id, "icode": instrument_code},
        )
        return r.one_or_none()

    async def instrument_params(self, *, instrument_code: str) -> list[str]:
        """Реальные строки instruments_parameters инструмента, упорядоченные для детерминизма."""
        result = await self._session.execute(
            text(
                "SELECT parameter_code FROM catalog.instruments_parameters WHERE instrument_code = :icode"
                " ORDER BY parameter_code"
            ),
            {"icode": instrument_code},
        )
        return [pcode for (pcode,) in result.all()]

    async def instrument_question_codes(self, *, instrument_code: str) -> list[str]:
        """Коды вопросов СИСТЕМЫ инструмента: вопросы, у которых хотя бы один параметр опции
        принадлежит инструменту этой системы — знаменатель гейта до фильтрации по применимости.
        Упорядочены для детерминизма.
        """
        result = await self._session.execute(
            text(
                "SELECT DISTINCT o.question_code FROM catalog.options o"
                " JOIN catalog.instruments_parameters ip ON ip.parameter_code = o.parameter_code"
                " JOIN catalog.systems_instruments si ON si.instrument_code = ip.instrument_code"
                " WHERE si.system_code IN ("
                "   SELECT system_code FROM catalog.systems_instruments WHERE instrument_code = :icode"
                " ) ORDER BY o.question_code"
            ),
            {"icode": instrument_code},
        )
        return [qcode for (qcode,) in result.all()]

    async def is_pregnant(self, *, patient_id: str) -> bool | None:
        row = await self._session.execute(
            text("SELECT is_pregnant FROM risk_profile.patients WHERE patient_id = :pid"),
            {"pid": patient_id},
        )
        return row.scalar_one()

    async def answer_expiration(self, *, patient_id: str, parameter_code: str) -> datetime | None:
        row = await self._session.execute(
            text(
                "SELECT expiration_date FROM risk_profile.patients_parameters WHERE patient_id = :pid AND"
                " parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        return row.scalar_one_or_none()

    async def answer_columns(self, *, patient_id: str, parameter_code: str) -> Mapping[str, Any] | None:
        """Строка patients_parameters целиком — для проверок реконсиляции bmi (#139) и записи
        биомаркеров ЭМК (`external_id`)."""
        row = await self._session.execute(
            text(
                "SELECT value, source, external_id, expiration_date, date_time FROM risk_profile.patients_parameters"
                " WHERE patient_id = :pid AND parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        found = row.mappings().one_or_none()
        return dict(found) if found is not None else None

    async def answer_history(self, *, patient_id: str, parameter_code: str) -> list[Mapping[str, Any]]:
        row = await self._session.execute(
            text(
                "SELECT value, source, external_id, expiration_date, date_time FROM"
                " risk_profile.patients_parameters_history"
                " WHERE patient_id = :pid AND parameter_code = :code ORDER BY patient_parameter_history_id"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        return [dict(m) for m in row.mappings().all()]

    async def answer_history_date_time(self, *, patient_id: str, parameter_code: str) -> datetime | None:
        row = await self._session.execute(
            text(
                "SELECT date_time FROM risk_profile.patients_parameters_history WHERE patient_id = :pid AND"
                " parameter_code = :code"
            ),
            {"pid": patient_id, "code": parameter_code},
        )
        return row.scalar_one_or_none()

    async def parameter_validity(self, *, parameter_code: str) -> datetime:
        row = await self._session.execute(
            text("SELECT validity_period FROM catalog.parameters WHERE code = :code"),
            {"code": parameter_code},
        )
        return row.scalar_one()

    async def count_interpretations_history(self, *, patient_id: str, system_code: str) -> int:
        row = await self._session.execute(
            text(
                "SELECT COUNT(*) FROM risk_calculation.interpretations_history WHERE patient_id = :pid AND"
                " system_code = :code"
            ),
            {"pid": patient_id, "code": system_code},
        )
        return row.scalar_one()

    # Бизнес-колонки перечислены явными литералами (без суррогатного PK) — архив сверяется
    # с оригиналом байт-в-байт; литеральный SQL, без конкатенации, чтобы не триггерить SAST.

    async def results_history(self, *, patient_id: str, instrument_code: str) -> list[Mapping[str, Any]]:
        row = await self._session.execute(
            text(
                "SELECT instrument_code, patient_id, value, indicator, date_time, interpretation_status,"
                " expiration_date, risk_level, applicability, unit FROM risk_calculation.results_history"
                " WHERE patient_id = :pid AND instrument_code = :code ORDER BY indicator"
            ),
            {"pid": patient_id, "code": instrument_code},
        )
        return [dict(m) for m in row.mappings().all()]

    async def interpretations_history(self, *, patient_id: str, system_code: str) -> list[Mapping[str, Any]]:
        row = await self._session.execute(
            text(
                "SELECT system_code, patient_id, risk_level, text, diseases, risk_factors_code, doctors_code,"
                " date_time FROM risk_calculation.interpretations_history WHERE patient_id = :pid AND system_code ="
                " :code"
            ),
            {"pid": patient_id, "code": system_code},
        )
        return [dict(m) for m in row.mappings().all()]
