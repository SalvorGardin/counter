from typing import Any

import pytest
from pydantic import SecretStr, ValidationError

from src.config import (
    BulkRecalcSettings,
    CvdSettings,
    KafkaConsumerSettings,
    KafkaSettings,
    ProfilerSettings,
    ServiceRuntime,
    Settings,
)
from src.constants import REQUIRED_LOG_MASK_KEYS, normalize_mask_key

_DB_URL_ENVS: dict[ServiceRuntime, str] = {
    ServiceRuntime.PROFILE: "RISK_MODEL_PROFILE_DB_URL",
    ServiceRuntime.CALCULATION: "RISK_MODEL_CALCULATION_DB_URL",
    ServiceRuntime.EHR: "RISK_MODEL_EHR_DB_URL",
    ServiceRuntime.BULK_RECALC: "RISK_MODEL_BULK_RECALC_DB_URL",
}
_ALL_DB_URL_ENVS = (*_DB_URL_ENVS.values(), "RISK_MODEL_MIGRATIONS_DB_URL")


@pytest.mark.parametrize("env", _ALL_DB_URL_ENVS)
def test_db_url_is_loaded_from_its_own_variable(monkeypatch, env: str, mock_db_string: str):
    monkeypatch.setenv(env, mock_db_string)
    field = env.removeprefix("RISK_MODEL_").lower()
    assert getattr(Settings(), field).get_secret_value() == mock_db_string


def test_settings_load_without_any_db_url(monkeypatch):
    """Обязательность строки подключения проверяет процесс на старте, а не загрузка `Settings`:
    процессу, которому подключили только его файл переменных, чужая не нужна."""
    for env in _ALL_DB_URL_ENVS:
        monkeypatch.delenv(env, raising=False)
    s = Settings()
    assert s.profile_db_url is None
    assert s.calculation_db_url is None
    assert s.ehr_db_url is None
    assert s.bulk_recalc_db_url is None
    assert s.migrations_db_url is None


@pytest.mark.parametrize("value", ["", "  "])
def test_blank_db_urls_load_as_unset(monkeypatch, value: str):
    """Пустые значения не роняют загрузку `Settings`: её проходят все процессы, а своя переменная
    нужна каждому одна — её проверяет старт процесса (`require_db_url`)."""
    for env in _ALL_DB_URL_ENVS:
        monkeypatch.setenv(env, value)
    s = Settings()
    for env in _ALL_DB_URL_ENVS:
        assert getattr(s, env.removeprefix("RISK_MODEL_").lower()) is None


def test_db_urls_are_secret(monkeypatch, mock_db_string: str):
    """URL несёт пароль: он не должен попадать ни в repr, ни в model_dump."""
    for env in _ALL_DB_URL_ENVS:
        monkeypatch.setenv(env, mock_db_string)
    s = Settings()
    assert "postgresql" not in repr(s)
    dumped = s.model_dump()
    for env in _ALL_DB_URL_ENVS:
        assert str(dumped[env.removeprefix("RISK_MODEL_").lower()]) == "**********"


def test_legacy_db_variables_are_not_read(monkeypatch):
    """Прежние имена больше не задают ни роль, ни строку подключения."""
    monkeypatch.setenv("RISK_MODEL_DB_URL", "postgresql+asyncpg://risk_profile_app:pw@db:5432/riskdb")
    monkeypatch.setenv("RISK_MODEL_SERVICE_RUNTIME", "profile")
    dumped = Settings().model_dump()
    assert "db_url" not in dumped
    assert "service_runtime" not in dumped


def test_assume_runtime_role_is_off_by_default(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_DB_ASSUME_RUNTIME_ROLE", raising=False)
    assert Settings().db_assume_runtime_role is False


@pytest.mark.parametrize("runtime", list(ServiceRuntime))
def test_require_db_url_fails_only_without_its_own_variable(monkeypatch, runtime: ServiceRuntime):
    """Нет своей переменной — ошибка с её именем; отсутствие чужих процессу не мешает."""
    from src.config import DatabaseConfigError, require_db_url

    url = SecretStr("postgresql+asyncpg://user:pw@db:5432/riskdb")
    for other, env in _DB_URL_ENVS.items():
        field = env.removeprefix("RISK_MODEL_").lower()
        monkeypatch.setattr(f"src.config.settings.{field}", None if other is runtime else url)
    with pytest.raises(DatabaseConfigError, match=_DB_URL_ENVS[runtime]):
        require_db_url(runtime)

    for other, env in _DB_URL_ENVS.items():
        field = env.removeprefix("RISK_MODEL_").lower()
        monkeypatch.setattr(f"src.config.settings.{field}", url if other is runtime else None)
    assert require_db_url(runtime).get_secret_value() == url.get_secret_value()


def test_legacy_db_notice_names_present_variables_without_values(monkeypatch, captured_app_logs):
    from src.config import notice_legacy_db_env

    secret_url = "postgresql+asyncpg://risk_profile_app:s3cr3t-pw@db:5432/riskdb"
    monkeypatch.setenv("RISK_MODEL_DB_URL", secret_url)
    monkeypatch.setenv("RISK_MODEL_SERVICE_RUNTIME", "profile")

    notice_legacy_db_env()

    records = [r for r in captured_app_logs.records if r.getMessage() == "legacy database env variables are ignored"]
    assert len(records) == 1
    assert records[0].levelname == "NOTICE"
    assert captured_app_logs.context_of("legacy database env variables are ignored")["variables"] == [
        "RISK_MODEL_DB_URL",
        "RISK_MODEL_SERVICE_RUNTIME",
    ]
    assert "s3cr3t-pw" not in captured_app_logs.output()


def test_legacy_db_notice_is_silent_without_legacy_variables(monkeypatch, captured_app_logs):
    from src.config import notice_legacy_db_env

    monkeypatch.delenv("RISK_MODEL_DB_URL", raising=False)
    monkeypatch.delenv("RISK_MODEL_SERVICE_RUNTIME", raising=False)

    notice_legacy_db_env()

    assert "legacy database env variables are ignored" not in captured_app_logs.messages()


@pytest.mark.parametrize(
    ("kafka_enabled", "testing_api_enabled", "required"),
    [
        (True, False, False),  # прод: считает консюмер, второго подключения у API нет
        (False, False, True),  # инлайн-пересчёт в процессе API
        (True, True, True),  # стенд: POST /testing/calculation/run считает и пишет здесь же
        (False, True, True),
    ],
)
def test_calculation_runtime_required_covers_both_consumers(
    monkeypatch, kafka_enabled: bool, testing_api_enabled: bool, required: bool
):
    """Потребителей второго подключения два, и хватает любого — иначе расчёт пишет под профилем."""
    from src.config import calculation_runtime_required

    monkeypatch.setattr("src.config.settings.kafka.enabled", kafka_enabled)
    monkeypatch.setattr("src.config.settings.testing_api_enabled", testing_api_enabled)
    assert calculation_runtime_required() is required


def test_log_level_reads_from_unprefixed_env(monkeypatch):
    monkeypatch.setenv("LOG_LEVEL", "WARNING")
    monkeypatch.delenv("RISK_MODEL_LOG_LEVEL", raising=False)

    s = Settings()
    assert s.log_level == "WARNING"


def test_log_level_ignores_prefixed_env(monkeypatch):
    # После переименования RISK_MODEL_LOG_LEVEL больше не должен влиять — только LOG_LEVEL.
    monkeypatch.delenv("LOG_LEVEL", raising=False)
    monkeypatch.setenv("RISK_MODEL_LOG_LEVEL", "ERROR")

    s = Settings()
    assert s.log_level == "NOTICE"


def test_log_level_default_is_notice(monkeypatch):
    monkeypatch.delenv("LOG_LEVEL", raising=False)
    monkeypatch.delenv("RISK_MODEL_LOG_LEVEL", raising=False)

    s = Settings()
    assert s.log_level == "NOTICE"


def test_log_level_rejects_invalid_value(monkeypatch):
    monkeypatch.setenv("LOG_LEVEL", "VERBOSE")

    with pytest.raises(ValidationError):
        Settings()


def test_workers_default_is_4(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_WORKERS", raising=False)

    s = Settings()
    assert s.workers == 4


def test_workers_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_WORKERS", "8")

    s = Settings()
    assert s.workers == 8


def test_workers_rejects_below_one(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_WORKERS", "0")

    with pytest.raises(ValidationError):
        Settings()


def test_profiler_disabled_by_default(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_PROFILER__ENABLED", raising=False)

    s = Settings()
    assert s.profiler.enabled is False
    assert s.profiler.retention_minutes == 20
    assert s.profiler.bucket_seconds == 60


def test_profiler_retention_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_PROFILER__ENABLED", "true")
    monkeypatch.setenv("RISK_MODEL_PROFILER__RETENTION_MINUTES", "5")

    s = Settings()
    assert s.profiler.enabled is True
    assert s.profiler.retention_minutes == 5


def test_profiler_bucket_must_not_exceed_window(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_PROFILER__RETENTION_MINUTES", "1")
    monkeypatch.setenv("RISK_MODEL_PROFILER__BUCKET_SECONDS", "120")

    with pytest.raises(ValidationError):
        Settings()


# --- Kafka: топик команд + consumer-воркер ---


def test_recalc_command_defaults():
    from src.config import settings

    assert settings.kafka.topics.recalc_commands == "risk-profile.recalc-commands"
    assert settings.kafka.recalc_commands_partitions == 6
    assert settings.kafka.consumer.group_id == "risk-recalc-workers"
    assert settings.kafka.consumer.max_concurrency == 4
    assert settings.kafka.consumer.auto_offset_reset == "earliest"


def test_recalc_commands_partitions_overridable(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_KAFKA__RECALC_COMMANDS_PARTITIONS", "12")

    s = Settings()
    assert s.kafka.recalc_commands_partitions == 12


def test_recalc_commands_partitions_rejects_below_one(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_KAFKA__RECALC_COMMANDS_PARTITIONS", "0")

    with pytest.raises(ValidationError):
        Settings()


def test_consumer_settings_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_KAFKA__CONSUMER__GROUP_ID", "custom-group")
    monkeypatch.setenv("RISK_MODEL_KAFKA__CONSUMER__MAX_CONCURRENCY", "8")
    monkeypatch.setenv("RISK_MODEL_KAFKA__CONSUMER__MAX_POLL_RECORDS", "100")

    s = Settings()
    assert s.kafka.consumer.group_id == "custom-group"
    assert s.kafka.consumer.max_concurrency == 8
    assert s.kafka.consumer.max_poll_records == 100


def test_consumer_auto_offset_reset_rejects_invalid():
    with pytest.raises(ValidationError):
        KafkaConsumerSettings(auto_offset_reset="middle")


def test_consumer_max_concurrency_rejects_below_one():
    with pytest.raises(ValidationError):
        KafkaConsumerSettings(max_concurrency=0)


def test_consumer_heartbeat_must_be_below_session_timeout():
    with pytest.raises(ValidationError):
        KafkaConsumerSettings(session_timeout_ms=3000, heartbeat_interval_ms=3000)


# --- Kafka: топик биомаркеров ЭМК + его consumer-воркер ---


def test_emr_biomarkers_defaults():
    from src.config import settings

    assert settings.kafka.topics.emr_biomarkers == "emr-biomarkers"
    assert settings.kafka.emr_biomarkers_enabled is False
    assert settings.kafka.emr_biomarkers_consumer.group_id == "risk-emr-biomarkers-workers"
    assert settings.emr_consumer_health_port == 8000


def test_emr_biomarkers_group_differs_from_recalc_group():
    """Общая группа посадила бы оба воркера в одну consumer-группу, и они начали бы отбирать
    друг у друга партиции своих топиков."""
    from src.config import settings

    assert settings.kafka.emr_biomarkers_consumer.group_id != settings.kafka.consumer.group_id


def test_emr_biomarkers_settings_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_KAFKA__TOPICS__EMR_BIOMARKERS", "emr-biomarkers-stage")
    monkeypatch.setenv("RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED", "true")
    monkeypatch.setenv("RISK_MODEL_KAFKA__EMR_BIOMARKERS_CONSUMER__GROUP_ID", "stage-emr-workers")
    monkeypatch.setenv("RISK_MODEL_KAFKA__EMR_BIOMARKERS_CONSUMER__MAX_CONCURRENCY", "2")
    monkeypatch.setenv("RISK_MODEL_EMR_CONSUMER_HEALTH_PORT", "8111")

    s = Settings()
    assert s.kafka.topics.emr_biomarkers == "emr-biomarkers-stage"
    assert s.kafka.emr_biomarkers_enabled is True
    assert s.kafka.emr_biomarkers_consumer.group_id == "stage-emr-workers"
    assert s.kafka.emr_biomarkers_consumer.max_concurrency == 2
    assert s.emr_consumer_health_port == 8111
    # Настройки воркера пересчёта своей секцией не задеты.
    assert s.kafka.consumer.group_id == "risk-recalc-workers"


def test_legacy_ehr_env_names_are_ignored(monkeypatch):
    """Имена переменных первой редакции контракта не читаются: алиасов и переходного периода нет,
    поэтому старое имя равносильно отсутствию переменной."""
    monkeypatch.setenv("RISK_MODEL_KAFKA__TOPICS__EHR_BIOMARKERS", "ehr-biomarkers")
    monkeypatch.setenv("RISK_MODEL_KAFKA__EHR_BIOMARKERS_ENABLED", "true")
    monkeypatch.setenv("RISK_MODEL_KAFKA__EHR_BIOMARKERS_CONSUMER__GROUP_ID", "risk-ehr-biomarkers-workers")
    monkeypatch.setenv("RISK_MODEL_EHR_CONSUMER_HEALTH_PORT", "8111")

    s = Settings()
    assert s.kafka.topics.emr_biomarkers == "emr-biomarkers"
    assert s.kafka.emr_biomarkers_enabled is False
    assert s.kafka.emr_biomarkers_consumer.group_id == "risk-emr-biomarkers-workers"
    assert s.emr_consumer_health_port == 8000


@pytest.mark.parametrize("port", ["0", "70000"])
def test_emr_consumer_health_port_rejects_out_of_range(monkeypatch, port):
    monkeypatch.setenv("RISK_MODEL_EMR_CONSUMER_HEALTH_PORT", port)

    with pytest.raises(ValidationError):
        Settings()


# --- log_mask_keys: принудительные секретные ключи (ревью !99) ---


def test_log_mask_keys_default_contains_required_secrets():
    s = Settings()
    present = {normalize_mask_key(k) for k in s.log_mask_keys.split(",") if k.strip()}
    for required in REQUIRED_LOG_MASK_KEYS.split(","):
        assert normalize_mask_key(required) in present


def test_log_mask_keys_secrets_enforced_when_env_omits_them():
    """Оператор задал только PII-ключи — секреты вливаются принудительно, токены не утекут."""
    s = Settings(log_mask_keys="gender,birthdate")
    assert s.log_mask_keys.startswith("gender,birthdate")
    for required in REQUIRED_LOG_MASK_KEYS.split(","):
        assert required in s.log_mask_keys


def test_log_mask_keys_empty_env_still_masks_secrets():
    s = Settings(log_mask_keys="")
    assert s.log_mask_keys == REQUIRED_LOG_MASK_KEYS


def test_log_mask_keys_no_duplicates_when_secrets_present():
    """Секреты уже в списке (в любом регистре/форме) — валидатор ничего не добавляет."""
    raw = "gender,Authorization,COOKIE,set_cookie,X-Test-Api-Key,x_restarter_api_key"
    s = Settings(log_mask_keys=raw)
    assert s.log_mask_keys == raw


def test_test_api_key_not_exposed_in_repr():
    """SecretStr: значение ключа не светится в repr/model_dump (ревью !99)."""
    s = Settings()
    secret = s.test_api_key.get_secret_value()
    assert secret  # conftest включает testing API и задаёт ключ
    assert secret not in repr(s)
    assert secret not in str(s.model_dump())


# --- Graceful shutdown ---


def test_db_pool_recycle_seconds_default(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_DB_POOL_RECYCLE_SECONDS", raising=False)

    s = Settings()
    assert s.db_pool_recycle_seconds == 300


def test_db_pool_recycle_seconds_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_DB_POOL_RECYCLE_SECONDS", "120")

    s = Settings()
    assert s.db_pool_recycle_seconds == 120


def test_db_pool_recycle_seconds_allows_zero_to_disable(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_DB_POOL_RECYCLE_SECONDS", "0")

    s = Settings()
    assert s.db_pool_recycle_seconds == 0


def test_db_pool_recycle_seconds_rejects_negative(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_DB_POOL_RECYCLE_SECONDS", "-1")

    with pytest.raises(ValidationError):
        Settings()


def test_shutdown_timeout_default(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_SHUTDOWN_TIMEOUT", raising=False)

    s = Settings()
    assert s.shutdown_timeout == 60


def test_shutdown_timeout_overridable_from_env(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "30")

    s = Settings()
    assert s.shutdown_timeout == 30


def test_shutdown_timeout_rejects_below_one(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "0")

    with pytest.raises(ValidationError):
        Settings()


def test_shutdown_grace_delay_default(monkeypatch):
    monkeypatch.delenv("RISK_MODEL_SHUTDOWN_GRACE_DELAY", raising=False)

    s = Settings()
    assert s.shutdown_grace_delay == 0.0


def test_shutdown_grace_delay_rejects_negative(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_GRACE_DELAY", "-1")

    with pytest.raises(ValidationError):
        Settings()


def test_shutdown_grace_delay_must_leave_teardown_budget(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "10")
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_GRACE_DELAY", "6")

    with pytest.raises(ValidationError):
        Settings()


def test_shutdown_grace_delay_at_max_allowed(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "10")
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_GRACE_DELAY", "5")

    s = Settings()
    assert s.shutdown_grace_delay == 5.0


def test_consumer_shutdown_timeout_inherits_shutdown_timeout(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "45")
    monkeypatch.delenv("RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT", raising=False)

    s = Settings()
    assert s.consumer_shutdown_timeout == 45


def test_consumer_shutdown_timeout_overridable_independently(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "60")
    monkeypatch.setenv("RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT", "30")

    s = Settings()
    assert s.shutdown_timeout == 60
    assert s.consumer_shutdown_timeout == 30


def test_consumer_shutdown_timeout_rejects_below_one(monkeypatch):
    monkeypatch.setenv("RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT", "0")

    with pytest.raises(ValidationError):
        Settings()


# --- restarter.stop_timeout_s: бюджет graceful stop при перезапуске контейнеров ---


def test_restarter_stop_timeout_covers_shutdown_budget_by_default():
    """Дефолт не даёт демону прибить процесс раньше его собственного бюджета остановки."""
    s = Settings()
    assert s.restarter.stop_timeout_s >= max(s.shutdown_timeout, s.consumer_shutdown_timeout)


def test_restarter_api_key_rejects_short_key(monkeypatch):
    """Ключ привилегированной ручки короче 16 символов перебирается — старт запрещён."""
    monkeypatch.setenv("RISK_MODEL_RESTARTER__API_KEY", "1")

    with pytest.raises(ValidationError, match="RESTARTER__API_KEY"):
        Settings()


def test_restarter_api_key_rejects_overlong_key(monkeypatch):
    """Длиннее 64 символов — в переменную попал не ключ, а посторонние данные."""
    monkeypatch.setenv("RISK_MODEL_RESTARTER__API_KEY", "a" * 65)

    with pytest.raises(ValidationError, match="RESTARTER__API_KEY"):
        Settings()


def test_restarter_api_key_accepts_empty_and_bounds(monkeypatch):
    """Пустое значение — штатный способ выключить ручку; границы диапазона допустимы."""
    monkeypatch.setenv("RISK_MODEL_RESTARTER__API_KEY", "")
    assert Settings().restarter.api_key.get_secret_value() == ""

    for key in ("a" * 16, "a" * 64):
        monkeypatch.setenv("RISK_MODEL_RESTARTER__API_KEY", key)
        assert Settings().restarter.api_key.get_secret_value() == key


def test_restarter_stop_timeout_rejects_shorter_than_shutdown_budget(monkeypatch):
    """`t` меньше бюджета дренажа — это SIGKILL посреди штатной остановки, старт запрещён."""
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "60")
    monkeypatch.setenv("RISK_MODEL_RESTARTER__STOP_TIMEOUT_S", "20")

    with pytest.raises(ValidationError, match="stop_timeout_s"):
        Settings()


def test_restarter_stop_timeout_tracks_consumer_budget(monkeypatch):
    """Бюджет берётся по максимуму из двух: у консюмера он может быть длиннее, чем у uvicorn."""
    monkeypatch.setenv("RISK_MODEL_SHUTDOWN_TIMEOUT", "30")
    monkeypatch.setenv("RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT", "90")
    monkeypatch.setenv("RISK_MODEL_RESTARTER__STOP_TIMEOUT_S", "60")

    with pytest.raises(ValidationError, match="stop_timeout_s"):
        Settings()

    monkeypatch.setenv("RISK_MODEL_RESTARTER__STOP_TIMEOUT_S", "90")
    assert Settings().restarter.stop_timeout_s == 90


# --- Отказы валидаторов настроек ---
#
# Каждый случай ниже — конфигурация, с которой сервис обязан НЕ стартовать. Пропущенная
# проверка не даёт видимой ошибки: сервис поднимается с молча неверным режимом безопасности
# Kafka или с открытым testing-API, и узнают об этом уже по последствиям.


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"auto_offset_reset": "newest"}, "auto_offset_reset must be one of"),
        ({"max_poll_records": 0}, "max_poll_records must be >= 1"),
        ({"fetch_max_wait_ms": 0}, "fetch_max_wait_ms must be >= 1"),
        # Kafka требует heartbeat_interval_ms < session_timeout_ms: равенство уже сбой.
        ({"session_timeout_ms": 10_000, "heartbeat_interval_ms": 10_000}, "must be < session_timeout_ms"),
        ({"session_timeout_ms": 10_000, "heartbeat_interval_ms": 20_000}, "must be < session_timeout_ms"),
    ],
)
def test_consumer_settings_reject_invalid_values(kwargs, message):
    with pytest.raises(ValidationError, match=message):
        KafkaConsumerSettings(**kwargs)


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"security_protocol": "SASL"}, "security_protocol must be one of"),
        ({"security_protocol": "SASL_SSL", "sasl_mechanism": "GSSAPI"}, "sasl_mechanism must be one of"),
        ({"sasl_password": SecretStr("pa,ss")}, "must not contain ','"),
        ({"recalc_commands_partitions": 0}, "recalc_commands_partitions must be >= 1"),
    ],
)
def test_kafka_settings_reject_invalid_values(kwargs, message):
    with pytest.raises(ValidationError, match=message):
        KafkaSettings(**kwargs)


def test_kafka_sasl_mechanism_not_checked_without_sasl():
    """Устаревший RISK_MODEL_KAFKA__SASL_MECHANISM в env не роняет старт там, где поле не используется."""
    assert KafkaSettings(security_protocol="PLAINTEXT", sasl_mechanism="GSSAPI").sasl_mechanism == "GSSAPI"


@pytest.mark.parametrize(
    ("protocol", "extra", "missing"),
    [
        ("PLAINTEXT", {}, "BOOTSTRAP_SERVERS"),
        ("SSL", {"bootstrap_servers": "kafka:9093"}, "SSL_CAFILE,SSL_CERTFILE,SSL_KEYFILE"),
        (
            "SSL",
            {"bootstrap_servers": "kafka:9093", "ssl_cafile": "/ca.crt", "ssl_certfile": "/c.crt"},
            "SSL_KEYFILE",
        ),
        ("SASL_PLAINTEXT", {"bootstrap_servers": "kafka:9093"}, "SASL_USERNAME,SASL_PASSWORD"),
        (
            "SASL_SSL",
            {"bootstrap_servers": "kafka:9093", "sasl_username": "risk-app"},
            "SASL_PASSWORD",
        ),
    ],
)
def test_enabled_kafka_requires_fields_of_its_security_mode(protocol, extra, missing):
    """У каждого режима безопасности свой обязательный набор — недобор валит старт, а не подключение.

    Иначе сервис поднялся бы, а сбой всплыл бы на первом же fetch как невнятная ошибка авторизации.
    """
    kafka = KafkaSettings(enabled=True, security_protocol=protocol, **extra)

    with pytest.raises(ValidationError, match=missing):
        Settings(kafka=kafka)


def test_enabled_kafka_with_ssl_accepts_full_mtls_set():
    kafka = KafkaSettings(
        enabled=True,
        security_protocol="SSL",
        bootstrap_servers="kafka:9093",
        ssl_cafile="/ca.crt",
        ssl_certfile="/c.crt",
        ssl_keyfile="/c.key",
    )
    assert Settings(kafka=kafka).kafka.enabled is True


def test_disabled_kafka_needs_no_fields():
    """Выключенная Kafka не требует ничего: в unit-тестах и локальном запуске брокера нет."""
    assert Settings(kafka=KafkaSettings(enabled=False)).kafka.bootstrap_servers == ""


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"retention_minutes": 0}, "retention_minutes must be >= 1"),
        ({"bucket_seconds": 0}, "bucket_seconds must be >= 1"),
        ({"retention_minutes": 1, "bucket_seconds": 61}, "must not exceed retention window"),
    ],
)
def test_profiler_settings_reject_invalid_values(kwargs, message):
    with pytest.raises(ValidationError, match=message):
        ProfilerSettings(**kwargs)


def test_cvd_default_period_rejects_unknown_horizon():
    with pytest.raises(ValidationError, match="default_period must be one of"):
        CvdSettings(default_period="Y10")


def test_log_body_max_bytes_rejects_below_one():
    with pytest.raises(ValidationError, match="LOG_BODY_MAX_BYTES must be >= 1"):
        Settings(log_body_max_bytes=0)


@pytest.mark.parametrize(
    ("key", "message"),
    [
        ("", "must not be empty when testing API is enabled"),
        ("short-key", "must be at least 16 characters"),
    ],
)
def test_test_api_key_rule_when_testing_api_enabled(key, message):
    """Ключ testing-API — контроль доступа: включённый API с пустым или коротким ключом не стартует."""
    with pytest.raises(ValidationError, match=message):
        Settings(testing_api_enabled=True, test_api_key=SecretStr(key))


def test_test_api_key_unchecked_when_testing_api_disabled():
    assert Settings(testing_api_enabled=False, test_api_key=SecretStr("")).test_api_key.get_secret_value() == ""


def test_validators_accept_explicit_valid_values():
    """Явно заданные корректные значения проходят.

    Валидаторы pydantic не запускаются на значениях по умолчанию, поэтому положительный исход
    каждой проверки виден только при явно переданном значении — здесь оно и передаётся.
    """
    consumer = KafkaConsumerSettings(
        auto_offset_reset="latest",
        session_timeout_ms=30_000,
        heartbeat_interval_ms=10_000,
        max_poll_records=100,
    )
    assert consumer.auto_offset_reset == "latest"
    assert consumer.heartbeat_interval_ms == 10_000

    kafka = KafkaSettings(
        security_protocol="SASL_SSL",
        sasl_mechanism="SCRAM-SHA-256",
        sasl_password=SecretStr("no-comma-here"),
        recalc_commands_partitions=12,
    )
    assert kafka.sasl_mechanism == "SCRAM-SHA-256"
    assert kafka.sasl_password.get_secret_value() == "no-comma-here"

    assert CvdSettings(default_period="Y2").default_period == "Y2"
    assert ProfilerSettings(retention_minutes=10, bucket_seconds=30).bucket_seconds == 30


def test_consumer_shutdown_timeout_inheritance_passes_through_non_mapping_input():
    """Наследование таймаута достраивается только по словарю источников.

    Валидатор стоит на mode="before" и получает вход как есть: не-словарь он обязан отдать
    дальше нетронутым, иначе валидация упала бы на попытке дописать в него ключ. Проверяется
    штатным путём, а не вызовом валидатора напрямую: ошибка про тип модели означает, что вход
    дошёл до проверки типа нетронутым, а падение внутри валидатора дало бы TypeError.
    """
    with pytest.raises(ValidationError) as exc_info:
        Settings.model_validate(None)

    assert [error["type"] for error in exc_info.value.errors()] == ["model_type"]


# ---------------------------------------------------------------- массовый пересчёт


def test_bulk_recalc_run_is_disabled_by_default():
    """CronJob заводится заранее, а включают прогон отдельно и осознанно — после проверки
    раската и ACL на запись в топик команд."""
    assert BulkRecalcSettings().enabled is False


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("batch_size", 0),
        ("canary_size", 0),
        ("time_budget_seconds", 0.0),
        ("canary_timeout_seconds", -1.0),
        ("canary_poll_interval_seconds", 0.0),
        ("query_timeout_seconds", 0.0),
        ("pause_seconds", -0.5),
    ],
)
def test_bulk_recalc_rejects_unusable_limits(field: str, value: float):
    """Границы прогона — единственное, что удерживает его от заливки когорты в очередь
    одномоментно: нулевой батч или отрицательная пауза должны падать на старте."""
    limits: dict[str, Any] = {field: value}
    with pytest.raises(ValidationError):
        BulkRecalcSettings(**limits)


def test_bulk_recalc_allows_a_zero_pause():
    assert BulkRecalcSettings(pause_seconds=0.0).pause_seconds == 0.0


def test_background_capacity_defaults_to_one_slot_per_process():
    """Абсолютное число, а не доля конкурентности воркера: доля молча выросла бы при её изменении."""
    assert Settings().background_recalc_capacity == 1


def test_background_capacity_allows_zero_to_close_background_entirely():
    assert Settings(background_recalc_capacity=0).background_recalc_capacity == 0


def test_background_capacity_rejects_a_negative_value():
    with pytest.raises(ValidationError):
        Settings(background_recalc_capacity=-1)


def test_background_min_interval_is_off_by_default():
    """Ограничение темпа включает оператор: дефолт оставляет прежнее поведение одной ёмкости."""
    assert Settings().background_recalc_min_interval_seconds == 0.0


def test_background_min_interval_rejects_a_negative_value():
    """Отрицательное значение работало бы как ноль — молча снятое ограничение темпа хуже отказа."""
    with pytest.raises(ValidationError):
        Settings(background_recalc_min_interval_seconds=-0.5)


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("saturation_window_seconds", 0.0),
        ("saturation_latency_ms", 0.0),
        ("saturation_min_observations", 0),
        ("saturation_error_rate", 1.5),
        ("saturation_error_rate", -0.1),
        ("saturation_recovery_jitter_seconds", -1.0),
    ],
)
def test_cvd_saturation_thresholds_are_validated(field: str, value: float):
    thresholds: dict[str, Any] = {field: value}
    with pytest.raises(ValidationError):
        CvdSettings(**thresholds)
