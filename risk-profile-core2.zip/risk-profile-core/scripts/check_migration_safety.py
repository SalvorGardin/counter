#!/usr/bin/env python3
"""Структурная страховка против повторяющихся блокеров в Alembic-миграциях.

Ловит ровно те классы проблем, которые чаще всего всплывали на ревью миграций
(см. docs/conventions/review-conventions.md, категория «Database / migration safety»):

  M1  add_column(..., nullable=False) без server_default
      → на непустой таблице `ADD COLUMN NOT NULL` упадёт. Сначала nullable → backfill → NOT NULL.
  M2  INSERT INTO ... без ON CONFLICT
      → upgrade→downgrade→upgrade задублирует сид-строки. Все сиды должны быть идемпотентны.
  M3  DELETE FROM ... без WHERE
      → сносит ВСЕ строки таблицы, включая те, что были до этой миграции. WHERE по своим строкам.
  M4  UPDATE ... без WHERE
      → массовый апдейт всей таблицы; почти всегда не то, что задумано.
  M5  downgrade() пустой / `pass` / `...` / raise NotImplementedError без коммента
      → молчаливо необратимая миграция. Либо реальный откат, либо явный комментарий-предупреждение.

Это эвристика на тексте (как scripts/check_logger_info.py), а не полноценный SQL-парсер:
цель — дать быстрый красный сигнал в CI и в hook-е до ревью, а не доказать корректность.
Ложное срабатывание глушится комментарием `# migration-safety: ok <причина>` на строке находки.

Запуск:
    python scripts/check_migration_safety.py                 # все миграции цепочки migrations/versions/
    python scripts/check_migration_safety.py path/to/0099_x.py  # конкретные файлы (hook)
"""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

# scripts/ не пакет: при запуске файлом сосед виден сам собой, но при вызове из хука с
# другим cwd — нет, поэтому директория добавляется в sys.path явно (как в
# scripts/make_squashed_baseline.py).
sys.path.insert(0, str(Path(__file__).resolve().parent))

import squash_config  # noqa: E402 — только после правки sys.path

REPO_ROOT = squash_config.REPO_ROOT

# Где живут цепочки — знает squash_config, и только он: раньше полный прогон смотрел
# только в migrations/versions, а фильтр argv матчил обе цепочки по подстроке, то есть
# хук линтил схлопнутую цепочку, а `make lint-migrations` — нет.
MIGRATIONS_DIRS = [squash_config.chain_version_location(chain) for chain in sorted(squash_config.CHAIN_DIRS)]

# Комментарий-глушилка на строке находки.
_SUPPRESS = re.compile(r"#\s*migration-safety:\s*ok\b")

# M1: Column(..., nullable=False ...) без server_default в том же вызове.
_COLUMN_CALL = re.compile(r"\.add_column\s*\(", re.IGNORECASE)
_NULLABLE_FALSE = re.compile(r"nullable\s*=\s*False")
_SERVER_DEFAULT = re.compile(r"server_default\s*=")

# M2/M3/M4: SQL-глаголы. Проверяем ТОЛЬКО строки внутри sa.text(...), не docstring/комментарии.
_INSERT = re.compile(r"\bINSERT\s+INTO\b", re.IGNORECASE)
_ON_CONFLICT = re.compile(r"\bON\s+CONFLICT\b", re.IGNORECASE)
_DELETE = re.compile(r"\bDELETE\s+FROM\b", re.IGNORECASE)
# Реальный UPDATE-стейтмент = `UPDATE <table> SET`, но НЕ `... DO UPDATE SET` (это upsert).
_UPDATE_STMT = re.compile(r"(?<!DO\s)\bUPDATE\s+\w+\s+SET\b", re.IGNORECASE)
_WHERE = re.compile(r"\bWHERE\b", re.IGNORECASE)


class Finding:
    __slots__ = ("path", "line", "code", "message")

    def __init__(self, path: Path, line: int, code: str, message: str) -> None:
        self.path = path
        self.line = line
        self.code = code
        self.message = message

    def __str__(self) -> str:
        rel = self.path.relative_to(REPO_ROOT)
        return f"{rel}:{self.line}: [{self.code}] {self.message}"


def _line_of(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def _suppressed(lines: list[str], line_no: int) -> bool:
    idx = line_no - 1
    return 0 <= idx < len(lines) and bool(_SUPPRESS.search(lines[idx]))


def _check_not_null_columns(text: str, lines: list[str], path: Path) -> list[Finding]:
    findings: list[Finding] = []
    for m in _COLUMN_CALL.finditer(text):
        # Берём аргументы add_column(...) до закрывающей скобки (грубо, по балансу).
        start = m.end()
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            if text[i] == "(":
                depth += 1
            elif text[i] == ")":
                depth -= 1
            i += 1
        segment = text[start:i]
        if _NULLABLE_FALSE.search(segment) and not _SERVER_DEFAULT.search(segment):
            line_no = _line_of(text, m.start())
            if not _suppressed(lines, line_no):
                findings.append(
                    Finding(
                        path,
                        line_no,
                        "M1",
                        "add_column(nullable=False) без server_default — упадёт на непустой таблице. "
                        "Делай nullable=True → backfill → alter_column(nullable=False), либо добавь server_default.",
                    )
                )
    return findings


def _extract_sql_literals(text: str) -> list[tuple[str, int]]:
    """Возвращает (sql, lineno) для каждого строкового литерала-аргумента sa.text(...).

    Так мы проверяем только настоящий SQL, а не прозу в docstring/комментариях.
    Соседние строковые литералы Python склеивает в один Constant ещё на парсинге.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    out: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        is_text = (isinstance(func, ast.Attribute) and func.attr == "text") or (
            isinstance(func, ast.Name) and func.id == "text"
        )
        if not is_text or not node.args:
            continue
        arg = node.args[0]
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            out.append((arg.value, node.lineno))
    return out


def _check_sql_verbs(text: str, lines: list[str], path: Path) -> list[Finding]:
    findings: list[Finding] = []
    for sql, line_no in _extract_sql_literals(text):
        if _suppressed(lines, line_no):
            continue
        if _INSERT.search(sql) and not _ON_CONFLICT.search(sql):
            findings.append(
                Finding(
                    path,
                    line_no,
                    "M2",
                    "INSERT INTO без ON CONFLICT — сид не идемпотентен, upgrade→downgrade→upgrade задублирует строки. "
                    "Добавь ON CONFLICT (...) DO NOTHING / DO UPDATE.",
                )
            )
        if _DELETE.search(sql) and not _WHERE.search(sql):
            findings.append(
                Finding(
                    path,
                    line_no,
                    "M3",
                    "DELETE FROM без WHERE — снесёт все строки таблицы, включая дозалитые до этой миграции. "
                    "Ограничь WHERE по строкам именно этой миграции (WHERE code = ANY(:codes)); "
                    "если это намеренный полный replace справочника — `# migration-safety: ok full replace`.",
                )
            )
        if _UPDATE_STMT.search(sql) and not _WHERE.search(sql):
            findings.append(
                Finding(
                    path,
                    line_no,
                    "M4",
                    "UPDATE ... SET без WHERE — массовый апдейт всей таблицы. "
                    "Убедись, что это намеренно, иначе добавь WHERE.",
                )
            )
    return findings


def _check_downgrade(text: str, path: Path) -> list[Finding]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    findings: list[Finding] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "downgrade":
            body = [n for n in node.body if not isinstance(n, ast.Expr) or not _is_docstring(n)]
            is_empty = not body or all(_is_noop(n) for n in body)
            if is_empty:
                findings.append(
                    Finding(
                        path,
                        node.lineno,
                        "M5",
                        "downgrade() пустой/no-op — миграция молчаливо необратима. "
                        "Сделай реальный откат, либо raise NotImplementedError с комментарием, "
                        "либо комментарий-предупреждение о потере данных.",
                    )
                )
    return findings


def _is_docstring(node: ast.Expr) -> bool:
    return isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)


def _is_noop(node: ast.stmt) -> bool:
    if isinstance(node, ast.Pass):
        return True
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and node.value.value is Ellipsis:
        return True
    return False


def check_file(path: Path) -> list[Finding]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    findings: list[Finding] = []
    findings += _check_not_null_columns(text, lines, path)
    findings += _check_sql_verbs(text, lines, path)
    findings += _check_downgrade(text, path)
    return findings


def _is_migration_file(path: Path) -> bool:
    return path.suffix == ".py" and path.name != "__init__.py" and path.parent in MIGRATIONS_DIRS


def _targets(argv: list[str]) -> list[Path]:
    """Файлы миграций: переданные аргументами (hook) либо все файлы обеих цепочек."""
    if argv:
        return [path for path in (Path(a).resolve() for a in argv) if _is_migration_file(path)]
    return sorted(p for d in MIGRATIONS_DIRS for p in d.glob("*.py") if _is_migration_file(p))


def main(argv: list[str]) -> int:
    targets = _targets(argv)
    all_findings: list[Finding] = []
    for path in targets:
        if path.exists():
            all_findings.extend(check_file(path))

    if all_findings:
        print("Migration safety check — найдены потенциальные блокеры:\n", file=sys.stderr)
        for f in all_findings:
            print(f"  {f}", file=sys.stderr)
        print(
            "\nЕсли это осознанно и безопасно — добавь `# migration-safety: ok <причина>` на строке находки.",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
