#!/usr/bin/env bash
# Останавливает и удаляет контейнеры, образы и volume'ы локального стека — оба compose-проекта:
#   risk-profile-core  (docker-compose.yml)       — db, migrations, app, consumer, emr-consumer
#   risk-profile-infra (docker-compose.infra.yml) — kafka, kafka-init, kafka-ui, ELK, LLM gateway
# Плюс удаляет общую сеть risk-net. Использует сам docker compose, чтобы не угадывать имена.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_FILE="${SCRIPT_DIR}/../docker-compose.yml"
INFRA_FILE="${SCRIPT_DIR}/../docker-compose.infra.yml"

if ! command -v docker >/dev/null 2>&1; then
    echo "docker не установлен или недоступен в PATH" >&2
    exit 1
fi

echo "Перед удалением — ресурсы стека (core + infra):"
docker compose -f "${COMPOSE_FILE}" ps --all
docker compose -f "${INFRA_FILE}" --profile llm ps --all
echo

# down останавливает и удаляет:
#   контейнеры всех сервисов проекта,
#   --rmi all      — образы, собранные/использованные сервисами,
#   --volumes      — именованные и анонимные volume'ы (db-data, kafka-data, es-data, llm-redis-data),
#   --remove-orphans — контейнеры от удалённых из compose сервисов.
# cvd — профильный сервис core-проекта; --profile cvd охватывает и его. LLM gateway — профильные
# сервисы infra-проекта: без --profile llm down их не трогает. ps и down с профилем проходят и без
# deploy/llm-gateway/*.env — эти файлы нужны только config/up.
docker compose -f "${COMPOSE_FILE}" --profile cvd down --rmi all --volumes --remove-orphans
docker compose -f "${INFRA_FILE}" --profile llm down --rmi all --volumes --remove-orphans

# Общая сеть переживает down каждого проекта (external) — убираем явно. Не падаем, если
# её уже нет или она ещё кем-то занята.
docker network rm risk-net 2>/dev/null || true

echo
echo "Готово: контейнеры, образы, volume'ы и сеть risk-net удалены."
