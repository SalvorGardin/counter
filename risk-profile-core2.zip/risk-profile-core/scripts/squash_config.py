"""Единственный дом для констант схлопывания цепочки миграций.

Импортируется генератором baseline (scripts/make_squashed_baseline.py) как соседний
модуль и подгружается тестами через importlib — scripts/ не пакет, как и в
tests/scripts/test_check_logger_info.py.
"""

from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

# Два чейна (полная цепочка + схлопнутая) существовали на период проверки их
# эквивалентности. Полная цепочка удалена из дерева,
# сейчас одна цепочка. Чтобы вернуть проверку эквивалентности (например, при следующем
# схлопывании), восстанови полную цепочку в migrations/versions_old/ (`git log --diff-filter=D
# -- migrations/versions_old` найдёт коммит удаления) и раскомментируй строки ниже вместо
# однострочных CHAIN_DIRS/CHAIN_INI_SECTIONS:
# CHAIN_DIRS = {"old": "versions_old", "new": "versions"}
# CHAIN_INI_SECTIONS = {"old": "old", "new": "alembic"}
CHAIN_DIRS = {"new": "versions"}
CHAIN_INI_SECTIONS = {"new": "alembic"}

MIGRATIONS_DIR = REPO_ROOT / "migrations"
CATALOG_DIR = REPO_ROOT / "catalog"

# ЕДИНСТВЕННАЯ ручка. Всё ниже выводится отсюда: и порядковый префикс, и имена файлов
# baseline, и граница хвоста. Перенос отсечения — это правка одной строки плюс
# регенерация (uv run python scripts/make_squashed_baseline.py).
#
# Точка отсечения: всё до неё включительно схлопывается в один baseline-файл.
# 0095_fix_cq_020_type_to_date. Общий хвост — 0096..0110.
CUT_REVISION = "e6007cc2c395"


def chain_version_location(chain: str) -> Path:
    """Директория ревизий для цепочки. Ровно одна — две дали бы два head."""
    try:
        return MIGRATIONS_DIR / CHAIN_DIRS[chain]
    except KeyError:
        raise ValueError(f"unknown chain {chain!r}, expected one of {sorted(CHAIN_DIRS)}") from None


def chain_ini_section(chain: str) -> str:
    """Секция alembic.ini для цепочки: `alembic -n <section>` / `make migrate CHAIN=<chain>`."""
    try:
        return CHAIN_INI_SECTIONS[chain]
    except KeyError:
        raise ValueError(f"unknown chain {chain!r}, expected one of {sorted(CHAIN_INI_SECTIONS)}") from None


_NEXTVAL_RE = re.compile(r"""nextval\('(?:"?public"?\.)?"?([a-zA-Z0-9_]+)"?'::regclass\)""")


def surrogate_sequence(server_default: str | None) -> str | None:
    """Имя последовательности из server_default вида nextval('public.foo_seq'::regclass)."""
    if server_default is None:
        return None
    match = _NEXTVAL_RE.search(server_default)
    return match.group(1) if match else None


def is_surrogate_pk(*, name: str, pk_names: frozenset[str], server_default: str | None, identity: bool) -> bool:
    """Суррогатный ключ — одноколоночный PK, значение которому выдаёт БД (serial/identity).

    Один дом на два вызова: генератор baseline не выгружает такие колонки, а компаратор
    (tests/migrations/snapshot.py) их не сравнивает. Разъехавшиеся копии предиката молчат
    ровно в одну сторону: если компаратор считает колонку суррогатной, а генератор — нет,
    то расхождение значений просто никто не увидит.

    Именно предикат, а не список имён: PK здесь называются parameter_id, doctor_id,
    instrument_id, а вовсе не id, и захардкоженное "id" молча не исключило бы ничего.
    Составные PK (recommendations, risk_factors) и строковый patients.patient_id — это
    бизнес-ключи: они совпадают у обеих цепочек и обязаны сравниваться.

    Ещё одна причина не вставлять такие значения: вставка явного значения не двигает
    последовательность, и первая же вставка в хвосте (0107/0108 идут через ON CONFLICT)
    упала бы на duplicate key.
    """
    if name not in pk_names or len(pk_names) != 1:
        return False
    return identity or surrogate_sequence(server_default) is not None


def cut_revision_file() -> Path:
    """Файл старой цепочки, на котором стоит отсечение.

    Ищется по revision id в имени, а не по номеру: так CUT_REVISION остаётся единственным
    местом правки, а опечатка в нём падает здесь с внятным сообщением, а не превращается
    в пустой хвост и «успешную» генерацию не того состояния.

    Работает только если цепочка "old" восстановлена в CHAIN_DIRS (см. комментарий там) —
    сейчас старой цепочки в дереве нет, вызов упадёт на chain_version_location("old").
    """
    matches = sorted(chain_version_location("old").glob(f"*_{CUT_REVISION}.py"))
    if len(matches) != 1:
        raise ValueError(f"ожидали ровно один файл ревизии {CUT_REVISION} в старой цепочке, нашли {matches}")
    return matches[0]


# Порядковый префикс отсечения. Раньше выводился из имени файла старой цепочки (см.
# cut_revision_file) — старой цепочки в дереве больше нет, поэтому хардкод. Значение
# зафиксировано на момент последнего схлопывания: 0095_fix_cq_020_type_to_date.
CUT_PREFIX = "0095"

# baseline переиспользует revision id старой миграции отсечения. Тогда следующей за ней
# не нужно править down_revision, файлы хвоста копируются байт-в-байт, а alembic_version
# совпадает у обеих цепочек в любой позиции — и потому сравнивается, а не исключается.
BASELINE_REVISION = CUT_REVISION
BASELINE_FILENAME = f"{CUT_PREFIX}_squashed_baseline_{CUT_REVISION}.py"
BASELINE_DATA_FILENAME = f"{CUT_PREFIX}_{CUT_REVISION}_baseline.json"


def tail_revision_files() -> list[Path]:
    """Файлы общего хвоста (строго после отсечения) в старой цепочке, по префиксу."""
    old = chain_version_location("old")
    return sorted(p for p in old.glob("0[0-9][0-9][0-9]_*.py") if p.name[:4] > CUT_PREFIX)
