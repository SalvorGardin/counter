#!/usr/bin/env bash
# Идемпотентная установка user-cron для scripts/prune_docker_build_cache.sh.
set -euo pipefail

readonly MARKER="# risk-profile-build-cache-prune"
readonly SCHEDULE="${DOCKER_BUILD_CACHE_PRUNE_SCHEDULE:-17 3 * * *}"
readonly RESERVED_SPACE="${DOCKER_BUILD_CACHE_RESERVED_SPACE:-1gb}"
readonly MAX_USED_SPACE="${DOCKER_BUILD_CACHE_MAX_USED_SPACE:-5gb}"
readonly MIN_FREE_SPACE="${DOCKER_BUILD_CACHE_MIN_FREE_SPACE:-10gb}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PRUNE_SCRIPT="${SCRIPT_DIR}/prune_docker_build_cache.sh"
readonly STATE_DIR="${DOCKER_BUILD_CACHE_PRUNE_STATE_DIR:-${HOME:?HOME is required}/.local/state/risk-profile}"
readonly LOG_FILE="${DOCKER_BUILD_CACHE_PRUNE_LOG_FILE:-${STATE_DIR}/build-cache-prune.log}"

action="install"
if [[ "${1:-}" == "--remove" ]]; then
    action="remove"
    shift
fi
if [[ "$#" -ne 0 ]]; then
    echo "Usage: $0 [--remove]" >&2
    exit 1
fi

if ! command -v crontab >/dev/null 2>&1; then
    echo "Error: crontab not found; install/enable cron on the host first." >&2
    exit 1
fi

tmp_file=$(mktemp)
trap 'rm -f "${tmp_file}"' EXIT
(crontab -l 2>/dev/null || true) | grep -vF "${MARKER}" >"${tmp_file}" || true

if [[ "${action}" == "remove" ]]; then
    crontab "${tmp_file}"
    echo "Docker build cache prune cron removed."
    exit 0
fi

if [[ ! -x "${PRUNE_SCRIPT}" ]]; then
    echo "Error: prune script is not executable: ${PRUNE_SCRIPT}" >&2
    exit 1
fi

docker_bin=$(command -v docker || true)
flock_bin=$(command -v flock || true)
bash_bin=$(command -v bash || true)
if [[ -z "${docker_bin}" || -z "${flock_bin}" || -z "${bash_bin}" ]]; then
    echo "Error: docker, flock and bash must be available in PATH." >&2
    exit 1
fi

validate_size() {
    local name="$1" value="$2"
    if [[ ! "${value}" =~ ^[0-9]+([kmgtpeKMGTPE][iI]?[bB]?)?$ ]]; then
        echo "Error: ${name} must be a Docker size such as 1gb or 512mb." >&2
        exit 1
    fi
}

validate_size "DOCKER_BUILD_CACHE_RESERVED_SPACE" "${RESERVED_SPACE}"
validate_size "DOCKER_BUILD_CACHE_MAX_USED_SPACE" "${MAX_USED_SPACE}"
validate_size "DOCKER_BUILD_CACHE_MIN_FREE_SPACE" "${MIN_FREE_SPACE}"

read -r -a schedule_fields <<<"${SCHEDULE}"
if [[ "${#schedule_fields[@]}" -ne 5 ]]; then
    echo "Error: DOCKER_BUILD_CACHE_PRUNE_SCHEDULE must contain five cron fields." >&2
    exit 1
fi
for field in "${schedule_fields[@]}"; do
    if [[ ! "${field}" =~ ^[0-9*/,-]+$ ]]; then
        echo "Error: unsupported character in cron schedule field: ${field}" >&2
        exit 1
    fi
done

mkdir -p "${STATE_DIR}"

cron_format='%s DOCKER_BIN=%q FLOCK_BIN=%q DOCKER_BUILD_CACHE_RESERVED_SPACE=%q '
cron_format+='DOCKER_BUILD_CACHE_MAX_USED_SPACE=%q DOCKER_BUILD_CACHE_MIN_FREE_SPACE=%q '
cron_format+='%q %q >> %q 2>&1 %s'
printf -v cron_line \
    "${cron_format}" \
    "${SCHEDULE}" \
    "${docker_bin}" \
    "${flock_bin}" \
    "${RESERVED_SPACE}" \
    "${MAX_USED_SPACE}" \
    "${MIN_FREE_SPACE}" \
    "${bash_bin}" \
    "${PRUNE_SCRIPT}" \
    "${LOG_FILE}" \
    "${MARKER}"

printf '%s\n' "${cron_line}" >>"${tmp_file}"
crontab "${tmp_file}"

echo "Docker build cache prune cron installed:"
echo "  schedule: ${SCHEDULE}"
echo "  cache: reserved=${RESERVED_SPACE}, max-used=${MAX_USED_SPACE}, min-free=${MIN_FREE_SPACE}"
echo "  log: ${LOG_FILE}"
