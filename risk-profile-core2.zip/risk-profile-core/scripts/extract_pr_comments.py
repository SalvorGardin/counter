#!/usr/bin/env python3
"""Extract all MR comments targeting the develop branch into per-MR text files."""

import json
import subprocess
import sys
from pathlib import Path

GITLAB_HOST = "gitlab.tywys.ru"
PROJECT_PATH = "risk-profile/risk-profile-core"
TARGET_BRANCH = "develop"
OUTPUT_DIR = Path("pr_comments")


def glab_api(endpoint: str) -> list | dict:
    result = subprocess.run(
        ["glab", "api", endpoint, "--hostname", GITLAB_HOST],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"[ERROR] glab api {endpoint}: {result.stderr.strip()}", file=sys.stderr)
        sys.exit(1)
    return json.loads(result.stdout)


def get_mrs() -> list[dict]:
    project_id = PROJECT_PATH.replace("/", "%2F")
    mrs = []
    page = 1
    while True:
        batch = glab_api(
            f"projects/{project_id}/merge_requests?target_branch={TARGET_BRANCH}&state=all&per_page=100&page={page}"
        )
        if not batch:
            break
        mrs.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    return mrs


def get_notes(mr_iid: int) -> list[dict]:
    project_id = PROJECT_PATH.replace("/", "%2F")
    notes = []
    page = 1
    while True:
        batch = glab_api(f"projects/{project_id}/merge_requests/{mr_iid}/notes?per_page=100&page={page}")
        if not batch:
            break
        notes.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    return notes


def get_discussions(mr_iid: int) -> list[dict]:
    project_id = PROJECT_PATH.replace("/", "%2F")
    discussions = []
    page = 1
    while True:
        batch = glab_api(f"projects/{project_id}/merge_requests/{mr_iid}/discussions?per_page=100&page={page}")
        if not batch:
            break
        discussions.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    return discussions


def format_mr_comments(mr: dict, discussions: list[dict]) -> str:
    lines = []
    sep = "=" * 80

    lines.append(sep)
    lines.append(f"MR !{mr['iid']}  {mr['title']}")
    lines.append(f"Author : {mr['author']['name']} (@{mr['author']['username']})")
    lines.append(f"State  : {mr['state']}")
    lines.append(f"Source : {mr['source_branch']} -> {mr['target_branch']}")
    lines.append(f"URL    : {mr['web_url']}")
    lines.append(sep)
    lines.append("")

    inline_discussions = [d for d in discussions if any(n.get("position") for n in d["notes"])]
    general_discussions = [d for d in discussions if not any(n.get("position") for n in d["notes"])]

    # -- Inline (diff) comments --
    if inline_discussions:
        lines.append("-" * 60)
        lines.append("INLINE COMMENTS (diff threads)")
        lines.append("-" * 60)
        lines.append("")

        for disc in inline_discussions:
            first = disc["notes"][0]
            pos = first.get("position") or {}
            new_path = pos.get("new_path") or pos.get("old_path") or "unknown file"
            new_line = pos.get("new_line") or pos.get("old_line") or "?"
            lines.append(f"  File : {new_path}:{new_line}")
            lines.append(f"  Thread ID: {disc['id']}")
            lines.append("")

            for note in disc["notes"]:
                author = note["author"]["name"]
                username = note["author"]["username"]
                created = note["created_at"][:19].replace("T", " ")
                resolved = ""
                if note.get("resolvable"):
                    resolved = "  [RESOLVED]" if note.get("resolved") else "  [OPEN]"
                system = "  [system]" if note.get("system") else ""
                lines.append(f"    [{created}] {author} (@{username}){resolved}{system}")
                body = note["body"].replace("\n", "\n    ")
                lines.append(f"    {body}")
                lines.append("")

            lines.append("")

    # -- General / MR-level comments --
    if general_discussions:
        lines.append("-" * 60)
        lines.append("GENERAL COMMENTS (MR-level)")
        lines.append("-" * 60)
        lines.append("")

        for disc in general_discussions:
            for note in disc["notes"]:
                if note.get("system"):
                    continue  # skip bot/system events
                author = note["author"]["name"]
                username = note["author"]["username"]
                created = note["created_at"][:19].replace("T", " ")
                lines.append(f"  [{created}] {author} (@{username})")
                body = note["body"].replace("\n", "\n  ")
                lines.append(f"  {body}")
                lines.append("")

    return "\n".join(lines)


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)

    print(f"Fetching MRs targeting '{TARGET_BRANCH}' from {PROJECT_PATH}...")
    mrs = get_mrs()
    print(f"Found {len(mrs)} MRs.")

    for mr in mrs:
        iid = mr["iid"]
        print(f"  !{iid} {mr['title'][:60]}")

        discussions = get_discussions(iid)
        content = format_mr_comments(mr, discussions)

        out_path = OUTPUT_DIR / f"{iid}_pr_comments.txt"
        out_path.write_text(content, encoding="utf-8")

    print(f"\nDone. Files written to {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
