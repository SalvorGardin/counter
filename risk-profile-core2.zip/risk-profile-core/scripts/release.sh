#!/usr/bin/env bash
#
# Релиз одного или нескольких сервисов по пайплайну GitLab (origin) -> GitVerse (gitverse):
#   синхронизируем develop из GitLab, поднимаем версию, ЛОКАЛЬНО мёржим develop -> release и
#   пушим уже готовый merge-коммит (PR/merge на GitVerse НЕ создаём — публичный REST GitVerse
#   не отдаёт merge-action: POST .../pulls/{n}/merge заворачивается шлюзом в голый 400 ""),
#   тегируем релиз, атомарно пушим develop/release/tag в GitLab (канонический таргет релиза),
#   атомарно пушим develop/release в GitVerse и создаём там тег с release-notes через Release API.
#   После публикации сверяем develop/release/tag на обоих хостах с локальными коммитами.
#
# Список сервисов задаётся в SERVICES ниже (соседние директории под общим родителем).
#
# Использование:
#   ./scripts/release.sh [services...] [--major|--minor|--patch] [--tag vX.Y.Z]
#                        --notes <service>=<file> [--notes <service>=<file> ...] [-h|--help]
#
#   services...           релизить только указанные (валидируются по SERVICES); без имён — все.
#   --major|--minor|--patch  какую часть версии поднять. По умолчанию --minor. Взаимоисключающие.
#   --tag vX.Y.Z          явный тег для ВСЕХ выбранных сервисов; перекрывает флаги бампа.
#   --notes <svc>=<file>  файл release-notes для сервиса (повторяемый, по одному на сервис).
#                         <file> ищется в ./release-notes/ КАЖДОГО сервиса; обязателен для всех
#                         выбранных сервисов — его содержимое станет телом релиза на GitVerse.
#
# Версия считается per-service из СОБСТВЕННОГО последнего git-тега v*.*.*.
# Только --tag форсит одинаковую версию для всех сервисов.
#
# Требуется env GITVERSE_TOKEN (Bearer-токен GitVerse). Для удобства, если переменная не
# задана, но в корне сервиса есть .env с GITVERSE_TOKEN — подхватим её оттуда.

set -uo pipefail

# ── конфиг сервисов ──────────────────────────────────────────────────────────

SERVICES=( "risk-model" "risk-profile-cvd" )

# ── константы API GitVerse ───────────────────────────────────────────────────

GITVERSE_API="https://api.gitverse.ru"
ACCEPT_HEADER="Accept: application/vnd.gitverse.object+json;version=1"

ORIGIN_REMOTE="origin"     # GitLab — канонический таргет релиза
GITVERSE_REMOTE="gitverse" # GitVerse — несёт ветку release и Release API (без PR/merge)
DEVELOP_BRANCH="develop"
RELEASE_BRANCH="release"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)" # родитель репозитория = общий каталог сервисов

# ── разбор аргументов ────────────────────────────────────────────────────────

BUMP_PART="minor"
EXPLICIT_TAG=""
REQUESTED_SERVICES=()
BUMP_FLAG_SEEN=""
declare -A NOTES_MAP=()

usage() {
    # печатаем шапку-комментарий (со строки 3 до первой не-комментарной строки)
    awk 'NR>=3 { if ($0 !~ /^#/) exit; sub(/^# ?/, ""); print }' "${BASH_SOURCE[0]}"
}

die() {
    echo "Error: $*" >&2
    exit 1
}

parse_notes_arg() {
    # принимает "<service>=<file>", кладёт в NOTES_MAP[service]=file
    local arg="$1" svc file
    [[ "${arg}" == *=* ]] || die "--notes ожидает <service>=<file>, получено: ${arg}"
    svc="${arg%%=*}"
    file="${arg#*=}"
    [[ -n "${svc}" && -n "${file}" ]] || die "--notes ожидает <service>=<file>, получено: ${arg}"
    # только имя файла: каталог release-notes/ зашит в скрипте, обхода пути в аргументах не допускаем
    [[ "${file}" != */* && "${file}" != *..* ]] \
        || die "--notes принимает только имя файла без пути (без '/' и '..'): ${file}"
    NOTES_MAP["${svc}"]="${file}"
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --major|--minor|--patch)
            part="${1#--}"
            if [[ -n "${BUMP_FLAG_SEEN}" && "${BUMP_FLAG_SEEN}" != "${part}" ]]; then
                die "--major/--minor/--patch взаимоисключающие (уже задан --${BUMP_FLAG_SEEN})"
            fi
            BUMP_PART="${part}"
            BUMP_FLAG_SEEN="${part}"
            ;;
        --tag)
            shift || true
            [[ $# -gt 0 ]] || die "--tag требует аргумент vX.Y.Z"
            EXPLICIT_TAG="$1"
            ;;
        --tag=*)
            EXPLICIT_TAG="${1#--tag=}"
            ;;
        --notes)
            shift || true
            [[ $# -gt 0 ]] || die "--notes требует аргумент <service>=<file>"
            parse_notes_arg "$1"
            ;;
        --notes=*)
            parse_notes_arg "${1#--notes=}"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        --*)
            die "Неизвестный флаг: $1"
            ;;
        *)
            REQUESTED_SERVICES+=( "$1" )
            ;;
    esac
    shift
done

if [[ -n "${EXPLICIT_TAG}" ]]; then
    [[ "${EXPLICIT_TAG}" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] \
        || die "--tag должен соответствовать v<major>.<minor>.<patch>, получено: ${EXPLICIT_TAG}"
fi

# Валидируем запрошенные имена сервисов против SERVICES; без имён — все.
SELECTED_SERVICES=()
if [[ ${#REQUESTED_SERVICES[@]} -eq 0 ]]; then
    SELECTED_SERVICES=( "${SERVICES[@]}" )
else
    for req in "${REQUESTED_SERVICES[@]}"; do
        found=""
        for known in "${SERVICES[@]}"; do
            [[ "${req}" == "${known}" ]] && found="yes" && break
        done
        [[ -n "${found}" ]] || die "Неизвестный сервис '${req}'. Доступны: ${SERVICES[*]}"
        SELECTED_SERVICES+=( "${req}" )
    done
fi

# Каждая запись --notes должна ссылаться на ВЫБРАННЫЙ сервис.
for svc in "${!NOTES_MAP[@]}"; do
    in_selected=""
    for sel in "${SELECTED_SERVICES[@]}"; do
        [[ "${svc}" == "${sel}" ]] && in_selected="yes" && break
    done
    [[ -n "${in_selected}" ]] || die "--notes ссылается на невыбранный сервис '${svc}'"
done

# Каждый выбранный сервис обязан иметь --notes с существующим файлом в ./release-notes/.
for svc in "${SELECTED_SERVICES[@]}"; do
    notes_file="${NOTES_MAP[${svc}]:-}"
    [[ -n "${notes_file}" ]] || die "для сервиса '${svc}' не задан --notes <service>=<file> (release-notes обязательны)"
    notes_path="${PARENT_DIR}/${svc}/release-notes/${notes_file}"
    [[ -f "${notes_path}" ]] || die "файл release-notes не найден: ${notes_path}"
done

# ── preflight ────────────────────────────────────────────────────────────────

for tool in git curl jq; do
    command -v "${tool}" >/dev/null 2>&1 || die "не найден '${tool}' в PATH"
done

# GITVERSE_TOKEN резолвится per-service внутри release_service: окружение имеет приоритет,
# иначе берётся из .env КОНКРЕТНОГО сервиса (${svc_dir}/.env), а не из CWD процесса —
# скрипт можно запускать из любого каталога, и у каждого сервиса свой токен.

# ── HTTP-хелперы (заполняют HTTP_CODE / HTTP_BODY) ───────────────────────────

http_request() {
    local method="$1" url="$2" data="${3:-}"
    local raw
    if [[ -n "${data}" ]]; then
        raw="$(curl -sS -w $'\n%{http_code}' -X "${method}" \
            -H "Authorization: Bearer ${GITVERSE_TOKEN}" \
            -H "${ACCEPT_HEADER}" \
            -H "Content-Type: application/json" \
            -d "${data}" "${url}")"
    else
        raw="$(curl -sS -w $'\n%{http_code}' -X "${method}" \
            -H "Authorization: Bearer ${GITVERSE_TOKEN}" \
            -H "${ACCEPT_HEADER}" \
            "${url}")"
    fi
    HTTP_CODE="${raw##*$'\n'}"
    HTTP_BODY="${raw%$'\n'*}"

    # 401 = токен отклонён шлюзом (SOWA). Это не лечится повтором и одинаково для всех
    # сервисов — нет смысла продолжать прогон, валимся сразу с понятным сообщением.
    if [[ "${HTTP_CODE}" == "401" ]]; then
        die "GITVERSE_TOKEN отклонён (HTTP 401) на ${method} ${url} — токен невалиден/просрочен/отозван. Обновите GITVERSE_TOKEN в .env."
    fi
}

http_ok() {
    [[ "${HTTP_CODE}" =~ ^2[0-9][0-9]$ ]]
}

# ── сверка git refs ──────────────────────────────────────────────────────────

ref_sha_from_listing() {
    local listing="$1" ref="$2"
    awk -v wanted="${ref}" '$2 == wanted { print $1; exit }' <<< "${listing}"
}

tag_commit_sha_from_listing() {
    local listing="$1" tag="$2"
    local ref="refs/tags/${tag}" peeled direct
    peeled="$(ref_sha_from_listing "${listing}" "${ref}^{}")"
    direct="$(ref_sha_from_listing "${listing}" "${ref}")"
    printf '%s' "${peeled:-${direct}}"
}

remote_refs_listing() {
    local remote="$1" tag="$2"
    git ls-remote "${remote}" \
        "refs/heads/${DEVELOP_BRANCH}" \
        "refs/heads/${RELEASE_BRANCH}" \
        "refs/tags/${tag}" \
        "refs/tags/${tag}^{}"
}

verify_remote_heads_unchanged() {
    local remote="$1" expected_develop="$2" expected_release="$3" tag="$4"
    local listing actual_develop actual_release actual_tag
    listing="$(remote_refs_listing "${remote}" "${tag}")" || return 1
    actual_develop="$(ref_sha_from_listing "${listing}" "refs/heads/${DEVELOP_BRANCH}")"
    actual_release="$(ref_sha_from_listing "${listing}" "refs/heads/${RELEASE_BRANCH}")"
    actual_tag="$(tag_commit_sha_from_listing "${listing}" "${tag}")"

    if [[ "${actual_develop}" != "${expected_develop}" || "${actual_release}" != "${expected_release}" ]]; then
        echo "  ${remote}: ветки изменились во время подготовки релиза" >&2
        echo "    ${DEVELOP_BRANCH}: ожидался ${expected_develop}, получен ${actual_develop:-<нет>}" >&2
        echo "    ${RELEASE_BRANCH}: ожидался ${expected_release}, получен ${actual_release:-<нет>}" >&2
        return 1
    fi
    if [[ -n "${actual_tag}" ]]; then
        echo "  ${remote}: тег ${tag} уже существует и указывает на ${actual_tag}; релиз остановлен" >&2
        return 1
    fi
}

verify_published_refs() {
    local remote="$1" expected_develop="$2" expected_release="$3" tag="$4"
    local listing actual_develop actual_release actual_tag
    listing="$(remote_refs_listing "${remote}" "${tag}")" || return 1
    actual_develop="$(ref_sha_from_listing "${listing}" "refs/heads/${DEVELOP_BRANCH}")"
    actual_release="$(ref_sha_from_listing "${listing}" "refs/heads/${RELEASE_BRANCH}")"
    actual_tag="$(tag_commit_sha_from_listing "${listing}" "${tag}")"

    if [[ "${actual_develop}" != "${expected_develop}" \
        || "${actual_release}" != "${expected_release}" \
        || "${actual_tag}" != "${expected_release}" ]]; then
        echo "  ${remote}: итоговая сверка refs не прошла" >&2
        echo "    ${DEVELOP_BRANCH}: ожидался ${expected_develop}, получен ${actual_develop:-<нет>}" >&2
        echo "    ${RELEASE_BRANCH}: ожидался ${expected_release}, получен ${actual_release:-<нет>}" >&2
        echo "    ${tag}: ожидался ${expected_release}, получен ${actual_tag:-<нет>}" >&2
        return 1
    fi
}

# ── разбор owner/repo из remote gitverse ─────────────────────────────────────

gitverse_owner_repo() {
    local url
    url="$(git remote get-url "${GITVERSE_REMOTE}")" || return 1
    # git@host:owner/repo.git | https://host/owner/repo.git -> owner/repo
    url="${url%.git}"
    if [[ "${url}" == *@*:* ]]; then
        printf '%s' "${url#*:}"
    else
        # отрезаем схему и хост: всё после третьего слэша
        printf '%s' "${url}" | sed -E 's#^[a-z]+://[^/]+/##'
    fi
}

# ── версия ───────────────────────────────────────────────────────────────────

compute_next_version() {
    # echo'ит тег vX.Y.Z в stdout; читает последний git-тег v*.*.*.
    local latest major minor patch
    latest="$(git tag --list 'v*' --sort=-v:refname | head -n1)"
    if [[ "${latest}" =~ ^v([0-9]+)\.([0-9]+)\.([0-9]+)$ ]]; then
        major="${BASH_REMATCH[1]}"; minor="${BASH_REMATCH[2]}"; patch="${BASH_REMATCH[3]}"
    else
        major=0; minor=0; patch=0
    fi
    case "${BUMP_PART}" in
        major) major=$((major + 1)); minor=0; patch=0 ;;
        minor) minor=$((minor + 1)); patch=0 ;;
        patch) patch=$((patch + 1)) ;;
    esac
    printf 'v%s.%s.%s' "${major}" "${minor}" "${patch}"
}

# ── релиз одного сервиса ─────────────────────────────────────────────────────

release_service() {
    local svc="$1"
    local svc_dir="${PARENT_DIR}/${svc}"

    [[ -d "${svc_dir}/.git" || -d "${svc_dir}" ]] || { echo "  каталог сервиса не найден: ${svc_dir}" >&2; return 1; }
    cd "${svc_dir}" || { echo "  не удалось перейти в ${svc_dir}" >&2; return 1; }

    git rev-parse --git-dir >/dev/null 2>&1 || { echo "  не git-репозиторий: ${svc_dir}" >&2; return 1; }

    local start_ref
    start_ref="$(git symbolic-ref --quiet --short HEAD || git rev-parse HEAD)"
    # восстановление исходной ветки — best-effort при выходе из функции
    restore_branch() { git checkout --quiet "${start_ref}" 2>/dev/null || true; }

    # Токен GitVerse: окружение имеет приоритет, иначе из .env ЭТОГО сервиса (по абсолютному
    # пути svc_dir, не из CWD). local динамически перекрывает глобальный GITVERSE_TOKEN для
    # вызываемого отсюда http_request, и не протекает между сервисами.
    local GITVERSE_TOKEN="${GITVERSE_TOKEN:-}"
    if [[ -z "${GITVERSE_TOKEN}" && -f "${svc_dir}/.env" ]]; then
        local token_line
        token_line="$(grep -E '^GITVERSE_TOKEN=' "${svc_dir}/.env" | head -1 || true)"
        [[ -n "${token_line}" ]] && GITVERSE_TOKEN="$(printf '%s' "${token_line#GITVERSE_TOKEN=}" | tr -d "\"'")"
    fi
    [[ -n "${GITVERSE_TOKEN}" ]] \
        || { echo "  GITVERSE_TOKEN не задан (env или ${svc_dir}/.env)" >&2; restore_branch; return 1; }

    # читаем файл release-notes (валидирован на старте) для тела релиза на GitVerse
    local notes_path
    notes_path="${svc_dir}/release-notes/${NOTES_MAP[${svc}]:-}"
    [[ -f "${notes_path}" ]] || { echo "  файл release-notes не найден: ${notes_path}" >&2; restore_branch; return 1; }

    # 1. Sync develop и remote-tracking refs обоих хостов. Теги GitVerse намеренно не fetch'им:
    #    Release API обычно создаёт lightweight-тег, а в GitLab тот же тег annotated; git fetch
    #    отказался бы заменять локальный объект сообщением "would clobber existing tag", хотя
    #    commit совпадает.
    echo "  [1/8] fetch обоих remotes + синхронизация ${DEVELOP_BRANCH}"
    git fetch "${ORIGIN_REMOTE}" --prune --tags \
        || { echo "  git fetch ${ORIGIN_REMOTE} упал" >&2; restore_branch; return 1; }
    git fetch "${GITVERSE_REMOTE}" --prune --no-tags \
        || { echo "  git fetch ${GITVERSE_REMOTE} упал" >&2; restore_branch; return 1; }
    if [[ -n "$(git status --porcelain)" ]]; then
        echo "  рабочее дерево не чистое — пропускаем сервис" >&2
        restore_branch; return 1
    fi
    git checkout --quiet "${DEVELOP_BRANCH}" || { echo "  нет ветки ${DEVELOP_BRANCH}" >&2; restore_branch; return 1; }
    git merge --ff-only "${ORIGIN_REMOTE}/${DEVELOP_BRANCH}" \
        || { echo "  ${DEVELOP_BRANCH} не fast-forward к ${ORIGIN_REMOTE}/${DEVELOP_BRANCH}" >&2; restore_branch; return 1; }

    local origin_develop_before origin_release_before gitverse_develop_before gitverse_release_before
    origin_develop_before="$(git rev-parse "${ORIGIN_REMOTE}/${DEVELOP_BRANCH}")" \
        || { echo "  нет ветки ${ORIGIN_REMOTE}/${DEVELOP_BRANCH}" >&2; restore_branch; return 1; }
    origin_release_before="$(git rev-parse "${ORIGIN_REMOTE}/${RELEASE_BRANCH}")" \
        || { echo "  нет ветки ${ORIGIN_REMOTE}/${RELEASE_BRANCH}" >&2; restore_branch; return 1; }
    gitverse_develop_before="$(git rev-parse "${GITVERSE_REMOTE}/${DEVELOP_BRANCH}")" \
        || { echo "  нет ветки ${GITVERSE_REMOTE}/${DEVELOP_BRANCH}" >&2; restore_branch; return 1; }
    gitverse_release_before="$(git rev-parse "${GITVERSE_REMOTE}/${RELEASE_BRANCH}")" \
        || { echo "  нет ветки ${GITVERSE_REMOTE}/${RELEASE_BRANCH}" >&2; restore_branch; return 1; }

    if [[ "${origin_release_before}" != "${gitverse_release_before}" ]]; then
        echo "  release расходится между ${ORIGIN_REMOTE} и ${GITVERSE_REMOTE}; автоматический релиз остановлен" >&2
        restore_branch; return 1
    fi
    if ! git merge-base --is-ancestor "${gitverse_develop_before}" "${origin_develop_before}"; then
        echo "  ${GITVERSE_REMOTE}/${DEVELOP_BRANCH} не является предком ${ORIGIN_REMOTE}/${DEVELOP_BRANCH}" >&2
        restore_branch; return 1
    fi

    # 2. Версия
    local tag version_no_v
    if [[ -n "${EXPLICIT_TAG}" ]]; then
        tag="${EXPLICIT_TAG}"
    else
        tag="$(compute_next_version)"
    fi
    version_no_v="${tag#v}"
    # публикуем версию наружу (глобал, не local) — основной цикл кладёт её в итоговую таблицу
    RELEASED_TAG="${tag}"
    echo "  [2/8] следующая версия: ${tag}"

    # 3. Бамп version.json (+ pyproject.toml/uv.lock) + commit develop ЛОКАЛЬНО (без push).
    #    Все push'и отложены до шага 7 — после удачного локального merge в release. Иначе
    #    при merge-конфликте develop уже уехал бы с bump-коммитом в оба ремоута, а release нет
    #    (частичное состояние). Так до первого push'а конфликт ловится без следов в ремоутах.
    echo "  [3/8] обновляем version.json/pyproject.toml/uv.lock и коммитим ${DEVELOP_BRANCH} (локально)"
    [[ -f version.json ]] || { echo "  version.json не найден" >&2; restore_branch; return 1; }
    local tmp_json
    tmp_json="$(mktemp)"
    local release_date
    release_date="$(date +%F)"
    jq --arg v "${version_no_v}" --arg created_at "${release_date}" \
        '.version = $v | .created_at = $created_at' version.json > "${tmp_json}" \
        || { echo "  jq не смог обновить version.json" >&2; rm -f "${tmp_json}"; restore_branch; return 1; }
    mv "${tmp_json}" version.json

    # pyproject.toml: правим только верхнеуровневый project version (первый '^version = "..."'),
    # не трогая возможные version в зависимостях. Файл опционален — сервис может его не иметь.
    if [[ -f pyproject.toml ]]; then
        local tmp_toml
        tmp_toml="$(mktemp)"
        sed -E "0,/^version = \"[^\"]*\"/ s//version = \"${version_no_v}\"/" pyproject.toml > "${tmp_toml}" \
            || { echo "  sed не смог обновить pyproject.toml" >&2; rm -f "${tmp_toml}"; restore_branch; return 1; }
        if ! grep -qE "^version = \"${version_no_v}\"" "${tmp_toml}"; then
            echo "  не нашёл строку 'version = \"...\"' в pyproject.toml" >&2; rm -f "${tmp_toml}"; restore_branch; return 1
        fi
        mv "${tmp_toml}" pyproject.toml
    else
        echo "  pyproject.toml не найден — пропускаем"
    fi

    # uv.lock хранит версию корневого editable-пакета. Обновляем его тем же инструментом,
    # которым управляется проект; offline не обращается к registry во время релиза.
    if [[ -f uv.lock ]]; then
        command -v uv >/dev/null 2>&1 \
            || { echo "  найден uv.lock, но не найден uv" >&2; restore_branch; return 1; }
        uv lock --offline \
            || { echo "  uv не смог обновить uv.lock" >&2; restore_branch; return 1; }
    fi

    if [[ -n "$(git status --porcelain version.json pyproject.toml uv.lock)" ]]; then
        git add version.json
        [[ -f pyproject.toml ]] && git add pyproject.toml
        [[ -f uv.lock ]] && git add uv.lock
        git commit --quiet -m "chore(release): bump version to ${version_no_v}" \
            || { echo "  commit бампа упал" >&2; restore_branch; return 1; }
    else
        echo "  версия уже = ${version_no_v}, коммит не нужен"
    fi

    # owner/repo для API
    local owner_repo
    owner_repo="$(gitverse_owner_repo)" || { echo "  не удалось разобрать owner/repo из remote ${GITVERSE_REMOTE}" >&2; restore_branch; return 1; }

    # 4. Локальный merge develop -> release. PR/merge на GitVerse НЕ используем: публичный
    #    REST GitVerse не отдаёт merge-action (POST .../pulls/{n}/merge заворачивается шлюзом
    #    SOWA в голый 400 ""). Базируемся на origin/release (канонический таргет релиза).
    echo "  [4/8] локальный merge ${DEVELOP_BRANCH} -> ${RELEASE_BRANCH}"
    git rev-parse -q --verify "${ORIGIN_REMOTE}/${RELEASE_BRANCH}" >/dev/null \
        || { echo "  нет ветки ${ORIGIN_REMOTE}/${RELEASE_BRANCH}" >&2; restore_branch; return 1; }
    git checkout -B "${RELEASE_BRANCH}" "${ORIGIN_REMOTE}/${RELEASE_BRANCH}" \
        || { echo "  не удалось создать локальный ${RELEASE_BRANCH} из ${ORIGIN_REMOTE}/${RELEASE_BRANCH}" >&2; restore_branch; return 1; }
    if ! git merge --no-ff -m "Release ${version_no_v}" "${DEVELOP_BRANCH}"; then
        git merge --abort 2>/dev/null || true
        echo "  merge-конфликт ${DEVELOP_BRANCH} -> ${RELEASE_BRANCH} — разрешите вручную" >&2
        restore_branch; return 1
    fi

    # merge-коммит = HEAD release после мёржа; тег и релиз на GitVerse привязываем к нему,
    # чтобы тег в обоих ремоутах указывал на ОДИН и тот же коммит.
    local merge_sha
    merge_sha="$(git rev-parse HEAD)" || { echo "  не удалось получить SHA merge-коммита" >&2; restore_branch; return 1; }

    # 5. Тег merge-коммита
    echo "  [5/8] тегируем merge-коммит ${RELEASE_BRANCH} как ${tag}"
    if git rev-parse -q --verify "refs/tags/${tag}" >/dev/null; then
        local existing_sha
        existing_sha="$(git rev-parse "refs/tags/${tag}^{commit}")"
        if [[ "${existing_sha}" != "${merge_sha}" ]]; then
            echo "  тег ${tag} уже существует, но указывает на ${existing_sha}, а merge-коммит ${merge_sha}" >&2
            restore_branch; return 1
        fi
        echo "        тег ${tag} уже на merge-коммите — переиспользуем"
    else
        git tag -a "${tag}" -m "Release ${version_no_v}" "${merge_sha}" \
            || { echo "  не удалось создать тег ${tag}" >&2; restore_branch; return 1; }
    fi

    # 6. Перед первой внешней записью убеждаемся, что refs не изменились после fetch. Затем
    #    пушим один атомарный набор на хост: GitLab получает develop/release/annotated tag,
    #    GitVerse — develop/release; tag там создаст Release API на следующем шаге.
    echo "  [6/8] проверяем, что remote refs не изменились"
    verify_remote_heads_unchanged \
        "${ORIGIN_REMOTE}" "${origin_develop_before}" "${origin_release_before}" "${tag}" \
        || { restore_branch; return 1; }
    verify_remote_heads_unchanged \
        "${GITVERSE_REMOTE}" "${gitverse_develop_before}" "${gitverse_release_before}" "${tag}" \
        || { restore_branch; return 1; }

    local develop_sha
    develop_sha="$(git rev-parse "${DEVELOP_BRANCH}")" \
        || { echo "  не удалось получить SHA ${DEVELOP_BRANCH}" >&2; restore_branch; return 1; }

    echo "  [7/8] атомарно пушим refs в ${ORIGIN_REMOTE}/${GITVERSE_REMOTE}"
    git push --atomic "${ORIGIN_REMOTE}" \
        "${DEVELOP_BRANCH}:${DEVELOP_BRANCH}" \
        "${RELEASE_BRANCH}:${RELEASE_BRANCH}" \
        "refs/tags/${tag}:refs/tags/${tag}" \
        || { echo "  atomic push -> ${ORIGIN_REMOTE} упал" >&2; restore_branch; return 1; }
    # Те же локальные refs уже прошли pre-push hook на каноническом push в GitLab; второй
    # одинаковый прогон тестов не нужен.
    git push --atomic --no-verify "${GITVERSE_REMOTE}" \
        "${DEVELOP_BRANCH}:${DEVELOP_BRANCH}" \
        "${RELEASE_BRANCH}:${RELEASE_BRANCH}" \
        || { echo "  atomic push -> ${GITVERSE_REMOTE} упал" >&2; restore_branch; return 1; }

    # 8. Создаём релиз на GitVerse (он же создаёт тег на GitVerse из target_commitish = merge_sha),
    #    затем проверяем, что оба хоста разрешают ветки и тег в ожидаемые commit SHA.
    echo "  [8/8] создаём релиз ${tag} на GitVerse и сверяем опубликованные refs"
    local releases_url="${GITVERSE_API}/repos/${owner_repo}/releases"
    local release_payload
    release_payload="$(jq -n \
        --rawfile body "${notes_path}" \
        --arg tag "${tag}" \
        --arg name "${tag}" \
        --arg target "${merge_sha}" \
        '{tag_name: $tag, name: $name, body: $body, target_commitish: $target}')"
    http_request POST "${releases_url}" "${release_payload}"
    if ! http_ok; then
        echo "  создание релиза ${tag} на GitVerse упало (HTTP ${HTTP_CODE}). Ответ: ${HTTP_BODY}" >&2
        restore_branch; return 1
    fi

    verify_published_refs "${ORIGIN_REMOTE}" "${develop_sha}" "${merge_sha}" "${tag}" \
        || { restore_branch; return 1; }
    verify_published_refs "${GITVERSE_REMOTE}" "${develop_sha}" "${merge_sha}" "${tag}" \
        || { restore_branch; return 1; }

    echo "        ${svc} зарелизен: ${tag}"
    restore_branch
    return 0
}

# ── основной цикл ────────────────────────────────────────────────────────────

echo "Релиз сервисов: ${SELECTED_SERVICES[*]}"
[[ -n "${EXPLICIT_TAG}" ]] && echo "Явный тег: ${EXPLICIT_TAG}" || echo "Бамп: --${BUMP_PART}"
echo

declare -A RESULTS=()
declare -A VERSIONS=()
ANY_FAILED=0

for svc in "${SELECTED_SERVICES[@]}"; do
    echo "=== ${svc} ==="
    RELEASED_TAG=""  # сбрасываем, чтобы не унаследовать тег предыдущего сервиса при ранней ошибке
    if release_service "${svc}"; then
        RESULTS["${svc}"]="OK"
    else
        RESULTS["${svc}"]="FAILED"
        ANY_FAILED=1
    fi
    VERSIONS["${svc}"]="${RELEASED_TAG:-—}"
    echo
done

# ── итоговая таблица ─────────────────────────────────────────────────────────

echo "=== Итог ==="
for svc in "${SELECTED_SERVICES[@]}"; do
    printf '  %-24s %-10s %s\n' "${svc}" "${VERSIONS[${svc}]:-—}" "${RESULTS[${svc}]}"
done

exit "${ANY_FAILED}"
