#!/usr/bin/env python3
"""Генератор baseline-миграции для схлопнутой цепочки.

Алгоритм:
  1. поднять временный PostgreSQL, накатить СТАРУЮ цепочку до CUT_REVISION;
  2. отразить (reflect) получившуюся схему и выгрузить строки всех непустых таблиц;
  3. отрендерить один файл миграции: down_revision = None, upgrade() создаёт схему и
     заливает справочники, downgrade() сносит схему;
  4. скопировать файлы общего хвоста (строго после отсечения) в новую директорию
     байт-в-байт.

Почему генерируется, а не пишется руками: воспроизвести состояние после десятков миграций
вручную — ровно тот способ, которым такие рефакторинги и ломаются.

Граница отсечения задаётся ОДНОЙ константой scripts/squash_config.py:CUT_REVISION;
имена файлов, префикс и состав хвоста выводятся из неё.

Почему DDL идёт через alembic-автогенерацию, а не через pg_dump: (а) сырой дамп пришлось
бы исполнять как несколько операторов в одном op.execute, чего asyncpg-путь (прод!) не
умеет; (б) модуль сравнения (tests/migrations/snapshot.py) построен ровно на pg_dump —
разные дороги к одному факту, иначе ошибки взаимно погасились бы (COMMENT-ы срезались бы
у обеих сторон, тест был бы зелёным, а прод — без комментариев).

Почему данные в JSON, а не в catalog/*.csv: load_csv() возвращает str и не отличает NULL
от пустой строки. Для сида, написанного человеком, это лечится ручным маппингом `or None`;
для машинной выгрузки 13 справочников — нет.

Запуск:
    uv run python scripts/make_squashed_baseline.py

Требует восстановленной старой цепочки: main() поднимает её в отдельной БД через
squash_config.chain_version_location("old"), а migrations/versions_old/ в дереве нет.
Перед запуском верни каталог (`git log --diff-filter=D -- migrations/versions_old`
найдёт коммит удаления) и раскомментируй CHAIN_DIRS/CHAIN_INI_SECTIONS в
scripts/squash_config.py — иначе запуск падает на неизвестной цепочке "old".
"""

from __future__ import annotations

import decimal
import json
import sys
from datetime import date, datetime
from pathlib import Path
from typing import Any

import sqlalchemy as sa
from alembic import command
from alembic.autogenerate import produce_migrations, render_python_code
from alembic.config import Config
from alembic.migration import MigrationContext
from sqlalchemy.engine.url import make_url
from testcontainers.postgres import PostgresContainer

# scripts/ не пакет: при запуске файлом сосед виден сам собой, но при загрузке модуля
# тестами через importlib — нет, поэтому директория добавляется в sys.path явно.
sys.path.insert(0, str(Path(__file__).resolve().parent))

import squash_config  # noqa: E402 — только после правки sys.path

_SRC_DB = "baseline_src"
_EMPTY_DB = "baseline_empty"

_TEMPLATE = '''"""{cut_prefix}_squashed_baseline

Revision ID: {revision}
Revises:
Create Date: {created}

СГЕНЕРИРОВАННЫЙ ФАЙЛ — правится генератором, не руками:
    uv run python scripts/make_squashed_baseline.py

Схлопывает миграции 0001..{cut_prefix} старой цепочки (migrations/versions/) в одно
состояние: схему и содержимое справочников на момент ревизии {revision}. Общий хвост
{tail_range} лежит рядом копиями и продолжает цепочку от этой ревизии.

revision намеренно совпадает с revision id старой {cut_prefix}: тогда следующей за ней
не нужно править down_revision, файлы хвоста копируются байт-в-байт, а alembic_version
у обеих цепочек показывает одно и то же в любой позиции.

Справочные строки лежат в catalog/{data_file} — сгенерированный снимок, не редактировать.
Порядок вставки берётся из metadata.sorted_tables (родители раньше детей), значения
приводятся к типам отражённых колонок: строка ISO в timestamptz на asyncpg-пути даёт
DataError (регресс 0099/0100), поэтому datetime собирается в Python, а не в SQL.

Эквивалентность этой миграции старой цепочке проверяется стендом:
    make test-migrations
"""

import json
from collections.abc import Sequence
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import sqlalchemy as sa
from alembic import op
{extra_imports}
revision: str = "{revision}"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_DATA_PATH = Path(__file__).parent.parent.parent / "catalog" / "{data_file}"


def _coerce(value: object, column: sa.Column) -> object:
    # Проверка на str, а не на None: типы, которые JSON не умеет, выгружены строками
    # (datetime/date — isoformat, Decimal — str), всё остальное лежит как есть и правки
    # не требует. Заодно снимает вопрос None у типизатора.
    if not isinstance(value, str):
        return value
    if isinstance(column.type, sa.DateTime):
        return datetime.fromisoformat(value)
    if isinstance(column.type, sa.Date):
        return datetime.fromisoformat(value).date()
    if isinstance(column.type, sa.Numeric) and not isinstance(column.type, sa.Float):
        return Decimal(value)
    return value


def _seed() -> None:
    conn = op.get_bind()
    payload = json.loads(_DATA_PATH.read_text(encoding="utf-8"))
    meta = sa.MetaData()
    meta.reflect(bind=conn)
    for table in meta.sorted_tables:  # родители раньше детей — иначе упрёмся в FK
        block = payload.get(table.name)
        if not block:
            continue
        columns = block["columns"]
        rows = [
            {{name: _coerce(value, table.c[name]) for name, value in zip(columns, row, strict=True)}}
            for row in block["rows"]
        ]
        conn.execute(table.insert(), rows)


def upgrade() -> None:
{upgrade_body}
    _seed()


def downgrade() -> None:
{downgrade_body}
'''


def _tail_range() -> str:
    """Диапазон хвоста для докстринга, например "0096..0110"."""
    tail = squash_config.tail_revision_files()
    return f"{tail[0].name[:4]}..{tail[-1].name[:4]}" if tail else "(пуст)"


def render_baseline(upgrade_body: str, downgrade_body: str) -> str:
    return _TEMPLATE.format(
        revision=squash_config.BASELINE_REVISION,
        cut_prefix=squash_config.CUT_PREFIX,
        tail_range=_tail_range(),
        data_file=squash_config.BASELINE_DATA_FILENAME,
        created=datetime.now().strftime("%Y-%m-%d"),
        extra_imports=_extra_imports(upgrade_body + downgrade_body),
        upgrade_body=_indent(upgrade_body),
        downgrade_body=_indent(downgrade_body),
    )


# Автогенерация по отражённой схеме рендерит диалектные типы без sa.-префикса:
# postgresql.TIMESTAMP(...), postgresql.ARRAY(TEXT()). Импорты под них render_python_code
# не отдаёт, поэтому дописываем сами — и только когда имя реально встретилось в теле,
# иначе ruff споткнётся об F401 на следующей регенерации.
_CONDITIONAL_IMPORTS: tuple[tuple[str, str], ...] = (
    ("TEXT(", "from sqlalchemy import TEXT"),
    ("postgresql.", "from sqlalchemy.dialects import postgresql"),
)


def _extra_imports(body: str) -> str:
    used = [statement for marker, statement in _CONDITIONAL_IMPORTS if marker in body]
    return "".join(f"{statement}\n" for statement in used)


def _indent(body: str) -> str:
    """Приводит тело к одному уровню отступа внутри def.

    render_python_code() отдаёт операторы уже с отступом в 4 пробела, а свои маркеры
    (`# ### commands auto generated ###`) — с нулевым. Поэтому не dedent+indent (общий
    отступ из-за маркеров равен нулю, и код уехал бы на второй уровень, что даёт
    IndentationError при импорте миграции), а «дотянуть до одного уровня»: строки мельче
    четырёх пробелов выравниваются, более глубокие остаются как есть.
    """
    lines = [line for line in body.splitlines() if line.strip()] or ["pass"]
    return "\n".join(line if len(line) - len(line.lstrip()) >= 4 else "    " + line.lstrip() for line in lines)


def _jsonable(value: Any) -> Any:
    # Неподдержанные типы намеренно не «спасаются»: json.dumps упадёт на них громко.
    # Половина round-trip-а (выгрузили hex, а _coerce обратно в bytes не умеет) засеяла бы
    # bytea литеральной строкой — то есть тихо испортила бы данные.
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return str(value)
    return value


def _server_default_text(column: sa.Column) -> str | None:
    default = column.server_default
    return str(getattr(default, "arg", default)) if default is not None else None


def _is_surrogate_pk(column: sa.Column) -> bool:
    """Адаптер отражённой sa.Column к общему предикату squash_config.is_surrogate_pk.

    Предикат один на генератор и компаратор осознанно: суррогатный ключ, который генератор
    считает бизнес-ключом, а компаратор — суррогатным, дал бы вставленное значение, на
    которое сравнение потом просто не смотрит. Такое расхождение проходит зелёным.
    """
    return squash_config.is_surrogate_pk(
        name=column.name,
        pk_names=frozenset(c.name for c in column.table.primary_key.columns),
        server_default=_server_default_text(column),
        identity=column.identity is not None,
    )


def export_rows(url: str) -> dict[str, dict[str, Any]]:
    """Строки всех непустых таблиц, кроме alembic_version, без суррогатных ключей.

    Список таблиц не захардкожен: на свежей БД непустыми оказываются ровно справочники,
    и такой список не может разъехаться с реальностью при добавлении новой таблицы.
    """
    engine = sa.create_engine(url)
    payload: dict[str, dict[str, Any]] = {}
    try:
        with engine.connect() as conn:
            meta = sa.MetaData()
            meta.reflect(bind=conn)
            for table in meta.sorted_tables:
                if table.name == "alembic_version":
                    continue
                columns = [c.name for c in table.columns if not _is_surrogate_pk(c)]
                quoted = ", ".join(f'"{c}"' for c in columns)
                rows = conn.execute(sa.text(f"SELECT {quoted} FROM public.{table.name} ORDER BY {quoted}")).all()
                if rows:
                    payload[table.name] = {
                        "columns": columns,
                        "rows": [[_jsonable(v) for v in row] for row in rows],
                    }
    finally:
        engine.dispose()
    return payload


def _render_ddl(src_url: str, empty_url: str) -> tuple[str, str]:
    """DDL состояния CUT_REVISION как op.*-вызовы: отражаем src, сравниваем с пустой БД."""
    src_engine = sa.create_engine(src_url)
    empty_engine = sa.create_engine(empty_url)
    try:
        meta = sa.MetaData()
        with src_engine.connect() as conn:
            meta.reflect(bind=conn)
        # alembic ведёт alembic_version сам — в baseline её быть не должно.
        if "alembic_version" in meta.tables:
            meta.remove(meta.tables["alembic_version"])
        with empty_engine.connect() as conn:
            ctx = MigrationContext.configure(connection=conn, opts={"compare_type": True})
            script = produce_migrations(ctx, meta)
        # produce_migrations() всегда наполняет обе ветки; None в аннотации — про общий
        # MigrationScript, который бывает и пустым. Пустой baseline — это провал генерации,
        # поэтому assert, а не тихий "pass" в теле миграции.
        assert script.upgrade_ops is not None and script.downgrade_ops is not None, (
            "produce_migrations() не вернул операции — отражение схемы не удалось"
        )
        return (
            render_python_code(script.upgrade_ops),
            render_python_code(script.downgrade_ops),
        )
    finally:
        src_engine.dispose()
        empty_engine.dispose()


def render_sequence_renames(pairs: list[tuple[str, str]]) -> list[str]:
    """op.execute-строки, приводящие имена последовательностей к историческим."""
    return [f'op.execute("ALTER SEQUENCE public.{new} RENAME TO {old}")' for new, old in pairs]


def sequence_renames(url: str) -> list[str]:
    """Последовательности, чьё имя в старой цепочке разошлось с именем колонки.

    patients.unique_id раньше назывался patient_id: SERIAL создал последовательность
    patients_patient_id_seq, а переименование колонки имя последовательности не меняет.
    Свежий create_table в baseline создаёт patients_unique_id_seq, и pg_dump честно
    показывает расхождение схем. Приводим имена к историческим — это настоящая разница,
    а не шум, и глушить её в нормализации нельзя.
    """
    engine = sa.create_engine(url)
    try:
        meta = sa.MetaData()
        with engine.connect() as conn:
            meta.reflect(bind=conn)
        pairs: list[tuple[str, str]] = []
        for table in meta.sorted_tables:
            for column in table.columns:
                actual = squash_config.surrogate_sequence(_server_default_text(column))
                if actual is None or not _is_surrogate_pk(column):
                    continue
                expected = f"{table.name}_{column.name}_seq"
                if actual != expected:
                    pairs.append((expected, actual))
        return render_sequence_renames(pairs)
    finally:
        engine.dispose()


def copy_tail(dest: Path) -> list[Path]:
    """Копирует файлы хвоста в новую цепочку байт-в-байт. Идентичность проверяет тест."""
    copied = []
    for source in squash_config.tail_revision_files():
        target = dest / source.name
        target.write_bytes(source.read_bytes())
        copied.append(target)
    return copied


def prune_stale(dest: Path) -> list[Path]:
    """Сносит артефакты предыдущего отсечения: файлы ревизий и снимок справочников.

    Без этого перенос CUT_REVISION оставил бы в новой цепочке и старый baseline, и копии
    ревизий, ушедших под отсечение, — то есть два корня и дубли, на которых alembic просто
    откажется строить цепочку. Удаляется строго то, что генератор сам и создаёт.
    """
    keep = {squash_config.BASELINE_FILENAME} | {p.name for p in squash_config.tail_revision_files()}
    removed = [p for p in sorted(dest.glob("*.py")) if p.name not in keep]
    # Глоб сужен до имён, которые генератор сам и порождает (0095_<rev>_baseline.json):
    # catalog/ — рукописная директория, и регенерация не должна сносить оттуда ничего чужого.
    snapshots = sorted(squash_config.CATALOG_DIR.glob("[0-9][0-9][0-9][0-9]_*_baseline.json"))
    removed += [p for p in snapshots if p.name != squash_config.BASELINE_DATA_FILENAME]
    for path in removed:
        path.unlink()
    return removed


def main() -> None:
    dest = squash_config.chain_version_location("new")
    dest.mkdir(parents=True, exist_ok=True)
    for path in prune_stale(dest):
        print(f"removed stale {path}")

    with PostgresContainer("postgres:16-alpine") as container:
        admin_url = container.get_connection_url()
        admin_engine = sa.create_engine(admin_url, isolation_level="AUTOCOMMIT")
        try:
            with admin_engine.connect() as conn:
                for db in (_SRC_DB, _EMPTY_DB):
                    conn.execute(sa.text(f'DROP DATABASE IF EXISTS "{db}"'))
                    conn.execute(sa.text(f'CREATE DATABASE "{db}"'))
        finally:
            admin_engine.dispose()

        def _url(db: str) -> str:
            return (
                make_url(admin_url)
                .set(drivername="postgresql+psycopg2", database=db)
                .render_as_string(hide_password=False)
            )

        cfg = Config(str(squash_config.REPO_ROOT / "alembic.ini"))
        cfg.set_main_option("sqlalchemy.url", _url(_SRC_DB))
        cfg.set_main_option("version_locations", str(squash_config.chain_version_location("old")))
        print(f"upgrading {_SRC_DB} to {squash_config.CUT_REVISION} via the old chain...")
        command.upgrade(cfg, squash_config.CUT_REVISION)

        upgrade_body, downgrade_body = _render_ddl(_url(_SRC_DB), _url(_EMPTY_DB))
        # Переименования идут после create_table и до сида — на сам сид они не влияют,
        # но схема должна совпасть с исторической до последней последовательности.
        upgrade_body = "\n".join([upgrade_body, *sequence_renames(_url(_SRC_DB))])
        payload = export_rows(_url(_SRC_DB))

    data_path = squash_config.CATALOG_DIR / squash_config.BASELINE_DATA_FILENAME
    data_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    print(f"wrote {data_path} ({sum(len(b['rows']) for b in payload.values())} rows across {len(payload)} tables)")

    baseline_path = dest / squash_config.BASELINE_FILENAME
    baseline_path.write_text(render_baseline(upgrade_body, downgrade_body), encoding="utf-8")
    print(f"wrote {baseline_path}")

    copied = copy_tail(dest)
    print(f"copied {len(copied)} tail revisions into {dest}")


if __name__ == "__main__":
    main()
