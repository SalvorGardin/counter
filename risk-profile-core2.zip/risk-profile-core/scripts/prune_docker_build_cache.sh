#!/usr/bin/env bash
# Ограниченная очистка неиспользуемого Docker build cache на dev-сервере.
set -euo pipefail

readonly RESERVED_SPACE="${DOCKER_BUILD_CACHE_RESERVED_SPACE:-1gb}"
readonly MAX_USED_SPACE="${DOCKER_BUILD_CACHE_MAX_USED_SPACE:-5gb}"
readonly MIN_FREE_SPACE="${DOCKER_BUILD_CACHE_MIN_FREE_SPACE:-10gb}"
readonly DEFAULT_LOCK_DIR="${XDG_RUNTIME_DIR:-/tmp}"
readonly DEFAULT_LOCK_FILE="${DEFAULT_LOCK_DIR}/risk-profile-build-cache-prune-${UID}.lock"
readonly LOCK_FILE="${DOCKER_BUILD_CACHE_PRUNE_LOCK_FILE:-${DEFAULT_LOCK_FILE}}"

docker_bin="${DOCKER_BIN:-}"
if [[ -z "${docker_bin}" ]]; then
    docker_bin=$(command -v docker || true)
fi
if [[ -z "${docker_bin}" || ! -x "${docker_bin}" ]]; then
    echo "Error: docker not found or is not executable: ${docker_bin:-<empty>}" >&2
    exit 1
fi
readonly docker_bin

flock_bin="${FLOCK_BIN:-}"
if [[ -z "${flock_bin}" ]]; then
    flock_bin=$(command -v flock || true)
fi
if [[ -z "${flock_bin}" || ! -x "${flock_bin}" ]]; then
    echo "Error: flock not found or is not executable: ${flock_bin:-<empty>}" >&2
    exit 1
fi
readonly flock_bin

exec 9>"${LOCK_FILE}"
if ! "${flock_bin}" -n 9; then
    echo "$(date --iso-8601=seconds) Docker build cache prune is already running; skipping."
    exit 0
fi

echo "$(date --iso-8601=seconds) Starting Docker build cache prune."

# Новые версии Buildx одновременно ограничивают cache и учитывают свободное
# место. На старом Docker остаётся совместимый --keep-storage.
buildx_help=$("${docker_bin}" buildx prune --help 2>/dev/null || true)
if [[ "${buildx_help}" == *"--reserved-space"* \
    && "${buildx_help}" == *"--max-used-space"* \
    && "${buildx_help}" == *"--min-free-space"* ]]; then
    "${docker_bin}" buildx prune \
        --all \
        --force \
        --reserved-space "${RESERVED_SPACE}" \
        --max-used-space "${MAX_USED_SPACE}" \
        --min-free-space "${MIN_FREE_SPACE}"
else
    echo "Warning: Docker Buildx does not support space-aware prune flags; using --keep-storage fallback." >&2
    "${docker_bin}" builder prune \
        --all \
        --force \
        --keep-storage "${MAX_USED_SPACE}"
fi

echo "$(date --iso-8601=seconds) Docker build cache prune completed."
