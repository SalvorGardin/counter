#!/usr/bin/env python3
import re
import shutil
import subprocess  # nosec B404
import sys
from pathlib import Path

VERSIONS_DIR = Path(__file__).parent.parent / "migrations" / "versions"


def main() -> None:
    args = sys.argv[1:]
    autogenerate = "--autogenerate" in args
    args = [a for a in args if a != "--autogenerate"]

    if len(args) < 1:
        print("Usage: python scripts/create_revision.py <migration_name> [--autogenerate]", file=sys.stderr)
        sys.exit(1)
    if len(args) > 1:
        print(
            "Too many arguments. Usage: python scripts/create_revision.py <migration_name> [--autogenerate]",
            file=sys.stderr,
        )
        sys.exit(1)

    name = args[0]

    numbers = [int(m.group(1)) for f in VERSIONS_DIR.glob("*.py") if (m := re.match(r"^(\d+)_", f.name))]
    next_number = (max(numbers) + 1) if numbers else 1
    message = f"{next_number:04d}_{name}"

    alembic = shutil.which("alembic")
    if alembic is None:
        print("ERROR: alembic not found in PATH", file=sys.stderr)
        sys.exit(1)
    cmd = [alembic, "revision", "-m", message]
    if autogenerate:
        cmd.append("--autogenerate")
    subprocess.run(cmd, check=True)  # nosec B603


if __name__ == "__main__":
    main()
