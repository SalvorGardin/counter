#!/usr/bin/env bash
# Ждёт завершения one-shot compose-сервисов (restart:"no") и проверяет, что они вышли с кодом 0.
# Общий для scripts/docker_up.sh и Makefile-таргета infra-up — чтобы `make infra-up` на стенде/проде
# НЕ был fire-and-forget: провижининг топиков/ACL должен успеть до старта app-tier, иначе продюсер
# app/consumer закэширует «unauthorized»-топик (aiokafka не сбрасывает это на metadata-refresh).
#
# Использование: wait_oneshot.sh <compose-file> <service> [service...]
set -euo pipefail

if [[ $# -lt 2 ]]; then
    echo "Usage: $0 <compose-file> <service> [service...]" >&2
    exit 2
fi

compose_file="$1"
shift

wait_one() {
    local svc="$1" cid state exit_code timeout_sec="${ONESHOT_TIMEOUT_SECONDS:-300}" elapsed=0
    cid=$(docker compose -f "${compose_file}" ps --all -q "${svc}" 2>/dev/null || true)
    if [[ -z "${cid}" ]]; then
        echo "  Warning: ${svc} container not found — skipping wait." >&2
        return
    fi
    while [[ ${elapsed} -lt ${timeout_sec} ]]; do
        state=$(docker inspect --format='{{.State.Status}}' "${cid}" 2>/dev/null || echo "")
        [[ "${state}" == "exited" ]] && break
        sleep 2
        elapsed=$((elapsed + 2))
    done
    if [[ ${elapsed} -ge ${timeout_sec} ]]; then
        echo "Error: ${svc} did not finish within ${timeout_sec}s." >&2
        docker logs "${cid}" >&2
        exit 1
    fi
    exit_code=$(docker inspect --format='{{.State.ExitCode}}' "${cid}")
    if [[ "${exit_code}" != "0" ]]; then
        echo "Error: ${svc} failed (exit code ${exit_code})." >&2
        docker logs "${cid}" >&2
        exit 1
    fi
    echo "  ${svc} finished successfully."
}

for svc in "$@"; do
    wait_one "${svc}"
done
