#!/usr/bin/env python3
"""Скачивает текущий срез профиля с `/api/v1/debug/profile` и кладёт .prof в `profiles/`.

Запуск:
    BASE_URL=http://localhost:9001 API_KEY=<key> uv run scripts/fetch_profile.py
    # очистить скользящее окно после скачивания:
    API_KEY=<key> uv run scripts/fetch_profile.py --reset

Требования в .env сервиса:
    RISK_MODEL_TESTING_API_ENABLED=true
    RISK_MODEL_TEST_API_KEY=<key>
    RISK_MODEL_PROFILER__ENABLED=true

Открыть результат:
    uv run python -m pstats profiles/<file>.prof
    # или snakeviz profiles/<file>.prof
"""

import asyncio
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

import httpx2

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
API_KEY = os.getenv("API_KEY", "")
HEADERS = {"X-Test-Api-Key": API_KEY}
PROFILES_DIR = Path(__file__).resolve().parent.parent / "profiles"


async def main() -> None:
    if not API_KEY:
        print("Ошибка: установите переменную API_KEY")
        print("  Пример: API_KEY=mykey uv run scripts/fetch_profile.py")
        sys.exit(1)

    reset = "--reset" in sys.argv[1:]

    async with httpx2.AsyncClient(base_url=BASE_URL, headers=HEADERS, timeout=60) as client:
        r = await client.get("/api/v1/debug/profile", params={"reset": str(reset).lower()})
        r.raise_for_status()

    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(tz=UTC).strftime("%Y%m%d-%H%M%S")
    out_path = PROFILES_DIR / f"risk-model-{stamp}.prof"
    out_path.write_bytes(r.content)

    print(f"✓ профиль сохранён: {out_path}  ({len(r.content)} байт)")
    if reset:
        print("  скользящее окно профайлера очищено (--reset)")
    print(f"  открыть: uv run python -m pstats {out_path}")


asyncio.run(main())
