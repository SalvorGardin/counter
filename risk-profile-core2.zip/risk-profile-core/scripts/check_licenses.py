#!/usr/bin/env python3
"""Verify that all installed packages use approved open-source licenses.

Approved: MIT, Apache-2.0, BSD, PSF, ISC, MPL-2.0, LGPL, and compatible.
"""

from __future__ import annotations

import json
import shutil
import subprocess  # nosec B404
import sys

# Substrings matched case-insensitively against the license string
APPROVED_PATTERNS: tuple[str, ...] = (
    "mit",
    "apache",
    "bsd",
    "python software foundation",
    "psf",
    "isc",
    "mozilla public license",
    "mpl",
    "public domain",
    "unlicense",
    "cc0",
    "gnu lesser general public license",
    "lgpl",
    "historical permission notice",
    "hpnd",
    "zlib",
    "libpng",
)

# Packages whose PyPI metadata omits the license field but are known-approved.
# Key: package name (case-insensitive), Value: actual SPDX identifier.
KNOWN_LICENSES: dict[str, str] = {
    "chroma-hnswlib": "Apache-2.0",
    "peewee": "MIT",
    "taskiq-dependencies": "MIT",
}

# Own packages and meta-packages to skip entirely.
IGNORED_PACKAGES: frozenset[str] = frozenset(
    [
        "impuls-project",  # this project itself (installed as editable)
        "risk-model",
        "lpa",  # internal package
    ]
)
IGNORED_PACKAGE_VERSIONS: frozenset[tuple[str, str]] = frozenset({("lizard", "1.24.0"), ("face", "26.0.1")})


def main() -> int:
    pip_licenses = shutil.which("pip-licenses")
    if pip_licenses is None:
        print("ERROR: pip-licenses not found in PATH", file=sys.stderr)
        return 1
    result = subprocess.run(  # nosec B603
        [pip_licenses, "--format=json"],
        capture_output=True,
        text=True,
        check=True,
    )
    packages: list[dict[str, str]] = json.loads(result.stdout)

    failures: list[str] = []
    for pkg in packages:
        name = pkg.get("Name", "UNKNOWN")
        version = pkg.get("Version", "?")
        license_str = pkg.get("License", "UNKNOWN").strip()

        if name.lower() in {p.lower() for p in IGNORED_PACKAGES} or (name.lower(), version) in IGNORED_PACKAGE_VERSIONS:
            continue

        # Use known override if pip-licenses couldn't detect the license
        if license_str == "UNKNOWN" and name.lower() in {k.lower() for k in KNOWN_LICENSES}:
            license_str = next(v for k, v in KNOWN_LICENSES.items() if k.lower() == name.lower())

        license_lower = license_str.lower()
        approved = any(pat in license_lower for pat in APPROVED_PATTERNS)

        if not approved:
            failures.append(f"  {name}=={version}: {license_str!r}")

    if failures:
        print(f"FAIL: {len(failures)} package(s) with unapproved or unknown licenses:")
        print("\n".join(failures))
        return 1

    print(f"OK: all {len(packages)} packages have approved licenses")
    return 0


if __name__ == "__main__":
    sys.exit(main())
