SELECT
    patient_parameter_id,
    patient_id,
    parameter_code,
    value,
    source,
    expiration_date,
    date_time
FROM risk_profile.patients_parameters
WHERE patient_id = :patient_id
ORDER BY patient_parameter_id;
