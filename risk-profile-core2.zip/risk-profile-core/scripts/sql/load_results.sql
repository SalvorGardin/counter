SELECT
    result_id,
    instrument_code,
    patient_id,
    value,
    indicator,
    date_time,
    interpretation_status,
    expiration_date,
    risk_level,
    applicability,
    unit
FROM risk_calculation.results
WHERE patient_id = :patient_id
ORDER BY result_id;
