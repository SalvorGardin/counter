SELECT
    interpretation_id,
    system_code,
    patient_id,
    risk_level,
    text,
    diseases,
    risk_factors_code,
    doctors_code,
    date_time
FROM risk_calculation.interpretations
WHERE patient_id = :patient_id
ORDER BY interpretation_id;
