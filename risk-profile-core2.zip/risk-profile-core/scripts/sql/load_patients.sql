SELECT
    unique_id,
    patient_id,
    is_pregnant
FROM risk_profile.patients
WHERE patient_id = :patient_id
ORDER BY unique_id;
