#!/usr/bin/env bash
# Поднимает локальный стек для разработки в ДВУХ независимых compose-проектах:
#   risk-profile-core  (docker-compose.yml)       — db, migrations, app, consumer, emr-consumer
#   risk-profile-infra (docker-compose.infra.yml) — kafka, kafka-init, kafka-acls-init, kafka-ui
# Генерит TLS-сертификаты, создаёт общую сеть risk-net, поднимает Kafka, ждёт kafka-init
# (создание топиков) и kafka-acls-init (выдача ACL для User:risk-app), затем поднимает приложение.
#
# Использование:
#   ./scripts/docker_up.sh             # с пересборкой образов
#   ./scripts/docker_up.sh --no-build  # без пересборки
#
# ELK локально не поднимаем — нужен полный инфра-стек (Kafka + ELK), запускай `make infra-up`.
# На dev-стенде/проде Kafka разворачивается так же — отдельным проектом risk-profile-infra;
# релиз ядра (docker-compose.yml) её не трогает.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${SCRIPT_DIR}/.."
COMPOSE_FILE="${ROOT_DIR}/docker-compose.yml"
INFRA_FILE="${ROOT_DIR}/docker-compose.infra.yml"
ENV_FILE="${ROOT_DIR}/.env"
BUILD_FLAG="--build"

for arg in "$@"; do
    case "$arg" in
        --no-build) BUILD_FLAG="" ;;
        *) echo "Unknown argument: $arg" >&2; exit 1 ;;
    esac
done

# ── prerequisites ────────────────────────────────────────────────────────────

if ! command -v docker >/dev/null 2>&1; then
    echo "Error: docker not found in PATH" >&2
    exit 1
fi

if [[ ! -f "${ENV_FILE}" ]]; then
    echo "Error: .env not found — copy .env.example and fill in the values." >&2
    exit 1
fi

# Имена проектов берутся из top-level `name:` в каждом файле — `-f` его не меняет.
_app() { docker compose -f "${COMPOSE_FILE}" "$@"; }
_infra() { docker compose -f "${INFRA_FILE}" "$@"; }

# ── TLS certs (idempotent — skips if already generated) ─────────────────────

echo "[1/4] Checking Kafka TLS certs..."
bash "${SCRIPT_DIR}/generate_kafka_certs.sh"

# ── shared network + Kafka + провижининг (infra-проект, без ELK) ─────────────
# kafka-init создаёт топики, kafka-acls-init выдаёт ACL для risk-app — оба идемпотентны
# и описаны в docker-compose.infra.yml (единый источник прав, работает и на стенде через infra-up).

echo "[2/4] Starting Kafka + topic/ACL provisioning (project risk-profile-infra)..."
docker network create risk-net 2>/dev/null || true
# shellcheck disable=SC2086
_infra up -d ${BUILD_FLAG} kafka kafka-init kafka-acls-init kafka-ui

# ── wait for one-shot provisioning (topics + ACLs) ───────────────────────────

echo "[3/4] Waiting for topic + ACL provisioning to complete..."
bash "${SCRIPT_DIR}/wait_oneshot.sh" "${INFRA_FILE}" kafka-init kafka-acls-init

# ── application (core-проект) ────────────────────────────────────────────────

echo "[4/4] Starting application (project risk-profile-core)..."
# shellcheck disable=SC2086
_app up -d ${BUILD_FLAG}

# ── summary ──────────────────────────────────────────────────────────────────

app_port=$(grep "^RISK_MODEL_PORT=" "${ENV_FILE}" | head -1 | cut -d= -f2- | tr -d "\"'" || echo "8000")

echo
echo "All containers are up."
echo "  Service:  http://localhost:${app_port}"
echo "  API docs: http://localhost:${app_port}/docs"
echo "  Consumer: docker compose -f docker-compose.yml logs -f consumer"
echo "  EMR consumer: docker compose -f docker-compose.yml logs -f emr-consumer"
echo "  Kafka UI: http://localhost:8080 (на стенде — через SSH-туннель)"
echo "  Teardown: make docker-down"
