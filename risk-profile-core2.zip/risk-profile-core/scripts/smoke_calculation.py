#!/usr/bin/env python3
"""Smoke-тест: создаёт 3 пациентов, выставляет все параметры, запускает расчёт, печатает результаты.

Запуск:
    BASE_URL=http://localhost:9001 API_KEY=<key> uv run scripts/smoke_calculation.py

Требования в .env:
    RISK_MODEL_TESTING_API_ENABLED=true
    RISK_MODEL_TEST_API_KEY=<key>
"""

import asyncio
import os
from datetime import UTC, datetime, timedelta
from typing import TypedDict

import httpx2


class Patient(TypedDict):
    patientId: str
    isPregnant: bool
    label: str
    params: dict[str, str]


BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
API_KEY = os.getenv("API_KEY", "")
HEADERS = {"X-Test-Api-Key": API_KEY}
EXPIRATION = (datetime.now(tz=UTC) + timedelta(days=365)).isoformat()

# fmt: off
_SPILB_SITUATIONAL_LOW  = ["Нет, это не так"] * 20   # SPILB1–SPILB20, score=1
_SPILB_PERSONAL_LOW     = ["Почти никогда"]   * 20   # SPILB21–SPILB40, score=1
_SPILB_SITUATIONAL_HIGH = ["Совершенно верно"] * 20  # score=4
_SPILB_PERSONAL_HIGH    = ["Почти всегда"]     * 20  # score=4

def _spilb(sit: list[str], pers: list[str]) -> dict[str, str]:
    params = {}
    for i, v in enumerate(sit, start=1):
        params[f"stai{i}"] = v
    for i, v in enumerate(pers, start=21):
        params[f"stai{i}"] = v
    return params

_BECK_LOW = {
    "bdi1":  "Я не чувствую себя несчастным.",
    "bdi2":  "Думая о будущем, я не чувствую себя особенно разочарованным.",
    "bdi3":  "Я не чувствую себя неудачником.",
    "bdi4":  "Я получаю столько же удовольствия от жизни, как и раньше.",
    "bdi5":  "Я не чувствую себя особенно виноватым.",
    "bdi6":  "Я не чувствую, что меня за что-то наказывают.",
    "bdi7":  "Я не испытываю разочарование в себе.",
    "bdi8":  "У меня нет чувства, что я в чем-то хуже других.",
    "bdi9":  "У меня нет мыслей о том, чтобы покончить с собой.",
    "bdi10": "Я плачу не больше, чем обычно.",
    "bdi11": "Сейчас я не более раздражителен, чем обычно.",
    "bdi12": "Я не потерял интереса к другим людям.",
    "bdi13": "Я способен принимать решения так же, как всегда.",
    "bdi14": "Я не чувствую, что я выгляжу хуже, чем обычно.",
    "bdi15": "Я могу работать так же, как раньше.",
    "bdi16": "Я могу спать так же хорошо, как и обычно.",
    "bdi17": "Я устаю не больше обычного.",
    "bdi18": "Мой аппетит не хуже, чем обычно.",
    "bdi19": "Если в последнее время я и потерял в весе, то очень немного.",
    "bdi20": "Я беспокоюсь о своем здоровье не больше, чем обычно.",
    "bdi21": "Я не замечал каких-либо изменений в моих сексуальных интересах.",
}

_BECK_HIGH = {
    "bdi1":  "Я настолько несчастен и опечален, что не могу этого вынести.",
    "bdi2":  "Я чувствую, что будущее безнадежно и ничего не изменится к лучшему.",
    "bdi3":  "Я чувствую себя полным неудачником.",
    "bdi4":  "Я всем неудовлетворен, и мне все надоело.",
    "bdi5":  "Я чувствую себя виноватым все время.",
    "bdi6":  "Я чувствую, что меня наказывают за что-то.",
    "bdi7":  "Я ненавижу себя.",
    "bdi8":  "Я виню себя за все плохое, что происходит.",
    "bdi9":  "Я бы покончил с собой, если бы представился удобный случай.",
    "bdi10": "Раньше я еще мог плакать, но теперь не смогу, даже если захочу.",
    "bdi11": "Меня уже ничто не раздражает, потому что все стало безразлично.",
    "bdi12": "Я потерял всякий интерес к другим людям.",
    "bdi13": "Я больше не могу принимать каких-либо решений.",
    "bdi14": "Я уверен, что выгляжу безобразным.",
    "bdi15": "Я вообще не могу работать.",
    "bdi16": "Я просыпаюсь на несколько часов раньше обычного и не могу снова заснуть.",
    "bdi17": "Я слишком устал, чтобы делать что бы то ни было.",
    "bdi18": "Я вообще потерял аппетит.",
    "bdi19": "Я потерял в весе более 6 кг.",
    "bdi20": "Я до такой степени обеспокоен своим здоровьем, что вообще ни о чем не могу думать.",
    "bdi21": "Я совершенно утратил интерес к сексу.",
}

PATIENTS: list[Patient] = [
    {
        "patientId": "smoke-001-low-risk-female",
        "isPregnant": False,
        "label": "Женщина 45 лет — низкий риск",
        "params": {
            # Общие
            "gender": "Женский",
            "age": "45",
            # BCRAT
            "breast_cancer": "Нет",
            "age_menarche": "13",
            "breast_biopsies_count": "Ноль",
            "breast_atypical_hyperplasia": "Данных по атипической гиперплазии ни в одном из образцов не обнаружено",
            "age_first_birth": "20 - 24 года",
            "family_breast_cancer": "Ноль",
            # STOP-BANG
            "snoring": "Нет",
            "daytime_fatigue": "Нет",
            "sleep_apnea_episodes": "Нет",
            "arterial_hypertension": "Нет",
            "height": "165",
            "weight": "60",
            "neck_circumference": "Нет",
            # SCORE2
            "atherosclerosis": "Нет",
            "diabetes": "Нет",
            "family_hypercholesterolemia": "Нет",
            "smoking": "Нет",
            "systolic_bp": "120",
            "diastolic_bp": "80",
            "total_cholesterol": "5.0",
            "ldl": "3.0",
            "hdl": "1.5",
            # CKD-EPI
            "creatinine": "60",
            # FINDRISC
            "waist_circumference": "75",
            "fruits_veg_intake": "Каждый день",
            "physical_activity_level": "Да",
            "antihypertensive_meds": "Нет",
            "glucose_elevated_history": "Нет",
            "family_diabetes_close": "Нет",
            "family_diabetes_far": "Нет",
            **_BECK_LOW,
            **_spilb(_SPILB_SITUATIONAL_LOW, _SPILB_PERSONAL_LOW),
        },
    },
    {
        "patientId": "smoke-002-high-risk-female",
        "isPregnant": False,
        "label": "Женщина 60 лет — высокий риск",
        "params": {
            "gender": "Женский",
            "age": "60",
            "breast_cancer": "Нет",
            "age_menarche": "11",
            "breast_biopsies_count": "Больше одной",
            "breast_atypical_hyperplasia":
            "В процессе исследования хотя бы в одном образце "
            "биопсии была обнаружена атипическая гиперплазия",
            "age_first_birth": "Не рожала",
            "family_breast_cancer": "Больше одного",
            "snoring": "Да",
            "daytime_fatigue": "Да",
            "sleep_apnea_episodes": "Да",
            "arterial_hypertension": "Да",
            "height": "160",
            "weight": "100",
            "neck_circumference": "Да",
            "atherosclerosis": "Нет",
            "diabetes": "Нет",
            "family_hypercholesterolemia": "Нет",
            "smoking": "Да",
            "systolic_bp": "175",
            "diastolic_bp": "105",
            "total_cholesterol": "7.5",
            "ldl": "5.0",
            "hdl": "0.9",
            "creatinine": "120",
            "waist_circumference": "95",
            "fruits_veg_intake": "Не каждый день",
            "physical_activity_level": "Нет",
            "antihypertensive_meds": "Да",
            "glucose_elevated_history": "Да",
            "family_diabetes_close": "Да",
            "family_diabetes_far": "Да",
            **_BECK_HIGH,
            **_spilb(_SPILB_SITUATIONAL_HIGH, _SPILB_PERSONAL_HIGH),
        },
    },
    {
        "patientId": "smoke-004-youth",
        "isPregnant": False,
        "label": "Подросток 16 лет — BDI + STAI + FINDRISK",
        "params": {
            "gender": "Женский",
            "age": "16",
            # FINDRISK (все обязательные)
            "height": "165",
            "weight": "68",
            "waist_circumference": "92",
            "fruits_veg_intake": "Не каждый день",
            "physical_activity_level": "Нет",
            "antihypertensive_meds": "Нет",
            "glucose_elevated_history": "Нет",
            "family_diabetes_close": "Нет",
            "family_diabetes_far": "Нет",
            # BDI
            **_BECK_LOW,
            # STAI
            **_spilb(_SPILB_SITUATIONAL_LOW, _SPILB_PERSONAL_LOW),
        },
    },
    {
        "patientId": "smoke-003-male",
        "isPregnant": False,
        "label": "Мужчина 55 лет — средний риск",
        "params": {
            "gender": "Мужской",
            "age": "55",
            "breast_cancer": "Нет",   # BCRAT not applicable (male)
            "age_menarche": "13",
            "breast_biopsies_count": "Ноль",
            "breast_atypical_hyperplasia": "Данных по атипической гиперплазии ни в одном из образцов не обнаружено",
            "age_first_birth": "20 - 24 года",
            "family_breast_cancer": "Ноль",
            "snoring": "Да",
            "daytime_fatigue": "Да",
            "sleep_apnea_episodes": "Нет",
            "arterial_hypertension": "Нет",
            "height": "178",
            "weight": "85",
            "neck_circumference": "Нет",
            "atherosclerosis": "Нет",
            "diabetes": "Нет",
            "family_hypercholesterolemia": "Нет",
            "smoking": "Да",
            "systolic_bp": "145",
            "diastolic_bp": "92",
            "total_cholesterol": "6.2",
            "ldl": "4.0",
            "hdl": "1.1",
            "creatinine": "95",
            "waist_circumference": "98",
            "fruits_veg_intake": "Не каждый день",
            "physical_activity_level": "Нет",
            "antihypertensive_meds": "Нет",
            "glucose_elevated_history": "Нет",
            "family_diabetes_close": "Нет",
            "family_diabetes_far": "Да",
            **_BECK_LOW,
            **_spilb(_SPILB_SITUATIONAL_LOW, _SPILB_PERSONAL_LOW),
        },
    },
]
# fmt: on


def _sep(char: str = "─", w: int = 72) -> None:
    print(char * w)


def _risk_badge(risk_level: str | None, applicable: bool) -> str:
    if not applicable:
        return "⬜ не применимо"
    return {"low": "🟢 low", "medium": "🟡 medium", "high": "🔴 high"}.get(risk_level or "", f"— {risk_level}")


async def upsert_patient(client: httpx2.AsyncClient, patient_id: str, is_pregnant: bool) -> None:
    r = await client.post("/api/v1/testing/patients", json={"patientId": patient_id, "isPregnant": is_pregnant})
    if r.status_code == 201:
        print(f"  ✓ создан  {patient_id}")
    elif r.status_code == 409:
        print(f"  ~ уже есть {patient_id}")
    else:
        r.raise_for_status()


async def set_params(client: httpx2.AsyncClient, patient_id: str, params: dict[str, str]) -> tuple[int, list[str]]:
    r = await client.get("/api/v1/testing/parameters")
    r.raise_for_status()
    available = {p["code"] for p in r.json()}

    ok, skipped = 0, []
    for code, value in params.items():
        if code not in available:
            skipped.append(code)
            continue
        r = await client.post(
            "/api/v1/testing/patient-parameters",
            json={
                "patientId": patient_id,
                "parameterCode": code,
                "value": value,
                "source": "smoke",
                "expirationDate": EXPIRATION,
            },
        )
        r.raise_for_status()
        ok += 1
    return ok, skipped


async def main() -> None:
    if not API_KEY:
        print("Ошибка: установите переменную API_KEY")
        print("  Пример: API_KEY=mykey uv run scripts/smoke_calculation.py")
        return

    async with httpx2.AsyncClient(base_url=BASE_URL, headers=HEADERS, timeout=60) as client:
        _sep("═")
        print("Шаг 1 / 3 — Создание пациентов")
        _sep()
        for p in PATIENTS:
            await upsert_patient(client, p["patientId"], p["isPregnant"])

        _sep("═")
        print("Шаг 2 / 3 — Выставление параметров")
        _sep()
        for p in PATIENTS:
            print(f"  {p['label']} ({p['patientId']})")
            ok, skipped = await set_params(client, p["patientId"], p["params"])
            print(f"  → выставлено: {ok}  |  не найдено в БД: {len(skipped)}")
            if skipped:
                print(f"     пропущено: {', '.join(skipped[:10])}{'...' if len(skipped) > 10 else ''}")

        _sep("═")
        print("Шаг 3 / 3 — Расчёт")
        _sep()
        r = await client.post(
            "/api/v1/testing/calculation/run",
            json={"patients": [{"patientId": p["patientId"]} for p in PATIENTS]},
        )
        r.raise_for_status()
        by_patient: dict[str, list] = {item["patientId"]: item["results"] for item in r.json()}
        total = sum(len(v) for v in by_patient.values())
        print(f"  ✓ расчёт завершён  |  всего результатов: {total}")

        _sep("═")
        print("Результаты")
        for p in PATIENTS:
            _sep()
            pid = p["patientId"]
            results = sorted(by_patient.get(pid, []), key=lambda x: x["instrumentCode"])
            print(f"  {p['label']}")
            print(f"  id: {pid}  |  результатов: {len(results)}")
            if not results:
                print("  (нет результатов)")
                continue
            for r in results:
                value = r.get("value") or "—"
                unit = r.get("unit") or ""
                badge = _risk_badge(r.get("riskLevel"), r.get("applicability", True))
                indicator = (r.get("indicator") or "")[:38]
                print(f"    [{r['instrumentCode']:10}]  {indicator:40}  {str(value):>10} {unit:22}  {badge}")
        _sep("═")


asyncio.run(main())
