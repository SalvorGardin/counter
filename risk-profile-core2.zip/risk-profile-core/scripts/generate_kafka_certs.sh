#!/usr/bin/env bash
#
# Генерация self-signed CA и серверного TLS-сертификата для Kafka (SASL_SSL).
#
# Создаёт в каталоге OUT_DIR (по умолчанию ./certs):
#   ca.crt, ca.key       — корневой CA (10 лет)
#   kafka.crt, kafka.key — сертификат брокера (SAN: kafka,localhost,127.0.0.1)
#
# Аутентификация клиентов идёт через SASL/SCRAM (логин + пароль), поэтому клиентские сертификаты
# здесь не выпускаются — нужен только CA, чтобы клиент мог проверить идентичность брокера.
#
# CA для каждого окружения свой — не пересылайте приватные ключи между стендами.
# Скрипт идемпотентен: уже существующие файлы не пересоздаются (удаляйте вручную при ротации).

set -euo pipefail

OUT_DIR="${OUT_DIR:-./certs}"
ORG="${KAFKA_CERT_ORG:-risk-profile}"
COUNTRY="${KAFKA_CERT_COUNTRY:-RU}"
DAYS_CA="${KAFKA_CERT_DAYS_CA:-3650}"
DAYS_LEAF="${KAFKA_CERT_DAYS_LEAF:-825}"
BROKER_SAN="${KAFKA_BROKER_SAN:-DNS:kafka,DNS:localhost,IP:127.0.0.1}"

mkdir -p "${OUT_DIR}"
cd "${OUT_DIR}"

require_openssl() {
    if ! command -v openssl >/dev/null 2>&1; then
        echo "openssl not found in PATH" >&2
        exit 1
    fi
}

generate_ca() {
    if [[ -f ca.key && -f ca.crt ]]; then
        echo "[skip] ca.key / ca.crt already exist"
        return
    fi
    echo "[ca] generating root CA"
    openssl genrsa -out ca.key 4096 2>/dev/null
    openssl req -x509 -new -nodes -key ca.key -sha256 -days "${DAYS_CA}" \
        -subj "/CN=${ORG}-kafka-ca/O=${ORG}/C=${COUNTRY}" \
        -out ca.crt
}

generate_broker_cert() {
    if [[ -f kafka.key && -f kafka.crt ]]; then
        echo "[skip] kafka.key / kafka.crt already exist"
        return
    fi

    echo "[cert] generating broker cert (CN=kafka, SAN=${BROKER_SAN})"
    openssl genrsa -out kafka.key 4096 2>/dev/null
    openssl req -new -key kafka.key \
        -subj "/CN=kafka/O=${ORG}/C=${COUNTRY}" \
        -out kafka.csr

    local ext_file
    ext_file=$(mktemp)
    cat > "${ext_file}" <<EOF
subjectAltName = ${BROKER_SAN}
extendedKeyUsage = serverAuth
EOF

    openssl x509 -req -in kafka.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
        -out kafka.crt -days "${DAYS_LEAF}" -sha256 -extfile "${ext_file}"

    rm -f kafka.csr "${ext_file}"
}

main() {
    require_openssl
    generate_ca
    generate_broker_cert

    # Бинд-маунт в docker сохраняет UID файла; внутри контейнера app работает под non-root
    # пользователем с другим UID, поэтому ключи должны быть world-readable, иначе ssl-загрузчик
    # упадёт с PermissionError. Для dev-стенда приемлемо — секреты дополнительно защищены SSH/файрволлом.
    chmod 644 ./*.key
    chmod 644 ./*.crt

    echo
    echo "[done] certs ready in ${OUT_DIR}/"
    echo "  CA:     ca.crt (передать клиентам как trust anchor)"
    echo "  Broker: kafka.crt / kafka.key (только для брокера, не раздавать)"
    echo
    echo "Клиенты аутентифицируются через SASL/SCRAM-SHA-512 — креды раздаются вне этого скрипта."
}

main "$@"
