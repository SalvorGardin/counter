#!/usr/bin/env python3
"""Заводит и снимает роли PostgreSQL для изоляции схем. Выдача — ОДИН раз перед `alembic upgrade`.

Роли в PostgreSQL кластерные, поэтому их выдача — шаг деплоя, а не миграция: миграция не должна
носить в себе пароли рантаймов (см. openspec/changes/isolate-database-schemas-per-service).

Запуск:
    RISK_MODEL_DB_ADMIN_URL=postgresql+asyncpg://postgres:...@db:5432/riskdb \
    RISK_MODEL_DB_PROFILE_PASSWORD_FILE=/run/secrets/risk_profile_app_password \
    RISK_MODEL_DB_CALCULATION_PASSWORD_FILE=... \
    RISK_MODEL_DB_EHR_PASSWORD_FILE=... \
    RISK_MODEL_DB_BULK_RECALC_PASSWORD_FILE=... \
    RISK_MODEL_DB_MIGRATIONS_PASSWORD_FILE=... \
    POSTGRES_USER=riskuser \
    uv run scripts/bootstrap_db_roles.py

Каждый пароль берётся из `<VAR>_FILE` (docker secret) либо из `<VAR>`. Значения не печатаются.
Повторный запуск идемпотентен и служит ротацией паролей.

Завести или обновить только отдельные логины, не трогая пароли остальных (новый логин в релизе,
ротация одного пароля). Пароль читается из указанного файла, переменные `*_PASSWORD` не нужны:
    RISK_MODEL_DB_ADMIN_URL=postgresql+asyncpg://postgres:...@db:5432/riskdb \
    uv run scripts/bootstrap_db_roles.py --role risk_bulk_recalc_app=/run/secrets/risk_bulk_recalc_app_password

Ключ `--role` повторяется. Логин получает `LOGIN`, пароль и `CONNECT` на базу; роли-владельцы
схем и членство в них здесь не выдаются, поэтому первую установку делает только полный прогон.

Режим общего логина — только для стенда, где все процессы подключаются под одним логином
(`RISK_MODEL_DB_ASSUME_RUNTIME_ROLE=true`). Полный прогон с `--shared-login` дополнительно выдаёт
этому логину членство в остальных рантайм-логинах `WITH INHERIT FALSE, SET TRUE`: права рантайма
он получает, только переключившись в его логин. `risk_migrations` и роли-владельцы схем общим
логином быть не могут. В проде и стейдже процессы работают под отдельными логинами и ключ не нужен:
    RISK_MODEL_DB_ADMIN_URL=... RISK_MODEL_DB_*_PASSWORD_FILE=... \
    uv run scripts/bootstrap_db_roles.py --shared-login risk_profile_app

Снятие ролей при откате (паролей не требует, нужен только админский URL):
    RISK_MODEL_DB_ADMIN_URL=postgresql+asyncpg://postgres:...@db:5432/riskdb \
    uv run scripts/bootstrap_db_roles.py --drop-roles

Запускать ПОСЛЕ `alembic downgrade`: пока схемы сервисов на месте, скрипт откажет. Объекты с
данными он не удаляет ни при каком порядке запуска — гарантии описаны в `drop_roles`.

Соединение всегда открывается на asyncpg, каким бы драйвером ни был записан админский URL:
пароли рантаймов должны уехать на сервер связанными параметрами, а не литералами в тексте
запроса — иначе они видны в `pg_stat_activity` и попадают в лог при `log_statement=all`.
"""

import argparse
import asyncio
import os
import sys
from pathlib import Path

from pydantic import SecretStr

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.infra.db_bootstrap import (  # noqa: E402
    SELECTABLE_LOGIN_ROLES,
    RoleCredentials,
    bootstrap_logins_at_url,
    bootstrap_roles_at_url,
    drop_roles_at_url,
)

_ADMIN_URL_VAR = "RISK_MODEL_DB_ADMIN_URL"
# Владелец таблиц в `public` до переноса: без членства в нём миграция не сможет их перенести.
_LEGACY_OWNER_VAR = "POSTGRES_USER"
_PASSWORD_VARS = {
    "profile": "RISK_MODEL_DB_PROFILE_PASSWORD",
    "calculation": "RISK_MODEL_DB_CALCULATION_PASSWORD",
    "ehr": "RISK_MODEL_DB_EHR_PASSWORD",
    "bulk_recalc": "RISK_MODEL_DB_BULK_RECALC_PASSWORD",
    "migrations": "RISK_MODEL_DB_MIGRATIONS_PASSWORD",
}


def _secret_from_env(var: str) -> SecretStr:
    """`<VAR>_FILE` приоритетнее `<VAR>`: docker secret не виден в `docker inspect`."""
    path = os.getenv(f"{var}_FILE")
    if path:
        return SecretStr(Path(path).read_text(encoding="utf-8").strip())
    return SecretStr(os.getenv(var, ""))


def _role_password_file(value: str) -> tuple[str, SecretStr]:
    """`NAME=PASSWORD_FILE` → имя логина и пароль из файла. Путь, а не сам пароль: аргументы
    командной строки видны в `ps` и в истории шелла."""
    name, separator, path = value.partition("=")
    if not separator or not name or not path:
        raise argparse.ArgumentTypeError(f"expected NAME=PASSWORD_FILE, got '{value}'")
    if name not in SELECTABLE_LOGIN_ROLES:
        raise argparse.ArgumentTypeError(
            f"unknown login '{name}', expected one of: {', '.join(SELECTABLE_LOGIN_ROLES)}"
        )
    try:
        password = Path(path).read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise argparse.ArgumentTypeError(f"cannot read password file for '{name}': {exc.strerror}") from exc
    if not password:
        raise argparse.ArgumentTypeError(f"password file for '{name}' is empty")
    return name, SecretStr(password)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--drop-roles",
        action="store_true",
        help="снять роли после alembic downgrade вместо выдачи; объекты с данными не трогает",
    )
    mode.add_argument(
        "--role",
        action="append",
        type=_role_password_file,
        metavar="NAME=PASSWORD_FILE",
        help=f"завести или обновить только этот логин; ключ повторяется. Логины: {', '.join(SELECTABLE_LOGIN_ROLES)}",
    )
    parser.add_argument(
        "--shared-login",
        metavar="LOGIN",
        help="только при полном прогоне: дать LOGIN право переключаться в остальные рантайм-логины "
        "(режим общего логина, стенд тестирования)",
    )
    arguments = parser.parse_args()
    if arguments.shared_login is not None and (arguments.drop_roles or arguments.role):
        parser.error("--shared-login is only valid for the full bootstrap run")

    admin_url = os.getenv(_ADMIN_URL_VAR, "")
    if not admin_url:
        print(f"{_ADMIN_URL_VAR} is not set", file=sys.stderr)
        return 2

    if arguments.drop_roles:
        asyncio.run(drop_roles_at_url(admin_url))
        print("Database roles are dropped.")
        return 0

    if arguments.role:
        names = [name for name, _ in arguments.role]
        duplicated = sorted({name for name in names if names.count(name) > 1})
        if duplicated:
            parser.error(f"--role repeats login: {', '.join(duplicated)}")
        asyncio.run(bootstrap_logins_at_url(admin_url, dict(arguments.role)))
        print(f"Database logins are up to date: {', '.join(names)}.")
        return 0

    credentials = RoleCredentials(**{field: _secret_from_env(var) for field, var in _PASSWORD_VARS.items()})

    asyncio.run(
        bootstrap_roles_at_url(
            admin_url,
            credentials,
            legacy_owner=os.getenv(_LEGACY_OWNER_VAR) or None,
            shared_login=arguments.shared_login,
        )
    )
    print("Database roles are up to date.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
