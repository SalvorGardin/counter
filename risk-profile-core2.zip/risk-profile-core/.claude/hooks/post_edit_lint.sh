#!/usr/bin/env bash
# PostToolUse hook: даёт агенту немедленный red-сигнал по только что отредактированному файлу,
# чтобы он сам исправлял проблемы ДО ревью (in-loop feedback). Зеркалит самые частые находки
# из docs/conventions/review-conventions.md, которые ловятся детерминированно.
#
# Использует те же make-цели, что и CI/разработчик (единый источник правды):
#   - migrations/versions/*.py  -> make lint-migrations ARGS=<file>
#     (старая цепочка versions_old/ удалена из дерева;
#     если восстановишь её, добавь обратно в глоб ниже)
#   - src|scripts/**/*.py        -> make lint-ruff ARGS=<file>  +  make lint-logger
#
# Контракт hook-а: при exit code 2 stderr возвращается агенту как блокирующая обратная связь.
# Любой другой ненулевой код — некритичная ошибка самого hook-а (не блокирует).

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT" || exit 0

# Путь отредактированного файла приходит в JSON на stdin (tool_input.file_path).
payload="$(cat)"
file_path="$(printf '%s' "$payload" | jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null)"
[ -z "$file_path" ] && exit 0

# Нормализуем к пути относительно репозитория для матчинга и передачи в make.
rel="${file_path#"$REPO_ROOT"/}"

case "$rel" in
  *.py) : ;;
  *) exit 0 ;;  # интересуют только Python-файлы
esac

findings=""

case "$rel" in
  migrations/versions/*.py)
    out="$(make -s lint-migrations ARGS="$rel" 2>&1)" || findings+="$out"$'\n'
    ;;
  src/*.py|scripts/*.py)
    if out="$(make -s lint-ruff ARGS="$rel" 2>&1)"; then :; else findings+="$out"$'\n'; fi
    # check_logger_info сканирует весь src/scripts — показываем, только если виноват этот файл.
    if out="$(make -s lint-logger 2>&1)"; then :; else
      printf '%s' "$out" | grep -qF "$rel" && findings+="$out"$'\n'
    fi
    ;;
esac

if [ -n "${findings//[$'\n\t ']/}" ]; then
  {
    echo "Хук post_edit_lint нашёл проблемы в $rel — поправь до завершения задачи:"
    echo
    # Отбрасываем собственные служебные строки make (`make: *** [...] Error N`).
    printf '%s\n' "$findings" | grep -vE '^make(\[[0-9]+\])?: \*\*\*'
  } >&2
  exit 2
fi

exit 0
