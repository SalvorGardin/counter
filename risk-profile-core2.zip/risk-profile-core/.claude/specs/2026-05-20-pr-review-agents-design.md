# PR Review Multi-Agent System — Design

Date: 2026-05-20
Status: approved, ready for implementation

Implements `pr-review-agents-spec.md` for this project: 5 cohesive LLM review
agents + 1 orchestrator agent, integrated with the project's `.claude/rules/`,
layer architecture, and GitLab MR workflow.

## Goals

- Tiered review: deterministic tooling (Tier 1) gates LLM judgment agents (Tier 2).
- 5 agents grouped by analytical lens (not criterion count), per spec §4.
- One reconciled, ranked review posted as inline comments to the GitLab MR.
- All findings tied to project rules (`.claude/rules/*.md`) where applicable.

## Non-goals

- No UI/accessibility review (backend-only project).
- Lens agents never post to GitLab — only the orchestrator posts.
- No new tooling: reuse existing `uv run ruff/ty/bandit/semgrep`.

## Decisions (from brainstorming)

- **Orchestrator form:** a dedicated agent (`pr-review-orchestrator.md`) holding
  the gate + fan-out + aggregation runbook. Because Claude Code subagents cannot
  spawn subagents, the main thread performs the parallel fan-out by following the
  orchestrator runbook; the orchestrator agent owns aggregation + posting.
- **Target & output:** review a GitLab MR; orchestrator posts inline comments to
  `gitlab.tywys.ru` project `risk-profile/risk-profile-core`. Lens agents only
  analyze and return structured findings.
- **Post threshold:** post only 🔴 blockers and ⚠️ warnings inline. 💡 suggestions
  go to the chat overview only (matches `mr-reviewer`).
- **Tier 1 gating:** hard gate — if ruff/ty/bandit/semgrep fail on changed files,
  stop and report; do not spend agent tokens (spec §6.1).
- **Language:** English, concise human-engineer tone (matches `code-reviewer`).

## Artifacts

All in `.claude/agents/`, prefixed `pr-` to avoid collision with existing
`code-reviewer`, `mr-reviewer`, `security-auditor`, `perf-optimizer`.

| File | Spec agent | Criteria | Rules wired |
|---|---|---|---|
| `pr-security-privacy.md` | Agent 1 | #1, #19, #20 (boundary), #13, #24 | `security.md`, `api-conventions.md` |
| `pr-quality.md` | Agent 2 | #2, #4, #16, #22 | `code-style.md`, `linting.md` |
| `pr-architecture.md` | Agent 3 | #3, #6, #11, #15, #23 | `architecture.md`, `api-conventions.md` |
| `pr-reliability.md` | Agent 4 | #5, #7, #10, #12, #17, #18, #21 + migrations | `error-handling.md`, `dependencies.md`, `architecture.md`, postgres-migrations skill |
| `pr-testing-obs.md` | Agent 5 | #9, #8, #25 | `testing.md`, `error-handling.md` |
| `pr-review-orchestrator.md` | Orchestrator | gate/fan-out/aggregate/post | all of the above |

Tier 1 (tooling-owned) criteria: #14 dependency hygiene, raw complexity/duplication/
dead-code/coverage/secret-scan — handled by `uv run` tools, fed to agents as context.

## Lens agent contract

- **Frontmatter:** `name`, `description` (with trigger examples), `tools: Bash, Read,
  Grep, Glob`, `model: sonnet`, `color`.
- **Behavior:** read full changed files (not just diff), trace callers/types, check
  against assigned criteria + rules. Analyze only — never call `glab`, never post.
- **Output:** structured findings block so the orchestrator can dedupe mechanically:

```
[🔴|⚠️|💡] criterion=#<n> file=<path> line=<n> confidence=<high|low>
<one-line problem → concrete fix>
```

  `confidence=low` = the spec §5 "flag-and-defer pointer": an agent raising an issue
  outside its lane marks it low so the owning agent's verdict wins.

- **Memory footer:** like `code-reviewer`, record recurring patterns/anti-patterns/
  risky zones to agent memory across reviews.

### Per-agent lens summaries

- **pr-security-privacy:** trust boundaries, attack surface, authz vs authn, input
  validation at the API boundary (Pydantic), secrets in config/env, PII in logs.
  Hard-catches from `security.md`: hardcoded secrets, SQL injection, unmasked PII
  logging, auth bypass.
- **pr-quality:** justify (not re-count) tool complexity flags, real duplication,
  docs/changelog gaps, stale feature flags. Catches `code-style.md` violations not
  covered by formatter (missing type hints, mapping libraries, sync-without-reason).
- **pr-architecture:** layer conformance routers→handlers→services→infra, dependency
  direction (domain independent of API/infra), API contract stability + backwards
  compat, change blast radius. Hard-catches from `architecture.md`/`api-conventions.md`:
  business logic in routers/repos, infra leaking into domain, DI libraries, missing
  `response_model=`, manual parsing instead of Pydantic.
- **pr-reliability:** runtime under load/failure/real data — performance, error
  handling (no swallowed exceptions per `error-handling.md`), DB/data layer + repository
  pattern, concurrency/races, resource lifecycle, idempotency/retry, scalability,
  Alembic migration safety (lock behavior, online-safe, ordering; migrations invoked
  via CLI/Makefile not app code per `dependencies.md`; consult postgres-migrations skill).
- **pr-testing-obs:** test quality not just coverage % (`testing.md`: `dependency_overrides`
  not mocks, no over-mocking, no redundant cases), logging/metrics/tracing adequacy,
  correctness traps (money/float, datetime/tz, encoding, locale, rounding) — the bugs
  that should have had a test and a log line.

## Orchestrator runbook

The orchestrator agent's instructions are a runbook the main thread executes:

1. **Sync:** `git fetch`; `glab mr checkout <iid> -R risk-profile/risk-profile-core`;
   `pull --ff-only`. Local edits / merge conflict → stop, report one line.
2. **Tier 1 hard gate** on changed files, via `uv run`:
   `ruff check` → `ty check` → `bandit -r src/ -c pyproject.toml` →
   `semgrep scan --config auto src/`. Any failure → stop, report failures, do not
   fan out agents.
3. **Diff + refs:** `glab mr diff <iid>`; capture `diff_refs` (`base_sha`,
   `start_sha`, `head_sha`) for inline positions; also `web_url`, `changes_count`.
4. **Fan out** the 5 lens agents in parallel, each given diff + its context budget
   (spec §4) + relevant rules + Tier 1 output as context.
5. **Aggregate:**
   - Dedupe: same root cause from multiple agents → one finding.
   - Reconcile severity: take max, record dissent (don't average).
   - Resolve seams via spec §5 ownership table (input-validation vs data-integrity;
     API contract vs migration; secrets-in-config vs secrets-in-logs; dead-code vs
     stale-flags). Owner's verdict wins; the other's low-confidence pointer is dropped
     or merged.
   - Rank: blockers → should-fix → nits.
6. **Post** only 🔴/⚠️ inline via `glab api` discussions with text position (the
   `mr-reviewer` recipe):

```bash
glab api -X POST "projects/risk-profile%2Frisk-profile-core/merge_requests/<iid>/discussions" \
  -f "position[position_type]=text" \
  -f "position[base_sha]=<base_sha>" -f "position[start_sha]=<start_sha>" \
  -f "position[head_sha]=<head_sha>" \
  -f "position[new_path]=<file>" -f "position[old_path]=<file>" \
  -f "position[new_line]=<line>" \
  -f "body=🔴 ... | ⚠️ ..."
```

   One `glab api` per inline; first 4xx → stop, report.
7. **Chat overview** (4–8 lines): 🔴/⚠️ counts + MR URL, 1–3 main themes, 💡
   suggestions (not posted), Tier 1 + deps one-liner.

## Risks / preconditions

- **glab host not configured:** `glab auth status` shows only `gitlab.com` (401).
  Posting to `gitlab.tywys.ru` requires `glab auth login --hostname gitlab.tywys.ru`
  with a token. Orchestrator file documents this precondition; live posting fails
  without it. Analysis/aggregation still work offline.
- All `glab` calls use `-R risk-profile/risk-profile-core` to avoid hitting the
  default gitlab.com.

## Testing / verification

- Lint the six new markdown files for valid frontmatter (name/description/tools).
- Dry-run the orchestrator runbook against an existing MR without the final
  `glab api` POST to confirm gate + fan-out + aggregation produce a sane report.
- Confirm lens agents never emit `glab` calls.
