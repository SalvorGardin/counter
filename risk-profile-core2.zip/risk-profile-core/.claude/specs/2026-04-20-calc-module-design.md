# Calc Module Design

**Date:** 2026-04-20
**Status:** Approved

## Overview

A calculation engine that, given a list of patient IDs, runs all instruments against each patient's parameters and upserts the resulting scores into the `results` table. The entry point is a plain async handler — no HTTP trigger yet, that comes later.

---

## Input / Output

- **Input:** `list[int]` — patient IDs
- **Output:** nothing (fire-and-forget, writes to DB)
- **Side effects:** upserted rows in `results`, warning logs for skipped instruments

---

## Module Layout

```
src/calc/
├── handler.py          # entry point — orchestrates, owns error logging
├── domain/
│   ├── service.py      # pure domain logic — presence check, validity check, transform
│   └── formula.py      # stub formula — isolated for future replacement
└── infra/
    └── repository.py   # all DB access — load queries + upsert
```

No `__init__.py` barrel exports — import from full paths.

---

## Classes and Responsibilities

### `CalcHandler` (`handler.py`)
- Single public method: `async def run(patient_ids: list[int]) -> None`
- Owns the session lifecycle (receives `AsyncSession` via constructor)
- Calls repo to load data, iterates patient × instrument, delegates to service + formula, calls repo to save
- Logs warning (with `patient_id`, `instrument_id`, `parameter_id`) on validity error; continues to next instrument
- **Per-patient transaction (Level 2):** each patient's upserts run inside their own transaction; a failure on one patient rolls back only that patient's partial results and does not affect others
- **Per-`(patient, instrument)` catch (Level 1):** unexpected exceptions inside the inner loop are caught, logged as error with full context (`patient_id`, `instrument_id`, `exc`), and the loop continues to the next combination
- At the end of `run()`, logs a summary: patients processed, instruments skipped (validity/presence), `(patient, instrument)` pairs that raised exceptions

### `CalcService` (`domain/service.py`)
- `def check_presence(patient_param_ids: set[int], required_ids: list[int]) -> bool`
  - Returns `True` if all required parameter IDs exist in the patient's loaded parameters
  - Returns `False` silently — not an error, instrument simply doesn't apply
- `def check_validity(params: dict[int, str | None], required_ids: list[int]) -> list[int]`
  - Returns list of parameter IDs whose value is `NULL`
  - Caller (handler) decides what to do with them (log + skip)
- `def transform(params: dict[int, str | None], required_ids: list[int]) -> dict[int, str]`
  - Filters to required parameters only, returns `{parameter_id: value}` dict
  - Only called after validity check passes (no nulls guaranteed at this point)

### `Formula` (`domain/formula.py`)
- `def calculate(params: dict[int, str]) -> float`
- **Stub:** ignores input, returns `0.0`
- Comment inside: `# TODO: replace with real formula logic`

### `CalcRepository` (`infra/repository.py`)
- `async def load_patient_parameters(patient_ids: list[int]) -> list[PatientParameterRow]`
  - `SELECT * FROM patient_parameters JOIN parameters USING (parameter_id)`
  - `WHERE patient_id = ANY(:ids) AND expiration_date > now()`
  - Returns all rows including those with `NULL` value
  - Comment: `# TODO: prune JOIN columns once it's clear which parameters fields are needed`
- `async def load_instruments_parameters() -> dict[int, list[int]]`
  - `SELECT instrument_id, parameter_id FROM instruments_parameters`
  - Returns `{instrument_id: [parameter_id, ...]}`
- `async def upsert_result(patient_id: int, instrument_id: int, score: float, expiration_days: int) -> None`
  - INSERT ... ON CONFLICT (patient_id, instrument_id) DO UPDATE
  - Sets `result = score`, `date = now()`, `expiration_date = now() + interval 'N days'`

---

## Data Models

```python
class PatientParameterRow(BaseModel):
    # from patient_parameters
    patient_parameter_id: int
    patient_id: int
    parameter_id: int
    value: str | None
    source: str | None
    expiration_date: datetime

    # from parameters (JOIN — prune unused fields later)
    code: str
    description: str | None
    validity_period: datetime | None
    status: str
```

---

## Data Flow (detailed)

```
handler.run(patient_ids)
  │
  ├─ repo.load_patient_parameters(patient_ids)
  │    groups result by patient_id → dict[int, list[PatientParameterRow]]
  │
  ├─ repo.load_instruments_parameters()
  │    → dict[instrument_id → list[parameter_id]]
  │
  └─ for patient_id, patient_rows in grouped:
       try:
         async with session.begin():                        # Level 2: per-patient transaction
           patient_param_ids = {row.parameter_id for row in patient_rows}
           patient_values    = {row.parameter_id: row.value for row in patient_rows}

           for instrument_id, required_ids in instruments_parameters.items():
             try:                                           # Level 1: per-(patient, instrument) catch
               if not service.check_presence(patient_param_ids, required_ids):
                   continue  # instrument not applicable, silent skip

               null_ids = service.check_validity(patient_values, required_ids)
               if null_ids:
                   logger.warning("null parameter values", patient_id=..., instrument_id=..., parameter_ids=null_ids)
                   continue

               params = service.transform(patient_values, required_ids)
               score  = formula.calculate(params)
               await repo.upsert_result(patient_id, instrument_id, score, settings.result_expiration_days)

             except Exception:
               logger.error("instrument calc failed", patient_id=..., instrument_id=..., exc_info=True)
               # continues to next instrument; transaction still active

       except Exception:
         logger.error("patient batch failed", patient_id=..., exc_info=True)
         # per-patient transaction rolled back; continues to next patient

  logger.info("calc run complete", processed=N, skipped=M, failed=P)
```

---

## Configuration

Add to `src/config.py` (pydantic-settings):

```python
result_expiration_days: int = 30
```

---

## Error Handling

| Situation | Level | Behavior |
|---|---|---|
| Required parameter missing from patient | — | Silent skip (instrument doesn't apply) |
| Required parameter present but value is NULL | — | Log warning with context, skip instrument |
| Unexpected exception in `(patient, instrument)` loop | 1 | Log error with full context, continue to next instrument; patient transaction still active |
| Unexpected exception at patient level (e.g. DB failure mid-patient) | 2 | Log error, roll back that patient's transaction, continue to next patient |
| Exception during initial data load (before patient loop) | — | Propagate — nothing has been written, caller handles |

**Retry story:** since all writes are upserts, the entire `run()` call is idempotent. Failed patients can be re-submitted by passing their IDs again — no special recovery mechanism needed.

---

## Testing

- `CalcService` — pure unit tests, no DB, no mocks needed
- `Formula` — trivial unit test (stub returns 0.0)
- `CalcRepository` — integration tests with testcontainers PostgreSQL
- `CalcHandler` — integration test with testcontainers: seed patient_parameters + instruments_parameters, run handler, assert results rows upserted correctly; assert warning logged on null-value case; assert one bad patient does not prevent others from being saved (Level 2 isolation)
