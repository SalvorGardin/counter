# Calc Module Refactor

**Date:** 2026-04-24
**Branch:** feature/instrument_calculators
**Status:** Implemented
**Supersedes:** 2026-04-20-calc-module-design.md

---

## Overview

Refactor of the calc module to introduce typed domain contracts, split read/write DB layers, move instrument-level logic into `Formula`, and write previous results to history on every upsert.

---

## Module Layout

```
src/calc/
├── handler.py              # orchestration only — no business logic
├── domain/
│   ├── models.py           # all intermediate types and InstrumentInput.build()
│   └── formula.py          # Formula dispatcher + per-instrument stubs
└── infra/
    ├── reader.py           # read-only DB queries, returns domain objects
    └── repository.py       # write-only — upsert result + archive to history
```

`CalcService` removed — logic absorbed into `InstrumentInput.build()`.

---

## Data Contracts (`domain/models.py`)

```python
class PatientParameterRow(BaseModel):
    patient_parameter_id: int
    patient_id: int
    parameter_code: str
    value: str | None       # None possible; build() treats it as missing
    source: str | None
    expiration_date: datetime

class InstrumentDefinition(BaseModel):
    instrument_code: str
    required_parameter_codes: list[str]

class InstrumentInput(BaseModel):
    instrument_code: str
    patient_id: int
    params: dict[str, str]  # guaranteed non-None after build()

    @classmethod
    def build(
        cls,
        definition: InstrumentDefinition,
        patient_values: dict[str, str | None],
        patient_id: int,
    ) -> "InstrumentInput | None":
        # Returns None if any required code is absent or has None value.

class FormulaResult(BaseModel):
    instrument_code: str
    patient_id: int
    score: float | None
    unit: int | None
    risk_level: str | None      # "low" | "medium" | "high" | None
    applicability: bool
    interpretation_status: str  # "ready" | "not_required"
    expiration_delta: timedelta # repo stamps absolute expiration_date = now() + delta
    # date is NOT here — repo stamps it at write time
    # FormulaResult is intentionally deterministic in its inputs: no `now()` calls.
    # This is what enables the repository's idempotent short-circuit on retry.
```

---

## Result Field Semantics

| Field | Calculated | Not applicable |
|---|---|---|
| `score` | formula output | `None` |
| `unit` | fixed per formula | `None` |
| `risk_level` | derived by formula from score | `None` |
| `applicability` | `True` | `False` |
| `interpretation_status` | `"ready"` | `"not_required"` |
| `expiration_delta` | `timedelta(100y)` | `timedelta(100y)` |
| `expiration_date` | stamped by repo at write (`now() + delta`) | stamped by repo at write (`now() + delta`) |
| `date` | stamped by repo at write | stamped by repo at write |

---

## Formula (`domain/formula.py`)

`Formula` is a dispatcher. Each instrument has its own internal implementation registered by `instrument_code`. All coefficients and thresholds live inside the per-instrument function — not in the DB, not in config.

```python
class Formula:
    def is_applicable(self, input: InstrumentInput) -> bool:
        # Dispatches to per-instrument applicability check.
        # May inspect any field in input.params (e.g. age range check).

    def calculate(self, input: InstrumentInput) -> FormulaResult:
        # Dispatches to per-instrument calculation.
        # Returns full FormulaResult including unit, risk_level, expiration_date.

    def make_dummy(self, input: InstrumentInput) -> FormulaResult:
        # Shared: returns applicability=False, interpretation_status="not_required".
        # expiration_date = now() + 100 years.
```

Unknown `instrument_code` is not possible — instrument configs are only loaded for instruments that exist in the DB, and every active instrument must have a corresponding formula.

---

## Read Layer (`infra/reader.py`)

Stateless. Uses SQLAlchemy ORM `select()` — no raw `text()` queries.

```python
class CalcReader:
    async def load_instrument_configs(self) -> dict[str, InstrumentDefinition]
    # SELECT instruments_parameters JOIN instruments WHERE status = 'active'
    # Returns only active instruments. Called once per run, result held by handler.

    async def load_patient_parameters(self, patient_ids: list[int]) -> list[PatientParameterRow]
    # SELECT patients_parameters WHERE patient_id IN (...) AND expiration_date > now() AND value IS NOT NULL
    # Null-value rows excluded at DB level (treat null value == parameter absent for calculation).
```

`load_instrument_configs` is **not cached** on `CalcReader` — it is called once at the start of `handler.run()` and the result is held in a local variable for the duration of the run.

---

## Write Layer (`infra/repository.py`)

```python
class CalcRepository:
    async def upsert_result(self, result: FormulaResult) -> None:
        # 1. SELECT existing result row (if any)
        # 2. If existing matches the new result on stable fields
        #    (score, unit, risk_level, applicability, interpretation_status):
        #    return early — idempotent short-circuit. No history insert, no upsert.
        # 3. Else, if existing is non-null: INSERT existing row into results_history
        # 4. UPSERT into results (ON CONFLICT patient_id + instrument_code DO UPDATE)
        # Stamps date = now() and expiration_date = now() + result.expiration_delta.
        # Must be called within an active transaction managed by the caller.
```

All changes to `results` (both calculated and dummy) produce a history entry on overwrite. Identical re-writes (e.g. a retry after a dropped commit ack) are absorbed by the equality short-circuit and produce no history row.

---

## Retry & Transaction Layer

Located at `src/infra/db_retry.py`. Generic, not calc-specific — reusable by any handler that needs classify-and-retry semantics around a write.

```python
class TransactionalRetryExecutor:
    def __init__(
        self,
        session: AsyncSession,
        *,
        max_attempts: int = 3,
        backoff_base_s: float = 0.1,
        retriable: tuple[type[BaseException], ...] = (OperationalError, InterfaceError),
    ) -> None: ...

    async def run(self, op: Callable[..., Awaitable[T]], *args, **kwargs) -> T:
        # Each attempt opens its own `session.begin()`.
        # On retriable error → roll back, sleep with exponential backoff, retry.
        # On non-retriable → raise NonRetriableDbError immediately.
        # On exhaustion → raise RetriableDbError.
```

Exception hierarchy surfaced to callers (SQLAlchemy types stay inside the module):

```python
class DbOperationError(Exception):
    cause: BaseException
    attempts: int

class RetriableDbError(DbOperationError): ...      # retries exhausted
class NonRetriableDbError(DbOperationError): ...   # not eligible for retry
```

Default classification:
- **Retriable:** `OperationalError`, `InterfaceError` (covers deadlocks, serialization failures, connection drops).
- **Non-retriable:** everything else (`IntegrityError`, `DataError`, `ProgrammingError`, `ValueError`, …).

Each `upsert_result` call runs in its **own** transaction. There is no patient-level transaction. A failure on one `(patient, instrument)` pair never affects any other.

---

## Handler Flow (`handler.py`)

```
handler.run(patient_ids)
  │
  ├─ configs = reader.load_instrument_configs()     # once, all active instruments
  ├─ rows = reader.load_patient_parameters(ids)     # once, all valid params
  ├─ group rows → dict[patient_id, dict[code, value]]
  ├─ session.commit()                               # end read transaction
  │
  └─ for patient_id, patient_values in grouped:
       for instrument_code, definition in configs.items():
         input = InstrumentInput.build(definition, patient_values, patient_id, is_pregnant)
         if input is None:
             skipped += 1; continue          # missing or null params — no DB write

         result = formula.calculate(input) if formula.is_applicable(input) else formula.make_dummy(input)

         try:
           await executor.run(repo.upsert_result, result)   # own transaction, classify-and-retry
         except DbOperationError as e:
           logger.error("upsert failed", attempts=e.attempts, kind=type(e).__name__)
           failed += 1
         else:
           processed += 1

  logger.info("calc run complete", processed=N, skipped=M, failed=P)
```

Patients absent from `grouped` (all params missing or expired) are silently ignored — no result written, not counted. Domain/formula errors propagate (they are programming bugs, not data conditions); they are not silently counted as `failed`.

---

## Error Handling

| Situation | Behavior |
|---|---|
| Required param missing or null | `build()` returns `None` — silent skip, no DB write |
| Instrument domain rule fails | `make_dummy()` written — `applicability=False` |
| `DbOperationError` from executor (retriable exhausted or non-retriable) | Log (with `attempts` and `kind`), count `failed`, continue to next `(patient, instrument)` pair |
| Domain/formula bug (non-DB exception) | Propagate — surfaces in tests; not silently counted as `failed` |
| Exception before patient loop (reader phase) | Propagate — nothing written, caller handles |

**Idempotency.** The executor provides at-least-once delivery (transient errors trigger retry). The op underneath is content-idempotent: `upsert_result` short-circuits when the existing `results` row already matches the formula's stable output (`score`, `unit`, `risk_level`, `applicability`, `interpretation_status`). So a post-commit retry caused by a dropped connection does **not** produce a phantom `results_history` row. `expiration_date` and `date` are excluded from the equality check — they are write-time bookkeeping, not part of the result identity, and re-stamping them on a no-op retry is intentionally avoided by the short-circuit. Passing the same `patient_ids` again is safe.

---

## Testing

| Layer | Type | Notes |
|---|---|---|
| `InstrumentInput.build()` | Unit | No DB, no mocks — pure logic |
| `CalcReader` | Integration (testcontainers) | Covers active/inactive filter, expired/null exclusion |
| `CalcRepository` | Integration (testcontainers) | Covers insert, overwrite, history archival |
| `CalcHandler` | Integration (testcontainers) | Happy path, skipping, isolation between patients |
