# DB Setup & Migrations — Design Spec

**Date:** 2026-04-13  
**Branch:** feature/db_setup  
**Status:** Approved

---

## Goal

Add minimal PostgreSQL support to the Risk Model service: async SQLAlchemy engine, session factory, Alembic migration scaffolding, and a `make migrate` command. No tables yet — this is infrastructure only.

---

## Dependencies to Add

```
sqlalchemy[asyncio]
asyncpg
alembic
```

Added to `[project.dependencies]` in `pyproject.toml`.

---

## Configuration (`src/config.py`)

Add `db_url: str` to `Settings`:

```python
db_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/risk_model"
```

Env var: `RISK_MODEL_DB_URL` (consistent with existing `RISK_MODEL_` prefix).  
`.env.example` gets a blank `RISK_MODEL_DB_URL=` entry.

---

## Infra Layer (`src/infra/database.py`)

Single module containing:

- `create_async_engine(settings.db_url, pool_size=5, max_overflow=10)`
- `async_session_factory = async_sessionmaker(engine, expire_on_commit=False)`
- `Base = DeclarativeBase()` — single metadata source for all models and Alembic
- `get_session()` — async generator for FastAPI `Depends()`

Pool settings are hardcoded defaults; not configurable via env for now.

---

## Application Lifespan (`src/main.py`)

Replace the current no-lifespan app with a `@asynccontextmanager` lifespan that disposes the engine on shutdown:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await engine.dispose()

app = FastAPI(title="Risk Model Service", lifespan=lifespan)
```

No startup logic needed yet (SQLAlchemy creates connections lazily).

---

## Alembic Setup

| File | Purpose |
|---|---|
| `alembic.ini` | Standard config; `script_location = migrations` |
| `migrations/env.py` | Async-capable env using `run_sync`; imports `Base.metadata` from `src.infra.database` |
| `migrations/script.py.mako` | Default Alembic template |
| `migrations/versions/` | Empty, ready for first `alembic revision` |

`sqlalchemy.url` in `alembic.ini` is set to a placeholder — actual URL is read from `settings.db_url` in `migrations/env.py` to avoid duplication.

---

## Makefile

Add `migrate` target:

```makefile
migrate:
    alembic upgrade head
```

---

## What This Does NOT Include

- No models / tables (first migration comes later)
- No testcontainers or DB fixtures in tests (no DB-touching code yet)
- No connection pool env-var configuration
- No health check that pings the DB (can be added later to `/readiness`)
