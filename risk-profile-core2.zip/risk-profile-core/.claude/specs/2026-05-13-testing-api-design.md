# Testing API Design

**Date:** 2026-05-13
**Branch:** feature/questionaire_calculation
**Purpose:** CRUD endpoints for test data management + a calculation trigger endpoint, mounted conditionally behind an env flag and a static token header.

---

## Scope

Five resource groups under a single `testing` domain:

| Resource | Table |
|---|---|
| patients | `patients` |
| instruments | `instruments` |
| parameters | `parameters` |
| patient_parameters | `patients_parameters` |
| calculation | `results` (read-only trigger) |

---

## Mounting & Configuration

`main.py` conditionally includes the testing router:

```python
if settings.testing_api_enabled:
    app.include_router(testing_router)
```

Two new fields in `config.py` (pydantic-settings, loaded from env):

```python
testing_api_enabled: bool = False        # TESTING_API_ENABLED
test_api_key: str = ""                   # TEST_API_KEY
```

URL prefix: `/api/v1/testing`

---

## Authentication

File: `src/api/v1/testing/auth.py`

FastAPI dependency `verify_test_token` reads `X-Test-Api-Key` header, compares against `settings.test_api_key` using constant-time comparison (`secrets.compare_digest`). Returns 401 envelope on mismatch or missing header.

Applied as `dependencies=[Depends(verify_test_token)]` on each sub-router — not per-endpoint.

---

## Endpoints

All endpoints use the project's standard `ErrorEnvelope` / `common_responses` for 400/404/500.

### Patients — `/api/v1/testing/patients`

| Method | Path | Status | Description |
|---|---|---|---|
| POST | `/` | 201 | Create patient |
| GET | `/` | 200 | List all patients |
| GET | `/{patient_id}` | 200 | Get by `patient_id` (string, not PK) |
| PUT | `/{patient_id}` | 200 | Replace patient |
| DELETE | `/{patient_id}` | 204 | Delete patient |

`patient_id` in the path is the business key (`patients.patient_id: str`), not `unique_id`.

Request/response fields: `patient_id: str`, `is_pregnant: bool`.

### Instruments — `/api/v1/testing/instruments`

| Method | Path | Status | Description |
|---|---|---|---|
| POST | `/` | 201 | Create instrument |
| GET | `/` | 200 | List all instruments |
| GET | `/{code}` | 200 | Get by `code` |
| PUT | `/{code}` | 200 | Replace instrument |
| DELETE | `/{code}` | 204 | Delete instrument |

Fields: `code: str`, `description: str`, `type: str`, `status: str`, `diseases: str | None`.

### Parameters — `/api/v1/testing/parameters`

| Method | Path | Status | Description |
|---|---|---|---|
| POST | `/` | 201 | Create parameter |
| GET | `/` | 200 | List all parameters |
| GET | `/{code}` | 200 | Get by `code` |
| PUT | `/{code}` | 200 | Replace parameter |
| DELETE | `/{code}` | 204 | Delete parameter |

Fields: `code: str`, `description: str`, `status: str`, `validity_period: datetime`.

### Patient Parameters — `/api/v1/testing/patient-parameters`

| Method | Path | Status | Description |
|---|---|---|---|
| POST | `/` | 201 | Create patient parameter |
| GET | `/` | 200 | List all (optional `?patient_id=` filter) |
| GET | `/{patient_parameter_id}` | 200 | Get by PK |
| PUT | `/{patient_parameter_id}` | 200 | Replace patient parameter |
| DELETE | `/{patient_parameter_id}` | 204 | Delete by PK |

Fields: `patient_parameter_id: int` (PK, response only), `patient_id: str`, `parameter_code: str`, `value: str | None`, `source: str`, `expiration_date: datetime`.

`patient_id` references `patients.patient_id`; `parameter_code` references `parameters.code`. FK violations surface as 500 (standard unhandled error) — no special handling needed for a testing API.

### Calculation Trigger — `/api/v1/testing/calculation`

| Method | Path | Status | Description |
|---|---|---|---|
| POST | `/run` | 200 | Trigger calculation and return results |

**Request:**
```json
{ "patient_ids": ["p1", "p2"] }
```

**Response:**
```json
[
  {
    "patient_id": "p1",
    "results": [
      {
        "result_id": 1,
        "instrument_code": "SCORE2",
        "value": "3.14",
        "indicator": null,
        "date_time": "2026-05-13T10:00:00Z",
        "interpretation_status": "normal",
        "expiration_date": "2026-06-13T10:00:00Z",
        "risk_level": "low",
        "applicability": true,
        "unit": null
      }
    ]
  }
]
```

- Queries `results` table filtered by the provided `patient_ids`.
- Patients with no results appear in the response with `"results": []`.
- Unknown `patient_ids` (not in `patients` table) are silently included with `"results": []` — no 404, this is a test utility.
- `value` is serialized as a string to preserve `Decimal` precision.

---

## File Layout

```
src/api/v1/testing/
  __init__.py
  auth.py
  patients/
    __init__.py
    router.py
    schemas.py
  instruments/
    __init__.py
    router.py
    schemas.py
  parameters/
    __init__.py
    router.py
    schemas.py
  patient_parameters/
    __init__.py
    router.py
    schemas.py
  calculation/
    __init__.py
    router.py
    schemas.py
```

Each `router.py` instantiates its own `APIRouter` with prefix, tags, and `dependencies=[Depends(verify_test_token)]`. A thin `src/api/v1/testing/__init__.py` aggregates all five sub-routers into one `testing_router` that `main.py` imports.

Repositories: each router receives an `AsyncSession` via `Depends(get_session)` and queries SQLAlchemy models directly — no separate service layer, this is test infrastructure not domain logic.

---

## Error Handling

| Scenario | Response |
|---|---|
| Missing / wrong `X-Test-Api-Key` | 401 `UNAUTHORIZED` envelope |
| Resource not found (GET/PUT/DELETE) | 404 `NOT_FOUND` envelope |
| Validation error (Pydantic) | 400 envelope (existing global handler) |
| DB error / unhandled | 500 envelope (existing global handler) |

No new domain exceptions needed — 404s are raised via `HTTPException(status_code=404)` directly in the router handlers.

---

## Out of Scope

- No pagination on list endpoints (test data sets are small)
- No partial update (PATCH) — PUT replaces the full record
- No auth token rotation or multiple keys
- No audit logging of testing API calls
