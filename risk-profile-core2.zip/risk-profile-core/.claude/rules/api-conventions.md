# API Conventions

- Точка входа — `main.py`, подключение роутеров через `include_router`
- Структура запроса: router → handler → service (domain) → repository (infra)
- Роутеры группируются по доменным областям: `api/v1/{domain}/router.py`
- Десериализация — встроенная через Pydantic, не писать ручной парсинг
- Версионирование API через prefix: `/api/v1/`, `/api/v2/`
- Middleware добавлять через `app.add_middleware()` в main.py
- Конфигурация приложения — pydantic-settings, загрузка из env / .env файла
- Response-модели указывать явно в декораторе роута: `response_model=SomeSchema`
