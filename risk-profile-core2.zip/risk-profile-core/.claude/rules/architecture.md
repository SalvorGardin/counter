# Architecture

- Слои: routers (API) → handlers → domain services → infra (repositories, clients)
- Зависимости направлены внутрь: API зависит от domain, domain не зависит от API и infra
- DI — вручную через FastAPI `Depends()`, без DI-библиотек
- Код организован по доменным областям, не по техническим слоям
- Внешние интеграции: отдельные клиенты в `infra/`, async httpx
- Repository pattern для доступа к данным — абстракция над SQLAlchemy
- Бизнес-логика — в domain services, не в роутерах и не в repositories
