# Testing

- Фреймворк: pytest, без альтернатив
- Testcontainers допустимы, но приоритет — простота и скорость запуска тестов
- Подмена зависимостей в тестах — через `app.dependency_overrides` (FastAPI DI override)
- Не мокать то, что можно поднять локально (БД через testcontainers, если нужна реальная)
- Структура: `tests/unit/`, `tests/integration/`, общий `conftest.py` в корне `tests/`
- Фикстуры — в conftest.py соответствующего уровня
