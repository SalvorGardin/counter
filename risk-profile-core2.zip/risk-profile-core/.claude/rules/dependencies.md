# Dependencies

- Пакетный менеджер: uv (быстрый, на Rust)
- Система сборки: make — Makefile с основными командами (dev, test, lint, migrate)
- HTTP-клиент: httpx (async) — предпочтительнее requests
- ORM: SQLAlchemy (async) для работы с БД
- Миграции: Alembic — вызывать извне (CLI / Makefile), не из кода приложения
- Конфигурация: pydantic-settings
- Перед добавлением новой зависимости — проверить, нет ли встроенного решения в stdlib или уже подключённых пакетах
