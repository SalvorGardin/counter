# Перезаливка справочников (catalog) миграциями

- Правишь/перезаливаешь `options.value` — в ТОЙ ЖЕ миграции ремапь `patients_parameters.value`
  по `(parameter_code, old_value) → new_value`
  (паттерн `_option_value_renames` / `_remap_patient_answers`, см. 0096/0097/0112). Ответ пациента
  хранится текстом выбранной опции, без ремапа он повисает сиротой. Касается только параметров
  select/boolean-вопросов: multi хранит `Да`/`Нет`, текст опции в БД не попадает. Никогда не
  ремапить пары, где `old` = `Да`/`Нет`. `patients_parameters_history` не трогать: миграции
  правят только живые данные, history — аудитный след (решение ревью !154).
- `parameter_scores.value`, `risk_factors.param_value`, `conditions.value` матчатся с ответами
  пациентов строгим строковым равенством — при переименовании `option.value` эти таблицы должны
  меняться согласованно в том же сиде.
- `parameters.code` не удалять никогда (PII-FK с RESTRICT) — только `status='inactive'`;
  `patients_parameters` не удалять и не «чистить».
- Сид, перезаливающий справочник целиком (`DELETE` + `INSERT`), удаляет строки в порядке от
  зависимых таблиц к родительской: внешние ключи справочника стоят с `RESTRICT`, и `DELETE`
  по родителю упадёт, пока на него кто-то ссылается. Перед перезаливкой сверить актуальный список
  зависимых по `grep -n "ForeignKey" src/models/*.py`, а не по памяти — он растёт. На сегодня:
  `risk_factors.code` ← `recommendations`, `risk_factor_systems`, `risk_factor_triggers`,
  `risk_factor_scores`, `risk_factor_clinrecs`; `systems.code` ← `diseases`, `parameter_scores`,
  `recommended_doctors`, `risk_factor_systems`, `risk_factor_triggers`, `system_instruments`,
  `system_checkup_examinations`; `diseases.code` ← `disease_icd`, `risk_factor_scores`,
  `risk_factor_clinrecs`, `disease_examinations`; `examinations.code` ← `disease_examinations`,
  `system_checkup_examinations`; `clinical_recommendations.code` ← `risk_factor_clinrecs`;
  `questions.code` и `parameters.code` ← `options`; `parameters.code` ← ещё и `biomarkers`,
  `biomarker_parameter_mappings`; `options.code` ← `biomarker_parameter_mappings`.
  Сверх справочника на `diseases.code` ссылаются `results` и `results_history`, на
  `parameters.code` — `patients_parameters` и её история, а на `systems.code` —
  `interpretations` и `interpretations_history`: данные пациентов сид не удаляет, но
  `RESTRICT` они держат так же, и ни группу заболеваний с посчитанными по ней результатами,
  ни систему с сохранённой интерпретацией перезалить нельзя.
- Удаление вопроса/опции → явно проверить судьбу сохранённых ответов и зафиксировать решение
  в докстринге миграции.
- Дублирование новой миграции во вторую цепочку сейчас не требуется — старая цепочка
  (`migrations/versions_old/`) удалена из дерева, цепочка одна.
- Меняешь справочник так, что меняются результаты расчёта или интерпретаций (формулы, пороги,
  состав инструментов, значения, по которым матчатся ответы), — в ТОМ ЖЕ изменении бампни
  `version` в `calculation-version.json`. По нему определяется когорта массового пересчёта
  (`docs/spec-bulk-recalculation.md`): без бампа уже посчитанные профили останутся с прежней
  версией, прогон не найдёт ни одного устаревшего пациента и завершится молча. Автоматической
  проверки здесь нет намеренно: связь «миграция трогает справочник» → «нужен полный пересчёт»
  смысловая, а не структурная, и линтер давал бы ложные срабатывания.
- Прогонять `make lint-migrations ARGS="<новые файлы>"`.
