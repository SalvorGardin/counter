# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Структура проекта

```
src/                  # исходный код сервиса (main.py, logger.py)
tests/                # тесты (pytest)
scripts/              # вспомогательные скрипты (check_licenses.py)
docker/               # Dockerfile
docs/requirements/    # требования к сервисам (разбиты по темам)
.gitverse/workflows/  # CI pipeline (ci.yaml)
.gitverse/pr_rules/   # правила для PR
version.json          # версия модели (обязателен в корне)
pyproject.toml        # зависимости и конфигурация инструментов
```

## Логирование

Полные требования — `docs/requirements/logging.md`. Кратко для разработки:

### Точка входа

Только через `src.logger`. Не пишем `import logging` и не создаём свои `Logger`-ы:

```python
from src.logger import logger, notice, business, alert, emergency
```

### Выбор уровня

| Что | Как |
|-----|-----|
| Бизнес-событие, должно быть в Kibana всегда (questionnaire completed, kafka.publish) | `business("event", context={...})` — INFO + `channel="business"`, мимо fingers-crossed и порога |
| Штатное отклонение, видимое в проде (skip, validation, маршрутизация) | `notice("event", context={...})` — NOTICE, всегда выходит |
| Диагностика для разбора инцидента (per-request milestones) | `logger.debug("...", extra={"log_context": {...}})` — копится в fingers-crossed буфере, выводится только при ERROR+ в том же запросе |
| Некритичная ошибка | `logger.warning("...", extra={"log_context": {...}})` |
| Сбой, бизнес-логика не выполнилась | `logger.error("...", extra={"log_context": {...}})` (+ `exc_info=exc` если есть исключение) |
| Сбой важного компонента / нужно немедленное вмешательство | `alert(...)` / `emergency(...)` |

**В проде по умолчанию пишутся только NOTICE+.** INFO допустим **только** через `business()`. `logger.info(...)` / `logging.info(...)` / `logger.log(logging.INFO, ...)` запрещены в `src/` и `scripts/` — ловится линтером `make lint-logger` (`scripts/check_logger_info.py`).

### Структурированный контекст

- Хелперы (`notice`, `business`, `alert`, `emergency`) — позиционный аргумент `context={...}`.
- Stdlib-уровни (`logger.debug/.warning/.error/.critical`) — `extra={"log_context": {...}}`.
- `requestId` и `authorization` добавляются автоматически из ContextVar-ов — руками класть **не нужно**.

### Запреты по PII

`MonologFormatter` рекурсивно маскирует значения по ключам из env `RISK_MODEL_LOG_MASK_KEYS` (CSV; дефолт — `DEFAULT_LOG_MASK_KEYS` в `src/constants.py`: ПДн + wire-ключи тел + секреты заголовков). Сравнение нормализованное: lowercase без `-`/`_`, так что `birthdate` покрывает `birthDate`/`birth_date`. Тело и заголовки входящего запроса И тело ответа логируются в `request completed` целиком (решение на период тестирования, 06.2026) — маскирование делает формат­тер. `body_for_log`/`_request_body_for_log` ВСЕГДА отдают `dict | None`: JSON-объект как есть, form-urlencoded → dict, не-объектный JSON (скаляр/массив) → `{"_value": ...}`, а сверхлимит/без Content-Length/chunked/plaintext/ошибка → dict-маркер `body_marker()` `{"_omitted": ...}`. Тело ответа (`_response_body_for_log`) симметрично: ответ приходит как `_StreamingResponse` с одноразовым `body_iterator`, поэтому он вычитывается и тут же переустанавливается на повтор прочитанного (`_replay_chunks`) — клиент получает то же тело; буферим только JSON в пределах лимита, прочее → `{"_omitted": ...}` (не-bytes pathsend-чанки проигрываются без искажения, но как тело не пишутся). Это **контракт типа для Elasticsearch**: строковый маркер в одном индексе и объект в другом дали бы `context.request_body type=conflict`, и Kibana спрятала бы поле (инцидент 06.2026). Дальше `_sanitize_context` (после маскировки) сериализует blob-поля `_BLOB_CONTEXT_KEYS` (`request_body`/`response_body`/`request_headers`) в **одну JSON-строку**: объект Kibana не выводит колонкой (ячейка пустая), плюс это убирает mapping explosion от произвольных ключей тел. Цена — по под-полям (`request_body.gender`) фильтровать нельзя, только полнотекст. Секреты (`Authorization`, `X-Test-Api-Key`, `Cookie`) валидатор Settings вливает в маск-лист принудительно — убрать их через env нельзя. Пароли и токены в `context` по-прежнему не кладём руками. Stacktrace в `context["exception"]` не маскируется — не логировать переменные в исключениях.

### Сквозная трассировка

- Каждый запрос имеет `requestId` (uuid v4) — пробрасывается в `extra.requestId` всех логов и в downstream-вызовы как `x-request-id`.
- `X-Enable-Debug` — клиент может включить DEBUG-режим для конкретного запроса; middleware нормализует значение к `"true"`/`""` на границе доверия и пробрасывает в downstream как `x-enable-debug`.
- Фоновые задачи (`BackgroundTasks.add_task`) — оборачивать `with_request_context(task)` (см. `src/logger.py`), иначе теряется `requestId`.

### Fingers-crossed

Внутри HTTP-запроса логи ниже NOTICE копятся в буфере и выводятся только если в этом же запросе случился ERROR+. Для фоновых задач выключено по спеке (риск бесконечного буфера). Подробности — `src/logger.py:FingersCrossedHandler`.