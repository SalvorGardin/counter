"use strict";

const biomarkerState = { choices: [], entries: [] };

function biomarkerHeaders() {
  return { "Content-Type": "application/json", "X-Test-Api-Key": window.TEST_TOKEN };
}

async function biomarkerFetch(path, options = {}) {
  const response = await fetch(`${state.baseUrl}${path}`, { ...options, headers: biomarkerHeaders() });
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail ?? `HTTP ${response.status}`);
  return data;
}

function renderBiomarkerEntries() {
  const list = document.getElementById("biomarker-entries");
  list.replaceChildren(...biomarkerState.entries.map((entry, index) => {
    const item = document.createElement("li");
    item.className = "biomarker-entry";
    const text = document.createElement("span");
    text.textContent = `${entry.biomarkerCode}${entry.unitCode === null ? "" : ` (${entry.unitCode})`}: ${entry.value}`;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "biomarker-remove secondary-btn";
    remove.textContent = "Удалить";
    remove.addEventListener("click", () => { biomarkerState.entries.splice(index, 1); renderBiomarkerEntries(); });
    item.append(text, remove);
    return item;
  }));
}

// Список показателей живёт ровно столько, сколько идёт опрос одного пациента: на новом пациенте
// прежние значения не должны уехать в его карту при первом же сохранении.
function resetBiomarkerEntries() {
  biomarkerState.entries = [];
  const value = document.getElementById("biomarker-value");
  if (value) value.value = "";
  clearError(document.getElementById("biomarker-error"));
  renderBiomarkerEntries();
}

async function openBiomarkerStep() {
  const error = document.getElementById("biomarker-error");
  clearError(error);
  try {
    biomarkerState.choices = await biomarkerFetch("/api/v1/testing/biomarkers");
    const select = document.getElementById("biomarker-choice");
    select.replaceChildren(...biomarkerState.choices.map((choice, index) => {
      const option = document.createElement("option");
      option.value = String(index);
      const mapped = choice.mappedParameterCodes.length ? choice.mappedParameterCodes.join(", ") : "—";
      option.textContent = `${choice.biomarkerCode}${choice.unitCode === null ? "" : ` (${choice.unitCode})`} — ${choice.type}; параметр: ${choice.parameterCode}; влияет: ${mapped}`;
      return option;
    }));
    renderBiomarkerEntries();
    showScreen("biomarkers");
  } catch (err) { showError(error, `Не удалось загрузить биомаркеры: ${err.message}`); showScreen("biomarkers"); }
}

async function continueFromBiomarkers() {
  const data = await postAnswer(null, {}, null);
  await advanceAfterRequest(data, null);
}

// Возврат к шагу биомаркеров с экрана результатов. Внесённые показатели остаются в списке:
// повторное сохранение перезаписывает те же параметры пациента и заново запускает расчёт.
el.editBiomarkersBtn.addEventListener("click", async () => {
  el.editBiomarkersBtn.disabled = true;
  try {
    await openBiomarkerStep();
  } finally {
    el.editBiomarkersBtn.disabled = false;
  }
});

document.getElementById("add-biomarker-btn").addEventListener("click", () => {
  const choice = biomarkerState.choices[Number(document.getElementById("biomarker-choice").value)];
  const value = document.getElementById("biomarker-value").value.trim();
  if (!choice || !value) return showError(document.getElementById("biomarker-error"), "Выберите показатель и введите значение");
  biomarkerState.entries.push({ biomarkerCode: choice.biomarkerCode, unitCode: choice.unitCode, value });
  document.getElementById("biomarker-value").value = "";
  clearError(document.getElementById("biomarker-error"));
  renderBiomarkerEntries();
});

document.getElementById("skip-biomarkers-btn").addEventListener("click", () => continueFromBiomarkers().catch((err) => showError(document.getElementById("biomarker-error"), err.message)));
document.getElementById("submit-biomarkers-btn").addEventListener("click", async () => {
  const error = document.getElementById("biomarker-error");
  if (!biomarkerState.entries.length) return continueFromBiomarkers().catch((err) => showError(error, err.message));
  try {
    await biomarkerFetch("/api/v1/testing/biomarkers/manual", { method: "POST", body: JSON.stringify({ patientId: state.clientId, biomarkers: biomarkerState.entries }) });
    await continueFromBiomarkers();
  } catch (err) { showError(error, err.message); }
});
