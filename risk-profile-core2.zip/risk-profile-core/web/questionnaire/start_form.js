"use strict";

// --- State -----------------------------------------------------------------

const state = {
  // API всегда тот же хост, что отдал страницу: панель раздаётся самим сервисом,
  // а пути запросов абсолютные (/api/v1/...). window.location.origin — без слеша на конце.
  baseUrl: window.location.origin,
  clientId: "",
  question: null,
  // Система показанного вопроса может отличаться от выбранной из-за приоритета общих вопросов.
  systemCode: null,
  selectedSystemCode: null,
  navigationSystems: [],
  // Признак «в текущей сессии панели сохранён хотя бы один ответ» — гейт кнопки
  // перехода к результатам. Ответы прошлых сессий сюда не попадают.
  hasAnswers: false,
  // Режим экрана результатов: RESULTS_MODE_* из final_page.js, null — экран не открывался.
  resultsMode: null,
};

// --- clientId ---------------------------------------------------------------

// Ограничения серверной валидации path-параметра clientId дублируются здесь
// литералами: панель — статические файлы без доступа к Python-константам.
// Источник правды — CLIENT_ID_MIN_LENGTH / CLIENT_ID_MAX_LENGTH / ID_PATTERN
// в src/api/schemas.py.
const CLIENT_ID_MIN_LENGTH = 5;
const CLIENT_ID_MAX_LENGTH = 36;
const CLIENT_ID_PATTERN = /^[A-Za-z0-9-]+$/;

// Префикс помечает пациентов, заведённых через панель, чтобы их было видно в БД
// и логах без внешнего контекста. Бюджет длины жёсткий: 6 символов префикса плюс
// 11 + 19 hex-символов дают ровно CLIENT_ID_MAX_LENGTH.
const CLIENT_ID_PREFIX = "panel-";
const CLIENT_ID_TIMESTAMP_HEX_LENGTH = 11;
const CLIENT_ID_RANDOM_HEX_LENGTH = 19;

// Без Web Crypto: панель раздаётся с произвольного стенда по обычному HTTP.
// Метка времени в старших символах разводит последовательные генерации в одной
// вкладке даже при повторе значений PRNG, случайный хвост — одновременные
// генерации в разных вкладках.
function generateClientId() {
  const timestamp = Date.now()
    .toString(16)
    .padStart(CLIENT_ID_TIMESTAMP_HEX_LENGTH, "0")
    .slice(-CLIENT_ID_TIMESTAMP_HEX_LENGTH);

  let random = "";
  while (random.length < CLIENT_ID_RANDOM_HEX_LENGTH) {
    random += Math.random().toString(16).slice(2);
  }

  return `${CLIENT_ID_PREFIX}${timestamp}${random.slice(0, CLIENT_ID_RANDOM_HEX_LENGTH)}`;
}

// Возвращает текст ошибки или null. Значение приходит уже без окружающих пробелов.
function validateClientId(value) {
  if (value.length < CLIENT_ID_MIN_LENGTH || value.length > CLIENT_ID_MAX_LENGTH) {
    return `clientId должен быть длиной от ${CLIENT_ID_MIN_LENGTH} до ${CLIENT_ID_MAX_LENGTH} символов`;
  }
  if (!CLIENT_ID_PATTERN.test(value)) {
    return "clientId допускает только латинские буквы, цифры и дефис";
  }
  return null;
}

// --- DOM references ---------------------------------------------------------

const el = {
  card: document.querySelector("main.card"),
  screens: {
    start: document.getElementById("screen-start"),
    question: document.getElementById("screen-question"),
    final: document.getElementById("screen-final"),
    biomarkers: document.getElementById("screen-biomarkers"),
  },
  clientId: document.getElementById("client-id"),
  regenerateClientId: document.getElementById("regenerate-client-id"),
  gender: document.getElementById("gender"),
  birthDate: document.getElementById("birth-date"),
  heightCm: document.getElementById("height-cm"),
  weightKg: document.getElementById("weight-kg"),
  startBtn: document.getElementById("start-btn"),
  startError: document.getElementById("start-error"),
  startStatus: document.getElementById("start-status"),
  resetPatientBtn: document.getElementById("reset-patient-btn"),
  resetPatientDialog: document.getElementById("reset-patient-dialog"),
  resetPatientTarget: document.getElementById("reset-patient-target"),
  resetPatientConfirm: document.getElementById("reset-patient-confirm"),
  resetPatientCancel: document.getElementById("reset-patient-cancel"),
  systemName: document.getElementById("system-name"),
  progressBar: document.getElementById("progress-bar"),
  progressLabel: document.getElementById("progress-label"),
  questionText: document.getElementById("question-text"),
  options: document.getElementById("options"),
  answerForm: document.getElementById("answer-form"),
  submitBtn: document.getElementById("submit-btn"),
  skipBtn: document.getElementById("skip-btn"),
  questionError: document.getElementById("question-error"),
  questionSystemsList: document.getElementById("question-systems-list"),
  questionSystemsError: document.getElementById("question-systems-error"),
  toResultsBtn: document.getElementById("to-results-btn"),
  backToQuestionsBtn: document.getElementById("back-to-questions-btn"),
  editBiomarkersBtn: document.getElementById("edit-biomarkers-btn"),
  newPatientBtn: document.getElementById("new-patient-btn"),
  finalStatus: document.getElementById("final-status"),
  finalError: document.getElementById("final-error"),
  dataDownload: document.getElementById("data-download"),
  downloadDataBtn: document.getElementById("download-data-btn"),
  downloadDataError: document.getElementById("download-data-error"),
  riskResults: document.getElementById("risk-results"),
  riskTableBody: document.getElementById("risk-table-body"),
  // Шапки экранов опроса показывают одного и того же пациента, поэтому узлы обновляются вместе.
  patientIds: [
    document.getElementById("biomarkers-patient-id"),
    document.getElementById("question-patient-id"),
    document.getElementById("final-patient-id"),
  ],
};

// --- Screen switching -------------------------------------------------------

function showScreen(name) {
  for (const [key, node] of Object.entries(el.screens)) {
    node.hidden = key !== name;
  }
  // Идентификатор пишется на смене экрана, а не там, где он назначается: так его не забыть
  // обновить ни на новом пациенте, ни на возврате к вопросам, ни на редактировании биомаркеров.
  for (const node of el.patientIds) node.textContent = state.clientId;
  // У результатов и вопросов разные широкие разметки; остальные экраны сохраняют прежнюю ширину.
  el.card.classList.toggle("card-wide", name === "final");
  el.card.classList.toggle("card-question-wide", name === "question");
}

function showError(node, message) {
  node.textContent = message;
  node.hidden = false;
}

function clearError(node) {
  node.textContent = "";
  node.hidden = true;
}

// Успешное действие — не ошибка: сообщение о нём идёт в отдельный узел, чтобы узел ошибки не
// приходилось читать как «то ли получилось, то ли нет». Поведение узлов одинаковое.
const showStatus = showError;
const clearStatus = clearError;

// --- API --------------------------------------------------------------------

async function postUrl(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error(`Сервер вернул некорректный ответ (HTTP ${res.status})`);
  }

  if (!res.ok || data.isSuccess === false) {
    const code = data.error?.code ?? `HTTP ${res.status}`;
    const message = data.error?.message ?? "Неизвестная ошибка";
    throw new Error(`${code}: ${message}`);
  }
  return data;
}

// Одно значение на параметр: повторяющиеся параметры строит вызывающий через postUrl.
function postJson(path, searchParams, body) {
  const url = new URL(`${state.baseUrl}${path}`);
  for (const [key, value] of Object.entries(searchParams)) {
    if (value) url.searchParams.set(key, value);
  }
  return postUrl(url, body);
}

function initClient(body) {
  const path = `/api/v1/clients/${encodeURIComponent(state.clientId)}/anthropometry`;
  return postJson(path, {}, body);
}

function postAnswer(questionCode, body, systemCode = state.selectedSystemCode) {
  const path = `/api/v2/clients/${encodeURIComponent(state.clientId)}/questions/answers`;
  return postJson(path, { questionCode, systemCode }, body);
}

async function getJson(path) {
  const res = await fetch(new URL(`${state.baseUrl}${path}`));
  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error(`Сервер вернул некорректный ответ (HTTP ${res.status})`);
  }
  if (!res.ok || data.isSuccess === false) {
    const code = data.error?.code ?? `HTTP ${res.status}`;
    const message = data.error?.message ?? "Неизвестная ошибка";
    throw new Error(`${code}: ${message}`);
  }
  return data;
}

function postRiskCalculation() {
  const path = `/api/v1/clients/${encodeURIComponent(state.clientId)}/medical-risk/events/risk-calculation`;
  return postJson(path, {}, {});
}

// clientId — параметр: сброс данных запрашивает оценку по идентификатору из стартовой формы,
// который ещё не стал текущим пациентом панели.
function getMedicalRisk(clientId = state.clientId) {
  return getJson(`/api/v1/clients/${encodeURIComponent(clientId)}/medical-risk`);
}

function postAnswersReset(clientId, systemCodes) {
  const path = `/api/v1/clients/${encodeURIComponent(clientId)}/medical-risk/events/answers-reset`;
  const url = new URL(`${state.baseUrl}${path}`);
  for (const code of systemCodes) url.searchParams.append("systemCode", code);
  return postUrl(url, {});
}

// --- Start form -------------------------------------------------------------

function collectAnthropometry() {
  const birthDate = el.birthDate.value;
  if (!birthDate) throw new Error("Укажите дату рождения");

  const body = { gender: el.gender.value, birthDate };
  const height = el.heightCm.value.trim();
  const weight = el.weightKg.value.trim();
  if (height !== "") body.heightCm = Number(height);
  if (weight !== "") body.weightKg = Number(weight);
  return body;
}

async function onStart() {
  const clientId = el.clientId.value.trim();
  const clientIdError = validateClientId(clientId);
  if (clientIdError) return showError(el.startError, clientIdError);

  let anthropometry;
  try {
    anthropometry = collectAnthropometry();
  } catch (err) {
    return showError(el.startError, err.message);
  }

  state.clientId = clientId;
  clearError(el.startError);
  clearStatus(el.startStatus);
  el.startBtn.disabled = true;
  try {
    await initClient(anthropometry);
    await openBiomarkerStep();
  } catch (err) {
    showError(el.startError, err.message);
  } finally {
    el.startBtn.disabled = false;
  }
}

// Возврат к стартовой форме с чистым прогрессом опроса. Данные прежнего пациента остаются на
// сервере и доступны по его clientId — сбрасывается только состояние панели. Пол, дата рождения
// и антропометрия сохраняются как заготовка для следующего пациента, как и при перегенерации
// clientId; новым выдаётся только идентификатор.
function startNewPatient() {
  state.clientId = "";
  forgetPatientProgress();
  clearError(el.startError);
  clearStatus(el.startStatus);
  el.clientId.value = generateClientId();
  showScreen("start");
}

// --- Сброс данных пациента --------------------------------------------------

// Сброс идёт тем же событием, что и в проде: answers-reset архивирует ответы, результаты и
// интерпретации в history и инвалидирует живые строки, сохраняя пол и дату рождения. Своего
// удаления панель не изобретает — иначе сброшенный ею пациент отличался бы от сброшенного
// системой.
//
// Системы событие требует явно и без них отвечает ошибкой, поэтому список берётся из оценки
// медицинских рисков. Общих вопросов в нём нет, и это не потеря: собственных параметров у них
// не бывает — параметры привязаны к инструментам систем и уходят в сброс вместе с ними.
async function resetPatientData(clientId) {
  const risk = await getMedicalRisk(clientId);
  const systemCodes = (risk.systemInterpretationResults ?? []).map((system) => system.systemCode);
  if (!systemCodes.length) throw new Error("сервер не вернул ни одной системы");
  await postAnswersReset(clientId, systemCodes);
}

// Сброшенный пациент начинается заново с тем же clientId: поля стартовой формы и идентификатор
// остаются, чтобы его можно было тут же пройти повторно.
function forgetPatientProgress() {
  state.question = null;
  state.systemCode = null;
  state.selectedSystemCode = null;
  state.navigationSystems = [];
  state.hasAnswers = false;
  state.resultsMode = null;
  resetBiomarkerEntries();
}

function openResetPatientDialog() {
  clearError(el.startError);
  clearStatus(el.startStatus);
  const clientId = el.clientId.value.trim();
  const clientIdError = validateClientId(clientId);
  if (clientIdError) return showError(el.startError, clientIdError);
  el.resetPatientTarget.textContent = clientId;
  el.resetPatientDialog.showModal();
}

async function onResetPatientConfirmed() {
  el.resetPatientDialog.close();
  const clientId = el.clientId.value.trim();
  el.resetPatientBtn.disabled = true;
  try {
    await resetPatientData(clientId);
    forgetPatientProgress();
    showStatus(el.startStatus, `Данные пациента ${clientId} сброшены`);
  } catch (err) {
    showError(el.startError, `Не удалось сбросить данные пациента: ${err.message}`);
  } finally {
    el.resetPatientBtn.disabled = false;
  }
}

el.clientId.value = generateClientId();
el.startBtn.addEventListener("click", onStart);
el.resetPatientBtn.addEventListener("click", openResetPatientDialog);
el.resetPatientConfirm.addEventListener("click", onResetPatientConfirmed);
el.resetPatientCancel.addEventListener("click", () => el.resetPatientDialog.close());
el.newPatientBtn.addEventListener("click", startNewPatient);
// Перегенерация трогает только clientId: остальные поля стартовой формы сохраняются.
el.regenerateClientId.addEventListener("click", () => {
  el.clientId.value = generateClientId();
});
