"use strict";

// --- Recommendations --------------------------------------------------------

function renderRecommendations(items) {
  const section = document.getElementById("recommendations");
  const list = document.getElementById("recommendations-list");
  if (!items.length) { section.hidden = true; return; }
  const cards = items.map(({ title, details }) => {
    const item = document.createElement("div");
    item.className = "rec-item";
    const btn = document.createElement("button");
    btn.className = "rec-title";
    btn.textContent = title;
    btn.addEventListener("click", () => item.classList.toggle("open"));
    const body = document.createElement("div");
    body.className = "rec-details";
    body.textContent = details;
    item.append(btn, body);
    return item;
  });
  list.replaceChildren(...cards);
  section.hidden = false;
}

function biomarkerOutcomeList(label, rows) {
  if (!rows?.length) return null;
  const block = document.createElement("div");
  const heading = document.createElement("p");
  heading.textContent = `${label}:`;
  const values = document.createElement("ul");
  values.replaceChildren(...rows.map((row) => {
    const item = document.createElement("li");
    item.textContent = row.name ?? row.title;
    return item;
  }));
  block.append(heading, values);
  return block;
}

function biomarkerOutcomeNode({ result, system }) {
  const item = document.createElement("div");
  item.className = "ui-block";
  const title = document.createElement("h3");
  title.textContent = result.diseaseName ?? result.diseaseCode;
  const state = document.createElement("p");
  const value = result.value === null || result.value === undefined ? "—" : result.value;
  state.textContent = `Результат: ${value}; применимость: ${result.applicability ? "да" : "нет"}`;
  item.append(title, state);

  // Неприменимая строка — законченный клинический исход группы. Общая системная интерпретация
  // могла появиться из опросника, но приписывать её этому биомаркеру было бы неверно.
  if (!result.applicability) return item;
  if (!system?.risk) {
    const pending = document.createElement("p");
    pending.textContent = `Интерпретация системы: ${STATUS_LABELS[system?.interpretationStatus] ?? "не готова"}`;
    item.append(pending);
    return item;
  }

  const systemTitle = document.createElement("h4");
  systemTitle.textContent = system.systemName;
  const risk = document.createElement("p");
  risk.textContent = `Уровень риска: ${RISK_LEVEL_LABELS[system.risk.riskLevel] ?? system.risk.riskLevel}`;
  item.append(systemTitle, risk);
  for (const node of [
    biomarkerOutcomeList("Заболевания", system.diseaseRisks),
    biomarkerOutcomeList("Факторы риска", system.risk.riskFactors),
    biomarkerOutcomeList("Рекомендации", system.risk.recommendations),
  ]) {
    if (node) item.append(node);
  }
  return item;
}

function renderBiomarkerInterpretations(data, calculationResults) {
  const section = document.getElementById("biomarker-interpretation");
  const list = document.getElementById("biomarker-interpretation-list");
  const outcomes = buildBiomarkerClinicalOutcomes(data, calculationResults);
  list.replaceChildren(...outcomes.map(biomarkerOutcomeNode));
  section.hidden = outcomes.length === 0;
}

async function loadBiomarkerInterpretations(clientId, baseUrl, medicalRisk) {
  const section = document.getElementById("biomarker-interpretation");
  const error = document.getElementById("biomarker-interpretation-error");
  section.hidden = true;
  error.hidden = true;
  try {
    const base = baseUrl.replace(/\/+$/, "");
    const results = await uiFetchJson(
      `${base}/api/v1/testing/calculation/results?patientId=${encodeURIComponent(clientId)}`,
    );
    renderBiomarkerInterpretations(medicalRisk, results);
  } catch (err) {
    error.textContent = `Не удалось загрузить интерпретации биомаркеров: ${err.message}`;
    error.hidden = false;
    section.hidden = false;
  }
}

// --- Risk results -----------------------------------------------------------

// Итоговый режим ждёт долго: на пройденном опроснике расчёт обязан состояться.
// В промежуточном режиме lastCalculationDateTime остаётся null, пока ни один
// инструмент не прошёл гейт расчёта, — ждать нечего, поэтому бюджет короткий.
const RISK_POLL_ATTEMPTS_FINAL = 15;
const RISK_POLL_ATTEMPTS_INTERIM = 4;
const RISK_POLL_DELAY_MS = 1500;
const RISK_LEVEL_LABELS = { low: "Низкий", medium: "Средний", high: "Высокий" };
const STATUS_LABELS = { completed: "Готово", "not enough data": "Недостаточно данных" };
// Терминальные статусы интерпретации — те, для которых у нас есть метка.
// Любой другой статус (или его отсутствие) означает, что система ещё считается.
const TERMINAL_STATUSES = new Set(Object.keys(STATUS_LABELS));

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Расчёт готов, когда он реально стартовал (есть lastCalculationDateTime),
// список систем непустой и КАЖДАЯ система пришла в терминальный статус.
// Проверять одни лишь top-level таймстампы нельзя: они выставляются по первой
// завершённой интерпретации (и переживают предыдущий расчёт), поэтому
// последние по приоритету системы (например, BLOOD) не успевают попасть в снапшот.
function risksReady(data) {
  const systems = data.systemInterpretationResults ?? [];
  return Boolean(data.lastCalculationDateTime)
    && systems.length > 0
    && systems.every((system) => TERMINAL_STATUSES.has(system.interpretationStatus));
}

async function loadRisks() {
  clearError(el.finalError);
  hideDataDownload();
  el.riskResults.hidden = true;
  el.finalStatus.hidden = false;
  el.finalStatus.textContent = "Рассчитываем ваши риски…";
  const attempts = state.resultsMode === RESULTS_MODE_INTERIM ? RISK_POLL_ATTEMPTS_INTERIM : RISK_POLL_ATTEMPTS_FINAL;
  try {
    await postRiskCalculation();
    let data = await getMedicalRisk();
    for (let i = 0; i < attempts && !risksReady(data); i++) {
      await sleep(RISK_POLL_DELAY_MS);
      data = await getMedicalRisk();
    }
    if (state.resultsMode === RESULTS_MODE_INTERIM && !risksReady(data)) {
      showNoRisksYet();
      return;
    }
    renderRisks(data);
  } catch (err) {
    el.finalStatus.hidden = true;
    showError(el.finalError, err.message);
    showDataDownload();
  }
}

// Отсутствие расчёта на неполном опроснике — состояние, а не ошибка: сообщение
// идёт в узел статуса, el.finalError не трогаем.
function showNoRisksYet() {
  el.finalStatus.textContent = "Рассчитанных результатов пока нет: ответьте ещё на несколько вопросов.";
  el.finalStatus.hidden = false;
  el.riskResults.hidden = true;
  document.getElementById("recommendations").hidden = true;
  document.getElementById("user-info").hidden = true;
  // Причины по инструментам нужны именно здесь: результатов ещё нет, и без разбора экран не
  // объясняет, чего не хватило расчёту.
  loadExplanation(state.clientId, state.baseUrl);
  showDataDownload();
}

// Отметка выбранной системы живёт на строке, а не на блоке разбора: таблица рисуется один раз,
// а разбор перерисовывается, пока догружается, и отметка пережила бы не всякую перерисовку.
// Разбор догружается к уже показанным результатам: пока его блока нет, показывать нечего, и
// отметка остаётся на прежней системе — иначе она указывала бы не на тот разбор, что виден.
function selectSystemRow(row) {
  if (!explRevealSystem(row.dataset.systemCode)) return;
  for (const other of el.riskTableBody.querySelectorAll("tr.selected")) other.classList.remove("selected");
  row.classList.add("selected");
}

// Описание усечено в таблице двумя строками, поэтому полный текст кладётся в title: иначе он
// становится недоступен совсем.
function riskDescriptionCell(text) {
  const td = document.createElement("td");
  td.title = text;
  const body = document.createElement("div");
  body.className = "risk-description-text";
  body.textContent = text;
  td.append(body);
  return td;
}

function renderRisks(data) {
  const rows = (data.systemInterpretationResults ?? []).map((system) => {
    const level = system.risk?.riskLevel;
    const tr = document.createElement("tr");
    tr.className = level ? `system-row risk-${level}` : "system-row";
    // Адрес строки для разбора расчёта: он приходит позже и живёт в области подробностей.
    tr.dataset.systemCode = system.systemCode;
    tr.addEventListener("click", () => selectSystemRow(tr));
    const description = system.risk?.description ?? "—";
    const cells = [
      system.systemName,
      `${system.systemCompletionPercentage}%`,
      STATUS_LABELS[system.interpretationStatus] ?? "—",
      level ? (RISK_LEVEL_LABELS[level] ?? level) : "—",
    ];
    for (const value of cells) {
      const td = document.createElement("td");
      td.textContent = value;
      tr.append(td);
    }
    tr.append(riskDescriptionCell(description));
    return tr;
  });
  el.riskTableBody.replaceChildren(...rows);
  el.finalStatus.hidden = true;
  el.riskResults.hidden = false;
  renderRecommendations(data.topRecommendations ?? []);
  loadBiomarkerInterpretations(state.clientId, state.baseUrl, data);
  loadUserInfo(state.clientId, state.baseUrl);
  // Разбор расчёта достраивается к показанным результатам и не задерживает их: ожидание уходит
  // в отдельный запрос, таблица и рекомендации уже на экране.
  loadExplanation(state.clientId, state.baseUrl);
  showDataDownload();
}

// --- Режимы экрана результатов ----------------------------------------------

const RESULTS_MODE_INTERIM = "interim";
const RESULTS_MODE_FINAL = "final";

// Наличие возврата к вопросам — единственное, чем режимы различаются: набор и порядок блоков
// результатов одинаковый.
function applyResultsMode(mode) {
  state.resultsMode = mode;
  el.backToQuestionsBtn.hidden = mode !== RESULTS_MODE_INTERIM;
}

// Единственная точка показа экрана результатов: режим невозможно забыть выставить,
// а итоговый сценарий не расходится с промежуточным по набору отрисованных блоков.
function showResults(mode) {
  applyResultsMode(mode);
  showScreen("final");
  loadRisks();
}

// --- Возврат к вопросам -----------------------------------------------------

async function onBackToQuestions() {
  clearError(el.finalError);
  el.backToQuestionsBtn.disabled = true;
  try {
    // Тот же вызов, которым панель стартует опросник: сервер — единственный
    // источник того, какой вопрос сейчас текущий, и ответ он не сохраняет.
    const requestedSystemCode = state.selectedSystemCode;
    const data = await postAnswer(null, {}, requestedSystemCode);
    updateNavigationProgress(data, requestedSystemCode);
    if (data.question) {
      advance(data);
      return;
    }

    const next = await postAnswer(null, {}, null);
    updateNavigationProgress(next, null);
    if (next.question) {
      state.selectedSystemCode = next.systemCode;
      advance(next);
      return;
    }
    // Вопросы кончились за время просмотра: результаты уже на экране, перезапрашивать
    // их не нужно — меняется только режим.
    applyResultsMode(RESULTS_MODE_FINAL);
  } catch (err) {
    showError(el.finalError, err.message);
  } finally {
    el.backToQuestionsBtn.disabled = false;
  }
}

el.backToQuestionsBtn.addEventListener("click", onBackToQuestions);
