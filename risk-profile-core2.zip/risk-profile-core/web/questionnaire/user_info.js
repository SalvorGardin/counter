"use strict";

// Token is injected by GET /questionnaire/config.js from settings.test_api_key (LOCAL DEV ONLY).
const UI_RISK_LEVEL_LABELS = { low: "Низкий", medium: "Средний", high: "Высокий" };
const UI_STATUS_LABELS = {
  completed: "Готово",
  "not enough data": "Недостаточно данных",
  normal: "Норма",
};

function uiHeaders() {
  return { "X-Test-Api-Key": window.TEST_TOKEN };
}

async function uiFetchJson(url, { allow404 = false } = {}) {
  const response = await fetch(url, { headers: uiHeaders() });
  if (response.status === 404 && allow404) return null;
  if (!response.ok) {
    throw new Error(`GET ${url} → ${response.status}`);
  }
  return response.json();
}

function uiFormatDate(value) {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? value : d.toISOString().slice(0, 10);
}

function uiTextCell(value) {
  const td = document.createElement("td");
  td.textContent = value === null || value === undefined || value === "" ? "—" : String(value);
  return td;
}

function uiShowError(message) {
  const node = document.getElementById("user-info-error");
  node.textContent = message;
  node.hidden = false;
}

function uiRenderUser(clientId, patient) {
  document.getElementById("ui-client-id").textContent = clientId;
  const row = document.getElementById("ui-pregnancy-row");
  if (patient === null) {
    row.hidden = true;
    return;
  }
  row.hidden = false;
  document.getElementById("ui-pregnancy").textContent = patient.isPregnant ? "да" : "нет";
}

function uiRenderParams(params, parameters) {
  const descriptionByCode = new Map((parameters ?? []).map((p) => [p.code, p.description]));
  const body = document.getElementById("ui-params-body");
  const empty = document.getElementById("ui-params-empty");
  const table = document.getElementById("ui-params-table");
  body.replaceChildren();
  if (!params || params.length === 0) {
    table.hidden = true;
    empty.hidden = false;
    return;
  }
  table.hidden = false;
  empty.hidden = true;
  for (const p of params) {
    const tr = document.createElement("tr");
    tr.append(
      uiTextCell(p.parameterCode),
      uiTextCell(descriptionByCode.get(p.parameterCode)),
      uiTextCell(p.value),
      uiTextCell(uiFormatDate(p.expirationDate)),
    );
    body.append(tr);
  }
}

function uiRenderResults(instruments, results) {
  const body = document.getElementById("ui-results-body");
  body.replaceChildren();
  const byCode = new Map();
  for (const r of results ?? []) {
    if (!byCode.has(r.instrumentCode)) byCode.set(r.instrumentCode, []);
    byCode.get(r.instrumentCode).push(r);
  }
  for (const inst of instruments ?? []) {
    const rows = byCode.get(inst.code);
    if (!rows || rows.length === 0) {
      const tr = document.createElement("tr");
      tr.append(uiTextCell(inst.code), uiTextCell(null), uiTextCell(null), uiTextCell(null), uiTextCell(null));
      body.append(tr);
      continue;
    }
    for (const r of rows) {
      const label = r.diseaseCode ? `${inst.code} (${r.diseaseCode})` : (r.indicator ? `${inst.code} (${r.indicator})` : inst.code);
      const tr = document.createElement("tr");
      tr.append(
        uiTextCell(label),
        uiTextCell(r.value),
        uiTextCell(r.unit),
        uiTextCell(r.riskLevel ? (UI_RISK_LEVEL_LABELS[r.riskLevel] ?? r.riskLevel) : null),
        uiTextCell(
          r.interpretationStatus ? (UI_STATUS_LABELS[r.interpretationStatus] ?? r.interpretationStatus) : null,
        ),
      );
      body.append(tr);
    }
  }
}

async function loadUserInfo(clientId, baseUrl) {
  const section = document.getElementById("user-info");
  section.hidden = false;
  document.getElementById("user-info-error").hidden = true;

  if (!clientId) {
    uiShowError("clientId не задан");
    return;
  }

  const base = baseUrl.replace(/\/+$/, "");
  try {
    const [patient, params, parameters, instruments, results] = await Promise.all([
      uiFetchJson(`${base}/api/v1/testing/patients/${encodeURIComponent(clientId)}`, { allow404: true }),
      uiFetchJson(`${base}/api/v1/testing/patient-parameters?patientId=${encodeURIComponent(clientId)}`),
      uiFetchJson(`${base}/api/v1/testing/parameters`),
      uiFetchJson(`${base}/api/v1/testing/instruments`),
      uiFetchJson(`${base}/api/v1/testing/calculation/results?patientId=${encodeURIComponent(clientId)}`),
    ]);
    uiRenderUser(clientId, patient);
    uiRenderParams(params, parameters);
    uiRenderResults(instruments, results);
  } catch (err) {
    uiShowError(`Не удалось загрузить данные пользователя: ${err.message}`);
  }
}
