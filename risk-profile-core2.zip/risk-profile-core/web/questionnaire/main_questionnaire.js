"use strict";

// --- Rendering --------------------------------------------------------------

function renderQuestion(question) {
  el.questionText.textContent = question.text;

  if (question.type === "numeric") {
    const input = renderNumericInput();
    el.options.replaceChildren(input);
    input.focus();
  } else {
    const inputType = question.type === "multi" ? "checkbox" : "radio";
    const nodes = (question.options ?? []).map((option) => renderOption(option, inputType));
    el.options.replaceChildren(...nodes);
  }

  el.skipBtn.hidden = !question.isSkippable;
  el.toResultsBtn.hidden = !state.hasAnswers;
}

function renderOption(option, inputType) {
  const label = document.createElement("label");
  label.className = "option";

  const input = document.createElement("input");
  input.type = inputType;
  input.name = "option";
  input.value = option.optionCode;

  const text = document.createElement("span");
  text.textContent = option.text;

  label.append(input, text);
  return label;
}

function renderNumericInput() {
  const input = document.createElement("input");
  input.type = "number";
  input.name = "numeric";
  input.step = "any";
  input.id = "numeric-input";
  return input;
}

function renderProgress(data) {
  el.systemName.textContent = data.systemName ?? "";
  const pct = data.systemCompletionPercentage ?? 0;
  el.progressBar.style.width = `${pct}%`;
  el.progressLabel.textContent = `${pct}%`;
}

// Группа общих вопросов. В списке систем её нет и быть не может: medical-risk намеренно исключает
// COMMON из systemInterpretationResults, собственной заполненности у неё нет (общие вопросы
// засчитываются в системы, чьи параметры затрагивают их варианты), а запрос вопроса с
// systemCode=COMMON сервер трактует как завершение опроса. Поэтому строка справочная: без
// процента, без выбора — она лишь показывает, что сейчас идёт общий блок, а не выбранная система.
const COMMON_SYSTEM_CODE = "COMMON";
const COMMON_SYSTEM_NAME = "Общие вопросы"; // systems.description кода COMMON

function renderCommonSystemItem() {
  const item = document.createElement("div");
  item.className = "question-system-item question-system-common";
  item.classList.toggle("current", state.systemCode === COMMON_SYSTEM_CODE);

  const name = document.createElement("span");
  name.textContent = COMMON_SYSTEM_NAME;
  item.append(name);
  return item;
}

function renderSystemNavigation() {
  const items = state.navigationSystems.map((system) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "question-system-item";
    button.classList.toggle("selected", system.systemCode === state.selectedSystemCode);
    button.setAttribute("aria-pressed", String(system.systemCode === state.selectedSystemCode));

    const name = document.createElement("span");
    name.textContent = system.systemName;
    const percentage = document.createElement("span");
    percentage.className = "question-system-percentage";
    percentage.textContent = `${system.systemCompletionPercentage}%`;
    button.append(name, percentage);
    button.addEventListener("click", () => selectQuestionSystem(system.systemCode));
    return button;
  });
  // Общие вопросы идут первыми и у сервера: rang COMMON меньше рангов систем.
  el.questionSystemsList.replaceChildren(renderCommonSystemItem(), ...items);
}

// Перерисовки списка накладываются: при быстрых ответах следующий запрос уходит раньше, чем
// вернулся предыдущий. Применяется только самый свежий, иначе поздний ранний ответ вернул бы
// проценты, посчитанные до последних ответов.
let navigationLoadVersion = 0;

async function loadSystemNavigation() {
  clearError(el.questionSystemsError);
  const version = ++navigationLoadVersion;
  try {
    const data = await getMedicalRisk();
    if (version !== navigationLoadVersion) return;
    // Порядок и состав задаёт сервер; COMMON в этом ответе отсутствует.
    state.navigationSystems = data.systemInterpretationResults ?? [];
    renderSystemNavigation();
  } catch (err) {
    if (version !== navigationLoadVersion) return;
    showError(el.questionSystemsError, `Не удалось загрузить список систем: ${err.message}`);
  }
}

function updateNavigationProgress(data, requestedSystemCode) {
  const systemCode = requestedSystemCode ?? data.systemCode;
  if (!systemCode || data.systemCompletionPercentage === null || data.systemCompletionPercentage === undefined) {
    return;
  }
  state.navigationSystems = state.navigationSystems.map((system) => (
    system.systemCode === systemCode
      ? { ...system, systemCompletionPercentage: data.systemCompletionPercentage }
      : system
  ));
  renderSystemNavigation();
}

// --- Answer collection ------------------------------------------------------

function collectAnswer() {
  if (state.question.type === "numeric") {
    const raw = document.getElementById("numeric-input").value.trim();
    if (raw === "") throw new Error("Введите значение");
    return { answer: raw };
  }

  const selected = [...el.options.querySelectorAll("input:checked")].map((input) => input.value);
  if (selected.length === 0) throw new Error("Выберите вариант ответа");
  return { optionCodes: selected };
}

// --- Flow -------------------------------------------------------------------

function advance(data) {
  if (!data.question) {
    showResults(RESULTS_MODE_FINAL);
    return;
  }
  state.question = data.question;
  state.systemCode = data.systemCode;
  renderProgress(data);
  renderQuestion(data.question);
  clearError(el.questionError);
  showScreen("question");
  // Ответ несёт заполненность одной системы — запрошенной, — а двигает несколько: общие вопросы
  // засчитываются в каждую систему, чьи параметры затрагивают их варианты. Точечное обновление
  // выше показывает её сразу, а остальные строки догоняют этим запросом. Не ждём его: следующий
  // вопрос уже на экране. Единственная точка перезагрузки списка — через неё проходят и ответ,
  // и выбор системы, и возврат с результатов, и продолжение после биомаркеров.
  void loadSystemNavigation();
}

async function advanceAfterRequest(data, requestedSystemCode) {
  updateNavigationProgress(data, requestedSystemCode);
  if (data.question) {
    advance(data);
    return;
  }
  if (!requestedSystemCode) {
    showResults(RESULTS_MODE_FINAL);
    return;
  }

  // Пустой ответ с systemCode завершает только выбранную систему. Пустой запрос без
  // systemCode определяет следующий вопрос общей очереди или завершение всего опросника.
  const next = await postAnswer(null, {}, null);
  updateNavigationProgress(next, null);
  if (!next.question) {
    showResults(RESULTS_MODE_FINAL);
    return;
  }
  state.selectedSystemCode = next.systemCode;
  renderSystemNavigation();
  advance(next);
}

async function selectQuestionSystem(systemCode) {
  clearError(el.questionError);
  const buttons = el.questionSystemsList.querySelectorAll("button");
  for (const button of buttons) button.disabled = true;
  try {
    // Выбор фиксируется только после успешного запроса: при ошибке остаются прежние
    // вопрос и отметка, а несохранённые варианты ответа не отправляются.
    const data = await postAnswer(null, {}, systemCode);
    state.selectedSystemCode = systemCode;
    renderSystemNavigation();
    await advanceAfterRequest(data, systemCode);
  } catch (err) {
    showError(el.questionError, err.message);
  } finally {
    for (const button of el.questionSystemsList.querySelectorAll("button")) button.disabled = false;
  }
}

async function submitAnswer(body) {
  el.submitBtn.disabled = true;
  el.skipBtn.disabled = true;
  try {
    const requestedSystemCode = state.selectedSystemCode;
    const data = await postAnswer(state.question.questionCode, body, requestedSystemCode);
    // До advance() и на любом успешном ответе, включая пропуск: с этого момента
    // промежуточные результаты есть что смотреть.
    state.hasAnswers = true;
    await advanceAfterRequest(data, requestedSystemCode);
  } catch (err) {
    showError(el.questionError, err.message);
  } finally {
    el.submitBtn.disabled = false;
    el.skipBtn.disabled = false;
  }
}

// --- Event handlers ---------------------------------------------------------

function onSubmit(event) {
  event.preventDefault();
  let body;
  try {
    body = collectAnswer();
  } catch (err) {
    return showError(el.questionError, err.message);
  }
  submitAnswer(body);
}

function onSkip() {
  submitAnswer({ isSkipped: true });
}

// Переход к результатам не отправляет текущий ответ: отмеченные варианты
// отбрасываются, при возврате вопрос перерисовывается по данным сервера.
function onToResults() {
  showResults(RESULTS_MODE_INTERIM);
}

// Number keys 1-9 select the corresponding option. Radio selects; checkbox
// (multi) toggles. Inactive on numeric questions so digits type into the field.
function onOptionHotkey(event) {
  if (el.screens.question.hidden || state.question?.type === "numeric") return;
  if (event.ctrlKey || event.altKey || event.metaKey) return;
  const index = Number(event.key) - 1;
  if (!Number.isInteger(index) || index < 0) return;

  const inputs = el.options.querySelectorAll("input");
  const input = inputs[index];
  if (!input) return;

  event.preventDefault();
  if (input.type === "checkbox") input.checked = !input.checked;
  else input.checked = true;
  input.focus();
}

el.answerForm.addEventListener("submit", onSubmit);
el.skipBtn.addEventListener("click", onSkip);
el.toResultsBtn.addEventListener("click", onToResults);
document.addEventListener("keydown", onOptionHotkey);
