"use strict";

function hideDataDownload() {
  el.dataDownload.hidden = true;
  clearError(el.downloadDataError);
}

function showDataDownload() {
  el.dataDownload.hidden = false;
}

async function onDownloadData() {
  clearError(el.downloadDataError);
  el.downloadDataBtn.disabled = true;
  const patientId = state.clientId;
  const base = state.baseUrl.replace(/\/+$/, "");
  const url = `${base}/api/v1/testing/patients/${encodeURIComponent(patientId)}/export`;

  try {
    const response = await fetch(url, { headers: { "X-Test-Api-Key": window.TEST_TOKEN } });
    if (!response.ok) throw new Error(`GET ${url} → ${response.status}`);

    const objectUrl = URL.createObjectURL(await response.blob());
    try {
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = `patient-${patientId}-data.zip`;
      link.hidden = true;
      document.body.append(link);
      link.click();
      link.remove();
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  } catch (err) {
    showError(el.downloadDataError, `Не удалось скачать данные: ${err.message}`);
  } finally {
    el.downloadDataBtn.disabled = false;
  }
}

el.downloadDataBtn.addEventListener("click", onDownloadData);
