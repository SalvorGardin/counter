"use strict";

// Разбор расчёта на экране результатов: почему инструмент не дал показателя и что стоит за
// уровнем риска системы. Данные берутся у эндпоинта объяснения — он уже отдаёт формулировки
// причин и состояний текстом, поэтому своего словаря панель не держит: два набора текстов
// расходились бы при добавлении кода на сервере.
//
// Маршрут существует только при включённом сборе диагностических данных. Его отсутствие —
// не ошибка: 404 означает «возможности нет», и экран выглядит как без неё.

const EXPL_URL = "/api/v1/testing/explanation";
const EXPL_UNMATCHED_URL = `${EXPL_URL}/unmatched-risk-factors`;
const EXPL_RETRY_DELAY_MS = 3000;
const EXPL_RETRY_WINDOW_MS = 60000;
let explLoadVersion = 0;
const explUnmatchedCache = new Map();

// Формулировка приходит с сервера; на неизвестном коде печатаем сам код, чтобы новый код не
// делал причину невидимой.
function explText(text, code) {
  if (text) return text;
  return code ? String(code) : "";
}

function explDetailsLine(instrument) {
  const parts = [];
  const missing = instrument.missingParameters ?? [];
  if (missing.length) parts.push(`недостающих показателей: ${missing.length}`);
  if (instrument.applicableQuestions !== null && instrument.applicableQuestions !== undefined) {
    parts.push(`вопросов пройдено: ${instrument.progressedQuestions ?? 0} из ${instrument.applicableQuestions}`);
  }
  return parts.join(", ");
}

// Перечисления панели — по строке на пункт: в одну строку через разделитель они читаются как
// сплошной текст. Один узел на все списки, чтобы блоки не расходились по виду.
function explLinesNode(lines) {
  const node = document.createElement("div");
  node.className = "expl-lines";
  for (const line of lines) {
    const row = document.createElement("div");
    row.textContent = line;
    node.append(row);
  }
  return node;
}

// Списки показателей — по дополнительному раскрытию: у шкал их десятки, и в строке они
// разрывают вёрстку.
function explCollapsibleBlock(label, lines, key) {
  if (!lines.length) return null;
  const item = document.createElement("div");
  item.className = "expl-collapse";
  item.dataset.explKey = key;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "expl-collapse-title";
  btn.textContent = `${label} (${lines.length})`;
  btn.addEventListener("click", () => item.classList.toggle("open"));
  const body = explLinesNode(lines);
  body.classList.add("expl-collapse-details");
  item.append(btn, body);
  return item;
}

function explMissingBlock(instrument) {
  const missing = instrument.missingParameters ?? [];
  const lines = missing.map((p) => (p.name ? `${p.code} — ${p.name}` : p.code));
  return explCollapsibleBlock("Недостающие показатели", lines, `${instrument.instrumentCode}:missing`);
}

function explParametersBlock(instrument) {
  const parameters = instrument.parameters ?? [];
  const lines = parameters.map((parameter) => {
    const name = parameter.name ? `${parameter.name} (${parameter.code})` : parameter.code;
    const kind = parameter.required ? "обязательный" : "необязательный";
    return `${name} — ${kind}, ответ: ${parameter.answer ?? "нет ответа"}`;
  });
  return explCollapsibleBlock("Входные показатели", lines, `${instrument.instrumentCode}:parameters`);
}

function explInstrumentNode(instrument) {
  const node = document.createElement("div");
  node.className = "expl-inst";
  const title = document.createElement("div");
  title.className = "expl-inst-title";
  title.textContent = instrument.instrumentName
    ? `${instrument.instrumentName} (${instrument.instrumentCode})`
    : instrument.instrumentCode;
  const state = document.createElement("div");
  state.className = "muted";
  // Состояние объяснения и причина отвечают на разные вопросы: первое — соответствует ли объяснение
  // показанному результату, второе — почему показателя нет.
  const reason = explText(instrument.reasonText, instrument.reasonCode);
  const lines = [explText(instrument.explanationStateText, instrument.explanationState)];
  if (reason) lines.push(reason);
  const details = explDetailsLine(instrument);
  if (details) lines.push(details);
  state.textContent = lines.join(" · ");
  node.append(title, state);
  const parameters = explParametersBlock(instrument);
  if (parameters) node.append(parameters);
  const missing = explMissingBlock(instrument);
  if (missing) node.append(missing);
  return node;
}

function explReasonNode(label, reason) {
  const text = explText(reason?.reasonText, reason?.reasonCode);
  if (!text) return null;
  const node = document.createElement("div");
  node.className = "muted";
  node.textContent = `${label}: ${text}`;
  return node;
}

function explStateNode(state, text) {
  if (!state || state === "matches") return null;
  const node = document.createElement("div");
  node.className = `expl-state expl-state-${state}`;
  node.textContent = explText(text, state);
  return node;
}

function explReferenceText(item) {
  return item.name ? `${item.name} (${item.code})` : item.code;
}

function explListNode(label, items, formatter = String) {
  if (!items?.length) return null;
  const node = document.createElement("div");
  node.className = "expl-list";
  const title = document.createElement("strong");
  title.textContent = `${label}: `;
  node.append(title, document.createTextNode(items.map(formatter).join("; ")));
  return node;
}

// Операторы порога отличаются только знаком, поэтому знак берётся таблицей: пропущенный оператор
// выводился бы как «условие не указано» у фактора, у которого условие есть и по нему он сработал.
// Набор — тот же, что в CHECK `ck_risk_factor_triggers_operator` и в сравнении на стороне модели.
const EXPL_THRESHOLD_SIGNS = { gt: ">", gte: "≥", lt: "<", lte: "≤" };

function explConditionText(condition) {
  if (!condition) return "условие не указано";
  let text = "";
  const sign = EXPL_THRESHOLD_SIGNS[condition.operator];
  if (condition.operator === "eq" && condition.valueText !== null && condition.valueText !== undefined) {
    text = `= ${condition.valueText}`;
  } else if (sign !== undefined && condition.valueNum !== null && condition.valueNum !== undefined) {
    text = `${sign} ${condition.valueNum}`;
  } else if (condition.operator === "between") {
    const parts = [];
    if (condition.minValue !== null && condition.minValue !== undefined) parts.push(`от ${condition.minValue}`);
    if (condition.maxValue !== null && condition.maxValue !== undefined) parts.push(`до ${condition.maxValue}`);
    text = parts.join(" ");
  }
  if (!text) text = "условие не указано";
  return condition.gender ? `${text}; пол: ${condition.gender}` : text;
}

function explRiskFactorNode(factor) {
  const node = document.createElement("div");
  node.className = "expl-factor";
  const title = document.createElement("div");
  title.className = "expl-factor-title";
  const code = factor.riskFactorCode ?? factor.triggerCode ?? "код не указан";
  title.textContent = factor.name ? `${factor.name} (${code})` : code;
  const parameter = factor.parameterName
    ? `${factor.parameterName} (${factor.parameterCode})`
    : factor.parameterCode;
  const lines = [
    `Триггер: ${factor.triggerCode}`,
    `Показатель: ${parameter}`,
    `Сработавшее условие: ${explConditionText(factor.condition)}`,
    `Текущий ответ: ${factor.answer ?? "нет ответа"}`,
    `Модифицируемость: ${factor.modifiability}`,
  ];
  if (factor.answerMatchesCondition === false) {
    lines.push("Текущий ответ больше не соответствует сохранённому условию");
    node.classList.add("expl-factor-mismatch");
  }
  if (factor.isRepresentative) {
    lines.push("Показан в риск-профиле");
  } else {
    lines.push("Не выбран представителем в риск-профиле");
  }
  if (factor.scoreReferenceIncomplete) lines.push("В справочнике отсутствует оценка для условия");
  node.append(title, explLinesNode(lines));
  if (factor.reasoning) {
    const reasoning = document.createElement("div");
    reasoning.className = "expl-factor-reasoning";
    reasoning.textContent = factor.reasoning;
    node.append(reasoning);
  }
  return node;
}

function explUnmatchedFactorNode(factor) {
  const node = document.createElement("div");
  node.className = "expl-factor expl-factor-unmatched";
  const title = document.createElement("div");
  title.className = "expl-factor-title";
  const code = factor.riskFactorCode ?? factor.triggerCode ?? "код не указан";
  title.textContent = factor.name ? `${factor.name} (${code})` : code;
  const parameter = factor.parameterName
    ? `${factor.parameterName} (${factor.parameterCode})`
    : factor.parameterCode;
  const lines = [
    `Триггер: ${factor.triggerCode}`,
    `Показатель: ${parameter}`,
    `Условие: ${explConditionText(factor.condition)}`,
    `Текущий ответ: ${factor.answer ?? "нет ответа"}`,
    explText(factor.reasonText, factor.reasonCode),
  ].filter(Boolean);
  node.append(title, explLinesNode(lines));
  if (factor.reasoning) {
    const reasoning = document.createElement("div");
    reasoning.className = "expl-factor-reasoning";
    reasoning.textContent = factor.reasoning;
    node.append(reasoning);
  }
  return node;
}

function explRenderUnmatchedResult(result, data) {
  result.className = "expl-unmatched-result";
  const items = data.items ?? [];
  const note = document.createElement("div");
  note.className = "muted";
  note.textContent = "Отдельный пересчёт на текущих данных; это не сохранённое объяснение прошлого расчёта.";
  if (!items.length) {
    const empty = document.createElement("div");
    empty.textContent = "Несработавших факторов нет.";
    result.replaceChildren(note, empty);
  } else {
    result.replaceChildren(note, ...items.map(explUnmatchedFactorNode));
  }
}

function explUnmatchedBlock(system, clientId, baseUrl) {
  const openText = "Проверить несработавшие факторы на текущих данных";
  const closeText = "Скрыть несработавшие факторы";
  const block = document.createElement("div");
  block.className = "expl-unmatched";
  block.dataset.systemCode = system.systemCode;
  const button = document.createElement("button");
  button.type = "button";
  button.className = "secondary";
  button.textContent = openText;
  button.setAttribute("aria-expanded", "false");
  const result = document.createElement("div");
  result.className = "expl-unmatched-result";
  result.hidden = true;
  let loaded = false;
  let loading = false;
  button.addEventListener("click", async () => {
    const opening = result.hidden;
    result.hidden = !opening;
    button.textContent = opening ? closeText : openText;
    button.setAttribute("aria-expanded", String(opening));
    if (!opening || loaded || loading) return;

    const cacheKey = `${clientId}\n${system.systemCode}`;
    const cached = explUnmatchedCache.get(cacheKey);
    if (cached) {
      explRenderUnmatchedResult(result, cached);
      loaded = true;
      return;
    }

    loading = true;
    result.className = "expl-unmatched-result muted";
    result.textContent = "Выполняется пересчёт…";
    const base = baseUrl.replace(/\/+$/, "");
    const query = new URLSearchParams({ patientId: clientId, systemCode: system.systemCode });
    try {
      const data = await uiFetchJson(`${base}${EXPL_UNMATCHED_URL}?${query}`);
      explUnmatchedCache.set(cacheKey, data);
      explRenderUnmatchedResult(result, data);
      loaded = true;
    } catch (err) {
      result.className = "expl-unmatched-result error";
      result.textContent = `Не удалось проверить факторы: ${err.message}`;
    } finally {
      loading = false;
    }
  });
  block.append(button, result);
  return block;
}

function explSystemBody(system, clientId, baseUrl) {
  const body = document.createElement("div");
  body.className = "expl-body";
  const state = explStateNode(system.explanationState, system.explanationStateText);
  if (state) body.append(state);
  // Пока объяснение новой интерпретации готовится, старые причины нельзя показывать как текущие.
  if (system.explanationState === "pending") return body;
  const riskLevel = document.createElement("div");
  riskLevel.className = "expl-list";
  const riskLevelTitle = document.createElement("strong");
  riskLevelTitle.textContent = "Уровень риска: ";
  riskLevel.append(riskLevelTitle, document.createTextNode(system.riskLevel ?? "не определён"));
  body.append(riskLevel);
  for (const node of [
    explListNode("Блокирующие инструменты", system.blockingInstruments, explReferenceText),
    explListNode("Заболевания", system.diseases),
    explListNode("Врачи", system.doctors, explReferenceText),
  ]) {
    if (node) body.append(node);
  }
  for (const [label, reason] of [
    ["Уровень риска", system.riskLevelReason],
    ["Заболевания", system.diseasesReason],
    ["Факторы риска", system.riskFactorsReason],
    ["Врачи", system.doctorsReason],
  ]) {
    const node = explReasonNode(label, reason);
    if (node) body.append(node);
  }
  const factors = system.riskFactors ?? [];
  if (factors.length) {
    const heading = document.createElement("h4");
    heading.textContent = "Сработавшие факторы риска";
    body.append(heading, ...factors.map(explRiskFactorNode));
  }
  body.append(explUnmatchedBlock(system, clientId, baseUrl));
  const instruments = system.instruments ?? [];
  if (!instruments.length) {
    const empty = document.createElement("div");
    empty.className = "muted";
    empty.textContent = "Инструментов у системы нет";
    body.append(empty);
    return body;
  }
  // Рассчитанные инструменты тоже показываются: без них не видно, на чём построен уровень риска.
  for (const instrument of instruments) body.append(explInstrumentNode(instrument));
  return body;
}

function explClearRendered() {
  document.getElementById("expl-hint").hidden = true;
  document.getElementById("expl-systems-list").replaceChildren();
  document.getElementById("expl-outside-list").replaceChildren();
}

function explCaptureOpenState() {
  return {
    systems: new Set(
      [...document.querySelectorAll("#expl-systems-list .rec-item.open[data-system-code]")].map(
        (item) => item.dataset.systemCode,
      ),
    ),
    collapses: new Set(
      [...document.querySelectorAll(".expl-collapse.open[data-expl-key]")].map((item) => item.dataset.explKey),
    ),
    unmatchedSystems: new Set(
      [...document.querySelectorAll('.expl-unmatched[data-system-code] button[aria-expanded="true"]')].map(
        (button) => button.parentElement.dataset.systemCode,
      ),
    ),
  };
}

function explRestoreOpenState(state) {
  for (const item of document.querySelectorAll("#expl-systems-list .rec-item[data-system-code]")) {
    if (state.systems.has(item.dataset.systemCode)) item.classList.add("open");
  }
  for (const item of document.querySelectorAll(".expl-collapse[data-expl-key]")) {
    if (state.collapses.has(item.dataset.explKey)) item.classList.add("open");
  }
  for (const block of document.querySelectorAll(".expl-unmatched[data-system-code]")) {
    if (state.unmatchedSystems.has(block.dataset.systemCode)) block.querySelector("button").click();
  }
}

function explNeedsRetry(data) {
  // loadExplanation вызывается после запуска полного пересчёта. После релиза диагностика может
  // быть очищена, поэтому missing здесь тоже временное состояние до завершения нового прогона.
  const unsettled = new Set(["pending", "previous_run", "missing"]);
  for (const system of data.systems ?? []) {
    if (unsettled.has(system.explanationState)) return true;
    if ((system.instruments ?? []).some((item) => unsettled.has(item.explanationState))) return true;
  }
  return (data.instrumentsOutsideSystems ?? []).some((item) => unsettled.has(item.explanationState));
}

// Блок разбора одной системы. Строится одинаково для всех систем ответа эндпоинта, в том числе
// для тех, которым не нашлось строки в таблице: в промежуточном режиме рассчитанных систем может
// не быть вовсе, а причины по инструментам нужны именно тогда.
function explSystemItem(system, clientId, baseUrl) {
  const item = document.createElement("div");
  item.className = "rec-item";
  item.dataset.systemCode = system.systemCode;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "rec-title";
  btn.textContent = system.systemName || system.systemCode;
  btn.addEventListener("click", () => item.classList.toggle("open"));
  const body = document.createElement("div");
  body.className = "rec-details";
  body.append(explSystemBody(system, clientId, baseUrl));
  item.append(btn, body);
  return item;
}

// Стык сводки и подробностей: обработчик на строке таблицы живёт в final_page.js, потому что
// строку создаёт он, а показ разбора — здесь, потому что аккордеон принадлежит этому модулю.
// Обработчик вешается заведомо раньше, чем загрузится разбор, поэтому отсутствие блока — штатное
// состояние, а не ошибка: возвращаем признак того, что показывать было что.
function explRevealSystem(systemCode) {
  const selector = `#expl-systems-list .rec-item[data-system-code="${CSS.escape(systemCode)}"]`;
  const item = document.querySelector(selector);
  if (!item) return false;
  item.classList.add("open");
  item.scrollIntoView({ behavior: "smooth", block: "start" });
  return true;
}

function explRenderOutside(instruments) {
  const block = document.getElementById("expl-outside-block");
  const list = document.getElementById("expl-outside-list");
  if (!instruments || !instruments.length) {
    block.hidden = true;
    return;
  }
  list.replaceChildren(...instruments.map(explInstrumentNode));
  block.hidden = false;
}

function explShowError(message) {
  const node = document.getElementById("calc-explanation-error");
  node.textContent = message;
  node.hidden = false;
  document.getElementById("calc-explanation").hidden = false;
}

// Вызывается после отрисовки таблицы систем и рекомендаций и ничего не блокирует: результаты уже
// на экране, разбор достраивается по мере готовности.
async function loadExplanation(clientId, baseUrl, retry = null) {
  const context = retry ?? { version: ++explLoadVersion, startedAt: Date.now() };
  if (retry === null) explUnmatchedCache.clear();
  const section = document.getElementById("calc-explanation");
  if (retry === null) section.hidden = true;
  document.getElementById("calc-explanation-error").hidden = true;
  document.getElementById("expl-outside-block").hidden = true;
  if (!clientId) return;

  const base = baseUrl.replace(/\/+$/, "");
  let data;
  try {
    data = await uiFetchJson(`${base}${EXPL_URL}?patientId=${encodeURIComponent(clientId)}`, { allow404: true });
  } catch (err) {
    // Прочие ошибки, включая отказ авторизации testing-API, — ошибка блока разбора: таблица
    // систем, рекомендации и данные пользователя остаются на месте.
    explShowError(`Не удалось загрузить разбор расчёта: ${err.message}`);
    return;
  }
  if (context.version !== explLoadVersion) return;
  if (data === null) return;
  if (data.diagnosticsAvailable === false) {
    explShowError("Диагностические данные недоступны. Причины расчёта определить нельзя.");
    return;
  }

  const signature = JSON.stringify(data);
  if (context.signature === signature) {
    if (explNeedsRetry(data) && Date.now() - context.startedAt < EXPL_RETRY_WINDOW_MS) {
      setTimeout(() => {
        if (context.version === explLoadVersion) loadExplanation(clientId, baseUrl, context);
      }, EXPL_RETRY_DELAY_MS);
    }
    return;
  }
  context.signature = signature;
  const openState = explCaptureOpenState();
  explClearRendered();
  const systems = data.systems ?? [];
  const items = systems.map((system) => explSystemItem(system, clientId, baseUrl));
  // Подсказка про выбор системы стоит у таблицы, а не у разбора, и появляется только когда
  // разбор загружен: без него выбирать строку нечего.
  document.getElementById("expl-hint").hidden = items.length === 0;
  document.getElementById("expl-systems-list").replaceChildren(...items);
  const outside = data.instrumentsOutsideSystems ?? [];
  explRenderOutside(outside);
  explRestoreOpenState(openState);
  section.hidden = systems.length === 0 && outside.length === 0;
  if (explNeedsRetry(data) && Date.now() - context.startedAt < EXPL_RETRY_WINDOW_MS) {
    setTimeout(() => {
      if (context.version === explLoadVersion) loadExplanation(clientId, baseUrl, context);
    }, EXPL_RETRY_DELAY_MS);
  }
}
