"use strict";

const BIOMARKER_CLINREC_INSTRUMENT_CODE = "biomarker_kr";

function buildBiomarkerClinicalOutcomes(medicalRisk, calculationResults) {
  const systemsByCode = new Map(
    (medicalRisk.systemInterpretationResults ?? []).map((system) => [system.systemCode, system]),
  );
  return (calculationResults ?? [])
    .filter((result) => (
      result.instrumentCode === BIOMARKER_CLINREC_INSTRUMENT_CODE
      && result.diseaseCode
      && result.systemCode
    ))
    .map((result) => ({ result, system: systemsByCode.get(result.systemCode) ?? null }));
}

// CommonJS-экспорт нужен только unit-тесту чистой корреляции; браузер использует глобальную функцию.
if (typeof module !== "undefined") module.exports = { buildBiomarkerClinicalOutcomes };
