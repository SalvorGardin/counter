#!/usr/bin/env bash
# Идемпотентное провижининг Elasticsearch для Kibana и Filebeat.
set -euo pipefail

readonly ES_URL="${ELASTICSEARCH_URL:-http://elasticsearch:9200}"
readonly SETUP_DIR="${ELASTICSEARCH_SETUP_DIR:-/setup}"
readonly POLICY_FILE="${SETUP_DIR}/docker-logs-ilm-policy.json"
readonly TEMPLATE_FILE="${SETUP_DIR}/docker-logs-index-template.json"

: "${ELASTIC_PASSWORD:?ELASTIC_PASSWORD is required}"
: "${KIBANA_PASSWORD:?KIBANA_PASSWORD is required}"
: "${FILEBEAT_PASSWORD:?FILEBEAT_PASSWORD is required}"

es_request() {
    curl \
        --fail \
        --silent \
        --show-error \
        --retry 5 \
        --connect-timeout 5 \
        --max-time 30 \
        --user "elastic:${ELASTIC_PASSWORD}" \
        "$@"
}

es_json() {
    local method="$1" path="$2" body="$3"
    es_request \
        --request "${method}" \
        --header "Content-Type: application/json" \
        --data-binary "${body}" \
        "${ES_URL}/${path}" >/dev/null
}

es_json_file() {
    local method="$1" path="$2" file="$3"
    es_request \
        --request "${method}" \
        --header "Content-Type: application/json" \
        --data-binary "@${file}" \
        "${ES_URL}/${path}" >/dev/null
}

json_escape() {
    local value="$1"
    value=${value//\\/\\\\}
    value=${value//\"/\\\"}
    value=${value//$'\n'/\\n}
    value=${value//$'\r'/\\r}
    value=${value//$'\t'/\\t}
    printf '%s' "${value}"
}

kibana_password_json=$(json_escape "${KIBANA_PASSWORD}")
filebeat_password_json=$(json_escape "${FILEBEAT_PASSWORD}")

es_json \
    POST \
    "_security/user/kibana_system/_password" \
    "{\"password\":\"${kibana_password_json}\"}"
echo "kibana_system password set"

es_json \
    PUT \
    "_security/role/filebeat_writer_role" \
    '{"cluster":["monitor"],"indices":[{"names":["docker-logs-*"],"privileges":["create_index","write","view_index_metadata"]}]}'
echo "filebeat_writer_role created"

es_json \
    PUT \
    "_security/user/filebeat_writer" \
    "{\"password\":\"${filebeat_password_json}\",\"roles\":[\"filebeat_writer_role\"]}"
echo "filebeat_writer user created"

es_json_file PUT "_ilm/policy/docker-logs-30d" "${POLICY_FILE}"
echo "docker-logs-30d ILM policy ensured"

es_json_file PUT "_index_template/docker-logs-retention" "${TEMPLATE_FILE}"
echo "docker-logs-retention index template ensured"

# Индексы создаются Filebeat по дням без rollover alias. Для существующих индексов ILM считает
# возраст от даты создания; на dev-сервере индексы старше 30 дней можно удалять без архива.
es_json \
    PUT \
    "docker-logs-*/_settings?allow_no_indices=true&expand_wildcards=open,closed" \
    '{"index.lifecycle.name":"docker-logs-30d","index.number_of_replicas":0}'
echo "docker-logs existing indices attached to ILM"
