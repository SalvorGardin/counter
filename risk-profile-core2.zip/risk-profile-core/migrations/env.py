import asyncio
from collections.abc import MutableMapping
from logging.config import fileConfig
from typing import Literal

from alembic import context
from sqlalchemy import Connection, create_engine
from sqlalchemy.ext.asyncio import create_async_engine

import src.models  # noqa: F401 — registers all ORM models with Base.metadata
from src.config import DatabaseConfigError, settings
from src.infra.database import Base
from src.infra.db_schemas import is_compared_schema

config = context.config
if config.config_file_name is not None:
    # disable_existing_loggers=False: миграции гоняются in-process из тест-фикстуры
    # (tests/conftest.py: command.upgrade), а дефолт fileConfig=True выключил бы уже
    # поднятый логгер "app" (logging.config гасит все существующие логгеры не из ini).
    # Тогда _MetricsHandler перестаёт эмитить и errors_total не растёт — падал бы
    # test_metrics_errors в полном прогоне (make test). В проде миграции — отдельный
    # CLI-процесс, там логгера "app" ещё нет, так что флаг ни на что не влияет.
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = Base.metadata

# Сигнатура фильтра задана alembic — повторяем её литералы, чтобы типы сходились.
_ObjectKind = Literal["schema", "table", "column", "index", "unique_constraint", "foreign_key_constraint"]
_ParentKind = Literal["schema_name", "table_name", "schema_qualified_table_name"]

# ORM объявляет физического владельца таблицы, поэтому без include_schemas alembic видел бы
# только public и предложил бы заново создать все 35 таблиц.


def include_name(
    name: str | None,
    type_: _ObjectKind,
    parent_names: MutableMapping[_ParentKind, str | None],
) -> bool:
    """Фильтр alembic: ограничивает сравнение схемами приложения, прочие имена пропускает как есть."""
    if type_ == "schema":
        return is_compared_schema(name)
    return True


# Движки миграций намеренно создаются без execution_options(schema_translate_map=...):
# alembic обязан видеть физическое размещение объектов, а не локальные представления рантайма.


def _get_db_url() -> str:
    # Read at call time so cfg.set_main_option() in tests takes effect before we use the URL.
    url = config.get_main_option("sqlalchemy.url")
    if url:
        return url
    # Логин миграций — свой, отдельный от рантайм-логинов: он входит во все роли-владельцы схем.
    if settings.migrations_db_url is None:
        raise DatabaseConfigError("RISK_MODEL_MIGRATIONS_DB_URL must be set and non-empty to run migrations")
    return settings.migrations_db_url.get_secret_value()


def run_migrations_offline() -> None:
    context.configure(
        url=_get_db_url(),
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        target_metadata=target_metadata,
        include_schemas=True,
        include_name=include_name,
    )
    with context.begin_transaction():
        context.run_migrations()


def _run_sync_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        include_schemas=True,
        include_name=include_name,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online_sync() -> None:
    """Run migrations using a synchronous engine (used when URL is a plain psycopg2 URL)."""
    engine = create_engine(_get_db_url())
    try:
        with engine.connect() as connection:
            _run_sync_migrations(connection)
    finally:
        engine.dispose()


async def run_migrations_online_async() -> None:
    """Run migrations using an asyncpg engine (default for application use)."""
    async_engine = create_async_engine(_get_db_url())
    try:
        async with async_engine.connect() as connection:
            await connection.run_sync(_run_sync_migrations)
    finally:
        await async_engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    import logging

    from sqlalchemy.exc import SQLAlchemyError

    try:
        url = _get_db_url()
        if url and (url.startswith("postgresql://") or url.startswith("postgresql+psycopg2://")):
            run_migrations_online_sync()
        else:
            asyncio.run(run_migrations_online_async())
    except (SQLAlchemyError, OSError):
        logging.getLogger(__name__).exception("Online migration failed")
        raise
