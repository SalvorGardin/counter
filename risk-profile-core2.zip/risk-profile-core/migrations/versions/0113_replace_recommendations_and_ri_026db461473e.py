"""0113_replace_recommendations_and_risk_factors_seed

Revision ID: 026db461473e
Revises: 98fefd2350da
Create Date: 2026-07-31 00:00:00.000000

Перезаливка recommendations и risk_factors из catalog/0113_026db461473e_<entity>.csv
(свежий снимок из админки). Остальные справочники (options, questions, conditions,
parameters_score, instruments_parameters) не трогаем — они не менялись с 0111.

risk_factors: 521 -> 515 логических строк (естественный ключ parameter_code+code+
param_value+min_param_value+max_param_value+system_code без дублей — проверено).
recommendations: 155 -> 145 логических строк.

FK risk_factors -> parameters.code / systems.code (RESTRICT) и recommendations ->
systems.code (RESTRICT) не задеваем: все parameter_code/system_code нового набора
присутствуют в сидах 0096/0103. FK recommendations -> risk_factors снят в 0096
(связь risk_factors_code+system_code живёт на уровне приложения) — проверено, что
все пары risk_factor_group-рекомендаций в новом наборе ссылаются на существующие
пары (code, system_code) в новом risk_factors.

Порядок DELETE/INSERT: recommendations перед risk_factors как в прошлых миграциях,
парных FK между ними в БД нет, порядок значения не имеет.

downgrade возвращает предыдущие сиды: recommendations -> 0102, risk_factors -> 0111.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "026db461473e"
down_revision: str | None = "98fefd2350da"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = {
    "recommendations": _CATALOG / "0113_026db461473e_recommendations.csv",
    "risk_factors": _CATALOG / "0113_026db461473e_risk_factors.csv",
}
_OLD = {
    "recommendations": _CATALOG / "0102_5cf098fad5d6_recommendations.csv",
    "risk_factors": _CATALOG / "0111_06526a399cf8_risk_factors.csv",
}

_INSERT_RECOMMENDATIONS = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)


def _parse_recommendations(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": r["recommendations_group"],
            "risk_factors_code": r["risk_factors_code"] or None,
            "system_code": r["system_code"],
            "name": r["name"],
            "text": r.get("text") or None,
        }
        for r in load_csv(path)
    ]


def _parse_risk_factors(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r["modifiability"],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r["reasoning"] or None,
            "system_code": r["system_code"] or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _replace(seeds: dict[str, Path]) -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM recommendations"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM risk_factors"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_RISK_FACTORS), _parse_risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _parse_recommendations(seeds["recommendations"]))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
