"""0131_add_results_disease_code

Revision ID: 7be0d4915caf
Revises: 9c2e07ab4d16
Create Date: 2026-08-28 11:20:00.000000

`disease_code` в `results` и `results_history` — группа заболеваний, в разрезе которой посчитан
результат. Заполнена только у расчёта по клиническим рекомендациям; у калькуляторов и опросников
группы нет, поэтому колонка nullable.

Уникальный ключ `results` расширяется группой заболеваний отдельной ревизией: перезаведение
ключа берёт на таблицу ACCESS EXCLUSIVE, и откатывать его нужно независимо от самой колонки.

Блокировки не разнесены на `NOT VALID` + `VALIDATE CONSTRAINT` и `CREATE INDEX CONCURRENTLY`
намеренно: добавление внешнего ключа сканирует `results`/`results_history` под
SHARE ROW EXCLUSIVE, построение индекса держит SHARE, и на это время запись в таблицы встаёт.
Миграция накатывается в окне технических работ, поэтому простая форма предпочтена
неблокирующей — она короче и её downgrade тривиален.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "7be0d4915caf"
down_revision: str | None = "9c2e07ab4d16"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    for table in ("results", "results_history"):
        op.add_column(table, sa.Column("disease_code", sa.String(), nullable=True))
        op.create_foreign_key(
            op.f(f"fk_{table}_diseases_disease_code"),
            table,
            "diseases",
            ["disease_code"],
            ["code"],
            ondelete="RESTRICT",
        )
    # Индекс — по стилю таблицы: в results_history колонки внешних ключей индексируются,
    # в results нет.
    op.create_index(op.f("ix_results_history_disease_code"), "results_history", ["disease_code"])


def downgrade() -> None:
    op.drop_index(op.f("ix_results_history_disease_code"), table_name="results_history")
    for table in ("results_history", "results"):
        op.drop_constraint(op.f(f"fk_{table}_diseases_disease_code"), table, type_="foreignkey")
        op.drop_column(table, "disease_code")
