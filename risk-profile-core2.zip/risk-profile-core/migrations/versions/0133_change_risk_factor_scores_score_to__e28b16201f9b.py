"""0133_change_risk_factor_scores_score_to_integer

Revision ID: e28b16201f9b
Revises: 2fd8a61c9074
Create Date: 2026-08-31 12:12:41.668348

Балл фактора риска в группе заболеваний — целое число. Дробная часть у балла смысла не имеет:
справочник задаёт его целыми значениями, а расчёт сравнивает балл точным равенством с порогом.

Приведение `Numeric(6, 3)` к `integer` округляет дробные значения, поэтому перед DDL проверяем,
что таких строк нет: молча округлённый балл поменял бы состав факторов, попадающих под порог.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "e28b16201f9b"
down_revision: str | None = "2fd8a61c9074"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    conn = op.get_bind()
    fractional = conn.execute(
        sa.text("SELECT count(*) FROM risk_factor_scores WHERE score <> trunc(score)")
    ).scalar_one()
    if fractional:
        raise RuntimeError(
            f"risk_factor_scores: {fractional} row(s) have a fractional score; "
            "resolve them before narrowing the column to integer"
        )
    op.alter_column(
        "risk_factor_scores",
        "score",
        existing_type=sa.Numeric(precision=6, scale=3),
        type_=sa.Integer(),
        existing_nullable=False,
        nullable=False,
        postgresql_using="score::integer",
    )


def downgrade() -> None:
    op.alter_column(
        "risk_factor_scores",
        "score",
        existing_type=sa.Integer(),
        type_=sa.Numeric(precision=6, scale=3),
        existing_nullable=False,
        nullable=False,
    )
