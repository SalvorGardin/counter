"""0129_create_biomarker_parameter_mappings_table

Revision ID: 5ad1c860f273
Revises: f70d95b3ea41
Create Date: 2026-08-28 11:00:00.000000

Разметка «биомаркер заполняет параметр расширенного опросника»: маппинг `value` переносит
значение как есть, маппинг `flag` сравнивает значение с границей нормы и записывает вариант
ответа при отклонении.

Обе стороны маппинга ссылаются на `parameters.code`: и параметр-биомаркер, и заполняемый
параметр опросника лежат в одном справочнике.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "5ad1c860f273"
down_revision: str | None = "f70d95b3ea41"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_INDEXED_COLUMNS = ("biomarker_parameter_code", "parameter_code", "option_code")


def upgrade() -> None:
    op.create_table(
        "biomarker_parameter_mappings",
        sa.Column("biomarker_parameter_mapping_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("biomarker_parameter_code", sa.String(), nullable=False),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("mapping_type", sa.String(), nullable=False),
        sa.Column("operator", sa.String(), nullable=True),
        sa.Column("value_num", sa.Numeric(precision=12, scale=6), nullable=True),
        sa.Column("option_code", sa.String(), nullable=True),
        sa.Column("unit", sa.String(), nullable=True),
        sa.CheckConstraint(
            "mapping_type IN ('value', 'flag')",
            name=op.f("ck_biomarker_parameter_mappings_mapping_type"),
        ),
        sa.CheckConstraint(
            "operator IS NULL OR operator IN ('gt', 'gte', 'lt', 'lte', 'eq')",
            name=op.f("ck_biomarker_parameter_mappings_operator"),
        ),
        # Условие отклонения от нормы заполнено целиком у flag и пусто целиком у value:
        # частичная строка описывала бы правило, которое нельзя применить.
        sa.CheckConstraint(
            "(mapping_type = 'flag' AND operator IS NOT NULL AND value_num IS NOT NULL "
            "AND option_code IS NOT NULL) OR "
            "(mapping_type = 'value' AND operator IS NULL AND value_num IS NULL AND option_code IS NULL)",
            name=op.f("ck_biomarker_parameter_mappings_shape"),
        ),
        sa.ForeignKeyConstraint(
            ["biomarker_parameter_code"],
            ["parameters.code"],
            name=op.f("fk_biomarker_parameter_mappings_biomarker_parameter_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["parameter_code"],
            ["parameters.code"],
            name=op.f("fk_biomarker_parameter_mappings_parameter_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["option_code"],
            ["options.code"],
            name=op.f("fk_biomarker_parameter_mappings_option_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("biomarker_parameter_mapping_id", name=op.f("pk_biomarker_parameter_mappings")),
        sa.UniqueConstraint(
            "biomarker_parameter_code",
            "parameter_code",
            name=op.f("uq_biomarker_parameter_mappings_source_target"),
        ),
    )
    for column in _INDEXED_COLUMNS:
        op.create_index(op.f(f"ix_biomarker_parameter_mappings_{column}"), "biomarker_parameter_mappings", [column])


def downgrade() -> None:
    for column in _INDEXED_COLUMNS:
        op.drop_index(op.f(f"ix_biomarker_parameter_mappings_{column}"), table_name="biomarker_parameter_mappings")
    op.drop_table("biomarker_parameter_mappings")
