"""0105_fix_low_platelets_score_value

Revision ID: ef9934ec3bce
Revises: e0b27d2ebc69
Create Date: 2026-07-07 00:00:00.000000

Правит справочник parameter_scores для параметра Low_Platelets (система BLOOD): балл 3
теперь начисляется при ответе «Да» (тромбоциты понижены), а не при «Нет». Прежнее значение
value='Нет' было ошибкой — по задаче #121 (@badretdinovaar) начислять 3 балла нужно при
подтверждении низких тромбоцитов.

Точечный идемпотентный UPDATE по одной строке. Каталог-сид
catalog/0096_..._parameters_score.csv поправлен синхронно (Low_Platelets → «Да»), чтобы
свежая установка и будущий reseed не вернули «Нет» (тот же приём, что в 0099).
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "ef9934ec3bce"
down_revision: str | None = "e0b27d2ebc69"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_NEW_VALUE_SQL = (
    "UPDATE parameter_scores SET value = 'Да' "
    "WHERE parameter_code = 'Low_Platelets' AND system_code = 'BLOOD' AND value = 'Нет'"
)
_OLD_VALUE_SQL = (
    "UPDATE parameter_scores SET value = 'Нет' "
    "WHERE parameter_code = 'Low_Platelets' AND system_code = 'BLOOD' AND value = 'Да'"
)


def upgrade() -> None:
    op.get_bind().execute(sa.text(_NEW_VALUE_SQL))


def downgrade() -> None:
    op.get_bind().execute(sa.text(_OLD_VALUE_SQL))
