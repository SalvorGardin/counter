"""0096_replace_recommendations_seed

Revision ID: a460718b3b84
Revises: e6007cc2c395
Create Date: 2026-06-25 17:14:51.277169

Полная перезаливка справочников из обновлённых catalog/0096_a460718b3b84_*.csv.
Схема НЕ меняется — таблицы уже в актуальном виде (questions без response_type/
category и options без score после 0092, risk_factors с составным ключом после 0090/0091).

parameters и questions заливаются через UPSERT (а не DELETE+INSERT):
  - parameters.code — на неё ссылаются patients_parameters/_history с ON DELETE RESTRICT
    (реальные ответы пациентов, PII), поэтому исчезнувшие из каталога коды не удаляются,
    а помечаются status='inactive' (soft-delete, как в 0078). parameter_id из CSV
    игнорируется — им владеет serial.
  - questions.code — на неё ссылается conditions с ON DELETE RESTRICT (сид conditions
    в 0096 не трогается), поэтому DELETE FROM questions падал бы на FK. Коды, пропавшие
    из каталога, не удаляются.

Естественный ключ risk_factors расширяется (uq(code, system_code) → uq по полному ключу
parameter_code+code+param_value+min+max+system, NULLS NOT DISTINCT): один code+system
повторяется по параметрам (fr_extreme_sport — строка на каждый вид спорта) и по бакетам
param_value/min/max (диета, окружность талии). Составной FK recommendations→risk_factors
снимается совсем — навесить FK можно только на UNIQUE-набор, а (code, system_code) им быть
перестаёт; связь recommendations↔risk_factors остаётся прикладной (matching в reader'ах).
См. _widen_natural_key / _restore_narrow_key.

Остальные пять таблиц перезаливаются целиком. Порядок диктуют FK (все ON DELETE RESTRICT):
  options         -> questions, parameters
  parameter_scores-> parameters, systems
  instruments_parameters -> instruments, parameters
  risk_factors    -> parameters, systems

DELETE — от детей к родителям; INSERT — от родителей к детям; parameters и questions
апсертятся первыми, т.к. на них ссылаются дочерние таблицы. systems/instruments не
трогаем — это внешние родители, их коды в новых CSV уже существуют.

Перед перезаливкой options ответы пациентов ремапятся под переименованные value:
patients_parameters(+_history).value хранит выбранный текст опции строкой, а перезаливка
переименовывает ~100 опций (напр. breast_biopsies_count «Да - 1 раз» → «Один раз»). Без
ремапа исторический ответ повисает сиротой и calc-формулы с bare dict lookup падают KeyError
(BCRAT — см. src/calc/domain/formulas/bcrat.py). См. _option_value_renames/_remap_patient_answers;
downgrade ремапит симметрично обратно (source/target меняются местами через options_other).

downgrade возвращает предыдущие сиды: parameters→0078, questions→0092, risk_factors→0091
(колонка modifiability вместо modofiability), options→0083, parameter_scores→0076,
instruments_parameters→0086, recommendations→0091, плюс сужает ключ обратно и чинит FK.
"""

from collections.abc import Sequence
from datetime import datetime
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "a460718b3b84"
down_revision: str | None = "e6007cc2c395"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

# --- новые каталоги (upgrade) ---
_NEW_PARAMS = _CATALOG / "0096_a460718b3b84_parameters.csv"
_NEW_QUESTIONS = _CATALOG / "0096_a460718b3b84_questions.csv"
_NEW_RISK_FACTORS = _CATALOG / "0096_a460718b3b84_risk_factors.csv"
_NEW_OPTIONS = _CATALOG / "0096_a460718b3b84_options.csv"
_NEW_PARAM_SCORES = _CATALOG / "0096_a460718b3b84_parameters_score.csv"
_NEW_INSTR_PARAMS = _CATALOG / "0096_a460718b3b84_instruments_parameters.csv"
_NEW_RECS = _CATALOG / "0096_a460718b3b84_recommendations.csv"

# --- предыдущие сиды (downgrade) ---
_OLD_PARAMS = _CATALOG / "0078_052d370886bd_parameters.csv"
_OLD_QUESTIONS = _CATALOG / "0092_a75418e929f6_questions.csv"
_OLD_RISK_FACTORS = _CATALOG / "0091_414089eafa17_risk_factors.csv"
_OLD_OPTIONS = _CATALOG / "0083_c3753bb6d51f_options.csv"
_OLD_PARAM_SCORES = _CATALOG / "0076_f447edd785c0_parameters_score.csv"
_OLD_INSTR_PARAMS = _CATALOG / "0086_cad1a0c0ffee_instrument_parameters.csv"
_OLD_RECS = _CATALOG / "0091_414089eafa17_recommendations.csv"

# validity_period семантически — длительность от UNIX-эпохи; 1980-01-01 = дефолт каталога.
# datetime (а не строка!): asyncpg биндит timestamptz только из datetime, строку (как
# psycopg2 в тестах) он не коэрсит — отсюда DataError на проде. Парсим в _parse_params.
_DEFAULT_VALIDITY = datetime.fromisoformat("1980-01-01 00:00:00+00")

# parameter_id не трогаем — им владеет serial; code уникален и служит ключом конфликта.
_UPSERT_PARAM_SQL = (
    "INSERT INTO parameters (code, description, status, validity_period) "
    "VALUES (:code, :description, :status, :validity_period) "
    "ON CONFLICT (code) DO UPDATE SET "
    "description = EXCLUDED.description, status = EXCLUDED.status, validity_period = EXCLUDED.validity_period"
)
# questions — UPSERT (а не DELETE+INSERT): на questions.code ссылается conditions
# (fk_conditions_questions_question_code, ON DELETE RESTRICT), сид которой 0096 не трогает,
# поэтому DELETE FROM questions падал бы на FK. Коды, пропавшие из каталога, не удаляем —
# оставляем как есть (conditions может на них ссылаться).
_UPSERT_QUESTION_SQL = (
    "INSERT INTO questions (code, question, type, group_code, is_skippable) "
    "VALUES (:code, :question, :type, :group_code, :is_skippable) "
    "ON CONFLICT (code) DO UPDATE SET "
    "question = EXCLUDED.question, "
    "type = EXCLUDED.type, "
    "group_code = EXCLUDED.group_code, "
    "is_skippable = EXCLUDED.is_skippable"
)
_INSERT_RF_SQL = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)
_INSERT_OPTION_SQL = (
    "INSERT INTO options (question_code, parameter_code, code, value) "
    "VALUES (:question_code, :parameter_code, :code, :value)"
)
_INSERT_PSCORE_SQL = (
    "INSERT INTO parameter_scores (parameter_code, value, min_value, max_value, system_code, score) "
    "VALUES (:parameter_code, :value, :min_value, :max_value, :system_code, :score)"
)
_INSERT_INSTR_SQL = (
    "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)
_INSERT_REC_SQL = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)


def _numeric(s: str) -> str | None:
    s = s.replace(",", ".").rstrip("+").strip()
    return s or None


def _parse_params(path: Path) -> list[dict]:
    # load_csv уже .strip()-ает значения — снимает хвостовые пробелы/переводы строк в кодах.
    return [
        {
            "code": r["code"],
            "description": r["description"] or None,
            "status": r["status"] or "active",
            "validity_period": (
                datetime.fromisoformat(raw) if (raw := r.get("validity_period")) else _DEFAULT_VALIDITY
            ),
        }
        for r in load_csv(path)
    ]


def _parse_questions(path: Path) -> list[dict]:
    # Новый CSV содержит лишние response_type/category — их в схеме больше нет (0092), игнорируем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "type": r["type"],
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
            "is_skippable": bool(int(r["is_skippable"])) if r["is_skippable"] else False,
        }
        for r in load_csv(path)
    ]


def _parse_risk_factors(path: Path, *, modifiability_col: str) -> list[dict]:
    # Пустые строки-артефакты (без code) пропускаем; modifiability_col отличается между
    # новым CSV (modofiability, опечатка) и сидом 0091 (modifiability).
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r[modifiability_col],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r.get("reasoning") or None,
            "system_code": r.get("system_code") or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_options(path: Path) -> list[dict]:
    # options.score удалён в 0092 — колонку CSV (если есть) не читаем.
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "value": r["value"] or None,
        }
        for r in load_csv(path)
    ]


def _parse_param_scores(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            "value": _numeric(r["value"]),
            "min_value": _numeric(r["min_value"]),
            "max_value": _numeric(r["max_value"]),
            "system_code": r["system_code"],
            "score": _numeric(r["score"]),
        }
        for r in load_csv(path)
    ]


def _parse_instr_params(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
    ]


def _parse_recs(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": r["recommendations_group"],
            "risk_factors_code": r["risk_factors_code"] or None,
            "system_code": r["system_code"],
            "name": r["name"],
            "text": r.get("text") or None,
        }
        for r in load_csv(path)
    ]


def _option_value_renames(source: Path, target: Path) -> list[dict]:
    """Опции, у которых сменился отображаемый value (естественный ключ опции — parameter_code+code).

    Возвращает [{"param", "old", "new"}]: source — сид, который сейчас в БД (его value лежат
    в patients_parameters.value как ответы пациентов), target — устанавливаемый сид.
    """

    def by_code(path: Path) -> dict[tuple[str, str], str | None]:
        return {(r["parameter_code"], r["code"]): (r["value"] or None) for r in load_csv(path)}

    src, tgt = by_code(source), by_code(target)
    return [
        {"param": param_code, "old": old_value, "new": new_value}
        for (param_code, code), old_value in src.items()
        if (new_value := tgt.get((param_code, code))) and old_value and old_value != new_value
    ]


def _remap_patient_answers(renames: list[dict]) -> None:
    """SET value=new в patients_parameters(+_history) для исторических ответов по (parameter_code, old).

    Опции переименовываются перезаливкой (DELETE+INSERT в _reseed), но ответы пациентов — это PII
    с FK ON DELETE RESTRICT, их не трогаем, а value они хранят выбранной строкой опции. Без ремапа
    старый текст пропадает из справочника, и calc-формулы с bare dict lookup падают KeyError на всей
    исторической базе (см. src/calc/domain/formulas/bcrat.py). Цепочечных/неоднозначных
    переименований в сидах нет (проверено), поэтому порядок UPDATE-ов неважен.
    """
    if not renames:
        return
    conn = op.get_bind()
    for table in ("patients_parameters", "patients_parameters_history"):
        # nosec B608 — table из захардкоженного литерала, не пользовательский ввод
        sql = sa.text(f"UPDATE {table} SET value = :new WHERE parameter_code = :param AND value = :old")  # nosec B608  # nosemgrep: python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
        conn.execute(sql, renames)


def _upsert_parameters(new_path: Path, other_path: Path) -> None:
    """Апсерт parameters из new_path; коды, пропавшие относительно other_path, → status='inactive'."""
    conn = op.get_bind()
    new_rows = _parse_params(new_path)
    conn.execute(sa.text(_UPSERT_PARAM_SQL), new_rows)
    disappeared = sorted({r["code"] for r in _parse_params(other_path)} - {r["code"] for r in new_rows})
    if disappeared:
        conn.execute(
            sa.text("UPDATE parameters SET status = 'inactive' WHERE code IN :codes").bindparams(
                sa.bindparam("codes", expanding=True)
            ),
            {"codes": disappeared},
        )


def _reseed(
    *,
    params_new: Path,
    params_other: Path,
    questions: Path,
    risk_factors: Path,
    rf_modifiability_col: str,
    options: Path,
    options_other: Path,
    param_scores: Path,
    instr_params: Path,
    recs: Path,
) -> None:
    conn = op.get_bind()

    # parameters: upsert + soft-delete (никогда не DELETE — PII-FK с RESTRICT).
    _upsert_parameters(params_new, params_other)

    # questions апсертится (не удаляется) — на неё ссылается conditions с ON DELETE RESTRICT.
    conn.execute(sa.text(_UPSERT_QUESTION_SQL), _parse_questions(questions))

    # Ремап ответов пациентов под переименованные value опций — ДО DELETE FROM options.
    # options_other — текущий в БД сид (source), options — устанавливаемый (target).
    _remap_patient_answers(_option_value_renames(options_other, options))

    # DELETE — от детей к родителям. questions здесь нет (см. выше — UPSERT).
    for table in (
        "recommendations",
        "options",
        "parameter_scores",
        "instruments_parameters",
        "risk_factors",
    ):
        conn.execute(sa.text(f"DELETE FROM {table}"))  # nosec B608 — table из захардкоженного литерала, не пользовательский ввод  # nosemgrep: python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text

    # INSERT — от родителей к детям.
    conn.execute(sa.text(_INSERT_RF_SQL), _parse_risk_factors(risk_factors, modifiability_col=rf_modifiability_col))
    conn.execute(sa.text(_INSERT_OPTION_SQL), _parse_options(options))
    conn.execute(sa.text(_INSERT_PSCORE_SQL), _parse_param_scores(param_scores))
    conn.execute(sa.text(_INSERT_INSTR_SQL), _parse_instr_params(instr_params))
    conn.execute(sa.text(_INSERT_REC_SQL), _parse_recs(recs))


# --- естественный ключ risk_factors ---
_OLD_UQ = "uq_risk_factors_code_system_code"
_NEW_UQ = "uq_risk_factors_natural_key"
_REC_FK = "fk_recommendations_risk_factors_code_system_code"
# Полный естественный ключ фактора: один code+system повторяется по параметрам
# (напр. fr_extreme_sport — отдельная строка на каждый вид спорта) и по бакетам
# param_value/min/max (диета, окружность талии и т.п.). NULLS NOT DISTINCT — чтобы
# пустые param_value/min/max (NULL) считались равными и случайные точные дубли ловились.
_NATURAL_KEY_COLS = ["parameter_code", "code", "param_value", "min_param_value", "max_param_value", "system_code"]


def _widen_natural_key() -> None:
    """uq(code, system_code) -> uq(полный ключ). FK recommendations снимаем совсем.

    FK можно навесить только на UNIQUE-набор, а после расширения (code, system_code)
    уникальным быть перестаёт. recommendations -> risk_factors остаётся связью на уровне
    приложения (matching по risk_factors_code+system_code в reader'ах, БД-целостность теряем).
    Сначала FK (висит на старом uq), потом сам uq.
    """
    op.drop_constraint(_REC_FK, "recommendations", type_="foreignkey")
    op.drop_constraint(_OLD_UQ, "risk_factors", type_="unique")
    op.create_unique_constraint(_NEW_UQ, "risk_factors", _NATURAL_KEY_COLS, postgresql_nulls_not_distinct=True)


def _restore_narrow_key() -> None:
    """Откат: полный ключ -> uq(code, system_code) + воссоздание FK recommendations.

    Вызывается ПОСЛЕ восстановления узких данных (_reseed старого сида), иначе uq(code,
    system_code) не натянется на расширенный набор строк.
    """
    op.drop_constraint(_NEW_UQ, "risk_factors", type_="unique")
    op.create_unique_constraint(_OLD_UQ, "risk_factors", ["code", "system_code"])
    op.create_foreign_key(
        _REC_FK,
        "recommendations",
        "risk_factors",
        ["risk_factors_code", "system_code"],
        ["code", "system_code"],
        ondelete="RESTRICT",
    )


def upgrade() -> None:
    # Сначала расширяем ключ (new CSV с дублями code+system иначе не вставить), потом заливка.
    _widen_natural_key()
    _reseed(
        params_new=_NEW_PARAMS,
        params_other=_OLD_PARAMS,
        questions=_NEW_QUESTIONS,
        risk_factors=_NEW_RISK_FACTORS,
        rf_modifiability_col="modofiability",
        options=_NEW_OPTIONS,
        options_other=_OLD_OPTIONS,
        param_scores=_NEW_PARAM_SCORES,
        instr_params=_NEW_INSTR_PARAMS,
        recs=_NEW_RECS,
    )


def downgrade() -> None:
    # Сначала возвращаем узкий сид (одна строка на code+system), затем сужаем ключ и чиним FK.
    _reseed(
        params_new=_OLD_PARAMS,
        params_other=_NEW_PARAMS,
        questions=_OLD_QUESTIONS,
        risk_factors=_OLD_RISK_FACTORS,
        rf_modifiability_col="modifiability",
        options=_OLD_OPTIONS,
        options_other=_NEW_OPTIONS,
        param_scores=_OLD_PARAM_SCORES,
        instr_params=_OLD_INSTR_PARAMS,
        recs=_OLD_RECS,
    )
    _restore_narrow_key()
