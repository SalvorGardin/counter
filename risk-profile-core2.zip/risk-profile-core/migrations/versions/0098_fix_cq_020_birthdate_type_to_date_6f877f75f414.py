"""0098_fix_cq_020_birthdate_type_to_date

Revision ID: 6f877f75f414
Revises: 9086772873a5
Create Date: 2026-06-30 11:36:40.182550

Чинит тип вопроса даты рождения cq_020 («Укажите вашу дату рождения»): date вместо numeric.

История регрессии: 0092 уже выставлял cq_020.type='date', но полная перезаливка questions
в 0096 (UPSERT ... DO UPDATE SET type=EXCLUDED.type из catalog/0096_..._questions.csv, где
cq_020 снова numeric) затёрла фикс. В итоге risk-communication гонит ответ-дату через
coerce_numeric_answer и отвечает 400 INVALID_ANSWER_TYPE ("answer is not a valid numeric
value: '1987-05-14'"). Значение birthdate хранится в ISO (risk-init пишет date.isoformat(),
conditions читает date.fromisoformat) — при type='date' ответ сохраняется как есть и совместим.

Точечный идемпотентный UPDATE по одному коду (не перезаливка questions): на questions.code
ссылается conditions с ON DELETE RESTRICT, поэтому полный reseed здесь не нужен и опасен.
Эта миграция чинит уже задеплоенные БД, где 0096 отработал с numeric.

Синхронно поправлен и источник правды catalog/0096_a460718b3b84_questions.csv (cq_020 → date),
чтобы свежая установка получала date сразу из 0096, а следующий полный reseed questions не
скопировал numeric из устаревшего CSV. Защита от рецидива — тест
tests/integration/risk_communication/test_birthdate_question_type.py (падает, если после
upgrade head cq_020.type != 'date').
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "6f877f75f414"
down_revision: str | None = "9086772873a5"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.get_bind().execute(sa.text("UPDATE questions SET type = 'date' WHERE code = 'cq_020'"))


def downgrade() -> None:
    op.get_bind().execute(sa.text("UPDATE questions SET type = 'numeric' WHERE code = 'cq_020'"))
