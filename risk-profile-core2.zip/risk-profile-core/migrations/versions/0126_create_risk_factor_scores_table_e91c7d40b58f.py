"""0126_create_risk_factor_scores_table

Revision ID: e91c7d40b58f
Revises: b62a4f18d3c9
Create Date: 2026-08-28 10:30:00.000000

Балл и влияние фактора риска в группе заболеваний. Таблица реализует связь «многие-ко-многим»
фактор ↔ группа: балл фактора в группе задаётся один раз.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "e91c7d40b58f"
down_revision: str | None = "b62a4f18d3c9"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "risk_factor_scores",
        sa.Column("risk_factor_score_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("risk_factor_code", sa.String(), nullable=False),
        sa.Column("disease_code", sa.String(), nullable=False),
        sa.Column("score", sa.Numeric(precision=6, scale=3), nullable=False),
        sa.Column("influence", sa.String(), nullable=False),
        sa.CheckConstraint(
            "influence IN ('increase', 'decrease', 'undetermined')",
            name=op.f("ck_risk_factor_scores_influence"),
        ),
        sa.ForeignKeyConstraint(
            ["risk_factor_code"],
            ["risk_factors.code"],
            name=op.f("fk_risk_factor_scores_risk_factors_risk_factor_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["disease_code"],
            ["diseases.code"],
            name=op.f("fk_risk_factor_scores_diseases_disease_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("risk_factor_score_id", name=op.f("pk_risk_factor_scores")),
        sa.UniqueConstraint(
            "risk_factor_code",
            "disease_code",
            name=op.f("uq_risk_factor_scores_risk_factor_code_disease_code"),
        ),
    )
    for column in ("risk_factor_code", "disease_code"):
        op.create_index(op.f(f"ix_risk_factor_scores_{column}"), "risk_factor_scores", [column])


def downgrade() -> None:
    for column in ("risk_factor_code", "disease_code"):
        op.drop_index(op.f(f"ix_risk_factor_scores_{column}"), table_name="risk_factor_scores")
    op.drop_table("risk_factor_scores")
