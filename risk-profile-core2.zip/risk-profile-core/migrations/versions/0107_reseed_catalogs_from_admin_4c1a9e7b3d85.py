"""0107_reseed_catalogs_from_admin

Revision ID: 4c1a9e7b3d85
Revises: 9b3d7bd1495d
Create Date: 2026-07-15 00:00:00.000000

Проливка шести справочников из админки risk-profile-admin (снимки на 15.07):
conditions v4, options v6, questions v10, parameters_score v15, recommendations v17,
risk_factors v145. Экспорты лежат в catalog/0107_4c1a9e7b3d85_<entity>.csv.

Пролиты ТОЛЬКО те справочники, которые аналитик реально правил в админке. Остальные
семь не трогаем: doctors / instruments / recommended_doctors / systems /
systems_instruments совпадают со стендом байт-в-байт, а parameters и
instrument_parameters в админке остались нетронутым импортом v1 от 02.07 — там впереди
core, а не админка (см. «Чего эта миграция НЕ делает»).

Дельта к состоянию стенда на 0106:
  • conditions      +6 / −7   min_age 0→1 у sq_0360/0370/0390/0400/0420; +sq_1030 (age 30–100);
                              −2 except-условия sq_0080 (вместе с самим вопросом, см. ниже).
  • options         47 строк  BDI/STAI: убраны финальные точки, гендерные формы
                              («раздражителен» → «раздражителен(на)»), в BDI14_03 убран \\n.
  • questions       10 правок текста; −3 строки: sq_0080 / sq_0820 / sq_0830.
  • parameters_score 27 строк  diastolic_bp max 150→200, systolic_bp max 250→300,
                              family_alzheimer/family_parkinson «Затрудняюсь ответить» CVD→NEURO,
                              neuro_cancer «Да» 4→5, physical_activity_level «Да»→«Нет»,
                              changing_moles «Не уверен(а)»→«Не знаю»,
                              unexplained_weight_loss → unexplained_weight_fluct,
                              плюс восстановление запятых в тексте (см. «Порча текста» ниже).
  • recommendations +28 / −4
  • risk_factors    +14 новых строк, 3 правки пробелов в param_value
                    («Регулярно /1–2 раза в неделю» → «Регулярно / 1–2 раза в неделю»).

Почему parameters_score и risk_factors ОБЯЗАНЫ ехать одной миграцией: risk_factors.param_value
сопоставляется с parameter_scores.value по тексту, а аналитик поправил пробелы после «/» в
обеих таблицах. Пролив по отдельности разъедет связку alcohol × GI/URO.

Удаление sq_0080 / sq_0820 / sq_0830 безопасно: этих кодов нет ни в одном сиде и ни в
источнике импорта админки — это сироты в БД стенда, пережившие UPSERT-only перезаливки
(та же природа, что у сирот 0057, вычищенных в 0065). options на них не ссылается,
ответов пациентов по ним нет; единственные ссылки — 2 строки conditions, которые
админка сносит согласованно в этой же миграции.

Порча текста в parameter_scores.value (чинится здесь же). Сид 0096 парсил колонку `value`
через _numeric(), а тот делает s.replace(",", "."). `value` — character varying с текстом
ответа, поэтому каждая запятая в русском тексте превращалась в точку: на стенде 14 строк
вида «Да. было однократно» вместо «Да, было однократно». В самих CSV-сидах запятые целы —
портил загрузчик. Здесь _numeric() применяется только к min_value/max_value/score
(единственная реальная нужда — десятичная запятая «0,5» в score), а `value` пишется как
есть. DELETE+INSERT из чистого экспорта лечит все 14 строк.

Low_Platelets × BLOOD: в экспорте админки value='Нет', но в CSV этой миграции лежит 'Да' —
правка внесена сознательно. 'Да' — это фикс 0105 по задаче #121 (@badretdinovaar: 3 балла
начисляются при ПОДТВЕРЖДЕНИИ низких тромбоцитов). Админка про #121 не знает: 'Нет'
приехало туда bulk-выгрузкой каталогов от 26.06 (risk-profile-admin, коммит 4051683) и за
15 версий его никто не трогал — значения 'Да' в истории админки не было ни разу. Правим
CSV синхронно (тот же приём, что в 0101/0105), чтобы следующий reseed не вернул 'Нет';
расхождение с админкой остаётся живым, пока аналитик не поправит строку у себя.

Чего эта миграция НЕ делает (осознанно):
  • parameters — в админке v1 (импорт 02.07, ни одной правки). Стенд впереди на 12 строк
    sports_* (status=inactive). Пролив снёс бы их, а FK parameter_scores/risk_factors →
    parameters (ON DELETE RESTRICT) на этом бы и упал.
  • instrument_parameters — в админке v1 (399 строк) против 454 на стенде. Пролив откатил бы
    0104 (7 анамнез-параметров form_cvd/form_endo/form_onco/form_resp обратно в required) и
    заново сломал бы #122.
Обе таблицы нужно сначала выгрузить из core в админку, а не наоборот.

Схема НЕ меняется. Порядок DELETE/INSERT продиктован FK на questions
(options.question_code и conditions.question_code, оба ON DELETE RESTRICT):
сначала сносим детей, потом questions; вставляем в обратном порядке.
risk_factors_code в recommendations — не FK (снят в 0096).
Родители parameters/systems/doctors не трогаются, все FK и uq_risk_factors_natural_key
на новом наборе проверены заранее.

downgrade возвращает предыдущие сиды: conditions → 0074, options → 0097,
parameters_score → 0096, recommendations → 0102, risk_factors → 0106. Точечные фиксы
0095/0101/0105 при этом не теряются — они были синхронно внесены в сид 0096.
questions откатывается не на голый 0096, а на 0107_..._questions_pre.csv (сид 0096 плюс
три сироты): сид conditions 0074 ссылается на sq_0080, которого в 0096 нет, и downgrade
на голом сиде падал бы на FK. Так восстанавливается ровно то состояние, что было до 0107.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "4c1a9e7b3d85"
down_revision: str | None = "9b3d7bd1495d"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = {
    "conditions": _CATALOG / "0107_4c1a9e7b3d85_conditions.csv",
    "options": _CATALOG / "0107_4c1a9e7b3d85_options.csv",
    "questions": _CATALOG / "0107_4c1a9e7b3d85_questions.csv",
    "parameters_score": _CATALOG / "0107_4c1a9e7b3d85_parameters_score.csv",
    "recommendations": _CATALOG / "0107_4c1a9e7b3d85_recommendations.csv",
    "risk_factors": _CATALOG / "0107_4c1a9e7b3d85_risk_factors.csv",
}
_OLD = {
    "conditions": _CATALOG / "0074_c4c707e39e40_conditions.csv",
    "options": _CATALOG / "0097_9086772873a5_options.csv",
    # НЕ сид 0096: он не содержит сирот sq_0080/sq_0820/sq_0830, а сид conditions 0074
    # ссылается на sq_0080 (FK ON DELETE RESTRICT) — downgrade на голом 0096 падал бы.
    # 0107_..._questions_pre.csv = сид 0096 (209 строк, с фиксами 0095/0101) + 3 сироты.
    "questions": _CATALOG / "0107_4c1a9e7b3d85_questions_pre.csv",
    "parameters_score": _CATALOG / "0096_a460718b3b84_parameters_score.csv",
    "recommendations": _CATALOG / "0102_5cf098fad5d6_recommendations.csv",
    "risk_factors": _CATALOG / "0106_9b3d7bd1495d_risk_factors.csv",
}

_INSERT_QUESTIONS = (
    "INSERT INTO questions (code, question, type, is_skippable, group_code) "
    "VALUES (:code, :question, :type, :is_skippable, :group_code)"
)
_INSERT_OPTIONS = (
    "INSERT INTO options (code, value, question_code, parameter_code) "
    "VALUES (:code, :value, :question_code, :parameter_code)"
)
_INSERT_CONDITIONS = (
    "INSERT INTO conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)
_INSERT_PARAM_SCORES = (
    "INSERT INTO parameter_scores (parameter_code, value, min_value, max_value, system_code, score) "
    "VALUES (:parameter_code, :value, :min_value, :max_value, :system_code, :score)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)
_INSERT_RECOMMENDATIONS = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)


def _numeric(s: str) -> str | None:
    # Только для numeric-колонок: в каталоге десятичный разделитель — запятая («0,5»).
    # К текстовым колонкам НЕ применять: replace(",", ".") калечит русский текст (см. докстринг).
    s = (s or "").replace(",", ".").rstrip("+").strip()
    return s or None


def _int_or_none(s: str) -> int | None:
    s = (s or "").strip()
    return int(s) if s else None


def _parse_questions(path: Path) -> list[dict]:
    # CSV из админки содержит лишнюю колонку category — в схеме её нет с 0092, игнорируем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "type": r["type"],
            "is_skippable": bool(int(r["is_skippable"])) if r["is_skippable"] else False,
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_options(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "value": r["value"] or None,
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": r["value"] or None,
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _parse_param_scores(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            # value — текст ответа, не число: пишем как есть (в 0096 здесь был _numeric → порча).
            "value": r["value"] or None,
            "min_value": _numeric(r["min_value"]),
            "max_value": _numeric(r["max_value"]),
            "system_code": r["system_code"],
            "score": _numeric(r["score"]),
        }
        for r in load_csv(path)
        if r["parameter_code"]
    ]


def _parse_risk_factors(path: Path, *, modifiability_col: str) -> list[dict]:
    # modifiability_col: в сидах 0106/0107 без опечатки, в более старых — «modofiability».
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r[modifiability_col],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r.get("reasoning") or None,
            "system_code": r.get("system_code") or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_recs(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": r["recommendations_group"],
            "risk_factors_code": r["risk_factors_code"] or None,
            "system_code": r["system_code"],
            "name": r["name"],
            "text": r.get("text") or None,
        }
        for r in load_csv(path)
    ]


def _replace(seeds: dict[str, Path], *, modifiability_col: str) -> None:
    conn = op.get_bind()

    # options/conditions ссылаются на questions (ON DELETE RESTRICT) — сносим детей первыми.
    conn.execute(sa.text("DELETE FROM options"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM conditions"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM questions"))  # migration-safety: ok full replace
    conn.execute(sa.text(_INSERT_QUESTIONS), _parse_questions(seeds["questions"]))
    conn.execute(sa.text(_INSERT_OPTIONS), _parse_options(seeds["options"]))
    conn.execute(sa.text(_INSERT_CONDITIONS), _parse_conditions(seeds["conditions"]))

    conn.execute(sa.text("DELETE FROM parameter_scores"))  # migration-safety: ok full replace
    conn.execute(sa.text(_INSERT_PARAM_SCORES), _parse_param_scores(seeds["parameters_score"]))

    conn.execute(sa.text("DELETE FROM risk_factors"))  # migration-safety: ok full replace
    conn.execute(
        sa.text(_INSERT_RISK_FACTORS),
        _parse_risk_factors(seeds["risk_factors"], modifiability_col=modifiability_col),
    )

    conn.execute(sa.text("DELETE FROM recommendations"))  # migration-safety: ok full replace
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _parse_recs(seeds["recommendations"]))


def upgrade() -> None:
    _replace(_NEW, modifiability_col="modifiability")


def downgrade() -> None:
    _replace(_OLD, modifiability_col="modifiability")
