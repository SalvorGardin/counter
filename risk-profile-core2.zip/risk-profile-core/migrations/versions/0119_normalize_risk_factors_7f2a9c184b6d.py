"""0119 normalize risk factors into factors, systems and triggers.

Revision ID: 7f2a9c184b6d
Revises: be5e117d3602
"""

# ruff: noqa: E501 -- SQL and migration-safety annotations are intentionally kept on one line.

import csv
from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

revision: str = "7f2a9c184b6d"
down_revision: str | None = "be5e117d3602"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_FACTORS = _CATALOG / "0119_7f2a9c184b6d_risk_factors.csv"
_SYSTEMS = _CATALOG / "0119_7f2a9c184b6d_risk_factor_systems.csv"
_TRIGGERS = _CATALOG / "0119_7f2a9c184b6d_risk_factor_triggers.csv"
_OLD = _CATALOG / "0116_163ab71d0203_risk_factors.csv"


def _rows(path: Path) -> list[dict[str, object]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter=";"))


def _nullable(row: dict[str, object], *names: str) -> dict[str, object]:
    for name in names:
        row[name] = row[name] or None
    return row


def upgrade() -> None:
    op.drop_table("risk_factors")
    op.create_table(
        "risk_factors",
        sa.Column("risk_factor_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("description", sa.String(), nullable=False),
        sa.Column("modifiability", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("risk_factor_id", name=op.f("pk_risk_factors")),
        sa.UniqueConstraint("code", name=op.f("uq_risk_factors_code")),
    )
    op.create_index(op.f("ix_risk_factors_code"), "risk_factors", ["code"], unique=False)
    op.create_table(
        "risk_factor_systems",
        sa.Column("risk_factor_system_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("risk_factor_code", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("reasoning", sa.String(), nullable=True),
        sa.ForeignKeyConstraint(["risk_factor_code"], ["risk_factors.code"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["system_code"], ["systems.code"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("risk_factor_system_id"),
        sa.UniqueConstraint("risk_factor_code", "system_code", name="uq_risk_factor_systems_factor_system"),
    )
    op.create_index(op.f("ix_risk_factor_systems_risk_factor_code"), "risk_factor_systems", ["risk_factor_code"])
    op.create_index(op.f("ix_risk_factor_systems_system_code"), "risk_factor_systems", ["system_code"])
    op.create_table(
        "risk_factor_triggers",
        sa.Column("trigger_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("trigger_code", sa.String(), nullable=False),
        sa.Column("risk_factor_code", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("value_type", sa.String(), nullable=False),
        sa.Column("operator", sa.String(), nullable=False),
        sa.Column("value_num", sa.Numeric(), nullable=True),
        sa.Column("min_value", sa.Numeric(), nullable=True),
        sa.Column("max_value", sa.Numeric(), nullable=True),
        sa.Column("value_text", sa.String(), nullable=True),
        sa.Column("gender", sa.String(), nullable=True),
        sa.CheckConstraint("value_type IN ('text', 'number')", name="ck_risk_factor_triggers_value_type"),
        sa.CheckConstraint(
            "operator IN ('eq', 'gt', 'gte', 'lt', 'lte', 'between')", name="ck_risk_factor_triggers_operator"
        ),
        sa.CheckConstraint("gender IS NULL OR gender IN ('Мужской', 'Женский')", name="ck_risk_factor_triggers_gender"),
        sa.CheckConstraint(
            "(value_type = 'text' AND operator = 'eq' AND value_text IS NOT NULL AND value_num IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator IN ('gt', 'gte', 'lt', 'lte') AND value_num IS NOT NULL AND value_text IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator = 'between' AND value_num IS NULL AND value_text IS NULL AND min_value IS NOT NULL AND max_value IS NOT NULL AND min_value <= max_value)",
            name="ck_risk_factor_triggers_value_shape",
        ),
        sa.ForeignKeyConstraint(["risk_factor_code"], ["risk_factors.code"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["system_code"], ["systems.code"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["parameter_code"], ["parameters.code"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("trigger_id", name=op.f("pk_risk_factor_triggers")),
        sa.UniqueConstraint("trigger_code", name=op.f("uq_risk_factor_triggers_trigger_code")),
        # Естественный ключ условия: одна и та же проверка не заводится дважды в паре «фактор +
        # система». Идентичность строки при перезаливке каталога держит trigger_code, поэтому оба
        # ключа нужны: один защищает ссылки на строку, второй — сами данные справочника.
        # nulls_not_distinct: незаполненные поля условия (все, кроме одного, у каждой формы) —
        # часть ключа, иначе Postgres считал бы такие строки различными и ограничение не работало
        # бы ни на одной реальной строке.
        sa.UniqueConstraint(
            "risk_factor_code",
            "system_code",
            "parameter_code",
            "operator",
            "value_num",
            "min_value",
            "max_value",
            "value_text",
            "gender",
            name="uq_risk_factor_triggers_condition",
            postgresql_nulls_not_distinct=True,
        ),
    )
    for column in ("risk_factor_code", "system_code", "parameter_code"):
        op.create_index(op.f(f"ix_risk_factor_triggers_{column}"), "risk_factor_triggers", [column])
    conn = op.get_bind()
    factors, systems, triggers = _rows(_FACTORS), _rows(_SYSTEMS), _rows(_TRIGGERS)
    # migration-safety: ok tables were created empty immediately above
    conn.execute(
        sa.text(
            "INSERT INTO risk_factors (code, description, modifiability) VALUES (:code, :description, :modifiability) "
            "ON CONFLICT (code) DO NOTHING"
        ),
        factors,
    )  # migration-safety: ok new empty table
    # migration-safety: ok table was created empty immediately above
    conn.execute(
        sa.text(
            "INSERT INTO risk_factor_systems (risk_factor_code, system_code, reasoning) VALUES (:risk_factor_code, :system_code, :reasoning) "
            "ON CONFLICT (risk_factor_code, system_code) DO NOTHING"
        ),
        systems,
    )  # migration-safety: ok new empty table
    triggers = [_nullable(row, "value_num", "min_value", "max_value", "value_text", "gender") for row in triggers]
    # migration-safety: ok table was created empty immediately above
    conn.execute(
        sa.text(
            "INSERT INTO risk_factor_triggers (trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator, value_num, min_value, max_value, value_text, gender) VALUES (:trigger_code, :risk_factor_code, :system_code, :parameter_code, :value_type, :operator, :value_num, :min_value, :max_value, :value_text, :gender) "
            "ON CONFLICT (trigger_code) DO NOTHING"
        ),
        triggers,
    )  # migration-safety: ok new empty table
    op.create_foreign_key(
        "fk_recommendations_risk_factors_code",
        "recommendations",
        "risk_factors",
        ["risk_factors_code"],
        ["code"],
        ondelete="RESTRICT",
    )


def downgrade() -> None:
    op.drop_constraint("fk_recommendations_risk_factors_code", "recommendations", type_="foreignkey")
    op.drop_table("risk_factor_triggers")
    op.drop_table("risk_factor_systems")
    op.drop_table("risk_factors")
    op.create_table(
        "risk_factors",
        sa.Column("risk_factor_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("description", sa.String(), nullable=False),
        sa.Column("modifiability", sa.String(), nullable=False),
        sa.Column("reasoning", sa.String(), nullable=True),
        sa.Column("param_value", sa.String(), nullable=True),
        sa.Column("min_param_value", sa.String(), nullable=True),
        sa.Column("max_param_value", sa.String(), nullable=True),
        sa.ForeignKeyConstraint(["parameter_code"], ["parameters.code"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["system_code"], ["systems.code"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("risk_factor_id"),
        sa.UniqueConstraint(
            "parameter_code",
            "code",
            "param_value",
            "min_param_value",
            "max_param_value",
            "system_code",
            name="uq_risk_factors_natural_key",
            postgresql_nulls_not_distinct=True,
        ),
    )
    op.create_index(op.f("ix_risk_factors_parameter_code"), "risk_factors", ["parameter_code"])
    op.create_index(op.f("ix_risk_factors_system_code"), "risk_factors", ["system_code"])
    old = [_nullable(row, "param_value", "min_param_value", "max_param_value", "reasoning") for row in _rows(_OLD)]
    # migration-safety: ok table was recreated empty immediately above
    op.get_bind().execute(
        sa.text(
            "INSERT INTO risk_factors (parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, reasoning, system_code) VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, :max_param_value, :reasoning, :system_code) "
            "ON CONFLICT DO NOTHING"
        ),
        old,
    )  # migration-safety: ok new empty table
