"""0149_gendered_questionnaire_texts

Revision ID: 34ab1a9e9ac6
Revises: 5d2a8e61c740
Create Date: 2026-09-25 12:00:00.000000

Родовые формы текстов опросников: пациенту показывается текст в роде по его полу («Я расстроен» /
«Я расстроена») вместо нейтральной формы со скобками («Я расстроен(а)»).

Схема. `catalog.questions` получает `question_male` / `question_female`, `catalog.options` —
`value_male` / `value_female`; все четыре колонки nullable. CHECK `gendered_pair` на каждой таблице:
пара либо пуста целиком, либо заполнена непустыми строками.

Базовые колонки не меняются намеренно. `options.value` пишется в `patients_parameters.value` при
выборе варианта и служит ключом балла BDI (балл берётся из суффикса кода, `value` — ключ поиска);
`questions.question` — текст по умолчанию. Родовые колонки только для отображения: в хранение
ответа, условия показа и расчёт не входят. Поэтому `patients_parameters` и
`patients_parameters_history` миграция не трогает, ремапа ответов нет, результаты расчёта `bdi` /
`stai` не меняются и бамп `calculation-version.json` не нужен.

Данные. `questions` и `options` перезаливаются из файлов `catalog/0149_34ab1a9e9ac6_*`: это файлы
0145 без изменений плюс родовые формы у 14 вопросов STAI и 39 вариантов ответа BDI, текст которых
содержит скобки. На `questions.code` ссылаются `conditions` и `options`, на `options.code` —
`biomarker_parameter_mappings`, все с `RESTRICT`, поэтому эти две таблицы перезаливаются тоже —
из файлов 0145 без изменений. Порядок строк файлов сохраняет порядок `question_id` / `option_id`,
по которому опросник отдаёт вопросы и варианты.

Откат снимает CHECK и колонки. Перезаливать справочник обратно не нужно: базовые колонки и состав
строк те же, что у 0145.
"""

from collections.abc import Sequence
from decimal import Decimal
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "34ab1a9e9ac6"
down_revision: str | None = "5d2a8e61c740"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

CATALOG_SCHEMA = "catalog"

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_SEEDS = {
    "questions": _CATALOG / "0149_34ab1a9e9ac6_questions.csv",
    "options": _CATALOG / "0149_34ab1a9e9ac6_options.csv",
    "conditions": _CATALOG / "0145_15c247ec61bb_conditions.csv",
    "biomarker_parameter_mappings": _CATALOG / "0145_15c247ec61bb_biomarker_parameter_mappings.csv",
}

# `IS NOT NULL` во второй ветке обязателен: без него половина пары даёт `'x' <> '' AND NULL <> ''`
# = NULL, а CHECK с результатом NULL строку пропускает.
_QUESTIONS_PAIR = (
    "(question_male IS NULL AND question_female IS NULL) OR "
    "(question_male IS NOT NULL AND question_female IS NOT NULL AND question_male <> '' AND question_female <> '')"
)
_OPTIONS_PAIR = (
    "(value_male IS NULL AND value_female IS NULL) OR "
    "(value_male IS NOT NULL AND value_female IS NOT NULL AND value_male <> '' AND value_female <> '')"
)

# Порядок — от зависимых к родительским: внешние ключи справочника стоят с RESTRICT.
_DELETE_CATALOGS = (
    "DELETE FROM catalog.biomarker_parameter_mappings",  # migration-safety: ok full replace
    "DELETE FROM catalog.options",  # migration-safety: ok full replace
    "DELETE FROM catalog.conditions",  # migration-safety: ok full replace
    "DELETE FROM catalog.questions",  # migration-safety: ok full replace
)

_INSERT_QUESTIONS = (
    "INSERT INTO catalog.questions (code, question, question_male, question_female, type, is_skippable, group_code) "
    "VALUES (:code, :question, :question_male, :question_female, :type, :is_skippable, :group_code)"
)
_INSERT_OPTIONS = (
    "INSERT INTO catalog.options (code, value, value_male, value_female, question_code, parameter_code) "
    "VALUES (:code, :value, :value_male, :value_female, :question_code, :parameter_code)"
)
_INSERT_CONDITIONS = (
    "INSERT INTO catalog.conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)
_INSERT_MAPPINGS = (
    "INSERT INTO catalog.biomarker_parameter_mappings "
    "(biomarker_parameter_code, parameter_code, mapping_type, operator, value_num, value_text, option_code, unit) "
    "VALUES (:biomarker_parameter_code, :parameter_code, :mapping_type, :operator, :value_num, :value_text, "
    ":option_code, :unit)"
)


def _none_if_blank(value: str) -> str | None:
    return value or None


def _decimal_or_none(value: str) -> Decimal | None:
    """asyncpg принимает в `Numeric` только `Decimal`; в старых сидах разделитель — запятая."""
    value = value.replace(",", ".").rstrip("+")
    return Decimal(value) if value else None


def _int_or_none(value: str) -> int | None:
    return int(value) if value else None


def _questions(path: Path) -> list[dict]:
    # Колонки `category` в схеме нет с 0092, файл выгрузки её содержит — не читаем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "question_male": _none_if_blank(r["question_male"]),
            "question_female": _none_if_blank(r["question_female"]),
            "type": r["type"],
            "is_skippable": r["is_skippable"] == "1",
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _options(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "value": _none_if_blank(r["value"]),
            "value_male": _none_if_blank(r["value_male"]),
            "value_female": _none_if_blank(r["value_female"]),
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": _none_if_blank(r["value"]),
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _mappings(path: Path) -> list[dict]:
    return [
        {
            "biomarker_parameter_code": r["biomarker_parameter_code"],
            "parameter_code": r["parameter_code"],
            "mapping_type": r["mapping_type"],
            "operator": _none_if_blank(r["operator"]),
            "value_num": _decimal_or_none(r["value_num"]),
            "value_text": _none_if_blank(r["value_text"]),
            "option_code": _none_if_blank(r["option_code"]),
            "unit": _none_if_blank(r["unit"]),
        }
        for r in load_csv(path)
        if r["biomarker_parameter_code"]
    ]


def _replace_catalogs(conn: sa.Connection) -> None:
    """Перезаливка четырёх таблиц: удаление от зависимых к родительским, вставка — обратно."""
    for statement in _DELETE_CATALOGS:
        conn.execute(sa.text(statement))

    # Порядок строк файла сохраняется: по нему раздаются `question_id` / `option_id`.
    conn.execute(sa.text(_INSERT_QUESTIONS), _questions(_SEEDS["questions"]))
    conn.execute(sa.text(_INSERT_CONDITIONS), _conditions(_SEEDS["conditions"]))
    conn.execute(sa.text(_INSERT_OPTIONS), _options(_SEEDS["options"]))
    conn.execute(sa.text(_INSERT_MAPPINGS), _mappings(_SEEDS["biomarker_parameter_mappings"]))


def upgrade() -> None:
    for column in ("question_male", "question_female"):
        op.add_column("questions", sa.Column(column, sa.String(), nullable=True), schema=CATALOG_SCHEMA)
    for column in ("value_male", "value_female"):
        op.add_column("options", sa.Column(column, sa.String(), nullable=True), schema=CATALOG_SCHEMA)
    op.create_check_constraint(op.f("ck_questions_gendered_pair"), "questions", _QUESTIONS_PAIR, schema=CATALOG_SCHEMA)
    op.create_check_constraint(op.f("ck_options_gendered_pair"), "options", _OPTIONS_PAIR, schema=CATALOG_SCHEMA)

    _replace_catalogs(op.get_bind())


def downgrade() -> None:
    op.drop_constraint(op.f("ck_options_gendered_pair"), "options", type_="check", schema=CATALOG_SCHEMA)
    op.drop_constraint(op.f("ck_questions_gendered_pair"), "questions", type_="check", schema=CATALOG_SCHEMA)
    for column in ("value_female", "value_male"):
        op.drop_column("options", column, schema=CATALOG_SCHEMA)
    for column in ("question_female", "question_male"):
        op.drop_column("questions", column, schema=CATALOG_SCHEMA)
