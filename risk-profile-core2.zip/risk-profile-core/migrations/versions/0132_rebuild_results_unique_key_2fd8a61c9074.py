"""0132_rebuild_results_unique_key

Revision ID: 2fd8a61c9074
Revises: 7be0d4915caf
Create Date: 2026-08-28 11:30:00.000000

Естественный ключ `results` расширяется группой заболеваний: у расчёта по клиническим
рекомендациям строки одного инструмента различаются только ей.

Режим NULLS NOT DISTINCT обязателен: у калькуляторов и опросников `disease_code` пуст, и без
этого режима ключ не срабатывал бы на таких строках вообще — upsert начал бы плодить дубли на
каждый пересчёт. С ним поведение для существующих строк не меняется, поэтому ни бэкфилла, ни
дедупликации не требуется.

Ключ заводится под новым именем: на него по имени ссылается `ON CONFLICT ON CONSTRAINT` в
`src/calc/infra/repository.py`. Смена имени делает рассинхрон кода и схемы громким — старый код
с новой схемой падает сразу, а не пишет дубли молча.

`ADD CONSTRAINT ... UNIQUE` строит индекс под ACCESS EXCLUSIVE, то есть на время выполнения
`results` недоступна и на чтение. Неблокирующая форма (`CREATE UNIQUE INDEX CONCURRENTLY` +
`ADD CONSTRAINT ... USING INDEX`) не используется: миграция накатывается в окне технических
работ, а `CONCURRENTLY` нельзя выполнить внутри транзакции миграции и его падение оставляет
невалидный индекс, который приходится убирать руками.
"""

from collections.abc import Sequence

from alembic import op

revision: str = "2fd8a61c9074"
down_revision: str | None = "7be0d4915caf"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_OLD_CONSTRAINT = "uq_results_patient_id_instrument_code_indicator"
_NEW_CONSTRAINT = "uq_results_patient_id_instrument_code_indicator_disease_code"


def upgrade() -> None:
    op.drop_constraint(_OLD_CONSTRAINT, "results", type_="unique")
    # ADD CONSTRAINT ... UNIQUE NULLS NOT DISTINCT: op.create_unique_constraint режим не
    # передаёт, а без него ограничение молча получилось бы другим.
    op.execute(
        f"ALTER TABLE results ADD CONSTRAINT {_NEW_CONSTRAINT} "
        "UNIQUE NULLS NOT DISTINCT (patient_id, instrument_code, indicator, disease_code)"
    )


def downgrade() -> None:
    op.drop_constraint(_NEW_CONSTRAINT, "results", type_="unique")
    op.create_unique_constraint(_OLD_CONSTRAINT, "results", ["patient_id", "instrument_code", "indicator"])
