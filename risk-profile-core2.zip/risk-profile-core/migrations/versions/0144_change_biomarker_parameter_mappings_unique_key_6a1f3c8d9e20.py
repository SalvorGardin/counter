"""0144_change_biomarker_parameter_mappings_unique_key

Revision ID: 6a1f3c8d9e20
Revises: c4b1f7ae90d2
Create Date: 2026-09-10 00:00:00.000000

Пара (`biomarker_parameter_code`, `parameter_code`) допускала одну строку разметки, то есть ровно
одно условие отклонения от нормы на «биомаркер заполняет параметр опросника». Условий у пары
бывает несколько: разные границы количественного биомаркера и разные эталоны качественного пишут
разные варианты ответа. Естественный ключ расширяется до вида разметки, оператора и записываемого
варианта, а имя ограничения перестаёт называть только пару колонок.

`nulls_not_distinct`: у строк `mapping_type = 'value'` оператор и вариант ответа пусты. В режиме
Postgres по умолчанию такие строки не конфликтовали бы между собой, и прямой перенос значения
заводился бы на пару сколько угодно раз — ослабление сверх нужного. С этим режимом пустые поля
входят в ключ наравне с остальными.

Новая уникальность слабее прежней: существующие строки уникальны по паре «источник → цель», а
значит уникальны и по расширенному набору. Накат не требует ни чистки, ни переноса данных и не
может упасть на существующих строках.

Перед DDL выставляется `lock_timeout` и снимается сразу после: `ALTER TABLE` запрашивает ACCESS
EXCLUSIVE, и без таймаута, встав за долгой транзакцией читателя справочника, он висел бы
неограниченно, копя за собой очередь. Alembic гоняет прогон одной транзакцией (`migrations/env.py`),
поэтому `SET LOCAL` без возврата к `DEFAULT` действовал бы и на следующих миграциях.

`downgrade` возвращает прежний ключ и предварительно проверяет, что второй строки на пару
«источник → цель» не появилось: молча удалять строки справочника нельзя, а без проверки откат
падал бы на создании ограничения с невнятной ошибкой уникальности.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "6a1f3c8d9e20"
down_revision: str | None = "c4b1f7ae90d2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = "biomarker_parameter_mappings"
_OLD_CONSTRAINT = "uq_biomarker_parameter_mappings_source_target"
_OLD_KEY = ["biomarker_parameter_code", "parameter_code"]
_NEW_CONSTRAINT = "uq_biomarker_parameter_mappings_source_target_condition"
_NEW_KEY = ["biomarker_parameter_code", "parameter_code", "mapping_type", "operator", "option_code"]

_DUPLICATE_PAIRS = sa.text(
    "SELECT count(*) FROM ("
    "  SELECT 1 FROM biomarker_parameter_mappings"
    "  GROUP BY biomarker_parameter_code, parameter_code HAVING count(*) > 1"
    ") AS pairs"
)


def upgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text("SET LOCAL lock_timeout = '2s'"))
    op.drop_constraint(_OLD_CONSTRAINT, _TABLE, type_="unique")
    op.create_unique_constraint(_NEW_CONSTRAINT, _TABLE, _NEW_KEY, postgresql_nulls_not_distinct=True)
    conn.execute(sa.text("SET LOCAL lock_timeout = DEFAULT"))


def downgrade() -> None:
    conn = op.get_bind()
    duplicated = conn.execute(_DUPLICATE_PAIRS).scalar_one()
    if duplicated:
        raise RuntimeError(
            f"{_TABLE}: {duplicated} source/target pair(s) carry more than one mapping row; "
            "resolve them before narrowing the unique key back to the pair"
        )
    # Таймаут ставится после проверки: под ним должен быть только DDL, иначе откат падал бы на
    # ожидании в SELECT выше, не дойдя до операции, ради которой таймаут и нужен.
    conn.execute(sa.text("SET LOCAL lock_timeout = '2s'"))
    op.drop_constraint(_NEW_CONSTRAINT, _TABLE, type_="unique")
    op.create_unique_constraint(_OLD_CONSTRAINT, _TABLE, _OLD_KEY)
    conn.execute(sa.text("SET LOCAL lock_timeout = DEFAULT"))
