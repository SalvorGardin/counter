"""0150_reseed_catalogs_chronic_disease_control

Revision ID: 221190c24974
Revises: 34ab1a9e9ac6
Create Date: 2026-09-28 00:00:00.000000

Перезаливка справочников из выгрузки админки: блок уточняющих вопросов о контроле хронических
заболеваний и наблюдении у врача (risk-profile-core#300). Файлы лежат в
`catalog/0150_221190c24974_<таблица>.csv`, каждая таблица приводится к своему файлу целиком.

Дельта против состояния до наката (справка для ревью, источником записи не служит):

  * questions        202 → 221: +20 вопросов `sq_1480`–`sq_1621`; правка текста `sq_0220`;
                     снят `sq_1200` (профессиональный спорт).
  * options          624 → 682: +60 вариантов новых вопросов, −2 варианта `sq_1200`; тексты
                     существующих не менялись.
  * parameters       321 → 335 в файле: +15 параметров новых вопросов (`asthma_exacerbation`,
                     `htn_target`, `clim_*`, `br_*`, `mole_dermatologist` и др.); `professional_sport`
                     в файле нет — в базе переводится в `inactive`. Описания существующих не менялись.
  * conditions        72 → 108: +36 условий показа новых вопросов.
  * parameter_scores 340 → 372: +36 баллов новых параметров и `arterial_hypertension` × ENDO.
                     Изменены баллы существующих параметров: `arterial_hypertension` × CVD 10 → 8,
                     `atherosclerosis` 10 → 8, `family_acute_cvd` и `family_hypercholesterolemia`
                     5 → 4, `antihypertensive_meds` × CVD и `lipid_lowering_meds` 5 → 0.1,
                     `respy_meds` × RESP 5 → −1, `new_moles_after_30` × ONCO 1 → 2. Сняты
                     `family_diabetes_close` × URO, `antihypertensive_meds` × ENDO и
                     `professional_sport` × CVD и × TRAUMA.
  * risk_factors     197 → 217: +20 факторов; `fr_professionalsport` остаётся без систем и условий.
                     У пяти факторов приёма препаратов (`fr_anticoagulant_meds`, `fr_lipid_lowering_meds`,
                     `fr_antihypertensive_meds`, `fr_respy_meds`, `fr_antiarrhythmics_meds`) описание
                     заменено на «Приём препаратов …»; `fr_respy_meds` и `fr_antiarrhythmics_meds` стали
                     `modifiable`.
  * risk_factor_systems 265 → 287: +26 пар; ризонинг тех же пяти факторов заменён (6 пар); сняты
                     `fr_antihypertensive_meds` × ENDO и × SENSE, `fr_professionalsport` × CVD и × TRAUMA.
  * risk_factor_triggers 350 → 384: +38 условий; сняты `fr_antihypertensive_meds` × ENDO и × SENSE,
                     `fr_professionalsport` × CVD и × TRAUMA.
  * recommendations  156 → 174: +21 — рекомендации новых факторов и вторые рекомендации факторов
                     приёма препаратов, тексты существующих не менялись; сняты
                     `fr_antihypertensive_meds` × ENDO и обе рекомендации `fr_professionalsport`.
  * instruments_parameters 501 → 520: +21 привязка новых параметров, все необязательные; снят
                     `professional_sport` из `form_cvd` и `form_trauma`.

Неизменённые таблицы. `risk_factor_scores` и `risk_factor_clinrecs` ссылаются на `risk_factors`,
`biomarker_parameter_mappings` — на `options`, все с RESTRICT, и мешают удалить родителя. Они
перезаливаются тем же приёмом из файлов 0145 без изменений.

Приёмы записи:

  * parameters — `INSERT ... ON CONFLICT (code) DO UPDATE`, коды вне файла переводятся
    в `status='inactive'`: на `parameters.code` ссылаются `patients_parameters` и её история с RESTRICT.
  * Остальные двенадцать таблиц — `DELETE` + `INSERT`, как в 0145: `DELETE` от зависимых таблиц
    к родительским, `INSERT` — в обратном порядке. Строки вставляются в порядке файла: по нему
    раздаются `question_id`, `option_id` и `trigger_id` — порядок выдачи опросника и тай-брейк
    сработавших условий.
  * `questions` и `options` пишутся с родовыми формами. Выгрузка админки родовых колонок не знает и
    заменяет неразрывные пробелы обычными, поэтому файлы сведены с сидом 0149: родовые формы
    существующих кодов и неразрывные пробелы (варианты шкалы Бека — ключ `bdi_score_map`) перенесены
    оттуда, у новых кодов родовых форм нет.

Ответы пациентов. Ни один существующий вариант ответа не сменил текст, поэтому ремапа
`patients_parameters.value` нет. Снятый вопрос `sq_1200` удаляется вместе с вариантами, ответы
пациентов на него (`professional_sport`) остаются в базе: параметр неактивен, баллов и условий
факторов по нему нет, в расчёт ответ больше не попадает. При откате параметр снова активен и ответы
читаются как прежде.

Изменение баллов и факторов меняет результаты расчёта, поэтому в том же изменении бампается
`calculation-version.json`.

downgrade перезаливает те же таблицы тем же приёмом из предыдущих сидов: `questions` и `options` —
из 0149, остальное — из 0145. 15 параметров, заведённых накатом, переводятся в `inactive`,
`professional_sport` — обратно в `active`; ответы пациентов на новые вопросы остаются в базе и
перестают читаться.
"""

from collections.abc import Sequence
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "221190c24974"
down_revision: str | None = "34ab1a9e9ac6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_PREFIX = "0150_221190c24974_"
_PREV_PREFIX = "0145_15c247ec61bb_"

_NEW = {
    "parameters": _CATALOG / f"{_PREFIX}parameters.csv",
    "questions": _CATALOG / f"{_PREFIX}questions.csv",
    "options": _CATALOG / f"{_PREFIX}options.csv",
    "conditions": _CATALOG / f"{_PREFIX}conditions.csv",
    "parameter_scores": _CATALOG / f"{_PREFIX}parameters_score.csv",
    "risk_factors": _CATALOG / f"{_PREFIX}risk_factors.csv",
    "risk_factor_systems": _CATALOG / f"{_PREFIX}risk_factor_systems.csv",
    "risk_factor_triggers": _CATALOG / f"{_PREFIX}risk_factor_triggers.csv",
    "risk_factor_scores": _CATALOG / f"{_PREV_PREFIX}risk_factor_scores.csv",
    "risk_factor_clinrecs": _CATALOG / f"{_PREV_PREFIX}risk_factor_clinrecs.csv",
    "recommendations": _CATALOG / f"{_PREFIX}recommendations.csv",
    "instruments_parameters": _CATALOG / f"{_PREFIX}instrument_parameters.csv",
    "biomarker_parameter_mappings": _CATALOG / f"{_PREV_PREFIX}biomarker_parameter_mappings.csv",
}
_OLD = {
    "parameters": _CATALOG / f"{_PREV_PREFIX}parameters.csv",
    "questions": _CATALOG / "0149_34ab1a9e9ac6_questions.csv",
    "options": _CATALOG / "0149_34ab1a9e9ac6_options.csv",
    "conditions": _CATALOG / f"{_PREV_PREFIX}conditions.csv",
    "parameter_scores": _CATALOG / f"{_PREV_PREFIX}parameters_score.csv",
    "risk_factors": _CATALOG / f"{_PREV_PREFIX}risk_factors.csv",
    "risk_factor_systems": _CATALOG / f"{_PREV_PREFIX}risk_factor_systems.csv",
    "risk_factor_triggers": _CATALOG / f"{_PREV_PREFIX}risk_factor_triggers.csv",
    "risk_factor_scores": _CATALOG / f"{_PREV_PREFIX}risk_factor_scores.csv",
    "risk_factor_clinrecs": _CATALOG / f"{_PREV_PREFIX}risk_factor_clinrecs.csv",
    "recommendations": _CATALOG / f"{_PREV_PREFIX}recommendations.csv",
    "instruments_parameters": _CATALOG / f"{_PREV_PREFIX}instrument_parameters.csv",
    "biomarker_parameter_mappings": _CATALOG / f"{_PREV_PREFIX}biomarker_parameter_mappings.csv",
}

_UPSERT_PARAMETERS = (
    "INSERT INTO catalog.parameters (code, description, status, validity_period) "
    "VALUES (:code, :description, :status, :validity_period) "
    "ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description, status = EXCLUDED.status, "
    "validity_period = EXCLUDED.validity_period"
)
_DEACTIVATE_PARAMETERS = "UPDATE catalog.parameters SET status = 'inactive' WHERE NOT (code = ANY(:codes))"

# Таблицы перечислены готовыми запросами, а не именами в цикле: имя таблицы, подставленное в строку
# запроса, читается статическим анализом как конструирование SQL. Порядок — от зависимых
# к родительским.
_DELETE_CATALOGS = (
    "DELETE FROM catalog.biomarker_parameter_mappings",  # migration-safety: ok full replace
    "DELETE FROM catalog.instruments_parameters",  # migration-safety: ok full replace
    "DELETE FROM catalog.recommendations",  # migration-safety: ok full replace
    "DELETE FROM catalog.risk_factor_clinrecs",  # migration-safety: ok full replace
    "DELETE FROM catalog.risk_factor_scores",  # migration-safety: ok full replace
    "DELETE FROM catalog.risk_factor_triggers",  # migration-safety: ok full replace
    "DELETE FROM catalog.risk_factor_systems",  # migration-safety: ok full replace
    "DELETE FROM catalog.risk_factors",  # migration-safety: ok full replace
    "DELETE FROM catalog.parameter_scores",  # migration-safety: ok full replace
    "DELETE FROM catalog.conditions",  # migration-safety: ok full replace
    "DELETE FROM catalog.options",  # migration-safety: ok full replace
    "DELETE FROM catalog.questions",  # migration-safety: ok full replace
)

_INSERT_QUESTIONS = (
    "INSERT INTO catalog.questions (code, question, question_male, question_female, type, is_skippable, group_code) "
    "VALUES (:code, :question, :question_male, :question_female, :type, :is_skippable, :group_code)"
)
_INSERT_OPTIONS = (
    "INSERT INTO catalog.options (code, value, value_male, value_female, question_code, parameter_code) "
    "VALUES (:code, :value, :value_male, :value_female, :question_code, :parameter_code)"
)
_INSERT_CONDITIONS = (
    "INSERT INTO catalog.conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)
_INSERT_PARAMETER_SCORES = (
    "INSERT INTO catalog.parameter_scores (parameter_code, value, min_value, max_value, system_code, score) "
    "VALUES (:parameter_code, :value, :min_value, :max_value, :system_code, :score)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO catalog.risk_factors (code, description, modifiability) VALUES (:code, :description, :modifiability)"
)
_INSERT_FACTOR_SYSTEMS = (
    "INSERT INTO catalog.risk_factor_systems (risk_factor_code, system_code, reasoning) "
    "VALUES (:risk_factor_code, :system_code, :reasoning)"
)
_INSERT_TRIGGERS = (
    "INSERT INTO catalog.risk_factor_triggers "
    "(trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator, "
    "value_num, min_value, max_value, value_text, gender) "
    "VALUES (:trigger_code, :risk_factor_code, :system_code, :parameter_code, :value_type, :operator, "
    ":value_num, :min_value, :max_value, :value_text, :gender)"
)
_INSERT_SCORES = (
    "INSERT INTO catalog.risk_factor_scores (risk_factor_code, disease_code, score, influence) "
    "VALUES (:risk_factor_code, :disease_code, :score, :influence)"
)
_INSERT_FACTOR_CLINRECS = (
    "INSERT INTO catalog.risk_factor_clinrecs (risk_factor_code, disease_code, clinrec_code) "
    "VALUES (:risk_factor_code, :disease_code, :clinrec_code)"
)
_INSERT_RECOMMENDATIONS = (
    "INSERT INTO catalog.recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)
_INSERT_INSTRUMENT_PARAMS = (
    "INSERT INTO catalog.instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)
_INSERT_MAPPINGS = (
    "INSERT INTO catalog.biomarker_parameter_mappings "
    "(biomarker_parameter_code, parameter_code, mapping_type, operator, value_num, value_text, option_code, unit) "
    "VALUES (:biomarker_parameter_code, :parameter_code, :mapping_type, :operator, :value_num, :value_text, "
    ":option_code, :unit)"
)


def _none_if_blank(value: str) -> str | None:
    return value or None


def _decimal_or_none(value: str) -> Decimal | None:
    """asyncpg принимает в `Numeric` только `Decimal`; в выгрузке разделитель — запятая («0,1»)."""
    value = value.replace(",", ".").rstrip("+")
    return Decimal(value) if value else None


def _int_or_none(value: str) -> int | None:
    return int(value) if value else None


def _parameters(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "status": r["status"],
            # TIMESTAMP asyncpg принимает только datetime.
            "validity_period": datetime.fromisoformat(r["validity_period"]),
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _questions(path: Path) -> list[dict]:
    # Колонки `category` в схеме нет с 0092; в файле 0149 она есть — не читаем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "question_male": _none_if_blank(r["question_male"]),
            "question_female": _none_if_blank(r["question_female"]),
            "type": r["type"],
            "is_skippable": r["is_skippable"] == "1",
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _options(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "value": _none_if_blank(r["value"]),
            "value_male": _none_if_blank(r["value_male"]),
            "value_female": _none_if_blank(r["value_female"]),
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": _none_if_blank(r["value"]),
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _parameter_scores(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            # Текст ответа, не число: запятая в нём — часть текста.
            "value": _none_if_blank(r["value"]),
            "min_value": _decimal_or_none(r["min_value"]),
            "max_value": _decimal_or_none(r["max_value"]),
            "system_code": r["system_code"],
            "score": _decimal_or_none(r["score"]),
        }
        for r in load_csv(path)
        if r["parameter_code"]
    ]


def _risk_factors(path: Path) -> list[dict]:
    return [
        {"code": r["code"], "description": r["description"], "modifiability": r["modifiability"]}
        for r in load_csv(path)
        if r["code"]
    ]


def _factor_systems(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "reasoning": _none_if_blank(r["reasoning"]),
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _triggers(path: Path) -> list[dict]:
    return [
        {
            "trigger_code": r["trigger_code"],
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "parameter_code": r["parameter_code"],
            "value_type": r["value_type"],
            "operator": r["operator"],
            "value_num": _decimal_or_none(r["value_num"]),
            "min_value": _decimal_or_none(r["min_value"]),
            "max_value": _decimal_or_none(r["max_value"]),
            "value_text": _none_if_blank(r["value_text"]),
            "gender": _none_if_blank(r["gender"]),
        }
        for r in load_csv(path)
        if r["trigger_code"]
    ]


def _scores(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "score": int(r["score"]),
            "influence": r["influence"],
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _factor_clinrecs(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "clinrec_code": r["clinrec_code"],
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _recommendations(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": _none_if_blank(r["recommendations_group"]),
            "risk_factors_code": _none_if_blank(r["risk_factors_code"]),
            "system_code": r["system_code"],
            "name": r["name"],
            "text": _none_if_blank(r["text"]),
        }
        for r in load_csv(path)
        if r["system_code"]
    ]


def _instrument_parameters(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
        if r["instrument_code"]
    ]


def _mappings(path: Path) -> list[dict]:
    return [
        {
            "biomarker_parameter_code": r["biomarker_parameter_code"],
            "parameter_code": r["parameter_code"],
            "mapping_type": r["mapping_type"],
            "operator": _none_if_blank(r["operator"]),
            "value_num": _decimal_or_none(r["value_num"]),
            "value_text": _none_if_blank(r["value_text"]),
            "option_code": _none_if_blank(r["option_code"]),
            "unit": _none_if_blank(r["unit"]),
        }
        for r in load_csv(path)
        if r["biomarker_parameter_code"]
    ]


def _upsert_parameters(conn: sa.Connection, seeds: dict[str, Path]) -> None:
    """Запись каждой строки файла, коды вне файла — в `inactive`.

    Строки не удаляются: на `parameters.code` ссылаются данные пациентов с RESTRICT.
    """
    parameters = _parameters(seeds["parameters"])
    conn.execute(sa.text(_UPSERT_PARAMETERS), parameters)
    conn.execute(sa.text(_DEACTIVATE_PARAMETERS), {"codes": [r["code"] for r in parameters]})


def _replace_catalogs(conn: sa.Connection, seeds: dict[str, Path]) -> None:
    """Перезаливка двенадцати таблиц: удаление от зависимых к родительским, вставка — обратно."""
    for statement in _DELETE_CATALOGS:
        conn.execute(sa.text(statement))

    # Порядок строк файла сохраняется: по нему раздаются `question_id`, `option_id` и `trigger_id`.
    conn.execute(sa.text(_INSERT_QUESTIONS), _questions(seeds["questions"]))
    conn.execute(sa.text(_INSERT_OPTIONS), _options(seeds["options"]))
    conn.execute(sa.text(_INSERT_CONDITIONS), _conditions(seeds["conditions"]))
    conn.execute(sa.text(_INSERT_PARAMETER_SCORES), _parameter_scores(seeds["parameter_scores"]))
    conn.execute(sa.text(_INSERT_RISK_FACTORS), _risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_FACTOR_SYSTEMS), _factor_systems(seeds["risk_factor_systems"]))
    conn.execute(sa.text(_INSERT_TRIGGERS), _triggers(seeds["risk_factor_triggers"]))
    conn.execute(sa.text(_INSERT_SCORES), _scores(seeds["risk_factor_scores"]))
    conn.execute(sa.text(_INSERT_FACTOR_CLINRECS), _factor_clinrecs(seeds["risk_factor_clinrecs"]))
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _recommendations(seeds["recommendations"]))
    conn.execute(sa.text(_INSERT_INSTRUMENT_PARAMS), _instrument_parameters(seeds["instruments_parameters"]))
    conn.execute(sa.text(_INSERT_MAPPINGS), _mappings(seeds["biomarker_parameter_mappings"]))


def upgrade() -> None:
    conn = op.get_bind()
    _upsert_parameters(conn, _NEW)
    _replace_catalogs(conn, _NEW)


def downgrade() -> None:
    conn = op.get_bind()
    _upsert_parameters(conn, _OLD)
    _replace_catalogs(conn, _OLD)
