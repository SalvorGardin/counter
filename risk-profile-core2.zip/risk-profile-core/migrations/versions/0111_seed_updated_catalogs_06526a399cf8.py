"""0111_seed_updated_catalogs

Revision ID: 06526a399cf8
Revises: 0f44c26b435f
Create Date: 2026-07-27 17:15:11.752812

Проливка пяти справочников из админки risk-profile-admin (снимок на 27.07):
risk_factors, options, questions, parameters_score, instruments_parameters.
Экспорты — catalog/0111_06526a399cf8_<entity>.csv.

Не трогаем остальные таблицы: recommendations / parameters / systems / doctors /
instruments либо совпадают со стендом, либо остаются за скопом админки (впереди core,
см. «Чего миграция НЕ делает» в 0107). conditions контентно не изменился, но
участвует в перезаливке циклом (см. ниже про FK).

Дельта к состоянию стенда (0107 для контентных таблиц, 0104 для instruments_parameters):

  • risk_factors    −117 строк. Основной массив — спорт: extreme_sport_* / professional_sport
                    (по одной строке на систему, 70+ строк), плюс food, physical_activity_level,
                    waist_circumference, age и др. По системам: URO 25, CVD 14, ENDO 13, BLOOD 10,
                    RESP 10, ONCO 9, SENSE 9, NEURO 9, REPROD 8, TRAUMA 8, GI 2.
                    +38 строк по 19 параметрам, которых в risk_factors не было вовсе: гематология
                    (Low_Platelets, Petechiae_Ecchymosis, Prolonged_Bleeding, Splenomegaly,
                    Myelosuppressive_Drugs, Family_Bleeding_Disorder, Mouth_Ulcers_Infections, LUQ_Pain,
                    Abdominal_Trauma), ЛОР/зрение (chronic_nasal_symptoms, chronic_hoarseness,
                    ent_visit_last_year, eye_visit_12m, double_vision), неврология (convulsion, dizziness,
                    face_numbness, neck_pain, speech).
                    13 правок reasoning. description и modifiability не менялись ни у одной общей строки.
                    В том числе снова переписан текст липидов (fr_hdl / fr_ldl / fr_total_cholesterol ×
                    CVD, плюс fr_lipid_lowering_meds): это НЕ откат фикса 0108 — там чинился «почечный»
                    copy-paste, здесь аналитик заменил уже корректный текст новой формулировкой про
                    отклонения в липидном профиле.
  • questions       −2 строки: sq_1360 (внезапная температура) и sq_1400 (раннее насыщение).
                    1 правка текста: sq_0010 «новообразования?» → «новообразование?».
                    is_skippable/group_code остальных строк не менялись.
  • options         −6 строк: 4 option-строки для удалённых sq_1360/sq_1400 (Да/Нет × 2 вопроса)
                    плюс 2 осиротевших sq_0010_13 / sq_0020_03. Тексты остальных option-строк
                    не менялись.
  • parameters_score +10 / −2. Добавлены: fever_unexplained (6 ответов × BLOOD/ONCO,
                    +6 строк — аналитик завёл параметр взамен удалённого sq_1360),
                    solarium_use × SKIN (Ранее / Регулярно, +2 строки), age × RESP (max 120),
                    unexplained_weight_fluct × ENDO («Да, потеря веса на 5% и более за месяц»).
                    Удалены: age × ONCO (перенесён в RESP), early_menopause × ENDO «Да»
                    (параметр ушёл, строчка стала не нужна). min/max/score прежних строк
                    не менялись; Low_Platelets × BLOOD остаётся 'Да' (фикс 0105/#121).
  • instruments_parameters −4 / +3. Добавлены: airi_ssz × {age, gender, bmi, diabetes,
                    family_acute_cvd, family_hypercholesterolemia, atherosclerosis, hdl, ldl,
                    lipid_lowering_meds, lipoprotein_a, systolic_bp} (is_required=true),
                    form_uro/food, form_skin/solarium_use. Удалены: form_blood/lymphadenopathy_unexplained,
                    form_cvd/family_alzheimer, form_cvd/family_parkinson,
                    form_resp/arterial_hypertension.

Схема НЕ меняется. Приём — полная перезаливка каждой таблицы (DELETE + INSERT), как в 0107,
а не UPSERT: естественные ключи (uq_risk_factors_natural_key, uq_options_code,
uq_instruments_parameters_instrument_parameter и др.) покрывают почти все колонки —
«обновлять» на месте можно лишь текстовые поля, а удаления одним ON CONFLICT не выразить.
Уникальность новых наборов по естественным ключам проверена заранее (дублей нет).

Порядок DELETE/INSERT продиктован FK options.question_code → questions.code
(ON DELETE RESTRICT) и conditions.question_code → questions.code (тоже RESTRICT):
сначала сносим options и conditions, потом questions; вставляем в обратном порядке.
conditions контентно не менялся (сид 0107), но участвует в цикле — иначе DELETE FROM
questions падает на FK от conditions. risk_factors / parameter_scores /
instruments_parameters ссылаются на parameters / systems / instruments
(ON DELETE RESTRICT со стороны справочников) — их мы не трогаем, все parameter_code
и system_code нового набора в сидах 0096/0103 присутствуют.

Безопасность перезаливки risk_factors. FK на risk_factors нет ни одного: составной FK
recommendations → risk_factors снят в 0096 вместе с расширением ключа, связь живёт на
уровне приложения. Родители — parameters.code и systems.code, их не трогаем.

Осознанный побочный эффект: 16 пар (risk_factors_code, system_code) в recommendations
перестают на что-либо ссылаться — рекомендации risk_factor_group по ним больше не будут
подбираться. Это следствие удаления строк в админке: fr_professionalsport × BLOOD/ENDO/GI/
NEURO/RESP/SENSE, fr_systolic_bp и fr_diastolic_bp × SENSE/URO, fr_hdl / fr_ldl /
fr_total_cholesterol / fr_lipid_lowering_meds / fr_diabetes × URO, fr_physical_activity_stage
× CVD. БД это не ломает (FK нет), чистка recommendations — отдельная задача аналитика.

downgrade возвращает предыдущие сиды: risk_factors → 0107, options → 0107,
questions → 0107, parameters_score → 0107, instruments_parameters → 0104.
conditions остаётся на сиде 0107 (контент не менялся). Точечные фиксы 0108
(lipid reasoning) и 0105 (Low_Platelets) при этом не теряются — они были синхронно
внесены в сиды 0107. questions откатывается на голый 0107_..._questions.csv
(а не на _pre.csv, как в самом 0107): состояния до 0111 == пост-0107, conditions 0107
не ссылается на sq_0080, поэтому FK не падает.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "06526a399cf8"
down_revision: str | None = "0f44c26b435f"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = {
    "questions": _CATALOG / "0111_06526a399cf8_questions.csv",
    "options": _CATALOG / "0111_06526a399cf8_options.csv",
    # conditions контентно не менялся: 0111 каталога для него нет, ездит сид 0107.
    # Нужен в цикле только чтобы FK conditions.question_code → questions.code
    # (ON DELETE RESTRICT) не падал на DELETE FROM questions.
    "conditions": _CATALOG / "0107_4c1a9e7b3d85_conditions.csv",
    "parameters_score": _CATALOG / "0111_06526a399cf8_parameters_score.csv",
    "risk_factors": _CATALOG / "0111_06526a399cf8_risk_factors.csv",
    "instruments_parameters": _CATALOG / "0111_06526a399cf8_instrument_parameters.csv",
}
_OLD = {
    "questions": _CATALOG / "0107_4c1a9e7b3d85_questions.csv",
    "options": _CATALOG / "0107_4c1a9e7b3d85_options.csv",
    "conditions": _CATALOG / "0107_4c1a9e7b3d85_conditions.csv",
    "parameters_score": _CATALOG / "0107_4c1a9e7b3d85_parameters_score.csv",
    "risk_factors": _CATALOG / "0107_4c1a9e7b3d85_risk_factors.csv",
    # instruments_parameters в админку не выгружался (см. 0107/0108): на 0104 core-правка
    # 7 анамнез-параметров (form_cvd/form_endo/form_onco/form_resp required → optional),
    # поэтому откат идёт на 0104, а не на более старый 0096.
    "instruments_parameters": _CATALOG / "0104_e0b27d2ebc69_instrument_parameters.csv",
}

_INSERT_QUESTIONS = (
    "INSERT INTO questions (code, question, type, is_skippable, group_code) "
    "VALUES (:code, :question, :type, :is_skippable, :group_code)"
)
_INSERT_OPTIONS = (
    "INSERT INTO options (code, value, question_code, parameter_code) "
    "VALUES (:code, :value, :question_code, :parameter_code)"
)
_INSERT_CONDITIONS = (
    "INSERT INTO conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)
_INSERT_PARAM_SCORES = (
    "INSERT INTO parameter_scores (parameter_code, value, min_value, max_value, system_code, score) "
    "VALUES (:parameter_code, :value, :min_value, :max_value, :system_code, :score)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)
_INSERT_INSTR_PARAMS = (
    "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)


def _numeric(s: str) -> str | None:
    # Только для numeric-колонок: в каталоге десятичный разделитель — запятая («0,5»).
    # К текстовым колонкам НЕ применять: replace(",", ".") калечит русский текст (см. 0107).
    s = (s or "").replace(",", ".").rstrip("+").strip()
    return s or None


def _int_or_none(s: str) -> int | None:
    s = (s or "").strip()
    return int(s) if s else None


def _parse_questions(path: Path) -> list[dict]:
    # CSV из админки содержит лишнюю колонку category — в схеме её нет с 0092, игнорируем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "type": r["type"],
            "is_skippable": bool(int(r["is_skippable"])) if r["is_skippable"] else False,
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_options(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "value": r["value"] or None,
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": r["value"] or None,
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _parse_param_scores(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            # value — текст ответа, не число: пишем как есть (см. 0107 про порчу текста).
            "value": r["value"] or None,
            "min_value": _numeric(r["min_value"]),
            "max_value": _numeric(r["max_value"]),
            "system_code": r["system_code"],
            "score": _numeric(r["score"]),
        }
        for r in load_csv(path)
        if r["parameter_code"]
    ]


def _parse_risk_factors(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r["modifiability"],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r["reasoning"] or None,
            "system_code": r["system_code"] or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_instr_params(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
    ]


def _replace(seeds: dict[str, Path]) -> None:
    conn = op.get_bind()

    # options/conditions → questions (ON DELETE RESTRICT): сносим детей первыми, потом parent.
    conn.execute(sa.text("DELETE FROM options"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM conditions"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM questions"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM parameter_scores"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM risk_factors"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM instruments_parameters"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_QUESTIONS), _parse_questions(seeds["questions"]))
    conn.execute(sa.text(_INSERT_OPTIONS), _parse_options(seeds["options"]))
    conn.execute(sa.text(_INSERT_CONDITIONS), _parse_conditions(seeds["conditions"]))
    conn.execute(sa.text(_INSERT_PARAM_SCORES), _parse_param_scores(seeds["parameters_score"]))
    conn.execute(sa.text(_INSERT_RISK_FACTORS), _parse_risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_INSTR_PARAMS), _parse_instr_params(seeds["instruments_parameters"]))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
