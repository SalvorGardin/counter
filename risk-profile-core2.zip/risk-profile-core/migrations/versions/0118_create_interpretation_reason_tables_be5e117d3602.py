"""0118_create_interpretation_reason_tables

Revision ID: be5e117d3602
Revises: 4b1e7c93a5d2
Create Date: 2026-08-11 12:00:00.000000

Диагностические таблицы `interpretation_statuses` и `risk_factor_matches`: почему по системе пуст
каждый из четырёх результатов интерпретации и какая строка справочника факторов риска сработала у
пациента. Клинические данные в них не хранятся — профиль по-прежнему в `interpretations`.

Запись в таблицы управляется флагом `RISK_MODEL_CALC_STATUS_COLLECTION_ENABLED` (тем же, что у
`calculation_statuses`, см. `docs/requirements/calc-statuses.md`), но сами таблицы создаются
безусловно: состояние флага не должно влиять на схему базы.

Внешних ключей на `risk_factors`, `parameters` и `systems` нет ни одного: сиды каталога
перезаливают справочники целиком (`DELETE` + `INSERT`), и ключ с запретом удаления сорвал бы
перезаливку. Условие срабатывания фактора поэтому хранится снимком.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "be5e117d3602"
down_revision: str | None = "4b1e7c93a5d2"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "interpretation_statuses",
        sa.Column("interpretation_status_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("risk_level_status", sa.String(), nullable=False),
        sa.Column("risk_level_reason_code", sa.String(), nullable=True),
        sa.Column("diseases_status", sa.String(), nullable=False),
        sa.Column("diseases_reason_code", sa.String(), nullable=True),
        sa.Column("risk_factors_status", sa.String(), nullable=False),
        sa.Column("risk_factors_reason_code", sa.String(), nullable=True),
        sa.Column("doctors_status", sa.String(), nullable=False),
        sa.Column("doctors_reason_code", sa.String(), nullable=True),
        sa.Column("blocking_instrument_codes", sa.ARRAY(sa.Text()), nullable=True),
        sa.Column("date_time", sa.TIMESTAMP(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            ["patients.patient_id"],
            name=op.f("fk_interpretation_statuses_patients_patient_id"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("interpretation_status_id", name=op.f("pk_interpretation_statuses")),
        sa.UniqueConstraint(
            "patient_id",
            "system_code",
            name=op.f("uq_interpretation_statuses_patient_id_system_code"),
        ),
    )
    op.create_table(
        "risk_factor_matches",
        sa.Column("risk_factor_match_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("risk_factor_id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("param_value", sa.String(), nullable=True),
        sa.Column("min_param_value", sa.String(), nullable=True),
        sa.Column("max_param_value", sa.String(), nullable=True),
        sa.Column("modifiability", sa.String(), nullable=False),
        sa.Column("is_representative", sa.Boolean(), nullable=False),
        sa.Column("superseded_by_risk_factor_id", sa.Integer(), nullable=True),
        sa.Column("date_time", sa.TIMESTAMP(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            ["patients.patient_id"],
            name=op.f("fk_risk_factor_matches_patients_patient_id"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("risk_factor_match_id", name=op.f("pk_risk_factor_matches")),
        sa.UniqueConstraint(
            "patient_id",
            "system_code",
            "risk_factor_id",
            name=op.f("uq_risk_factor_matches_patient_id_system_code_risk_factor_id"),
        ),
    )


def downgrade() -> None:
    op.drop_table("risk_factor_matches")
    op.drop_table("interpretation_statuses")
