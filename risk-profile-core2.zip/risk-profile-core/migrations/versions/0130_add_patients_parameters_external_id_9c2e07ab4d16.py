"""0130_add_patients_parameters_external_id

Revision ID: 9c2e07ab4d16
Revises: 5ad1c860f273
Create Date: 2026-08-28 11:10:00.000000

`external_id` — идентификатор экземпляра значения во внешней системе-источнике. Заполняется
только у параметров, пришедших из ЭМК, поэтому колонка nullable.

Колонка добавляется и в `patients_parameters_history`: история заполняется прикладным кодом по
явным спискам колонок, и без правки этих списков колонка осталась бы пустой навсегда.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "9c2e07ab4d16"
down_revision: str | None = "5ad1c860f273"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("patients_parameters", sa.Column("external_id", sa.Integer(), nullable=True))
    op.add_column("patients_parameters_history", sa.Column("external_id", sa.Integer(), nullable=True))


def downgrade() -> None:
    op.drop_column("patients_parameters_history", "external_id")
    op.drop_column("patients_parameters", "external_id")
