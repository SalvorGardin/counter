"""0138_create_disease_examinations_table

Revision ID: aaa40fe11a3a
Revises: 0dcbef89b5f9
Create Date: 2026-09-04 10:10:00.000000

Состав рекомендованных исследований группы заболеваний: строка — одно исследование для одной
группы с учётом пола клиента. Тип исследования не дублируется, он берётся из
`examinations.examination_type`; деления на базовые и дополнительные исследования нет.

`gender IS NULL` означает «без ограничения по полу». Для пары (группа, исследование) допустима
либо одна такая общая строка, либо строки по полу — одновременно они не допускаются. Это
условие пар строк, поэтому его держит EXCLUDE-ограничение, а не UNIQUE: пол разворачивается
в отрезок ('Мужской' → [0,1), 'Женский' → [1,2), NULL → [0,2)), и запрещается пересечение
отрезков внутри пары. Общая строка перекрывает оба слота и потому конфликтует и с любой
полоспецифичной строкой, и сама с собой — то есть то же ограничение даёт и уникальность
тройки (`disease_code`, `examination_code`, `gender`) с NULLS NOT DISTINCT.

Сравнение по `=` внутри GiST-индекса требует расширения btree_gist. Оно trusted начиная с
PostgreSQL 13, то есть ставится владельцем БД без прав суперпользователя.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "aaa40fe11a3a"
down_revision: str | None = "0dcbef89b5f9"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_INDEXED_COLUMNS = ("disease_code", "examination_code")
_GENDER_SCOPE_CONSTRAINT = "ex_disease_examinations_gender_scope"


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS btree_gist")
    op.create_table(
        "disease_examinations",
        sa.Column("disease_examination_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("disease_code", sa.String(), nullable=False),
        sa.Column("examination_code", sa.Uuid(), nullable=False),
        sa.Column("gender", sa.String(), nullable=True),
        sa.CheckConstraint(
            "gender IS NULL OR gender IN ('Мужской', 'Женский')",
            name=op.f("ck_disease_examinations_gender"),
        ),
        sa.ForeignKeyConstraint(
            ["disease_code"],
            ["diseases.code"],
            name=op.f("fk_disease_examinations_diseases_disease_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["examination_code"],
            ["examinations.code"],
            name=op.f("fk_disease_examinations_examinations_examination_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("disease_examination_id", name=op.f("pk_disease_examinations")),
    )
    for column in _INDEXED_COLUMNS:
        op.create_index(op.f(f"ix_disease_examinations_{column}"), "disease_examinations", [column])
    op.execute(
        f"ALTER TABLE disease_examinations ADD CONSTRAINT {_GENDER_SCOPE_CONSTRAINT} "
        "EXCLUDE USING gist ("
        "disease_code WITH =, "
        "examination_code WITH =, "
        "(CASE gender "
        "WHEN 'Мужской' THEN int4range(0, 1) "
        "WHEN 'Женский' THEN int4range(1, 2) "
        "ELSE int4range(0, 2) END) WITH &&"
        ")"
    )


def downgrade() -> None:
    op.execute(f"ALTER TABLE disease_examinations DROP CONSTRAINT {_GENDER_SCOPE_CONSTRAINT}")
    for column in _INDEXED_COLUMNS:
        op.drop_index(op.f(f"ix_disease_examinations_{column}"), table_name="disease_examinations")
    op.drop_table("disease_examinations")
    # btree_gist намеренно не удаляется: расширение — общая инфраструктура схемы, и его
    # использует также ex_system_checkup_examinations_gender_scope из 0139. DROP EXTENSION
    # здесь либо упал бы на зависимости, либо снёс бы объект, которым владеет не эта миграция.
