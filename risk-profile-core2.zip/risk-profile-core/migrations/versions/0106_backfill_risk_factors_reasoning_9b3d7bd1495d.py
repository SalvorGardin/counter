"""0106_backfill_risk_factors_reasoning

Revision ID: 9b3d7bd1495d
Revises: ef9934ec3bce
Create Date: 2026-07-07

Проливка справочника факторов риска (#96, бэкофилл reasoning) из админки
risk-profile-admin: аналитик наполнил и переформулировал тексты `reasoning`,
добавил недостающие связки фактор×система и убрал лишние. Экспорт снимка
v138 лежит в catalog/0106_9b3d7bd1495d_risk_factors.csv.

Дельта относительно текущего сида (0096):
  • reasoning: 5 пустых заполнены, 285 переформулированы (0 очищено);
  • +75 строк (напр. extreme_sport_* / long_flights по ENDO/ONCO/SENSE/REPROD/...),
    −12 строк (в осн. extreme_sport_* × URO + пустая строка-мусор);
  • description изменён в 1 строке, modifiability — без изменений.

Схема НЕ меняется. risk_factors_code в recommendations — не FK (снят в 0096),
поэтому это простой DELETE+INSERT одной таблицы. Естественный ключ
uq_risk_factors_natural_key (NULLS NOT DISTINCT) в новом наборе уникален,
все parameter_code/system_code проходят FK на parameters/systems.

reasoning в новом CSV непустой у всех строк, кроме одной (nullable — пишем NULL).
Заголовок modifiability уже без опечатки; старый сид 0096 читаем как «modofiability».

downgrade возвращает сид 0096 (306 строк, reasoning прежней редакции).
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "9b3d7bd1495d"
down_revision: str | None = "ef9934ec3bce"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_NEW_CSV_PATH = _CATALOG / "0106_9b3d7bd1495d_risk_factors.csv"
_OLD_CSV_PATH = _CATALOG / "0096_a460718b3b84_risk_factors.csv"

_INSERT_SQL = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)


def _parse_rows(path: Path, *, modifiability_col: str) -> list[dict]:
    # Пустые строки-артефакты (без code) пропускаем — как в сиде 0096; modifiability_col
    # отличается: новый CSV 0106 без опечатки (modifiability), сид 0096 — modofiability.
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r[modifiability_col],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r.get("reasoning") or None,
            "system_code": r.get("system_code") or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _replace(path: Path, *, modifiability_col: str) -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM risk_factors"))
    conn.execute(sa.text(_INSERT_SQL), _parse_rows(path, modifiability_col=modifiability_col))


def upgrade() -> None:
    _replace(_NEW_CSV_PATH, modifiability_col="modifiability")


def downgrade() -> None:
    _replace(_OLD_CSV_PATH, modifiability_col="modofiability")
