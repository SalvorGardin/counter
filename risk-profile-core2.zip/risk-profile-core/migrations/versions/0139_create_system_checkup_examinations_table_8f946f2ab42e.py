"""0139_create_system_checkup_examinations_table

Revision ID: 8f946f2ab42e
Revises: aaa40fe11a3a
Create Date: 2026-09-04 10:20:00.000000

Состав общего чек-апа системы организма: строка — одно исследование чек-апа с учётом пола
клиента. У системы один общий чек-ап, его состав задаётся всеми подходящими строками таблицы,
поэтому отдельной сущности чек-апа и отдельного кода у него нет.

Правило совместимости строк по полу то же, что в `disease_examinations` (0138): для пары
(система, исследование) допустима либо общая строка с `gender IS NULL`, либо строки по полу.
Держит его EXCLUDE-ограничение по пересечению отрезков пола — оно же даёт уникальность тройки
(`system_code`, `examination_code`, `gender`) с NULLS NOT DISTINCT. Расширение btree_gist,
нужное для сравнения по `=` внутри GiST-индекса, установлено в 0138.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "8f946f2ab42e"
down_revision: str | None = "aaa40fe11a3a"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_INDEXED_COLUMNS = ("system_code", "examination_code")
_GENDER_SCOPE_CONSTRAINT = "ex_system_checkup_examinations_gender_scope"


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS btree_gist")
    op.create_table(
        "system_checkup_examinations",
        sa.Column("system_checkup_examination_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("examination_code", sa.Uuid(), nullable=False),
        sa.Column("gender", sa.String(), nullable=True),
        sa.CheckConstraint(
            "gender IS NULL OR gender IN ('Мужской', 'Женский')",
            name=op.f("ck_system_checkup_examinations_gender"),
        ),
        sa.ForeignKeyConstraint(
            ["system_code"],
            ["systems.code"],
            name=op.f("fk_system_checkup_examinations_systems_system_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["examination_code"],
            ["examinations.code"],
            name=op.f("fk_system_checkup_examinations_examinations_examination_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("system_checkup_examination_id", name=op.f("pk_system_checkup_examinations")),
    )
    for column in _INDEXED_COLUMNS:
        op.create_index(op.f(f"ix_system_checkup_examinations_{column}"), "system_checkup_examinations", [column])
    op.execute(
        f"ALTER TABLE system_checkup_examinations ADD CONSTRAINT {_GENDER_SCOPE_CONSTRAINT} "
        "EXCLUDE USING gist ("
        "system_code WITH =, "
        "examination_code WITH =, "
        "(CASE gender "
        "WHEN 'Мужской' THEN int4range(0, 1) "
        "WHEN 'Женский' THEN int4range(1, 2) "
        "ELSE int4range(0, 2) END) WITH &&"
        ")"
    )


def downgrade() -> None:
    op.execute(f"ALTER TABLE system_checkup_examinations DROP CONSTRAINT {_GENDER_SCOPE_CONSTRAINT}")
    for column in _INDEXED_COLUMNS:
        op.drop_index(op.f(f"ix_system_checkup_examinations_{column}"), table_name="system_checkup_examinations")
    op.drop_table("system_checkup_examinations")
