"""0116_actualize_risk_factors_and_instrument_parameters_from_admin

Revision ID: 163ab71d0203
Revises: e76865e52a0b
Create Date: 2026-08-07 12:00:00.000000

Перезаливка risk_factors и instruments_parameters из
catalog/0116_163ab71d0203_<entity>.csv (свежие снимки из админки). Остальные справочники
(recommendations, questions, options, conditions, parameter_scores, parameters, systems)
не трогаем: recommendations в снимке совпадает с сидом 0114 построчно (сверено по ключу
recommendations_group+risk_factors_code+system_code+name и по тексту), остальные — за
скопом снимка.

Дельта против состояния стенда (risk_factors — сид 0114, instruments_parameters — 0111):

  • risk_factors     300 → 307 строк. Основной вид правки — заполнение пустого
                     `param_value` у 51 логического фактора: раньше строка ссылалась на
                     параметр, но не указывала, какой именно ответ считается фактором
                     риска, из-за чего фактор не мог сматчиться с ответом пациента.
                     Теперь у каждой такой строки указан текст ответа
                     (`fr_chest_pain × CVD` → `Да`, `fr_nocturia × URO` → `2 раза и более`
                     и т.д.), а там, где фактором считаются несколько ответов, строка
                     разложена на несколько (`fr_dysuria × URO` → `Иногда` + `Часто`,
                     `fr_unexplained_weight_fluct × ENDO/ONCO` → две градации каждая) —
                     отсюда +7 к общему числу строк.
                     `fr_lipoprotein_a × CVD` вместо `param_value` получает числовой
                     диапазон `min_param_value=50`, `max_param_value=1000` (параметр
                     количественный, порог согласован с parameter_scores 0111, где
                     50+ даёт score 2).
                     Одна правка ключа: `fr_antihypertensive_meds × SENSE` переезжает с
                     `parameter_code=antiarrhythmics_meds` на `antihypertensive_meds` —
                     фактор «препараты для снижения давления» был привязан к параметру
                     про нормализацию сердечного ритма. Строка
                     `fr_antiarrhythmics_meds × CVD` на `antiarrhythmics_meds` остаётся.
                     description, modifiability и reasoning не менялись ни у одной строки.
  • instruments_parameters +1 строка: `form_sense × antihypertensive_meds`
                     (is_required=false). Удалений и правок is_required нет.

Новые `param_value` матчатся с ответами пациентов строгим строковым равенством, поэтому
все они сверены с текстами `options.value` действующего сида 0111 — совпадают. Исключение
одно и оно штатное: `antihypertensive_meds` относится к вопросу типа multi, где в
`patients_parameters.value` хранится `Да`/`Нет`, а не текст опции, — для такой строки
`param_value=Да` и есть правильное значение (так же устроены остальные multi-факторы,
уже приехавшие в 0111).

Ответы пациентов не затрагиваются и ремап `patients_parameters.value` не нужен:
`options.value` не переименовываются, миграция правит только справочник факторов.

Приём — полная перезаливка каждой таблицы (DELETE + INSERT), как в 0111/0113/0114:
естественные ключи (`uq_risk_factors_natural_key` по полному кортежу,
`uq_instruments_parameters_instrument_parameter`) покрывают почти все колонки, поэтому
«обновление на месте» одним UPSERT невыразимо. Уникальность новых наборов по этим ключам
проверена заранее — дублей нет.

FK не задеваются. risk_factors → parameters.code / systems.code и instruments_parameters →
instruments.code / parameters.code (везде ON DELETE RESTRICT) смотрят на родителей,
которых миграция не трогает; все `parameter_code`, `system_code` и `instrument_code`
нового набора присутствуют в сидах 0096/0103/0086 — сверено. Составной FK
recommendations → risk_factors снят в 0096, связь по паре (`code`, `system_code`) живёт на
уровне приложения: набор таких пар в risk_factors не меняется (перевешивание
`fr_antihypertensive_meds × SENSE` на другой параметр пару сохраняет), поэтому
recommendations не осиротеет ни по одной строке — проверено.

downgrade возвращает предыдущие сиды: risk_factors → 0114,
instruments_parameters → 0111.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "163ab71d0203"
down_revision: str | None = "e76865e52a0b"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = {
    "risk_factors": _CATALOG / "0116_163ab71d0203_risk_factors.csv",
    "instruments_parameters": _CATALOG / "0116_163ab71d0203_instrument_parameters.csv",
}
_OLD = {
    "risk_factors": _CATALOG / "0114_00c99f0ebbe8_risk_factors.csv",
    "instruments_parameters": _CATALOG / "0111_06526a399cf8_instrument_parameters.csv",
}

_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)
_INSERT_INSTR_PARAMS = (
    "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)


def _parse_risk_factors(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r["modifiability"],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r["reasoning"] or None,
            "system_code": r["system_code"] or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _parse_instr_params(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
        if r["instrument_code"]
    ]


def _replace(seeds: dict[str, Path]) -> None:
    conn = op.get_bind()
    # Обе таблицы — листья в графе FK (родители parameters/systems/instruments не
    # трогаются, а FK recommendations → risk_factors снят в 0096), поэтому порядок
    # DELETE/INSERT между ними свободен.
    conn.execute(sa.text("DELETE FROM risk_factors"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM instruments_parameters"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_RISK_FACTORS), _parse_risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_INSTR_PARAMS), _parse_instr_params(seeds["instruments_parameters"]))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
