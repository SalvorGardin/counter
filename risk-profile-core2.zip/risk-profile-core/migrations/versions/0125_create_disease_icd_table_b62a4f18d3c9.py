"""0125_create_disease_icd_table

Revision ID: b62a4f18d3c9
Revises: d3b8e5091c7a
Create Date: 2026-08-28 10:20:00.000000

Состав группы заболеваний: коды МКБ третьего уровня, входящие в группу. Один код привязан к
группе один раз.

`icd_code` — строка без внешнего ключа: справочника кодов МКБ в базе нет. Добавить ключ
позже, когда справочник появится, дешевле, чем снимать его сейчас.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "b62a4f18d3c9"
down_revision: str | None = "d3b8e5091c7a"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "disease_icd",
        sa.Column("disease_icd_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("disease_code", sa.String(), nullable=False),
        sa.Column("icd_code", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["disease_code"],
            ["diseases.code"],
            name=op.f("fk_disease_icd_diseases_disease_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("disease_icd_id", name=op.f("pk_disease_icd")),
        sa.UniqueConstraint(
            "disease_code",
            "icd_code",
            name=op.f("uq_disease_icd_disease_code_icd_code"),
        ),
    )
    op.create_index(op.f("ix_disease_icd_disease_code"), "disease_icd", ["disease_code"])


def downgrade() -> None:
    op.drop_index(op.f("ix_disease_icd_disease_code"), table_name="disease_icd")
    op.drop_table("disease_icd")
