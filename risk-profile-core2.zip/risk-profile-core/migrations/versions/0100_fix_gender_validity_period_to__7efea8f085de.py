"""0100_fix_gender_validity_period_to_match_risk_init

Revision ID: 7efea8f085de
Revises: c73d90dc2648
Create Date: 2026-06-30 15:25:48.733012

То же, что 0099, но для gender: выравниваем срок жизни ответа gender в risk-communication
с risk-init. parameters.validity_period у gender стоял дефолтным 1980-01-01 (~10 лет от эпохи,
см. expiration.to_timedelta), тогда как risk-init пишет gender с PARAMETER_VALIDITY[gender] =
100 лет (36500 дней, src/services/risk_init/domain/validity.py). Пол биологически неизменен — 100 лет
корректнее 10.

Ставим validity_period = 1970-01-01 + 36500 дней (= 2069-12-07): to_timedelta даёт ровно
36500 дней, как timedelta(days=36500) у risk-init. validity_period читает только
risk-communication. Существующие строки gender не ремапятся — фикс на новые ответы.

Идемпотентный UPDATE по одному коду. Каталог-сид catalog/0096_..._parameters.csv поправлен
синхронно (gender → 2069-12-07).
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "7efea8f085de"
down_revision: str | None = "c73d90dc2648"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# Литерал, а НЕ bind-параметр: asyncpg (прод) не коэрсит str → timestamptz и падает DataError
# на CAST(:param AS TIMESTAMPTZ) (psycopg2 в тестах — коэрсит, поэтому баг не ловился). Литерал
# TIMESTAMPTZ '...' парсится сервером. 1970-01-01 + 36500 дней == 100*365 == PARAMETER_VALIDITY
# [gender] в risk-init.
_NEW_VALIDITY_SQL = (
    "UPDATE parameters SET validity_period = TIMESTAMPTZ '1970-01-01 00:00:00+00' + INTERVAL '36500 days' "
    "WHERE code = 'gender'"
)
# Прежний дефолт каталога (~10 лет от эпохи) — для отката.
_OLD_VALIDITY_SQL = "UPDATE parameters SET validity_period = TIMESTAMPTZ '1980-01-01 00:00:00+00' WHERE code = 'gender'"


def upgrade() -> None:
    op.get_bind().execute(sa.text(_NEW_VALIDITY_SQL))


def downgrade() -> None:
    op.get_bind().execute(sa.text(_OLD_VALIDITY_SQL))
