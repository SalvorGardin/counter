"""0115_add_cq030_age_condition

Revision ID: e76865e52a0b
Revises: 00c99f0ebbe8
Create Date: 2026-08-06 18:26:51.843271

Перезаливка conditions из catalog/0115_e76865e52a0b_conditions.csv: сид 0107 плюс ОДНА
строка `cq_030;age;;age;1;49` — вопрос о беременности не задаётся пациентам 50 лет и
старше. Формат строки повторяет уже существующие возрастные ограничения женских вопросов
(sq_0360/sq_0390/sq_0400/sq_0420, `1;49` у sq_0420), отдельного механизма не вводится.

Эффект даёт общая доменная логика без правок кода: `classify_question` трактует
сработавшее условие типа `age` так же, как `except` по gender, — вопрос выпадает из
знаменателя заполненности (Risk-profile, шаг 4) и из счёта применимых вопросов гейта
опросников (STEP 3), а `question_is_visible` перестаёт отдавать его в опроснике. То есть
пациентка 50+ получает ровно то же поведение, что мужчина по строке `cq_030;gender;Мужской`.
Возраст берётся из актуального параметра `birthdate`; при его отсутствии условие не
проходит и вопрос также не показывается.

`patients.is_pregnant` миграция НЕ трогает: у не отвечавших пациентов остаётся NULL.
Значение и не требуется — вопрос больше не применим, поэтому проверки «отвечен ли cq_030»
(`_question_answered`, `build_questionnaire_eligibility`) до него не доходят, а формулам
и medical-risk NULL и False эквивалентны.

Ответы пациентов не затрагиваются: `options.value` не переименовываются, ремап
`patients_parameters.value` не нужен. Строки conditions с ответами матчатся только по
`value`, а добавленная строка — возрастная, с пустым `value`.

FK conditions.question_code → questions.code (ON DELETE RESTRICT) не задевается: cq_030
присутствует в сиде questions 0111.

downgrade возвращает сид conditions 0107 (текущее состояние стенда).
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "e76865e52a0b"
down_revision: str | None = "00c99f0ebbe8"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = _CATALOG / "0115_e76865e52a0b_conditions.csv"
_OLD = _CATALOG / "0107_4c1a9e7b3d85_conditions.csv"

_INSERT_CONDITIONS = (
    "INSERT INTO conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)


def _int_or_none(s: str) -> int | None:
    s = (s or "").strip()
    return int(s) if s else None


def _parse_conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": r["value"] or None,
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _replace(seed: Path) -> None:
    conn = op.get_bind()
    # conditions — лист в графе FK (родитель questions не трогаем), поэтому перезаливается
    # в одиночку, тем же DELETE+INSERT, что и в 0107/0111.
    conn.execute(sa.text("DELETE FROM conditions"))  # migration-safety: ok full replace
    conn.execute(sa.text(_INSERT_CONDITIONS), _parse_conditions(seed))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
