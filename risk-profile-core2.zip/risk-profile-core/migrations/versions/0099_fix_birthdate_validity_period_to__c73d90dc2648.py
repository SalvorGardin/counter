"""0099_fix_birthdate_validity_period_to_match_risk_init

Revision ID: c73d90dc2648
Revises: 6f877f75f414
Create Date: 2026-06-30 15:20:31.563996

Выравнивает срок жизни ответа birthdate, заданного через risk-communication, с risk-init.

parameters.validity_period семантически — длительность от UNIX-эпохи (expiration.to_timedelta:
expiration_date = now + (validity_period − 1970-01-01)). У birthdate в каталоге стоял дефолт
1980-01-01 = ~10 лет, поэтому risk-communication ставил дату рождения протухать через 10 лет.
risk-init же пишет birthdate с PARAMETER_VALIDITY[birthdate] = 100 лет (36500 дней,
src/services/risk_init/domain/validity.py). Дата рождения биологически неизменна — 100 лет (де-факто
никогда) корректнее 10.

Ставим validity_period = 1970-01-01 + 36500 дней (= 2069-12-07), чтобы to_timedelta дало
ровно 36500 дней — тот же интервал, что timedelta(days=36500) у risk-init. Затрагивает только
risk-communication (единственный читатель validity_period). Существующие строки birthdate с уже
записанным 10-летним expiration не ремапятся — фикс действует на новые ответы (как и 0098).

Идемпотентный UPDATE по одному коду. Каталог-сид catalog/0096_..._parameters.csv поправлен
синхронно (birthdate → 2069-12-07), чтобы свежая установка и будущий reseed не вернули дефолт.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "c73d90dc2648"
down_revision: str | None = "6f877f75f414"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# Литерал, а НЕ bind-параметр: asyncpg (прод) не коэрсит str → timestamptz и падает DataError
# на CAST(:param AS TIMESTAMPTZ) (psycopg2 в тестах — коэрсит, поэтому баг не ловился). Литерал
# TIMESTAMPTZ '...' парсится сервером. 1970-01-01 + 36500 дней == 100*365 == PARAMETER_VALIDITY
# [birthdate] в risk-init.
_NEW_VALIDITY_SQL = (
    "UPDATE parameters SET validity_period = TIMESTAMPTZ '1970-01-01 00:00:00+00' + INTERVAL '36500 days' "
    "WHERE code = 'birthdate'"
)
# Прежний дефолт каталога (~10 лет от эпохи) — для отката.
_OLD_VALIDITY_SQL = (
    "UPDATE parameters SET validity_period = TIMESTAMPTZ '1980-01-01 00:00:00+00' WHERE code = 'birthdate'"
)


def upgrade() -> None:
    op.get_bind().execute(sa.text(_NEW_VALIDITY_SQL))


def downgrade() -> None:
    op.get_bind().execute(sa.text(_OLD_VALIDITY_SQL))
