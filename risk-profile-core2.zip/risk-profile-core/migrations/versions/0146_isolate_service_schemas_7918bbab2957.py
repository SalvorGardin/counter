"""0146_isolate_service_schemas

Revision ID: 7918bbab2957
Revises: 15c247ec61bb
Create Date: 2026-09-07 12:00:00.000000

Разносит физические таблицы по схемам владельцев и оставляет каждому рантайму доступ только
к его собственной схеме.

* `risk_profile` — данные пациента: `patients`, `patients_parameters`, `patients_parameters_history`.
* `risk_calculation` — посчитанное: результаты, интерпретации, диагностические статусы, факторы.
* `catalog` — статические справочники, общие и доступные рантаймам только на чтение.
* `risk_ehr` — собственных таблиц нет: только интерфейс консюмера ЭМК.

Данные не копируются и не переписываются: таблицы переносятся `ALTER TABLE ... SET SCHEMA`,
вместе с ними уезжают индексы, ограничения и принадлежащие им последовательности.

Перед переносом выставляется `lock_timeout`. `SET SCHEMA` берёт ACCESS EXCLUSIVE, и если к
моменту миграции остался хоть один писатель или `idle in transaction`-сессия, без таймаута
миграция не упала бы с понятной ошибкой, а встала в очередь блокировок — выстроив за собой
все новые обращения к таблице, включая SELECT, на всё время ожидания и в одной транзакции
alembic. Ждать есть кого: автодеплой гонит миграции при живых старых процессах, а ручную
остановку писателей (шаг 2 в `deploy/DEPLOY.txt`) CI не делает. С таймаутом миграция падает
быстро и предсказуемо, а повторный прогон безопасен: DDL транзакционен, полупереехавшей схемы
не остаётся. Таймаут снимается сразу после переноса: alembic гоняет весь прогон одной
транзакцией, и без возврата `SET LOCAL` действовал бы на всех следующих миграциях. Обратный
перенос в `downgrade()` обёрнут тем же таймаутом по той же причине.

Кросс-сервисный доступ идёт через представления в схеме ПОТРЕБИТЕЛЯ с теми же именами, что у
таблиц-источников: ORM подменяет схему через `schema_translate_map`, поэтому одна и та же модель
адресует либо свою таблицу, либо локальное представление. Представления принадлежат владельцу
схемы, и права на нижележащие таблицы есть только у владельцев — рантайм-логины к чужим
физическим таблицам не допущены вовсе.

Запись параметров из ЭМК идёт обычным INSERT в `risk_ehr.patients_parameters`; всю работу
(валидация, архивация прежнего значения, upsert) делает `INSTEAD OF INSERT`-триггер в той же
транзакции вызывающего. Функция триггера — SECURITY DEFINER с владельцем `risk_ehr_owner`,
фиксированным `search_path`, полностью квалифицированными именами, без динамического SQL и без
логирования значений; EXECUTE у PUBLIC отобран, вызвать её напрямую рантайм не может.

Роли (владельцы схем, три рантайм-логина и миграционный) создаются ДО alembic —
`scripts/bootstrap_db_roles.py`: роли кластерные, а пароли рантаймов не место в миграции.
Если ролей нет, миграция падает с явным сообщением, а не выдаёт доступ кому попало.

Права на будущие объекты не наследуются ниоткуда: каждая миграция, заводящая таблицу,
последовательность или представление в этих схемах, обязана сама переназначить владельца
(`ALTER TABLE ... OWNER TO`) и выдать права (`GRANT`). Механизма `ALTER DEFAULT PRIVILEGES`
здесь нет намеренно: он привязан к роли, которая создала объект, а создаёт их `risk_migrations`,
и его членство в роли-владельце в расчёт не идёт. Правило закреплено тестом
`test_a_new_table_needs_owner_and_grants_from_its_own_migration`.

Откат сохраняет данные: сначала снимаются зависимые представления и триггер, затем таблицы
физически возвращаются в `public` и восстанавливаются прежние права. Перед откатом в проде
рантаймы должны быть остановлены.
"""

from collections.abc import Sequence

from alembic import op

revision: str = "7918bbab2957"
down_revision: str | None = "15c247ec61bb"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

PROFILE_SCHEMA = "risk_profile"
CALCULATION_SCHEMA = "risk_calculation"
EHR_SCHEMA = "risk_ehr"
CATALOG_SCHEMA = "catalog"

SCHEMA_OWNERS = {
    PROFILE_SCHEMA: "risk_profile_owner",
    CALCULATION_SCHEMA: "risk_calculation_owner",
    EHR_SCHEMA: "risk_ehr_owner",
    CATALOG_SCHEMA: "catalog_owner",
}

PROFILE_APP = "risk_profile_app"
CALCULATION_APP = "risk_calculation_app"
EHR_APP = "risk_ehr_app"
RUNTIME_ROLES = (PROFILE_APP, CALCULATION_APP, EHR_APP)
REQUIRED_ROLES = (*SCHEMA_OWNERS.values(), *RUNTIME_ROLES, "risk_migrations")
# Список ролей продублирован литералом внутри проверки `_require_roles` — asyncpg не принимает
# bind-параметры в `DO`-блоке. Расхождение этих двух мест означало бы, что миграция проверяет
# не те роли, которым потом выдаёт права.
assert set(REQUIRED_ROLES) == {
    "risk_profile_owner",
    "risk_calculation_owner",
    "risk_ehr_owner",
    "catalog_owner",
    "risk_profile_app",
    "risk_calculation_app",
    "risk_ehr_app",
    "risk_migrations",
}

PROFILE_TABLES = ("patients", "patients_parameters", "patients_parameters_history")
CALCULATION_TABLES = (
    "results",
    "results_history",
    "calculation_statuses",
    "interpretations",
    "interpretations_history",
    "interpretation_statuses",
    "risk_factor_matches",
)
CATALOG_TABLES = (
    "biomarkers",
    "biomarker_parameter_mappings",
    "clinical_recommendations",
    "conditions",
    "disease_examinations",
    "disease_icd",
    "diseases",
    "doctors",
    "examinations",
    "instruments",
    "instruments_parameters",
    "options",
    "parameter_scores",
    "parameters",
    "questions",
    "recommendations",
    "recommended_doctors",
    "risk_factor_clinrecs",
    "risk_factor_scores",
    "risk_factor_systems",
    "risk_factor_triggers",
    "risk_factors",
    "system_checkup_examinations",
    "systems",
    "systems_instruments",
)

TABLE_PLACEMENT: tuple[tuple[str, str], ...] = (
    *((table, PROFILE_SCHEMA) for table in PROFILE_TABLES),
    *((table, CALCULATION_SCHEMA) for table in CALCULATION_TABLES),
    *((table, CATALOG_SCHEMA) for table in CATALOG_TABLES),
)

# Колонки представлений перечислены явно: `SELECT *` замёрз бы на форме таблицы момента создания
# и разъехался бы с ней после ALTER-а, а расхождение поймал бы уже рантайм, а не тест формы.
VIEW_COLUMNS: dict[str, tuple[str, ...]] = {
    "patients": ("unique_id", "patient_id", "is_pregnant"),
    "patients_parameters": (
        "patient_parameter_id",
        "patient_id",
        "parameter_code",
        "value",
        "source",
        "external_id",
        "expiration_date",
        "date_time",
    ),
    "results": (
        "result_id",
        "instrument_code",
        "patient_id",
        "disease_code",
        "value",
        "indicator",
        "date_time",
        "interpretation_status",
        "expiration_date",
        "risk_level",
        "applicability",
        "unit",
    ),
    "results_history": (
        "result_history_id",
        "instrument_code",
        "patient_id",
        "disease_code",
        "value",
        "indicator",
        "date_time",
        "interpretation_status",
        "expiration_date",
        "risk_level",
        "applicability",
        "unit",
    ),
    "calculation_statuses": (
        "calculation_status_id",
        "patient_id",
        "instrument_code",
        "status",
        "reason_code",
        "date_time",
        "missing_parameter_codes",
        "applicable_questions",
        "progressed_questions",
    ),
    "interpretations": (
        "interpretation_id",
        "system_code",
        "patient_id",
        "risk_level",
        "text",
        "diseases",
        "risk_factors_code",
        "doctors_code",
        "date_time",
    ),
    "interpretations_history": (
        "interpretations_history_id",
        "system_code",
        "patient_id",
        "risk_level",
        "text",
        "diseases",
        "risk_factors_code",
        "doctors_code",
        "date_time",
    ),
    "interpretation_statuses": (
        "interpretation_status_id",
        "patient_id",
        "system_code",
        "risk_level_status",
        "risk_level_reason_code",
        "diseases_status",
        "diseases_reason_code",
        "risk_factors_status",
        "risk_factors_reason_code",
        "doctors_status",
        "doctors_reason_code",
        "blocking_instrument_codes",
        "date_time",
    ),
    "risk_factor_matches": (
        "risk_factor_match_id",
        "patient_id",
        "system_code",
        "trigger_code",
        "risk_factor_code",
        "factor_description",
        "reasoning",
        "parameter_code",
        "value_type",
        "operator",
        "value_num",
        "min_value",
        "max_value",
        "value_text",
        "gender",
        "modifiability",
        "is_representative",
        "date_time",
    ),
}

# Представления расчёта над данными профиля — только чтение.
CALCULATION_VIEWS = ("patients", "patients_parameters")
# Представления профиля над посчитанным: имя → операции, доступные профильному логину.
PROFILE_VIEWS: dict[str, tuple[str, ...]] = {
    "results": ("SELECT", "DELETE"),
    "results_history": ("INSERT",),
    "interpretations": ("SELECT", "DELETE"),
    "interpretations_history": ("INSERT",),
    "calculation_statuses": ("SELECT", "DELETE"),
    "interpretation_statuses": ("SELECT", "DELETE"),
    "risk_factor_matches": ("SELECT", "DELETE"),
}
EHR_VIEWS = ("patients", "patients_parameters")

EHR_WRITE_FUNCTION = f"{EHR_SCHEMA}.write_patient_parameter"


def _columns(name: str) -> str:
    return ", ".join(VIEW_COLUMNS[name])


def _require_roles() -> None:
    """Падает с явным сообщением, если роли не выданы: молча грантовать fallback-роли нельзя.

    Имена ролей записаны литералом, а не подставлены bind-параметром: asyncpg (прод-драйвер
    миграций) параметры в `DO`-блоке не поддерживает вовсе, а миграция — замороженный снимок,
    и имена ролей в ней меняться не должны. Совпадение с константами держит утверждение ниже.
    """
    op.execute("""
        DO $do$
        DECLARE
            missing text[];
        BEGIN
            SELECT array_agg(required)
              INTO missing
              FROM unnest(ARRAY[
                       'risk_profile_owner', 'risk_calculation_owner', 'risk_ehr_owner', 'catalog_owner',
                       'risk_profile_app', 'risk_calculation_app', 'risk_ehr_app', 'risk_migrations'
                   ]) AS required
             WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = required);
            IF missing IS NOT NULL THEN
                RAISE EXCEPTION
                    'Missing database roles: %. Run scripts/bootstrap_db_roles.py before alembic.',
                    array_to_string(missing, ', ');
            END IF;
        END
        $do$
    """)


def _create_schemas() -> None:
    for schema, owner in SCHEMA_OWNERS.items():
        op.execute(f"CREATE SCHEMA IF NOT EXISTS {schema} AUTHORIZATION {owner}")
        # AUTHORIZATION игнорируется, если схема уже была: владельца выставляем отдельно.
        op.execute(f"ALTER SCHEMA {schema} OWNER TO {owner}")
        op.execute(f"REVOKE ALL ON SCHEMA {schema} FROM PUBLIC")


def _move_tables() -> None:
    """Перенос 35 таблиц. Ждать чужую блокировку не дольше `lock_timeout` — обоснование в докстринге."""
    op.execute("SET LOCAL lock_timeout = '2s'")
    for table, schema in TABLE_PLACEMENT:
        op.execute(f"ALTER TABLE public.{table} SET SCHEMA {schema}")
        # Владелец меняется вместе с принадлежащими таблице последовательностями.
        op.execute(f"ALTER TABLE {schema}.{table} OWNER TO {SCHEMA_OWNERS[schema]}")
    op.execute("SET LOCAL lock_timeout = DEFAULT")


def _create_views() -> None:
    for name in CALCULATION_VIEWS:
        # Все подставляемые имена — константы этого модуля; пользовательского ввода тут нет.
        op.execute(  # nosec B608
            f"CREATE VIEW {CALCULATION_SCHEMA}.{name} AS SELECT {_columns(name)} FROM {PROFILE_SCHEMA}.{name}"  # nosec B608
        )
        op.execute(f"ALTER VIEW {CALCULATION_SCHEMA}.{name} OWNER TO {SCHEMA_OWNERS[CALCULATION_SCHEMA]}")

    for name in PROFILE_VIEWS:
        op.execute(  # nosec B608
            f"CREATE VIEW {PROFILE_SCHEMA}.{name} AS SELECT {_columns(name)} FROM {CALCULATION_SCHEMA}.{name}"  # nosec B608
        )
        op.execute(f"ALTER VIEW {PROFILE_SCHEMA}.{name} OWNER TO {SCHEMA_OWNERS[PROFILE_SCHEMA]}")

    for name in EHR_VIEWS:
        op.execute(  # nosec B608
            f"CREATE VIEW {EHR_SCHEMA}.{name} AS SELECT {_columns(name)} FROM {PROFILE_SCHEMA}.{name}"  # nosec B608
        )
        op.execute(f"ALTER VIEW {EHR_SCHEMA}.{name} OWNER TO {SCHEMA_OWNERS[EHR_SCHEMA]}")


def _create_ehr_write_surface() -> None:
    """Контролируемая запись параметра из ЭМК: валидация + архив + upsert в одной транзакции.

    Тело функции записано литералом, без подстановки: миграция — замороженный снимок схемы, а
    имена объектов в ней не должны зависеть от значения константы в текущем коде.
    """
    # migration-safety: ok — INSERT в историю здесь не сид, а копия текущего значения; ON CONFLICT
    # ему не нужен, повторные вызовы дают новые архивные строки по построению.
    op.execute("""
        CREATE FUNCTION risk_ehr.write_patient_parameter() RETURNS trigger
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog
        AS $function$
        BEGIN
            IF NEW.source IS DISTINCT FROM 'EMR' THEN
                RAISE EXCEPTION 'risk_ehr.patients_parameters accepts only EMR-sourced rows'
                    USING ERRCODE = 'check_violation';
            END IF;
            IF NEW.parameter_code IS NULL OR NEW.expiration_date IS NULL THEN
                RAISE EXCEPTION 'risk_ehr.patients_parameters requires parameter_code and expiration_date'
                    USING ERRCODE = 'not_null_violation';
            END IF;
            IF NOT EXISTS (
                SELECT 1 FROM risk_profile.patients WHERE patient_id = NEW.patient_id
            ) THEN
                RAISE EXCEPTION 'Unknown patient for risk_ehr.patients_parameters'
                    USING ERRCODE = 'foreign_key_violation';
            END IF;

            INSERT INTO risk_profile.patients_parameters_history
                (parameter_code, patient_id, value, source, external_id, expiration_date, date_time)
            SELECT current.parameter_code, current.patient_id, current.value, current.source,
                   current.external_id, current.expiration_date, current.date_time
              FROM risk_profile.patients_parameters AS current
             WHERE current.patient_id = NEW.patient_id
               AND current.parameter_code = NEW.parameter_code;

            INSERT INTO risk_profile.patients_parameters
                (parameter_code, patient_id, value, source, external_id, expiration_date, date_time)
            VALUES (NEW.parameter_code, NEW.patient_id, NEW.value, NEW.source, NEW.external_id,
                    NEW.expiration_date, COALESCE(NEW.date_time, now()))
            ON CONFLICT ON CONSTRAINT uq_patients_parameters_patient_id_parameter_code
            DO UPDATE SET value = EXCLUDED.value,
                          source = EXCLUDED.source,
                          external_id = EXCLUDED.external_id,
                          expiration_date = EXCLUDED.expiration_date,
                          date_time = EXCLUDED.date_time
            RETURNING patient_parameter_id, date_time INTO NEW.patient_parameter_id, NEW.date_time;

            RETURN NEW;
        END
        $function$
    """)
    op.execute(f"ALTER FUNCTION {EHR_WRITE_FUNCTION}() OWNER TO {SCHEMA_OWNERS[EHR_SCHEMA]}")
    # Функция достижима только через триггер представления: прямой вызов рантайму недоступен.
    op.execute(f"REVOKE ALL ON FUNCTION {EHR_WRITE_FUNCTION}() FROM PUBLIC")
    op.execute(f"""
        CREATE TRIGGER write_patient_parameter
        INSTEAD OF INSERT ON {EHR_SCHEMA}.patients_parameters
        FOR EACH ROW EXECUTE FUNCTION {EHR_WRITE_FUNCTION}()
    """)


def _grant_owner_cross_schema_access() -> None:
    """Права владельцев на чужие физические таблицы: представление работает от имени владельца."""
    profile_owner = SCHEMA_OWNERS[PROFILE_SCHEMA]
    calculation_owner = SCHEMA_OWNERS[CALCULATION_SCHEMA]
    ehr_owner = SCHEMA_OWNERS[EHR_SCHEMA]

    op.execute(f"GRANT USAGE ON SCHEMA {CALCULATION_SCHEMA} TO {profile_owner}")
    for name, operations in PROFILE_VIEWS.items():
        op.execute(f"GRANT {', '.join(operations)} ON {CALCULATION_SCHEMA}.{name} TO {profile_owner}")

    op.execute(f"GRANT USAGE ON SCHEMA {PROFILE_SCHEMA} TO {calculation_owner}, {ehr_owner}")
    op.execute(
        f"GRANT SELECT ON {PROFILE_SCHEMA}.patients, {PROFILE_SCHEMA}.patients_parameters TO {calculation_owner}"
    )
    op.execute(f"GRANT SELECT ON {PROFILE_SCHEMA}.patients TO {ehr_owner}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE ON {PROFILE_SCHEMA}.patients_parameters TO {ehr_owner}")
    op.execute(f"GRANT INSERT ON {PROFILE_SCHEMA}.patients_parameters_history TO {ehr_owner}")

    # Вставка в чужую таблицу двигает её последовательность: без USAGE на ней INSERT упадёт.
    _grant_sequence_usage(f"{PROFILE_SCHEMA}.patients_parameters", "patient_parameter_id", ehr_owner)
    _grant_sequence_usage(f"{PROFILE_SCHEMA}.patients_parameters_history", "patient_parameter_history_id", ehr_owner)
    _grant_sequence_usage(f"{CALCULATION_SCHEMA}.results_history", "result_history_id", profile_owner)
    _grant_sequence_usage(f"{CALCULATION_SCHEMA}.interpretations_history", "interpretations_history_id", profile_owner)


def _grant_sequence_usage(qualified_table: str, column: str, role: str) -> None:
    """Имя последовательности спрашиваем у самой БД: после переноса оно схемно-квалифицированное."""
    op.execute(f"""
        DO $$
        DECLARE
            sequence_name text := pg_get_serial_sequence('{qualified_table}', '{column}');
        BEGIN
            IF sequence_name IS NULL THEN
                RAISE EXCEPTION 'No sequence owned by {qualified_table}.{column}';
            END IF;
            EXECUTE format('GRANT USAGE ON SEQUENCE %s TO %I', sequence_name, '{role}');
        END
        $$
    """)


def _grant_runtime_access() -> None:
    """Каждому логину — только его схема: свои таблицы, свои представления и чтение справочников."""
    op.execute("REVOKE ALL ON SCHEMA public FROM PUBLIC")
    for schema in (PROFILE_SCHEMA, CALCULATION_SCHEMA, EHR_SCHEMA, CATALOG_SCHEMA):
        op.execute(f"REVOKE ALL ON ALL TABLES IN SCHEMA {schema} FROM PUBLIC")

    op.execute(f"GRANT USAGE ON SCHEMA {PROFILE_SCHEMA} TO {PROFILE_APP}")
    for table in PROFILE_TABLES:
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {PROFILE_SCHEMA}.{table} TO {PROFILE_APP}")
    op.execute(f"GRANT USAGE ON ALL SEQUENCES IN SCHEMA {PROFILE_SCHEMA} TO {PROFILE_APP}")
    for name, operations in PROFILE_VIEWS.items():
        op.execute(f"GRANT {', '.join(operations)} ON {PROFILE_SCHEMA}.{name} TO {PROFILE_APP}")
    # Представления истории автообновляемые, а не с INSTEAD OF-триггером, как поверхность записи
    # ЭМК. Право на саму таблицу PostgreSQL проверяет у владельца представления, но `nextval()` в
    # DEFAULT ключа — это вызов функции, и USAGE на последовательности проверяется у ТЕКУЩЕГО
    # пользователя. Без этих двух грантов архивация из профиля падает 42501 на первой же вставке.
    _grant_sequence_usage(f"{CALCULATION_SCHEMA}.results_history", "result_history_id", PROFILE_APP)
    _grant_sequence_usage(f"{CALCULATION_SCHEMA}.interpretations_history", "interpretations_history_id", PROFILE_APP)

    op.execute(f"GRANT USAGE ON SCHEMA {CALCULATION_SCHEMA} TO {CALCULATION_APP}")
    for table in CALCULATION_TABLES:
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {CALCULATION_SCHEMA}.{table} TO {CALCULATION_APP}")
    op.execute(f"GRANT USAGE ON ALL SEQUENCES IN SCHEMA {CALCULATION_SCHEMA} TO {CALCULATION_APP}")
    for name in CALCULATION_VIEWS:
        op.execute(f"GRANT SELECT ON {CALCULATION_SCHEMA}.{name} TO {CALCULATION_APP}")

    op.execute(f"GRANT USAGE ON SCHEMA {EHR_SCHEMA} TO {EHR_APP}")
    op.execute(f"GRANT SELECT ON {EHR_SCHEMA}.patients TO {EHR_APP}")
    op.execute(f"GRANT SELECT, INSERT ON {EHR_SCHEMA}.patients_parameters TO {EHR_APP}")

    runtime = ", ".join(RUNTIME_ROLES)
    op.execute(f"GRANT USAGE ON SCHEMA {CATALOG_SCHEMA} TO {runtime}")
    op.execute(f"GRANT SELECT ON ALL TABLES IN SCHEMA {CATALOG_SCHEMA} TO {runtime}")


def upgrade() -> None:
    _require_roles()
    _create_schemas()
    _move_tables()
    _create_views()
    _create_ehr_write_surface()
    _grant_owner_cross_schema_access()
    _grant_runtime_access()


def downgrade() -> None:
    """Возвращает таблицы в public без копирования данных: сначала зависимые объекты, потом сами таблицы."""
    op.execute(f"DROP TRIGGER IF EXISTS write_patient_parameter ON {EHR_SCHEMA}.patients_parameters")
    op.execute(f"DROP FUNCTION IF EXISTS {EHR_WRITE_FUNCTION}()")
    for schema, views in (
        (EHR_SCHEMA, EHR_VIEWS),
        (PROFILE_SCHEMA, tuple(PROFILE_VIEWS)),
        (CALCULATION_SCHEMA, CALCULATION_VIEWS),
    ):
        for name in views:
            op.execute(f"DROP VIEW IF EXISTS {schema}.{name}")

    # Владельцем возвращённых таблиц становится тот же, кто владеет alembic_version, — роль,
    # под которой цепочка создавала эти таблицы до переноса.
    # `lock_timeout` тот же, что и на переносе вперёд: обратный `SET SCHEMA` берёт всё тот же
    # ACCESS EXCLUSIVE, а откат идёт в аварийной ситуации, где ждать чужую зависшую транзакцию
    # неопределённо долго хуже, чем упасть с понятной ошибкой.
    op.execute("SET LOCAL lock_timeout = '2s'")
    op.execute("""
        DO $$
        DECLARE
            legacy_owner text;
            moved record;
        BEGIN
            SELECT tableowner INTO legacy_owner
              FROM pg_tables WHERE schemaname = 'public' AND tablename = 'alembic_version';
            IF legacy_owner IS NULL THEN
                legacy_owner := current_user;
            END IF;
            FOR moved IN
                SELECT schemaname, tablename FROM pg_tables
                 WHERE schemaname IN ('risk_profile', 'risk_calculation', 'catalog')
            LOOP
                EXECUTE format('ALTER TABLE %I.%I SET SCHEMA public', moved.schemaname, moved.tablename);
                EXECUTE format('ALTER TABLE public.%I OWNER TO %I', moved.tablename, legacy_owner);
            END LOOP;
        END
        $$
    """)
    op.execute("SET LOCAL lock_timeout = DEFAULT")

    for schema in SCHEMA_OWNERS:
        op.execute(f"DROP SCHEMA IF EXISTS {schema} RESTRICT")
    # Ровно то право, что было до миграции, и не больше: `CREATE` на схеме public PostgreSQL
    # не выдаёт PUBLIC начиная с 15-й версии, а `upgrade()` отозвал у PUBLIC `ALL`.
    op.execute("GRANT USAGE ON SCHEMA public TO PUBLIC")
