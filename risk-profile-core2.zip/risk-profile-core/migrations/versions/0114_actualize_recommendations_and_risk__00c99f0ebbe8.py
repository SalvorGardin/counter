"""0114_actualize_recommendations_and_risk_factors_from_admin

Revision ID: 00c99f0ebbe8
Revises: 026db461473e
Create Date: 2026-08-04 16:37:33.963246

Перезаливка recommendations и risk_factors из catalog/0114_00c99f0ebbe8_<entity>.csv
(свежие снимки из админки: recommendations v28, risk_factors v206). Остальные
справочники (options, questions, conditions, parameter_scores, instrument_parameters,
systems) не трогаем — контентно совпадают с сидами 0107/0111/0103, сверено построчно.

Дельта против 0113 — только текстовые поля пяти строк, состав строк и ключи не меняются
(recommendations 145 логических строк, risk_factors 300, естественные ключи без дублей —
проверено):
  • recommendations.text — «Отказ от курения» (fr_smoking × RESP), «Режим труда и отдыха»
    (common_group × SKIN и × ONCO) переписаны; «Минимизация стресса» (common_group × SKIN)
    очищен (NULL): в админке поле пустое, переносим как есть.
  • risk_factors.reasoning — «Карнивор: только еда животного происхождения»
    (food / fr_food × GI): был NULL, заполнен.

FK risk_factors -> parameters.code / systems.code (RESTRICT) и recommendations ->
systems.code (RESTRICT) не задеваем: все parameter_code/system_code нового набора
присутствуют в сидах 0096/0103. FK recommendations -> risk_factors снят в 0096 (связь
risk_factors_code+system_code живёт на уровне приложения) — проверено, что все пары
risk_factor_group-рекомендаций нового набора ссылаются на существующие пары
(code, system_code) в новом risk_factors.

Ответы пациентов не затрагиваются: option.value не переименовываются, а
parameter_scores/conditions с текстами рекомендаций и reasoning не матчатся.

downgrade возвращает предыдущие сиды 0113 (recommendations и risk_factors).
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "00c99f0ebbe8"
down_revision: str | None = "026db461473e"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = {
    "recommendations": _CATALOG / "0114_00c99f0ebbe8_recommendations.csv",
    "risk_factors": _CATALOG / "0114_00c99f0ebbe8_risk_factors.csv",
}
_OLD = {
    "recommendations": _CATALOG / "0113_026db461473e_recommendations.csv",
    "risk_factors": _CATALOG / "0113_026db461473e_risk_factors.csv",
}

_INSERT_RECOMMENDATIONS = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors "
    "(parameter_code, code, description, modifiability, param_value, min_param_value, max_param_value, "
    "reasoning, system_code) "
    "VALUES (:parameter_code, :code, :description, :modifiability, :param_value, :min_param_value, "
    ":max_param_value, :reasoning, :system_code)"
)


def _parse_recommendations(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": r["recommendations_group"],
            "risk_factors_code": r["risk_factors_code"] or None,
            "system_code": r["system_code"],
            "name": r["name"],
            "text": r.get("text") or None,
        }
        for r in load_csv(path)
    ]


def _parse_risk_factors(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "description": r["description"],
            "modifiability": r["modifiability"],
            "param_value": r["param_value"] or None,
            "min_param_value": r["min_param_value"] or None,
            "max_param_value": r["max_param_value"] or None,
            "reasoning": r["reasoning"] or None,
            "system_code": r["system_code"] or None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _replace(seeds: dict[str, Path]) -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM recommendations"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM risk_factors"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_RISK_FACTORS), _parse_risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _parse_recommendations(seeds["recommendations"]))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
