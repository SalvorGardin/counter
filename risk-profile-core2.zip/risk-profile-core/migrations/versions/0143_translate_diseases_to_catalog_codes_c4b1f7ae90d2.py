"""0143_translate_diseases_to_catalog_codes

Revision ID: c4b1f7ae90d2
Revises: e50a0aed0495
Create Date: 2026-09-07 14:00:00.000000

`instruments.diseases` и `interpretations.diseases` переводятся с названий заболеваний на
`diseases.code`. Тип колонок (`text[]`) и их роль не меняются — меняется словарь значений.

Колонки переводятся по-разному, потому что различаются их источники.

`instruments.diseases` — разметка «инструмент → группа заболеваний», её ведут сидами. Она
перезаливается из `catalog/0143_c4b1f7ae90d2_instruments.csv`: тот же снимок справочника
инструментов, что и в 0136, но колонка `diseases` заполнена кодами. До этой миграции разметка
кодами не существовала ни в одном файле, и следующая выгрузка справочника из административной
панели вернула бы в колонку названия, а §4.2 молча перестал бы находить группы. Файл делает
разметку кодами версионируемым артефактом, от которого отталкивается следующая выгрузка.

Сид пишется как `INSERT ... ON CONFLICT (code) DO UPDATE SET diseases`. Полная перезаливка
(`DELETE` + `INSERT`) для `instruments` невозможна: на `instruments.code` стоят внешние ключи с
`RESTRICT` из `results`, `results_history`, `calculation_statuses`, `instruments_parameters` и
`systems_instruments`, а первые три — данные пациентов. Обновляется ровно `diseases`: остальные
колонки нужны, чтобы отсутствующая строка вставилась целиком, но затирать ими живые значения
нечем оправдать.

`interpretations.diseases` — результат расчёта, сидов у него нет, поэтому значения переводятся
на месте по сопоставлению «текст → код». Оно строится из справочника `diseases` целиком:
`description → code` для каждой строки плюс тождественный перевод `code → code`. Словарь значений
колонки и есть словарь справочника — её писал расчёт, который разворачивал `results.disease_code`
в `diseases.description`, то есть в колонку могло попасть любое описание справочника.

Названия, которых в справочнике уже нет, перечислены отдельно в `_LEGACY_TEXT_TO_CODE`:

| Текст                     | Код                          |
|---------------------------|------------------------------|
| Хроническая болезнь почек | `renal_failure`              |
| Инфаркт                   | `infarction_ischemic_stroke` |
| Инсульт                   | `infarction_ischemic_stroke` |

«Хроническая болезнь почек» — предшественник «Почечной недостаточности» (URO), «Инфаркт» и
«Инсульт» — вид результата CVD до объединения в одну группу. В живых данных их быть не должно:
0121 переписала обе колонки на текущие названия. Список оставлен страховкой на случай строки,
которую та миграция не застала, — без него такое значение остановило бы перевод.

Откат — обратный перевод по тому же справочнику: `code → description`, `LEFT JOIN` с
`COALESCE(description, value)`, чтобы код, выбывший из справочника между накатом и откатом, остался
в колонке как есть и не потерялся. Он покрывает все строки независимо от времени записи, поэтому
откатывать можно и через часы работы сервиса на переведённой базе: пары, посчитанные уже кодами,
вернутся к названиям вместе с остальными. Снимок исходных значений вместо этого перевода был бы
точен только в момент миграции — строки, записанные после неё, он бы не покрыл, а пересчитанные
вернул бы к устаревшему значению, разошедшемуся с `risk_level` той же строки.

Что откат не восстанавливает: прежние названия из таблицы выше. После 0121 их в живых данных нет,
а её собственный откат сделан так же — обратной заменой по справочнику, без снимка.

Обе колонки меняются одной миграцией: при переведённой одной из них алгоритм §4.2 сравнивал бы
код с названием, не находил совпадений и молча обнулял заболевания по системам вместо ошибки.

`interpretations_history.diseases` не переписывается. Колонка только пишется при архивировании и
не читается ни одним маршрутом сервиса, а история — аудитный след: миграции правят живые данные.
Строки, заархивированные до этой миграции, остаются с названиями (зафиксировано в докстринге
`src/models/interpretation_history.py`).

Значения, уже совпадающие с целевым кодом, проходят через сопоставление без изменений, а сид
идемпотентен по построению — повторный `upgrade` поверх переведённых данных не падает и ничего
не портит.

Порядок выката: миграция и релиз применяются вместе, в одном окне с остановкой сервиса. Откат
приложения на предыдущую версию поверх переведённой базы ошибки не даёт — прежний код сравнивает
коды с маркерами-названиями, не находит совпадений и обнуляет заболевания по системам, а причины
при этом выглядят законными. Поэтому откат приложения выполняется только вместе с откатом этой
миграции.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "c4b1f7ae90d2"
down_revision: str | None = "e50a0aed0495"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_INSTRUMENTS_CSV = Path(__file__).parent.parent.parent / "catalog" / "0143_c4b1f7ae90d2_instruments.csv"

# Названия, переименованные или объединённые до этой миграции. Всё остальное берётся из справочника
# на момент прогона.
_LEGACY_TEXT_TO_CODE: dict[str, str] = {
    "Хроническая болезнь почек": "renal_failure",
    "Инфаркт": "infarction_ischemic_stroke",
    "Инсульт": "infarction_ischemic_stroke",
}

_INSTRUMENTS = "instruments"
_INSTRUMENTS_PK = "instrument_id"
_INTERPRETATIONS = "interpretations"
_INTERPRETATIONS_PK = "interpretation_id"

# Откат возвращает названия в обе колонки: обе переписываются накатом.
_TABLES: dict[str, str] = {
    _INSTRUMENTS: _INSTRUMENTS_PK,
    _INTERPRETATIONS: _INTERPRETATIONS_PK,
}

_INSERT_INSTRUMENTS = (
    "INSERT INTO instruments (code, description, type, status, diseases)"
    " VALUES (:code, :description, :type, :status, :diseases)"
    " ON CONFLICT (code) DO UPDATE SET diseases = EXCLUDED.diseases"
)


# Сопоставление как подзапрос `mapping(source, code)`. Три источника: описание справочника,
# тождественный перевод кода в самого себя (значение уже переведённой строки должно проходить
# перевод без изменений) и названия, выбывшие из справочника. `UNION ALL` может дать одинаковые
# пары дважды — переводу это безразлично, дедупликация идёт по коду.
#
# Выбывшие названия приходят двумя массивами-параметрами, а не списком `VALUES`, собранным из их
# количества: запрос остаётся постоянной строкой, а значения — связанными параметрами.
_MAPPING_SQL = (
    "("
    " SELECT description AS source, code FROM diseases"
    " UNION ALL SELECT code AS source, code FROM diseases"
    " UNION ALL SELECT * FROM unnest(CAST(:legacy_sources AS text[]), CAST(:legacy_codes AS text[]))"
    " AS legacy(source, code)"
    ") AS mapping"
)

# Направления перевода для `_rewrite`: чем элемент массива присоединяется к справочнику и чем
# заменяется. Накат идёт внутренним соединением — непокрытых значений к этому моменту не осталось,
# они останавливают миграцию проверкой. Откат идёт внешним: код, выбывший из справочника уже после
# наката, остаётся в колонке как есть, а не выпадает из массива.
_TO_CODE_JOIN = f"JOIN {_MAPPING_SQL} ON mapping.source = element.value"
_TO_CODE_VALUE = "mapping.code"
_TO_TEXT_JOIN = "LEFT JOIN diseases ON diseases.code = element.value"
_TO_TEXT_VALUE = "COALESCE(diseases.description, element.value)"


def _instruments() -> list[dict]:
    """Строки сида справочника инструментов.

    Колонка в БД — `ARRAY(Text)`, в файле у инструмента не больше одного кода группы или пусто:
    прежняя пара названий одной группы схлопнулась в один код ещё в файле.
    """
    return [
        {
            "code": row["code"],
            "description": row["description"],
            "type": row["type"],
            "status": row["status"],
            "diseases": [row["diseases"]] if row["diseases"] else None,
        }
        for row in load_csv(_INSTRUMENTS_CSV)
        if row["code"]
    ]


def _seed_codes() -> list[str]:
    return sorted({row["diseases"] for row in load_csv(_INSTRUMENTS_CSV) if row["diseases"]})


def _mapping_params() -> dict[str, list[str]]:
    pairs = sorted(_LEGACY_TEXT_TO_CODE.items())
    return {
        "legacy_sources": [source for source, _ in pairs],
        "legacy_codes": [code for _, code in pairs],
    }


def _assert_mapping_is_unambiguous(conn: sa.Connection) -> None:
    """Одно значение — один код.

    Сопоставление собирается из справочника, а он меняется сидами: два заболевания с одинаковым
    описанием или выбывшее название, вернувшееся в справочник за другим кодом, дали бы перевод
    одного значения сразу в два кода. Такой массив молча получил бы лишний элемент.
    """
    ambiguous = (
        conn.execute(
            sa.text(
                f"SELECT source FROM {_MAPPING_SQL}"  # nosec B608 — подзапрос это константа _MAPPING_SQL, значения приходят параметрами
                " GROUP BY source HAVING count(DISTINCT code) > 1 ORDER BY source"
            ),
            _mapping_params(),
        )
        .scalars()
        .all()
    )
    if ambiguous:
        raise RuntimeError(f"0143: значения diseases переводятся сразу в несколько кодов: {sorted(ambiguous)}")


def _assert_every_value_is_covered(conn: sa.Connection) -> None:
    """Падение до первой записи, если в интерпретациях встретилось значение вне сопоставления.

    Молчаливое отбрасывание непокрытого значения потеряло бы заболевание пациента безвозвратно, а
    частичная запись оставила бы колонки в разном словаре.
    """
    uncovered = (
        conn.execute(
            sa.text(
                f"SELECT DISTINCT unnest(diseases) AS value FROM {_INTERPRETATIONS}"  # nosec B608 — имя таблицы из захардкоженной константы, не пользовательский ввод
                f" EXCEPT SELECT source FROM {_MAPPING_SQL}"
            ),
            _mapping_params(),
        )
        .scalars()
        .all()
    )
    if uncovered:
        raise RuntimeError(
            f"0143: значения diseases вне сопоставления «текст → код», перевод не выполнен: {sorted(uncovered)}"
        )


def _assert_target_codes_exist(conn: sa.Connection) -> None:
    """Целевой код обязан быть в справочнике: перевод в несуществующий код — та же потеря.

    Проверяются коды выбывших названий и коды сида инструментов: коды, взятые из справочника
    самим сопоставлением, существуют по построению.
    """
    codes = sorted(set(_LEGACY_TEXT_TO_CODE.values()) | set(_seed_codes()))
    missing = (
        conn.execute(
            sa.text(
                "SELECT code FROM unnest(CAST(:codes AS text[])) AS code WHERE code NOT IN (SELECT code FROM diseases)"
            ),
            {"codes": codes},
        )
        .scalars()
        .all()
    )
    if missing:
        raise RuntimeError(f"0143: целевых кодов нет в справочнике diseases: {sorted(missing)}")


def _count_filled(conn: sa.Connection, table: str) -> int:
    return conn.execute(sa.text(f"SELECT count(*) FROM {table} WHERE diseases IS NOT NULL")).scalar_one()  # nosec B608 — имена таблиц из захардкоженного _TABLES, не пользовательский ввод


def _assert_filled_rows_kept(conn: sa.Connection, table: str, before: int) -> None:
    """Число строк с непустой колонкой обязано совпасть с замером до записи.

    Для интерпретаций это проверка перевода, для инструментов — проверка сида: инструмент,
    размеченный на стенде, но оставшийся без кода в файле, обнулился бы `DO UPDATE`.
    """
    after = _count_filled(conn, table)
    if before != after:
        raise RuntimeError(f"0143: {table}.diseases — строк с заполненной колонкой было {before}, стало {after}")


def _seed(conn: sa.Connection) -> None:
    """Перезаливка разметки `instruments.diseases` кодами из файла справочника."""
    conn.execute(sa.text(_INSERT_INSTRUMENTS), _instruments())


def _rewrite(conn: sa.Connection, table: str, pk: str, join: str, value: str, params: dict) -> None:
    """Поэлементная замена массива с сохранением порядка и дедупликацией по первому вхождению.

    Разбор идёт через `WITH ORDINALITY`, сборка — `array_agg(... ORDER BY ordinality)`:
    `array_agg(DISTINCT ...)` отсортировал бы элементы по значению и молча сменил порядок
    `diseaseRisks` в ответе. Дубли, возникшие от схлопывания прежних парных названий одной группы,
    снимаются по первой позиции замены.
    """
    conn.execute(
        sa.text(
            f"UPDATE {table} AS target SET diseases = rewritten.elements"  # nosec B608 — имена таблиц и направление перевода из захардкоженных констант, значения приходят параметрами
            " FROM ("
            "   SELECT source_row.pk AS pk,"
            "          array_agg(source_row.value ORDER BY source_row.position) AS elements"
            "   FROM ("
            f"     SELECT t.{pk} AS pk, {value} AS value, min(element.ordinality) AS position"
            f"     FROM {table} AS t"
            "      CROSS JOIN LATERAL unnest(t.diseases) WITH ORDINALITY AS element(value, ordinality)"
            f"     {join}"
            "      WHERE t.diseases IS NOT NULL"
            f"     GROUP BY t.{pk}, {value}"
            "   ) AS source_row"
            "   GROUP BY source_row.pk"
            " ) AS rewritten"
            f" WHERE target.{pk} = rewritten.pk"
        ),
        params,
    )


def upgrade() -> None:
    conn = op.get_bind()
    _assert_mapping_is_unambiguous(conn)
    _assert_every_value_is_covered(conn)
    _assert_target_codes_exist(conn)
    filled = {table: _count_filled(conn, table) for table in _TABLES}
    _seed(conn)
    _rewrite(conn, _INTERPRETATIONS, _INTERPRETATIONS_PK, _TO_CODE_JOIN, _TO_CODE_VALUE, _mapping_params())
    for table, before in filled.items():
        _assert_filled_rows_kept(conn, table, before)


def downgrade() -> None:
    """Обратный перевод обеих колонок по справочнику: код заменяется своим описанием."""
    conn = op.get_bind()
    for table, pk in _TABLES.items():
        _rewrite(conn, table, pk, _TO_TEXT_JOIN, _TO_TEXT_VALUE, {})
