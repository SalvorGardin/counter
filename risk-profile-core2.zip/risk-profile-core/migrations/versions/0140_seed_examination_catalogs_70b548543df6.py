"""0140_seed_examination_catalogs

Revision ID: 70b548543df6
Revises: 8f946f2ab42e
Create Date: 2026-09-04 12:00:00.000000

Первое наполнение справочников исследований, созданных пустыми в 0137–0139, по снимку админки:

  * examinations 124 строки — 89 лабораторных и 35 инструментальных исследований, все со
    статусом `active`;
  * disease_examinations 389 — рекомендованные исследования 95 групп заболеваний из 126
    (у остальных исследований в снимке нет). Все строки без ограничения по полу;
  * system_checkup_examinations 128 — состав общего чек-апа 12 систем из 14; чек-апа нет у
    COMMON и REPROD. Полоспецифичны 9 строк, все в ONCO (ПСА и ТРУЗИ предстательной железы —
    мужские, Пап-тест, УЗИ матки и придатков, АМГ, ДНК ВПЧ — женские). Остальные 119 общие.

Три исследования снимка (`Кальций (кровь)`, `Прогестерон`, `СОЭ`) не входят ни в один комплекс
и ни в один чек-ап: справочник заводится целиком, связи появятся отдельным сидом.

Все внешние ключи снимка сверены с целевым состоянием до записи миграции: `disease_code` — с
сидом групп заболеваний 0136, `system_code` — с сидом систем 0121, `examination_code` обеих
таблиц связей — с examinations этого же сида. Нарушений нет. Правило пола снимок соблюдает:
пары «группа/система + исследование» с общей и полоспецифичной строкой одновременно в нём
отсутствуют, то есть `ex_*_gender_scope` из 0138–0139 наполнение пропустит.

Приёмы записи:

  * examinations — INSERT с `ON CONFLICT (code) DO NOTHING`.
  * Таблицы связей — INSERT с `ON CONFLICT DO NOTHING` без указания ключа: уникальность в них
    держит EXCLUDE-ограничение, а арбитром `ON CONFLICT` может быть только уникальный индекс.
    Без указания ключа Postgres пропускает и нарушение EXCLUDE, так что повторный upgrade
    строк не задваивает.

`downgrade` снимает строки по кодам исследований этого снимка: сначала обе таблицы связей,
потом сам справочник — внешние ключи стоят с RESTRICT. Связь, заведённую после этой миграции
на исследование из снимка, downgrade тоже удалит: иначе RESTRICT не дал бы снять родителя.
"""

from collections.abc import Sequence
from pathlib import Path
from uuid import UUID

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "70b548543df6"
down_revision: str | None = "8f946f2ab42e"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_PREFIX = "0140_70b548543df6_"

_EXAMINATIONS = _CATALOG / f"{_PREFIX}examinations.csv"
_DISEASE_EXAMINATIONS = _CATALOG / f"{_PREFIX}disease_examinations.csv"
_CHECKUP_EXAMINATIONS = _CATALOG / f"{_PREFIX}system_checkup_examinations.csv"

_INSERT_EXAMINATIONS = (
    "INSERT INTO examinations (code, name, examination_type, status) "
    "VALUES (:code, :name, :examination_type, :status) ON CONFLICT (code) DO NOTHING"
)
_INSERT_DISEASE_EXAMINATIONS = (
    "INSERT INTO disease_examinations (disease_code, examination_code, gender) "
    "VALUES (:disease_code, :examination_code, :gender) ON CONFLICT DO NOTHING"
)
_INSERT_CHECKUP_EXAMINATIONS = (
    "INSERT INTO system_checkup_examinations (system_code, examination_code, gender) "
    "VALUES (:system_code, :examination_code, :gender) ON CONFLICT DO NOTHING"
)


def _examination_code(value: str) -> UUID:
    """`examinations.code` — UUID.

    asyncpg (под ним идёт `upgrade head` приложения) принимает в такую колонку только `UUID`,
    строку он отвергает — в отличие от синхронного драйвера, которым миграции гоняются в CI.
    """
    return UUID(value)


def _none_if_blank(value: str) -> str | None:
    return value or None


def _examinations() -> list[dict]:
    return [
        {
            "code": _examination_code(r["code"]),
            "name": r["name"],
            "examination_type": r["examination_type"],
            "status": r["status"],
        }
        for r in load_csv(_EXAMINATIONS)
    ]


def _disease_examinations() -> list[dict]:
    return [
        {
            "disease_code": r["disease_code"],
            "examination_code": _examination_code(r["examination_code"]),
            "gender": _none_if_blank(r["gender"]),
        }
        for r in load_csv(_DISEASE_EXAMINATIONS)
    ]


def _checkup_examinations() -> list[dict]:
    return [
        {
            "system_code": r["system_code"],
            "examination_code": _examination_code(r["examination_code"]),
            "gender": _none_if_blank(r["gender"]),
        }
        for r in load_csv(_CHECKUP_EXAMINATIONS)
    ]


def _examination_codes() -> list[UUID]:
    return [_examination_code(r["code"]) for r in load_csv(_EXAMINATIONS)]


def upgrade() -> None:
    conn = op.get_bind()

    # От родителя к зависимым: без строк справочника не встают внешние ключи таблиц связей.
    conn.execute(sa.text(_INSERT_EXAMINATIONS), _examinations())
    conn.execute(sa.text(_INSERT_DISEASE_EXAMINATIONS), _disease_examinations())
    conn.execute(sa.text(_INSERT_CHECKUP_EXAMINATIONS), _checkup_examinations())


def downgrade() -> None:
    conn = op.get_bind()
    codes = {"codes": _examination_codes()}

    # Таблицы связей — раньше справочника: внешние ключи стоят с RESTRICT.
    conn.execute(sa.text("DELETE FROM disease_examinations WHERE examination_code = ANY(:codes)"), codes)
    conn.execute(sa.text("DELETE FROM system_checkup_examinations WHERE examination_code = ANY(:codes)"), codes)
    conn.execute(sa.text("DELETE FROM examinations WHERE code = ANY(:codes)"), codes)
