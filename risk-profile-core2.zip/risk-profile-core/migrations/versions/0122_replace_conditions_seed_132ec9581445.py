"""0122_replace_conditions_seed

Revision ID: 132ec9581445
Revises: c4e81f92d7a3
Create Date: 2026-08-27 13:30:00.000000

Полная перезаливка conditions из catalog/0122_conditions.csv.

Дельта против действующего сида 0115:

  * добавлено условие `sq_0120;family_neuro;Нет;except;;`: вопрос о болезни
    Паркинсона у родственников скрывается, если семейные неврологические заболевания
    не отмечены;
  * добавлено условие `sq_0320;breast_biopsies_count;Нет;except;;`: вопрос о
    результатах биопсии скрывается, если биопсий не было;
  * строки для sq_0740, sq_0750 и sq_0770 продублированы в исходном CSV. Точные
    дубли сохранены, чтобы таблица соответствовала предоставленному снимку. Они не
    меняют семантику: conditions применяются как AND, а повтор одной проверки даёт
    тот же результат.

В CSV 68 строк данных и 65 уникальных полных строк. Все question_code и
parameter_code присутствуют в действующих сидах questions и parameters, поэтому FK
conditions.question_code / conditions.parameter_code не нарушаются.

Ответы пациентов не меняются: options.value не переименовываются и не удаляются,
поэтому ремап patients_parameters.value не нужен. Новые conditions только читают уже
сохранённые значения `Нет`; patients_parameters_history остаётся аудитным следом и
не затрагивается. parameter_scores, risk_factor_triggers и другие справочники также
не требуют согласованного изменения, поскольку значения ответов не меняются.

downgrade возвращает действующий до этой миграции сид conditions 0115.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "132ec9581445"
down_revision: str | None = "c4e81f92d7a3"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW = _CATALOG / "0122_132ec9581445_conditions.csv"
_OLD = _CATALOG / "0115_e76865e52a0b_conditions.csv"

_INSERT_CONDITIONS = (
    "INSERT INTO conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)


def _int_or_none(value: str) -> int | None:
    value = (value or "").strip()
    return int(value) if value else None


def _parse_conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": row["question_code"],
            "parameter_code": row["parameter_code"],
            "value": row["value"] or None,
            "type": row["type"],
            "min_age": _int_or_none(row["min_age"]),
            "max_age": _int_or_none(row["max_age"]),
        }
        for row in load_csv(path)
        if row["question_code"]
    ]


def _replace(seed: Path) -> None:
    conn = op.get_bind()
    # conditions — лист в графе FK: родительские questions и parameters не
    # изменяются, поэтому справочник безопасно перезаливается отдельно.
    conn.execute(sa.text("DELETE FROM conditions"))  # migration-safety: ok full replace
    conn.execute(sa.text(_INSERT_CONDITIONS), _parse_conditions(seed))


def upgrade() -> None:
    _replace(_NEW)


def downgrade() -> None:
    _replace(_OLD)
