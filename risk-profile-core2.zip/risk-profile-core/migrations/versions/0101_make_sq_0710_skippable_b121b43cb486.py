"""0101_make_sq_0710_skippable

Revision ID: b121b43cb486
Revises: 7efea8f085de
Create Date: 2026-07-01 11:58:15.012773

Делает вопрос об уровне креатинина sq_0710 («Укажите ваш уровень креатинина крови
(мкмоль/л)?») пропускаемым: is_skippable=true. Сейчас в каталоге 0096 у него is_skippable=0,
поэтому risk-communication на ответе с is_skipped=true отвечает QuestionNotSkippableError
(src/services/risk_communication/service.py: `if body.is_skipped and not question.is_skippable`).
Анализ крови есть не у всех — вопрос должен быть необязательным.

Точечный идемпотентный UPDATE по одному коду (не перезаливка questions): на questions.code
ссылается conditions с ON DELETE RESTRICT, поэтому полный reseed здесь не нужен и опасен.
Эта миграция чинит уже задеплоенные БД, где 0096 отработал с is_skippable=0.

Синхронно поправлен источник правды catalog/0096_a460718b3b84_questions.csv (sq_0710 → 1),
чтобы свежая установка получала is_skippable=true сразу из 0096, а следующий полный reseed
questions не скопировал 0 из устаревшего CSV.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "b121b43cb486"
down_revision: str | None = "7efea8f085de"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.get_bind().execute(sa.text("UPDATE questions SET is_skippable = true WHERE code = 'sq_0710'"))


def downgrade() -> None:
    op.get_bind().execute(sa.text("UPDATE questions SET is_skippable = false WHERE code = 'sq_0710'"))
