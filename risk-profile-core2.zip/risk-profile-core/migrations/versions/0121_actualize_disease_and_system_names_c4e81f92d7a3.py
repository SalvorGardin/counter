"""0121_actualize_disease_and_system_names_and_risk_factor_catalog

Revision ID: c4e81f92d7a3
Revises: a31c9d7e5b20
Create Date: 2026-08-19 12:00:00.000000

Уточнение наименований заболеваний и систем организма (issue #224) и актуализация
справочника факторов риска по свежему снимку админки.

Дельта против состояния стенда (instruments — сид 0086, systems — 0103,
risk_factor_systems и risk_factor_triggers — сид 0119):

  • instruments.diseases  `ckd_epi`: «Хроническая болезнь почек» → «Почечная недостаточность»
                          `score_2`: {«Инфаркт», «Инсульт»} → {«Инфаркт и ишемический инсульт»}
                          (два отдельных заболевания объединены в одно).
                          Остальные строки снимка совпадают с 0086 построчно.
  • systems.description   `SENSE`: «Зрение и слух» → «Органы чувств».
                          Остальные строки, включая все `rang`, не меняются.
  • interpretations.diseases  ремап уже сохранённых значений под новые наименования.
  • risk_factor_systems   249 → 249 строк. Пар «фактор + система» не добавилось и не убыло,
                          у двух (`fr_diabetes × SENSE`, `fr_food × GI`) из `reasoning`
                          убран концевой пробел. Текст в остальном не менялся.
  • risk_factor_triggers  307 → 320 строк. Удалений нет, `trigger_code` ни у одной
                          существующей строки не переиспользован.
                          +13 условий — средняя градация ответа там, где раньше фактором
                          считалась только крайняя: `fr_nocturia × URO` → `1 раз`,
                          `fr_painful_menses × REPROD` → `Умеренная боль`,
                          `fr_vision_loss_1yr × SENSE` → `Незначительно`,
                          `fr_fever_unexplained × ONCO` → `Да, было однократно`,
                          `Не уверен(а)` у `fr_proteinuria × URO` и `fr_hematuria ×
                          URO/BLOOD`, `Иногда` у `fr_urinary_urgency × URO`,
                          `fr_hearingloss` и `fr_frequentrequesttorepeatspeech × SENSE`,
                          `fr_dryscalyskinchronic`, `fr_pruritusnocause` и
                          `fr_persistentrashlongduration × SKIN`. Все — форма
                          `text` + `eq`, каждое получает суффикс `__02` при том же
                          `__01`, что и раньше.
                          Одна правка порога: `fr_lipoprotein_a__CVD__lipoprotein_a__01`
                          `value_num` 50 → 30 (мг/дл). `trigger_code` сохранён: это то же
                          условие с пересмотренной границей, а не новое, и записи
                          `risk_factor_matches`, снятые по нему раньше, остаются
                          сопоставимыми по коду.

`value_text` новых условий сверены с `options.value` действующего сида 0111 — матчатся
с ответами пациентов строгим строковым равенством. `parameter_code` и `system_code`
новых строк уже присутствуют в справочнике, новых факторов нет — `risk_factors`
миграция не трогает.

Почему ремап `interpretations` обязателен именно здесь: `compute_diseases` (§4.2) матчит
`instruments.diseases` с маркерами групп строгим строковым равенством, и те же строки
попадают в `interpretations.diseases`. Без ремапа прочитанные из БД исторические записи
отдавали бы в `diseaseRisks[]` устаревшие названия рядом с новыми у свежих расчётов.
Маркеры в коде (`src/interpretation/domain/constants.py`) обновлены тем же изменением —
разъехавшись со справочником, они молча отправили бы `ckd_epi`/`score_2` в «прочие» и
через `other_blocks` обнулили `diseases` систем URO и CVD.

`interpretations_history` намеренно не трогаем: миграции правят живые данные, history —
аудитный след того, что было отдано на момент расчёта (решение ревью !154). По той же
причине не трогаем `risk_factor_matches`: сматченные условия сохранены там денормализованно
(FK на `risk_factor_triggers` нет) и описывают расчёт на момент его выполнения.

Приём для `risk_factor_systems` и `risk_factor_triggers` — полная перезаливка каждой
таблицы (DELETE + INSERT), как в 0111/0113/0114/0116: естественные ключи
(`uq_risk_factor_systems_factor_system`, `uq_risk_factor_triggers_condition`) покрывают
почти все колонки, поэтому «обновление на месте» одним UPSERT невыразимо. Обе таблицы —
листья в графе FK: родители (`risk_factors`, `systems`, `parameters`) не трогаются,
ссылок на сами таблицы нет. Уникальность новых наборов по обоим ключам проверена заранее —
дублей нет.

Приём для `instruments` и `systems` — точечный UPDATE по естественному ключу, а не DELETE+INSERT: `instruments.code` и
`systems.code` под FK с ON DELETE RESTRICT из `instruments_parameters`, `systems_instruments`,
`interpretations` и `risk_factors`. Перезаливка `systems` не требует снятия `uq_systems_rang`
(в отличие от 0103): `rang` не меняется ни у одной строки, промежуточного состояния с
дублем нет.

Слияние «Инфаркт» + «Инсульт» в одно значение обратимо детерминированно: единственный
источник этой пары — CVD-группа `DISEASE_RULES`, порядок элементов задан её `output`.
"""

import json
from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "c4e81f92d7a3"
down_revision: str | None = "a31c9d7e5b20"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"

_NEW_INSTRUMENTS = _CATALOG / "0121_c4e81f92d7a3_instruments.csv"
_OLD_INSTRUMENTS = _CATALOG / "0086_cad1a0c0ffee_instruments.csv"
_NEW_SYSTEMS = _CATALOG / "0121_c4e81f92d7a3_systems.csv"
_OLD_SYSTEMS = _CATALOG / "0103_5084fe5bc764_systems.csv"
_NEW_FACTOR_SYSTEMS = _CATALOG / "0121_c4e81f92d7a3_risk_factor_systems.csv"
_OLD_FACTOR_SYSTEMS = _CATALOG / "0119_7f2a9c184b6d_risk_factor_systems.csv"
_NEW_TRIGGERS = _CATALOG / "0121_c4e81f92d7a3_risk_factor_triggers.csv"
_OLD_TRIGGERS = _CATALOG / "0119_7f2a9c184b6d_risk_factor_triggers.csv"

_DISEASE_CKD_OLD = "Хроническая болезнь почек"
_DISEASE_CKD_NEW = "Почечная недостаточность"
_DISEASE_HEART_ATTACK_OLD = "Инфаркт"
_DISEASE_STROKE_OLD = "Инсульт"
_DISEASE_CVD_NEW = "Инфаркт и ишемический инсульт"


def _parse_diseases(raw: str) -> list[str] | None:
    """Колонка `diseases` в снимках админки записана в двух форматах.

    Пусто → NULL; JSON-массив (`["Инфаркт", "Инсульт"]`) — так записан старый сид 0086;
    иначе одиночное название как есть. В БД колонка — ARRAY(Text), так что одиночное
    значение оборачивается в список из одного элемента.
    """
    if not raw:
        return None
    if raw.startswith("["):
        return list(json.loads(raw))
    return [raw]


_UPDATE_INSTRUMENTS = """
    UPDATE instruments
       SET description = :description, type = :type, status = :status, diseases = :diseases
     WHERE code = :code
"""

_UPDATE_SYSTEMS = "UPDATE systems SET description = :description, rang = :rang WHERE code = :code"

_INSERT_FACTOR_SYSTEMS = (
    "INSERT INTO risk_factor_systems (risk_factor_code, system_code, reasoning) "
    "VALUES (:risk_factor_code, :system_code, :reasoning)"
)
_INSERT_TRIGGERS = (
    "INSERT INTO risk_factor_triggers "
    "(trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator, "
    "value_num, min_value, max_value, value_text, gender) "
    "VALUES (:trigger_code, :risk_factor_code, :system_code, :parameter_code, :value_type, :operator, "
    ":value_num, :min_value, :max_value, :value_text, :gender)"
)

# Переименование один-в-один: array_replace меняет элемент на месте, порядок и остальные
# элементы массива сохраняются.
_REMAP_CKD = """
    UPDATE interpretations
       SET diseases = array_replace(diseases, :old, :new)
     WHERE :old = ANY(diseases)
"""

# Слияние и обратное разделение сформулированы через remove+append, а не через подстановку:
# так строка чинится и когда в массиве лежит только одно из двух старых названий, и прочие
# элементы массива не затираются. Порядок «Инфаркт», «Инсульт» при откате задан `output`
# CVD-группы `DISEASE_RULES` — другого источника этой пары нет.
_MERGE_CVD = """
    UPDATE interpretations
       SET diseases = array_remove(array_remove(diseases, :heart_attack), :stroke) || ARRAY[:merged]::text[]
     WHERE diseases && ARRAY[:heart_attack, :stroke]::text[]
"""

_SPLIT_CVD = """
    UPDATE interpretations
       SET diseases = array_remove(diseases, :merged) || ARRAY[:heart_attack, :stroke]::text[]
     WHERE :merged = ANY(diseases)
"""


def _parse_factor_systems(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "reasoning": r["reasoning"] or None,
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _parse_triggers(path: Path) -> list[dict]:
    return [
        {
            "trigger_code": r["trigger_code"],
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "parameter_code": r["parameter_code"],
            "value_type": r["value_type"],
            "operator": r["operator"],
            "value_num": r["value_num"] or None,
            "min_value": r["min_value"] or None,
            "max_value": r["max_value"] or None,
            "value_text": r["value_text"] or None,
            "gender": r["gender"] or None,
        }
        for r in load_csv(path)
        if r["trigger_code"]
    ]


def _replace_risk_factor_catalog(factor_systems_path: Path, triggers_path: Path) -> None:
    conn = op.get_bind()
    # Обе таблицы — листья в графе FK (родители risk_factors/systems/parameters не трогаются,
    # risk_factor_matches хранит условие денормализованно и на триггеры не ссылается),
    # поэтому порядок DELETE/INSERT между ними свободен.
    conn.execute(sa.text("DELETE FROM risk_factor_triggers"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM risk_factor_systems"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_FACTOR_SYSTEMS), _parse_factor_systems(factor_systems_path))
    conn.execute(sa.text(_INSERT_TRIGGERS), _parse_triggers(triggers_path))


def _reseed(instruments_path: Path, systems_path: Path) -> None:
    conn = op.get_bind()
    conn.execute(
        sa.text(_UPDATE_INSTRUMENTS),
        [
            {
                "code": r["code"],
                "description": r["description"],
                "type": r["type"],
                "status": r["status"],
                "diseases": _parse_diseases(r["diseases"]),
            }
            for r in load_csv(instruments_path)
        ],
    )
    conn.execute(
        sa.text(_UPDATE_SYSTEMS),
        [{"code": r["code"], "description": r["description"], "rang": int(r["rang"])} for r in load_csv(systems_path)],
    )


def upgrade() -> None:
    _reseed(_NEW_INSTRUMENTS, _NEW_SYSTEMS)
    _replace_risk_factor_catalog(_NEW_FACTOR_SYSTEMS, _NEW_TRIGGERS)
    conn = op.get_bind()
    conn.execute(sa.text(_REMAP_CKD), {"old": _DISEASE_CKD_OLD, "new": _DISEASE_CKD_NEW})
    conn.execute(
        sa.text(_MERGE_CVD),
        {
            "heart_attack": _DISEASE_HEART_ATTACK_OLD,
            "stroke": _DISEASE_STROKE_OLD,
            "merged": _DISEASE_CVD_NEW,
        },
    )


def downgrade() -> None:
    _reseed(_OLD_INSTRUMENTS, _OLD_SYSTEMS)
    _replace_risk_factor_catalog(_OLD_FACTOR_SYSTEMS, _OLD_TRIGGERS)
    conn = op.get_bind()
    conn.execute(sa.text(_REMAP_CKD), {"old": _DISEASE_CKD_NEW, "new": _DISEASE_CKD_OLD})
    conn.execute(
        sa.text(_SPLIT_CVD),
        {
            "heart_attack": _DISEASE_HEART_ATTACK_OLD,
            "stroke": _DISEASE_STROKE_OLD,
            "merged": _DISEASE_CVD_NEW,
        },
    )
