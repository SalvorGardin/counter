"""0112_remap_answers_to_0111_options

Revision ID: 98fefd2350da
Revises: 06526a399cf8
Create Date: 2026-07-31 10:54:52.000000

Data-only: догоняющий ремап ответов пациентов под переименованные options.value.
Схема НЕ меняется, справочники НЕ перезаливаются — трогаем только
patients_parameters.value. patients_parameters_history НЕ трогаем (в отличие от
0096/0097): решение ревью !154 — миграции правят только живые данные, history остаётся
аудитным следом как есть; расчёты читают только живую таблицу.

ПОЧЕМУ. Перезаливки справочников из админки — 0107_reseed_catalogs_from_admin и
0111_seed_updated_catalogs — переименовали отображаемые options.value, но, в отличие
от 0096/0097, ответы пациентов под них не отремапили. patients_parameters.value хранит
выбранный текст опции строкой (FK на parameters с ON DELETE RESTRICT — это PII, записи
не удаляем и не чистим), поэтому у всех, кто отвечал до деплоя 0107, ответы «повисли»
на старых текстах:
  • BDI — жёсткий отказ расчёта. CalcCatalog.bdi_score_map строится из живого каталога
    как {option.value: score} (src/infra/catalog/calc.py), формула делает bare dict lookup
    _score_map[ответ] (src/calc/domain/formulas/beck_depression.py) → FormulaCalculationError
    на КАЖДЫЙ расчёт BDI пациента со старыми ответами (все 21 bdi-параметр).
  • alcohol — тихая потеря балла и фактора риска. parameter_scores (GI: «Эпизодически /
    Несколько раз в месяц» = 0,5; «Регулярно / 1–2 раза в неделю» = 2) и risk_factors
    (fr_alcohol × GI) в сиде 0111 уже с новыми пробелами вокруг «/», а матчинг — строгое
    строковое равенство (src/services/risk_profile/domain/range_match.py). Ошибки нет, просто
    неверный результат.
  • family_hypercholesterolemia — данные НЕ затронуты: sq_0040 это вопрос типа multi,
    multi-ответы хранятся как «Да»/«Нет» по каждому параметру (src/services/risk_communication/
    service.py), текст опции в БД не попадает. Ремап для него — no-op по построению.

ЧТО РЕМАПИМ. Дельта считается из уже лежащих в репо CSV, новых сидов не заводим:
source — catalog/0097_9086772873a5_options.csv (сид, чьи value лежат в ответах пациентов),
target — catalog/0111_06526a399cf8_options.csv (актуальный справочник). Естественный ключ
опции — parameter_code+code. Получается 47 переименований value (все они произошли на
0097→0107; на 0107→0111 переименований нет, только удаления):
  • 43 опции BDI (bdi2…bdi21) — снята финальная точка, у BDI3_01/BDI11_01 ещё правки формы
    («неудачником (цей)» → «неудачником(цей)», «раздражителен» → «раздражителен(на)»);
  • alcohol — sq_1140_02/03/04, пробелы вокруг «/»;
  • family_hypercholesterolemia — sq_0040_05, текст переписан с числовыми порогами (no-op,
    см. выше).
Проверено на CSV: неоднозначностей
нет (один (parameter_code, old) → ровно один new), цепочек нет (new одного не равен old
другого — значит порядок UPDATE-ов неважен), ни один old/new не равен «Да»/«Нет».
У BDI14_03 / BDI20_03 / BDI20_04 внутри старого текста живёт перенос строки — матч точный
и CSV-driven, так что он совпадает байт-в-байт с тем, что положил в БД тот же load_csv.

ПОЧЕМУ 6 УДАЛЁННЫХ ОПЦИЙ НЕ ТРОГАЕМ. Между 0107 и 0111 из справочника ушли sq_1360_01/02
(Unexplained_Fever), sq_1400_01/02 (Early_Satiety), sq_0010_13 (no_cancer),
sq_0020_03 (hodgkins_lymphoma). Сохранённые ответы по ним осознанно оставляем как есть:
  • sq_1360/sq_1400 — вопросы типа boolean, ответы хранятся как «Да»/«Нет»; строки
    parameter_scores для Unexplained_Fever/Early_Satiety × BLOOD («Да») в сиде 0111
    сохранены, значит старые ответы продолжают корректно скориться. Новый параметр
    fever_unexplained — другой код, коллизий нет.
  • sq_0010_13 (no_cancer) — multi, хранится «Да»/«Нет», к текстам опций не привязан.
  • sq_0020_03 (hodgkins_lymphoma, «Такого диагноза не было») — наследие issue #122
    (cq_060 → hodgkins_lymphoma='none'); обратная реконсиляция старых ответов — за
    аналитикой и в скоуп этого фикса не входит.
Ни один из этих случаев не лечится переименованием value, поэтому миграция про них молчит
намеренно, а не по недосмотру.

GUARD. Перед выполнением проверяем, что ни в одной паре old/new нет «Да»/«Нет» (литералы,
без импорта констант приложения — миграция самодостаточна). Это защита от переиспользования
паттерна на справочнике, где такая пара появится: UPDATE по (parameter_code, «Да») переписал
бы ответы multi/boolean-вопросов, а откатить их уже нечем.

ИДЕМПОТЕНТНОСТЬ. Матч идёт по ТОЧНОМУ старому значению, поэтому повторный прогон не находит
ничего, а ответы, данные после деплоя 0107 (уже с новыми текстами), не задеваются. UPDATE
всегда с WHERE по (parameter_code, value) — массовых апдейтов нет.

date_time / expiration_date НЕ трогаем: это нормализация текста уже данного ответа, а не
новый ответ (прецедент 0096/0097).

ПОСЛЕ ДЕПЛОЯ. Принудительный пересчёт миграция не делает: сломанные BDI-расчёты
самовосстановятся при первом же recalc-событии по пациенту.

downgrade симметричен — обратный ремап (source/target меняются местами), как в 0096/0097.
Хелперы _option_value_renames / _remap_patient_answers перенесены копией из 0096/0097:
миграции самодостаточны и не импортируют друг друга.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "98fefd2350da"
down_revision: str | None = "06526a399cf8"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
# Сид, чьи value лежат в ответах пациентов (последний, после которого ремап делался).
_ANSWERS_OPTIONS = _CATALOG / "0097_9086772873a5_options.csv"
# Актуальный справочник, под который приводим ответы.
_CURRENT_OPTIONS = _CATALOG / "0111_06526a399cf8_options.csv"

# Ответы multi/boolean-вопросов. Литералы, а не импорт из src: миграция обязана оставаться
# самодостаточной, а переименование константы в приложении не должно менять смысл гварда.
_BOOLEAN_ANSWERS = ("Да", "Нет")


def _option_value_renames(source: Path, target: Path) -> list[dict]:
    """Опции, у которых сменился отображаемый value (естественный ключ опции — parameter_code+code).

    Возвращает [{"param", "old", "new"}]: source — сид, чьи value лежат в patients_parameters.value
    как ответы пациентов, target — справочник, под который приводим. Опции, пропавшие в target,
    в результат не попадают (нет new) — см. «почему 6 удалённых не трогаем» в докстринге.
    """

    def by_code(path: Path) -> dict[tuple[str, str], str | None]:
        return {(r["parameter_code"], r["code"]): (r["value"] or None) for r in load_csv(path)}

    src, tgt = by_code(source), by_code(target)
    return [
        {"param": param_code, "old": old_value, "new": new_value}
        for (param_code, code), old_value in src.items()
        if (new_value := tgt.get((param_code, code))) and old_value and old_value != new_value
    ]


def _assert_not_boolean_answers(renames: list[dict]) -> None:
    """Гвард: ни один old/new не равен «Да»/«Нет».

    multi- и boolean-вопросы хранят ответ этими двумя строками, а не текстом опции, поэтому
    UPDATE по (parameter_code, «Да») переписал бы чужие ответы вслепую и необратимо.
    """
    unsafe = [r for r in renames if r["old"] in _BOOLEAN_ANSWERS or r["new"] in _BOOLEAN_ANSWERS]
    assert not unsafe, f"ремап затрагивает ответы multi/boolean-вопросов («Да»/«Нет»): {unsafe}"


def _remap_patient_answers(renames: list[dict]) -> None:
    """SET value=new в patients_parameters для исторических ответов по (parameter_code, old).

    Ответы пациентов — PII с FK ON DELETE RESTRICT, записи не трогаем, а value они хранят выбранной
    строкой опции. Цепочечных/неоднозначных переименований в наборе нет (проверено на CSV и запинено
    тестом), поэтому порядок UPDATE-ов неважен. history не трогаем — см. докстринг миграции.
    """
    if not renames:
        return
    _assert_not_boolean_answers(renames)
    conn = op.get_bind()
    sql = sa.text("UPDATE patients_parameters SET value = :new WHERE parameter_code = :param AND value = :old")
    conn.execute(sql, renames)


def upgrade() -> None:
    _remap_patient_answers(_option_value_renames(_ANSWERS_OPTIONS, _CURRENT_OPTIONS))


def downgrade() -> None:
    _remap_patient_answers(_option_value_renames(_CURRENT_OPTIONS, _ANSWERS_OPTIONS))
