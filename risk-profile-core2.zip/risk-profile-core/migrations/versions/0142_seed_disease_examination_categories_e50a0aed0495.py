"""0142_seed_disease_examination_categories

Revision ID: e50a0aed0495
Revises: e8d2f4fa1305
Create Date: 2026-09-07 12:10:00.000000

Снимок размечает 389 существующих связей: 210 лабораторных анализов как `basic`, 82 как
`extended`, у 97 инструментальных исследований категория отсутствует. Технических ключей в
снимке нет, поэтому строки идентифицируются парой (`disease_code`, `examination_code`).

`upgrade` идемпотентен: повторный вызов записывает в найденные строки те же значения, не меняя
их состав. `downgrade` очищает категорию только у перечисленных в снимке пар.
"""

from collections.abc import Sequence
from pathlib import Path
from uuid import UUID

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "e50a0aed0495"
down_revision: str | None = "e8d2f4fa1305"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_SNAPSHOT = Path(__file__).parent.parent.parent / "catalog" / "0142_e50a0aed0495_disease_examinations.csv"
_UPDATE_CATEGORY = (
    "UPDATE disease_examinations SET category = :category "
    "WHERE disease_code = :disease_code AND examination_code = :examination_code"
)
_CLEAR_CATEGORY = (
    "UPDATE disease_examinations SET category = NULL "
    "WHERE disease_code = :disease_code AND examination_code = :examination_code"
)


def _rows() -> list[dict[str, str | UUID | None]]:
    return [
        {
            "disease_code": row["disease_code"],
            "examination_code": UUID(row["examination_code"]),
            "category": row["category"] or None,
        }
        for row in load_csv(_SNAPSHOT)
    ]


def upgrade() -> None:
    op.get_bind().execute(sa.text(_UPDATE_CATEGORY), _rows())


def downgrade() -> None:
    op.get_bind().execute(sa.text(_CLEAR_CATEGORY), _rows())
