"""0110_reconcile_orphaned_bmi

Revision ID: 0f44c26b435f
Revises: 14493c663c0b
Create Date: 2026-07-22

Разовый бэкфилл к issue #139 (Вопрос 1). `answers-reset?systemCode=URO` (а также TRAUMA)
инвалидирует производный `bmi`, не трогая его источники: по проливке 0104 `bmi` привязан
к form_uro/form_trauma, а `height`/`weight` — только к stop_bang/findrisk/form_common, и
спец-правило доп-сброса антропометрии срабатывает лишь для CVD/ENDO. Вопроса про `bmi`
в анкете не существует (у параметра нет ни одной записи в `options`), а рост и вес остались
актуальными — переспросить нечего, и `bmi` залипал протухшим навсегда. При этом он
`is_required` для stop_bang, findrisk, half_frax, form_cvd, form_endo, airi_ssz, то есть
сброс одной урологии тихо ломал расчёт ССЗ и эндокринологии.

Рантайм-фикс (реконсиляция в `RiskEventService.handle_answers_reset`) чинит только новые
события — эта миграция лечит уже накопленные записи на стенде и в проде. Правила значения,
формата, `expiration_date` и `source` те же, что в рантайме:
  • значение — weight / (height/100)^2, 2 знака, целые без «.0» (зеркалит
    risk_init.domain.bmi.compute_bmi + risk_init.domain.numbers.format_number);
  • `expiration_date` = now() + (parameters.validity_period − epoch), как на пути анкеты (#136);
  • `source` — из заменяемой строки, реконсиляция не меняет происхождение значения.

Схема НЕ меняется. Требования к SQL:
  • `patients_parameters.value` — текст произвольного содержания, поэтому числовой фильтр
    идёт регуляркой ВНУТРИ CASE, и приведение к numeric выполняется только для прошедших
    проверку строк: Postgres не гарантирует порядок вычисления AND-условий, и «голый»
    `value::numeric > 0` рядом с регуляркой мог бы упасть на мусорной строке;
  • округление — в `numeric`, не в `double precision`: `round(numeric, 2)::text` всегда даёт
    два знака после точки, поэтому срезание хвостов `rtrim(rtrim(…, '0'), '.')` безопасно
    (для «25.00» → «25», а не «2», как было бы с текстом без точки);
  • архивация заменяемых строк и сам UPDATE — в ОДНОМ операторе через data-modifying CTE:
    оба шага видят один снапшот и один и тот же набор `orphans`, разъехаться предикатам
    физически негде;
  • идемпотентность обеспечивает сама выборка: после прогона `bmi` актуален и в неё не попадает.

Принятая неточность: Postgres округляет numeric «половину от нуля», Python — «половину
к чётному» на double. На точной середине сотой доли (напр. ИМТ ровно 23.505) результат
миграции может отличаться от `compute_bmi` на 0.01. Клинически незначимо, а при следующей
штатной записи значение всё равно пересчитается рантайм-путём.

Радиус блокировок (почему обход последовательный и почему этого достаточно):
  • `sources` / `orphans` (SELECT) — `ACCESS SHARE` на `patients_parameters`: не конфликтует
    ни с INSERT, ни с UPDATE, ни с SELECT конкурентных писателей;
  • `archived` (INSERT) — `ROW EXCLUSIVE` на `patients_parameters_history`: конфликтует только
    с DDL, а его на этой таблице никто параллельно не делает;
  • `UPDATE` — построчные `FOR UPDATE` ТОЛЬКО на строках `bmi`, попавших в выборку.
Значит конкурентный писатель ждёт, лишь если пишет в ту же самую строку `bmi` того же пациента,
которую чинит бэкфилл, — ровно тот случай, ради которого сериализация и нужна.

Обход последовательный по построению: единственный индекс таблицы — составной уникальный
(patient_id, parameter_code), одноколоночный по `parameter_code` снят миграцией 0087 с
формулировкой «no query filters on parameter_code alone». Предикат по одному лишь
`parameter_code` он обслужить не может, но и добавлять индекс незачем: бэкфилл по определению
идёт по ВСЕМ пациентам, полного прохода тут не избежать никаким индексом. Про объём 0087
говорит прямо: «patients_parameters is small (only patient actions mutate it)».

Батчинг по диапазонам `patient_id` с промежуточными коммитами НЕ заводится: при таком радиусе
блокировок он ничего не выигрывает, зато ломает «всё или ничего» для миграции данных и требует
выхода из транзакции alembic (частично применённый бэкфилл откатить нечем). Единственная
реальная опасность живого сервера — залипнуть в очереди блокировок за медленным запросом; она
снимается `lock_timeout` в `upgrade()`: миграция падает быстро и предсказуемо, а повторный
прогон безопасен благодаря идемпотентности. Если появятся цифры по объёму прода, опровергающие
оценку 0087, батчинг заводится отдельной задачей.

downgrade — no-op: прежние `expiration_date` не восстановимы (их значение было «протухшим»
маркером, а не бизнес-данными), заменённые строки лежат в `patients_parameters_history`.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0f44c26b435f"
down_revision: str | None = "14493c663c0b"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# migration-safety: ok — INSERT в history без ON CONFLICT намеренный: у таблицы нет уникального
# ключа (это журнал), а от повторного прогона защищает предикат выборки orphans.
_RECONCILE_ORPHANED_BMI = sa.text(  # migration-safety: ok
    r"""
    WITH sources AS (
        SELECT
            pp.patient_id,
            max(CASE WHEN pp.parameter_code = 'height' AND pp.value ~ '^[0-9]+(\.[0-9]+)?$'
                     THEN pp.value::numeric END) AS height_cm,
            max(CASE WHEN pp.parameter_code = 'weight' AND pp.value ~ '^[0-9]+(\.[0-9]+)?$'
                     THEN pp.value::numeric END) AS weight_kg
        FROM patients_parameters AS pp
        WHERE pp.parameter_code IN ('height', 'weight')
          AND pp.value IS NOT NULL
          AND pp.expiration_date >= now()
        GROUP BY pp.patient_id
    ),
    orphans AS (
        SELECT bmi.patient_parameter_id, s.height_cm, s.weight_kg
        FROM patients_parameters AS bmi
        JOIN sources AS s ON s.patient_id = bmi.patient_id
        WHERE bmi.parameter_code = 'bmi'
          AND (bmi.value IS NULL OR bmi.expiration_date < now())
          AND s.height_cm > 0
          AND s.weight_kg > 0
    ),
    archived AS (
        INSERT INTO patients_parameters_history
            (parameter_code, patient_id, value, source, expiration_date, date_time)
        SELECT pp.parameter_code, pp.patient_id, pp.value, pp.source, pp.expiration_date, pp.date_time
        FROM patients_parameters AS pp
        JOIN orphans AS o ON o.patient_parameter_id = pp.patient_parameter_id
    )
    UPDATE patients_parameters AS pp
    SET value = rtrim(rtrim(round(o.weight_kg / ((o.height_cm / 100) ^ 2), 2)::text, '0'), '.'),
        expiration_date = now() + (p.validity_period - TIMESTAMPTZ '1970-01-01 00:00:00+00'),
        date_time = now()
    FROM orphans AS o, parameters AS p
    WHERE pp.patient_parameter_id = o.patient_parameter_id
      AND p.code = 'bmi'
    """
)


def upgrade() -> None:
    conn = op.get_bind()
    # Fail-fast вместо парковки деплоя в очереди блокировок: построчные FOR UPDATE ниже могут
    # встать за медленной транзакцией конкурентного писателя той же строки bmi, и без таймаута
    # миграция висела бы неограниченно. Значение — как в 0087, где та же защита и то же
    # обоснование. SET LOCAL живёт до COMMIT, поэтому не протечёт в следующие миграции по этому
    # же соединению. Повторный прогон после срабатывания безопасен: выборка идемпотентна.
    conn.execute(sa.text("SET LOCAL lock_timeout = '2s'"))
    conn.execute(_RECONCILE_ORPHANED_BMI)


def downgrade() -> None:
    # Откат данных невозможен: прежние expiration_date были маркером «протухло», а не бизнес-
    # значением, и восстанавливать состояние, из-за которого расчёты уходили в skip, незачем.
    # Заменённые строки целиком сохранены в patients_parameters_history.
    return
