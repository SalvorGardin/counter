"""0128_create_risk_factor_clinrecs_table

Revision ID: f70d95b3ea41
Revises: c48f3a2079de
Create Date: 2026-08-28 10:50:00.000000

Обоснование балла фактора риска в группе заболеваний клинической рекомендацией. Одна пара
«фактор + группа» может ссылаться на несколько рекомендаций, поэтому уникальный ключ тройной.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "f70d95b3ea41"
down_revision: str | None = "c48f3a2079de"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_INDEXED_COLUMNS = ("risk_factor_code", "disease_code", "clinrec_code")


def upgrade() -> None:
    op.create_table(
        "risk_factor_clinrecs",
        sa.Column("risk_factor_clinrec_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("risk_factor_code", sa.String(), nullable=False),
        sa.Column("disease_code", sa.String(), nullable=False),
        sa.Column("clinrec_code", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["risk_factor_code"],
            ["risk_factors.code"],
            name=op.f("fk_risk_factor_clinrecs_risk_factors_risk_factor_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["disease_code"],
            ["diseases.code"],
            name=op.f("fk_risk_factor_clinrecs_diseases_disease_code"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["clinrec_code"],
            ["clinical_recommendations.code"],
            name=op.f("fk_risk_factor_clinrecs_clinical_recommendations_clinrec_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("risk_factor_clinrec_id", name=op.f("pk_risk_factor_clinrecs")),
        sa.UniqueConstraint(
            "risk_factor_code",
            "disease_code",
            "clinrec_code",
            name=op.f("uq_risk_factor_clinrecs_factor_disease_clinrec"),
        ),
    )
    for column in _INDEXED_COLUMNS:
        op.create_index(op.f(f"ix_risk_factor_clinrecs_{column}"), "risk_factor_clinrecs", [column])


def downgrade() -> None:
    for column in _INDEXED_COLUMNS:
        op.drop_index(op.f(f"ix_risk_factor_clinrecs_{column}"), table_name="risk_factor_clinrecs")
    op.drop_table("risk_factor_clinrecs")
