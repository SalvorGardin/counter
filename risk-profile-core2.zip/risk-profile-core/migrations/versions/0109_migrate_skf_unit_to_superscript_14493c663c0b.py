"""0109_migrate_skf_unit_to_superscript

Revision ID: 14493c663c0b
Revises: b8f1c0a7d2e9
Create Date: 2026-07-21 17:03:16.676189

Приводит единицу измерения инструмента СКФ (instrument_code='ckd_epi') в таблице
текущих результатов `results` к новому формату: 'мл/мин/1.73м^2' -> 'мл/мин/1.73м²'
(надстрочный U+00B2 вместо '^2'). Синхронно с правкой InstrumentsUnits.SKF в коде —
новые записи уже пишутся в новом формате, миграция чинит ранее сохранённые строки.

Историю (`results_history`) НЕ трогаем намеренно: там хранится значение, актуальное на
момент записи. Точечный идемпотентный UPDATE, предикат по старой строке делает повторный
прогон no-op. downgrade — честный обратный UPDATE.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "14493c663c0b"
down_revision: str | None = "b8f1c0a7d2e9"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_NEW_UNIT_SQL = (
    "UPDATE results SET unit = 'мл/мин/1.73м²' WHERE instrument_code = 'ckd_epi' AND unit = 'мл/мин/1.73м^2'"
)
_OLD_UNIT_SQL = (
    "UPDATE results SET unit = 'мл/мин/1.73м^2' WHERE instrument_code = 'ckd_epi' AND unit = 'мл/мин/1.73м²'"
)


def upgrade() -> None:
    op.get_bind().execute(sa.text(_NEW_UNIT_SQL))


def downgrade() -> None:
    op.get_bind().execute(sa.text(_OLD_UNIT_SQL))
