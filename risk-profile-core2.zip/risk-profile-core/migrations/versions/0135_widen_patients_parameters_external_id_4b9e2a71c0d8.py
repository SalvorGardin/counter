"""0135_widen_patients_parameters_external_id

Revision ID: 4b9e2a71c0d8
Revises: 25c3ead721e7
Create Date: 2026-08-31 14:05:00.000000

`external_id` хранит идентификатор экземпляра результата в системе-источнике, а контракт топика
`emr-biomarkers` разрешает ему длину до 10 цифр. `integer` вмещает только до 2 147 483 647, то есть
валидное по контракту сообщение падало бы на вставке. Сузить чужой идентификатор нельзя —
отбраковка валидных данных хуже расширения колонки, поэтому она становится `bigint`.

`ALTER COLUMN TYPE` с `integer` на `bigint` переписывает таблицу целиком под ACCESS EXCLUSIVE —
пустота колонки этого не отменяет. Делается именно сейчас: колонка пуста по всей таблице (её не
заполняет ни один существующий путь записи параметров), и та же операция после накопления
биомаркерных строк обошлась бы дороже.

Перед DDL выставляется `lock_timeout`. Он ограничивает ожидание в очереди блокировок, а не саму
перезапись: `ALTER` запрашивает ACCESS EXCLUSIVE, и без таймаута, встав за долгой транзакцией
читателя, он висел бы неограниченно, копя за собой очередь из всех остальных обращений к таблице.
С таймаутом миграция падает быстро и предсказуемо, а повторный прогон безопасен — DDL
транзакционен, частично применённой схемы не остаётся. Длительность самой перезаписи таймаутом
не ограничивается, она пропорциональна объёму таблицы, поэтому миграция применяется в окно низкой
нагрузки; на `patients_parameters_history`, которая растёт с каждым изменением параметра, время
удержания блокировки заметно больше, чем на самой `patients_parameters`.

`lock_timeout` возвращается к `DEFAULT` сразу после DDL: alembic здесь гоняет весь прогон одной
транзакцией (`migrations/env.py`, `context.begin_transaction()` вокруг `run_migrations()`), и без
возврата `SET LOCAL` действовал бы до конца прогона — на всех следующих миграциях, которым этот
таймаут не предназначен.

`downgrade` сужает колонку обратно и предварительно проверяет, что сохранённые значения
укладываются в `integer`: молча обрезать идентификатор чужой системы нельзя.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "4b9e2a71c0d8"
down_revision: str | None = "25c3ead721e7"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLES = ("patients_parameters", "patients_parameters_history")

# Границы integer: значение вне них при сужении колонки не сохранить.
_INT32_MIN = -2147483648
_INT32_MAX = 2147483647

# Запросы проверки заведены литералами на таблицу, а не собираются подстановкой имени: SQL,
# построенный форматированием строки, ловится SAST'ом независимо от того, откуда взято имя.
_OUT_OF_RANGE_COUNTS = {
    "patients_parameters": sa.text(
        "SELECT count(*) FROM patients_parameters"
        " WHERE external_id IS NOT NULL AND (external_id < :low OR external_id > :high)"
    ),
    "patients_parameters_history": sa.text(
        "SELECT count(*) FROM patients_parameters_history"
        " WHERE external_id IS NOT NULL AND (external_id < :low OR external_id > :high)"
    ),
}


def upgrade() -> None:
    conn = op.get_bind()
    # Fail-fast вместо парковки деплоя в очереди блокировок; после DDL таймаут снимается, чтобы
    # не распространяться на остальные миграции прогона (обоснование обоих шагов — в докстринге).
    conn.execute(sa.text("SET LOCAL lock_timeout = '2s'"))
    for table in _TABLES:
        op.alter_column(
            table,
            "external_id",
            existing_type=sa.Integer(),
            type_=sa.BigInteger(),
            existing_nullable=True,
        )
    conn.execute(sa.text("SET LOCAL lock_timeout = DEFAULT"))


def downgrade() -> None:
    conn = op.get_bind()
    for table, statement in _OUT_OF_RANGE_COUNTS.items():
        out_of_range = conn.execute(statement, {"low": _INT32_MIN, "high": _INT32_MAX}).scalar_one()
        if out_of_range:
            raise RuntimeError(
                f"{table}: {out_of_range} row(s) have external_id outside the integer range; "
                "resolve them before narrowing the column back to integer"
            )
    # Таймаут ставится после проверок: под ним должен быть только DDL, иначе миграция падала бы
    # на ожидании в SELECT'ах выше, не дойдя до операции, ради которой он и нужен.
    conn.execute(sa.text("SET LOCAL lock_timeout = '2s'"))
    for table in _TABLES:
        op.alter_column(
            table,
            "external_id",
            existing_type=sa.BigInteger(),
            type_=sa.Integer(),
            existing_nullable=True,
        )
    conn.execute(sa.text("SET LOCAL lock_timeout = DEFAULT"))
