"""0145_reseed_catalogs_from_admin

Revision ID: 15c247ec61bb
Revises: 6a1f3c8d9e20
Create Date: 2026-09-11 00:00:00.000000

Перезаливка четырнадцати справочников из выгрузки админки. Файлы лежат в
`catalog/0145_15c247ec61bb_<таблица>.csv`, и каждая таблица приводится к своему файлу целиком:
строки по дельте не отбираются, после наката содержимое таблицы равно файлу. Следующая выгрузка
сводится к замене файлов.

Дельта против состояния до наката (справка для ревью, источником записи не служит):

  * questions        207 → 202: −5 выведенных вопросов (`sq_1100`, `sq_1270`, `sq_1290`,
                     `sq_1440`, `sq_1450`), 19 правок текста.
  * options          636 → 624: −13 вариантов выведенных вопросов и `sq_0380_03` («Нет»);
                     +2 варианта «Затрудняюсь ответить» (`sq_1230_03`, `sq_1250_03`); 25 вариантов
                     сменили текст — 22 у вопросов типа select, 3 у multi.
  * parameters       +3 параметра липопротеина(а) по единицам (`lipoprotein_a_mg_l`,
                     `lipoprotein_a_nmol`, `lipoprotein_a_gl`); 5 параметров выведенных вопросов
                     переводятся в `inactive`; 12 правок описаний. Двенадцать `sports_*` в файле нет —
                     они неактивны с 0096 и такими остаются.
  * parameter_scores 348 → 340: правила переведены на новые тексты вариантов, сняты баллы выведенных
                     вопросов и ответов «не знаю» у `changing_moles`, `hematuria`, `proteinuria`,
                     `neck_circumference`, баллы липопротеина(а) заведены на параметры по единицам.
  * conditions        68 → 72: +10 условий возраста 110–120, −3 условия возраста 35–85
                     (`sq_0290`, `sq_0300`, `sq_0330`), −3 повтора строк `except` у `sq_0740`,
                     `sq_0750`, `sq_0770` — повторы лежали в сиде 0122 и на поведение не влияли.
  * risk_factors     203 → 197: −6 факторов (`fr_double_vision`, `fr_elevated_lipoprotein_a`,
                     `fr_ent_visit_last_year`, `fr_eye_visit_12m`, `fr_face_numbness`,
                     `fr_physical_activity_stage`).
  * risk_factor_systems 272 → 265: −7 пар снятых факторов.
  * risk_factor_triggers 355 → 350: −12 условий снятых факторов, +7 условий `fr_lipoprotein_a × CVD`
                     (4 по параметрам-биомаркерам, 3 по параметрам по единицам), 21 правка
                     `value_text` под новые тексты вариантов.
  * risk_factor_scores и risk_factor_clinrecs: строка `fr_elevated_lipoprotein_a × dyslipidemia`
                     заменена на `fr_lipoprotein_a × dyslipidemia`.
  * recommendations  158 → 156: −2 рекомендации `fr_physical_activity_stage` (ENDO, URO), 22 правки.
  * instruments_parameters 504 → 501: −6 параметров выведенных вопросов у `form_endo`, `form_neuro`,
                     `form_sense`, `form_uro`; +3 параметра липопротеина(а) по единицам у `form_cvd`,
                     все необязательные; `form_cvd × total_cholesterol` перестаёт быть обязательным.
  * biomarker_parameter_mappings 27 → 44: разметка липопротеина(а) в мг/л, нмоль/л и г/л переведена
                     с `lipoprotein_a` на параметры по единицам; +10 `hematuria`, +3 `antitgab`,
                     +2 `proteinuria`, +1 `glucose_elevated_history`, +1 `elevated_psa`.
  * instruments      24 → 24, без изменений: файл совпадает с сидом 0143.

Липопротеин(а). До наката все четыре единицы писались в `lipoprotein_a` без пересчёта. Теперь
в него пишется только мг/дл, а мг/л, нмоль/л и г/л — в отдельные параметры, которые не читает ни одна
формула. Смешение единиц прекращается ценой сужения покрытия `airi_ssz` до выгрузок в мг/дл.

Приёмы записи:

  * parameters и instruments — `INSERT ... ON CONFLICT (code) DO UPDATE` всех колонок файла, коды
    вне файла переводятся в `status='inactive'`. Удалять эти строки нельзя: на `parameters.code`
    ссылаются `patients_parameters` и её история, на `instruments.code` — `results`,
    `results_history` и `calculation_statuses`, все с RESTRICT.
  * Остальные двенадцать таблиц — `DELETE` + `INSERT`, как в 0111 и 0136: естественные ключи
    покрывают почти все колонки, и обновление на месте одним запросом невыразимо. `DELETE` идёт
    от зависимых таблиц к родительским, `INSERT` — в обратном порядке: `biomarker_parameter_mappings`
    ссылается на `options`, `options` и `conditions` — на `questions`, пять таблиц — на
    `risk_factors`. `risk_factor_matches` внешнего ключа на справочник не имеет и не трогается.
  * Текст пишется как есть. Неразрывные пробелы внутри вариантов ответа сохраняются: по тексту
    варианта строится `bdi_score_map`, и потеря символа уронила бы расчёт шкалы Бека.

Ответы пациентов. `patients_parameters.value` у select-вопросов хранит текст выбранного варианта,
поэтому 20 пар `(parameter_code, старый текст) → новый текст` ремапятся в этой же миграции. Карта
выписана литералом, чтобы миграция не менялась при последующих правках файлов. Переименования
multi-вопросов в карту не входят: там хранится «Да»/«Нет». `patients_parameters_history` не трогаем —
это аудитный след (решение ревью !154).

Ответы на выведенные вопросы и `sq_0380_03` («Нет») остаются в базе и перестают читаться: параметры
не удаляются, а сохранённое «Нет» не ремапится никогда.

Интерпретации. Биомаркерный фактор `fr_elevated_lipoprotein_a` объединяется с уже существующим
`fr_lipoprotein_a`: на него переводятся триггеры, балл заболевания и клиническая рекомендация.
Тот же код заменяется в живом `interpretations.risk_factors_code`; если в массиве уже были оба
фактора, старый удаляется без дубля и с сохранением позиции существующего `fr_lipoprotein_a`.
`interpretations_history` и `risk_factor_matches` не трогаются: это аудитный след расчёта.

downgrade перезаливает справочники тем же приёмом из предыдущих сидов целиком: опросник — из 0111,
`conditions` — из 0122, `parameters`, факторы риска со связями, рекомендации,
`instruments_parameters` и разметка биомаркеров — из 0136, `instruments` — из 0143. Файлы 0136
`parameters` и `risk_factors` полные: в них лежат и строки прежних сидов 0096 и 0119. Коды вне
файла 0136 — это двенадцать `sports_*`, неактивных с 0096, и три параметра, заведённые накатом;
откат переводит их в `inactive`. Ремап разворачивается обратной
картой без пары `fever_unexplained`: её новый текст «Нет», и в откате он стал бы старым значением,
а пары со старым «Да»/«Нет» не ремапятся — такие ответы после отката остаются «Нет».
Слияние кодов фактора липопротеина(а) не разворачивается: старый справочник содержит
`fr_lipoprotein_a`, а отличить его исходное вхождение от заменённого после слияния нельзя.
"""

from collections.abc import Sequence
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "15c247ec61bb"
down_revision: str | None = "6a1f3c8d9e20"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_PREFIX = "0145_15c247ec61bb_"

_NEW = {
    "parameters": _CATALOG / f"{_PREFIX}parameters.csv",
    "instruments": _CATALOG / f"{_PREFIX}instruments.csv",
    "questions": _CATALOG / f"{_PREFIX}questions.csv",
    "options": _CATALOG / f"{_PREFIX}options.csv",
    "conditions": _CATALOG / f"{_PREFIX}conditions.csv",
    "parameter_scores": _CATALOG / f"{_PREFIX}parameters_score.csv",
    "risk_factors": _CATALOG / f"{_PREFIX}risk_factors.csv",
    "risk_factor_systems": _CATALOG / f"{_PREFIX}risk_factor_systems.csv",
    "risk_factor_triggers": _CATALOG / f"{_PREFIX}risk_factor_triggers.csv",
    "risk_factor_scores": _CATALOG / f"{_PREFIX}risk_factor_scores.csv",
    "risk_factor_clinrecs": _CATALOG / f"{_PREFIX}risk_factor_clinrecs.csv",
    "recommendations": _CATALOG / f"{_PREFIX}recommendations.csv",
    "instruments_parameters": _CATALOG / f"{_PREFIX}instrument_parameters.csv",
    "biomarker_parameter_mappings": _CATALOG / f"{_PREFIX}biomarker_parameter_mappings.csv",
}
_OLD = {
    "parameters": _CATALOG / "0136_f2a806c31d94_parameters.csv",
    "instruments": _CATALOG / "0143_c4b1f7ae90d2_instruments.csv",
    "questions": _CATALOG / "0111_06526a399cf8_questions.csv",
    "options": _CATALOG / "0111_06526a399cf8_options.csv",
    "conditions": _CATALOG / "0122_132ec9581445_conditions.csv",
    "parameter_scores": _CATALOG / "0111_06526a399cf8_parameters_score.csv",
    "risk_factors": _CATALOG / "0136_f2a806c31d94_risk_factors.csv",
    "risk_factor_systems": _CATALOG / "0136_f2a806c31d94_risk_factor_systems.csv",
    "risk_factor_triggers": _CATALOG / "0136_f2a806c31d94_risk_factor_triggers.csv",
    "risk_factor_scores": _CATALOG / "0136_f2a806c31d94_risk_factor_scores.csv",
    "risk_factor_clinrecs": _CATALOG / "0136_f2a806c31d94_risk_factor_clinrecs.csv",
    "recommendations": _CATALOG / "0136_f2a806c31d94_recommendations.csv",
    "instruments_parameters": _CATALOG / "0136_f2a806c31d94_instrument_parameters.csv",
    "biomarker_parameter_mappings": _CATALOG / "0136_f2a806c31d94_biomarker_parameter_mappings.csv",
}

# Переименования вариантов select-вопросов: (parameter_code, текст до наката, текст после).
# `menopause_onset` пишут два вопроса (`sq_0370`, `sq_0380`) одинаковыми текстами — пара одна.
_ANSWER_RENAMES: tuple[tuple[str, str, str], ...] = (
    ("menopause_onset", "Да, менопауза наступила до 45 лет", "Менопауза наступила до 45 лет"),
    ("menopause_onset", "Да, менопауза наступила после 45 лет", "Менопауза наступила после 45 лет"),
    ("dysuria", "Иногда", "Иногда: 1 эпизод за последние 6 месяцев"),
    ("dysuria", "Часто", "Часто: 2 и более эпизодов за 6 месяцев или 3 и более за год"),
    (
        "urinary_urgency",
        "Иногда",
        "Иногда: реже 1 раза в неделю, при этом удается дойти до туалета без подтекания мочи",
    ),
    ("urinary_urgency", "Часто", "Часто: 1 раз в неделю или чаще с эпизодами недержания"),
    ("proteinuria", "Не уверен(а)", "Затрудняюсь ответить"),
    ("hematuria", "Не уверен(а)", "Затрудняюсь ответить"),
    (
        "infection_frequency",
        "Часто",
        "Часто: 2 и более случаев приёма антибиотиков за год, 2 и более пневмоний за 3 года, "
        "2 и более серьёзных синуситов за год",
    ),
    ("eye_strain_screen_work", "Иногда", "Иногда: около 1 раза в неделю, обычно после 2 часов без перерыва"),
    ("eye_strain_screen_work", "Часто", "Часто: 2-3 раза в неделю или практически ежедневно"),
    ("dry_scaly_skin_chronic", "Иногда", "Иногда: не каждый день и меньше 6 недель в сумме за год"),
    (
        "dry_scaly_skin_chronic",
        "Постоянно",
        "Постоянно: почти каждый день в течение 6 недель и дольше в сумме за год",
    ),
    ("pruritus_no_cause", "Иногда", "Иногда: не каждый день и меньше 6 недель в сумме за год"),
    ("pruritus_no_cause", "Часто", "Часто: почти каждый день в течение 6 недель и дольше в сумме за год"),
    ("persistent_rash_long_duration", "Иногда", "Иногда: проходят самостоятельно за 1-2 недели, появляются редко"),
    (
        "persistent_rash_long_duration",
        "Часто",
        "Часто: держатся дольше 2-4 недель или появляются несколько раз в год",
    ),
    ("frequent_sunburn", "Иногда", "Иногда: 1 солнечный ожог за сезон"),
    (
        "frequent_sunburn",
        "Часто",
        "Часто: 2 и более солнечных ожогов за сезон или ожог после пребывания на солнце меньше 30 минут",
    ),
    ("fever_unexplained", "Нет, не замечал(а)", "Нет"),
)

# Ответы multi- и boolean-вопросов. Литералы, а не импорт из src: миграция самодостаточна.
_BOOLEAN_ANSWERS = ("Да", "Нет")

_UPSERT_PARAMETERS = (
    "INSERT INTO parameters (code, description, status, validity_period) "
    "VALUES (:code, :description, :status, :validity_period) "
    "ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description, status = EXCLUDED.status, "
    "validity_period = EXCLUDED.validity_period"
)
_DEACTIVATE_PARAMETERS = "UPDATE parameters SET status = 'inactive' WHERE NOT (code = ANY(:codes))"
_UPSERT_INSTRUMENTS = (
    "INSERT INTO instruments (code, description, type, status, diseases) "
    "VALUES (:code, :description, :type, :status, :diseases) "
    "ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description, type = EXCLUDED.type, "
    "status = EXCLUDED.status, diseases = EXCLUDED.diseases"
)
_DEACTIVATE_INSTRUMENTS = "UPDATE instruments SET status = 'inactive' WHERE NOT (code = ANY(:codes))"

# Таблицы перечислены готовыми запросами, а не именами в цикле: имя таблицы, подставленное в строку
# запроса, читается статическим анализом как конструирование SQL. Порядок — от зависимых
# к родительским.
_DELETE_CATALOGS = (
    "DELETE FROM biomarker_parameter_mappings",  # migration-safety: ok full replace
    "DELETE FROM instruments_parameters",  # migration-safety: ok full replace
    "DELETE FROM recommendations",  # migration-safety: ok full replace
    "DELETE FROM risk_factor_clinrecs",  # migration-safety: ok full replace
    "DELETE FROM risk_factor_scores",  # migration-safety: ok full replace
    "DELETE FROM risk_factor_triggers",  # migration-safety: ok full replace
    "DELETE FROM risk_factor_systems",  # migration-safety: ok full replace
    "DELETE FROM risk_factors",  # migration-safety: ok full replace
    "DELETE FROM parameter_scores",  # migration-safety: ok full replace
    "DELETE FROM conditions",  # migration-safety: ok full replace
    "DELETE FROM options",  # migration-safety: ok full replace
    "DELETE FROM questions",  # migration-safety: ok full replace
)

_INSERT_QUESTIONS = (
    "INSERT INTO questions (code, question, type, is_skippable, group_code) "
    "VALUES (:code, :question, :type, :is_skippable, :group_code)"
)
_INSERT_OPTIONS = (
    "INSERT INTO options (code, value, question_code, parameter_code) "
    "VALUES (:code, :value, :question_code, :parameter_code)"
)
_INSERT_CONDITIONS = (
    "INSERT INTO conditions (question_code, parameter_code, value, type, min_age, max_age) "
    "VALUES (:question_code, :parameter_code, :value, :type, :min_age, :max_age)"
)
_INSERT_PARAMETER_SCORES = (
    "INSERT INTO parameter_scores (parameter_code, value, min_value, max_value, system_code, score) "
    "VALUES (:parameter_code, :value, :min_value, :max_value, :system_code, :score)"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors (code, description, modifiability) VALUES (:code, :description, :modifiability)"
)
_INSERT_FACTOR_SYSTEMS = (
    "INSERT INTO risk_factor_systems (risk_factor_code, system_code, reasoning) "
    "VALUES (:risk_factor_code, :system_code, :reasoning)"
)
_INSERT_TRIGGERS = (
    "INSERT INTO risk_factor_triggers "
    "(trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator, "
    "value_num, min_value, max_value, value_text, gender) "
    "VALUES (:trigger_code, :risk_factor_code, :system_code, :parameter_code, :value_type, :operator, "
    ":value_num, :min_value, :max_value, :value_text, :gender)"
)
_INSERT_SCORES = (
    "INSERT INTO risk_factor_scores (risk_factor_code, disease_code, score, influence) "
    "VALUES (:risk_factor_code, :disease_code, :score, :influence)"
)
_INSERT_FACTOR_CLINRECS = (
    "INSERT INTO risk_factor_clinrecs (risk_factor_code, disease_code, clinrec_code) "
    "VALUES (:risk_factor_code, :disease_code, :clinrec_code)"
)
_INSERT_RECOMMENDATIONS = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)
_INSERT_INSTRUMENT_PARAMS = (
    "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)
_INSERT_MAPPINGS = (
    "INSERT INTO biomarker_parameter_mappings "
    "(biomarker_parameter_code, parameter_code, mapping_type, operator, value_num, value_text, option_code, unit) "
    "VALUES (:biomarker_parameter_code, :parameter_code, :mapping_type, :operator, :value_num, :value_text, "
    ":option_code, :unit)"
)
_REMAP_ANSWERS = "UPDATE patients_parameters SET value = :new WHERE parameter_code = :param AND value = :old"

_OLD_LIPOPROTEIN_RISK_FACTOR_CODE = "fr_elevated_lipoprotein_a"
_NEW_LIPOPROTEIN_RISK_FACTOR_CODE = "fr_lipoprotein_a"
_LIPOPROTEIN_RISK_FACTOR_SYSTEM_CODE = "CVD"

# Старый биомаркерный фактор объединяется с уже существующим фактором. Если новый код уже есть
# в массиве, удаляем только старый; иначе заменяем его на месте. Так порядок прочих факторов
# сохраняется, а `risk_factors_code` не получает дубль.
_MERGE_LIPOPROTEIN_RISK_FACTOR = """
    UPDATE interpretations
       SET risk_factors_code = CASE
               WHEN :new = ANY(risk_factors_code) THEN array_remove(risk_factors_code, :old)
               ELSE array_replace(risk_factors_code, :old, :new)
           END
     WHERE system_code = :system_code
       AND :old = ANY(risk_factors_code)
"""


def _none_if_blank(value: str) -> str | None:
    return value or None


def _decimal_or_none(value: str) -> Decimal | None:
    """Числовые колонки справочников — `Numeric`.

    asyncpg (под ним идёт `upgrade head` приложения) принимает в такую колонку только `Decimal`.
    В старых сидах десятичный разделитель — запятая («0,5»).
    """
    value = value.replace(",", ".").rstrip("+")
    return Decimal(value) if value else None


def _int_or_none(value: str) -> int | None:
    return int(value) if value else None


def _parameters(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "status": r["status"],
            # TIMESTAMP asyncpg принимает только datetime.
            "validity_period": datetime.fromisoformat(r["validity_period"]),
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _instruments(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "type": r["type"],
            "status": r["status"],
            # Колонка в БД — ARRAY(Text); в файле одиночный код группы заболеваний или пусто.
            "diseases": [r["diseases"]] if r["diseases"] else None,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _questions(path: Path) -> list[dict]:
    # Колонки `category` в схеме нет с 0092, файл выгрузки её содержит — не читаем.
    return [
        {
            "code": r["code"],
            "question": r["question"],
            "type": r["type"],
            "is_skippable": r["is_skippable"] == "1",
            "group_code": int(r["group_code"]) if r["group_code"] else 0,
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _options(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "value": _none_if_blank(r["value"]),
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
        }
        for r in load_csv(path)
        if r["code"]
    ]


def _conditions(path: Path) -> list[dict]:
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "value": _none_if_blank(r["value"]),
            "type": r["type"],
            "min_age": _int_or_none(r["min_age"]),
            "max_age": _int_or_none(r["max_age"]),
        }
        for r in load_csv(path)
        if r["question_code"]
    ]


def _parameter_scores(path: Path) -> list[dict]:
    return [
        {
            "parameter_code": r["parameter_code"],
            # Текст ответа, не число: запятая в нём — часть текста.
            "value": _none_if_blank(r["value"]),
            "min_value": _decimal_or_none(r["min_value"]),
            "max_value": _decimal_or_none(r["max_value"]),
            "system_code": r["system_code"],
            "score": _decimal_or_none(r["score"]),
        }
        for r in load_csv(path)
        if r["parameter_code"]
    ]


def _risk_factors(path: Path) -> list[dict]:
    return [
        {"code": r["code"], "description": r["description"], "modifiability": r["modifiability"]}
        for r in load_csv(path)
        if r["code"]
    ]


def _factor_systems(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "reasoning": _none_if_blank(r["reasoning"]),
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _triggers(path: Path) -> list[dict]:
    return [
        {
            "trigger_code": r["trigger_code"],
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "parameter_code": r["parameter_code"],
            "value_type": r["value_type"],
            "operator": r["operator"],
            "value_num": _decimal_or_none(r["value_num"]),
            "min_value": _decimal_or_none(r["min_value"]),
            "max_value": _decimal_or_none(r["max_value"]),
            "value_text": _none_if_blank(r["value_text"]),
            "gender": _none_if_blank(r["gender"]),
        }
        for r in load_csv(path)
        if r["trigger_code"]
    ]


def _scores(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "score": int(r["score"]),
            "influence": r["influence"],
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _factor_clinrecs(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "clinrec_code": r["clinrec_code"],
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _recommendations(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": _none_if_blank(r["recommendations_group"]),
            "risk_factors_code": _none_if_blank(r["risk_factors_code"]),
            "system_code": r["system_code"],
            "name": r["name"],
            "text": _none_if_blank(r["text"]),
        }
        for r in load_csv(path)
        if r["system_code"]
    ]


def _instrument_parameters(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
        if r["instrument_code"]
    ]


def _mappings(path: Path) -> list[dict]:
    return [
        {
            "biomarker_parameter_code": r["biomarker_parameter_code"],
            "parameter_code": r["parameter_code"],
            "mapping_type": r["mapping_type"],
            "operator": _none_if_blank(r["operator"]),
            "value_num": _decimal_or_none(r["value_num"]),
            "value_text": _none_if_blank(r["value_text"]),
            "option_code": _none_if_blank(r["option_code"]),
            "unit": _none_if_blank(r["unit"]),
        }
        for r in load_csv(path)
        if r["biomarker_parameter_code"]
    ]


def _upsert_parents(conn: sa.Connection, seeds: dict[str, Path]) -> None:
    """Параметры и инструменты: запись каждой строки файла, коды вне файла — в `inactive`.

    Строки не удаляются: на коды обеих таблиц ссылаются данные пациентов с RESTRICT.
    """
    parameters = _parameters(seeds["parameters"])
    conn.execute(sa.text(_UPSERT_PARAMETERS), parameters)
    conn.execute(sa.text(_DEACTIVATE_PARAMETERS), {"codes": [r["code"] for r in parameters]})

    instruments = _instruments(seeds["instruments"])
    conn.execute(sa.text(_UPSERT_INSTRUMENTS), instruments)
    conn.execute(sa.text(_DEACTIVATE_INSTRUMENTS), {"codes": [r["code"] for r in instruments]})


def _replace_catalogs(conn: sa.Connection, seeds: dict[str, Path]) -> None:
    """Перезаливка двенадцати таблиц: удаление от зависимых к родительским, вставка — обратно."""
    for statement in _DELETE_CATALOGS:
        conn.execute(sa.text(statement))

    conn.execute(sa.text(_INSERT_QUESTIONS), _questions(seeds["questions"]))
    conn.execute(sa.text(_INSERT_OPTIONS), _options(seeds["options"]))
    conn.execute(sa.text(_INSERT_CONDITIONS), _conditions(seeds["conditions"]))
    conn.execute(sa.text(_INSERT_PARAMETER_SCORES), _parameter_scores(seeds["parameter_scores"]))
    conn.execute(sa.text(_INSERT_RISK_FACTORS), _risk_factors(seeds["risk_factors"]))
    conn.execute(sa.text(_INSERT_FACTOR_SYSTEMS), _factor_systems(seeds["risk_factor_systems"]))
    # Порядок строк файла сохраняется: `trigger_id` раздаётся по нему и служит тай-брейком при
    # равных баллах.
    conn.execute(sa.text(_INSERT_TRIGGERS), _triggers(seeds["risk_factor_triggers"]))
    conn.execute(sa.text(_INSERT_SCORES), _scores(seeds["risk_factor_scores"]))
    conn.execute(sa.text(_INSERT_FACTOR_CLINRECS), _factor_clinrecs(seeds["risk_factor_clinrecs"]))
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _recommendations(seeds["recommendations"]))
    conn.execute(sa.text(_INSERT_INSTRUMENT_PARAMS), _instrument_parameters(seeds["instruments_parameters"]))
    conn.execute(sa.text(_INSERT_MAPPINGS), _mappings(seeds["biomarker_parameter_mappings"]))


def _upgrade_renames() -> list[dict]:
    return [{"param": param, "old": old, "new": new} for param, old, new in _ANSWER_RENAMES]


def _downgrade_renames() -> list[dict]:
    """Обратная карта без пар, у которых старым значением стал бы ответ «Да»/«Нет»."""
    return [
        {"param": param, "old": new, "new": old} for param, old, new in _ANSWER_RENAMES if new not in _BOOLEAN_ANSWERS
    ]


def _remap_patient_answers(conn: sa.Connection, renames: list[dict]) -> None:
    """Переписать сохранённые ответы по `(parameter_code, старый текст)`.

    Гвард на старое значение «Да»/«Нет»: multi- и boolean-вопросы хранят ответ этими строками,
    и обновление по ним переписало бы чужие ответы необратимо. Новое значение «Нет» допустимо —
    ответ приводится к тексту варианта своего select-вопроса.
    """
    unsafe = [r for r in renames if r["old"] in _BOOLEAN_ANSWERS]
    if unsafe:
        raise RuntimeError(f"0145: ремап затрагивает ответы multi/boolean-вопросов («Да»/«Нет»): {unsafe}")
    conn.execute(sa.text(_REMAP_ANSWERS), renames)


def _merge_lipoprotein_risk_factor(conn: sa.Connection) -> None:
    """Объединить старый биомаркерный код с действующим кодом в живых интерпретациях."""
    conn.execute(
        sa.text(_MERGE_LIPOPROTEIN_RISK_FACTOR),
        {
            "old": _OLD_LIPOPROTEIN_RISK_FACTOR_CODE,
            "new": _NEW_LIPOPROTEIN_RISK_FACTOR_CODE,
            "system_code": _LIPOPROTEIN_RISK_FACTOR_SYSTEM_CODE,
        },
    )


def upgrade() -> None:
    conn = op.get_bind()
    _upsert_parents(conn, _NEW)
    _replace_catalogs(conn, _NEW)
    _remap_patient_answers(conn, _upgrade_renames())
    _merge_lipoprotein_risk_factor(conn)


def downgrade() -> None:
    conn = op.get_bind()
    _remap_patient_answers(conn, _downgrade_renames())
    _upsert_parents(conn, _OLD)
    _replace_catalogs(conn, _OLD)
