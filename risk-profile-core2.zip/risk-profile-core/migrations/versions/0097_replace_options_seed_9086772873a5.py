"""0097_replace_options_seed

Revision ID: 9086772873a5
Revises: a460718b3b84
Create Date: 2026-06-26 11:51:53.424348

Перезаливка справочника options из catalog/0097_9086772873a5_options.csv.
Схема НЕ меняется — options после 0092 без колонки score (CSV-колонку игнорируем),
естественный ключ опции — parameter_code+code.

Относительно сида 0096 переименованы четыре отображаемых value (правки опечаток/формы
в шкале BDI: bdi17/bdi19 — «усталости..» → «усталости.», «не похудел» → «не похудел(а)»
и т.п.). Перед DELETE FROM options ответы пациентов ремапятся под новые value:
patients_parameters(+_history).value хранит выбранный текст опции строкой, FK на parameters
с ON DELETE RESTRICT (PII), поэтому записи не трогаем, а текст приводим к новому. Без ремапа
исторический ответ повисает сиротой и calc-формулы с bare dict lookup падают KeyError
(см. src/calc/domain/formulas/bcrat.py и перезаливку 0096). См. _option_value_renames /
_remap_patient_answers.

downgrade возвращает сид options из 0096 (0096_a460718b3b84_options.csv) и ремапит ответы
пациентов симметрично обратно (source/target меняются местами).
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "9086772873a5"
down_revision: str | None = "a460718b3b84"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_NEW_OPTIONS = _CATALOG / "0097_9086772873a5_options.csv"
_OLD_OPTIONS = _CATALOG / "0096_a460718b3b84_options.csv"

_INSERT_OPTION_SQL = (
    "INSERT INTO options (question_code, parameter_code, code, value) "
    "VALUES (:question_code, :parameter_code, :code, :value)"
)


def _parse_options(path: Path) -> list[dict]:
    # options.score удалён в 0092 — колонку CSV не читаем.
    return [
        {
            "question_code": r["question_code"],
            "parameter_code": r["parameter_code"],
            "code": r["code"],
            "value": r["value"] or None,
        }
        for r in load_csv(path)
    ]


def _option_value_renames(source: Path, target: Path) -> list[dict]:
    """Опции, у которых сменился отображаемый value (естественный ключ опции — parameter_code+code).

    Возвращает [{"param", "old", "new"}]: source — сид, который сейчас в БД (его value лежат
    в patients_parameters.value как ответы пациентов), target — устанавливаемый сид.
    """

    def by_code(path: Path) -> dict[tuple[str, str], str | None]:
        return {(r["parameter_code"], r["code"]): (r["value"] or None) for r in load_csv(path)}

    src, tgt = by_code(source), by_code(target)
    return [
        {"param": param_code, "old": old_value, "new": new_value}
        for (param_code, code), old_value in src.items()
        if (new_value := tgt.get((param_code, code))) and old_value and old_value != new_value
    ]


def _remap_patient_answers(renames: list[dict]) -> None:
    """SET value=new в patients_parameters(+_history) для исторических ответов по (parameter_code, old).

    Опции переименовываются перезаливкой (DELETE+INSERT), но ответы пациентов — это PII с FK
    ON DELETE RESTRICT, их не трогаем, а value они хранят выбранной строкой опции. Без ремапа
    старый текст пропадает из справочника, и calc-формулы с bare dict lookup падают KeyError на всей
    исторической базе (см. src/calc/domain/formulas/bcrat.py). Цепочечных/неоднозначных
    переименований в сидах нет (проверено), поэтому порядок UPDATE-ов неважен.
    """
    if not renames:
        return
    conn = op.get_bind()
    for table in ("patients_parameters", "patients_parameters_history"):
        # nosec B608 — table из захардкоженного литерала, не пользовательский ввод
        sql = sa.text(f"UPDATE {table} SET value = :new WHERE parameter_code = :param AND value = :old")  # nosec B608  # nosemgrep: python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
        conn.execute(sql, renames)


def _replace_options(new_path: Path, old_path: Path) -> None:
    """Ремап ответов пациентов под новые value (ДО DELETE) + полная перезаливка options.

    old_path — сид, который сейчас в БД (source ремапа), new_path — устанавливаемый (target).
    """
    conn = op.get_bind()
    _remap_patient_answers(_option_value_renames(old_path, new_path))
    conn.execute(sa.text("DELETE FROM options"))
    conn.execute(sa.text(_INSERT_OPTION_SQL), _parse_options(new_path))


def upgrade() -> None:
    _replace_options(_NEW_OPTIONS, _OLD_OPTIONS)


def downgrade() -> None:
    _replace_options(_OLD_OPTIONS, _NEW_OPTIONS)
