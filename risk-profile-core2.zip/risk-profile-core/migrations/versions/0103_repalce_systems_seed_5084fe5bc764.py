"""0103_replace_systems_seed
Revision ID: 5084fe5bc764
Revises: 5cf098fad5d6
Create Date: 2026-05-27 12:00:00.000000

"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "5084fe5bc764"
down_revision: str | None = "5cf098fad5d6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_NEW_CSV_PATH = Path(__file__).parent.parent.parent / "catalog" / "0103_5084fe5bc764_systems.csv"
_OLD_CSV_PATH = Path(__file__).parent.parent.parent / "catalog" / "0038_23f0834bc5f0_systems.csv"


def _parse_rows(path: Path) -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "rang": int(r["rang"]),
        }
        for r in load_csv(path)
    ]


_UPDATE_SQL = "UPDATE systems SET description = :description, rang = :rang WHERE code = :code"

# rang has a non-deferrable UNIQUE constraint (uq_systems_rang). A per-row UPDATE
# batch that permutes rang values trips it on an intermediate state, so we defer the
# check to commit time by dropping and re-adding the constraint around the reseed.
_RANG_CONSTRAINT = "uq_systems_rang"


def _reseed(path: Path) -> None:
    conn = op.get_bind()
    op.drop_constraint(_RANG_CONSTRAINT, "systems", type_="unique")
    conn.execute(sa.text(_UPDATE_SQL), _parse_rows(path))
    op.create_unique_constraint(_RANG_CONSTRAINT, "systems", ["rang"])


def upgrade() -> None:
    _reseed(_NEW_CSV_PATH)


def downgrade() -> None:
    _reseed(_OLD_CSV_PATH)
