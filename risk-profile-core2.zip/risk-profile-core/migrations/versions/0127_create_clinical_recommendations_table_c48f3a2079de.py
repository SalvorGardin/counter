"""0127_create_clinical_recommendations_table

Revision ID: c48f3a2079de
Revises: e91c7d40b58f
Create Date: 2026-08-28 10:40:00.000000

Справочник клинических рекомендаций: код и название документа, которым обосновывается балл
фактора риска в группе заболеваний. Сама привязка «фактор + группа → рекомендация» лежит в
`risk_factor_clinrecs`.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "c48f3a2079de"
down_revision: str | None = "e91c7d40b58f"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "clinical_recommendations",
        sa.Column("clinrec_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("clinrec_id", name=op.f("pk_clinical_recommendations")),
        sa.UniqueConstraint("code", name=op.f("uq_clinical_recommendations_code")),
    )


def downgrade() -> None:
    op.drop_table("clinical_recommendations")
