"""0134_add_biomarker_parameter_mappings_value_text

Revision ID: 25c3ead721e7
Revises: e28b16201f9b
Create Date: 2026-08-31 12:14:02.113927

Качественный биомаркер не сравнивается с числовой границей: отклонением от нормы для него
считается совпадение значения с эталонным текстом. Колонка `value_text` хранит этот эталон и
работает в паре с оператором `eq`, как `value_text` в `risk_factor_triggers`.

Условие отклонения от нормы получает три допустимые формы вместо двух, и ограничение `shape`
переписывается целиком: числовой оператор требует `value_num` и запрещает `value_text`,
оператор `eq` — наоборот, маппинг `value` по-прежнему не заполняет ничего из этой тройки.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "25c3ead721e7"
down_revision: str | None = "e28b16201f9b"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# Имя уже в конечной форме — op.f() удерживает его от повторного прогона через naming convention.
_SHAPE_CONSTRAINT = op.f("ck_biomarker_parameter_mappings_shape")

_SHAPE_WITH_VALUE_TEXT = (
    "(mapping_type = 'flag' AND operator IN ('gt', 'gte', 'lt', 'lte') "
    "AND value_num IS NOT NULL AND value_text IS NULL AND option_code IS NOT NULL) OR "
    "(mapping_type = 'flag' AND operator = 'eq' "
    "AND value_num IS NULL AND value_text IS NOT NULL AND option_code IS NOT NULL) OR "
    "(mapping_type = 'value' AND operator IS NULL "
    "AND value_num IS NULL AND value_text IS NULL AND option_code IS NULL)"
)

_SHAPE_WITHOUT_VALUE_TEXT = (
    "(mapping_type = 'flag' AND operator IS NOT NULL AND value_num IS NOT NULL "
    "AND option_code IS NOT NULL) OR "
    "(mapping_type = 'value' AND operator IS NULL AND value_num IS NULL AND option_code IS NULL)"
)


def upgrade() -> None:
    op.add_column("biomarker_parameter_mappings", sa.Column("value_text", sa.String(), nullable=True))
    op.drop_constraint(_SHAPE_CONSTRAINT, "biomarker_parameter_mappings", type_="check")
    op.create_check_constraint(_SHAPE_CONSTRAINT, "biomarker_parameter_mappings", _SHAPE_WITH_VALUE_TEXT)


def downgrade() -> None:
    # Качественную разметку прежняя форма выразить не может: оператор `eq` без `value_num` она
    # запрещает, а `value_text` вместе с колонкой исчезает. Такие строки удаляет downgrade того
    # сида, который их завёл; если они на месте, откат здесь молча потерял бы разметку.
    conn = op.get_bind()
    qualitative = conn.execute(
        sa.text("SELECT count(*) FROM biomarker_parameter_mappings WHERE value_text IS NOT NULL")
    ).scalar_one()
    if qualitative:
        raise RuntimeError(
            f"biomarker_parameter_mappings: {qualitative} qualitative row(s) rely on value_text; "
            "roll back the seed that created them before dropping the column"
        )
    op.drop_constraint(_SHAPE_CONSTRAINT, "biomarker_parameter_mappings", type_="check")
    op.create_check_constraint(_SHAPE_CONSTRAINT, "biomarker_parameter_mappings", _SHAPE_WITHOUT_VALUE_TEXT)
    op.drop_column("biomarker_parameter_mappings", "value_text")
