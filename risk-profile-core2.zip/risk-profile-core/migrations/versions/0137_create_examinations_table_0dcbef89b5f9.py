"""0137_create_examinations_table

Revision ID: 0dcbef89b5f9
Revises: f2a806c31d94
Create Date: 2026-09-04 10:00:00.000000

Единый справочник лабораторных и инструментальных исследований. Тип исследования отличает
строки внутри одной таблицы (`examination_type`), отдельных справочников на тип не заводится.

`code` — UUID, стабильный идентификатор исследования во внешнем контракте: по нему исследование
передаётся смежной системе и на него ссылаются таблицы подбора `disease_examinations` и
`system_checkup_examinations`. Пол клиента здесь не хранится: это условие конкретной
рекомендации, оно живёт в таблицах связей.

Исключённое из подбора исследование переводится в `status = 'inactive'`, строка не удаляется:
на `code` стоят внешние ключи с RESTRICT.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0dcbef89b5f9"
down_revision: str | None = "f2a806c31d94"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "examinations",
        sa.Column("examination_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("code", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("examination_type", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.CheckConstraint(
            "examination_type IN ('laboratory', 'instrumental')",
            name=op.f("ck_examinations_examination_type"),
        ),
        sa.CheckConstraint("status IN ('active', 'inactive')", name=op.f("ck_examinations_status")),
        sa.PrimaryKeyConstraint("examination_id", name=op.f("pk_examinations")),
        # Уникальность code держит внешние ключи таблиц подбора и заодно даёт под них индекс.
        sa.UniqueConstraint("code", name=op.f("uq_examinations_code")),
        # Одно и то же название допустимо у лабораторного и инструментального исследования
        # (например, одноимённые тест и процедура), поэтому в ключ входит и тип.
        sa.UniqueConstraint("name", "examination_type", name=op.f("uq_examinations_name")),
    )
    op.create_index(op.f("ix_examinations_status"), "examinations", ["status"])


def downgrade() -> None:
    op.drop_index(op.f("ix_examinations_status"), table_name="examinations")
    op.drop_table("examinations")
