"""0123_create_biomarkers_table

Revision ID: a7f4c21b9e05
Revises: 132ec9581445
Create Date: 2026-08-28 10:00:00.000000

Справочник биомаркеров: одна строка — биомаркер в одной допустимой единице измерения. Таблица
нужна для входной валидации значений, приходящих из ЭМК, и для связи биомаркера с параметром,
под которым его значение сохраняется.

Таблица создаётся пустой: `parameter_code` — обязательный внешний ключ на `parameters.code`,
поэтому строки появятся только после заведения параметров `biomarker_<code>`. Наполнение
справочника — отдельная задача.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "a7f4c21b9e05"
down_revision: str | None = "132ec9581445"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "biomarkers",
        sa.Column("biomarker_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("biomarker_code", sa.Integer(), nullable=False),
        sa.Column("unit_code", sa.Integer(), nullable=True),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("type", sa.String(), nullable=False),
        sa.Column("unit", sa.String(), nullable=True),
        sa.CheckConstraint("type IN ('quantitative', 'qualitative')", name=op.f("ck_biomarkers_type")),
        sa.CheckConstraint("(unit IS NULL) = (unit_code IS NULL)", name=op.f("ck_biomarkers_unit_pair")),
        sa.ForeignKeyConstraint(
            ["parameter_code"],
            ["parameters.code"],
            name=op.f("fk_biomarkers_parameters_parameter_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("biomarker_id", name=op.f("pk_biomarkers")),
        # Уникальность parameter_code держит связь 1:1 с параметром и заодно даёт индекс под
        # внешний ключ, поэтому отдельный ix на эту колонку не заводим.
        sa.UniqueConstraint("parameter_code", name=op.f("uq_biomarkers_parameter_code")),
        # nulls_not_distinct: биомаркер, значение которого приходит без единицы измерения, описан
        # одной строкой с пустым unit_code. Без этого режима Postgres считал бы такие строки
        # различными и ограничение не сработало бы ни на одной из них.
        sa.UniqueConstraint(
            "biomarker_code",
            "unit_code",
            name="uq_biomarkers_biomarker_code_unit_code",
            postgresql_nulls_not_distinct=True,
        ),
    )


def downgrade() -> None:
    op.drop_table("biomarkers")
