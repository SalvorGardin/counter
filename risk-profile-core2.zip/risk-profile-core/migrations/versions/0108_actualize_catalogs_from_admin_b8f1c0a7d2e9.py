"""0108_actualize_catalogs_from_admin

Revision ID: b8f1c0a7d2e9
Revises: 4c1a9e7b3d85
Create Date: 2026-07-17 00:00:00.000000

Точечная актуализация справочников из админки risk-profile-admin (снимки на 17.07).
Между v0.7.0 (0107) и сейчас аналитик правил контент только в двух таблицах —
risk_factors (v146) и systems (v4). Остальные тронутые справочники контентно не
изменились: questions (v11) и parameter_scores (v17) получили новые версии-снимки, но их
CSV байт-в-байт совпадает с сидом 0107 (пустые ревизии/пересохранения); conditions /
options / recommendations — та же версия, что тянул 0107. Поэтому здесь только две таблицы.

Дельта:
  • risk_factors — reasoning у трёх строк «Отклонения в липидном профиле» × CVD
    (fr_hdl / fr_ldl / fr_total_cholesterol). Прежний текст был ошибочным — описывал
    связь лишнего веса с почками (тот же абзац, что у fr_bmi_obesity: copy-paste).
    Аналитик заменил его корректным объяснением про ЛПНП/ЛПВП и атеросклероз.
    fr_bmi_obesity со своим «почечным» текстом НЕ трогаем — аналитик его не менял.
  • systems — описания двух систем: REPROD «Женское/Мужское здоровье» →
    «Репродуктивная система»; URO «Почки и выделительная система» →
    «Почки и мочевыделительная система». Код и rang не меняются.

Приём — точечный идемпотентный UPDATE (как 0101/0105), а не DELETE+INSERT: правок мало,
а systems — родитель множества FK (ON DELETE RESTRICT), полная перезаливка там избыточна.
Обновляем только текстовые поля, поэтому FK и uq_risk_factors_natural_key
(parameter_code, code, param_value, min/max, system_code) не затрагиваются: (parameter_code,
code, system_code) внутри CVD изолирует ровно одну строку. WHERE дополнительно привязан к
прежнему тексту — UPDATE идемпотентен и обратим, на свежей БД (сиды 0103/0107 правлены
синхронно) upgrade выходит no-op, а на стенде чинит реальные строки.

risk_factors грузится из CSV (тексты длинные): новые значения — из сида
catalog/0107_4c1a9e7b3d85_risk_factors.csv (правлен синхронно), прежние — из пре-образа
catalog/0108_b8f1c0a7d2e9_risk_factors_pre.csv (приём _pre.csv из 0107, нужен для
downgrade). systems правится инлайном — строки короткие. Сид
catalog/0103_5084fe5bc764_systems.csv тоже правлен синхронно, чтобы следующий reseed не
вернул старые описания.

Схема не меняется. Чего миграция НЕ делает (как и 0107): parameters и
instrument_parameters из админки не проливаются — там нетронутый импорт v1, core впереди
(12 sports_* и 454 строки под #122). Low_Platelets × BLOOD в parameter_scores аналитик уже
выставил в 'Да' (совпал с фиксом 0105/#121) — расхождения больше нет.
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "b8f1c0a7d2e9"
down_revision: str | None = "4c1a9e7b3d85"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_RF_NEW_CSV = _CATALOG / "0107_4c1a9e7b3d85_risk_factors.csv"
_RF_OLD_CSV = _CATALOG / "0108_b8f1c0a7d2e9_risk_factors_pre.csv"
# Тройка строк CVD, у которых аналитик поправил reasoning. Ключ (parameter_code, code,
# system_code) внутри CVD уникален, поэтому UPDATE по нему бьёт ровно одну строку.
_RF_KEYS = {("hdl", "fr_hdl", "CVD"), ("ldl", "fr_ldl", "CVD"), ("total_cholesterol", "fr_total_cholesterol", "CVD")}

_RF_UPDATE = (
    "UPDATE risk_factors SET reasoning = :new_reasoning "
    "WHERE parameter_code = :parameter_code AND code = :code AND system_code = :system_code "
    "AND reasoning = :old_reasoning"
)

# systems: короткие описания двух систем — правим инлайном (код и rang не трогаем).
_SYS = (
    ("REPROD", "Женское/Мужское здоровье", "Репродуктивная система"),
    ("URO", "Почки и выделительная система", "Почки и мочевыделительная система"),
)
_SYS_UPDATE = "UPDATE systems SET description = :new WHERE code = :code AND description = :old"


def _rf_reasoning_by_key(csv_path: Path) -> dict[tuple[str, str, str], str]:
    """reasoning трёх целевых строк risk_factors из CSV, по ключу (parameter_code, code, system_code)."""
    by_key = {
        (r["parameter_code"], r["code"], r["system_code"]): r["reasoning"]
        for r in load_csv(csv_path)
        if (r["parameter_code"], r["code"], r["system_code"]) in _RF_KEYS
    }
    missing = _RF_KEYS - set(by_key)
    if missing:
        raise RuntimeError(f"risk_factors CSV {csv_path.name} не содержит строк: {sorted(missing)}")
    return by_key


def _apply_risk_factors(new_csv: Path, old_csv: Path) -> None:
    conn = op.get_bind()
    new_by_key = _rf_reasoning_by_key(new_csv)
    old_by_key = _rf_reasoning_by_key(old_csv)
    params = [
        {
            "parameter_code": pc,
            "code": code,
            "system_code": sc,
            "new_reasoning": new_by_key[(pc, code, sc)],
            "old_reasoning": old_by_key[(pc, code, sc)],
        }
        for (pc, code, sc) in _RF_KEYS
    ]
    conn.execute(sa.text(_RF_UPDATE), params)


def upgrade() -> None:
    _apply_risk_factors(_RF_NEW_CSV, _RF_OLD_CSV)
    conn = op.get_bind()
    for code, old, new in _SYS:
        conn.execute(sa.text(_SYS_UPDATE), {"code": code, "old": old, "new": new})


def downgrade() -> None:
    # new/old меняются местами: восстанавливаем прежний reasoning и описания систем.
    _apply_risk_factors(_RF_OLD_CSV, _RF_NEW_CSV)
    conn = op.get_bind()
    for code, old, new in _SYS:
        conn.execute(sa.text(_SYS_UPDATE), {"code": code, "old": new, "new": old})
