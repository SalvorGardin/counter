"""0124_create_diseases_table

Revision ID: d3b8e5091c7a
Revises: a7f4c21b9e05
Create Date: 2026-08-28 10:10:00.000000

Справочник групп заболеваний: одна строка — группа, в разрезе которой считается риск по
клиническим рекомендациям. Группа привязана к системе организма.

Существующие колонки `instruments.diseases` и `interpretations.diseases` (`text[]`) хранят
названия заболеваний текстом и к этой таблице не относятся — их сведение к справочнику в объём
изменения не входит.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "d3b8e5091c7a"
down_revision: str | None = "a7f4c21b9e05"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "diseases",
        sa.Column("disease_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("description", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["system_code"],
            ["systems.code"],
            name=op.f("fk_diseases_systems_system_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("disease_id", name=op.f("pk_diseases")),
        sa.UniqueConstraint("code", name=op.f("uq_diseases_code")),
    )
    op.create_index(op.f("ix_diseases_system_code"), "diseases", ["system_code"])


def downgrade() -> None:
    op.drop_index(op.f("ix_diseases_system_code"), table_name="diseases")
    op.drop_table("diseases")
