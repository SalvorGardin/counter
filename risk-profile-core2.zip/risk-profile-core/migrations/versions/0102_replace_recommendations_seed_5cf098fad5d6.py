"""0102_replace_recommendations_seed

Revision ID: 5cf098fad5d6
Revises: b121b43cb486
Create Date: 2026-07-02 00:00:00.000000

Перезаливка recommendations из catalog/0102_5cf098fad5d6_recommendations.csv: текстовые
поля с переносами строк (питание, режим труда и отдыха и т.п.) исправлены на настоящий
многострочный CSV-формат (значение в кавычках, `\\n` заменён на перевод строки) — раньше
эти строки хранили буквальный `\\n` двумя символами.

Простой DELETE+INSERT одной таблицы: risk_factors_code — не FK (снят в 0096), схема не
меняется, задевать другие таблицы не нужно.

downgrade возвращает сид 0096 (последняя перезаливка recommendations до этой миграции).
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "5cf098fad5d6"
down_revision: str | None = "b121b43cb486"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_NEW_CSV_PATH = Path(__file__).parent.parent.parent / "catalog" / "0102_5cf098fad5d6_recommendations.csv"
_OLD_CSV_PATH = Path(__file__).parent.parent.parent / "catalog" / "0096_a460718b3b84_recommendations.csv"

_INSERT_SQL = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)


def _parse_rows(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": r["recommendations_group"],
            "risk_factors_code": r["risk_factors_code"] or None,
            "system_code": r["system_code"],
            "name": r["name"],
            "text": r.get("text") or None,
        }
        for r in load_csv(path)
    ]


def _replace_table(rows: list[dict]) -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM recommendations"))
    conn.execute(sa.text(_INSERT_SQL), rows)


def upgrade() -> None:
    _replace_table(_parse_rows(_NEW_CSV_PATH))


def downgrade() -> None:
    _replace_table(_parse_rows(_OLD_CSV_PATH))
