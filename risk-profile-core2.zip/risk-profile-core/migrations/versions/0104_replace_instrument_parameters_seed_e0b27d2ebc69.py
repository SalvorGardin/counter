"""0104_replace_instrument_parameters_seed

Revision ID: e0b27d2ebc69
Revises: 5084fe5bc764
Create Date: 2026-07-06 00:00:00.000000

Приводит instruments_parameters к состоянию дев-стенда на 06.07.
Набор пар (instrument_code, parameter_code) не меняется — те же 454 строки, что
и в 0096. Меняется только is_required: 7 анамнез-параметров в формах становятся
необязательными (required -> optional):
  form_cvd;family_cardiomyopathy
  form_cvd;family_sudden_cardiac_death
  form_cvd;family_thrombus
  form_cvd;hodgkins_lymphoma
  form_endo;glucose_elevated_history
  form_onco;other_cancer
  form_resp;resp_cancer
"""

from collections.abc import Sequence
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "e0b27d2ebc69"
down_revision: str | None = "5084fe5bc764"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_NEW_CSV_PATH = _CATALOG / "0104_e0b27d2ebc69_instrument_parameters.csv"
_OLD_CSV_PATH = _CATALOG / "0096_a460718b3b84_instruments_parameters.csv"


def _parse_rows(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
    ]


def _replace_table(rows: list[dict]) -> None:
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM instruments_parameters"))
    conn.execute(
        sa.text(
            "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
            "VALUES (:instrument_code, :parameter_code, :is_required)"
        ),
        rows,
    )


def upgrade() -> None:
    _replace_table(_parse_rows(_NEW_CSV_PATH))


def downgrade() -> None:
    _replace_table(_parse_rows(_OLD_CSV_PATH))
