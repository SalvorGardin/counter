"""0141_add_disease_examination_category

Revision ID: e8d2f4fa1305
Revises: 70b548543df6
Create Date: 2026-09-07 12:00:00.000000

Связь группы заболеваний с исследованием больше не зависит от пола клиента: существующий
справочник не использует `gender`, поэтому колонка, CHECK и EXCLUDE удаляются. После удаления
пола уникальность пары (`disease_code`, `examination_code`), которую EXCLUDE обеспечивал
побочно, выражается обычным UNIQUE.

`category` различает базовые (`basic`) и дополнительные (`extended`) лабораторные анализы.
Колонка nullable для инструментальных исследований. CHECK ограничивает только домен значений:
соответствие категории типу исследования зависит от строки в `examinations` и обычным
межтабличным CHECK не выражается.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "e8d2f4fa1305"
down_revision: str | None = "70b548543df6"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = "disease_examinations"
# Имена уже в конечной форме — op.f() удерживает их от повторного прогона через
# naming convention, где CHECK использует шаблон с constraint_name.
_CATEGORY_CHECK = op.f("ck_disease_examinations_category")
_GENDER_CHECK = op.f("ck_disease_examinations_gender")
_PAIR_UNIQUE = "uq_disease_examinations_disease_code_examination_code"


def upgrade() -> None:
    op.add_column(_TABLE, sa.Column("category", sa.String(), nullable=True))
    op.create_check_constraint(
        _CATEGORY_CHECK,
        _TABLE,
        "category IS NULL OR category IN ('basic', 'extended')",
    )
    op.execute("ALTER TABLE disease_examinations DROP CONSTRAINT ex_disease_examinations_gender_scope")
    op.drop_constraint(_GENDER_CHECK, _TABLE, type_="check")
    op.drop_column(_TABLE, "gender")
    op.create_unique_constraint(_PAIR_UNIQUE, _TABLE, ["disease_code", "examination_code"])


def downgrade() -> None:
    op.drop_constraint(_PAIR_UNIQUE, _TABLE, type_="unique")
    op.drop_constraint(_CATEGORY_CHECK, _TABLE, type_="check")
    op.drop_column(_TABLE, "category")
    op.add_column(_TABLE, sa.Column("gender", sa.String(), nullable=True))
    op.create_check_constraint(
        _GENDER_CHECK,
        _TABLE,
        "gender IS NULL OR gender IN ('Мужской', 'Женский')",
    )
    op.execute(
        "ALTER TABLE disease_examinations ADD CONSTRAINT ex_disease_examinations_gender_scope "
        "EXCLUDE USING gist ("
        "disease_code WITH =, "
        "examination_code WITH =, "
        "(CASE gender "
        "WHEN 'Мужской' THEN int4range(0, 1) "
        "WHEN 'Женский' THEN int4range(1, 2) "
        "ELSE int4range(0, 2) END) WITH &&"
        ")"
    )
