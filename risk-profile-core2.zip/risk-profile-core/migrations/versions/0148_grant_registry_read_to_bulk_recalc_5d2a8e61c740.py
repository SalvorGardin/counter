"""0148_grant_registry_read_to_bulk_recalc

Revision ID: 5d2a8e61c740
Revises: 3b1f7c9d4e2a
Create Date: 2026-09-22 11:00:00.000000

Выдаёт логину продюсера массового пересчёта (`risk_bulk_recalc_app`) единственное право, которое
ему нужно: чтение реестра версий расчёта. Под логином расчёта он получил бы заодно право
переписать результаты любого пациента — ради запроса списка идентификаторов.

Роль кластерная и заводится ДО alembic (`scripts/bootstrap_db_roles.py`): пароли рантаймов не
место в миграции. Если роли нет, миграция падает с явным сообщением, а не выдаёт права кому попало
и не пропускает выдачу молча.

Права на запись здесь не выдаются ни на одну таблицу — ни результатов, ни интерпретаций, ни
данных профиля. `USAGE` на схему расчёта само по себе доступа к таблицам не даёт: оно лишь
разрешает называть объекты внутри схемы.
"""

from collections.abc import Sequence

from alembic import op

revision: str = "5d2a8e61c740"
down_revision: str | None = "3b1f7c9d4e2a"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

CALCULATION_SCHEMA = "risk_calculation"
REGISTRY_TABLE = f"{CALCULATION_SCHEMA}.patient_calculation_versions"
BULK_RECALC_APP = "risk_bulk_recalc_app"


def _require_role() -> None:
    """Падает с явным сообщением, если логин продюсера не заведён.

    Имя роли записано литералом: asyncpg (прод-драйвер миграций) bind-параметры в `DO`-блоке не
    поддерживает, а миграция — замороженный снимок. Совпадение с константой держит утверждение ниже.
    """
    op.execute("""
        DO $do$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'risk_bulk_recalc_app') THEN
                RAISE EXCEPTION
                    'Missing database role: risk_bulk_recalc_app. Run scripts/bootstrap_db_roles.py before alembic.';
            END IF;
        END
        $do$
    """)


assert BULK_RECALC_APP == "risk_bulk_recalc_app"


def upgrade() -> None:
    _require_role()
    op.execute(f"GRANT USAGE ON SCHEMA {CALCULATION_SCHEMA} TO {BULK_RECALC_APP}")
    op.execute(f"GRANT SELECT ON {REGISTRY_TABLE} TO {BULK_RECALC_APP}")


def downgrade() -> None:
    # Роль к этому моменту может быть уже снята (порядок отката: alembic downgrade → снятие
    # ролей), поэтому отзыв условный: REVOKE на несуществующую роль упал бы.
    # Имена роли, схемы и таблицы — захардкоженные константы модуля, не пользовательский ввод.
    revoke = (
        "DO $do$ BEGIN "  # nosec B608
        f"IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{BULK_RECALC_APP}') THEN "
        f"EXECUTE 'REVOKE SELECT ON {REGISTRY_TABLE} FROM {BULK_RECALC_APP}'; "
        f"EXECUTE 'REVOKE USAGE ON SCHEMA {CALCULATION_SCHEMA} FROM {BULK_RECALC_APP}'; "
        "END IF; END $do$"
    )
    op.execute(revoke)
