"""0136_seed_biomarker_and_disease_catalogs

Revision ID: f2a806c31d94
Revises: 4b9e2a71c0d8
Create Date: 2026-09-01 11:30:00.000000

Наполнение справочников биомаркеров, групп заболеваний и клинических рекомендаций и
актуализация справочников, от которых они зависят, по свежему снимку админки.

Пустые с момента создания таблицы (0123–0129) получают первый сид:

  * diseases 126 строк, disease_icd 455 — состав групп заболеваний кодами МКБ третьего уровня;
  * clinical_recommendations 21 — источники, которыми обоснованы баллы;
  * risk_factor_scores 29 и risk_factor_clinrecs 31 — балл фактора риска в группе и его
    обоснование. `influence` у всех строк снимка `increase`;
  * biomarkers 53 и biomarker_parameter_mappings 27 — биомаркер в одной единице измерения и
    разметка «биомаркер заполняет параметр опросника».

Дельта по справочникам, которые уже наполнены (действующие сиды: parameters — 0096,
risk_factors — 0119, risk_factor_systems и risk_factor_triggers — 0121, recommendations — 0114,
instruments_parameters — 0116, instruments — 0121, systems_instruments — 0095):

  * parameters      +53, изменений и удалений нет. Это параметры `biomarker_<код>_<единица>`,
                    под которыми сохраняется значение биомаркера: без них не встают внешние
                    ключи `biomarkers.parameter_code` и `biomarker_parameter_mappings`.
  * risk_factors    +25, изменений и удалений нет — факторы, распознаваемые по биомаркерам
                    (`fr_low_ferritin`, `fr_elevated_HbA1c`, `fr_STI_infections` и другие).
  * risk_factor_systems  249 → 272: +26 пар под новые факторы, −3 (`fr_arterial_hypertension ×
                    ENDO`, `fr_edema × URO`, `fr_thrombus × BLOOD`). Тексты `reasoning`
                    существующих пар не менялись.
  * risk_factor_triggers 320 → 355: +39 условий (37 из них читают параметры-биомаркеры),
                    −4 условия удалённых пар и `fr_extreme_sport × RESP`, и 5 правок
                    `value_text` при том же `trigger_code`: у `fr_bypass_surgery`,
                    `fr_heart_surgery`, `fr_heart_transplantation`, `fr_second_bypass_surgery`
                    и `fr_valve_replacement` эталон заменён с текста варианта ответа на `Да`.
                    Параметры этих факторов принадлежат вопросу `sq_0230` типа `multi`, а
                    ответ на multi сохраняется как `Да`/`Нет` — по тексту варианта условие не
                    матчилось никогда.
  * recommendations 145 → 158: +13 рекомендаций под новые факторы риска. Существующие строки
                    не менялись и не удалялись.
  * instruments     +1: `biomarker_kr` — расчёт рисков по биомаркерам на основании клинических
                    рекомендаций. Строки действующих инструментов сид не трогает (INSERT с
                    `ON CONFLICT DO NOTHING`): снимок админки отстаёт от 0121 и вернул бы
                    `ckd_epi.diseases` к «Хроническая болезнь почек», а `score_2.diseases` — к
                    паре «Инфаркт»/«Инсульт». Наименования групп матчатся с маркерами
                    `src/interpretation/domain/constants.py` строгим равенством, и откат увёл
                    бы обе группы в «прочие».
  * instruments_parameters 454 → 504: +53 параметра-биомаркера у `biomarker_kr`,
                    −3 (`form_blood × fever_unexplained`, `form_sense × antihypertensive_meds`,
                    `form_skin × solarium_use`). Все 53 — необязательные.
  * systems_instruments 23 → 36: `biomarker_kr` добавлен ко всем 13 системам, кроме COMMON.
                    Удалений нет.

Чем `biomarker_kr` становится для расчёта: этим сидом клинрек-расчёт включается на всех
пациентов. Тип `biomarker_kr` в `instruments.type` — маршрут в отдельную ветку расчёта
(`BiomarkerClinrecPipeline`), не в формульную: строка результата пишется в разрезе группы
заболеваний по числу сработавших факторов с баллом 3. Пациент без значений биомаркеров строк не
получает вовсе, а изменившаяся группа тянет за собой интерпретацию только своей системы
(`diseases.system_code`), а не всех 13 систем инструмента.

Все внешние ключи и check-ограничения снимка сверены с целевым состоянием до записи миграции:
`system_code` — с сидом систем 0121, `option_code` маппингов и `value_text` текстовых условий —
с сидом опций 0111, `parameter_code` — с parameters этого же сида. Нарушений нет.

Ответы пациентов не ремапятся: `options.value` миграция не трогает, новые условия и маппинги
только читают уже сохранённые значения. `patients_parameters_history`, `results_history`,
`interpretations_history` и `risk_factor_matches` — аудитный след, не трогаем (решение ревью !154).

Приёмы записи и почему выбраны именно они:

  * parameters и risk_factors — INSERT новых строк, без DELETE. `parameters.code` под FK с
    RESTRICT из `patients_parameters` (значения биомаркеров ЭМК уже пишутся туда), поэтому
    параметр не удаляется никогда — downgrade переводит новые в `status='inactive'`.
    У risk_factors удалений в дельте нет, перезаливать нечего.
  * risk_factor_systems, risk_factor_triggers, recommendations, instruments_parameters и
    systems_instruments — полная перезаливка (DELETE + INSERT), как в 0111/0113/0114/0116/0121:
    естественные ключи покрывают почти все колонки, «обновление на месте» одним UPSERT
    невыразимо. Все пять — листья в графе FK, ссылок на них нет.
  * instruments — INSERT с `ON CONFLICT (code) DO NOTHING`: добавляет отсутствующую строку и
    оставляет действующие как есть.
  * Новые справочники — обычный INSERT в порядке от родителей к зависимым: таблицы созданы
    пустыми и никто на них ещё не ссылается.

Порядок DELETE в downgrade обратный: сначала зависимые справочники, потом родители, иначе
внешние ключи с RESTRICT не дадут удалить. Строки результата по группам заболеваний downgrade
удаляет перед строкой инструмента — `results.instrument_code` стоит под RESTRICT, а других
записей по этому коду быть не может: инструмент заводится этой же миграцией.
"""

from collections.abc import Sequence
from datetime import datetime
from decimal import Decimal
from pathlib import Path

import sqlalchemy as sa
from alembic import op

from src.utils.csv_loader import load_csv

revision: str = "f2a806c31d94"
down_revision: str | None = "4b9e2a71c0d8"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_CATALOG = Path(__file__).parent.parent.parent / "catalog"
_PREFIX = "0136_f2a806c31d94_"

_PARAMETERS = _CATALOG / f"{_PREFIX}parameters.csv"
_RISK_FACTORS = _CATALOG / f"{_PREFIX}risk_factors.csv"
_INSTRUMENTS = _CATALOG / f"{_PREFIX}instruments.csv"
_DISEASES = _CATALOG / f"{_PREFIX}diseases.csv"
_DISEASE_ICD = _CATALOG / f"{_PREFIX}disease_icd.csv"
_CLINRECS = _CATALOG / f"{_PREFIX}clinical_recommendations.csv"
_SCORES = _CATALOG / f"{_PREFIX}risk_factor_scores.csv"
_FACTOR_CLINRECS = _CATALOG / f"{_PREFIX}risk_factor_clinrecs.csv"
_BIOMARKERS = _CATALOG / f"{_PREFIX}biomarkers.csv"
_MAPPINGS = _CATALOG / f"{_PREFIX}biomarker_parameter_mappings.csv"

_NEW_FACTOR_SYSTEMS = _CATALOG / f"{_PREFIX}risk_factor_systems.csv"
_OLD_FACTOR_SYSTEMS = _CATALOG / "0121_c4e81f92d7a3_risk_factor_systems.csv"
_NEW_TRIGGERS = _CATALOG / f"{_PREFIX}risk_factor_triggers.csv"
_OLD_TRIGGERS = _CATALOG / "0121_c4e81f92d7a3_risk_factor_triggers.csv"
_NEW_RECOMMENDATIONS = _CATALOG / f"{_PREFIX}recommendations.csv"
_OLD_RECOMMENDATIONS = _CATALOG / "0114_00c99f0ebbe8_recommendations.csv"
_NEW_INSTRUMENT_PARAMS = _CATALOG / f"{_PREFIX}instrument_parameters.csv"
_OLD_RISK_FACTORS = _CATALOG / "0119_7f2a9c184b6d_risk_factors.csv"
_OLD_INSTRUMENT_PARAMS = _CATALOG / "0116_163ab71d0203_instrument_parameters.csv"
_NEW_SYSTEM_INSTRUMENTS = _CATALOG / f"{_PREFIX}systems_instruments.csv"

_BIOMARKER_INSTRUMENT_CODE = "biomarker_kr"

# Таблицы перечислены готовыми запросами, а не именами в цикле: имя таблицы, подставленное в
# строку запроса, читается статическим анализом как конструирование SQL.
_DELETE_BIOMARKER_CALC_TRACES = (
    "DELETE FROM results WHERE instrument_code = :code",
    "DELETE FROM results_history WHERE instrument_code = :code",
    "DELETE FROM calculation_statuses WHERE instrument_code = :code",
)

_INSERT_PARAMETERS = (
    "INSERT INTO parameters (code, description, status, validity_period) "
    "VALUES (:code, :description, :status, :validity_period) ON CONFLICT (code) DO NOTHING"
)
_INSERT_RISK_FACTORS = (
    "INSERT INTO risk_factors (code, description, modifiability) "
    "VALUES (:code, :description, :modifiability) ON CONFLICT (code) DO NOTHING"
)
_INSERT_INSTRUMENTS = (
    "INSERT INTO instruments (code, description, type, status, diseases) "
    "VALUES (:code, :description, :type, :status, :diseases) ON CONFLICT (code) DO NOTHING"
)
_INSERT_INSTRUMENT_PARAMS = (
    "INSERT INTO instruments_parameters (instrument_code, parameter_code, is_required) "
    "VALUES (:instrument_code, :parameter_code, :is_required)"
)
_INSERT_SYSTEM_INSTRUMENTS = (
    "INSERT INTO systems_instruments (system_code, instrument_code) VALUES (:system_code, :instrument_code)"
)
_INSERT_FACTOR_SYSTEMS = (
    "INSERT INTO risk_factor_systems (risk_factor_code, system_code, reasoning) "
    "VALUES (:risk_factor_code, :system_code, :reasoning)"
)
_INSERT_TRIGGERS = (
    "INSERT INTO risk_factor_triggers "
    "(trigger_code, risk_factor_code, system_code, parameter_code, value_type, operator, "
    "value_num, min_value, max_value, value_text, gender) "
    "VALUES (:trigger_code, :risk_factor_code, :system_code, :parameter_code, :value_type, :operator, "
    ":value_num, :min_value, :max_value, :value_text, :gender)"
)
_INSERT_RECOMMENDATIONS = (
    "INSERT INTO recommendations (recommendations_group, risk_factors_code, system_code, name, text) "
    "VALUES (:recommendations_group, :risk_factors_code, :system_code, :name, :text)"
)
_INSERT_DISEASES = "INSERT INTO diseases (code, description, system_code) VALUES (:code, :description, :system_code)"
_INSERT_DISEASE_ICD = "INSERT INTO disease_icd (disease_code, icd_code) VALUES (:disease_code, :icd_code)"
_INSERT_CLINRECS = "INSERT INTO clinical_recommendations (code, name) VALUES (:code, :name)"
_INSERT_SCORES = (
    "INSERT INTO risk_factor_scores (risk_factor_code, disease_code, score, influence) "
    "VALUES (:risk_factor_code, :disease_code, :score, :influence)"
)
_INSERT_FACTOR_CLINRECS = (
    "INSERT INTO risk_factor_clinrecs (risk_factor_code, disease_code, clinrec_code) "
    "VALUES (:risk_factor_code, :disease_code, :clinrec_code)"
)
_INSERT_BIOMARKERS = (
    "INSERT INTO biomarkers (biomarker_code, unit_code, parameter_code, name, type, unit) "
    "VALUES (:biomarker_code, :unit_code, :parameter_code, :name, :type, :unit)"
)
_INSERT_MAPPINGS = (
    "INSERT INTO biomarker_parameter_mappings "
    "(biomarker_parameter_code, parameter_code, mapping_type, operator, value_num, value_text, option_code, unit) "
    "VALUES (:biomarker_parameter_code, :parameter_code, :mapping_type, :operator, :value_num, :value_text, "
    ":option_code, :unit)"
)


def _none_if_blank(value: str) -> str | None:
    return value or None


def _decimal_or_none(value: str) -> Decimal | None:
    """Числовые колонки справочников — `Numeric`.

    asyncpg (под ним идёт `upgrade head` приложения) принимает в такую колонку только `Decimal`,
    строку он отвергает — в отличие от синхронного драйвера, которым миграции гоняются в CI.
    """
    return Decimal(value) if value else None


def _parameters() -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "status": r["status"],
            # То же ограничение драйвера, что и у Numeric: TIMESTAMP asyncpg принимает
            # только datetime.
            "validity_period": datetime.fromisoformat(r["validity_period"]),
        }
        for r in load_csv(_PARAMETERS)
        if r["code"]
    ]


def _biomarker_parameter_codes() -> list[str]:
    return [r["parameter_code"] for r in load_csv(_BIOMARKERS) if r["parameter_code"]]


def _risk_factors() -> list[dict]:
    return [
        {"code": r["code"], "description": r["description"], "modifiability": r["modifiability"]}
        for r in load_csv(_RISK_FACTORS)
        if r["code"]
    ]


def _new_risk_factor_codes() -> list[str]:
    """Коды факторов риска, которых не было до этой миграции.

    Считаются по действующему сиду 0119, а не по текущему состоянию БД: downgrade обязан снять
    ровно то, что добавил upgrade, и не тронуть фактор, заведённый чем-то ещё.
    """
    before = {r["code"] for r in load_csv(_OLD_RISK_FACTORS)}
    return [r["code"] for r in _risk_factors() if r["code"] not in before]


def _instruments() -> list[dict]:
    return [
        {
            "code": r["code"],
            "description": r["description"],
            "type": r["type"],
            "status": r["status"],
            # Колонка в БД — ARRAY(Text); в снимке одиночное наименование группы или пусто.
            "diseases": [r["diseases"]] if r["diseases"] else None,
        }
        for r in load_csv(_INSTRUMENTS)
        if r["code"]
    ]


def _instrument_parameters(path: Path) -> list[dict]:
    return [
        {
            "instrument_code": r["instrument_code"],
            "parameter_code": r["parameter_code"],
            "is_required": r["is_required"].lower() == "true",
        }
        for r in load_csv(path)
        if r["instrument_code"]
    ]


def _system_instruments(path: Path) -> list[dict]:
    return [
        {"system_code": r["system_code"], "instrument_code": r["instrument_code"]}
        for r in load_csv(path)
        if r["system_code"]
    ]


def _factor_systems(path: Path) -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "reasoning": _none_if_blank(r["reasoning"]),
        }
        for r in load_csv(path)
        if r["risk_factor_code"]
    ]


def _triggers(path: Path) -> list[dict]:
    return [
        {
            "trigger_code": r["trigger_code"],
            "risk_factor_code": r["risk_factor_code"],
            "system_code": r["system_code"],
            "parameter_code": r["parameter_code"],
            "value_type": r["value_type"],
            "operator": r["operator"],
            "value_num": _decimal_or_none(r["value_num"]),
            "min_value": _decimal_or_none(r["min_value"]),
            "max_value": _decimal_or_none(r["max_value"]),
            "value_text": _none_if_blank(r["value_text"]),
            "gender": _none_if_blank(r["gender"]),
        }
        for r in load_csv(path)
        if r["trigger_code"]
    ]


def _recommendations(path: Path) -> list[dict]:
    return [
        {
            "recommendations_group": _none_if_blank(r["recommendations_group"]),
            "risk_factors_code": _none_if_blank(r["risk_factors_code"]),
            "system_code": r["system_code"],
            "name": r["name"],
            "text": _none_if_blank(r["text"]),
        }
        for r in load_csv(path)
        if r["system_code"]
    ]


def _diseases() -> list[dict]:
    return [
        {"code": r["code"], "description": r["description"], "system_code": r["system_code"]}
        for r in load_csv(_DISEASES)
        if r["code"]
    ]


def _disease_icd() -> list[dict]:
    return [
        {"disease_code": r["disease_code"], "icd_code": r["icd_code"]}
        for r in load_csv(_DISEASE_ICD)
        if r["disease_code"]
    ]


def _clinrecs() -> list[dict]:
    return [{"code": r["code"], "name": r["name"]} for r in load_csv(_CLINRECS) if r["code"]]


def _scores() -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "score": int(r["score"]),
            "influence": r["influence"],
        }
        for r in load_csv(_SCORES)
        if r["risk_factor_code"]
    ]


def _factor_clinrecs() -> list[dict]:
    return [
        {
            "risk_factor_code": r["risk_factor_code"],
            "disease_code": r["disease_code"],
            "clinrec_code": r["clinrec_code"],
        }
        for r in load_csv(_FACTOR_CLINRECS)
        if r["risk_factor_code"]
    ]


def _biomarkers() -> list[dict]:
    return [
        {
            "biomarker_code": int(r["biomarker_code"]),
            # Единица измерения и её код заполнены только вместе (ограничение `unit_pair`):
            # у качественного биомаркера без единицы обе колонки пустые.
            "unit_code": int(r["unit_code"]) if r["unit_code"] else None,
            "parameter_code": r["parameter_code"],
            "name": r["name"],
            "type": r["type"],
            "unit": _none_if_blank(r["unit"]),
        }
        for r in load_csv(_BIOMARKERS)
        if r["biomarker_code"]
    ]


def _mappings() -> list[dict]:
    return [
        {
            "biomarker_parameter_code": r["biomarker_parameter_code"],
            "parameter_code": r["parameter_code"],
            "mapping_type": r["mapping_type"],
            "operator": _none_if_blank(r["operator"]),
            "value_num": _decimal_or_none(r["value_num"]),
            "value_text": _none_if_blank(r["value_text"]),
            "option_code": _none_if_blank(r["option_code"]),
            "unit": _none_if_blank(r["unit"]),
        }
        for r in load_csv(_MAPPINGS)
        if r["biomarker_parameter_code"]
    ]


def _replace_leaf_catalogs(
    factor_systems: Path, triggers: Path, recommendations: Path, instrument_params: Path, system_instruments: Path
) -> None:
    """Перезалить справочники-листья.

    Все пять таблиц — листья в графе FK: их родители (`risk_factors`, `systems`, `parameters`,
    `instruments`) этой функцией не трогаются, а ссылок на сами таблицы нет, поэтому порядок
    DELETE между ними свободен.
    """
    conn = op.get_bind()
    conn.execute(sa.text("DELETE FROM risk_factor_triggers"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM risk_factor_systems"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM recommendations"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM instruments_parameters"))  # migration-safety: ok full replace
    conn.execute(sa.text("DELETE FROM systems_instruments"))  # migration-safety: ok full replace

    conn.execute(sa.text(_INSERT_FACTOR_SYSTEMS), _factor_systems(factor_systems))
    conn.execute(sa.text(_INSERT_TRIGGERS), _triggers(triggers))
    conn.execute(sa.text(_INSERT_RECOMMENDATIONS), _recommendations(recommendations))
    conn.execute(sa.text(_INSERT_INSTRUMENT_PARAMS), _instrument_parameters(instrument_params))
    conn.execute(sa.text(_INSERT_SYSTEM_INSTRUMENTS), _system_instruments(system_instruments))


def upgrade() -> None:
    conn = op.get_bind()

    # Родители справочников-листьев: без новых параметров и факторов не встанут ни условия по
    # биомаркерам, ни строки biomarkers/risk_factor_scores.
    conn.execute(sa.text(_INSERT_PARAMETERS), _parameters())
    # Повторный upgrade после downgrade: параметр удалить нельзя (см. докстринг), downgrade
    # переводит его в `inactive`, и вернуть его в строй обязан именно upgrade.
    conn.execute(
        sa.text("UPDATE parameters SET status = 'active' WHERE code = ANY(:codes)"),
        {"codes": _biomarker_parameter_codes()},
    )
    conn.execute(sa.text(_INSERT_RISK_FACTORS), _risk_factors())
    conn.execute(sa.text(_INSERT_INSTRUMENTS), _instruments())

    _replace_leaf_catalogs(
        _NEW_FACTOR_SYSTEMS, _NEW_TRIGGERS, _NEW_RECOMMENDATIONS, _NEW_INSTRUMENT_PARAMS, _NEW_SYSTEM_INSTRUMENTS
    )

    # Справочники, созданные пустыми в 0123–0129, — в порядке от родителей к зависимым.
    conn.execute(sa.text(_INSERT_DISEASES), _diseases())
    conn.execute(sa.text(_INSERT_DISEASE_ICD), _disease_icd())
    conn.execute(sa.text(_INSERT_CLINRECS), _clinrecs())
    conn.execute(sa.text(_INSERT_SCORES), _scores())
    conn.execute(sa.text(_INSERT_FACTOR_CLINRECS), _factor_clinrecs())
    conn.execute(sa.text(_INSERT_BIOMARKERS), _biomarkers())
    conn.execute(sa.text(_INSERT_MAPPINGS), _mappings())


def downgrade() -> None:
    conn = op.get_bind()

    # Зависимые справочники — раньше родителей: FK стоят с RESTRICT.
    conn.execute(sa.text("DELETE FROM biomarker_parameter_mappings"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM biomarkers"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM risk_factor_clinrecs"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM risk_factor_scores"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM clinical_recommendations"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM disease_icd"))  # migration-safety: ok seeded here
    conn.execute(sa.text("DELETE FROM diseases"))  # migration-safety: ok seeded here

    # Справочники-листья возвращаются к состоянию до этой миграции. `systems_instruments` до неё
    # содержал ровно строки сида 0095 — они же лежат в снимке без строк `biomarker_kr`,
    # поэтому отдельного старого файла для него нет: пары фильтруются по коду инструмента.
    _replace_leaf_catalogs(
        _OLD_FACTOR_SYSTEMS, _OLD_TRIGGERS, _OLD_RECOMMENDATIONS, _OLD_INSTRUMENT_PARAMS, _NEW_SYSTEM_INSTRUMENTS
    )
    conn.execute(
        sa.text("DELETE FROM systems_instruments WHERE instrument_code = :code"),
        {"code": _BIOMARKER_INSTRUMENT_CODE},
    )

    # Строки результата и история клинрек-расчёта. `instruments.code` под FK с RESTRICT из
    # `results`, `results_history` и `calculation_statuses`, поэтому строку инструмента без них
    # не удалить. Аудитный след при этом не теряется: инструмент заводится этой же миграцией,
    # записей по нему до неё не было, а после её отката считать по нему нечем — справочники
    # групп заболеваний и баллов downgrade снимает тем же вызовом.
    for statement in _DELETE_BIOMARKER_CALC_TRACES:
        conn.execute(sa.text(statement), {"code": _BIOMARKER_INSTRUMENT_CODE})
    conn.execute(
        sa.text("DELETE FROM instruments WHERE code = :code"),
        {"code": _BIOMARKER_INSTRUMENT_CODE},
    )
    conn.execute(
        sa.text("DELETE FROM risk_factors WHERE code = ANY(:codes)"),
        {"codes": _new_risk_factor_codes()},
    )
    # Параметр не удаляется никогда: `parameters.code` под FK с RESTRICT из `patients_parameters`,
    # куда уже пишутся значения биомаркеров из ЭМК. Снимаем его с эксплуатации статусом.
    conn.execute(
        sa.text("UPDATE parameters SET status = 'inactive' WHERE code = ANY(:codes)"),
        {"codes": _biomarker_parameter_codes()},
    )
