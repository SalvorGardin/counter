"""0117_create_calculation_statuses_table

Revision ID: 4b1e7c93a5d2
Revises: 163ab71d0203
Create Date: 2026-08-10 12:00:00.000000

Диагностическая таблица `calculation_statuses`: по какой причине инструмент не дал показателя
по паре «пациент × инструмент». Клинические данные в ней не хранятся — источник показателя
по-прежнему `results`.

Запись в таблицу управляется флагом `RISK_MODEL_CALC_STATUS_COLLECTION_ENABLED`
(см. docs/requirements/calc-statuses.md), но сама таблица создаётся безусловно: состояние
флага не должно влиять на схему базы.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "4b1e7c93a5d2"
down_revision: str | None = "163ab71d0203"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "calculation_statuses",
        sa.Column("calculation_status_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("instrument_code", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.Column("reason_code", sa.String(), nullable=True),
        sa.Column("date_time", sa.TIMESTAMP(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("missing_parameter_codes", sa.ARRAY(sa.Text()), nullable=True),
        sa.Column("applicable_questions", sa.Integer(), nullable=True),
        sa.Column("progressed_questions", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            ["patients.patient_id"],
            name=op.f("fk_calculation_statuses_patients_patient_id"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["instrument_code"],
            ["instruments.code"],
            name=op.f("fk_calculation_statuses_instruments_instrument_code"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("calculation_status_id", name=op.f("pk_calculation_statuses")),
        sa.UniqueConstraint(
            "patient_id",
            "instrument_code",
            name=op.f("uq_calculation_statuses_patient_id_instrument_code"),
        ),
    )


def downgrade() -> None:
    op.drop_table("calculation_statuses")
