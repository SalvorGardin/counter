"""0120 recreate diagnostics for normalized risk-factor matches.

Revision ID: a31c9d7e5b20
Revises: 7f2a9c184b6d
"""

# ruff: noqa: E501 -- schema checks mirror the catalog constraints verbatim.

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "a31c9d7e5b20"
down_revision: str | None = "7f2a9c184b6d"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _create_normalized_matches() -> None:
    op.create_table(
        "risk_factor_matches",
        sa.Column("risk_factor_match_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("trigger_code", sa.String(), nullable=False),
        sa.Column("risk_factor_code", sa.String(), nullable=False),
        sa.Column("factor_description", sa.String(), nullable=False),
        sa.Column("reasoning", sa.String(), nullable=True),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("value_type", sa.String(), nullable=False),
        sa.Column("operator", sa.String(), nullable=False),
        sa.Column("value_num", sa.Numeric(), nullable=True),
        sa.Column("min_value", sa.Numeric(), nullable=True),
        sa.Column("max_value", sa.Numeric(), nullable=True),
        sa.Column("value_text", sa.String(), nullable=True),
        sa.Column("gender", sa.String(), nullable=True),
        sa.Column("modifiability", sa.String(), nullable=False),
        sa.Column("is_representative", sa.Boolean(), nullable=False),
        sa.Column("date_time", sa.TIMESTAMP(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("value_type IN ('text', 'number')", name="ck_risk_factor_matches_value_type"),
        sa.CheckConstraint(
            "operator IN ('eq', 'gt', 'gte', 'lt', 'lte', 'between')", name="ck_risk_factor_matches_operator"
        ),
        sa.CheckConstraint("gender IS NULL OR gender IN ('Мужской', 'Женский')", name="ck_risk_factor_matches_gender"),
        sa.CheckConstraint(
            "(value_type = 'text' AND operator = 'eq' AND value_text IS NOT NULL AND value_num IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator IN ('gt', 'gte', 'lt', 'lte') AND value_num IS NOT NULL AND value_text IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator = 'between' AND value_num IS NULL AND value_text IS NULL AND min_value IS NOT NULL AND max_value IS NOT NULL AND min_value <= max_value)",
            name="ck_risk_factor_matches_value_shape",
        ),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            ["patients.patient_id"],
            name="fk_risk_factor_matches_patients_patient_id",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["patient_id", "system_code"],
            ["interpretation_statuses.patient_id", "interpretation_statuses.system_code"],
            name="fk_risk_factor_matches_interpretation_status",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("risk_factor_match_id", name="pk_risk_factor_matches"),
        sa.UniqueConstraint(
            "patient_id",
            "system_code",
            "trigger_code",
            name="uq_risk_factor_matches_patient_system_trigger",
        ),
    )


def upgrade() -> None:
    # Diagnostic history is intentionally disposable; application results are untouched.
    #
    # Known and accepted constraint: the reset covers interpretation_statuses and
    # calculation_statuses too, not just the table this migration rebuilds. The three are read as
    # one picture (see _load_diagnostics in src/explanation/service.py) — keeping statuses whose
    # matches no longer exist would show calculation reasons next to an empty factor list and read
    # as a model verdict. In production collection is off and the tables are empty; on a stand with
    # calc_status_collection_enabled=true the accumulated diagnostics are dropped and refill on the
    # next run.
    op.drop_table("risk_factor_matches")
    op.execute("DELETE FROM interpretation_statuses")  # migration-safety: intentional diagnostic reset
    op.execute("DELETE FROM calculation_statuses")  # migration-safety: intentional diagnostic reset
    _create_normalized_matches()


def downgrade() -> None:
    op.drop_table("risk_factor_matches")
    op.execute("DELETE FROM interpretation_statuses")  # migration-safety: normalized diagnostics are lossy
    op.execute("DELETE FROM calculation_statuses")  # migration-safety: normalized diagnostics are lossy
    op.create_table(
        "risk_factor_matches",
        sa.Column("risk_factor_match_id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("system_code", sa.String(), nullable=False),
        sa.Column("risk_factor_id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(), nullable=False),
        sa.Column("parameter_code", sa.String(), nullable=False),
        sa.Column("param_value", sa.String(), nullable=True),
        sa.Column("min_param_value", sa.String(), nullable=True),
        sa.Column("max_param_value", sa.String(), nullable=True),
        sa.Column("modifiability", sa.String(), nullable=False),
        sa.Column("is_representative", sa.Boolean(), nullable=False),
        sa.Column("superseded_by_risk_factor_id", sa.Integer(), nullable=True),
        sa.Column("date_time", sa.TIMESTAMP(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            ["patients.patient_id"],
            name="fk_risk_factor_matches_patients_patient_id",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("risk_factor_match_id", name="pk_risk_factor_matches"),
        sa.UniqueConstraint(
            "patient_id",
            "system_code",
            "risk_factor_id",
            name="uq_risk_factor_matches_patient_id_system_code_risk_factor_id",
        ),
    )
