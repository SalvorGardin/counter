"""0147_create_patient_calculation_versions

Revision ID: 3b1f7c9d4e2a
Revises: 7918bbab2957
Create Date: 2026-09-22 10:00:00.000000

Реестр версий расчёта: какой версией посчитан риск-профиль каждого пациента. По нему
определяется когорта массового пересчёта — строки, чья версия отличается от версии работающего
релиза (`calculation-version.json`, см. `src/calc/version.py`).

Таблица живёт в схеме расчёта: она описывает состояние расчёта, а не данные профиля. Владелец и
права выдаются здесь же — прав на будущие объекты в этих схемах не наследуется ниоткуда
(см. 0146 и тест `test_a_new_table_needs_owner_and_grants_from_its_own_migration`).

Бутстрап в той же миграции обязателен, а не желателен: отсутствие строки означает «пациент не
считался никогда» и выводит его из когорты, поэтому по пустому реестру первый же прогон не нашёл
бы ни одного уже посчитанного пациента и возможность оказалась бы мёртвой при живых тестах.
Источник — `results`: наличие там строк и означает, что профиль считался. Версия проставляется
заглушкой `bootstrap`, а не текущей: профили считались разными поколениями справочников, и
объявлять их актуальными значило бы записать неправду. Следствие принято сознательно — первый
прогон берёт в когорту всех уже посчитанных пациентов, а растягивает его политика допуска
фоновых команд.

Проверка после выката (входит в `deploy/DEPLOY.txt`): число строк реестра равно числу различных
пациентов в `results`. В проекте уже был случай, когда бэкфилл-миграция не отработала на проде
незамеченной.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "3b1f7c9d4e2a"
down_revision: str | None = "7918bbab2957"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

CALCULATION_SCHEMA = "risk_calculation"
PROFILE_SCHEMA = "risk_profile"
CALCULATION_OWNER = "risk_calculation_owner"
CALCULATION_APP = "risk_calculation_app"
TABLE = "patient_calculation_versions"
QUALIFIED = f"{CALCULATION_SCHEMA}.{TABLE}"
# Заглушка бутстрапа. Дублирует `BOOTSTRAP_CALCULATION_VERSION` из `src/calc/version.py`
# литералом намеренно: миграция — исторический артефакт и не должна меняться вслед за кодом.
BOOTSTRAP_VERSION = "bootstrap"

# Сам бутстрап-запрос вынесен константой: его проверяет integration-тест на населённой базе,
# а прогонять ради этого всю цепочку миграций заново незачем.
# Имена схемы и таблицы — захардкоженные константы модуля, не пользовательский ввод.
BOOTSTRAP_SQL = (
    f"INSERT INTO {QUALIFIED} (patient_id, calculation_version, calculated_at) "  # nosec B608
    f"SELECT r.patient_id, '{BOOTSTRAP_VERSION}', MAX(r.date_time) "
    f"FROM {CALCULATION_SCHEMA}.results AS r "
    "GROUP BY r.patient_id "
    "ON CONFLICT (patient_id) DO NOTHING"
)


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("patient_id", sa.String(), nullable=False),
        sa.Column("calculation_version", sa.String(), nullable=False),
        sa.Column("calculated_at", sa.TIMESTAMP(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(
            ["patient_id"],
            [f"{PROFILE_SCHEMA}.patients.patient_id"],
            name=op.f("fk_patient_calculation_versions_patients_patient_id"),
            # CASCADE, в отличие от `results` с их RESTRICT: строка реестра производна от расчёта
            # и аудитным следом не является. С RESTRICT она держала бы удаление пациента, а
            # чистить её вручную было бы некому — прав на реестр за пределами расчёта нет.
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("patient_id", name=op.f("pk_patient_calculation_versions")),
        schema=CALCULATION_SCHEMA,
    )
    op.execute(f"ALTER TABLE {QUALIFIED} OWNER TO {CALCULATION_OWNER}")
    # Логин расчёта распоряжается своими таблицами полностью — тот же набор прав, что и на
    # остальных таблицах схемы расчёта (см. матрицу прав в tests/integration/db_isolation).
    # Пишущий код реестр не чистит: строка пациента только обновляется.
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {QUALIFIED} TO {CALCULATION_APP}")

    # Индекс по версии обслуживает единственный запрос продюсера прогона: «строки, чья версия
    # отличается от текущей». Он же делает дешёвым замер размера когорты на входе и выходе.
    op.create_index(
        op.f("ix_patient_calculation_versions_calculation_version"),
        TABLE,
        ["calculation_version"],
        schema=CALCULATION_SCHEMA,
    )

    # Бутстрап по уже посчитанным пациентам. `calculated_at` берём по последнему результату
    # пациента, а не `now()`: отметка обязана говорить, когда профиль действительно считался.
    # ON CONFLICT DO NOTHING держит миграцию идемпотентной при upgrade→downgrade→upgrade.
    op.execute(sa.text(BOOTSTRAP_SQL))


def downgrade() -> None:
    # Данные реестра при откате теряются намеренно: они производны от `results` и
    # восстанавливаются повторным бутстрапом, а хранить их в откате негде.
    op.drop_index(
        op.f("ix_patient_calculation_versions_calculation_version"),
        table_name=TABLE,
        schema=CALCULATION_SCHEMA,
    )
    op.drop_table(TABLE, schema=CALCULATION_SCHEMA)
