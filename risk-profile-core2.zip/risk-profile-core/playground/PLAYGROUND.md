# Calc Playground

Локальный стенд, который гоняет пересчёт (`run_recalc`) без Kafka и без API-контейнера, но с поднятым
рядом cvd-сервисом ССЗ — чтобы прогон ходил в реальный ML-сервис по сети, как на боевом сервере.
Нужен, чтобы прогонять расчёты на реальных данных из БД и мерить их скорость.

Точка входа wire-faithful: каждый запрос из JSON-файла — это payload топика `recalc_commands`,
он проходит через `decode_command` → `run_recalc` (ровно как `_handle_command` в `calc_consumer`),
с замером времени каждой команды.

## Что нужно

- Docker + docker compose.
- `.env` в корне (как для обычного стека). Playground принудительно форсит
  `RISK_MODEL_KAFKA__ENABLED=false` (брокер не нужен) и `RISK_MODEL_CVD__ENABLED=true` — cvd поднимается
  и вызывается по compose-сети (`http://cvd:<port>`).
- Соседний checkout **risk-profile-cvd** (по умолчанию `../risk-profile-cvd`, переопределяется
  `CVD_CONTEXT`) — из него собирается образ cvd. Без него сборка playground упадёт.
- Пациенты (`clientId`) должны **уже существовать в БД**. Playground сидит только каталог
  (через миграции), но НЕ ответы пациентов — их заводят отдельно (testing-API / дамп / dev-БД).
  Каталог (инструменты, параметры, шкалы) заполняется миграциями автоматически.

## Файл запросов

`playground/requests.json` — JSON-объект `{ "имя_кейса": payload }`. Правится без пересборки образа
(каталог `./playground` смонтирован в контейнер). Стартовый шаблон — `playground/requests.example.json`
(этот файл в git; `requests.json` — в `.gitignore`, чтобы не коммитить реальные id).

```json
{
  "full_recalc":     { "clientId": "<patient-uuid>", "parameterCodes": null },
  "partial_example": { "clientId": "<patient-uuid>", "parameterCodes": ["age"] }
}
```

- `clientId` (str) — id пациента.
- `parameterCodes`: `null` — полный пересчёт; список — частичный; `[]` — no-op.

Первый запуск:

```bash
cp playground/requests.example.json playground/requests.json
# отредактируйте clientId на реальные id из вашей БД
```

## Запуск

Дефолтный прогон (весь `requests.json`):

```bash
docker compose -f docker-compose.playground.yml run --rm --build playground
```

Выбрать конкретные кейсы + повторить N раз (для стабильного среднего):

```bash
docker compose -f docker-compose.playground.yml run --rm playground \
  python -m playground.calc_playground --file /app/playground/requests.json --repeat 3 full_recalc partial_example
```

CLI:

- `--file` (обяз.) — путь к JSON-файлу запросов (в контейнере это `/app/playground/requests.json`).
- `--repeat N` — прогнать выбранный набор N раз (по умолчанию 1).
- `KEY ...` — какие ключи гонять; без ключей — все из файла.

> Используем `run --rm`, а не `up --abort-on-container-exit`: миграции — one-shot и штатно выходят
> кодом 0, при `--abort-on-container-exit` этот выход снёс бы сеть/БД в момент старта playground.

## Вывод

```
key              run     patient              ms  status   calcs
full_recalc      1/1     00000000-000       22.4  ok          12
partial_example  1/1     00000000-000        7.6  ok           1
--- summary ---
count=2  total=30.0ms  mean=15.0ms
p95=22.4ms  p99=22.4ms  max=22.4ms
per-key mean:  full_recalc=22.4ms  partial_example=7.6ms
--- recalculated instruments (per key) ---
full_recalc: airi_ssz, bdi, gad7, phq9, ...
partial_example: phq9
```

- `status`: `ok` — отработал без исключения; `no-op` — пустой `parameterCodes`; `invalid` — битый payload.
- `ok` означает «прошёл без ошибки на нашей стороне», а не гарантию записи строк: если `clientId`
  нет в БД, `run_recalc` штатно пропустит расчёт (в логах — `skipped`), но команда всё равно замерится.
- `calcs` — сколько калькуляторов реально записали результат в этом прогоне (пропущенные/неприменимые
  не считаются). Секция `recalculated instruments (per key)` перечисляет их коды по каждому ключу
  (объединение по повторам). `calcs=0` / `(none)` — ничего не пересчиталось (нет данных пациента,
  всё пропущено или внутренний сбой — детали в логах).
- `p95` / `p99` / `max` — перцентили (nearest-rank) и максимум времени по ВСЕМ прогонам: показывают
  хвост (самые долгие пересчёты), а не только среднее. Информативны при `--repeat N` с бо́льшим N.

## Убрать за собой

Одноразовый том БД удаляется вместе со стеком:

```bash
docker compose -f docker-compose.playground.yml down -v
```
