"""Дифф-прогон баллов опросников: снятый SQL против `build_questionnaire_scores`.

Зачем нужен отдельный скрипт. Юнит- и интеграционные тесты `build_questionnaire_scores`
проверяют функцию против ОЖИДАЕМЫХ значений, выписанных руками по докстрингу снятого SQL.
Это не перекрёстная проверка: ошибка в понимании outer join / coalesce / приоритета
`value` над диапазоном попадёт и в реализацию, и в ожидания теста одинаково — и тест
пройдёт. Здесь независимый оракул — сам PostgreSQL, исполняющий ИСХОДНЫЙ запрос дословно
(`git show 2fd2441^:src/calc/infra/reader.py`, метод `load_questionnaire_scores`). Совпали
две реализации на реальных данных — значит перенос семантики верен; разошлись — скрипт
печатает конкретные пары и слагаемые.

Запуск внутри контейнера playground (нужна заполненная БД):
    python /app/playground/_parity_questionnaire_scores.py                 # все пациенты
    python /app/playground/_parity_questionnaire_scores.py --limit 500
    python /app/playground/_parity_questionnaire_scores.py --patients p1 p2
    python /app/playground/_parity_questionnaire_scores.py --chunk 200 --show 50

Код возврата: 0 — расхождений нет, 1 — есть (годится для CI-гейта).

Обе реализации читают в ОДНОЙ транзакции, без commit'а между ними. Это не мелочь:
критерий актуальности ответа — `expiration_date >= now()`, а `now()` в PostgreSQL — время
НАЧАЛА ТРАНЗАКЦИИ. В разных транзакциях строка, истекающая между двумя запросами, попала бы
в один результат и не попала в другой, и скрипт показал бы ложное расхождение.
"""

import argparse
import asyncio
import sys
from decimal import Decimal

from sqlalchemy import Numeric, case, cast, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func

from src.calc.infra.reader import CalcReader
from src.config import ServiceRuntime
from src.infra.catalog.base import load_catalog
from src.infra.catalog.calc import CalcCatalog
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.models.instrument import Instrument
from src.models.instrument_parameter import InstrumentParameter
from src.models.parameter_scores import Score
from src.models.patient import Patient
from src.models.patient_parameter import PatientParameter
from src.models.system_instrument import SystemInstrument

ScoreMap = dict[tuple[str, str], Decimal]


async def legacy_questionnaire_scores(session: AsyncSession, patient_ids: list[str]) -> ScoreMap:
    """Снятый SQL, перенесённый СЮДА ДОСЛОВНО. Править только при сверке с git — это эталон.

    Источник: `git show 2fd2441^:src/calc/infra/reader.py`, `CalcReader.load_questionnaire_scores`.
    Ни одной «мелкой чистки»: любое отличие превращает оракул в ещё одну реализацию автора.
    """
    # Safe numeric cast: returns NULL for non-numeric strings, avoiding cast errors on range comparisons
    safe_numeric = case(
        (PatientParameter.value.op("~")(r"^-?[0-9]+(\.[0-9]+)?$"), cast(PatientParameter.value, Numeric(12, 6))),
        else_=None,
    )
    stmt = (
        select(
            PatientParameter.patient_id,
            InstrumentParameter.instrument_code,
            # STEP 4: sum scores per (patient, instrument); missing matches → 0
            func.sum(func.coalesce(Score.score, Decimal("0"))).label("score"),
        )
        # STEP 2: link patient answers to instruments via instruments_parameters
        .join(InstrumentParameter, InstrumentParameter.parameter_code == PatientParameter.parameter_code)
        .join(
            Instrument,
            (Instrument.code == InstrumentParameter.instrument_code)
            & (Instrument.type == Instrument.TYPE_QUESTIONNAIRE)
            & (Instrument.status == Instrument.STATUS_ACTIVE),
        )
        .join(SystemInstrument, SystemInstrument.instrument_code == InstrumentParameter.instrument_code)
        # STEP 1: parameter_code match + (exact value OR within [min_value, max_value])
        .outerjoin(
            Score,
            (Score.parameter_code == PatientParameter.parameter_code)
            & (Score.system_code == SystemInstrument.system_code)
            & or_(
                Score.value == PatientParameter.value,
                (Score.value.is_(None))
                & Score.min_value.isnot(None)
                & Score.max_value.isnot(None)
                & (safe_numeric >= Score.min_value)
                & (safe_numeric <= Score.max_value),
            ),
        )
        .where(
            PatientParameter.patient_id.in_(patient_ids),
            PatientParameter.value.isnot(None),
            PatientParameter.expiration_date >= func.now(),
        )
        # STEP 2: group by patient + instrument
        .group_by(PatientParameter.patient_id, InstrumentParameter.instrument_code)
    )
    result = await session.execute(stmt)
    return {(patient_id, instrument_code): score for patient_id, instrument_code, score in result.all()}


async def current_questionnaire_scores(session: AsyncSession, catalog: CalcCatalog, patient_ids: list[str]) -> ScoreMap:
    """Текущий путь целиком: тот же снимок пациента, что в проде, затем чистая функция."""
    reader = CalcReader(session, catalog)
    snapshot = await reader.load_patient_snapshot(patient_ids)
    rows = reader.build_questionnaire_scores(snapshot.rows)
    return {(r.patient_id, r.instrument_code): r.score for r in rows}


def compare(legacy: ScoreMap, current: ScoreMap) -> list[tuple[tuple[str, str], str, str]]:
    """Расхождения как (ключ, что было в SQL, что стало). `—` = пары нет вовсе.

    Значения сравниваются как Decimal, то есть по величине: `0` и `0.00` — не расхождение
    (SQL возвращает сумму в шкале колонки, память — в шкале слагаемых). Пропажа/появление
    ПАРЫ при этом расхождение всегда, даже с нулевым баллом: пара с нулём и отсутствие пары —
    разные вещи для вызывающего (см. outer join + coalesce в докстринге функции).
    """
    diffs: list[tuple[tuple[str, str], str, str]] = []
    for key in sorted(legacy.keys() | current.keys()):
        old, new = legacy.get(key), current.get(key)
        if old is None or new is None or old != new:
            diffs.append((key, "—" if old is None else str(old), "—" if new is None else str(new)))
    return diffs


async def _all_patient_ids(session: AsyncSession, limit: int | None) -> list[str]:
    stmt = select(Patient.patient_id).order_by(Patient.patient_id)
    if limit is not None:
        stmt = stmt.limit(limit)
    return list((await session.execute(stmt)).scalars().all())


async def _main(args: argparse.Namespace) -> int:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    try:
        return await _run(args)
    finally:
        # dispose в ТОМ ЖЕ loop'е, что открывал соединения: пул asyncpg привязан к loop'у,
        # закрытие из другого (например после выхода из asyncio.run) роняет соединения по таймауту.
        await shutdown_primary_runtime()


async def _run(args: argparse.Namespace) -> int:
    async with get_primary_runtime().session_factory() as session:
        catalog = CalcCatalog(await load_catalog(session))

    total_pairs = 0
    all_diffs: list[tuple[tuple[str, str], str, str]] = []
    checked = 0

    async with get_primary_runtime().session_factory() as session:
        patient_ids = args.patients or await _all_patient_ids(session, args.limit)
        if not patient_ids:
            print("[parity] в БД нет пациентов — сравнивать нечего")  # noqa: T201
            return 1
        print(f"[parity] пациентов: {len(patient_ids)}, размер пачки: {args.chunk}")  # noqa: T201

        for start in range(0, len(patient_ids), args.chunk):
            chunk = patient_ids[start : start + args.chunk]
            # Одна транзакция на пачку: `now()` в обоих запросах обязан быть один (см. докстринг
            # модуля). rollback, а не commit — скрипт только читает.
            legacy = await legacy_questionnaire_scores(session, chunk)
            current = await current_questionnaire_scores(session, catalog, chunk)
            await session.rollback()

            total_pairs += len(legacy.keys() | current.keys())
            all_diffs.extend(compare(legacy, current))
            checked += len(chunk)
            print(f"[parity] {checked}/{len(patient_ids)} пациентов, пар {total_pairs}, расхождений {len(all_diffs)}")  # noqa: T201

    print("")  # noqa: T201
    print(f"=== PARITY: пациентов {checked}, пар (объединение) {total_pairs}, расхождений {len(all_diffs)} ===")  # noqa: T201
    if not all_diffs:
        print("[parity] OK — реализации совпали на всех парах")  # noqa: T201
        return 0

    print(f"--- первые {min(args.show, len(all_diffs))} расхождений (patient, instrument, sql → memory) ---")  # noqa: T201
    for (patient_id, instrument_code), old, new in all_diffs[: args.show]:
        print(f"{patient_id:<40} {instrument_code:<24} {old:>12} → {new:>12}")  # noqa: T201
    return 1


def _args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Дифф-прогон снятого SQL против build_questionnaire_scores")
    p.add_argument("--limit", type=int, default=None, help="взять первые N пациентов (по умолчанию — всех)")
    p.add_argument("--chunk", type=int, default=500, help="пациентов в одной пачке сравнения")
    p.add_argument("--show", type=int, default=30, help="сколько расхождений напечатать")
    p.add_argument("--patients", nargs="*", default=None, help="конкретные patient_id вместо выборки из БД")
    return p.parse_args(argv)


if __name__ == "__main__":
    sys.exit(asyncio.run(_main(_args(sys.argv[1:]))))
