"""ORM-сущности против колоночной проекции на `load_patient_snapshot` (нужна БД).

Ридер грузит `select(PatientParameter)` — полные ORM-сущности, каждая с InstanceState,
weakref и записью в identity map, — и тут же схлопывает их в slots-датакласс PatientParameterRow.
Бенч гоняет тот же запрос двумя способами и меряет время + переживших рефкаунт объектов gen0.

Запуск: docker compose -f docker-compose.playground.yml run --rm playground \
          python /app/playground/_bench_orm_vs_core.py
"""

import asyncio
import gc
import sys
from collections import Counter
from time import perf_counter

import uvloop
from sqlalchemy import select
from sqlalchemy.sql import func

sys.path.insert(0, "/app")

from src.calc.domain.models import PatientParameterRow  # noqa: E402
from src.config import ServiceRuntime  # noqa: E402
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime  # noqa: E402
from src.models.patient_parameter import PatientParameter  # noqa: E402

ITER = 200


def _key(obj: object) -> str:
    t = type(obj)
    return f"{getattr(t, '__module__', '?')}.{getattr(t, '__qualname__', '?')}"


def _census() -> Counter:
    objects = gc.get_objects(0)
    counter = Counter(_key(o) for o in objects)
    counter.pop("builtins.list", None)
    del objects
    return counter


_WHERE = (
    PatientParameter.value.isnot(None),
    PatientParameter.expiration_date.isnot(None),
)


async def _orm(session, pids):  # noqa: ANN001, ANN202
    stmt = select(PatientParameter).where(PatientParameter.patient_id.in_(pids), *_WHERE)
    result = await session.execute(stmt)
    return [
        PatientParameterRow(
            patient_parameter_id=row.patient_parameter_id,
            patient_id=row.patient_id,
            parameter_code=row.parameter_code,
            value=row.value,
            source=row.source,
            expiration_date=row.expiration_date,
            date_time=row.date_time,
        )
        for row in result.scalars().all()
        if row.expiration_date is not None
    ]


async def _core(session, pids):  # noqa: ANN001, ANN202
    stmt = select(
        PatientParameter.patient_parameter_id,
        PatientParameter.patient_id,
        PatientParameter.parameter_code,
        PatientParameter.value,
        PatientParameter.source,
        PatientParameter.expiration_date,
        PatientParameter.date_time,
    ).where(PatientParameter.patient_id.in_(pids), *_WHERE)
    result = await session.execute(stmt)
    return [PatientParameterRow(*row) for row in result.all()]


async def _measure(name: str, fn, session, pids) -> None:  # noqa: ANN001
    for _ in range(5):
        await fn(session, pids)
        session.expunge_all()

    gc.collect()
    gc.disable()
    try:
        before = _census()
        rows = await fn(session, pids)
        after = _census()
    finally:
        gc.enable()
    after.subtract(before)
    survivors = {k: v for k, v in after.items() if v > 0}
    row_count = len(rows)
    del rows
    session.expunge_all()

    gc.collect()
    start = perf_counter()
    for _ in range(ITER):
        await fn(session, pids)
        session.expunge_all()
    elapsed_ms = (perf_counter() - start) / ITER * 1000

    print(f"\n--- {name} ---")  # noqa: T201
    print(f"rows={row_count}  time={elapsed_ms:.3f} ms/call  gen0 survivors={sum(survivors.values())}")  # noqa: T201
    for k, v in Counter(survivors).most_common(10):
        print(f"  {v:>4}  {k}")  # noqa: T201


async def _main() -> None:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    async with get_primary_runtime().session_factory() as session:
        pid_rows = await session.execute(select(PatientParameter.patient_id).limit(1))
        pids = [pid_rows.scalar_one()]
        print(f"patient={pids[0]}  now={await session.scalar(select(func.now()))}")  # noqa: T201
        await _measure("ORM entities (current)", _orm, session, pids)
        await _measure("column projection", _core, session, pids)
    await shutdown_primary_runtime()


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main())
