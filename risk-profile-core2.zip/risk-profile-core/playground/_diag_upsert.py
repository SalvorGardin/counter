"""Диагностика фазы upsert: раскладывает время каждой write-транзакции на
   (а) отдельные SQL-стейтменты, (б) pre-ping соединения, (в) BEGIN/COMMIT, (г) Python-остаток.

Каждое окно = один `TransactionalRetryExecutor.run(op, ...)` (одна транзакция).
Внутри окна печатается таймлайн событий: checkout/ping/begin/stmt/commit.

Запуск внутри контейнера playground:
    python -m playground._diag_upsert --file /app/playground/requests.json --repeat 5
"""

import argparse
import asyncio
import os
import sys
from collections import defaultdict
from pathlib import Path
from time import perf_counter

import uvloop
from sqlalchemy import event

import src.infra.db_retry as db_retry
from playground.calc_playground import load_requests, run_one, select_requests
from src.calc.infra.cvd_client import init_cvd_client, shutdown_cvd_client
from src.calc.timings import StepTimings
from src.config import ServiceRuntime
from src.infra.catalog.builder import build_catalogs
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.logger import request_id_var

# (t0, t1, kind, label). kind: stmt | ping | begin | commit | checkout | flush
EVENTS: list[tuple[float, float, str, str]] = []
# (t0, t1, op_name) — окно одной write-транзакции (executor.run)
WINDOWS: list[tuple[float, float, str]] = []

_stmt_start: dict[int, float] = {}


def _label(statement: str) -> str:
    s = " ".join(statement.split())
    return s[:78]


def install_probes() -> None:
    sync_engine = get_primary_runtime().engine.sync_engine

    @event.listens_for(sync_engine, "before_cursor_execute")
    def _before(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001, ANN202
        _stmt_start[id(cursor)] = perf_counter()

    @event.listens_for(sync_engine, "after_cursor_execute")
    def _after(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001, ANN202
        t0 = _stmt_start.pop(id(cursor), None)
        if t0 is None:
            return
        n = ""
        if executemany and isinstance(parameters, (list, tuple)):
            n = f" [executemany x{len(parameters)}]"
        EVENTS.append((t0, perf_counter(), "stmt", _label(statement) + n))

    @event.listens_for(sync_engine, "begin")
    def _begin(conn):  # noqa: ANN001, ANN202
        t = perf_counter()
        EVENTS.append((t, t, "begin", "BEGIN"))

    @event.listens_for(sync_engine, "commit")
    def _commit(conn):  # noqa: ANN001, ANN202
        t = perf_counter()
        EVENTS.append((t, t, "commit", "COMMIT (marker: before)"))

    @event.listens_for(sync_engine, "checkout")
    def _checkout(dbapi_conn, rec, proxy):  # noqa: ANN001, ANN202
        t = perf_counter()
        EVENTS.append((t, t, "checkout", "pool checkout"))

    # pool pre_ping: событий SQLAlchemy не имеет, оборачиваем dialect.do_ping
    dialect = sync_engine.dialect
    orig_ping = dialect.do_ping

    def do_ping(dbapi_connection):  # noqa: ANN001, ANN202
        t0 = perf_counter()
        try:
            return orig_ping(dbapi_connection)
        finally:
            EVENTS.append((t0, perf_counter(), "ping", "pre_ping"))

    dialect.do_ping = do_ping  # ty: ignore[invalid-assignment]

    # окна write-транзакций
    orig_run = db_retry.TransactionalRetryExecutor.run

    async def run(self, op, *a, **kw):  # noqa: ANN001, ANN202, ANN201
        t0 = perf_counter()
        try:
            return await orig_run(self, op, *a, **kw)
        finally:
            WINDOWS.append((t0, perf_counter(), getattr(op, "__name__", repr(op))))

    db_retry.TransactionalRetryExecutor.run = run  # ty: ignore[invalid-assignment]


def _in(t0: float, t1: float) -> list[tuple[float, float, str, str]]:
    return [e for e in EVENTS if e[0] >= t0 and e[0] < t1]


def _report(runs: list[tuple[str, float, float, StepTimings]]) -> None:
    out: list[str] = []
    out.append("=== DIAG: upsert decomposition ===")
    n = len(runs)
    out.append(
        f"runs={n}  mean elapsed={sum((b - a) for _, a, b, _ in runs) / n * 1000:.1f}ms  "
        f"mean calc.upsert={sum(s.upsert_ms for *_, s in runs) / n:.1f}ms  "
        f"mean interp.upsert={sum(s.interpretation.upsert_ms for *_, s in runs) / n:.1f}ms"
    )

    # --- агрегат по типам транзакций
    by_op: dict[str, list[tuple[float, float, str]]] = defaultdict(list)
    for w in WINDOWS:
        by_op[w[2]].append(w)
    out.append("")
    out.append("--- write transactions by op (per-transaction averages) ---")
    out.append(
        f"{'op':<26} {'count':>6} {'win_ms':>8} {'stmt_ms':>8} {'stmts':>6} "
        f"{'ping_ms':>8} {'pings':>6} {'resid_ms':>9} {'total_ms':>9}"
    )
    for op, wins in sorted(by_op.items(), key=lambda kv: -sum(b - a for a, b, _ in kv[1])):
        c = len(wins)
        win_sum = stmt_sum = ping_sum = 0.0
        nstmt = nping = 0
        for a, b, _ in wins:
            win_sum += b - a
            for e0, e1, kind, _lab in _in(a, b):
                if kind == "stmt":
                    stmt_sum += e1 - e0
                    nstmt += 1
                elif kind == "ping":
                    ping_sum += e1 - e0
                    nping += 1
        resid = win_sum - stmt_sum - ping_sum
        out.append(
            f"{op:<26} {c:>6} {win_sum / c * 1000:>8.2f} {stmt_sum / c * 1000:>8.2f} {nstmt / c:>6.1f} "
            f"{ping_sum / c * 1000:>8.2f} {nping / c:>6.1f} {resid / c * 1000:>9.2f} {win_sum * 1000:>9.1f}"
        )

    # --- агрегат по стейтментам внутри write-транзакций
    out.append("")
    out.append("--- statements inside write transactions (aggregated) ---")
    agg: dict[str, list[float]] = defaultdict(list)
    for a, b, op in WINDOWS:
        for e0, e1, kind, lab in _in(a, b):
            if kind == "stmt":
                agg[f"{op} :: {lab}"].append((e1 - e0) * 1000)
    out.append(f"{'count':>6} {'total_ms':>9} {'mean_ms':>8}  statement")
    for lab, vals in sorted(agg.items(), key=lambda kv: -sum(kv[1]))[:25]:
        out.append(f"{len(vals):>6} {sum(vals):>9.1f} {sum(vals) / len(vals):>8.2f}  {lab}")

    # --- таймлайн одного среднего прогона (последний)
    out.append("")
    key, ra, rb, _ = runs[-1]
    out.append(f"--- timeline of last run ({key}, elapsed={(rb - ra) * 1000:.1f}ms) ---")
    for a, b, op in WINDOWS:
        if not (a >= ra and a < rb):
            continue
        out.append(f"  [tx {op}] window={(b - a) * 1000:.2f}ms")
        prev = a
        for e0, e1, kind, lab in _in(a, b):
            out.append(
                f"      +{(e0 - a) * 1000:7.2f}  gap={(e0 - prev) * 1000:6.2f}  "
                f"dur={(e1 - e0) * 1000:6.2f}  {kind:<9} {lab}"
            )
            prev = e1
        out.append(f"      tail gap after last event: {(b - prev) * 1000:.2f}ms")

    print("\n".join(out))  # noqa: T201


async def _main(args: argparse.Namespace) -> None:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    request_id_var.set(f"diag-upsert-{os.getpid()}")
    all_requests = load_requests(args.file)
    selected = select_requests(all_requests, args.keys, args.repeat)

    await init_cvd_client()
    try:
        async with get_primary_runtime().session_factory() as session:
            catalogs = await build_catalogs(session)

        for _, payload in select_requests(all_requests, args.keys, 1):  # warmup, не инструментируем
            await run_one(payload, catalogs=catalogs)
        await asyncio.sleep(2.0)

        install_probes()
        runs = []
        for key, payload in selected:
            outcome = await run_one(payload, catalogs=catalogs)
            if outcome.steps is None:  # битый payload: run_recalc не звался, окна транзакций нет
                continue
            runs.append((key, outcome.started, outcome.ended, outcome.steps))
        _report(runs)
    finally:
        await shutdown_cvd_client()
        await shutdown_primary_runtime()


def _args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="diag_upsert")
    p.add_argument("--file", type=Path, required=True)
    p.add_argument("--repeat", type=int, default=5)
    p.add_argument("keys", nargs="*")
    return p.parse_args(argv)


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main(_args(sys.argv[1:])))
