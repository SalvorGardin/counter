"""Микробенч форм записи: N одиночных INSERT..ON CONFLICT против одного multi-row,
и N транзакций против одной. Все прогоны откатываются (rollback) — данные не меняются.

Запуск в контейнере playground:
    python /app/playground/_bench_upsert_shapes.py
"""

import asyncio
import sys
from datetime import UTC, datetime, timedelta
from time import perf_counter

import uvloop
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert

from src.config import ServiceRuntime
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.models.interpretation import Interpretation
from src.models.interpretation_history import InterpretationHistory
from src.models.result import RESULT_UNIQUE_CONSTRAINT, Result
from src.models.result_history import ResultHistory

REPEAT = 20


class _Row:
    """Плоский снимок строки (detached): ORM-объекты после rollback истекают и тянут lazy-refresh."""

    def __init__(self, **kw: object) -> None:
        self.__dict__.update(kw)


async def _sample_rows(session, n_results: int, n_systems: int):  # noqa: ANN001, ANN202
    """Берём реальные существующие (patient_id, instrument_code, indicator) и system_code."""
    res = (await session.execute(select(Result).limit(n_results))).scalars().all()
    interp = (await session.execute(select(Interpretation).limit(n_systems))).scalars().all()
    res_snap = [
        _Row(
            patient_id=r.patient_id,
            instrument_code=r.instrument_code,
            value=r.value,
            interpretation_status=r.interpretation_status,
            risk_level=r.risk_level,
            applicability=r.applicability,
            unit=r.unit,
            indicator=r.indicator,
        )
        for r in res
    ]
    interp_snap = [
        _Row(
            patient_id=i.patient_id,
            system_code=i.system_code,
            risk_level=i.risk_level,
            diseases=i.diseases,
            risk_factors_code=i.risk_factors_code,
            doctors_code=i.doctors_code,
        )
        for i in interp
    ]
    return res_snap, interp_snap


def _row(r, now: datetime) -> dict:  # noqa: ANN001
    return {
        "patient_id": r.patient_id,
        "instrument_code": r.instrument_code,
        "value": r.value,
        "date_time": now,
        "interpretation_status": r.interpretation_status,
        "expiration_date": now + timedelta(days=30),
        "risk_level": r.risk_level,
        "applicability": r.applicability,
        "unit": r.unit,
        "indicator": r.indicator,
    }


async def bench_results_loop(session, rows: list["_Row"]) -> float:
    """Текущая форма: ORM add_all(history) + N одиночных INSERT..ON CONFLICT."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    session.add_all(ResultHistory(**_row(r, now)) for r in rows)
    for r in rows:
        d = _row(r, now)
        await session.execute(
            insert(Result)
            .values(**d)
            .on_conflict_do_update(
                constraint=RESULT_UNIQUE_CONSTRAINT,
                set_={k: d[k] for k in d if k not in ("patient_id", "instrument_code")},
            )
        )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_results_batch(session, rows: list["_Row"]) -> float:
    """Целевая форма: один core INSERT в history (executemany) + один multi-row INSERT..ON CONFLICT."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    payload = [_row(r, now) for r in rows]
    await session.execute(insert(ResultHistory), payload)
    if True:
        stmt = insert(Result)
        excluded = stmt.excluded
        await session.execute(
            stmt.values(payload).on_conflict_do_update(
                constraint=RESULT_UNIQUE_CONSTRAINT,
                set_={
                    "value": excluded.value,
                    "date_time": excluded.date_time,
                    "interpretation_status": excluded.interpretation_status,
                    "expiration_date": excluded.expiration_date,
                    "risk_level": excluded.risk_level,
                    "applicability": excluded.applicability,
                    "unit": excluded.unit,
                    "indicator": excluded.indicator,
                },
            )
        )
    await session.rollback()
    return (perf_counter() - t0) * 1000


def _irow(i, now: datetime) -> dict:  # noqa: ANN001
    return {
        "patient_id": i.patient_id,
        "system_code": i.system_code,
        "risk_level": i.risk_level,
        "text": None,
        "diseases": i.diseases,
        "risk_factors_code": i.risk_factors_code,
        "doctors_code": i.doctors_code,
        "date_time": now,
    }


async def bench_interp_loop(session, rows: list["_Row"]) -> float:
    """Текущая форма: одна транзакция на систему, ORM history + одиночный upsert."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    for i in rows:
        d = _irow(i, now)
        session.add(InterpretationHistory(**d))
        await session.execute(
            insert(Interpretation)
            .values(**d)
            .on_conflict_do_update(
                constraint="uq_interpretations_patient_id_system_code",
                set_={k: d[k] for k in d if k not in ("patient_id", "system_code", "text")},
            )
        )
        await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_interp_batch(session, rows: list["_Row"]) -> float:
    """Целевая форма: одна транзакция, один core history-insert + один multi-row upsert."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    payload = [_irow(i, now) for i in rows]
    await session.execute(insert(InterpretationHistory), payload)
    if True:
        stmt = insert(Interpretation)
        excluded = stmt.excluded
        await session.execute(
            stmt.values(payload).on_conflict_do_update(
                constraint="uq_interpretations_patient_id_system_code",
                set_={
                    "risk_level": excluded.risk_level,
                    "diseases": excluded.diseases,
                    "risk_factors_code": excluded.risk_factors_code,
                    "doctors_code": excluded.doctors_code,
                    "date_time": excluded.date_time,
                },
            )
        )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_hist_orm(session, rows: list["_Row"]) -> float:
    """Только history: ORM add_all + flush."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    session.add_all(ResultHistory(**_row(r, now)) for r in rows)
    await session.flush()
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_hist_core(session, rows: list["_Row"]) -> float:
    """Только history: core executemany по таблице (без ORM unit-of-work)."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    # `__table__` типизирован как FromClause, хотя в рантайме это Table (ограничение стабов SQLAlchemy).
    await session.execute(
        insert(ResultHistory.__table__),  # ty: ignore[invalid-argument-type]
        [_row(r, now) for r in rows],
    )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_results_multivalues(session, rows: list["_Row"]) -> float:
    """Только results: один multi-row VALUES ON CONFLICT (не кэшируется компилятором)."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    payload = [_row(r, now) for r in rows]
    stmt = insert(Result)
    ex = stmt.excluded
    await session.execute(
        stmt.values(payload).on_conflict_do_update(
            constraint=RESULT_UNIQUE_CONSTRAINT,
            set_={
                "value": ex.value,
                "date_time": ex.date_time,
                "interpretation_status": ex.interpretation_status,
                "expiration_date": ex.expiration_date,
                "risk_level": ex.risk_level,
                "applicability": ex.applicability,
                "unit": ex.unit,
            },
        )
    )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_results_executemany(session, rows: list["_Row"]) -> float:
    """Только results: один стейтмент + executemany-параметры (компиляция кэшируется)."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    payload = [_row(r, now) for r in rows]
    stmt = insert(Result.__table__)  # ty: ignore[invalid-argument-type]
    ex = stmt.excluded
    await session.execute(
        stmt.on_conflict_do_update(
            constraint=RESULT_UNIQUE_CONSTRAINT,
            set_={
                "value": ex.value,
                "date_time": ex.date_time,
                "interpretation_status": ex.interpretation_status,
                "expiration_date": ex.expiration_date,
                "risk_level": ex.risk_level,
                "applicability": ex.applicability,
                "unit": ex.unit,
            },
        ),
        payload,
    )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def bench_interp_executemany(session, rows: list["_Row"]) -> float:
    """interp: одна транзакция, core executemany в history + executemany upsert."""
    t0 = perf_counter()
    now = datetime.now(tz=UTC)
    payload = [_irow(i, now) for i in rows]
    await session.execute(insert(InterpretationHistory.__table__), payload)  # ty: ignore[invalid-argument-type]
    stmt = insert(Interpretation.__table__)  # ty: ignore[invalid-argument-type]
    ex = stmt.excluded
    await session.execute(
        stmt.on_conflict_do_update(
            constraint="uq_interpretations_patient_id_system_code",
            set_={
                "risk_level": ex.risk_level,
                "diseases": ex.diseases,
                "risk_factors_code": ex.risk_factors_code,
                "doctors_code": ex.doctors_code,
                "date_time": ex.date_time,
            },
        ),
        payload,
    )
    await session.rollback()
    return (perf_counter() - t0) * 1000


async def _timeit(name: str, fn, session, rows) -> None:  # noqa: ANN001
    for _ in range(3):  # warmup (компиляция стейтментов в кэш)
        await fn(session, rows)
    samples = [await fn(session, rows) for _ in range(REPEAT)]
    samples.sort()
    print(  # noqa: T201
        f"{name:<28} n_rows={len(rows):<3} mean={sum(samples) / len(samples):7.2f}ms  "
        f"min={samples[0]:6.2f}  p95={samples[int(0.95 * len(samples))]:6.2f}"
    )


async def _main() -> None:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    async with get_primary_runtime().session_factory() as session:
        results, interps = await _sample_rows(session, 22, 13)
        # дедуп по уникальному ключу (multi-row ON CONFLICT не терпит дублей в одном стейтменте)
        results = list({(r.patient_id, r.instrument_code, r.indicator): r for r in results}.values())
        interps = list({(i.patient_id, i.system_code): i for i in interps}.values())
        await session.rollback()
        print(f"sampled results={len(results)} interpretations={len(interps)}")  # noqa: T201

        await _timeit("results: N stmts (current)", bench_results_loop, session, results)
        await _timeit("results: 1 multi-row", bench_results_batch, session, results)
        await _timeit("  history only: ORM add_all", bench_hist_orm, session, results)
        await _timeit("  history only: core exec-many", bench_hist_core, session, results)
        await _timeit("  results only: multi-values", bench_results_multivalues, session, results)
        await _timeit("  results only: executemany", bench_results_executemany, session, results)
        await _timeit("interp: N tx (current)", bench_interp_loop, session, interps)
        await _timeit("interp: 1 tx multi-row", bench_interp_batch, session, interps)
        await _timeit("interp: 1 tx executemany", bench_interp_executemany, session, interps)
    await shutdown_primary_runtime()


if __name__ == "__main__":
    uvloop.install()
    sys.exit(asyncio.run(_main()) or 0)
