"""Дифф-прогон гейта STEP 3: снятый SQL против `build_questionnaire_eligibility`.

Парный скрипт к `_parity_questionnaire_scores.py`, но со СТРОГО МЕНЬШЕЙ областью сравнения —
и это главное, что нужно знать перед тем, как трактовать его вывод.

ЧТО СРАВНИВАЕТСЯ (снятый SQL здесь честный независимый оракул):
  * множество пар «пациент × инструмент» — раньше его давал GROUP BY по джойну
    `patients_parameters × instruments_parameters × instruments`, теперь пересечение множеств
    из каталога (`params_by_questionnaire & answered_codes`). Пара определяет, дойдёт ли
    инструмент до гейта вообще, так что расхождение здесь меняет состав расчёта.
  * `required_answered` — числитель required-params guard'а, у которого ВЫСШИЙ приоритет в
    `QuestionnaireCalculator.ineligibility_reason`. Раньше — `SELECT DISTINCT` по required-
    параметрам плюс отдельная подстановка `patients.is_pregnant`, теперь — пересечение
    множеств. Именно этот счётчик перекрёстной проверки не имел.

ЧТО НЕ СРАВНИВАЕТСЯ И ПОЧЕМУ:
  * Условие 2 гейта с тех пор НАМЕРЕННО переопределено (#190, f9002c6): считалось в ПАРАМЕТРАХ
    (`non_general_total`/`non_general_answered`), стало считаться в применимых пациенту ВОПРОСАХ
    (`applicable_questions`/`progressed_questions`). Снятый SQL для него не оракул, а просто другая
    бизнес-логика: диффать значило бы требовать от кода воспроизводить поведение, которое issue
    специально исправил. Этому счётчику нужны фикстуры от спеки, а не дифф-прогон.
  * Условие 1 (`general_answered`/`general_total`): счётчик раздела «Общие данные» в сравниваемый
    срез не входит, запрос `common_answers_stmt` сюда не переносится.
  * `required_total` тоже не сравнивается отдельно: обе стороны берут его из ОДНОГО вью каталога
    (`required_by_instrument`), сравнение было бы тавтологией — но он участвует в проверке пар.

Оракул: `git show ab28b83:src/calc/infra/reader.py`, `load_questionnaire_eligibility` — последняя
ревизия, где счётчики действительно считал SQL. Единственная правка при переносе: из запроса пар
убрана агрегатная колонка `non_general_answered` (Условие 2 в старом смысле) — она не сравнивается.
На состав GROUP BY колонка не влияет, так что множество пар остаётся дословным.

Критерий актуальности ответа тоже разошёлся намеренно (02fe117): было `expiration_date > now()`,
стало `>= now()`. Здесь сохранено старое `>` — как в оракуле. Разойтись из-за этого может только
строка, истекающая ровно в момент начала транзакции, с точностью до микросекунды.

Запуск внутри контейнера playground (нужна заполненная БД):
    python /app/playground/_parity_questionnaire_eligibility.py                # все пациенты
    python /app/playground/_parity_questionnaire_eligibility.py --limit 500
    python /app/playground/_parity_questionnaire_eligibility.py --patients p1 p2

Код возврата: 0 — расхождений нет, 1 — есть.

Обе реализации читают в ОДНОЙ транзакции, без commit'а: `now()` в PostgreSQL — время начала
транзакции, и в разных транзакциях строка, истекающая между запросами, дала бы ложное расхождение.
"""

import argparse
import asyncio
import sys

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func

from src.calc.infra.reader import CalcReader
from src.config import ServiceRuntime
from src.infra.catalog.base import load_catalog
from src.infra.catalog.calc import CalcCatalog
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.models.instrument import Instrument
from src.models.instrument_parameter import InstrumentParameter
from src.models.patient import Patient
from src.models.patient_parameter import PatientParameter

_IS_PREGNANT_PARAM = "is_pregnant"

# (patient_id, instrument_code) → required_answered. Сравниваемый срез гейта, см. докстринг модуля.
GuardMap = dict[tuple[str, str], int]


async def legacy_eligibility_guard(session: AsyncSession, catalog: CalcCatalog, patient_ids: list[str]) -> GuardMap:
    """Снятый SQL, перенесённый дословно. Править только при сверке с git — это эталон.

    Источник: `git show ab28b83:src/calc/infra/reader.py`, `CalcReader.load_questionnaire_eligibility`.
    Из трёх запросов той версии здесь ровно те, что формируют сравниваемый срез: пары «пациент ×
    инструмент», отвеченные required-параметры и `patients.is_pregnant`. Запрос счётчика раздела
    «Общие данные» (`common_answers_stmt`) не переносится: Условие 1 в сравниваемый срез не входит.
    """
    required_by_instrument: dict[str, set[str]] = {k: set(v) for k, v in catalog.required_by_instrument.items()}
    all_required_params: set[str] = set().union(*required_by_instrument.values()) if required_by_instrument else set()

    # is_pregnant is a special case: its source of truth is patients.is_pregnant (set by the
    # app when cq_030 is submitted), not patient_parameters.
    pregnant_answered: set[str] = set()
    if _IS_PREGNANT_PARAM in all_required_params:
        pregnant_stmt = select(Patient.patient_id).where(
            Patient.patient_id.in_(patient_ids),
            Patient.is_pregnant.isnot(None),
        )
        pregnant_answered = {pid for (pid,) in (await session.execute(pregnant_stmt)).all()}

    # Per patient: which required params they answered (valid, unexpired). is_pregnant
    # is folded in via pregnant_answered (source = patients.is_pregnant, not patient_parameters).
    required_answered_by_patient: dict[str, set[str]] = {}
    table_required_params = all_required_params - {_IS_PREGNANT_PARAM}
    if table_required_params:
        required_answers_stmt = (
            select(PatientParameter.patient_id, PatientParameter.parameter_code)
            .where(
                PatientParameter.parameter_code.in_(table_required_params),
                PatientParameter.patient_id.in_(patient_ids),
                PatientParameter.value.isnot(None),
                PatientParameter.expiration_date > func.now(),
            )
            .distinct()
        )
        for pid, pcode in (await session.execute(required_answers_stmt)).all():
            required_answered_by_patient.setdefault(pid, set()).add(pcode)

    # Per (patient, questionnaire instrument): the pair key itself = the engagement universe
    # (the patient answered ≥1 of the instrument's params).
    answered_pairs_stmt = (
        select(PatientParameter.patient_id, InstrumentParameter.instrument_code)
        .join(InstrumentParameter, InstrumentParameter.parameter_code == PatientParameter.parameter_code)
        .join(
            Instrument,
            (Instrument.code == InstrumentParameter.instrument_code)
            & (Instrument.type == Instrument.TYPE_QUESTIONNAIRE)
            & (Instrument.status == Instrument.STATUS_ACTIVE),
        )
        .where(
            PatientParameter.patient_id.in_(patient_ids),
            PatientParameter.value.isnot(None),
            PatientParameter.expiration_date > func.now(),
        )
        .group_by(PatientParameter.patient_id, InstrumentParameter.instrument_code)
    )
    answered_pairs = {(pid, ic) for pid, ic in (await session.execute(answered_pairs_stmt)).all()}

    guard: GuardMap = {}
    for patient_id, instrument_code in answered_pairs:
        required_params = required_by_instrument.get(instrument_code, set())
        required_answered = len(required_params & required_answered_by_patient.get(patient_id, set()))
        if _IS_PREGNANT_PARAM in required_params and patient_id in pregnant_answered:
            required_answered += 1
        guard[(patient_id, instrument_code)] = required_answered
    return guard


async def current_eligibility_guard(session: AsyncSession, catalog: CalcCatalog, patient_ids: list[str]) -> GuardMap:
    """Текущий путь целиком: тот же снимок пациента, что в проде, затем чистая функция."""
    reader = CalcReader(session, catalog)
    snapshot = await reader.load_patient_snapshot(patient_ids)
    eligibility = reader.build_questionnaire_eligibility(patient_ids, snapshot.rows, snapshot.patient_data)
    return {key: e.required_answered for key, e in eligibility.items()}


def compare(legacy: GuardMap, current: GuardMap) -> list[tuple[tuple[str, str], str, str]]:
    """Расхождения как (ключ, что было в SQL, что стало). `—` = пары нет вовсе.

    Пропажа или появление ПАРЫ — расхождение всегда, даже при одинаковом счётчике: пары решают,
    какие инструменты вообще доходят до гейта.
    """
    diffs: list[tuple[tuple[str, str], str, str]] = []
    for key in sorted(legacy.keys() | current.keys()):
        old, new = legacy.get(key), current.get(key)
        if old is None or new is None or old != new:
            diffs.append((key, "—" if old is None else str(old), "—" if new is None else str(new)))
    return diffs


async def _all_patient_ids(session: AsyncSession, limit: int | None) -> list[str]:
    stmt = select(Patient.patient_id).order_by(Patient.patient_id)
    if limit is not None:
        stmt = stmt.limit(limit)
    return list((await session.execute(stmt)).scalars().all())


async def _main(args: argparse.Namespace) -> int:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    try:
        return await _run(args)
    finally:
        # dispose в ТОМ ЖЕ loop'е, что открывал соединения: пул asyncpg привязан к loop'у.
        await shutdown_primary_runtime()


async def _run(args: argparse.Namespace) -> int:
    async with get_primary_runtime().session_factory() as session:
        catalog = CalcCatalog(await load_catalog(session))

    total_pairs = 0
    all_diffs: list[tuple[tuple[str, str], str, str]] = []
    checked = 0

    async with get_primary_runtime().session_factory() as session:
        patient_ids = args.patients or await _all_patient_ids(session, args.limit)
        if not patient_ids:
            print("[parity] в БД нет пациентов — сравнивать нечего")  # noqa: T201
            return 1
        print(f"[parity] пациентов: {len(patient_ids)}, размер пачки: {args.chunk}")  # noqa: T201
        print("[parity] сравниваются: множество пар и required_answered (см. докстринг модуля)")  # noqa: T201

        for start in range(0, len(patient_ids), args.chunk):
            chunk = patient_ids[start : start + args.chunk]
            # Одна транзакция на пачку: `now()` в обоих путях обязан быть один.
            legacy = await legacy_eligibility_guard(session, catalog, chunk)
            current = await current_eligibility_guard(session, catalog, chunk)
            await session.rollback()

            total_pairs += len(legacy.keys() | current.keys())
            all_diffs.extend(compare(legacy, current))
            checked += len(chunk)
            print(f"[parity] {checked}/{len(patient_ids)} пациентов, пар {total_pairs}, расхождений {len(all_diffs)}")  # noqa: T201

    print("")  # noqa: T201
    print(f"=== PARITY: пациентов {checked}, пар (объединение) {total_pairs}, расхождений {len(all_diffs)} ===")  # noqa: T201
    if not all_diffs:
        print("[parity] OK — пары и required_answered совпали")  # noqa: T201
        print("[parity] NB: Условия 1–2 гейта не сравнивались — см. докстринг модуля")  # noqa: T201
        return 0

    print(f"--- первые {min(args.show, len(all_diffs))} расхождений (patient, instrument, sql → memory) ---")  # noqa: T201
    for (patient_id, instrument_code), old, new in all_diffs[: args.show]:
        print(f"{patient_id:<40} {instrument_code:<24} {old:>8} → {new:>8}")  # noqa: T201
    return 1


def _args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Дифф-прогон снятого SQL против build_questionnaire_eligibility")
    p.add_argument("--limit", type=int, default=None, help="взять первые N пациентов (по умолчанию — всех)")
    p.add_argument("--chunk", type=int, default=500, help="пациентов в одной пачке сравнения")
    p.add_argument("--show", type=int, default=30, help="сколько расхождений напечатать")
    p.add_argument("--patients", nargs="*", default=None, help="конкретные patient_id вместо выборки из БД")
    return p.parse_args(argv)


if __name__ == "__main__":
    sys.exit(asyncio.run(_main(_args(sys.argv[1:]))))
