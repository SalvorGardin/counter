"""Цена построения SQL-выражений на КАЖДЫЙ вызов ридера (без БД).

Ридер строит `select(...)` заново в каждом вызове. Дерево выражений неизменно — меняются
только значения bind-параметров. Бенч меряет, во что обходится это построение: время и
количество GC-отслеживаемых объектов, переживших рефкаунт (то, что копится к gen0-порогу).

Сессия — заглушка: `execute` кидает сентинел, так что меряется ровно построение выражения
внутри настоящего метода ридера (без дублирования SQL в бенче) и ни одного запроса в БД.

Запуск: docker compose -f docker-compose.playground.yml run --rm --no-deps playground \
          python /app/playground/_bench_stmt_build.py
"""

import asyncio
import gc
import sys
from collections import Counter
from time import perf_counter
from typing import cast

sys.path.insert(0, "/app")

from sqlalchemy.ext.asyncio import AsyncSession  # noqa: E402

from src.calc.infra.reader import CalcReader  # noqa: E402
from src.infra.catalog.calc import CalcCatalog  # noqa: E402


class _StopError(Exception):
    pass


class _StubSession:
    async def execute(self, *args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        raise _StopError


class _StubCatalog:
    instrument_configs = {}
    required_by_instrument = {"form_cvd": frozenset({"gender"})}
    system_codes_by_instrument = {}


def _key(obj: object) -> str:
    t = type(obj)
    return f"{getattr(t, '__module__', '?')}.{getattr(t, '__qualname__', '?')}"


def _census() -> Counter:
    objects = gc.get_objects(0)
    counter = Counter(_key(o) for o in objects)
    counter.pop("builtins.list", None)
    del objects
    return counter


async def _measure(name: str, call, iterations: int = 2000) -> None:  # noqa: ANN001
    # прогрев (первый вызов прогревает кэши типов SQLAlchemy)
    for _ in range(5):
        try:
            await call()
        except _StopError:
            pass

    gc.collect()
    gc.disable()
    try:
        before = _census()
        try:
            await call()
        except _StopError:
            pass
        after = _census()
    finally:
        gc.enable()
    after.subtract(before)
    survivors = {k: v for k, v in after.items() if v > 0}

    gc.collect()
    start = perf_counter()
    for _ in range(iterations):
        try:
            await call()
        except _StopError:
            pass
    elapsed_us = (perf_counter() - start) / iterations * 1e6

    print(f"\n--- {name} ---")  # noqa: T201
    print(f"build time: {elapsed_us:.1f} us/call   gen0 survivors: {sum(survivors.values())}")  # noqa: T201
    for k, v in Counter(survivors).most_common(12):
        print(f"  {v:>4}  {k}")  # noqa: T201


async def _main() -> None:
    # Заглушки повторяют лишь ту часть контракта, которую трогают меряемые методы (execute и
    # несколько полей каталога), поэтому подсовываем их через cast.
    reader = CalcReader(cast("AsyncSession", _StubSession()), cast("CalcCatalog", _StubCatalog()))
    # Значение bind-параметра ни на что не влияет — запрос не исполняется, меряется только
    # построение выражения. Любая строка подойдёт, поэтому берём заведомо несуществующий id.
    pids = ["00000000-0000-0000-0000-000000000000"]

    await _measure("load_patient_snapshot", lambda: reader.load_patient_snapshot(pids))
    await _measure("load_existing_result_keys", lambda: reader.load_existing_result_keys(pids))
    # build_questionnaire_scores / build_questionnaire_eligibility здесь нет намеренно: они больше
    # не строят SQL, а считают STEP-1/2/4 и STEP-3 в памяти по уже загруженным строкам
    # (см. CalcReader).


if __name__ == "__main__":
    asyncio.run(_main())
