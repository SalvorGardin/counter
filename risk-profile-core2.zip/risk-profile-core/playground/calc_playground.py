"""Локальный playground пересчёта: гоняет recalc-команды из JSON-файла прямо в calc-пайплайн.

Запуск: `python -m playground.calc_playground --file requests.json [--repeat N] [KEY ...]`.
Лежит в `playground/` (каталог отсечён `.dockerignore` и в боевой образ не едет) — в контейнер
попадает через bind-mount `./playground:/app/playground`, см. docker-compose.playground.yml.
Ни Kafka, ни API-контейнера — только БД (каталог из миграций) и сам расчёт; cvd-сервис ССЗ
опционален (зовётся, если RISK_MODEL_CVD__ENABLED=true — в compose-playground он включён). Точка входа
wire-faithful: каждый JSON-запрос — это payload топика recalc_commands, он проходит через
`decode_command` и затем `run_recalc` (как `_handle_command` в calc_consumer), с замером времени и
списком инструментов, по которым реально записан результат (возврат `run_recalc`).

Данные ответов пациента playground НЕ сеет — `clientId` из файла должны уже существовать в БД
(сидятся отдельно: testing-API / дамп / dev-БД). Каталог справочников сидится миграциями.
"""

import argparse
import asyncio
import json
import math
import os
import sys
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import uvloop

from src.calc.dispatcher import run_recalc
from src.calc.infra.cvd_client import init_cvd_client, shutdown_cvd_client
from src.calc.recalc_message import RecalcMessageError, decode_command
from src.calc.timings import StepTimings
from src.config import ServiceRuntime, notice_legacy_db_env
from src.exceptions import RiskBaseError
from src.infra.catalog.builder import Catalogs, catalog_builder
from src.infra.database import init_primary_runtime, shutdown_primary_runtime, verify_runtime_login
from src.logger import notice, request_id_var

# Интервал опроса event-loop lag-пробой. Проба просит цикл будить её каждые _LAG_PROBE_INTERVAL_S;
# насколько цикл опаздывает (overshoot) — столько времени он был занят CPU-bound работой и не мог
# обслужить пробу. В serial-прогоне под лимитом в 1 ядро это и есть сигнал насыщения (см. отчёт).
_LAG_PROBE_INTERVAL_S = 0.05

# Прогрев перед замеряемым прогоном: гоняем выбранные команды один раз вхолостую и ждём
# _WARMUP_WAIT_S, чтобы отложенная инициализация (пулы соединений БД/cvd, ленивые кэши каталога,
# разогрев event-loop) устоялась и не оседала в замерах реального прогона.
_WARMUP_WAIT_S = 3.0


class PlaygroundError(RiskBaseError):
    """Ошибка конфигурации прогона: битый файл запросов или неизвестный ключ."""


@dataclass(frozen=True)
class RunOutcome:
    """Результат одного прогона одной команды: что вернул пересчёт и в какие моменты он шёл.

    Границы (`started`/`ended`) — сырые отсчёты `perf_counter`, а не длительность: диагностические
    скрипты (`_diag_spikes`, `_diag_upsert`) по ним вырезают окно прогона из общего потока событий
    SQLAlchemy/GC, а отчёту playground'а хватает производного `elapsed_ms`.
    """

    patient_id: str
    started: float
    ended: float
    status: str  # "ok" | "no-op" | "invalid"
    # Коды инструментов, по которым РЕАЛЬНО записан результат (см. run_recalc/CalcHandler.run).
    instrument_codes: tuple[str, ...] = ()
    # По-шаговые замеры. None для invalid (хендлер не запускался); для no-op sink пустой с `ran=False`.
    steps: StepTimings | None = None

    @property
    def elapsed_ms(self) -> float:
        return (self.ended - self.started) * 1000


@dataclass(frozen=True)
class CommandTiming:
    """Один прогон одной команды: ключ, № повтора, пациент, время, статус, пересчитанные калькуляторы."""

    key: str
    run_index: int
    total_runs: int
    patient_id: str
    elapsed_ms: float
    status: str  # "ok" | "no-op" | "invalid"
    # Коды инструментов, по которым РЕАЛЬНО записан результат (см. run_recalc/CalcHandler.run).
    instrument_codes: tuple[str, ...] = ()
    # По-шаговые замеры (load/formula/questionnaire/upsert/interpretation). None для invalid; для
    # no-op sink пустой с `ran=False`. В step breakdown идут только команды с `steps.ran`.
    steps: StepTimings | None = None


def percentile(sorted_values: list[float], pct: float) -> float:
    """Перцентиль методом nearest-rank по УЖЕ отсортированному списку (не пустому).

    rank = ceil(pct/100 * N), индекс rank-1. Для pct=95/99 на малых N это «худшая из верхних»
    точек — то, ради чего перцентиль тут и считаем (увидеть самые долгие пересчёты)."""
    n = len(sorted_values)
    rank = math.ceil(pct / 100 * n)
    index = min(max(rank, 1), n) - 1
    return sorted_values[index]


async def _lag_probe(interval: float, samples: list[float]) -> None:
    """Фоновая проба event-loop lag: копит overshoot (мс) каждого пробуждения в `samples`.

    Крутится, пока её не отменят (`asyncio.CancelledError` — штатное завершение). На каждой итерации
    просит цикл разбудить её через `interval`; фактическая задержка минус `interval` — это время,
    что цикл был занят и не смог обслужить пробу вовремя.
    """
    while True:
        start = perf_counter()
        await asyncio.sleep(interval)
        samples.append((perf_counter() - start - interval) * 1000)


def _format_lag_section(interval: float, samples: list[float]) -> list[str]:
    """Строки секции event-loop lag для отчёта: count/mean/перцентили/max по overshoot-сэмплам."""
    lines = [f"--- event-loop lag (probe @{interval * 1000:.0f}ms) ---"]
    if not samples:
        lines.append("samples=0  (no lag data)")
        return lines
    ordered = sorted(samples)
    mean = sum(ordered) / len(ordered)
    lines.append(
        f"samples={len(ordered)}  mean={mean:.1f}ms  "
        f"p95={percentile(ordered, 95):.1f}ms  p99={percentile(ordered, 99):.1f}ms  max={ordered[-1]:.1f}ms"
    )
    return lines


def _format_step_breakdown(timings: list[CommandTiming]) -> list[str]:
    """Секция по-шаговых замеров: для каждого шага total/mean/p95/p99/max по всем командам,
    где хендлер реально отработал (`steps.ran`). Та же логика, что и для общего времени в summary.

    Шаги фиксированы (load/formula/cvd/questionnaire/upsert/interpretation). interpretation честно
    показывает 0, когда команде нечего было интерпретировать, — это валидный сэмпл, не отбрасываем.
    Под interpretation идут отступом её под-фазы (см. InterpretationTimings): их сумма чуть меньше
    interpretation_ms (per-patient overhead + session.commit не относятся ни к одной под-фазе).
    Команды invalid/no-op (хендлер не запускался) в агрегат не входят.

    Отступ = вложенность: под `load` и под `interpretation.load` перечислены их async-читатели
    (по одному `await` к БД на строку, см. LoadTimings / InterpretationLoadTimings). Синхронные
    читатели каталога отдельными строками НЕ идут — они отдают вью из RAM и всегда дают 0.
    Сумма вложенных строк меньше родительской: остаток — in-memory работа между чтениями.

    `cvd` — отдельная строка, а не часть `formula`: шаг внешнего вызова ССЗ вложен в шаг `formula`
    и вычтен из него самим sink'ом (см. StepTimings), так что строки не пересекаются и `formula`
    отражает только счёт инструментов в процессе.

    Сбор замеров живёт за флагом `RISK_MODEL_STEP_TIMINGS_ENABLED` (см. StepTimings): при выключенном
    таблица была бы стеной нулей, поэтому печатаем явную подсказку. Решение принимается по самим
    сэмплам (ни один sink не помечен `enabled`), а не повторным чтением настроек, — форматтер
    остаётся чистым. Смотрим только на команды, где хендлер отработал: у invalid/no-op sink не
    тронут и остаётся с дефолтным `enabled=True`, иначе смесь из пустых и обычных команд при
    выключенном сборе печатала бы «(no handler runs)» вместо подсказки про флаг.
    """
    lines = ["--- step breakdown ---"]
    steps = [t.steps for t in timings if t.steps is not None and t.steps.ran]
    if not steps:
        lines.append("(no handler runs)")
        return lines
    if not any(s.enabled for s in steps):
        lines.append("(disabled: set RISK_MODEL_STEP_TIMINGS_ENABLED=true)")
        return lines
    columns: list[tuple[str, list[float]]] = [
        ("load", [s.load_ms for s in steps]),
        ("  parameters", [s.load.parameters_ms for s in steps]),
        ("  quest_scores", [s.load.quest_scores_ms for s in steps]),
        ("  quest_eligibility", [s.load.quest_eligibility_ms for s in steps]),
        ("  existing_keys", [s.load.existing_keys_ms for s in steps]),
        ("  commit", [s.load.commit_ms for s in steps]),
        ("formula", [s.formula_ms for s in steps]),
        ("cvd", [s.cvd_ms for s in steps]),
        ("questionnaire", [s.questionnaire_ms for s in steps]),
        ("upsert", [s.upsert_ms for s in steps]),
        ("interpretation", [s.interpretation_ms for s in steps]),
        ("  load", [s.interpretation.load_ms for s in steps]),
        ("    results", [s.interpretation.load.results_ms for s in steps]),
        ("    active_params", [s.interpretation.load.active_params_ms for s in steps]),
        ("  compute", [s.interpretation.compute_ms for s in steps]),
        ("  upsert", [s.interpretation.upsert_ms for s in steps]),
    ]
    lines.append(f"runs={len(steps)}  (all values in ms)")
    lines.append(f"{'step':<19} {'total':>10} {'mean':>9} {'p95':>9} {'p99':>9} {'max':>9}")
    for name, samples in columns:
        ordered = sorted(samples)
        total = sum(ordered)
        mean = total / len(ordered)
        lines.append(
            f"{name:<19} {total:>10.1f} {mean:>9.1f} "
            f"{percentile(ordered, 95):>9.1f} {percentile(ordered, 99):>9.1f} {ordered[-1]:>9.1f}"
        )
    return lines


def format_report(timings: list[CommandTiming], lag_samples: list[float] | None = None) -> str:
    """Строит текстовый отчёт: строки по командам (со счётчиком пересчитанных калькуляторов) +
    сводка (count/total/mean) + среднее по ключам + список пересчитанных инструментов по каждому ключу.

    Если передан `lag_samples` — добавляет секцию event-loop lag (overshoot пробы в мс).
    """
    if not timings:
        return "no commands run"
    lines = [f"{'key':<16} {'run':<7} {'patient':<12} {'ms':>10}  {'status':<7}  calcs"]
    for t in timings:
        run = f"{t.run_index}/{t.total_runs}"
        calcs = len(t.instrument_codes)
        lines.append(f"{t.key:<16} {run:<7} {t.patient_id[:12]:<12} {t.elapsed_ms:>10.1f}  {t.status:<7}  {calcs:>5}")

    total = sum(t.elapsed_ms for t in timings)
    count = len(timings)
    ordered = sorted(t.elapsed_ms for t in timings)
    lines.append("--- summary ---")
    lines.append(f"count={count}  total={total:.1f}ms  mean={total / count:.1f}ms")
    # Перцентили по времени ВСЕХ прогонов — чтобы видеть хвост (самые долгие пересчёты), а не только среднее.
    lines.append(f"p95={percentile(ordered, 95):.1f}ms  p99={percentile(ordered, 99):.1f}ms  max={ordered[-1]:.1f}ms")

    per_key: dict[str, list[float]] = {}
    for t in timings:
        per_key.setdefault(t.key, []).append(t.elapsed_ms)
    means = "  ".join(f"{k}={sum(v) / len(v):.1f}ms" for k, v in per_key.items())
    lines.append(f"per-key mean:  {means}")

    # Пересчитанные инструменты по ключу: одинаковы между повторами (тот же пациент/параметры),
    # поэтому объединяем по всем прогонам ключа и сортируем. Ключи без результата — тоже показываем.
    codes_by_key: dict[str, set[str]] = {}
    for t in timings:
        codes_by_key.setdefault(t.key, set()).update(t.instrument_codes)
    lines.append("--- recalculated instruments (per key) ---")
    for key, codes in codes_by_key.items():
        listed = ", ".join(sorted(codes)) if codes else "(none)"
        lines.append(f"{key}: {listed}")

    lines.extend(_format_step_breakdown(timings))

    if lag_samples is not None:
        lines.extend(_format_lag_section(_LAG_PROBE_INTERVAL_S, lag_samples))
    return "\n".join(lines)


def load_requests(path: Path) -> dict[str, dict]:
    """Читает JSON-файл именованных запросов. Требует объект {name: payload-object}."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise PlaygroundError(f"requests file must be a JSON object of named requests, got {type(raw).__name__}")
    for name, payload in raw.items():
        if not isinstance(payload, dict):
            raise PlaygroundError(f"request {name!r} must be a JSON object, got {type(payload).__name__}")
    return raw


def select_requests(all_requests: dict[str, dict], keys: list[str], repeat: int) -> list[tuple[str, dict]]:
    """Разрешает ключи (пусто → все, порядок файла), валидирует неизвестные, размножает на repeat."""
    if keys:
        unknown = [k for k in keys if k not in all_requests]
        if unknown:
            available = ", ".join(all_requests) or "(none)"
            raise PlaygroundError(f"unknown request key(s): {', '.join(unknown)}; available: {available}")
        chosen = keys
    else:
        chosen = list(all_requests)
    single_pass = [(k, all_requests[k]) for k in chosen]
    return single_pass * repeat


def _positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("must be >= 1")
    return parsed


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="calc_playground", description="Local calc speed harness.")
    parser.add_argument("--file", type=Path, required=True, help="JSON file of named recalc requests.")
    parser.add_argument("--repeat", type=_positive_int, default=1, help="Run the selected set N times (>=1).")
    parser.add_argument("keys", nargs="*", help="Request keys to run; omit to run all.")
    return parser.parse_args(argv)


async def run_one(payload: dict, *, catalogs: Catalogs) -> RunOutcome:
    """Декодирует payload (wire-faithful) и запускает пересчёт с замером времени.

    Единственная точка запуска команды для всех скриптов `playground/`: отчёт харнесса и
    диагностические прогоны должны мерить один и тот же путь, иначе их цифры несопоставимы.

    RecalcMessageError → статус "invalid" (run_recalc не зовём). Пустой набор кодов → "no-op"
    (run_recalc закоротит сам). Иначе "ok". run_recalc ловит свои исключения внутри, так что
    "ok" = «отработал без исключения на нашей стороне», а не гарантия записи строк.

    `instrument_codes` — коды инструментов, по которым реально записан результат (возврат run_recalc):
    пусто, если ничего не пересчиталось (нет данных пациента / все пропущены / внутренний сбой).

    `steps` — по-шаговый sink `StepTimings` (None для invalid, где хендлер не запускался).
    Для no-op он вернётся с `ran=False` (run_recalc закоротил до хендлера) и в breakdown не войдёт.
    Длительности будут заполнены, только если включён `RISK_MODEL_STEP_TIMINGS_ENABLED`: сбор замеров — feature-flag,
    выключенный по умолчанию, чтобы на боевом пути не исполнялся код профилирования (см. StepTimings).
    """
    try:
        # Отметка постановки в очередь отбрасывается: реплей файла команд — не постановка в
        # очередь, замеры времени пересчёта из playground'а писать нечего.
        command = decode_command(payload)
        patient_id, parameter_codes = command.patient_id, command.parameter_codes
    except RecalcMessageError:
        # Пересчёта не было: границы схлопнуты в одну точку, elapsed_ms = 0.
        now = perf_counter()
        return RunOutcome(patient_id="-", started=now, ended=now, status="invalid")

    status = "no-op" if parameter_codes is not None and not parameter_codes else "ok"
    steps = StepTimings()
    start = perf_counter()
    result = await run_recalc(
        patient_id,
        parameter_codes,
        semaphore=None,
        catalogs=catalogs,
        timings=steps,
    )
    return RunOutcome(
        patient_id=patient_id,
        started=start,
        ended=perf_counter(),
        status=status,
        instrument_codes=tuple(result.processed_codes),
        steps=steps,
    )


async def _run_batch(selected: list[tuple[str, dict]], *, catalogs: Catalogs) -> list[CommandTiming]:
    """Прогоняет выбранные команды последовательно, нумеруя повторы в пределах каждого ключа."""
    total_by_key: dict[str, int] = {}
    for key, _ in selected:
        total_by_key[key] = total_by_key.get(key, 0) + 1

    run_index: dict[str, int] = {}
    timings: list[CommandTiming] = []
    for key, payload in selected:
        run_index[key] = run_index.get(key, 0) + 1
        outcome = await run_one(payload, catalogs=catalogs)
        timings.append(
            CommandTiming(
                key=key,
                run_index=run_index[key],
                total_runs=total_by_key[key],
                patient_id=outcome.patient_id,
                elapsed_ms=outcome.elapsed_ms,
                status=outcome.status,
                instrument_codes=outcome.instrument_codes,
                steps=outcome.steps,
            )
        )
    return timings


async def _main(args: argparse.Namespace) -> None:
    # Playground гоняет тот же пересчёт, что и консюмер, и обязан видеть ту же БД под той же ролью.
    # Логин приносит строка подключения; сверяем с БД (тот же порядок, что в calc_consumer._main).
    notice_legacy_db_env()
    database = init_primary_runtime(ServiceRuntime.CALCULATION)
    await verify_runtime_login(database.engine, ServiceRuntime.CALCULATION)
    request_id_var.set(f"calc-playground-{os.getpid()}")
    all_requests = load_requests(args.file)
    selected = select_requests(all_requests, args.keys, args.repeat)

    # Каталоги строятся ОДИН раз (после миграций) тем же вызовом, что и в боевых точках входа
    # (main.py lifespan / calc_consumer): загрузка + проекции + заморозка стартового heap'а за
    # один проход. Без заморозки замеры ловят паузы ~45мс на хвостовых командах и харнесс
    # перестаёт отражать прод (см. freeze_startup_heap). Пустой каталог → CatalogLoadError.
    # Порядок «каталог, затем клиенты» повторяет боевые точки входа — харнесс должен мерить
    # тот же набор замороженных объектов, что и прод.
    catalogs = await catalog_builder()

    # cvd-клиент: no-op при RISK_MODEL_CVD__ENABLED=false, иначе резидентный httpx-клиент к сервису
    # cvd (в docker-compose.playground.yml он включён и поднят рядом — прогон ходит в реальный ССЗ).
    await init_cvd_client()
    try:
        # Прогрев: один проход выбранных команд вхолостую (repeat игнорируем — хватает одного), затем
        # пауза _WARMUP_WAIT_S. Результаты отбрасываем; проба lag ещё не запущена, так что ни прогрев,
        # ни сон в замеры/lag не попадают. Реальный прогон стартует уже по «прогретым» глобалам.
        warmup = select_requests(all_requests, args.keys, 1)
        notice("calc.playground: warmup", context={"commands": len(warmup), "wait_s": _WARMUP_WAIT_S})
        await _run_batch(warmup, catalogs=catalogs)
        await asyncio.sleep(_WARMUP_WAIT_S)

        notice("calc.playground: starting", context={"commands": len(selected)})
        # Проба event-loop lag крутится параллельно прогону; overshoot её пробуждений = время, что
        # цикл был занят CPU-bound расчётом. Отменяем и дожидаемся до формирования отчёта.
        lag_samples: list[float] = []
        probe = asyncio.create_task(_lag_probe(_LAG_PROBE_INTERVAL_S, lag_samples))
        try:
            timings = await _run_batch(selected, catalogs=catalogs)
        finally:
            probe.cancel()
            with suppress(asyncio.CancelledError):
                await probe
        print(format_report(timings, lag_samples))  # noqa: T201 — dev harness, human-facing report to stdout
    finally:
        await shutdown_cvd_client()
        await shutdown_primary_runtime()


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main(parse_args(sys.argv[1:])))
