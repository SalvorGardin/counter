"""Диагностика аллокаций: сколько GC-отслеживаемых объектов рождает один пересчёт и где.

Две независимые метрики:

  A) gc-события за прогон (gc включён): сколько сборок каждого поколения, суммарная пауза,
     и перепись типов молодого поколения на входе в gen0-сборку — то, что GC реально обходит.

  B) поф_азная перепись (gc выключен, `gc.collect()` перед каждой командой): gen0 «до/после»
     вокруг load / formula / questionnaire / upsert / interpretation. Разница = объекты,
     созданные фазой и пережившие refcount, т.е. ровно то, что копится к gen0-порогу.

Запуск внутри контейнера playground:
    docker compose -f docker-compose.playground.yml run --rm playground \
      python -m playground._diag_alloc --file /app/playground/requests.json \
      --repeat 60 --phase-runs 10
"""

import argparse
import asyncio
import gc
import os
import sys
from collections import Counter
from pathlib import Path
from time import perf_counter

import uvloop

from playground.calc_playground import load_requests, run_one, select_requests
from src.calc.formula_pipeline import FormulaPipeline
from src.calc.handler import CalcHandler
from src.calc.infra.cvd_client import init_cvd_client, shutdown_cvd_client
from src.calc.infra.repository import CalcRepository
from src.calc.questionnaire_pipeline import QuestionnairePipeline
from src.config import ServiceRuntime
from src.infra.catalog.base import freeze_startup_heap
from src.infra.catalog.builder import build_catalogs
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.interpretation.handler import InterpretationHandler
from src.logger import request_id_var

# ------------------------------------------------------------------ helpers


def _key(obj: object) -> str:
    t = type(obj)
    module = getattr(t, "__module__", "?")
    name = getattr(t, "__qualname__", getattr(t, "__name__", "?"))
    return f"{module}.{name}"


def census_gen0() -> Counter:
    """Перепись типов молодого поколения. Свой список из get_objects исключаем."""
    objects = gc.get_objects(0)
    counter = Counter(_key(o) for o in objects)
    counter.pop(f"{type(objects).__module__}.{type(objects).__qualname__}", None)
    del objects
    return counter


# ------------------------------------------------------- A) gc-event probing

GC_STATS: list[tuple[int, float]] = []  # (generation, pause_ms)
GEN0_CENSUS: Counter = Counter()
GEN0_CENSUS_SAMPLES = 0
_gc_t0: dict[int, float] = {}
_census_every = 1
_census_seen = 0


def _install_gc_callback() -> None:
    def cb(phase: str, info: dict) -> None:
        global GEN0_CENSUS_SAMPLES, _census_seen
        gen = info["generation"]
        if phase == "start":
            _gc_t0[gen] = perf_counter()
            if gen == 0:
                _census_seen += 1
                if _census_seen % _census_every == 0:
                    GEN0_CENSUS.update(census_gen0())
                    GEN0_CENSUS_SAMPLES += 1
        else:
            t0 = _gc_t0.pop(gen, None)
            if t0 is not None:
                GC_STATS.append((gen, (perf_counter() - t0) * 1000))

    gc.callbacks.append(cb)


# ------------------------------------------------------ B) per-phase census

PHASES: dict[str, Counter] = {}
PHASE_ORDER = ["load", "formula", "questionnaire", "upsert", "interpretation"]
_phase_depth = 0


def _wrap_async(owner: type, attr: str, phase: str) -> None:
    original = getattr(owner, attr)

    async def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        global _phase_depth
        if _phase_depth:  # вложенный вызов — не двойной учёт
            return await original(*args, **kwargs)
        _phase_depth += 1
        before = census_gen0()
        try:
            return await original(*args, **kwargs)
        finally:
            after = census_gen0()
            after.subtract(before)
            PHASES.setdefault(phase, Counter()).update({k: v for k, v in after.items() if v > 0})
            _phase_depth -= 1

    setattr(owner, attr, wrapper)


def _wrap_sync(owner: type, attr: str, phase: str) -> None:
    original = getattr(owner, attr)

    def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        global _phase_depth
        if _phase_depth:
            return original(*args, **kwargs)
        _phase_depth += 1
        before = census_gen0()
        try:
            return original(*args, **kwargs)
        finally:
            after = census_gen0()
            after.subtract(before)
            PHASES.setdefault(phase, Counter()).update({k: v for k, v in after.items() if v > 0})
            _phase_depth -= 1

    setattr(owner, attr, wrapper)


def install_phase_probes() -> None:
    _wrap_async(CalcHandler, "_load", "load")
    _wrap_async(FormulaPipeline, "process", "formula")
    _wrap_sync(QuestionnairePipeline, "process", "questionnaire")
    _wrap_async(CalcRepository, "upsert_results_batch", "upsert")
    _wrap_async(InterpretationHandler, "run_for", "interpretation")


# ------------------------------------------------------------------ reports


def _report_gc(runs: int) -> str:
    lines = ["=== A) gc events during measured run ==="]
    per_gen: dict[int, list[float]] = {}
    for gen, ms in GC_STATS:
        per_gen.setdefault(gen, []).append(ms)
    lines.append(f"runs={runs}")
    lines.append(f"{'gen':<5} {'collections':>12} {'per-run':>9} {'total ms':>10} {'mean ms':>9} {'max ms':>9}")
    for gen in sorted(per_gen):
        samples = per_gen[gen]
        total = sum(samples)
        lines.append(
            f"{gen:<5} {len(samples):>12} {len(samples) / runs:>9.2f} "
            f"{total:>10.1f} {total / len(samples):>9.3f} {max(samples):>9.2f}"
        )
    if not per_gen:
        lines.append("(no collections)")
    lines.append("")
    lines.append(f"--- gen0 young-generation census at collection start (samples={GEN0_CENSUS_SAMPLES}) ---")
    if GEN0_CENSUS_SAMPLES:
        lines.append(f"{'objects/collection':>19}  type")
        for name, count in GEN0_CENSUS.most_common(40):
            lines.append(f"{count / GEN0_CENSUS_SAMPLES:>19.1f}  {name}")
        lines.append(f"{sum(GEN0_CENSUS.values()) / GEN0_CENSUS_SAMPLES:>19.1f}  TOTAL")
    return "\n".join(lines)


def _report_phases(runs: int) -> str:
    lines = ["", "=== B) gen0 survivors created per phase (gc off, per command) ===", f"commands={runs}"]
    lines.append(f"{'phase':<15} {'objects/run':>12}")
    for phase in PHASE_ORDER:
        counter = PHASES.get(phase)
        if counter is None:
            continue
        lines.append(f"{phase:<15} {sum(counter.values()) / runs:>12.1f}")
    for phase in PHASE_ORDER:
        counter = PHASES.get(phase)
        if not counter:
            continue
        lines.append("")
        lines.append(f"--- {phase}: top types (objects per command) ---")
        for name, count in counter.most_common(25):
            lines.append(f"{count / runs:>12.1f}  {name}")
    return "\n".join(lines)


# --------------------------------------------------------------------- main


async def _main(args: argparse.Namespace) -> None:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    global _census_every
    _census_every = args.census_every
    request_id_var.set(f"calc-diag-alloc-{os.getpid()}")
    all_requests = load_requests(args.file)

    await init_cvd_client()
    try:
        async with get_primary_runtime().session_factory() as session:
            catalogs = await build_catalogs(session)

        freeze_startup_heap()

        warmup = select_requests(all_requests, args.keys, 1)
        for _, payload in warmup:
            await run_one(payload, catalogs=catalogs)
        await asyncio.sleep(1.0)

        # ---- A) gc включён, замеряем реальные сборки
        selected = select_requests(all_requests, args.keys, args.repeat)
        gc.collect()
        _install_gc_callback()
        for _, payload in selected:
            await run_one(payload, catalogs=catalogs)
        gc.callbacks.clear()
        print(_report_gc(len(selected)))  # noqa: T201

        # ---- B) gc выключен, пофазная перепись
        install_phase_probes()
        phase_set = select_requests(all_requests, args.keys, args.phase_runs)
        gc.collect()
        gc.disable()
        try:
            for _, payload in phase_set:
                await run_one(payload, catalogs=catalogs)
                gc.collect()
        finally:
            gc.enable()
        print(_report_phases(len(phase_set)))  # noqa: T201
    finally:
        await shutdown_cvd_client()
        await shutdown_primary_runtime()


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="diag_alloc")
    parser.add_argument("--file", type=Path, required=True)
    parser.add_argument("--repeat", type=int, default=60)
    parser.add_argument("--phase-runs", type=int, default=10)
    parser.add_argument("--census-every", type=int, default=1)
    parser.add_argument("keys", nargs="*")
    return parser.parse_args(argv)


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main(parse_args(sys.argv[1:])))
