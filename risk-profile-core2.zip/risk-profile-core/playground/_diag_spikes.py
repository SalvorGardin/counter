"""Диагностика хвостовых спайков: раскладывает время каждой команды на
   (а) время в БД-стейтментах, (б) паузы GC, (в) необъяснённый Python-side gap.

Запуск внутри контейнера playground:
    python -m playground._diag_spikes --file /app/playground/requests.json --repeat 30

Колонки load_ms/interp_load_ms берутся из `StepTimings` — их сбор за флагом
`RISK_MODEL_STEP_TIMINGS_ENABLED` (боевой дефолт — выключен, в compose playground'а — включён).
Без него они будут нулями; остальная диагностика (БД/GC/gap) от флага не зависит.
"""

import argparse
import asyncio
import gc
import os
import sys
from collections.abc import Sequence
from pathlib import Path
from time import perf_counter

import uvloop
from sqlalchemy import event

from playground.calc_playground import load_requests, percentile, run_one, select_requests
from src.calc.infra.cvd_client import init_cvd_client, shutdown_cvd_client
from src.config import ServiceRuntime
from src.infra.catalog.builder import build_catalogs
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime
from src.logger import request_id_var

# ---------------------------------------------------------------- collectors

STMTS: list[tuple[float, float, str]] = []  # (t0, t1, label)
GC_EVENTS: list[tuple[float, float, int]] = []  # (t0, t1, generation)
POOL: list[tuple[float, float, str]] = []  # (t0, t1, "connect"|"checkout")

_stmt_start: dict[int, float] = {}
_gc_start: dict[int, float] = {}
_pool_start: dict[str, float] = {}


def _label(statement: str) -> str:
    s = " ".join(statement.split())
    return s[:70]


def install_probes() -> None:
    sync_engine = get_primary_runtime().engine.sync_engine

    @event.listens_for(sync_engine, "before_cursor_execute")
    def _before(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001, ANN202
        _stmt_start[id(cursor)] = perf_counter()

    @event.listens_for(sync_engine, "after_cursor_execute")
    def _after(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001, ANN202
        t0 = _stmt_start.pop(id(cursor), None)
        if t0 is not None:
            STMTS.append((t0, perf_counter(), _label(statement)))

    @event.listens_for(sync_engine, "connect")
    def _connect(dbapi_conn, rec):  # noqa: ANN001, ANN202
        POOL.append((perf_counter(), perf_counter(), "connect"))

    @event.listens_for(sync_engine, "checkout")
    def _checkout(dbapi_conn, rec, proxy):  # noqa: ANN001, ANN202
        POOL.append((perf_counter(), perf_counter(), "checkout"))

    def _gc_cb(phase: str, info: dict) -> None:
        gen = info.get("generation", -1)
        if phase == "start":
            _gc_start[gen] = perf_counter()
        else:
            t0 = _gc_start.pop(gen, None)
            if t0 is not None:
                GC_EVENTS.append((t0, perf_counter(), gen))

    gc.callbacks.append(_gc_cb)


def _window(events: Sequence[tuple[float, float, object]], t0: float, t1: float) -> list[tuple[float, float, object]]:
    # Sequence, а не list: у вызывающих последний элемент кортежа конкретный (str/int), а list
    # инвариантен по параметру типа — list[tuple[..., str]] не подошёл бы под list[tuple[..., object]].
    return [e for e in events if e[0] >= t0 and e[0] < t1]


# ---------------------------------------------------------------- run


async def _main(args: argparse.Namespace) -> None:
    # Скрипт гоняет расчёт в контейнере playground — под логином и картой схем расчёта.
    init_primary_runtime(ServiceRuntime.CALCULATION)
    request_id_var.set(f"diag-spikes-{os.getpid()}")
    all_requests = load_requests(args.file)
    selected = select_requests(all_requests, args.keys, args.repeat)

    await init_cvd_client()
    try:
        async with get_primary_runtime().session_factory() as session:
            catalogs = await build_catalogs(session)

        # warmup (не инструментируем)
        for _, payload in select_requests(all_requests, args.keys, 1):
            await run_one(payload, catalogs=catalogs)
        await asyncio.sleep(3.0)

        if args.gc_freeze:
            gc.collect()
            gc.freeze()
            print(f"[diag] gc.freeze() applied; frozen={gc.get_freeze_count()}")  # noqa: T201

        install_probes()

        rows = []
        for i, (key, payload) in enumerate(selected):
            outcome = await run_one(payload, catalogs=catalogs)
            steps = outcome.steps
            if steps is None:  # битый payload: run_recalc не звался, раскладывать нечего
                continue
            t0, t1 = outcome.started, outcome.ended
            stmts = _window(STMTS, t0, t1)
            gcs = _window(GC_EVENTS, t0, t1)
            pools = _window(POOL, t0, t1)
            stmt_ms = sum((b - a) for a, b, _ in stmts) * 1000
            gc_ms = sum((b - a) for a, b, _ in gcs) * 1000
            slowest = max(stmts, key=lambda e: e[1] - e[0], default=None)
            rows.append(
                {
                    "i": i,
                    "key": key,
                    "elapsed_ms": (t1 - t0) * 1000,
                    "load_ms": steps.load_ms,
                    "interp_load_ms": steps.interpretation.load_ms,
                    "stmt_ms": stmt_ms,
                    "stmt_n": len(stmts),
                    "gc_ms": gc_ms,
                    "gc_n": len(gcs),
                    "gc_gens": sorted({g for _, _, g in gcs}),
                    "pool_n": len(pools),
                    "slow_stmt_ms": (slowest[1] - slowest[0]) * 1000 if slowest else 0.0,
                    "slow_stmt": slowest[2] if slowest else "",
                }
            )

        _report(rows)
    finally:
        await shutdown_cvd_client()
        await shutdown_primary_runtime()


def _report(rows: list[dict]) -> None:
    out = []
    el = sorted(r["elapsed_ms"] for r in rows)
    out.append("=== DIAG: spike decomposition ===")
    out.append(
        f"n={len(rows)} mean={sum(el) / len(el):.1f} "
        f"p95={percentile(el, 95):.1f} p99={percentile(el, 99):.1f} max={el[-1]:.1f}"
    )

    gc_tot = sum(r["gc_ms"] for r in rows)
    out.append(
        f"gc: total={gc_tot:.1f}ms  collections={sum(r['gc_n'] for r in rows)}  "
        f"share={gc_tot / sum(el) * 100:.1f}% of wall"
    )

    out.append("")
    out.append("--- all runs (i, key, elapsed, load, iload, stmt_sum, n, gc, gcn, gens, gap) ---")
    for r in rows:
        gap = r["elapsed_ms"] - r["stmt_ms"] - r["gc_ms"]
        out.append(
            f"{r['i']:>4} {r['key']:<14} {r['elapsed_ms']:>7.1f} {r['load_ms']:>6.1f} {r['interp_load_ms']:>6.1f} "
            f"{r['stmt_ms']:>7.1f} {r['stmt_n']:>3} {r['gc_ms']:>6.1f} {r['gc_n']:>3} "
            f"{str(r['gc_gens']):<10} {gap:>7.1f}"
        )

    out.append("")
    out.append("--- top 12 slowest, decomposed ---")
    for r in sorted(rows, key=lambda x: -x["elapsed_ms"])[:12]:
        gap = r["elapsed_ms"] - r["stmt_ms"] - r["gc_ms"]
        out.append(
            f"i={r['i']:<4} {r['key']:<14} elapsed={r['elapsed_ms']:.1f} stmt={r['stmt_ms']:.1f}({r['stmt_n']}) "
            f"gc={r['gc_ms']:.1f}({r['gc_n']},gens={r['gc_gens']}) gap={gap:.1f}"
        )
        out.append(f"      slowest_stmt={r['slow_stmt_ms']:.1f}ms :: {r['slow_stmt']}")

    # baseline vs tail
    med = el[len(el) // 2]
    tail = [r for r in rows if r["elapsed_ms"] > med * 1.3]
    base = [r for r in rows if r["elapsed_ms"] <= med * 1.05]
    out.append("")
    out.append(f"--- tail(>{med * 1.3:.0f}ms) n={len(tail)}  vs  baseline(<={med * 1.05:.0f}ms) n={len(base)} ---")
    for name, grp in (("tail", tail), ("base", base)):
        if not grp:
            continue
        n = len(grp)
        out.append(
            f"{name}: elapsed={sum(r['elapsed_ms'] for r in grp) / n:.1f} "
            f"stmt={sum(r['stmt_ms'] for r in grp) / n:.1f} "
            f"stmt_n={sum(r['stmt_n'] for r in grp) / n:.1f} "
            f"gc={sum(r['gc_ms'] for r in grp) / n:.1f} "
            f"gc_n={sum(r['gc_n'] for r in grp) / n:.2f} "
            f"gap={sum(r['elapsed_ms'] - r['stmt_ms'] - r['gc_ms'] for r in grp) / n:.1f} "
            f"slow_stmt={sum(r['slow_stmt_ms'] for r in grp) / n:.1f}"
        )

    # slowest single statements across whole run
    out.append("")
    out.append("--- top 15 slowest individual statements in run ---")
    for t0, t1, lab in sorted(STMTS, key=lambda e: -(e[1] - e[0]))[:15]:
        out.append(f"{(t1 - t0) * 1000:>8.1f}ms  {lab}")

    # gc events
    out.append("")
    out.append("--- top 15 GC pauses ---")
    for t0, t1, gen in sorted(GC_EVENTS, key=lambda e: -(e[1] - e[0]))[:15]:
        out.append(f"{(t1 - t0) * 1000:>8.1f}ms  gen={gen}")
    print("\n".join(out))  # noqa: T201


def _args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="diag_spikes")
    p.add_argument("--file", type=Path, required=True)
    p.add_argument("--repeat", type=int, default=30)
    p.add_argument("--gc-freeze", action="store_true")
    p.add_argument("keys", nargs="*")
    return p.parse_args(argv)


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main(_args(sys.argv[1:])))
