"""Метрики Prometheus процесса app: единственное место, где создаются метрики сервиса.

Экспозиция — `GET /metrics` (см. `src/main.py`), формат text/plain prometheus, без авторизации.

ЖЁСТКОЕ ПРАВИЛО: модуль НЕ импортирует `src.config` и `src.logger` на уровне модуля. Связка
metrics→config или metrics→logger замкнула бы boot-order ровно так же, как logger→settings в
MR !41 — тем более что счётчик ошибок будет импортироваться сюда из самого логгера. Всё, что
нужно из конфига (версия сервиса), передаётся параметром в `init_metrics`.
"""

import os
import socket
from collections.abc import Iterator

from prometheus_client import (
    GC_COLLECTOR,
    PLATFORM_COLLECTOR,
    PROCESS_COLLECTOR,
    REGISTRY,
    CollectorRegistry,
    Counter,
    Histogram,
    generate_latest,
)
from prometheus_client.core import CounterMetricFamily, GaugeMetricFamily, Metric
from prometheus_client.multiprocess import MultiProcessCollector
from prometheus_client.registry import Collector

from src.metrics_multiproc import MULTIPROC_ENV, ensure_multiproc_dir

SERVICE_PREFIX = "risk_profile_core"

# Лейбл `host` входящих запросов = имя контейнера. Считаем один раз: внутри процесса hostname
# не меняется. Это ИМЕННО hostname контейнера сервиса, а не Host-заголовок клиента — заголовок
# в лейблы класть нельзя (неограниченная кардинальность от произвольного клиента).
HOSTNAME = socket.gethostname()

# Снимок режима, сделанный ОДНОВРЕМЕННО с выбором value-class внутри prometheus_client (тоже при
# импорте). Именно снимок, а не чтение env в рантайме: иначе `render()` могла бы уйти в
# multiprocess-ветку, пока значения метрик лежат в памяти процесса (или наоборот) — и отдать
# пустую, но валидную с виду выдачу. Директорию `src/metrics_multiproc.py` читает из env живьём:
# она про ФС, а не про режим.
_MULTIPROC_PATH = os.environ.get(MULTIPROC_ENV, "")

# /proc-коллектор CPU/RAM. sysconf есть на любом POSIX (в т.ч. macOS), но сам /proc — только
# Linux; на не-Linux коллектор тихо отдаёт пусто (см. _read_proc_stats). Читаем константы один раз.
_PROC_ROOT = "/proc"
_CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
_PAGE_SIZE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096

# Директорию создаём ДО создания метрик ниже по модулю (почему — см. `ensure_multiproc_dir`).
ensure_multiproc_dir()

# --- Счётные метрики: default REGISTRY ---
# В multiprocess-режиме prometheus_client сам пишет их значения в mmap-файлы каждого воркера,
# а MultiProcessCollector на скрейпе суммирует вклад всех воркеров (в т.ч. уже умерших).
# Только Counter/Histogram: Gauge в этом реестре потребовал бы multiprocess_mode=/mark_process_dead
# — если понадобится, сначала пересмотреть этот пункт, а не добавлять молча.

HTTP_REQUEST_DURATION = Histogram(
    f"{SERVICE_PREFIX}_http_request_duration_seconds",
    "Латентность входящих HTTP-запросов",
    ["method", "path", "status", "host"],
)

ERRORS_TOTAL = Counter(
    f"{SERVICE_PREFIX}_errors_total",
    "Число лог-записей уровня ERROR и выше (включая ошибки после отданного ответа)",
    ["level", "component"],
)

# Шкала корзин времени пересчёта — своя, а не дефолтная: у prometheus_client верхняя конечная
# корзина 10 с, а ожидание команды в очереди под нагрузкой в неё не помещается (на нагрузочных
# прогонах p95 доходил до десятков секунд). Выше 30 с разрешение не нужно: такие значения не
# теряются, а попадают в `+Inf` и в любом случае учтены в `_count`/`_sum`.
RECALC_TIMING_BUCKETS = (0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 20.0, 30.0)

# Значения лейблов гистограмм пересчёта. `outcome` — судьба записи результатов команды,
# `scope` — полный пересчёт против частичного, `source` — кто породил команду. Других разрезов
# нет намеренно: patient_id и instrument_code дали бы неограниченную кардинальность. Кортежи
# ниже — полный перечень значений: по ним идёт предынициализация рядов, а пишущая сторона
# (`src/calc/dispatcher.py`) берёт значения из этих же констант, так что разъехаться им негде.
RECALC_OUTCOME_WRITTEN = "written"
RECALC_OUTCOME_EMPTY = "empty"
RECALC_OUTCOME_FAILED = "failed"
RECALC_OUTCOMES = (RECALC_OUTCOME_WRITTEN, RECALC_OUTCOME_EMPTY, RECALC_OUTCOME_FAILED)

RECALC_SCOPE_FULL = "full"
RECALC_SCOPE_PARTIAL = "partial"
RECALC_SCOPES = (RECALC_SCOPE_FULL, RECALC_SCOPE_PARTIAL)

# `source` отделяет пользовательскую команду от команды массового прогона. Без него ряды
# смешивались бы, а смешивать их нельзя: у фоновой команды нет ни ответа пациента, ни человека,
# который ждёт результата, зато очередь она занимает плотнее любого пользовательского трафика.
# В общих рядах `answer_to_result` мерил бы время до события, которого не было, а `queue_wait`
# рос бы от глубины завала фоновых команд — то есть оба SLI переставали бы показывать
# пользовательский опыт ровно на время прогона, когда за ними и надо следить.
RECALC_SOURCE_USER = "user"
RECALC_SOURCE_BACKGROUND = "background"
RECALC_SOURCES = (RECALC_SOURCE_USER, RECALC_SOURCE_BACKGROUND)

RECALC_ANSWER_TO_RESULT = Histogram(
    f"{SERVICE_PREFIX}_recalc_answer_to_result_seconds",
    "Время от постановки команды пересчёта до записи результатов и интерпретаций",
    ["outcome", "scope", "source"],
    buckets=RECALC_TIMING_BUCKETS,
)

RECALC_QUEUE_WAIT = Histogram(
    f"{SERVICE_PREFIX}_recalc_queue_wait_seconds",
    "Ожидание команды пересчёта в очереди до начала обработки",
    ["outcome", "scope", "source"],
    buckets=RECALC_TIMING_BUCKETS,
)

RECALC_DURATION = Histogram(
    f"{SERVICE_PREFIX}_recalc_duration_seconds",
    "Длительность обработки команды пересчёта",
    ["outcome", "scope", "source"],
    buckets=RECALC_TIMING_BUCKETS,
)

# Допуск фоновых команд пересчёта (команд массового прогона) в воркере. Счётчики авторитетно
# отвечают на вопрос «сделал ли прогон работу»: размер когорты уменьшает и пользовательский
# трафик, а эти ряды растут только от команд самого прогона.
BACKGROUND_ADMITTED = "admitted"
BACKGROUND_DROPPED = "dropped"
BACKGROUND_DECISIONS = (BACKGROUND_ADMITTED, BACKGROUND_DROPPED)

# Причина отбрасывания. `none` — у принятой команды: лейбл обязан присутствовать у всех рядов
# одного имени, иначе ряды пришлось бы складывать по разным наборам лейблов.
BACKGROUND_REASON_NONE = "none"
BACKGROUND_REASON_NO_SLOT = "no_slot"
BACKGROUND_REASON_SATURATED = "cvd_saturated"
# Отказ по верхней границе темпа: слот свободен и внешний сервис здоров, но с прошлой допущенной
# команды прошло меньше минимального интервала (см. `src/calc/background_admission.py`).
BACKGROUND_REASON_RATE_LIMITED = "rate_limited"
BACKGROUND_REASONS = (
    BACKGROUND_REASON_NONE,
    BACKGROUND_REASON_NO_SLOT,
    BACKGROUND_REASON_SATURATED,
    BACKGROUND_REASON_RATE_LIMITED,
)

RECALC_BACKGROUND_COMMANDS = Counter(
    f"{SERVICE_PREFIX}_recalc_background_commands_total",
    "Фоновые команды пересчёта по решению политики допуска",
    ["decision", "reason"],
)

# Предынициализация всех комбинаций лейблов: ряды видны в экспозиции с момента старта процесса.
# Иначе `increase()`/`histogram_quantile()` увидели бы не рождение счётчика в нуле, а появление
# ряда из ниоткуда, а проверка готовности на тихом стенде зависела бы от того, случился ли уже
# пересчёт. Безопасно в обоих режимах: mmap-файл labeled-метрики создаётся на первом `.labels()`,
# а директория уже создана `ensure_multiproc_dir()` выше по модулю.
#
# Отсюда ПРАВИЛО ПОРЯДКА: в multiprocess-режиме импорт этого модуля открывает mmap-файлы процесса,
# поэтому директорию чистит точка входа процесса app (`src/__main__.py`) ДО импорта модуля. Очистка
# после импорта удалила бы открытые файлы, и при одном воркере, когда запросы обслуживает сам
# процесс точки входа, его наблюдения пропали бы из выдачи (см. `prepare_multiproc_dir` в
# `src/metrics_multiproc.py`).
#
# Пара `scope="partial"` × `source="background"` в перечень не входит: массовый прогон публикует
# только команды полного пересчёта, а разбор команды сбрасывает признак фоновой у частичной
# (см. `decode_command`). Ряд с постоянным нулём читался бы как «такого не случается»
# наравне с настоящими (та же причина, что у пар «решение × причина» ниже).
for _outcome in RECALC_OUTCOMES:
    for _scope in RECALC_SCOPES:
        for _source in RECALC_SOURCES:
            if _scope == RECALC_SCOPE_PARTIAL and _source == RECALC_SOURCE_BACKGROUND:
                continue
            RECALC_ANSWER_TO_RESULT.labels(_outcome, _scope, _source)
            RECALC_QUEUE_WAIT.labels(_outcome, _scope, _source)
            RECALC_DURATION.labels(_outcome, _scope, _source)

# Пары «решение × причина», которые политика допуска действительно порождает: у принятой команды
# причины нет, у отброшенной она обязательна. Остальные сочетания рядами не заводим — их
# постоянный ноль читался бы как «такого не бывает» наравне с настоящими.
RECALC_BACKGROUND_COMMANDS.labels(BACKGROUND_ADMITTED, BACKGROUND_REASON_NONE)
RECALC_BACKGROUND_COMMANDS.labels(BACKGROUND_DROPPED, BACKGROUND_REASON_NO_SLOT)
RECALC_BACKGROUND_COMMANDS.labels(BACKGROUND_DROPPED, BACKGROUND_REASON_SATURATED)
RECALC_BACKGROUND_COMMANDS.labels(BACKGROUND_DROPPED, BACKGROUND_REASON_RATE_LIMITED)

# --- Scrape-time метрики: LOCAL_REGISTRY ---
# Метрики процесса, обслуживающего текущий скрейп (build_info, cpu/ram, lag очереди). Они
# одинаковы/валидны из любого воркера, поэтому агрегировать их между воркерами не нужно и нельзя:
# lag очереди задублировался бы по числу воркеров.
#
# ИНВАРИАНТ: сюда регистрируются ТОЛЬКО кастомные коллекторы (collect() → *MetricFamily), но не
# объекты Gauge/Counter. Причина: value-class prometheus_client ГЛОБАЛЬНЫЙ (выбирается по env
# MULTIPROC_ENV при импорте) и не зависит от реестра — в контейнере Gauge, созданный на этом
# реестре, писал бы значение ещё и в mmap, откуда его подхватил бы MultiProcessCollector. Метрика
# попала бы в выдачу дважды: мусорный ряд с лейблом pid плюс ряд без него, два блока HELP/TYPE на
# одно имя. Строгие парсеры такую выдачу отвергают («second TYPE line»), нестрогие молча сливают
# ряды — то есть в лучшем случае метрика врёт. Локально (single-process) этого не видно вообще:
# ломается только на стенде. Держится тестом test_render_in_multiprocess_mode.
LOCAL_REGISTRY = CollectorRegistry()


class _BuildInfoCollector(Collector):
    """Версия сервиса как константа 1 с лейблом `version` — под аннотации деплоев в Grafana."""

    def __init__(self, version: str) -> None:
        self._version = version

    def collect(self) -> Iterator[Metric]:
        family = GaugeMetricFamily(
            f"{SERVICE_PREFIX}_build_info",
            "Версия сервиса из version.json (значение всегда 1)",
            labels=["version"],
        )
        family.add_metric([self._version], 1)
        yield family


def _parse_proc_stat(content: str) -> tuple[int, int]:
    """(ppid, utime+stime в тиках) из содержимого `/proc/<pid>/stat`.

    Парсим ПОСЛЕ последней `)`: comm (имя процесса) может содержать пробелы и скобки, поэтому
    split по всей строке сдвинул бы поля. После comm идут: state, ppid, ... utime(14), stime(15)
    — то есть в хвосте это индексы 1 (ppid), 11 (utime), 12 (stime), считая state за 0.
    """
    tail = content[content.rfind(")") + 1 :].split()
    ppid = int(tail[1])
    cpu_ticks = int(tail[11]) + int(tail[12])
    return ppid, cpu_ticks


def _parse_proc_statm_rss(content: str, page_size: int) -> int:
    """RSS в байтах: второе поле `/proc/<pid>/statm` (resident, в страницах) × page_size."""
    return int(content.split()[1]) * page_size


def _master_pid(workers: int) -> int:
    """PID «мастера» для суммирования cpu/rss. uvicorn спавнит отдельный master-процесс с
    воркерами-детьми ТОЛЬКО при workers>1; при workers==1 он крутит приложение в самом процессе.

    Поэтому родителя (`getppid()`) берём лишь когда мы реально воркер: multiprocess-режим И
    workers>1. Иначе — сам процесс (`getpid()`). Гейт по числу воркеров, а не по одному наличию
    env: при `RISK_MODEL_WORKERS=1` + выставленной multiproc-директории (например, форс профайлера)
    `getppid()` = PID 1 контейнера, и в метрики попали бы посторонние дети init.
    """
    if _MULTIPROC_PATH and workers > 1:
        return os.getppid()
    return os.getpid()


def _read_proc_stats(workers: int) -> tuple[float, int, int] | None:
    """(cpu_seconds, rss_bytes, process_count) суммарно по мастеру и воркерам, или None если
    `/proc` недоступен (не-Linux) либо не удалось прочитать ни один процесс.

    Воркеры — процессы с ppid == мастер (см. _master_pid).
    """
    if not os.path.isdir(_PROC_ROOT):
        return None
    master = _master_pid(workers)
    pids = {master}
    try:
        entries = os.listdir(_PROC_ROOT)
    except OSError:
        return None
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            with open(f"{_PROC_ROOT}/{entry}/stat") as handle:
                ppid, _ = _parse_proc_stat(handle.read())
        except (OSError, ValueError, IndexError):
            # Процесс исчез между листингом и чтением, либо битый stat — пропускаем молча.
            continue
        if ppid == master:
            pids.add(int(entry))

    total_ticks = 0
    total_rss = 0
    counted = 0
    for pid in pids:
        try:
            with open(f"{_PROC_ROOT}/{pid}/stat") as handle:
                _, cpu_ticks = _parse_proc_stat(handle.read())
            with open(f"{_PROC_ROOT}/{pid}/statm") as handle:
                rss = _parse_proc_statm_rss(handle.read(), _PAGE_SIZE)
        except (OSError, ValueError, IndexError):
            continue  # исчез/битый между листингом и чтением — пропускаем
        total_ticks += cpu_ticks
        total_rss += rss
        counted += 1
    if counted == 0:
        return None
    return total_ticks / _CLK_TCK, total_rss, counted


class _ProcStatsCollector(Collector):
    """CPU/RAM процесса сервиса по `/proc`, без psutil: суммарно uvicorn-мастер + все воркеры.

    Отдаётся ОДНИМ агрегатным рядом на метрику (метрики с позиции сервиса, без разбивки по PID);
    process_count — не разрез, а индикатор падения воркера. На не-Linux collect() пуст — метрик
    process_* в выдаче просто нет (см. _read_proc_stats). `workers` — эффективное число uvicorn-
    воркеров (нужно для выбора мастера, см. _master_pid).
    """

    def __init__(self, workers: int) -> None:
        self.workers = workers

    def collect(self) -> Iterator[Metric]:
        stats = _read_proc_stats(self.workers)
        if stats is None:
            return
        cpu_seconds, rss_bytes, process_count = stats
        cpu = CounterMetricFamily(
            f"{SERVICE_PREFIX}_process_cpu_seconds_total",
            "Суммарное CPU-время (utime+stime) uvicorn-мастера и воркеров, секунды",
        )
        cpu.add_metric([], cpu_seconds)
        yield cpu
        rss = GaugeMetricFamily(
            f"{SERVICE_PREFIX}_process_resident_memory_bytes",
            "Суммарный RSS uvicorn-мастера и воркеров, байты",
        )
        rss.add_metric([], rss_bytes)
        yield rss
        count = GaugeMetricFamily(
            f"{SERVICE_PREFIX}_process_count",
            "Число процессов сервиса (мастер + воркеры); падение воркера видно по проседанию",
        )
        count.add_metric([], process_count)
        yield count


_build_info_collector: _BuildInfoCollector | None = None
_proc_stats_collector: _ProcStatsCollector | None = None


def init_metrics(version: str, workers: int = 1) -> None:
    """Регистрирует scrape-time коллекторы. Вызывается из lifespan (`src/main.py`).

    Версия и число воркеров передаются параметрами, а не читаются из main/config — см. правило о
    boot-order выше. `workers` — эффективное число uvicorn-воркеров (для выбора мастера в
    /proc-коллекторе); дефолт 1 (single-process: тесты/локальный дев).
    Идемпотентна: lifespan поднимается заново в тестах, а повторная регистрация того же имени
    уронила бы старт (Duplicated timeseries in CollectorRegistry).
    """
    global _build_info_collector, _proc_stats_collector
    if _build_info_collector is not None:
        LOCAL_REGISTRY.unregister(_build_info_collector)
    _build_info_collector = _BuildInfoCollector(version)
    LOCAL_REGISTRY.register(_build_info_collector)

    if _proc_stats_collector is None:
        # /proc-коллектор не хранит состояния (читает /proc на каждый collect) — регистрируем
        # один раз, повторный init_metrics (перезапуск lifespan в тестах) его не пересоздаёт.
        _proc_stats_collector = _ProcStatsCollector(workers)
        LOCAL_REGISTRY.register(_proc_stats_collector)
    else:
        # Перезапуск lifespan — коллектор уже зарегистрирован; обновляем число воркеров на случай
        # изменения конфигурации между запусками.
        _proc_stats_collector.workers = workers


def _drop_default_process_collectors() -> None:
    """Снимает штатные python_*/process_* коллекторы с default REGISTRY.

    В multiprocess-режиме их в выдаче нет физически (MultiProcessCollector читает только
    mmap-файлы), и без этого локальная выдача отличалась бы от стендовой — а по ней сверяется
    docs/metrics.md. Наружу отдаём только метрики с нашим префиксом; cpu/ram считает свой
    /proc-коллектор, суммарно по мастеру и воркерам (штатный process_* видел бы один процесс).

    Вызывается при импорте, а не из `init_metrics`: иначе выдача зависела бы от того, поднимался
    ли lifespan (`TestClient(app)` без него — обычный паттерн тестов репо), и тесты видели бы не
    то, что уходит на стенд.
    """
    for collector in (PROCESS_COLLECTOR, PLATFORM_COLLECTOR, GC_COLLECTOR):
        try:
            REGISTRY.unregister(collector)
        except KeyError:
            # Уже сняты — идемпотентность, а не ошибка.
            continue


_drop_default_process_collectors()


def render() -> bytes:
    """Тело ответа `GET /metrics`: счётные метрики + scrape-time метрики этого процесса."""
    if _MULTIPROC_PATH:
        # Свежий реестр на каждый скрейп — контракт MultiProcessCollector: он вычитывает
        # mmap-файлы всех воркеров в момент сборки, кэшировать его между скрейпами нельзя.
        multiproc_registry = CollectorRegistry()
        MultiProcessCollector(multiproc_registry)
        return generate_latest(multiproc_registry) + generate_latest(LOCAL_REGISTRY)
    return generate_latest(REGISTRY) + generate_latest(LOCAL_REGISTRY)
