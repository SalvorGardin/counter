from datetime import datetime

from sqlalchemy import TIMESTAMP, ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class PatientCalculationVersion(Base):
    """Реестр версий расчёта: какой версией посчитан риск-профиль каждого пациента.

    Строка пишется самим расчётом по завершении полного пересчёта (см. `run_recalc`), а не
    продюсером массового прогона: продюсер знал бы только «опубликовано», и отброшенные команды
    выглядели бы сделанной работой. Отсюда свойство, ради которого реестр и заведён, — состояние
    прогона производно от состояния данных: когорта = строки с версией, отличной от текущей,
    поэтому прогон самозавершается, повторный запуск не дублирует работу, а таблица статусов
    прогона не нужна вовсе.

    Отсутствие строки означает «пациент не считался никогда» и в когорту его НЕ включает:
    массовый пересчёт обновляет уже посчитанные профили и не порождает первичный расчёт.

    Строка на пациента, а не на пару «пациент × инструмент»: версия скалярная и глобальная,
    частичного массового пересчёта нет (см. design.md, Non-Goals).
    """

    __tablename__ = "patient_calculation_versions"
    __table_args__ = ({"schema": CALCULATION_SCHEMA},)

    # Идентификатор пациента и есть ключ: строка на пациента одна, повторный пересчёт её обновляет.
    # Удаление пациента уносит строку каскадом: она производна от расчёта, а не аудитный след,
    # и с RESTRICT держала бы удаление данных пациента без того, кто мог бы её убрать.
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="CASCADE"), primary_key=True
    )
    # Версия расчёта, которой проштампован профиль (`src/calc/version.py`). Строка, а не число:
    # версия сравнивается только на равенство, а её формат задаёт релиз.
    calculation_version: Mapped[str] = mapped_column(String, nullable=False)
    # Момент последнего завершённого полного пересчёта. Нужен разбору: по нему видно, когда
    # пациент в последний раз проходил расчёт, и отличается ли это от времени бампа версии.
    calculated_at: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
