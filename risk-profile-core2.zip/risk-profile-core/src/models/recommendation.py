from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Recommendation(Base):
    __tablename__ = "recommendations"
    __table_args__ = {"schema": CATALOG_SCHEMA}
    # Фактор адресуется парой (risk_factors_code, system_code). Раньше это был составной FK
    # на risk_factors(code, system_code), но с 0096 естественный ключ risk_factors расширен
    # (parameter_code+code+param_value+min+max+system), и пара (code, system_code) больше не
    # уникальна — навесить на неё FK нельзя. Связь стала прикладной: matching по
    # risk_factors_code+system_code в reader'ах (risk_profile/interpretation), без БД-FK.
    # risk_factors_code остаётся NULLABLE: common_group-рекомендации привязаны к системе.

    recommendation_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    risk_factors_code: Mapped[str | None] = mapped_column(
        String, ForeignKey("catalog.risk_factors.code", ondelete="RESTRICT"), nullable=True, index=True
    )
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String, nullable=False)
    text: Mapped[str | None] = mapped_column(String, nullable=True)
    recommendations_group: Mapped[str | None] = mapped_column(String, nullable=True)
