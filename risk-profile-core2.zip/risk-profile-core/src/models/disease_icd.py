from sqlalchemy import ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class DiseaseIcd(Base):
    """Код МКБ третьего уровня, входящий в группу заболеваний.

    `icd_code` хранится строкой: справочника кодов МКБ в базе нет, ссылаться не на что.
    """

    __tablename__ = "disease_icd"
    __table_args__ = (
        UniqueConstraint("disease_code", "icd_code", name="uq_disease_icd_disease_code_icd_code"),
        {"schema": CATALOG_SCHEMA},
    )

    disease_icd_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    disease_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    icd_code: Mapped[str] = mapped_column(String, nullable=False)
