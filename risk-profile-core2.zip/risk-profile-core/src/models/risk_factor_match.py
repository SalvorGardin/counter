from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    TIMESTAMP,
    Boolean,
    CheckConstraint,
    ForeignKey,
    ForeignKeyConstraint,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class RiskFactorMatch(Base):
    """Self-contained snapshot of one normalized trigger matched in the latest run."""

    __tablename__ = "risk_factor_matches"
    __table_args__ = (
        CheckConstraint("value_type IN ('text', 'number')", name="ck_risk_factor_matches_value_type"),
        CheckConstraint(
            "operator IN ('eq', 'gt', 'gte', 'lt', 'lte', 'between')",
            name="ck_risk_factor_matches_operator",
        ),
        CheckConstraint("gender IS NULL OR gender IN ('Мужской', 'Женский')", name="ck_risk_factor_matches_gender"),
        CheckConstraint(
            "(value_type = 'text' AND operator = 'eq' AND value_text IS NOT NULL "
            "AND value_num IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator IN ('gt', 'gte', 'lt', 'lte') AND value_num IS NOT NULL "
            "AND value_text IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator = 'between' AND value_num IS NULL "
            "AND value_text IS NULL AND min_value IS NOT NULL AND max_value IS NOT NULL AND min_value <= max_value)",
            name="ck_risk_factor_matches_value_shape",
        ),
        ForeignKeyConstraint(
            ["patient_id", "system_code"],
            [
                "risk_calculation.interpretation_statuses.patient_id",
                "risk_calculation.interpretation_statuses.system_code",
            ],
            ondelete="CASCADE",
            name="fk_risk_factor_matches_interpretation_status",
        ),
        UniqueConstraint(
            "patient_id",
            "system_code",
            "trigger_code",
            name="uq_risk_factor_matches_patient_system_trigger",
        ),
        {"schema": CALCULATION_SCHEMA},
    )

    risk_factor_match_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    patient_id: Mapped[str] = mapped_column(String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"))
    system_code: Mapped[str] = mapped_column(String, nullable=False)
    trigger_code: Mapped[str] = mapped_column(String, nullable=False)
    risk_factor_code: Mapped[str] = mapped_column(String, nullable=False)
    factor_description: Mapped[str] = mapped_column(String, nullable=False)
    reasoning: Mapped[str | None] = mapped_column(String, nullable=True)
    parameter_code: Mapped[str] = mapped_column(String, nullable=False)
    value_type: Mapped[str] = mapped_column(String, nullable=False)
    operator: Mapped[str] = mapped_column(String, nullable=False)
    value_num: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    min_value: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    max_value: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    value_text: Mapped[str | None] = mapped_column(String, nullable=True)
    gender: Mapped[str | None] = mapped_column(String, nullable=True)
    modifiability: Mapped[str] = mapped_column(String, nullable=False)
    is_representative: Mapped[bool] = mapped_column(Boolean, nullable=False)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
