from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class System(Base):
    __tablename__ = "systems"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    system_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
    rang: Mapped[int] = mapped_column(nullable=False, unique=True)
