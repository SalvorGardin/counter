from sqlalchemy import CheckConstraint, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Option(Base):
    __tablename__ = "options"
    __table_args__ = (
        # Родовые формы текста заполняются парой: обе пусты либо обе непустые. Только для
        # отображения пациенту — в `patients_parameters.value` пишется `value`.
        CheckConstraint(
            "(value_male IS NULL AND value_female IS NULL) OR "
            "(value_male IS NOT NULL AND value_female IS NOT NULL AND value_male <> '' AND value_female <> '')",
            name="gendered_pair",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    option_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    value: Mapped[str | None] = mapped_column(String, nullable=True)
    value_male: Mapped[str | None] = mapped_column(String, nullable=True)
    value_female: Mapped[str | None] = mapped_column(String, nullable=True)
    question_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.questions.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
