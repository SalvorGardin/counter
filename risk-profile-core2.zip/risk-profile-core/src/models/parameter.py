from datetime import datetime

from sqlalchemy import TIMESTAMP, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Parameter(Base):
    __tablename__ = "parameters"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    parameter_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, index=True)
    validity_period: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
