from datetime import datetime
from decimal import Decimal

from sqlalchemy import TIMESTAMP, Boolean, ForeignKey, Numeric, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA

RESULT_UNIQUE_CONSTRAINT = "uq_results_patient_id_instrument_code_indicator_disease_code"


class Result(Base):
    __tablename__ = "results"
    __table_args__ = (
        # nulls_not_distinct: у калькуляторов и опросников disease_code пуст, и такие строки
        # обязаны конфликтовать между собой по трём остальным колонкам — ровно как до появления
        # группы заболеваний в ключе. Без режима ключ не срабатывал бы на них вообще.
        UniqueConstraint(
            "patient_id",
            "instrument_code",
            "indicator",
            "disease_code",
            name=RESULT_UNIQUE_CONSTRAINT,
            postgresql_nulls_not_distinct=True,
        ),
        {"schema": CALCULATION_SCHEMA},
    )

    result_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    instrument_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.instruments.code", ondelete="RESTRICT"), nullable=False
    )
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    # Группа заболеваний, в разрезе которой посчитан результат: заполнена только у расчёта
    # по клиническим рекомендациям, у калькуляторов и опросников группы нет.
    disease_code: Mapped[str | None] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=True
    )
    value: Mapped[Decimal | None] = mapped_column(Numeric(precision=12, scale=6), nullable=True)
    indicator: Mapped[str] = mapped_column(String, nullable=False)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
    interpretation_status: Mapped[str] = mapped_column(String, nullable=False)
    expiration_date: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    risk_level: Mapped[str | None] = mapped_column(String, nullable=True)
    applicability: Mapped[bool] = mapped_column(Boolean, nullable=False)
    unit: Mapped[str | None] = mapped_column(String, nullable=True)
