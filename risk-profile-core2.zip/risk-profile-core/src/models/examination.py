import uuid

from sqlalchemy import CheckConstraint, Integer, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Examination(Base):
    """Лабораторное или инструментальное исследование единого справочника.

    Тип отличает строки внутри таблицы, отдельного справочника на тип нет. Пол клиента здесь не
    хранится: это условие конкретной рекомендации, оно живёт в таблицах связей
    `disease_examinations` и `system_checkup_examinations`.
    """

    __tablename__ = "examinations"
    __table_args__ = (
        CheckConstraint("examination_type IN ('laboratory', 'instrumental')", name="examination_type"),
        CheckConstraint("status IN ('active', 'inactive')", name="status"),
        # Одно и то же название допустимо у лабораторного и инструментального исследования,
        # поэтому в ключ входит и тип.
        UniqueConstraint("name", "examination_type", name="uq_examinations_name"),
        {"schema": CATALOG_SCHEMA},
    )

    examination_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # Стабильный идентификатор во внешнем контракте: по нему исследование передаётся смежной
    # системе, на него же ссылаются таблицы подбора. Уникальность даёт индекс под их внешние ключи.
    code: Mapped[uuid.UUID] = mapped_column(Uuid(), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    examination_type: Mapped[str] = mapped_column(String, nullable=False)
    # Исключённое из подбора исследование переводится в `inactive`, строка не удаляется:
    # на `code` стоят внешние ключи с RESTRICT.
    status: Mapped[str] = mapped_column(String, nullable=False, index=True)
