from sqlalchemy import ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RiskFactorClinrec(Base):
    """Клиническая рекомендация, обосновывающая балл фактора риска в группе заболеваний.

    Балл одной пары «фактор + группа» может быть обоснован несколькими рекомендациями, поэтому
    ключ тройной, а не по паре.
    """

    __tablename__ = "risk_factor_clinrecs"
    __table_args__ = (
        # Компактное имя описывает все три роли ключа и укладывается в лимит Postgres.
        UniqueConstraint(
            "risk_factor_code",
            "disease_code",
            "clinrec_code",
            name="uq_risk_factor_clinrecs_factor_disease_clinrec",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    risk_factor_clinrec_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    risk_factor_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.risk_factors.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    disease_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    clinrec_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.clinical_recommendations.code", ondelete="RESTRICT"), nullable=False, index=True
    )
