from sqlalchemy import String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RiskFactor(Base):
    __tablename__ = "risk_factors"
    __table_args__ = (
        UniqueConstraint("code", name="uq_risk_factors_code"),
        {"schema": CATALOG_SCHEMA},
    )

    risk_factor_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, index=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
    modifiability: Mapped[str] = mapped_column(String, nullable=False)
