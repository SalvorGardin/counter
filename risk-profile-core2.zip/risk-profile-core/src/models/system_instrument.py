from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class SystemInstrument(Base):
    __tablename__ = "systems_instruments"
    __table_args__ = (
        UniqueConstraint(
            "system_code",
            "instrument_code",
            name="uq_systems_instruments_system_instrument",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    system_instrument_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    instrument_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.instruments.code", ondelete="RESTRICT"), nullable=False, index=True
    )
