from datetime import datetime

from sqlalchemy import TIMESTAMP, BigInteger, ForeignKey, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import PROFILE_SCHEMA

PATIENT_PARAMETER_UNIQUE_CONSTRAINT = "uq_patients_parameters_patient_id_parameter_code"


class PatientParameter(Base):
    __tablename__ = "patients_parameters"
    __table_args__ = (
        UniqueConstraint("patient_id", "parameter_code", name=PATIENT_PARAMETER_UNIQUE_CONSTRAINT),
        {"schema": PROFILE_SCHEMA},
    )

    patient_parameter_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False
    )
    value: Mapped[str | None] = mapped_column(String, nullable=True)
    source: Mapped[str] = mapped_column(String, nullable=False)
    # Идентификатор экземпляра значения во внешней системе-источнике: заполнен только
    # у параметров из ЭМК, у ответов на вопросы анкеты его нет.
    external_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    expiration_date: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    # Момент записи/обновления значения параметра. Прикладной код (risk-init, risk-communication)
    # выставляет date_time явно; server_default=now() гарантирует NOT NULL для прочих вставок
    # (testing-API, seeds) без правок каждого call-site.
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
