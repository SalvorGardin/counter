from sqlalchemy import String, Text
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Instrument(Base):
    __tablename__ = "instruments"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    STATUS_ACTIVE = "active"
    TYPE_QUESTIONNAIRE = "form"

    instrument_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, index=True)
    diseases: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
