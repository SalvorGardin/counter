from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RiskFactorSystem(Base):
    __tablename__ = "risk_factor_systems"
    __table_args__ = (
        UniqueConstraint("risk_factor_code", "system_code", name="uq_risk_factor_systems_factor_system"),
        {"schema": CATALOG_SCHEMA},
    )

    risk_factor_system_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    risk_factor_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.risk_factors.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    reasoning: Mapped[str | None] = mapped_column(String, nullable=True)
