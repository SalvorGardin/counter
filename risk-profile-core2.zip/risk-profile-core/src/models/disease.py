from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Disease(Base):
    """Группа заболеваний: единица, в разрезе которой считается риск по клиническим рекомендациям.

    Состав группы задаётся кодами МКБ третьего уровня в `disease_icd`.
    """

    __tablename__ = "diseases"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    disease_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
