from sqlalchemy import CheckConstraint, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RiskFactorScore(Base):
    """Балл и влияние фактора риска в группе заболеваний.

    Таблица реализует связь «многие-ко-многим» фактор ↔ группа: один фактор даёт балл в
    нескольких группах, одна группа набирает балл от нескольких факторов.
    """

    __tablename__ = "risk_factor_scores"
    __table_args__ = (
        CheckConstraint(
            "influence IN ('increase', 'decrease', 'undetermined')",
            name="influence",
        ),
        UniqueConstraint(
            "risk_factor_code",
            "disease_code",
            name="uq_risk_factor_scores_risk_factor_code_disease_code",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    risk_factor_score_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    risk_factor_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.risk_factors.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    disease_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    score: Mapped[int] = mapped_column(Integer, nullable=False)
    influence: Mapped[str] = mapped_column(String, nullable=False)
