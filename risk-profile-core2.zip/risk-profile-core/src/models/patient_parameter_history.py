from datetime import datetime

from sqlalchemy import TIMESTAMP, BigInteger, ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import PROFILE_SCHEMA


class PatientParameterHistory(Base):
    __tablename__ = "patients_parameters_history"
    __table_args__ = {"schema": PROFILE_SCHEMA}

    patient_parameter_history_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False, index=True
    )
    value: Mapped[str | None] = mapped_column(String, nullable=True)
    source: Mapped[str] = mapped_column(String, nullable=False)
    # Идентификатор экземпляра значения во внешней системе-источнике: заполнен только
    # у параметров из ЭМК, у ответов на вопросы анкеты его нет.
    external_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    expiration_date: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    # Оригинальный момент записи параметра — копируется «как есть» из patients_parameters при архивации.
    # server_default=now() — лишь страховка NOT NULL для вставок, не задающих поле явно (seeds).
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
