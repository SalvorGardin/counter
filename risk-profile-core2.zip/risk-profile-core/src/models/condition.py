from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Condition(Base):
    __tablename__ = "conditions"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    condition_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    type: Mapped[str] = mapped_column(String, nullable=False)
    question_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.questions.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    value: Mapped[str | None] = mapped_column(String, nullable=True)
    min_age: Mapped[int | None] = mapped_column(nullable=True)
    max_age: Mapped[int | None] = mapped_column(nullable=True)
