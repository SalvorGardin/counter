from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKeyConstraint, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class BiomarkerParameterMapping(Base):
    """Разметка «биомаркер заполняет параметр расширенного опросника».

    Маппинг `value` переносит значение биомаркера в параметр как есть. Маппинг `flag` при
    отклонении от нормы записывает в параметр текст варианта ответа; отклонение задаётся
    числовой границей `value_num` у количественного биомаркера и эталонным текстом `value_text`
    у качественного.
    """

    __tablename__ = "biomarker_parameter_mappings"
    __table_args__ = (
        CheckConstraint(
            "mapping_type IN ('value', 'flag')",
            name="mapping_type",
        ),
        CheckConstraint(
            "operator IS NULL OR operator IN ('gt', 'gte', 'lt', 'lte', 'eq')",
            name="operator",
        ),
        # Условие отклонения от нормы — это тройка «оператор + эталон + записываемый ответ»:
        # она есть целиком у flag и отсутствует целиком у value. Частично заполненная строка
        # означала бы правило, которое нельзя применить. Эталон задаётся ровно одной колонкой:
        # числовой оператор читает `value_num`, оператор `eq` — `value_text`, и заполненные обе
        # оставили бы неясным, по какой из них сравнивать.
        CheckConstraint(
            "(mapping_type = 'flag' AND operator IN ('gt', 'gte', 'lt', 'lte') "
            "AND value_num IS NOT NULL AND value_text IS NULL AND option_code IS NOT NULL) OR "
            "(mapping_type = 'flag' AND operator = 'eq' "
            "AND value_num IS NULL AND value_text IS NOT NULL AND option_code IS NOT NULL) OR "
            "(mapping_type = 'value' AND operator IS NULL "
            "AND value_num IS NULL AND value_text IS NULL AND option_code IS NULL)",
            name="shape",
        ),
        # Полные convention-имена внешних ключей превышают лимит Postgres для первого кода.
        # Явные короткие имена совпадают с миграцией и однозначно называют локальную колонку.
        ForeignKeyConstraint(
            ["biomarker_parameter_code"],
            ["catalog.parameters.code"],
            name="fk_biomarker_parameter_mappings_biomarker_parameter_code",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["parameter_code"],
            ["catalog.parameters.code"],
            name="fk_biomarker_parameter_mappings_parameter_code",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["option_code"],
            ["catalog.options.code"],
            name="fk_biomarker_parameter_mappings_option_code",
            ondelete="RESTRICT",
        ),
        # Пара «источник → цель» повторяется столько раз, сколько у неё условий разметки, поэтому
        # в ключ входят тип, оператор и записываемый вариант — и только они. Эталон сравнения
        # (`value_num`, `value_text`) в ключ не входит: две строки, различающиеся одним порогом,
        # пишут в один параметр один и тот же вариант ответа, то есть описывают вложенные условия,
        # из которых применяется одно. Пример: `gt 5 → Да` и `gt 10 → Да` на одной паре ключом
        # запрещены, а `gt 5 → Да` и `lt 3 → Нет` на ней же — разрешены, потому что различаются
        # оператором и вариантом. `nulls_not_distinct`: у прямого переноса значения оператор и
        # вариант пусты, и без него такая строка не конфликтовала бы сама с собой — на пару можно
        # было бы завести сколько угодно одинаковых. Компактное имя ограничения укладывается в
        # лимит идентификатора Postgres.
        UniqueConstraint(
            "biomarker_parameter_code",
            "parameter_code",
            "mapping_type",
            "operator",
            "option_code",
            name="uq_biomarker_parameter_mappings_source_target_condition",
            postgresql_nulls_not_distinct=True,
        ),
        {"schema": CATALOG_SCHEMA},
    )

    biomarker_parameter_mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # Обе стороны маппинга — коды одного справочника parameters: слева параметр-биомаркер,
    # справа заполняемый параметр опросника.
    biomarker_parameter_code: Mapped[str] = mapped_column(String, nullable=False, index=True)
    parameter_code: Mapped[str] = mapped_column(String, nullable=False, index=True)
    mapping_type: Mapped[str] = mapped_column(String, nullable=False)
    operator: Mapped[str | None] = mapped_column(String, nullable=True)
    value_num: Mapped[Decimal | None] = mapped_column(Numeric(12, 6), nullable=True)
    value_text: Mapped[str | None] = mapped_column(String, nullable=True)
    option_code: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    unit: Mapped[str | None] = mapped_column(String, nullable=True)
