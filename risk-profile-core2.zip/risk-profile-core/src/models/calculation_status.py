from datetime import datetime

from sqlalchemy import TIMESTAMP, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class CalculationStatus(Base):
    """Диагностический исход расчёта по паре «пациент × инструмент»: почему нет показателя.

    Запись в таблицу управляется `settings.calc_status_collection_enabled` (в проде выключена),
    но сама таблица существует всегда. Читающая сторона источником показателя её НЕ считает:
    показатель живёт в `results`, здесь — причина.

    Грань — `(patient_id, instrument_code)`, без индикатора: индикатор описывает показатель, а
    решение о расчёте принимается на инструмент целиком (у `stai` два индикатора и одно решение).

    `status` и `reason_code` — строки, как `results.risk_level` / `results.interpretation_status`:
    набор кодов причин будет расти, а PG-enum потребовал бы `ALTER TYPE` на каждое пополнение.
    Детали причины заполняются только для тех причин, к которым относятся, остальные — NULL.
    Значения ответов пациента и тексты исключений сюда не попадают.
    """

    __tablename__ = "calculation_statuses"
    __table_args__ = (
        UniqueConstraint(
            "patient_id",
            "instrument_code",
            name="uq_calculation_statuses_patient_id_instrument_code",
        ),
        {"schema": CALCULATION_SCHEMA},
    )

    calculation_status_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    instrument_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.instruments.code", ondelete="RESTRICT"), nullable=False
    )
    status: Mapped[str] = mapped_column(String, nullable=False)
    # NULL у успешного расчёта: причины отказа нет.
    reason_code: Mapped[str | None] = mapped_column(String, nullable=True)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
    # Коды недостающих параметров (не значения ответов) — деталь причин missing_required_parameters,
    # incomplete_scale и required_parameters_missing.
    missing_parameter_codes: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    # Числа гейта опросника — деталь причины not_enough_answers.
    applicable_questions: Mapped[int | None] = mapped_column(Integer, nullable=True)
    progressed_questions: Mapped[int | None] = mapped_column(Integer, nullable=True)
