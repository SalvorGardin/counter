from datetime import datetime
from decimal import Decimal

from sqlalchemy import TIMESTAMP, Boolean, ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class ResultHistory(Base):
    __tablename__ = "results_history"
    __table_args__ = {"schema": CALCULATION_SCHEMA}

    result_history_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    instrument_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.instruments.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False, index=True
    )
    # Группа заболеваний, в разрезе которой посчитан результат: заполнена только у расчёта
    # по клиническим рекомендациям, у калькуляторов и опросников группы нет.
    disease_code: Mapped[str | None] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=True, index=True
    )
    value: Mapped[Decimal | None] = mapped_column(Numeric(precision=12, scale=6), nullable=True)
    indicator: Mapped[str] = mapped_column(String, nullable=False)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    interpretation_status: Mapped[str] = mapped_column(String, nullable=False)
    expiration_date: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    risk_level: Mapped[str | None] = mapped_column(String, nullable=True)
    applicability: Mapped[bool] = mapped_column(Boolean, nullable=False)
    unit: Mapped[str | None] = mapped_column(String, nullable=True)
