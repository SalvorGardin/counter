from datetime import datetime

from sqlalchemy import TIMESTAMP, ForeignKey, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class InterpretationStatus(Base):
    """Диагностические причины интерпретации по паре «пациент × система».

    Запись в таблицу управляется `settings.calc_status_collection_enabled` (в проде выключена) —
    тот же флаг, что у `calculation_statuses`, — но сама таблица существует всегда. Источником
    профиля она не является: значения живут в `interpretations`, здесь — почему их нет.

    Одна строка на систему, а не по строке на каждый из четырёх результатов: они вычисляются
    одним проходом и читаются вместе, поэтому отсутствие строки означает ровно одно —
    интерпретация по этой системе не выполнялась.

    Внешнего ключа на `systems` нет намеренно: диагностика не должна участвовать в ограничениях
    целостности справочников, которые сиды каталога перезаливают целиком.
    """

    __tablename__ = "interpretation_statuses"
    __table_args__ = (
        UniqueConstraint(
            "patient_id",
            "system_code",
            name="uq_interpretation_statuses_patient_id_system_code",
        ),
        {"schema": CALCULATION_SCHEMA},
    )

    interpretation_status_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    system_code: Mapped[str] = mapped_column(String, nullable=False)
    # Четыре пары «статус + причина» — по числу результатов, которые интерпретация считает одним
    # проходом. Статус принимает `computed` / `empty`; код причины заполняется только при `empty`.
    risk_level_status: Mapped[str] = mapped_column(String, nullable=False)
    risk_level_reason_code: Mapped[str | None] = mapped_column(String, nullable=True)
    diseases_status: Mapped[str] = mapped_column(String, nullable=False)
    diseases_reason_code: Mapped[str | None] = mapped_column(String, nullable=True)
    risk_factors_status: Mapped[str] = mapped_column(String, nullable=False)
    risk_factors_reason_code: Mapped[str | None] = mapped_column(String, nullable=True)
    doctors_status: Mapped[str] = mapped_column(String, nullable=False)
    doctors_reason_code: Mapped[str | None] = mapped_column(String, nullable=True)
    # Деталь причины blocked_by_other_instruments — коды инструментов, обнуливших заболевания. Причина
    # новыми прогонами не выставляется, и они пишут NULL; заполнена только у строк, записанных раньше.
    blocking_instrument_codes: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=func.now())
