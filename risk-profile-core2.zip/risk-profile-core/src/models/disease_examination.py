import uuid

from sqlalchemy import CheckConstraint, ForeignKey, Integer, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class DiseaseExamination(Base):
    """Исследование, рекомендованное группе заболеваний.

    Тип исследования не дублируется — он берётся из `examinations.examination_type`. Категория
    различает базовые и дополнительные лабораторные анализы и отсутствует у инструментальных.
    """

    __tablename__ = "disease_examinations"
    __table_args__ = (
        CheckConstraint("category IS NULL OR category IN ('basic', 'extended')", name="category"),
        UniqueConstraint(
            "disease_code",
            "examination_code",
            name="uq_disease_examinations_disease_code_examination_code",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    disease_examination_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    disease_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.diseases.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    examination_code: Mapped[uuid.UUID] = mapped_column(
        Uuid(), ForeignKey("catalog.examinations.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    category: Mapped[str | None] = mapped_column(String, nullable=True)
