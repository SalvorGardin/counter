from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class ClinicalRecommendation(Base):
    """Клиническая рекомендация — источник, которым обоснован балл фактора риска в группе."""

    __tablename__ = "clinical_recommendations"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    clinrec_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
