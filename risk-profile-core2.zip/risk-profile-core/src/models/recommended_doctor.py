from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RecommendedDoctor(Base):
    __tablename__ = "recommended_doctors"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    recommended_doctor_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    risk_level: Mapped[str] = mapped_column(String, nullable=False)
    code: Mapped[int] = mapped_column(Integer, ForeignKey("catalog.doctors.code", ondelete="RESTRICT"), nullable=False)
