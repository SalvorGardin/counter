from sqlalchemy import ForeignKey, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class InstrumentParameter(Base):
    __tablename__ = "instruments_parameters"
    __table_args__ = (
        UniqueConstraint(
            "instrument_code",
            "parameter_code",
            name="uq_instruments_parameters_instrument_parameter",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    instrument_parameter_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    instrument_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.instruments.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    is_required: Mapped[bool] = mapped_column(nullable=False)
