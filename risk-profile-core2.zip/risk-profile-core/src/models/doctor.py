from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Doctor(Base):
    __tablename__ = "doctors"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    doctor_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(String, nullable=False)
