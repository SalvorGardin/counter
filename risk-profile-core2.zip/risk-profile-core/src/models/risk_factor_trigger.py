from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKey, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class RiskFactorTrigger(Base):
    __tablename__ = "risk_factor_triggers"
    __table_args__ = (
        CheckConstraint("value_type IN ('text', 'number')", name="ck_risk_factor_triggers_value_type"),
        CheckConstraint(
            "operator IN ('eq', 'gt', 'gte', 'lt', 'lte', 'between')",
            name="ck_risk_factor_triggers_operator",
        ),
        CheckConstraint("gender IS NULL OR gender IN ('Мужской', 'Женский')", name="ck_risk_factor_triggers_gender"),
        CheckConstraint(
            "(value_type = 'text' AND operator = 'eq' AND value_text IS NOT NULL "
            "AND value_num IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator IN ('gt', 'gte', 'lt', 'lte') AND value_num IS NOT NULL "
            "AND value_text IS NULL AND min_value IS NULL AND max_value IS NULL) OR "
            "(value_type = 'number' AND operator = 'between' AND value_num IS NULL "
            "AND value_text IS NULL AND min_value IS NOT NULL AND max_value IS NOT NULL AND min_value <= max_value)",
            name="ck_risk_factor_triggers_value_shape",
        ),
        UniqueConstraint("trigger_code", name="uq_risk_factor_triggers_trigger_code"),
        # Естественный ключ условия — рядом с trigger_code, а не вместо него: код держит
        # идентичность строки между перезаливками каталога, а этот ключ не даёт завести одну и ту
        # же проверку дважды в паре «фактор + система». Незаполненные поля условия входят в ключ
        # (`nulls_not_distinct`), иначе ограничение не срабатывало бы ни на одной строке: пустые
        # поля есть у каждой формы условия.
        UniqueConstraint(
            "risk_factor_code",
            "system_code",
            "parameter_code",
            "operator",
            "value_num",
            "min_value",
            "max_value",
            "value_text",
            "gender",
            name="uq_risk_factor_triggers_condition",
            postgresql_nulls_not_distinct=True,
        ),
        {"schema": CATALOG_SCHEMA},
    )

    # trigger_id — суррогатный PK, раздаваемый при заливке каталога в порядке строк CSV. Он
    # воспроизводит порядок, который до нормализации давал `risk_factors.risk_factor_id`, и служит
    # тай-брейком при равных баллах (wiki «Интерпретация» §4.3). Идентичность строки между
    # перезаливками держит trigger_code — по нему справочник связывается с диагностикой.
    trigger_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    trigger_code: Mapped[str] = mapped_column(String, nullable=False)
    risk_factor_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.risk_factors.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    value_type: Mapped[str] = mapped_column(String, nullable=False)
    operator: Mapped[str] = mapped_column(String, nullable=False)
    value_num: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    min_value: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    max_value: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    value_text: Mapped[str | None] = mapped_column(String, nullable=True)
    gender: Mapped[str | None] = mapped_column(String, nullable=True)
