from datetime import datetime

from sqlalchemy import TIMESTAMP, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class Interpretation(Base):
    __tablename__ = "interpretations"
    __table_args__ = (
        UniqueConstraint("patient_id", "system_code", name="uq_interpretations_patient_id_system_code"),
        {"schema": CALCULATION_SCHEMA},
    )

    interpretation_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False
    )
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    risk_level: Mapped[str | None] = mapped_column(String, nullable=True)
    text: Mapped[str | None] = mapped_column(String, nullable=True)
    diseases: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    risk_factors_code: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    doctors_code: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
