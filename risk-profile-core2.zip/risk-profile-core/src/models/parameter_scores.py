from decimal import Decimal

from sqlalchemy import ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Score(Base):
    __tablename__ = "parameter_scores"
    __table_args__ = {"schema": CATALOG_SCHEMA}

    score_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    value: Mapped[str | None] = mapped_column(String, nullable=True)
    min_value: Mapped[Decimal | None] = mapped_column(Numeric(precision=12, scale=6), nullable=True)
    max_value: Mapped[Decimal | None] = mapped_column(Numeric(precision=12, scale=6), nullable=True)
    score: Mapped[Decimal] = mapped_column(Numeric(precision=6, scale=3), nullable=False)
