from sqlalchemy import CheckConstraint, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Biomarker(Base):
    """Биомаркер в одной допустимой единице измерения.

    Строка справочника связана 1:1 с параметром: значение биомаркера сохраняется в
    `patients_parameters` под кодом `parameter_code`. У биомаркера, значение которого приходит в
    нескольких единицах измерения, на каждую единицу заведена своя строка и свой параметр.
    """

    __tablename__ = "biomarkers"
    __table_args__ = (
        CheckConstraint("type IN ('quantitative', 'qualitative')", name="type"),
        # Единица измерения и её код приходят и хранятся только вместе: код без названия не
        # показать пользователю, название без кода не сопоставить со справочником-источником.
        CheckConstraint("(unit IS NULL) = (unit_code IS NULL)", name="unit_pair"),
        # Биомаркер без единицы измерения существует в единственной строке, поэтому пустой
        # `unit_code` обязан конфликтовать сам с собой — отсюда `nulls_not_distinct`.
        UniqueConstraint(
            "biomarker_code",
            "unit_code",
            name="uq_biomarkers_biomarker_code_unit_code",
            postgresql_nulls_not_distinct=True,
        ),
        {"schema": CATALOG_SCHEMA},
    )

    biomarker_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    biomarker_code: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Уникальность parameter_code держит связь 1:1 и сама даёт индекс под внешний ключ.
    parameter_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.parameters.code", ondelete="RESTRICT"), nullable=False, unique=True
    )
    name: Mapped[str] = mapped_column(String, nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    unit: Mapped[str | None] = mapped_column(String, nullable=True)
