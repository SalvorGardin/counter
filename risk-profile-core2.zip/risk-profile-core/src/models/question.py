from sqlalchemy import Boolean, CheckConstraint, String
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA


class Question(Base):
    __tablename__ = "questions"
    __table_args__ = (
        # Родовые формы текста заполняются парой: обе пусты либо обе непустые. Только для
        # отображения пациенту — в хранение ответа, условия и расчёт не входят.
        CheckConstraint(
            "(question_male IS NULL AND question_female IS NULL) OR "
            "(question_male IS NOT NULL AND question_female IS NOT NULL "
            "AND question_male <> '' AND question_female <> '')",
            name="gendered_pair",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    question_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    question: Mapped[str] = mapped_column(String, nullable=False)
    question_male: Mapped[str | None] = mapped_column(String, nullable=True)
    question_female: Mapped[str | None] = mapped_column(String, nullable=True)
    type: Mapped[str] = mapped_column(String, nullable=False)
    group_code: Mapped[int] = mapped_column(nullable=False)
    is_skippable: Mapped[bool] = mapped_column(Boolean, nullable=False)
