import uuid

from sqlalchemy import CheckConstraint, ForeignKey, Integer, String, Uuid, text
from sqlalchemy.dialects.postgresql import ExcludeConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CATALOG_SCHEMA

# Пол строки как отрезок: 'Мужской' → [0,1), 'Женский' → [1,2), NULL («без ограничения по полу»)
# → [0,2). Отрезки мужской и женской строк не пересекаются, общая строка перекрывает оба.
_GENDER_SLOT_SQL = (
    "CASE gender WHEN 'Мужской' THEN int4range(0, 1) WHEN 'Женский' THEN int4range(1, 2) ELSE int4range(0, 2) END"
)


class SystemCheckupExamination(Base):
    """Исследование общего чек-апа системы организма с условием по полу клиента.

    У системы один общий чек-ап: его состав задают все подходящие строки таблицы, отдельной
    сущности чек-апа и отдельного кода у него нет.
    """

    __tablename__ = "system_checkup_examinations"
    __table_args__ = (
        CheckConstraint("gender IS NULL OR gender IN ('Мужской', 'Женский')", name="gender"),
        # Для пары (система, исследование) допустима либо одна общая строка с пустым `gender`,
        # либо строки по полу. Это условие пар строк, поэтому его держит EXCLUDE, а не UNIQUE:
        # запрещено пересечение отрезков пола внутри пары. Общая строка перекрывает оба слота и
        # конфликтует и с полоспецифичной строкой, и сама с собой — так что то же ограничение
        # даёт и уникальность тройки (system_code, examination_code, gender) с NULLS NOT
        # DISTINCT. Сравнение по `=` внутри GiST требует расширения btree_gist (ставит 0138).
        ExcludeConstraint(
            ("system_code", "="),
            ("examination_code", "="),
            # Статическое SQL-выражение ограничения; пользовательские данные в него не попадают.
            (text(f"({_GENDER_SLOT_SQL})"), "&&"),  # nosemgrep
            name="ex_system_checkup_examinations_gender_scope",
            using="gist",
        ),
        {"schema": CATALOG_SCHEMA},
    )

    system_checkup_examination_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    examination_code: Mapped[uuid.UUID] = mapped_column(
        Uuid(), ForeignKey("catalog.examinations.code", ondelete="RESTRICT"), nullable=False, index=True
    )
    gender: Mapped[str | None] = mapped_column(String, nullable=True)
