from datetime import datetime

from sqlalchemy import TIMESTAMP, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import CALCULATION_SCHEMA


class InterpretationHistory(Base):
    """Аудитный след `interpretations`: строка копируется сюда при архивировании и не читается.

    `diseases` — колонка со смешанным словарём, и это постоянное состояние, а не переходное.
    Строки, заархивированные до перевода групп заболеваний на коды справочника, хранят названия;
    все последующие приходят кодами (`diseases.code`). Миграция перевода историю не переписывала:
    она правит живые данные, а след остаётся тем, чем был записан. Запрос в обход сервиса обязан
    учитывать оба вида; маршрутов, читающих колонку, в сервисе нет.
    """

    __tablename__ = "interpretations_history"
    __table_args__ = (
        Index("ix_interpretations_history_patient_id_system_code", "patient_id", "system_code"),
        {"schema": CALCULATION_SCHEMA},
    )

    interpretations_history_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    system_code: Mapped[str] = mapped_column(
        String, ForeignKey("catalog.systems.code", ondelete="RESTRICT"), nullable=False
    )
    patient_id: Mapped[str] = mapped_column(
        String, ForeignKey("risk_profile.patients.patient_id", ondelete="RESTRICT"), nullable=False
    )
    risk_level: Mapped[str | None] = mapped_column(String, nullable=True)
    text: Mapped[str | None] = mapped_column(String, nullable=True)
    diseases: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    risk_factors_code: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    doctors_code: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    date_time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
