from sqlalchemy import String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from src.infra.database import Base
from src.infra.db_schemas import PROFILE_SCHEMA


class Patient(Base):
    __tablename__ = "patients"
    __table_args__ = (
        UniqueConstraint("patient_id", name="uq_patients_patient_id"),
        {"schema": PROFILE_SCHEMA},
    )

    unique_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[str] = mapped_column(String, nullable=False)
    # nullable: NULL = пациент ещё не отвечал на cq_030; False/True = отвечал «нет»/«да».
    # Отличие нужно шагам 7/11 risk-communication (см. wiki, особый случай cq_030).
    is_pregnant: Mapped[bool | None] = mapped_column(nullable=True, default=None)
