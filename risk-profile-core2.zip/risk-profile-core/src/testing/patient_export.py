import io
import json
import zipfile
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import inspect

from src.testing.infra.patient_export_repository import PatientExportRepository, PatientExportRows

ARCHIVE_FILES = (
    "patients.json",
    "patients_parameters.json",
    "interpretations.json",
    "results.json",
)


def _json_value(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, list):
        return [_json_value(item) for item in value]
    return value


def model_row(model: object) -> dict[str, Any]:
    return {column.key: _json_value(getattr(model, column.key)) for column in inspect(type(model)).columns}


def build_patient_archive(rows: PatientExportRows) -> bytes:
    documents = {
        "patients.json": [model_row(rows.patient)],
        "patients_parameters.json": [model_row(row) for row in rows.patient_parameters],
        "interpretations.json": [model_row(row) for row in rows.interpretations],
        "results.json": [model_row(row) for row in rows.results],
    }
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        for filename in ARCHIVE_FILES:
            content = json.dumps(documents[filename], ensure_ascii=False, separators=(",", ":"))
            archive.writestr(filename, content.encode("utf-8"))
    return buffer.getvalue()


class PatientExportService:
    def __init__(self, repository: PatientExportRepository) -> None:
        self._repository = repository

    async def export(self, patient_id: str) -> bytes | None:
        rows = await self._repository.load(patient_id)
        return None if rows is None else build_patient_archive(rows)
