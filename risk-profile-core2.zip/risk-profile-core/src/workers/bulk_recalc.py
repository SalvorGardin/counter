"""Продюсер массового пересчёта: разовый процесс, публикующий команды по когорте устаревших профилей.

Запуск: `python -m src.workers.bulk_recalc`. Носитель запуска в проде — k8s CronJob: расписание,
ручной запуск тем же Job'ом, `concurrencyPolicy: Forbid` против параллельных прогонов и
`activeDeadlineSeconds` как жёсткий потолок. Планировщик внутри процессов, обслуживающих трафик,
не годится: расписание отработало бы в каждой реплике.

Состояние прогона — сам реестр версий, а не курсор процесса. Отсюда три свойства даром: прогон
самозавершается (когорта тает по мере штампования), повторный запуск не дублирует работу, а
рестарт пода стоит одного повторно опубликованного батча.

Процесс ходит в БД под собственным логином, которому выдано ТОЛЬКО чтение реестра
(см. `src/infra/db_schemas.py`): списка идентификаторов ему достаточно, а под логином расчёта он
получил бы право переписать результаты любого пациента.

Команды публикуются с признаком фоновой: воркер вправе отбросить такую команду, если фоновый слот
занят или внешний сервис риска насыщен (см. `src/calc/background_admission.py`). Отброшенный
пациент остаётся в когорте и достаётся следующему прогону, поэтому избыточная публикация здесь —
осознанный размен: пропускная способность Kafka на порядки выше пропускной способности расчёта.
Команды проверочного батча — тоже фоновые (см. `probe_rollout`).
"""

import asyncio
import contextlib
import os
import signal
import time
import uuid
from collections.abc import Awaitable, Iterator, Mapping
from dataclasses import dataclass
from enum import StrEnum

import uvloop
from sqlalchemy.exc import InterfaceError, OperationalError
from sqlalchemy.ext.asyncio import AsyncSession

from src.calc.infra.version_registry import Stamp, VersionRegistry
from src.calc.recalc_message import encode_command
from src.calc.version import require_calculation_version
from src.config import ServiceRuntime, notice_legacy_db_env, settings
from src.constants import KAFKA_HEADER_REQUEST_ID
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime, verify_runtime_login
from src.infra.kafka import init_kafka_producer, shutdown_kafka_producer
from src.infra.kafka.exceptions import KafkaInitError, KafkaPublishError
from src.infra.kafka.producer import KafkaProducer, get_kafka_producer
from src.logger import alert, logger, notice, request_id_var

_NAME = "calc.bulk_recalc"
# Роль процесса: только чтение реестра версий, ни результатов, ни данных профиля.
_RUNTIME = ServiceRuntime.BULK_RECALC

# Коды завершения. Ноль — исчерпанная когорта и упёршийся в потолок времени прогон: и то, и
# другое штатно. Ненулевой — прогон не состоялся, и Job в Kubernetes обязан выглядеть сбойным.
_EXIT_OK = 0
_EXIT_NOT_RUN = 1
# Прогон, оборванный сигналом, завершается кодом 128 + номер сигнала — как процесс, убитый им.
_EXIT_SIGNAL_BASE = 128

# Сигналы остановки: SIGTERM шлют `docker stop` и Kubernetes, SIGINT — Ctrl-C в
# `docker compose run`. Обработчик нужен не только для записи в журнал: в контейнере процесс —
# PID 1, и ядро ОТБРАСЫВАЕТ адресованный ему SIGTERM, если обработчика нет. Тогда процесс доживает
# до SIGKILL по истечении grace-периода и исчезает, не оставив в журнале ничего после последнего
# `batch published`. SIGKILL (OOM, конец grace-периода) не перехватывается: такой прогон виден
# только как `starting` без `complete` и без ERROR.
_STOP_SIGNALS = (signal.SIGTERM, signal.SIGINT)


class RolloutProbe(StrEnum):
    """Итог проверочного батча."""

    # Батч посчитан текущей версией, прошлая версия в нём не встретилась.
    COMPLETE = "complete"
    # Хотя бы одного пациента батча посчитал воркер прошлой версии.
    INCOMPLETE = "incomplete"
    # Не посчитан ни один пациент батча: воркеры не разбирают топик, либо в когорте остались
    # только пациенты с устойчиво падающим пересчётом. Раскат при этом может быть завершён.
    NOT_RECALCULATED = "not_recalculated"


@dataclass(frozen=True, slots=True)
class CohortWalk:
    """Итог обхода когорты."""

    published: int
    # Обход остановил потолок времени прогона, а не исчерпание когорты.
    stopped_by_time_budget: bool


class BulkRecalcRun:
    """Один прогон: проверка раската, обход когорты и публикация команд.

    Границы прогона задаются конфигурацией (`settings.bulk_recalc`), а его состояние — реестром,
    поэтому объект не хранит ни курсора, ни счётчика, переживающего процесс.

    Каждое чтение реестра закрывает свою транзакцию сразу (`_end_transaction`): прогон длится до
    часа, и одна транзакция на всю сессию держала бы снапшот всё это время — горизонт `xmin` не
    двигался бы, и autovacuum не вычищал бы мёртвые версии строк ровно тогда, когда пересчёт их
    порождает. Страницы и так читаются по свежим данным, курсор keyset от этого не зависит.

    Каждое чтение ограничено `query_timeout_seconds`: потолок времени прогона проверяется между
    пачками, и зависший запрос не дал бы до этой проверки дойти.
    """

    def __init__(self, session: AsyncSession, producer: KafkaProducer, version: str) -> None:
        self._session = session
        self._registry = VersionRegistry(session)
        self._producer = producer
        self._version = version
        self._settings = settings.bulk_recalc
        self._topic = settings.kafka.topics.recalc_commands
        # Сколько команд ушло проверочным батчем. В `published` обхода они не входят, а когорту
        # не больше `canary_size` батч выбирает целиком — без этого счётчика такой прогон выглядел бы
        # в итоговой записи как ничего не опубликовавший.
        self.canary_published = 0

    async def cohort_size(self) -> int:
        """Размер когорты текущей версии."""
        return await self._read(self._registry.cohort_size(self._version))

    async def _read[T](self, query: Awaitable[T]) -> T:
        """Выполнить чтение реестра с таймаутом и закрыть его транзакцию до возврата."""
        result = await asyncio.wait_for(query, self._settings.query_timeout_seconds)
        await self._end_transaction()
        return result

    async def _end_transaction(self) -> None:
        """Закрыть транзакцию, открытую чтением реестра (autobegin), чтобы соединение не висело
        `idle in transaction` на время паузы, ожидания или публикации."""
        await self._session.commit()

    async def publish(self, patient_id: str) -> None:
        """Опубликовать фоновую команду ПОЛНОГО пересчёта по пациенту.

        Команда фоновая всегда, в том числе в проверочном батче: в метриках воркера пересчёты
        прогона идут рядами `source="background"` и не подмешиваются в пользовательский SLI.

        Ключ — идентификатор пациента: все его команды идут в одну партицию, поэтому порядок
        пересчётов на пациента сохраняется и фоновая команда не обгоняет пользовательскую.

        `x-request-id` у каждой команды свой: идентификатор процесса прогона слил бы в логах воркера
        все пересчёты прогона в один `requestId`, и судьбу отдельного пациента (его идентификатор
        в логах маскируется) по ним было бы не разобрать.
        """
        await self._producer.send(
            topic=self._topic,
            value=encode_command(patient_id, None, enqueued_at=time.time(), background=True),
            key=patient_id,
            headers={KAFKA_HEADER_REQUEST_ID: str(uuid.uuid4())},
        )

    async def probe_rollout(self) -> RolloutProbe:
        """Опубликовать проверочный батч и дождаться, чем воркеры его посчитают.

        Не чтение, а действие: команды уходят в топик, а ожидание длится до
        `canary_timeout_seconds`. Команды батча фоновые, как и остальные команды прогона, и
        проходят через политику допуска воркера: при закрытом фоне (нет слотов, насыщен внешний
        сервис) их отбросят, и батч закончится исходом `NOT_RECALCULATED`. Отброс штампа не
        оставляет, поэтому на признак прошлой версии он не влияет.

        Батч — случайная выборка из когорты, а не её первая страница: устойчиво сбойные
        пациенты из когорты не выходят, и первая страница в установившемся режиме состояла бы
        ровно из них.

        По каждому пациенту батча реестр отвечает одним из трёх способов: штамп текущей версии
        (посчитал воркер новой версии), сдвинутый `calculated_at` при прежней версии (посчитал
        воркер прошлой версии) или ничего (команда ещё в очереди, либо пересчёт упал). Хотя бы
        один пациент прошлой версии — раскат не завершён: остаток батча не ждём. Иначе ждём, пока
        посчитают всех, и не выходим по первому штампу — по нему прошла бы и одна обновлённая
        реплика из нескольких. Обнаружение прошлой версии вероятностное: партиции, которых батч
        не коснулся, проверкой не покрыты.

        Воркер релиза, в котором реестра ещё не было, реестр не трогает вовсе, и для него
        проверка сводится к «кто-то посчитал текущей версией».
        """
        canary = await self._read(self._registry.cohort_sample(self._version, limit=self._settings.canary_size))
        if not canary:
            return RolloutProbe.COMPLETE
        before = await self._read(self._registry.stamps_of(canary))
        for patient_id in canary:
            await self.publish(patient_id)
            self.canary_published += 1
        notice(f"{_NAME}: canary published", context={"patients": len(canary)})

        current = 0
        deadline = time.monotonic() + self._settings.canary_timeout_seconds
        while time.monotonic() < deadline:
            await asyncio.sleep(self._settings.canary_poll_interval_seconds)
            current, previous = self._tally(before, await self._read(self._registry.stamps_of(canary)))
            if previous:
                return RolloutProbe.INCOMPLETE
            if current == len(canary):
                return RolloutProbe.COMPLETE
        return RolloutProbe.COMPLETE if current else RolloutProbe.NOT_RECALCULATED

    def _tally(self, before: Mapping[str, Stamp], after: Mapping[str, Stamp]) -> tuple[int, int]:
        """Сколько пациентов батча посчитано текущей версией и сколько — прошлой."""
        current = previous = 0
        for patient_id, stamp in after.items():
            if stamp.version == self._version:
                current += 1
            elif patient_id not in before or stamp.calculated_at != before[patient_id].calculated_at:
                previous += 1
        return current, previous

    async def walk_cohort(self) -> CohortWalk:
        """Обойти когорту батчами и опубликовать по команде на пациента.

        Курсор keyset-пагинации живёт только внутри вызова: прерванный прогон продолжит
        следующий запуск — по реестру, а не по сохранённому месту.
        """
        deadline = time.monotonic() + self._settings.time_budget_seconds
        published = 0
        cursor: str | None = None
        while True:
            if time.monotonic() >= deadline:
                return CohortWalk(published, stopped_by_time_budget=True)
            page = await self._read(
                self._registry.cohort_page(self._version, after=cursor, limit=self._settings.batch_size)
            )
            if not page:
                return CohortWalk(published, stopped_by_time_budget=False)
            for patient_id in page:
                await self.publish(patient_id)
            published += len(page)
            cursor = page[-1]
            notice(f"{_NAME}: batch published", context={"published": published})
            await asyncio.sleep(self._settings.pause_seconds)


async def _run(version: str) -> int:
    if not settings.bulk_recalc.enabled:
        notice(f"{_NAME}: disabled by configuration, nothing published", context={"enabled": False})
        return _EXIT_OK
    if not settings.kafka.enabled:
        # Пересчёт идёт только через топик команд: без Kafka публиковать некуда, и молчаливый
        # успешный прогон выглядел бы выполненной работой.
        alert(f"{_NAME}: kafka is disabled, the run cannot publish commands", {"kafka_enabled": False})
        return _EXIT_NOT_RUN

    # Логин приносит строка подключения. Сверяем с БД, а не верим на слово.
    await verify_runtime_login(get_primary_runtime().engine, _RUNTIME)
    await init_kafka_producer()
    try:
        return await _publish_cohort(version)
    finally:
        await shutdown_kafka_producer()
        await shutdown_primary_runtime()


async def _publish_cohort(version: str) -> int:
    async with get_primary_runtime().session_factory() as session:
        run = BulkRecalcRun(session, get_kafka_producer(), version)
        cohort_at_start = await run.cohort_size()
        notice(f"{_NAME}: starting", context={"version": version, "cohort_size": cohort_at_start})
        if cohort_at_start == 0:
            notice(f"{_NAME}: cohort is empty, nothing to publish", context={"version": version})
            return _EXIT_OK

        probe = await run.probe_rollout()
        if probe is RolloutProbe.INCOMPLETE:
            # Расчёт ведёт процесс прошлой версии: прогон впустую нагружал бы базу и внешний
            # сервис риска, а когорта не таяла бы.
            alert(
                f"{_NAME}: rollout is incomplete, the run is aborted",
                {"version": version, "cohort_size": cohort_at_start},
            )
            return _EXIT_NOT_RUN
        if probe is RolloutProbe.NOT_RECALCULATED:
            # Отдельный alert: о раскате батч ничего не сказал, а причина — либо стоящие воркеры,
            # либо когорта из одних сбойных пациентов. И то, и другое требует человека.
            alert(
                f"{_NAME}: no canary patient was recalculated, the run is aborted",
                {"version": version, "cohort_size": cohort_at_start},
            )
            return _EXIT_NOT_RUN

        # Вход замеряется ПОСЛЕ проверочного батча: исход COMPLETE значит, что батч вывел из когорты
        # хотя бы часть своих пациентов. Считай мы вход до него — когорта уменьшалась бы всегда,
        # и признак «прогон ничего не добился» не сработал бы никогда.
        cohort_before = await run.cohort_size()
        walk = await run.walk_cohort()
        cohort_after = await run.cohort_size()

    notice(
        f"{_NAME}: complete",
        context={
            "version": version,
            "cohort_size_at_start": cohort_at_start,
            "canary_published": run.canary_published,
            "published": walk.published,
            "cohort_size_in": cohort_before,
            "cohort_size_out": cohort_after,
            "stopped_by_time_budget": walk.stopped_by_time_budget,
        },
    )
    if cohort_before > 0 and cohort_after >= cohort_before:
        # Грубый запасной признак: авторитетно о результате прогона говорят счётчики принятых и
        # отброшенных фоновых команд на стороне воркера — пользовательский трафик уменьшает
        # когорту независимо от прогона, а голодание фона иначе ничем себя не проявит.
        alert(
            f"{_NAME}: cohort did not shrink",
            {"cohort_size_in": cohort_before, "cohort_size_out": cohort_after, "published": walk.published},
        )
    return _EXIT_OK


@dataclass(slots=True)
class _Interruption:
    """Сигнал, оборвавший прогон; `None` — прогон сигналом не обрывался."""

    signum: int | None = None


@contextlib.contextmanager
def _cancel_on_stop_signals(task: asyncio.Task) -> Iterator[_Interruption]:
    """На время блока перевести сигналы остановки в отмену задачи прогона.

    Отмена, а не немедленный выход: `finally` в `_run` успевает остановить продюсер Kafka и
    закрыть пул соединений, а `_main` — записать в журнал, чем кончился прогон. Повторный сигнал
    вторую отмену не посылает: очистка уже идёт.
    """
    loop = asyncio.get_running_loop()
    interruption = _Interruption()

    def _on_signal(signum: int) -> None:
        if interruption.signum is None:
            interruption.signum = signum
            task.cancel()

    for signum in _STOP_SIGNALS:
        loop.add_signal_handler(signum, _on_signal, signum)
    try:
        yield interruption
    finally:
        for signum in _STOP_SIGNALS:
            loop.remove_signal_handler(signum)


async def _main() -> int:
    request_id_var.set(f"bulk-recalc-{os.getpid()}")
    notice_legacy_db_env()
    # Роль объявляет точка входа, строку подключения даёт переменная роли. Соединений пока нет.
    init_primary_runtime(_RUNTIME)
    version = require_calculation_version()
    task = asyncio.current_task()
    assert task is not None  # _main всегда выполняется внутри задачи asyncio.run
    with _cancel_on_stop_signals(task) as interruption:
        try:
            return await _run(version)
        except asyncio.CancelledError:
            if interruption.signum is None:
                raise
            # Отмена наша и обработана: снимаем её со счётчика задачи, чтобы код выше не принял
            # задачу за всё ещё отменяемую.
            task.uncancel()
            # ERROR, а не NOTICE: необойдённая часть когорты достанется следующему запуску, но
            # оборванный прогон — событие, которое человек обязан увидеть и объяснить.
            logger.error(
                f"{_NAME}: interrupted by signal, the run is incomplete",
                extra={"log_context": {"signal": signal.Signals(interruption.signum).name, "version": version}},
            )
            return _EXIT_SIGNAL_BASE + interruption.signum
        except (KafkaInitError, KafkaPublishError):
            # Публиковать некуда или публикация упала: прогон не состоялся, и Job обязан выглядеть
            # сбойным, а не «ничего не сделал и завершился успешно».
            logger.exception(f"{_NAME}: failed to publish recalc commands")
            return _EXIT_NOT_RUN
        except (TimeoutError, OperationalError, InterfaceError):
            # Обращение к реестру зависло дольше `query_timeout_seconds` или потеряло соединение:
            # прогон прерван, и Job обязан выглядеть сбойным. Недообойдённая когорта достанется
            # следующему запуску. Ловим только преходящие сбои (тот же набор, что `DEFAULT_RETRIABLE`
            # в `src/infra/db_retry.py`): ошибка в самом запросе или схеме повторным запуском не
            # лечится и должна упасть своим исключением, а не под видом таймаута.
            logger.exception(
                f"{_NAME}: registry query failed or timed out", extra={"log_context": {"version": version}}
            )
            return _EXIT_NOT_RUN
        except Exception:
            # Непредвиденная ошибка не маскируется под штатный исход и уходит наружу своим
            # исключением. Но трассировку необработанного исключения интерпретатор печатает в
            # stderr простым текстом мимо форматтера — в журнал она попадает только отсюда.
            logger.exception(f"{_NAME}: run failed unexpectedly", extra={"log_context": {"version": version}})
            raise


if __name__ == "__main__":
    uvloop.install()
    raise SystemExit(asyncio.run(_main()))
