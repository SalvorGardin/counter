"""Рантайм consumer-воркера: то, что одинаково у воркеров разных топиков.

Модуль свободен от домена — он не знает ни про пересчёт, ни про биомаркеры. Здесь живут запуск
и остановка сервера HTTP-проб, ожидание бинда порта, обработка сигналов и старт консюмера
с бэкоффом. Это не шаблонный код: в нём сидят неочевидные требования — пробы обязаны отвечать
раньше, чем воркер вступит в consumer-группу, занятый порт обязан ронять процесс, а не оставлять
его с мёртвыми пробами, а бэкофф должен переживать «воркер поднялся раньше брокера». Держим их
в одном месте, чтобы правка доезжала сразу до всех воркеров.

Жизненный цикл конкретного воркера — что он поднимает на старте, как дренит батч и что гасит
на выходе — остаётся в его собственном модуле: он у воркеров разный.

Параметр `name` — имя воркера в наблюдаемости: им начинаются его лог-сообщения
(`calc.consumer: ...`) и из него же собирается requestId процесса (`calc-consumer-<pid>`),
по которому в логах фильтруются записи одного воркера.
"""

import asyncio
import contextlib
import os
import signal
from collections.abc import Awaitable, Callable

import uvicorn

from src.config import settings
from src.infra.kafka import KafkaTopicConsumer
from src.infra.kafka.exceptions import KafkaInitError
from src.logger import alert, logger, notice, request_id_var
from src.workers.health import WorkerHealth, build_server

# Брокер может подниматься чуть позже воркера при деплое — даём ему время вместо restart-loop.
_START_RETRY_DELAYS = (1, 2, 3, 5, 8, 13)
# Пробы отвечают мгновенно, так что серверу на остановку нужен лишь короткий бюджет.
_HEALTH_STOP_TIMEOUT = 5.0
# Бинд порта — операция старта uvicorn; если за это время сервер не поднялся, считаем старт сбойным.
_HEALTH_START_TIMEOUT = 5.0

# Основной цикл воркера: получает состояние проб и владеет консюмером от старта до остановки.
type WorkerRun = Callable[[WorkerHealth], Awaitable[None]]

# Освобождение ресурсов конкретного воркера на выходе. Аргумент — остаток бюджета остановки
# в секундах: то, что ещё можно потратить после выхода консюмера из группы.
type Teardown = Callable[[float], Awaitable[None]]


def listen_for_stop() -> asyncio.Event:
    """Событие остановки, взводимое по SIGINT/SIGTERM."""
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(sig, stop.set)
    return stop


async def idle_until_signal() -> None:
    """Простой до сигнала остановки — режим воркера с выключенным консюмером."""
    await listen_for_stop().wait()


async def start_consumer_with_retry(consumer: KafkaTopicConsumer, *, name: str) -> None:
    """Старт консюмера с бэкоффом — переживаем ситуацию «воркер поднялся раньше брокера»."""
    last_error: KafkaInitError | None = None
    attempts = len(_START_RETRY_DELAYS)
    for attempt, delay in enumerate(_START_RETRY_DELAYS, start=1):
        try:
            await consumer.start()
            return
        except KafkaInitError as exc:
            last_error = exc
            if attempt >= attempts:
                break  # последняя попытка — не спим зря перед пробросом ошибки
            logger.warning(
                f"{name}: start failed, retrying",
                extra={"log_context": {"attempt": attempt, "delay_s": delay, "error": str(exc)}},
            )
            await asyncio.sleep(delay)
    raise last_error if last_error is not None else KafkaInitError("kafka consumer start failed")


async def _await_health_started(server: uvicorn.Server, task: asyncio.Task, *, name: str) -> None:
    """Ждём, пока uvicorn забиндит порт (`server.started`), либо ловим раннее падение `serve()`.

    Сервер проб запущен отдельной задачей — если порт занят, uvicorn бросит из `startup()` наружу
    и задача завершится с исключением. Без этой проверки воркер стартовал бы консюмер и вступил бы
    в группу с мёртвыми пробами: k8s liveness → restart-loop, а причина всплыла бы только на teardown.
    Проброс исключения здесь → процесс упадёт ненулевым кодом и оператор увидит реальный сбой."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + _HEALTH_START_TIMEOUT
    while not server.started:
        if task.done():
            task.result()  # переброс исключения serve() (типично — порт занят)
            raise RuntimeError(f"{name}: health probe server exited before startup")
        if loop.time() >= deadline:
            raise TimeoutError(f"{name}: health probe server did not start within {_HEALTH_START_TIMEOUT}s")
        await asyncio.sleep(0.05)


async def _stop_health_server(server: uvicorn.Server, task: asyncio.Task, *, name: str) -> None:
    """Останавливает сервер проб: should_exit=True → serve() выходит, ждём в пределах таймаута.

    Если serve() упал (типично — порт занят на старте), wait_for на уже-завершённой задаче
    перебросит это исключение сюда — логируем, а не молчим: воркер продолжает работать (пробы —
    обзервабилити, не бизнес-функция), но операционно важно видеть, почему liveness умер.
    Таймаут — serve() не завершилась; wait_for сам отменит задачу."""
    server.should_exit = True
    try:
        await asyncio.wait_for(task, timeout=_HEALTH_STOP_TIMEOUT)
    except TimeoutError:
        pass
    except Exception:
        logger.error(f"{name}: health probe server crashed", exc_info=True)


async def run_worker(run: WorkerRun, *, name: str, health_port: int) -> None:
    """Поднимает сервер проб, отдаёт управление жизненному циклу воркера, гасит пробы на выходе.

    Сервер проб поднимается ПЕРВЫМ и живёт весь жизненный цикл: пробы должны отвечать и в окне
    ретрай-бэкоффа старта консюмера, и в простое при выключенном консюмере. Он делит event loop
    с циклом воркера — поэтому 200 на `/liveness` доказывает, что цикл жив.

    Пробы гасятся последними и вне бюджета остановки воркера: свой короткий таймаут,
    гарантированно на ВСЕХ путях (простой / штатный выход / падение / сбой старта консюмера) —
    задача сервера не должна пережить процесс висящим таском.
    """
    request_id_var.set(f"{name.replace('.', '-')}-{os.getpid()}")
    health = WorkerHealth()
    server = build_server(health, host=settings.host, port=health_port)
    task = asyncio.create_task(server.serve())
    try:
        # Убеждаемся, что порт реально забинден, ДО старта консюмера (см. _await_health_started).
        await _await_health_started(server, task, name=name)
        await run(health)
    finally:
        await _stop_health_server(server, task, name=name)


async def serve_until_stop(
    consumer: KafkaTopicConsumer,
    health: WorkerHealth,
    *,
    name: str,
    teardown: Teardown | None = None,
) -> None:
    """Стартует консюмер, крутит его до сигнала остановки или до падения и гасит с дедлайном.

    Здесь живут четыре требования, которые легко потерять при копировании:
    - `/readiness` отдаёт 200 только пока воркер в группе: True после успешного старта,
      False сразу на входе в drain, чтобы балансировщик снял трафик до остановки;
    - падение `consumer.run()` отличается от штатной остановки. Иначе исключение проглотил бы
      `gather` ниже, процесс завершился бы кодом 0 и docker молча крутил бы restart-loop;
    - остановка укладывается в общий бюджет `consumer_shutdown_timeout`: он делится между
      выходом из группы, дренажом обработки и `teardown`, а не отсчитывается каждому заново;
    - принудительная отмена по таймауту считается сбоем, а не штатным выходом — иначе kill
      зависшего воркера выглядел бы в логах и exit code как нормальное завершение.

    `teardown` — освобождение ресурсов, специфичных для воркера (клиенты, пул соединений).
    Получает остаток бюджета и вызывается ПОСЛЕ выхода консюмера из группы: сначала перестаём
    брать работу, потом отпускаем то, что для неё нужно.

    Сигналы перехватываются до старта консюмера, поэтому SIGTERM в окне ретрай-бэкоффа не теряется.
    """
    stop = listen_for_stop()
    await start_consumer_with_retry(consumer, name=name)
    health.ready = True
    runner = asyncio.create_task(consumer.run())
    stopper = asyncio.create_task(stop.wait())
    crashed: BaseException | None = None
    try:
        # Просыпаемся либо по сигналу, либо если цикл консюмера завершился сам (например, упал).
        done, _ = await asyncio.wait({runner, stopper}, return_when=asyncio.FIRST_COMPLETED)
        if runner in done and not runner.cancelled():
            crashed = runner.exception()
        if crashed is not None:
            logger.error(f"{name}: run loop crashed", exc_info=crashed)
        else:
            notice(f"{name}: shutting down", context={})
    finally:
        health.ready = False
        stopper.cancel()
        loop = asyncio.get_event_loop()
        deadline = loop.time() + settings.consumer_shutdown_timeout

        def remaining() -> float:
            return max(0.0, deadline - loop.time())

        try:
            await asyncio.wait_for(consumer.stop(), timeout=remaining())
        except TimeoutError:
            alert(
                f"{name}: consumer.stop() timed out, LeaveGroup may not have been sent",
                {"timeout_s": settings.consumer_shutdown_timeout},
            )
        try:
            await asyncio.wait_for(asyncio.gather(runner, stopper, return_exceptions=True), timeout=remaining())
        except TimeoutError:
            runner.cancel()
            await asyncio.gather(runner, stopper, return_exceptions=True)
            crashed = RuntimeError(
                f"runner force-cancelled after shutdown timeout ({settings.consumer_shutdown_timeout}s)"
            )
            alert(
                f"{name}: runner force-cancelled after shutdown timeout",
                {"timeout_s": settings.consumer_shutdown_timeout},
            )

        if teardown is not None:
            budget = remaining()
            try:
                await asyncio.wait_for(teardown(budget), timeout=budget)
            except TimeoutError:
                alert(
                    f"{name}: teardown timed out, resources may not have been released cleanly",
                    {"timeout_s": settings.consumer_shutdown_timeout},
                )
    if crashed is not None:
        # Пробрасываем → asyncio.run завершит процесс ненулевым кодом → docker увидит реальный сбой.
        # Пробы гасит finally в run_worker — гарантированно на всех путях, включая этот.
        raise crashed
    notice(f"{name}: stopped", context={})
