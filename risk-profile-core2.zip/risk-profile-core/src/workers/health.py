"""HTTP-пробы здоровья consumer-воркеров (`calc_consumer`, `emr_biomarkers_consumer`).

Воркер — не HTTP-сервис, но и k8s (`httpGet`-пробы), и docker-compose (`healthcheck`)
ждут HTTP-эндпоинты. Поднимаем минимальный Starlette-app на uvicorn как asyncio-задачу
В ТОМ ЖЕ event loop, что и `consumer.run()`: ответ 200 на `/liveness` сам по себе доказывает,
что цикл не задедлочен (отдельный поток/процесс такой гарантии бы не дал). Контракт эндпоинтов
и форма ответа совпадают с `src/main.py` (`/health`, `/readiness`, `/liveness`).

Семантика (по решению дизайна — минимальная):
- `/liveness` — процесс жив, event loop крутится. k8s livenessProbe → рестарт при провале.
- `/readiness` — воркер «стартовал и не в drain» (флаг `WorkerHealth.ready`, ставит цикл воркера).
  503 в окне ретрай-бэкоффа старта консюмера и во время остановки.
- `/health` — агрегат «сервер поднят», для совместимости с compose-healthcheck.
- `/metrics` — экспозиция Prometheus этого процесса (гистограммы времени пересчёта, счётчик
  ошибок). Формат и форма 404 при выключенном флаге — те же, что у `/metrics` в `src/main.py`.
"""

import uvicorn
from prometheus_client import CONTENT_TYPE_LATEST
from starlette import status
from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from src.config import settings
from src.metrics import render


class WorkerHealth:
    """Разделяемое состояние здоровья воркера.

    `ready` выставляет цикл воркера: True после успешного старта консюмера (или сразу — в
    режиме простоя при выключенном консюмере), False при входе в drain. Читается хендлером
    `/readiness`. Обычный атрибут, без блокировки: и запись (`_main`), и чтение (хендлеры)
    живут в одном event loop, гонок нет.
    """

    def __init__(self) -> None:
        self.ready: bool = False


def build_app(health: WorkerHealth) -> Starlette:
    async def liveness(_: Request) -> JSONResponse:
        # 200 доказывает, что event loop жив: сервер делит его с consumer.run().
        return JSONResponse({"status": "alive"})

    async def readiness(_: Request) -> JSONResponse:
        if not health.ready:
            return JSONResponse({"status": "not_ready"}, status_code=status.HTTP_503_SERVICE_UNAVAILABLE)
        return JSONResponse({"status": "ready"})

    async def health_route(_: Request) -> JSONResponse:
        return JSONResponse({"status": "ok"})

    async def metrics_route(_: Request) -> Response:
        # Флаг читается на каждом запросе, как и в src/main.py: выключение метрик не должно
        # требовать пересборки маршрутов.
        if not settings.metrics.enabled:
            return JSONResponse({"detail": "Metrics endpoint is disabled"}, status_code=status.HTTP_404_NOT_FOUND)
        # render() синхронный, а этот сервер делит event loop с consumer.run(): собранный прямо
        # в хендлере ответ конкурировал бы с расчётом и пробами за то же ядро.
        body = await run_in_threadpool(render)
        return Response(content=body, media_type=CONTENT_TYPE_LATEST)

    return Starlette(
        routes=[
            Route("/health", health_route),
            Route("/readiness", readiness),
            Route("/liveness", liveness),
            Route("/metrics", metrics_route),
        ],
    )


def build_server(health: WorkerHealth, *, host: str, port: int) -> uvicorn.Server:
    """Собирает uvicorn.Server для проб. Запускать через `await server.serve()` как задачу.

    `install_signal_handlers` глушим: сигналы (SIGINT/SIGTERM) ловит сам воркер через
    `loop.add_signal_handler`, а uvicorn по умолчанию перевесил бы их на себя и сломал бы
    graceful shutdown консюмера. Остановка сервера — выставлением `server.should_exit = True`.
    access_log выключен: свой per-request лог у воркера не нужен, пробы шумели бы в Kibana.
    """
    config = uvicorn.Config(
        build_app(health),
        host=host,
        port=port,
        access_log=False,
        log_level="warning",
    )
    server = uvicorn.Server(config)
    # Метод есть в рантайме; стабы uvicorn его не объявляют — отсюда ty: ignore.
    server.install_signal_handlers = lambda: None  # ty: ignore[unresolved-attribute]
    return server
