"""Consumer-воркер пересчёта: разбирает команды из топика `recalc_commands` и считает риск.

Запуск: `python -m src.workers.calc_consumer`. Отдельный процесс — расчёт уехал из event loop
API-сервиса (CPU-bound формулы + DB-тяжёлый пересчёт больше не конкурируют с обработкой HTTP).

Масштабирование: поднять N инстансов этого воркера в одной consumer-группе — они поделят
партиции топика команд (cap = `kafka.recalc_commands_partitions`). Один инстанс обрабатывает
до `kafka.consumer.max_concurrency` партиций параллельно. Порядок пересчётов на пациента
сохраняется (ключ=patient_id → одна партиция → последовательная обработка).

Если Kafka выключена (`kafka.enabled=False`) — воркер не падает и не крутит restart-loop,
а простаивает до сигнала (локальная разработка без брокера; пересчёт идёт inline в API-процессе).

Что общие гарантии консюмера (`src/infra/kafka/consumer.py`) значат для этого топика:
- **at-least-once безопасен**: оффсет команды коммитится после обработки батча, а падение
  процесса до commit пригонит команды заново — сам пересчёт идемпотентен (upsert результатов).
- **порядок на пациента**: продюсер кладёт ключ=patient_id → все команды пациента в одной
  партиции → последовательная обработка, гонок upsert по одному пациенту нет.
- **события-результаты — BEST-EFFORT, не at-least-once**: `CalcHandler` публикует их в
  risk-calculation через fire-and-forget (`send_background`). При недоступном брокере событие
  может ПОТЕРЯТЬСЯ (ошибка логируется, но не ретраится), а при передоставке команды —
  ПРОДУБЛИРОВАТЬСЯ. Гарантии доставки самих событий тут нет — downstream должен это допускать.
"""

import asyncio
import functools

import uvloop

from src.calc.background_admission import BackgroundAdmission
from src.calc.dispatcher import run_recalc
from src.calc.infra.cvd_client import init_cvd_client, is_cvd_saturated, shutdown_cvd_client
from src.calc.recalc_message import RecalcCommand, decode_command
from src.calc.version import require_calculation_version
from src.config import ServiceRuntime, notice_legacy_db_env, settings
from src.infra.catalog.builder import Catalogs, catalog_builder
from src.infra.database import init_primary_runtime, shutdown_primary_runtime, verify_runtime_login
from src.infra.kafka import KafkaTopicConsumer, init_kafka_producer, shutdown_kafka_producer
from src.logger import notice
from src.workers.consumer_runtime import idle_until_signal, run_worker, serve_until_stop
from src.workers.health import WorkerHealth

# Имя воркера в наблюдаемости: префикс его лог-сообщений и основа requestId процесса.
_NAME = "calc.consumer"


# Воркер пересчёта ходит в БД под логином расчёта: свои таблицы — свои, данные профиля — через
# локальные представления `risk_calculation.patients*`.
_RUNTIME = ServiceRuntime.CALCULATION


async def _handle_command(value: object, *, catalogs: Catalogs, admission: BackgroundAdmission) -> None:
    """Декодирует команду и запускает пересчёт. `decode_command` бросает на poison —
    консюмер ловит это сам (логирует и пропускает сообщение).

    semaphore=None: конкурентность воркера ограничена `KafkaTopicConsumer._sem` (max_concurrency),
    модульный кап dispatcher'а здесь не нужен (и резал бы max_concurrency>5).

    `catalogs` строятся один раз на старте процесса (см. `_run`) и передаются через partial —
    горячий путь не пересобирает справочники на каждую команду.

    `enqueued_at` — отметка постановки команды в очередь; по ней `run_recalc` заполняет гистограммы
    времени пересчёта. Команда без отметки считается как обычно, но не замеряется.

    Команда массового прогона проходит через политику допуска: если фонового слота нет или внешний
    сервис риска насыщен, она отбрасывается без расчёта. Возврат отсюда означает обработанное
    сообщение, поэтому оффсет коммитится обычным порядком, а ретрая у отброшенной команды нет —
    её пациент остался в когорте и вернётся следующим прогоном. Пользовательская команда через
    политику не проходит вовсе.
    """
    command = decode_command(value)
    if not command.background:
        await _recalc(command, catalogs=catalogs)
        return
    with admission.admit() as admitted:
        if not admitted:
            return
        await _recalc(command, catalogs=catalogs)


async def _recalc(command: RecalcCommand, *, catalogs: Catalogs) -> None:
    await run_recalc(
        command.patient_id,
        command.parameter_codes,
        semaphore=None,
        catalogs=catalogs,
        enqueued_at=command.enqueued_at,
        background=command.background,
    )


async def _main() -> None:
    notice_legacy_db_env()
    # Роль объявляет точка входа, строку подключения даёт переменная роли. Соединений пока нет.
    database = init_primary_runtime(_RUNTIME)
    # Версия расчёта — артефакт релиза, едет в образе (см. `src/calc/version.py`). Воркер штампует
    # ею реестр версий, поэтому её отсутствие — отказ старта, а не проблема первой команды.
    require_calculation_version()
    # Логин приносит строка подключения. Сверяем с БД, а не верим на слово.
    await verify_runtime_login(database.engine, _RUNTIME)
    await run_worker(_run, name=_NAME, health_port=settings.consumer_health_port)


async def _run(health: WorkerHealth) -> None:
    """Основной жизненный цикл воркера. Сервер проб уже поднят `run_worker` и живёт вокруг нас;
    здесь только выставляем `WorkerHealth.ready` на переходах старт/drain."""
    if not settings.kafka.enabled:
        notice("calc.consumer: skipped — kafka disabled, idling", context={})
        health.ready = True  # намеренный простой — контейнер здоров, пробы зелёные
        await idle_until_signal()
        return

    notice(
        "calc.consumer: starting",
        context={
            "topic": settings.kafka.topics.recalc_commands,
            "group_id": settings.kafka.consumer.group_id,
        },
    )
    # Статические каталоги справочников строятся ОДИН раз на старте воркера (после миграций/сидов);
    # тем же вызовом стартовый heap уходит из-под gen2-сборки (иначе она обходит каталог на каждом
    # проходе и даёт stop-the-world паузы ~45мс в хвосте — см. freeze_startup_heap). Пустой/
    # непрогруженный каталог → CatalogLoadError → процесс не стартует. Идёт ДО клиентов: заморозка
    # накрывает всё живое, а объекты продюсера и cvd переживают переподключения и в permanent
    # generation им не место. Сервер проб поднят до входа сюда намеренно — пробы должны отвечать
    # и на время загрузки каталога.
    catalogs = await catalog_builder()

    # Продюсер — чтобы CalcHandler публиковал события-результаты (calculation/interpretation).
    # cvd-клиент — для ML-калькулятора airi_ssz (no-op, если cvd выключен).
    await init_kafka_producer()
    await init_cvd_client()

    # Фоновая ёмкость — состояние процесса: один объект на воркер, общий для всех партиций,
    # которые он обслуживает. Признак насыщения берётся функцией — он меняется между командами.
    admission = BackgroundAdmission(
        settings.background_recalc_capacity,
        is_saturated=is_cvd_saturated,
        min_interval_seconds=settings.background_recalc_min_interval_seconds,
    )
    notice(
        "calc.consumer: background admission ready",
        context={
            "capacity": settings.background_recalc_capacity,
            "min_interval_seconds": settings.background_recalc_min_interval_seconds,
        },
    )

    consumer = KafkaTopicConsumer(
        settings.kafka,
        topic=settings.kafka.topics.recalc_commands,
        record_handler=functools.partial(_handle_command, catalogs=catalogs, admission=admission),
    )

    async def _teardown(remaining: float) -> None:
        """Гасим то, что нужно было обработке команд: ML-клиент, продюсер событий, пул соединений.
        Продюсеру отдаём остаток бюджета на дренаж — недосланное событие-результат теряется."""
        await shutdown_cvd_client()
        await shutdown_kafka_producer(drain_timeout=remaining)
        await shutdown_primary_runtime()

    await serve_until_stop(consumer, health, name=_NAME, teardown=_teardown)


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main())
