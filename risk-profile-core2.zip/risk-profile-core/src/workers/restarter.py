"""HTTP-ручка перезапуска контейнеров ядра — чтобы процессы пересобрали резидентные каталоги из БД.

Модуль — композиционный корень отдельного процесса: собирает клиент Docker Engine
(`src/infra/docker`), отдаёт его операции перезапуска (`src/services/container_restart`) и
превращает её отчёт в HTTP-ответ. Ни формата Engine API, ни списка перезапускаемых сервисов
здесь нет.

Процесс работает ТОЛЬКО на стенде тестирования (в docker-compose он под профилем `qa`):
доступ к сокету демона равносилен root на хосте. Отсюда три независимых замка:
- профиль `qa` — контейнер не поднимается обычной командой релиза;
- `verify_restarter_token` отдаёт 401 при `testing_api_enabled=false` и при незаданном
  `restarter.api_key`, то есть на боевой конфигурации ручка мертва, даже если контейнер кто-то
  запустил. Ключ у ручки СВОЙ: `test_api_key` при включённом тестовом API уходит в браузер без
  авторизации через `/questionnaire/config.js`, и общий ключ дал бы любому, кто открыл опросник,
  право перезапускать процессы ядра;
- `network_mode: none` и unix-сокет вместо порта — из compose-сети ручка недостижима, снаружи
  доступна только пробросом сокета по SSH.

Список сервисов — константа `CATALOG_SERVICES`: из запроса в путь Engine API не попадает ничего,
поэтому через ручку нельзя дотянуться до контейнера, который в него не заложен (той же БД).
"""

import asyncio
import secrets
import time
from collections.abc import AsyncIterator
from typing import Annotated, Any

import httpx2
import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Security
from fastapi.responses import JSONResponse
from fastapi.security import APIKeyHeader
from starlette import status

from src.config import settings
from src.infra.docker import DockerEngineClient
from src.logger import notice
from src.services.container_restart.service import CATALOG_SERVICES, restart_catalog_services

# Заголовок ключа ручки. Намеренно НЕ X-Test-Api-Key: тот ключ отдаётся браузеру опросника
# (`/questionnaire/config.js`), а перезапуск контейнеров — привилегированная операция.
# Значение маскируется в логах принудительно (REQUIRED_LOG_MASK_KEYS в src/constants.py).
_RESTARTER_KEY_HEADER = "X-Restarter-Api-Key"

_api_key_header = APIKeyHeader(name=_RESTARTER_KEY_HEADER, auto_error=False)


async def verify_restarter_token(api_key: Annotated[str | None, Security(_api_key_header)] = None) -> None:
    """Ключ ручки перезапуска. Отдельный от `verify_test_token` — server-to-server, не для браузера.

    Пустой `restarter.api_key` и выключенный `testing_api_enabled` — оба дают 401: ручка на боевой
    конфигурации мертва, даже если контейнер кто-то запустил.
    """
    expected = settings.restarter.api_key.get_secret_value()
    if not settings.testing_api_enabled or not expected or not api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")
    if not secrets.compare_digest(api_key, expected):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")


async def get_engine_client() -> AsyncIterator[DockerEngineClient]:
    """Клиент Docker Engine API поверх unix-сокета демона. Подменяется в тестах через DI-override."""
    transport = httpx2.AsyncHTTPTransport(uds=settings.restarter.docker_socket)
    async with httpx2.AsyncClient(transport=transport, base_url="http://docker", timeout=300.0) as http:
        yield DockerEngineClient(http)


def build_app() -> FastAPI:
    """Собирает приложение ручки. Отдельная функция — чтобы тест подменял клиент через DI-override."""
    app = FastAPI(title="Risk Model Restarter", docs_url=None, redoc_url=None, openapi_url=None)

    @app.post("/restart", dependencies=[Depends(verify_restarter_token)])
    async def restart(client: Annotated[DockerEngineClient, Depends(get_engine_client)]) -> JSONResponse:
        """Перезапускает контейнеры ядра. 200 — только если перезапущены ВСЕ сервисы.

        Частичный успех — это 500 с разбором по сервисам: тестовой фикстуре достаточно
        `raise_for_status()`, чтобы не пойти дальше с процессом, который держит старый каталог.
        `restarted` заполнен и в этом случае — по нему видно, что уже перезапущено.
        """
        started = time.monotonic()
        report = await restart_catalog_services(client)
        took_s = round(time.monotonic() - started, 1)

        body: dict[str, Any] = {"restarted": report.restarted, "took_s": took_s}
        if not report.ok:
            body["failed"] = report.failed
            return JSONResponse(body, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

        notice("containers restarted", context={"restarted": report.restarted, "took_s": took_s})
        return JSONResponse(body)

    @app.get("/liveness")
    async def liveness() -> dict[str, str]:
        """Проба для compose-healthcheck. Без авторизации — как /liveness в остальных процессах."""
        return {"status": "alive"}

    return app


async def _main() -> None:
    notice(
        "restarter starting",
        context={"uds_path": settings.restarter.uds_path, "services": list(CATALOG_SERVICES)},
    )
    config = uvicorn.Config(
        build_app(),
        uds=settings.restarter.uds_path,
        access_log=False,
        log_level="warning",
    )
    await uvicorn.Server(config).serve()


if __name__ == "__main__":
    asyncio.run(_main())
