"""One-shot worker: создаёт Kafka-топики, описанные в KafkaTopicsSettings.

Запуск: `python -m src.workers.kafka_init`.

Идемпотентен: при повторном запуске уже существующие топики пропускаются.
"""

import asyncio
import sys

from src.config import settings
from src.infra.kafka.admin import TopicSpec, ensure_topics
from src.infra.kafka.exceptions import KafkaInitError
from src.logger import logger, notice

# TCP-порт может быть готов раньше, чем SASL listener — даём брокеру время устаканиться.
_RETRY_DELAYS = (1, 2, 3, 5, 8, 13)


def _topic_specs() -> list[TopicSpec]:
    """Топики приложения с нужным числом партиций.

    Команды пересчёта — многопартиционный топик (потолок параллелизма воркеров);
    результаты, тестовый и биомаркеры ЭМК — однопартиционные (объём низкий, проще порядок).
    """
    t = settings.kafka.topics
    return [
        TopicSpec(t.test),
        TopicSpec(t.risk_calculation),
        TopicSpec(t.recalc_commands, num_partitions=settings.kafka.recalc_commands_partitions),
        TopicSpec(t.emr_biomarkers),
    ]


async def _main() -> None:
    if not settings.kafka.enabled:
        notice("kafka.init skipped — kafka disabled", context={})
        return
    specs = _topic_specs()
    topics = [s.name for s in specs]
    notice("kafka.init starting", context={"topics": topics})

    last_error: KafkaInitError | None = None
    for attempt, delay in enumerate(_RETRY_DELAYS, start=1):
        try:
            await ensure_topics(settings.kafka, specs)
        except KafkaInitError as exc:
            last_error = exc
            logger.warning(
                "kafka.init attempt failed, retrying",
                extra={"log_context": {"attempt": attempt, "delay_s": delay, "error": str(exc)}},
            )
            await asyncio.sleep(delay)
            continue
        notice("kafka.init done", context={"topics": topics, "attempts": attempt})
        return

    logger.exception(
        "kafka.init failed after retries",
        extra={"log_context": {"topics": topics, "attempts": len(_RETRY_DELAYS)}},
        exc_info=last_error,
    )
    raise last_error if last_error is not None else KafkaInitError("kafka init failed")


if __name__ == "__main__":
    try:
        asyncio.run(_main())
    except KafkaInitError:
        sys.exit(1)
