"""Consumer-воркер биомаркеров ЭМК: читает топик `emr-biomarkers` и обрабатывает сообщения.

Запуск: `python -m src.workers.emr_biomarkers_consumer`. Процесс отдельный от воркера пересчёта:
реплики того масштабируются под партиции топика команд, и каждая лишняя заводила бы лишнего члена
в группе биомаркеров, а `/readiness` перестал бы отвечать на вопрос «этот воркер в своей группе?».

Включается флагом `kafka.emr_biomarkers_enabled` (по умолчанию выключен). При выключенном флаге —
как и `calc_consumer` при выключенной Kafka — воркер не создаёт консюмер и простаивает до сигнала:
контейнер здоров, пробы зелёные, restart-loop нет. Включать флаг только ПОСЛЕ провижининга топика
(`python -m src.workers.kafka_init`) и ACL (сервис `kafka-acls-init`): без них консюмер уйдёт
в бесконечный бэкофф по ошибке авторизации, выглядя при этом здоровым.

Что общие гарантии консюмера (`src/infra/kafka/consumer.py`) значат для этого топика:
- **payload доходит до обработчика сырым** (`raw_decoder`): разбор JSON — часть валидации
  контракта, и его ошибка обязана дать в логе код `INVALID_MESSAGE`, а не общий лог пропуска
  записи, из которого причина не видна.
- **оффсет коммитится и для отброшенных сообщений**: невалидные данные — не сбой обработки,
  передоставка их не исправит. Обработчик поэтому и не бросает на них (см. `src/emr_biomarkers`).
- **оффсет коммитится и при сбое обработки**: общий консюмер ловит исключение обработчика, пишет
  о пропуске записи и коммитит батч. Поэтому ретраибельный сбой базы гасится ретраями внутри
  обработки и заканчивается `alert`, а не исключением: передоставки, которая бы его вылечила,
  всё равно не будет.
"""

import asyncio
import functools

import uvloop

from src.calc.dispatcher import dispatch_recalc
from src.config import ServiceRuntime, notice_legacy_db_env, settings
from src.emr_biomarkers.processing import EmrBiomarkersProcessor
from src.emr_biomarkers.service import handle_emr_biomarkers_record
from src.infra.catalog.builder import catalog_builder
from src.infra.database import get_primary_runtime, init_primary_runtime, shutdown_primary_runtime, verify_runtime_login
from src.infra.kafka import KafkaTopicConsumer, init_kafka_producer, raw_decoder, shutdown_kafka_producer
from src.logger import notice
from src.workers.consumer_runtime import idle_until_signal, run_worker, serve_until_stop
from src.workers.health import WorkerHealth

# Имя воркера в наблюдаемости: префикс его лог-сообщений и основа requestId процесса.
_NAME = "emr.consumer"

# Консюмер ЭМК ходит в БД под своим логином: только схема `risk_ehr` — чтение пациента и
# контролируемая запись параметра через представление.
_RUNTIME = ServiceRuntime.EHR


async def _main() -> None:
    notice_legacy_db_env()
    # Роль объявляет точка входа, строку подключения даёт переменная роли. Соединений пока нет.
    database = init_primary_runtime(_RUNTIME)
    # Логин приносит строка подключения. Сверяем с БД, а не верим на слово.
    await verify_runtime_login(database.engine, _RUNTIME)
    await run_worker(_run, name=_NAME, health_port=settings.emr_consumer_health_port)


async def _run(health: WorkerHealth) -> None:
    """Основной жизненный цикл воркера. Сервер проб уже поднят `run_worker` и живёт вокруг нас;
    здесь только выставляем `WorkerHealth.ready` на переходах старт/drain."""
    kafka = settings.kafka
    # Гейт по двум флагам: `enabled` — есть ли вообще брокер у сервиса, `emr_biomarkers_enabled` —
    # выкачен ли провижининг именно этого топика.
    if not (kafka.enabled and kafka.emr_biomarkers_enabled):
        notice("emr.consumer: skipped — emr-biomarkers consumer disabled, idling", context={})
        health.ready = True  # намеренный простой — контейнер здоров, пробы зелёные
        await idle_until_signal()
        return

    notice(
        "emr.consumer: starting",
        context={"topic": kafka.topics.emr_biomarkers, "group_id": kafka.emr_biomarkers_consumer.group_id},
    )
    # Справочники строятся до клиентов и подписки: частичный каталог не должен допустить consumer
    # к сообщению, а заморозка стартового heap должна предшествовать долгоживущим Kafka-объектам.
    catalogs = await catalog_builder()
    # Продюсер — чтобы обработка заказывала пересчёт публикацией команды. Поднимается ДО
    # консюмера: сообщение, обработанное без продюсера, потеряло бы пересчёт.
    await init_kafka_producer()

    processor = EmrBiomarkersProcessor(get_primary_runtime().session_factory, catalogs.emr_biomarkers, dispatch_recalc)
    consumer = KafkaTopicConsumer(
        kafka,
        topic=kafka.topics.emr_biomarkers,
        record_handler=functools.partial(handle_emr_biomarkers_record, process=processor.process),
        consumer_settings=kafka.emr_biomarkers_consumer,
        decoder=raw_decoder,
    )

    async def _teardown(remaining: float) -> None:
        """Гасим то, что нужно было обработке: продюсер команд пересчёта и пул соединений.
        Продюсеру отдаём остаток бюджета на дренаж — недосланная команда означает несчитанный
        риск-профиль, а не потерянные данные: параметры к этому моменту уже записаны."""
        await shutdown_kafka_producer(drain_timeout=remaining)
        await shutdown_primary_runtime()

    await serve_until_stop(consumer, health, name=_NAME, teardown=_teardown)


if __name__ == "__main__":
    uvloop.install()
    asyncio.run(_main())
