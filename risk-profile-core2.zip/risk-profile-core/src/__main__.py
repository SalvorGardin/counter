"""Точка входа процесса app: `python -m src` (команда образа по умолчанию).

Модуль намеренно лёгкий: он не импортирует ни приложение (`src.main`), ни `src.metrics`, ни
`prometheus_client`. В multiprocess-режиме prometheus_client процесс открывает свои mmap-файлы
метрик уже при импорте `src.metrics`, а очистка директории после этого удалила бы открытые файлы:
при одном воркере uvicorn обслуживает запросы в этом же процессе, и его наблюдения пропали бы из
выдачи `/metrics`. Поэтому очистка идёт здесь, до загрузки приложения, а приложение загружает
uvicorn по импорт-строке: при одном воркере — в этом процессе, при нескольких — в каждом воркере,
мастер его не загружает вовсе.
"""

import uvicorn

from src.config import notice_legacy_db_env, settings
from src.logger import notice
from src.metrics_multiproc import prepare_multiproc_dir


def main() -> None:
    """Готовит процесс и запускает uvicorn с приложением `src.main:app`."""
    # Первым действием: до очистки в процессе не должно случиться ничего, что откроет файл метрик.
    # Даже запись уровня ERROR открыла бы его: на первой такой записи логгер импортирует
    # `src.metrics` ради счётчика ошибок.
    prepare_multiproc_dir()
    # Один раз на запуск, а не в lifespan: там событие повторилось бы в каждом uvicorn-воркере.
    notice_legacy_db_env()
    # При включённом профайлере форсируем один воркер: yappi копит статистику per-process.
    workers = settings.workers
    if settings.profiler.enabled and workers != 1:
        notice(
            "profiler enabled: forcing single uvicorn worker",
            context={"configured_workers": settings.workers},
        )
        workers = 1
    # Приложение — импорт-строкой: её требует workers>1, и только так приложение загружается уже
    # после очистки, в процессе, который его обслуживает. loop="uvloop" форсирует uvloop.
    uvicorn.run(
        "src.main:app",
        host=settings.host,
        port=settings.port,
        workers=workers,
        loop="uvloop",
        access_log=False,
        timeout_graceful_shutdown=settings.shutdown_timeout,
    )


if __name__ == "__main__":
    main()
