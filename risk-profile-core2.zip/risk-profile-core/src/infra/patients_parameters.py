"""Единое правило записи значения в `patients_parameters`: архив прежней строки + атомарный upsert.

Правило нужно трём доменам сразу — risk-init (`POST /anthropometry`), risk-communication (ответ на
вопрос анкеты) и risk-event (реконсиляция производного `bmi`), — поэтому живёт в `src/infra/`, где
уже лежит остальная межпредметная инфраструктура (`database.py`, `db_retry.py`, `catalog/`).
Пока копий было две, они успели разъехаться по деривации `bmi` (#136, #139); третья копия
воспроизвела бы ту же причину, так что реализация тут ровно одна.

Путь ЭМК — исключение: у него есть вторая реализация, `INSTEAD OF INSERT`-триггер на
`risk_ehr.patients_parameters` (см. миграцию 0146, функция триггера с владельцем `risk_ehr_owner`).
Она заморожена в теле миграции и не подтягивает правки этого хелпера автоматически — сейчас обе
копии совпадают колонка в колонку, но следующая правка хелпера должна прийти вместе с
`CREATE OR REPLACE FUNCTION` в новой миграции, иначе копии снова разъедутся.

`source` — аргумент, а не константа: risk-init пишет "EMR", risk-communication — свой доменный
`ANSWER_SOURCE`, реконсиляция наследует его от заменяемой строки. Хелпер про эти значения не знает.

Порядок захвата строк
---------------------

Канонический порядок, в котором транзакция берёт строки `patients_parameters` одного пациента, —
по возрастанию `parameter_code`. Правило живёт здесь, потому что это единственный модуль, который
читают все писатели таблицы; блокировку строки берёт `INSERT ... ON CONFLICT DO UPDATE` ниже и
держит её до конца транзакции вызывающего.

Порядку следуют: сброс параметров risk-event (все строки обоих множеств одним
`SELECT ... FOR UPDATE ORDER BY parameter_code`), запись биомаркеров ЭМК
(`EmrBiomarkersRepository.apply_writes`), параметры опций одного вопроса
(`RiskCommunicationService`). Не следуют: risk-init (антропометрия в фиксированной
последовательности, затем производные `age`/`bmi`), производные параметры опросника после
параметров опций и восстановление `bmi` в сбросе — их код строится вокруг чтения предыдущих
значений и деривации.

При взаимной блокировке PostgreSQL прерывает одну из транзакций после `deadlock_timeout`. Ошибка
приходит в код как `DBAPIError` (подклассы asyncpg `PostgresError`, а не `OperationalError`),
поэтому `TransactionalRetryExecutor` её не повторяет. Для путей, которые не следуют порядку, это
терпимо: все они — HTTP-запросы, вызывающий получает ошибку и повторяет запрос, данные не теряются.
Путь консьюмера `emr-biomarkers`, где прерывание потеряло бы результат лабораторного исследования
(батч коммитится независимо от исхода обработчика), со сбросом упорядочен.
"""

from datetime import datetime

from sqlalchemy import insert, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.patient_parameter import PATIENT_PARAMETER_UNIQUE_CONSTRAINT, PatientParameter
from src.models.patient_parameter_history import PatientParameterHistory

_HISTORY_COLUMNS = [
    "parameter_code",
    "patient_id",
    "value",
    "source",
    "external_id",
    "expiration_date",
    "date_time",
]


async def archive_and_upsert_patient_parameter(
    session: AsyncSession,
    *,
    patient_id: str,
    parameter_code: str,
    value: str,
    source: str,
    external_id: int | None,
    expiration_date: datetime,
    date_time: datetime,
) -> None:
    """Архивирует текущую строку параметра в history и перезаписывает её новым значением.

    Архивация — одним INSERT-FROM-SELECT, без материализации ORM-сущности: копируются семь полей,
    ради которых незачем поднимать объект, и строка не попадает в identity map, где после Core-UPDATE
    ниже она отдавала бы устаревшие атрибуты. Строки нет — SELECT пуст, INSERT не пишет ничего:
    отдельная проверка «есть ли что архивировать» не нужна. В history уезжает ОРИГИНАЛЬНЫЙ
    `date_time` архивируемой записи: там момент, когда значение реально писали, а не момент архивации.

    Race gap (принят осознанно): если параллельный писатель вставит строку между SELECT-ом архивации
    и INSERT-ом, его значение в history не попадёт — ON CONFLICT DO UPDATE перезапишет его молча.
    Окно узкое, а SELECT FOR UPDATE его не закрывает: до вставки блокировать нечего.

    `external_id` — аргумент без значения по умолчанию, и он входит в набор перезаписываемых колонок
    всегда: пустое значение — тоже значение. Источник без идентификатора экземпляра (ответ на вопрос
    анкеты, антропометрия, деривация) обязан затереть им прежний идентификатор, иначе строка,
    ранее записанная из ЭМК, унесла бы чужой `external_id` в историю уже под новым значением.

    HOT-update: `value`/`source`/`external_id`/`expiration_date`/`date_time` не входят в уникальный
    индекс, поэтому Postgres обновляет строку без правки индекса — важно для самой горячей на запись
    таблицы.

    Транзакцию держит вызывающий слой — своего `session.begin()` здесь нет.
    """
    current = select(
        PatientParameter.parameter_code,
        PatientParameter.patient_id,
        PatientParameter.value,
        PatientParameter.source,
        PatientParameter.external_id,
        PatientParameter.expiration_date,
        PatientParameter.date_time,
    ).where(
        PatientParameter.patient_id == patient_id,
        PatientParameter.parameter_code == parameter_code,
    )
    await session.execute(insert(PatientParameterHistory).from_select(_HISTORY_COLUMNS, current))

    new_values = {
        "value": value,
        "source": source,
        "external_id": external_id,
        "expiration_date": expiration_date,
        "date_time": date_time,
    }
    await session.execute(
        pg_insert(PatientParameter)
        .values(patient_id=patient_id, parameter_code=parameter_code, **new_values)
        .on_conflict_do_update(constraint=PATIENT_PARAMETER_UNIQUE_CONSTRAINT, set_=new_values)
    )
