"""Запись диагностики отдельной транзакцией, не влияющая на вызывающую сторону.

Общий путь для `CalcStatusCollector` и `InterpretationReasonCollector`: обе таблицы объясняют
чужой результат и не имеют права ни откатить чужую транзакцию, ни уронить того, кто их пишет.
Правило гашения ошибок одно на оба коллектора и живёт здесь в единственном экземпляре — раньше
оно было скопировано в оба и разошлось бы при первой правке обработки ошибок.
"""

from collections.abc import Awaitable, Callable
from typing import Any

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.logger import logger


async def run_isolated(
    session_factory: async_sessionmaker[AsyncSession],
    work: Callable[[AsyncSession], Awaitable[None]],
    *,
    failure_message: str,
    failure_log_context: dict[str, Any],
) -> None:
    """Выполняет `work` на собственной сессии одной транзакцией; сбой БД логируется и гасится.

    Вызывать ПОСЛЕ коммита той транзакции, которую диагностика объясняет, и вне её.
    """
    try:
        async with session_factory() as session:
            await work(session)
            await session.commit()
    except SQLAlchemyError as e:
        logger.error(failure_message, extra={"log_context": failure_log_context}, exc_info=e)
