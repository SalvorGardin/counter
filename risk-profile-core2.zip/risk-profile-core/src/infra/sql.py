"""Построение фильтров по списку значений.

`column.in_(values)` компилируется через expanding-параметр: на каждую длину списка драйвер шлёт
свой текст запроса, и Postgres кладёт его в `pg_stat_statements` отдельной записью со своим
`queryid`. Один логический запрос размазывается по десяткам строк, каждая со своей долей `calls` и
`total_exec_time`, — топ по времени перестаёт показывать тяжёлые запросы, а алерт на конкретный
запрос построить нельзя, потому что его идентификатор меняется вместе с размером списка.

`= ANY(:values)` берёт список ОДНИМ параметром-массивом: текст запроса не зависит от длины,
запись в `pg_stat_statements` одна, `queryid` стабильный. Побочно перестаёт зависеть от длин
списков и число подготовленных выражений на соединение.

Тип элемента массива выводится из самой колонки, а не задаётся на месте вызова: колонки разные
(`doctors.code` — integer, остальные фильтруемые — текстовые), и написанный руками `ARRAY(String)`
на integer-колонке дал бы приведение типа и потерю индексного скана.
"""

from collections.abc import Iterable
from typing import Any

from sqlalchemy import all_, any_, bindparam, literal
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import InstrumentedAttribute
from sqlalchemy.sql import ColumnElement

# ORM-атрибут (`Result.patient_id`) и Core-колонка — оба несут `.type` и оба приходят сюда,
# но общего супертипа, который видит типизатор, у них нет.
type FilterColumn = InstrumentedAttribute[Any] | ColumnElement[Any]


def any_of(column: FilterColumn, values: Iterable[Any]) -> ColumnElement[bool]:
    """`column = ANY(:values)` — замена `column.in_(values)` для списков переменной длины.

    `list(values)` обязателен: часть вызывающих передаёт `set`, а параметру-массиву нужна
    последовательность. Пустой список даёт `= ANY('{}')` = false — та же семантика, что у `IN ()`.
    """
    return column == any_(literal(list(values), ARRAY(column.type)))


def none_of(column: FilterColumn, values: Iterable[Any]) -> ColumnElement[bool]:
    """`column != ALL(:values)` — замена `column.notin_(values)`.

    Postgres и так вычисляет `x NOT IN (a, b)` как `x <> ALL (ARRAY[a, b])`, включая трёхзначный
    результат при NULL, так что подмена эквивалентна. Пустой список даёт `!= ALL('{}')` = true —
    та же семантика, что у `NOT IN ()`.
    """
    return column != all_(literal(list(values), ARRAY(column.type)))


def any_of_param(column: FilterColumn, name: str) -> ColumnElement[bool]:
    """То же, что `any_of`, но для стейтментов, скомпилированных один раз на модуль.

    Значение подставляется на исполнении под именем `name`; вызывающий передаёт обычный
    Python-список, как и раньше с `bindparam(name, expanding=True)`.

    В отличие от `any_of`, привести значение к списку тут негде: параметр уходит в драйвер как
    есть. `set` в `session.execute(stmt, params)` упадёт уже в asyncpg — передавать нужно
    именно список.
    """
    return column == any_(bindparam(name, type_=ARRAY(column.type)))
