"""Физическое размещение таблиц по схемам PostgreSQL и карты трансляции схем для рантаймов.

Модуль — единственный источник имён схем. Значения нужны в трёх местах, и все три должны
видеть одно и то же: ORM-модели (владелец таблицы), Alembic (сравнение метаданных без
трансляции) и конструирование движков (`schema_translate_map` конкретного рантайма).

Модели объявляют схему **физического владельца**. Рантайм-движок подменяет её на локальную
схему сервиса через `schema_translate_map`, поэтому один и тот же ORM-класс адресует либо
свою таблицу, либо локальное представление с тем же именем. Карта фиксируется в момент
создания движка и не может быть выбрана из входных данных запроса или сообщения.

Каталоги (`CATALOG_SCHEMA`) не транслируются никогда: они общие и доступны рантаймам
напрямую только на чтение.
"""

from collections.abc import Mapping
from types import MappingProxyType
from typing import Final

# Схема профиля: данные пациента и его параметры.
PROFILE_SCHEMA: Final[str] = "risk_profile"
# Схема расчёта: результаты, интерпретации и диагностические статусы.
CALCULATION_SCHEMA: Final[str] = "risk_calculation"
# Схема EMR-консьюмера: собственных таблиц нет, только представления и контролируемая запись.
EHR_SCHEMA: Final[str] = "risk_ehr"
# Общая схема статических справочников.
CATALOG_SCHEMA: Final[str] = "catalog"

APPLICATION_SCHEMAS: Final[tuple[str, ...]] = (PROFILE_SCHEMA, CALCULATION_SCHEMA, EHR_SCHEMA, CATALOG_SCHEMA)

# Роли-владельцы схем (NOLOGIN). Рантайм-логины членами этих ролей не являются.
SCHEMA_OWNER_ROLES: Final[Mapping[str, str]] = MappingProxyType(
    {
        PROFILE_SCHEMA: "risk_profile_owner",
        CALCULATION_SCHEMA: "risk_calculation_owner",
        EHR_SCHEMA: "risk_ehr_owner",
        CATALOG_SCHEMA: "catalog_owner",
    }
)

# Логины рантаймов. Владельцами схем не являются и прав CREATE не получают.
PROFILE_ROLE: Final[str] = "risk_profile_app"
CALCULATION_ROLE: Final[str] = "risk_calculation_app"
EHR_ROLE: Final[str] = "risk_ehr_app"
# Логин продюсера массового пересчёта: ему выдано ТОЛЬКО чтение реестра версий расчёта.
# Под логином расчёта он получил бы право переписать результаты любого пациента ради запроса
# списка идентификаторов, поэтому роль своя.
BULK_RECALC_ROLE: Final[str] = "risk_bulk_recalc_app"
MIGRATION_ROLE: Final[str] = "risk_migrations"

# Логины сервисов, обслуживающих данные: у каждого своя схема и доступ к общим справочникам.
# Продюсер прогона сюда не входит намеренно — он справочники не читает и своей схемы не имеет.
RUNTIME_ROLES: Final[tuple[str, ...]] = (PROFILE_ROLE, CALCULATION_ROLE, EHR_ROLE)

# Все логины приложения: то, что заводит бутстрап ролей и снимает откат.
LOGIN_ROLES: Final[tuple[str, ...]] = (*RUNTIME_ROLES, BULK_RECALC_ROLE)

# Таблицы профиля — физические, принадлежат PROFILE_SCHEMA.
PROFILE_TABLES: Final[tuple[str, ...]] = ("patients", "patients_parameters", "patients_parameters_history")

# Таблицы расчёта — физические, принадлежат CALCULATION_SCHEMA.
CALCULATION_TABLES: Final[tuple[str, ...]] = (
    "results",
    "results_history",
    "calculation_statuses",
    "interpretations",
    "interpretations_history",
    "interpretation_statuses",
    "risk_factor_matches",
    # Реестр версий расчёта: чем посчитан профиль пациента (см. `PatientCalculationVersion`).
    "patient_calculation_versions",
)

# Статические справочники — физически в CATALOG_SCHEMA, читаются всеми рантаймами напрямую.
CATALOG_TABLES: Final[tuple[str, ...]] = (
    "biomarkers",
    "biomarker_parameter_mappings",
    "clinical_recommendations",
    "conditions",
    "disease_examinations",
    "disease_icd",
    "diseases",
    "doctors",
    "examinations",
    "instruments",
    "instruments_parameters",
    "options",
    "parameter_scores",
    "parameters",
    "questions",
    "recommendations",
    "recommended_doctors",
    "risk_factor_clinrecs",
    "risk_factor_scores",
    "risk_factor_systems",
    "risk_factor_triggers",
    "risk_factors",
    "system_checkup_examinations",
    "systems",
    "systems_instruments",
)

# Представления расчёта над данными профиля — только чтение.
CALCULATION_LOCAL_VIEWS: Final[tuple[str, ...]] = ("patients", "patients_parameters")

# Представления профиля над данными расчёта: имя → разрешённые рантайму операции.
PROFILE_LOCAL_VIEWS: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        "results": ("SELECT", "DELETE"),
        "results_history": ("INSERT",),
        "interpretations": ("SELECT", "DELETE"),
        "interpretations_history": ("INSERT",),
        "calculation_statuses": ("SELECT", "DELETE"),
        "interpretation_statuses": ("SELECT", "DELETE"),
        "risk_factor_matches": ("SELECT", "DELETE"),
    }
)

# Представления EMR-консьюмера над данными профиля.
EHR_LOCAL_VIEWS: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        "patients": ("SELECT",),
        "patients_parameters": ("SELECT", "INSERT"),
    }
)


def _translate_map(profile_to: str, calculation_to: str) -> Mapping[str, str]:
    return MappingProxyType({PROFILE_SCHEMA: profile_to, CALCULATION_SCHEMA: calculation_to})


# Профильный рантайм: свои таблицы — свои, данные расчёта — локальные представления.
PROFILE_SCHEMA_MAP: Final[Mapping[str, str]] = _translate_map(PROFILE_SCHEMA, PROFILE_SCHEMA)
# Рантайм расчёта: свои таблицы — свои, данные профиля — локальные представления.
CALCULATION_SCHEMA_MAP: Final[Mapping[str, str]] = _translate_map(CALCULATION_SCHEMA, CALCULATION_SCHEMA)
# EMR-рантайм: репозитории расчёта не загружает, но карта уводит и их в risk_ehr — так процесс
# физически не может назвать чужую схему, даже если модель расчёта окажется импортирована.
EHR_SCHEMA_MAP: Final[Mapping[str, str]] = _translate_map(EHR_SCHEMA, EHR_SCHEMA)
# Продюсер массового пересчёта: локальных представлений у роли нет вовсе, карта тождественная.
# Он читает ровно одну физическую таблицу — реестр версий в схеме расчёта, — а к данным профиля
# доступа не имеет и назвать их некуда.
BULK_RECALC_SCHEMA_MAP: Final[Mapping[str, str]] = _translate_map(PROFILE_SCHEMA, CALCULATION_SCHEMA)


# Схемы, которые автогенерация Alembic сравнивает с метаданными: наши четыре плюс `public`,
# где лежит `alembic_version` и куда downgrade возвращает физические таблицы.
_COMPARED_SCHEMAS: Final[frozenset[str | None]] = frozenset(APPLICATION_SCHEMAS) | {"public", None}


def is_compared_schema(name: str | None) -> bool:
    """Схема участвует в сравнении метаданных? Посторонние схемы той же БД автогенерация не трогает."""
    return name in _COMPARED_SCHEMAS
