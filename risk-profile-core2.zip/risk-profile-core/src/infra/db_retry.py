import asyncio
import contextlib
from collections.abc import Awaitable, Callable, Generator
from dataclasses import dataclass
from typing import ParamSpec, TypeVar

from sqlalchemy.exc import InterfaceError, OperationalError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from src.exceptions import NonRetriableDbError, RetriableDbError
from src.logger import logger

P = ParamSpec("P")
T = TypeVar("T")

DEFAULT_RETRIABLE: tuple[type[BaseException], ...] = (OperationalError, InterfaceError)
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_BACKOFF_BASE_S = 0.1


class TransactionalRetryExecutor:
    """Runs an async DB op inside its own transaction with classify-and-retry semantics.

    Each attempt opens a fresh `session.begin()`. Retriable failures roll back the
    transaction and try again with exponential backoff. Non-retriable database failures
    surface immediately as NonRetriableDbError. Of database failures the caller sees only
    DbOperationError subclasses — SQLAlchemy exception types stay inside this module — while
    an exception raised by the op itself propagates as it is.
    """

    def __init__(
        self,
        session: AsyncSession,
        *,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        backoff_base_s: float = DEFAULT_BACKOFF_BASE_S,
        retriable: tuple[type[BaseException], ...] = DEFAULT_RETRIABLE,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        self._session = session
        self._max_attempts = max_attempts
        self._backoff_base_s = backoff_base_s
        self._retriable = retriable

    async def run(
        self,
        op: Callable[P, Awaitable[T]],
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> T:
        last_exc: BaseException | None = None
        for attempt in range(1, self._max_attempts + 1):
            try:
                # If __aexit__ raises during rollback (e.g. connection already dead),
                # that secondary exception is what we see here — it is reclassified
                # as a fresh attempt, which can make `attempts` undercount the real
                # number of DB interactions. Acceptable: the loop still terminates.
                async with self._session.begin():
                    return await op(*args, **kwargs)
            except self._retriable as exc:
                last_exc = exc
                logger.warning(
                    "db op failed with retriable error",
                    extra={
                        "log_context": {
                            "op": getattr(op, "__name__", repr(op)),
                            "attempt": attempt,
                            "max_attempts": self._max_attempts,
                        }
                    },
                    exc_info=True,
                )
                if attempt == self._max_attempts:
                    break
                await asyncio.sleep(self._backoff_base_s * (2 ** (attempt - 1)))
            except SQLAlchemyError as exc:
                # Only a database failure is reclassified. Anything else raised inside the
                # transaction — a domain bug, an arithmetic overflow, a bad mapping — leaves
                # unchanged: wrapping it would file a defect of the caller under
                # "database error is permanent" and send whoever debugs it to the wrong layer.
                # The transaction is still rolled back by `session.begin()` on the way out.
                raise NonRetriableDbError(
                    "non-retriable db error",
                    cause=exc,
                    attempts=attempt,
                ) from exc

        if last_exc is None:
            # Unreachable: loop only exits via `return`, raise, or after capturing
            # last_exc on the final retriable attempt. Explicit guard instead of
            # `assert` so this holds under `python -O`.
            raise RuntimeError("retry loop terminated without capturing an exception")
        raise RetriableDbError(
            "retriable db error: attempts exhausted",
            cause=last_exc,
            attempts=self._max_attempts,
        ) from last_exc


@dataclass(slots=True)
class DbWriteAttempt:
    """Outcome of one write step run under `tolerate_retriable_db_error`."""

    failed: bool = False


@contextlib.contextmanager
def tolerate_retriable_db_error(event: str, /, **log_context: object) -> Generator[DbWriteAttempt]:
    """Absorbs `RetriableDbError` only; `NonRetriableDbError` passes through.

    Catching the shared `DbOperationError` base at a write step also catches the permanent kind
    (schema/permission/constraint), and a permanent fault handled as if it were transient reads to
    an operator exactly like a blip of the database — it then survives as many runs as it takes
    someone to notice. A transient failure is ordinary degradation: the step is marked failed and
    the caller decides what to do next. A permanent one must abort the run and reach the caller
    with a traceback.

    `event` and `log_context` are the log message and its fields; `attempts` and `error` are taken
    from the exception here, so that every write step names them the same way.
    """
    attempt = DbWriteAttempt()
    try:
        yield attempt
    except RetriableDbError as exc:
        attempt.failed = True
        logger.error(
            event,
            extra={"log_context": {**log_context, "attempts": exc.attempts, "error": str(exc.cause)}},
            exc_info=exc,
        )
