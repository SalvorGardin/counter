"""Идемпотентная выдача ролей PostgreSQL под изоляцию схем.

Роли кластерные, а не бд-локальные, и пароли рантаймов не должны попадать в миграции —
поэтому роли заводятся ДО alembic, отдельным шагом деплоя (scripts/bootstrap_db_roles.py)
и той же функцией в тестовом стенде. Alembic отвечает только за объекты внутри БД.

Заводятся три вида ролей:

* владельцы схем (`NOLOGIN`) — им принадлежат таблицы, представления и триггерные функции;
* логины рантаймов — прав `CREATE` и администрирования ролей не получают;
* миграционный логин — член всех ролей-владельцев, поэтому может создавать объекты от их имени.

Пароли приходят только секретами (`SecretStr`) и в SQL попадают связанными параметрами через
`set_config`: тело `DO`-блока статично, имя роли и пароль в него не подставляются текстом.

Связанный параметр остаётся параметром только на драйвере с серверной подстановкой (asyncpg,
psycopg3). psycopg2 подставляет значения на клиенте, и на сервер уходит уже готовый
`SELECT set_config('risk_bootstrap.password', '<пароль>', true)` — он виден целиком в
`pg_stat_activity.query` и попадает в лог при `log_statement=all`. Поэтому драйвер соединения
проверяется явно, а точка входа `bootstrap_roles_at_url` открывает соединение сама.
"""

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Final

from pydantic import SecretStr
from sqlalchemy import Connection, text
from sqlalchemy.engine.url import make_url
from sqlalchemy.ext.asyncio import create_async_engine

from src.exceptions import RiskBaseError
from src.infra.db_schemas import (
    APPLICATION_SCHEMAS,
    BULK_RECALC_ROLE,
    CALCULATION_ROLE,
    EHR_ROLE,
    LOGIN_ROLES,
    MIGRATION_ROLE,
    PROFILE_ROLE,
    SCHEMA_OWNER_ROLES,
)
from src.logger import notice

# GUC-параметры одной транзакции: значения кладутся туда bind-параметрами и живут до её конца.
_ROLE_SETTING = "risk_bootstrap.role"
_MEMBER_SETTING = "risk_bootstrap.member"
# nosec B105 — имя GUC-параметра, а не пароль
_PASSWORD_SETTING = "risk_bootstrap.password"  # nosec B105

_SET_ROLE_NAME = text(f"SELECT set_config('{_ROLE_SETTING}', :role, true)")
_SET_MEMBER_NAME = text(f"SELECT set_config('{_MEMBER_SETTING}', :role, true)")
_SET_PASSWORD = text(f"SELECT set_config('{_PASSWORD_SETTING}', :password, true)")

# NOLOGIN-владелец: пароля нет вовсе, войти под ним нельзя.
# Имена GUC вписаны литералами, а не f-строкой: динамики в этом SQL нет вообще, и статический
# анализатор не должен принимать её за конструирование запроса. Совпадение с константами
# проверяется утверждением ниже.
_ENSURE_OWNER_ROLE = text("""
DO $$
DECLARE
    role_name text := current_setting('risk_bootstrap.role');
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
        EXECUTE format('CREATE ROLE %I NOLOGIN NOCREATEDB NOCREATEROLE NOSUPERUSER', role_name);
    ELSE
        EXECUTE format('ALTER ROLE %I NOLOGIN NOCREATEDB NOCREATEROLE NOSUPERUSER', role_name);
    END IF;
END
$$
""")

# Логин: пароль перезаписывается на каждом прогоне, поэтому ротация секрета — это повторный запуск.
_ENSURE_LOGIN_ROLE = text("""
DO $$
DECLARE
    role_name text := current_setting('risk_bootstrap.role');
    role_password text := current_setting('risk_bootstrap.password');
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
        EXECUTE format('CREATE ROLE %I LOGIN NOCREATEDB NOCREATEROLE NOSUPERUSER PASSWORD %L',
                       role_name, role_password);
    ELSE
        EXECUTE format('ALTER ROLE %I LOGIN NOCREATEDB NOCREATEROLE NOSUPERUSER PASSWORD %L',
                       role_name, role_password);
    END IF;
END
$$
""")

# Миграционный логин получает членство во владельцах: иначе он не сможет ни создать объект в
# их схемах, ни переназначить владельца созданному. Владельцем объект при этом НЕ становится —
# членство даёт право на действие, но создателем остаётся сам `risk_migrations`, поэтому каждая
# миграция обязана выполнить `ALTER TABLE ... OWNER TO` и `GRANT` явно.
_GRANT_ROLE_TO_MIGRATIONS = text(f"""
DO $$
DECLARE
    granted_role text := current_setting('{_ROLE_SETTING}');
BEGIN
    EXECUTE format('GRANT %I TO %I', granted_role, '{MIGRATION_ROLE}');
END
$$
""")

# Прежний общий владелец таблиц — случай особый: на стенде это суперпользователь, и обычное
# членство дало бы `risk_migrations` право перевоплотиться в него, то есть весь кластер. Нужны же
# ему ровно перенос таблиц и запись в `alembic_version`, а для этого хватает унаследованных прав:
# проверка владельца при `ALTER TABLE` смотрит на членство, а атрибут суперпользователя не
# наследуется никогда. `WITH SET FALSE` выдаёт членство без `SET ROLE` — отсюда требование к
# версии сервера.
#
# Роли-владельцам схем так выдать нельзя: `CREATE SCHEMA ... AUTHORIZATION` требует именно права
# `SET ROLE` в указанную роль, унаследованных прав ему мало. Опасности в этом нет — роли-владельцы
# заводятся `NOLOGIN` и не имеют прав за пределами своих схем.
_GRANT_LEGACY_OWNER_TO_MIGRATIONS = text(f"""
DO $$
DECLARE
    granted_role text := current_setting('{_ROLE_SETTING}');
BEGIN
    EXECUTE format('GRANT %I TO %I WITH SET FALSE', granted_role, '{MIGRATION_ROLE}');
END
$$
""")

# Общий логин (режим `RISK_MODEL_DB_ASSUME_RUNTIME_ROLE`) получает право переключиться в рантайм-логин,
# но не его права: `INHERIT FALSE` — пока сессия не переключилась, у общего логина остаются только
# свои права, `SET TRUE` — переключение стартовым параметром `role`. Синтаксис PostgreSQL 16.
# Имена GUC — литералами, как и выше: динамики в SQL нет, совпадение с константами проверяет assert.
_GRANT_RUNTIME_LOGIN_TO_SHARED = text("""
DO $$
DECLARE
    granted_role text := current_setting('risk_bootstrap.role');
    member_role text := current_setting('risk_bootstrap.member');
BEGIN
    EXECUTE format('GRANT %I TO %I WITH INHERIT FALSE, SET TRUE', granted_role, member_role);
END
$$
""")

# Подключаться к БД должны все логины; создавать в ней схемы — только миграционный.
# CREATE на самой БД не даёт прав внутри чужих схем: это лишь право завести новую схему.
_GRANT_DATABASE_ACCESS = text(f"""
DO $$
DECLARE
    role_name text := current_setting('{_ROLE_SETTING}');
BEGIN
    EXECUTE format('GRANT CONNECT ON DATABASE %I TO %I', current_database(), role_name);
    IF role_name = '{MIGRATION_ROLE}' THEN
        EXECUTE format('GRANT CREATE ON DATABASE %I TO %I', current_database(), role_name);
        -- Начиная с PostgreSQL 15 схема public не даёт CREATE всем подряд. Право нужно
        -- миграциям и до переноса (таблицы ещё в public), и после (туда же возвращает downgrade).
        EXECUTE format('GRANT CREATE, USAGE ON SCHEMA public TO %I', role_name);
    END IF;
END
$$
""")


# Снятие ролей. `DROP OWNED BY` не только отзывает права, но и УДАЛЯЕТ объекты роли, поэтому
# перед ним проверяется, что роль ничем не владеет, — см. `drop_roles`.
# Имя GUC здесь записано литералом, а не подставлено из константы: f-строка с DROP выглядит для
# bandit конкатенацией SQL. Совпадение с `_ROLE_SETTING` проверяется assert-ом ниже.
_DROP_OWNED_PRIVILEGES = text("""
DO $$
DECLARE
    role_name text := current_setting('risk_bootstrap.role');
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
        EXECUTE format('DROP OWNED BY %I', role_name);
    END IF;
END
$$
""")

_DROP_ROLE = text("""
DO $$
DECLARE
    role_name text := current_setting('risk_bootstrap.role');
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
        EXECUTE format('DROP ROLE %I', role_name);
    END IF;
END
$$
""")

# Схемы, таблицы, представления, последовательности и функции роли. Индексы и TOAST не
# перечисляются: они следуют за своей таблицей и без неё у роли не появятся.
_OWNED_OBJECTS = text("""
    SELECT n.nspname AS name
      FROM pg_namespace AS n
      JOIN pg_roles AS r ON r.oid = n.nspowner
     WHERE r.rolname = :role
    UNION ALL
    SELECT n.nspname || '.' || c.relname
      FROM pg_class AS c
      JOIN pg_namespace AS n ON n.oid = c.relnamespace
      JOIN pg_roles AS r ON r.oid = c.relowner
     WHERE r.rolname = :role AND c.relkind = ANY(ARRAY['r', 'p', 'v', 'm', 'S', 'f'])
    UNION ALL
    SELECT n.nspname || '.' || p.proname || '()'
      FROM pg_proc AS p
      JOIN pg_namespace AS n ON n.oid = p.pronamespace
      JOIN pg_roles AS r ON r.oid = p.proowner
     WHERE r.rolname = :role
     ORDER BY name
""")

_PRESENT_APPLICATION_SCHEMAS = text("""
    SELECT nspname FROM pg_namespace WHERE nspname = ANY(:schemas) ORDER BY nspname
""")


# Литералы GUC внутри DO-блоков выше обязаны совпадать с константами: разъехались бы —
# current_setting() упал бы на «unrecognized configuration parameter» уже в проде.
assert _ROLE_SETTING == "risk_bootstrap.role"
assert _MEMBER_SETTING == "risk_bootstrap.member"
assert _PASSWORD_SETTING == "risk_bootstrap.password"  # nosec B105 — имя GUC, не пароль


@dataclass(frozen=True)
class RoleCredentials:
    """Пароли логинов. Только секреты: значения не попадают в repr, dump и трассировки."""

    profile: SecretStr
    calculation: SecretStr
    ehr: SecretStr
    bulk_recalc: SecretStr
    migrations: SecretStr

    def as_login_map(self) -> Mapping[str, SecretStr]:
        return {
            PROFILE_ROLE: self.profile,
            CALCULATION_ROLE: self.calculation,
            EHR_ROLE: self.ehr,
            BULK_RECALC_ROLE: self.bulk_recalc,
            MIGRATION_ROLE: self.migrations,
        }


class EmptyRolePasswordError(RiskBaseError, ValueError):
    """Пустой пароль логина: роль без пароля молча осталась бы недоступной для рантайма.

    `ValueError` остаётся в предках: это ошибка валидации входных данных бутстрапа.
    """


class UnknownLoginRoleError(RiskBaseError, ValueError):
    """Запрошен логин, которого нет среди ролей изоляции схем (или не запрошен ни один)."""


class MissingMigrationRoleError(RiskBaseError, RuntimeError):
    """Миграционный логин можно только обновить: без полного прогона он остался бы без членства."""


class UnsafeBootstrapDriverError(RiskBaseError, RuntimeError):
    """Драйвер подставляет параметры на клиенте: пароль уехал бы на сервер литералом."""


class UnsupportedServerVersionError(RiskBaseError, RuntimeError):
    """Сервер старше 16: членство без `SET ROLE` не выдать, а с ним миграции получают суперпользователя."""


class SharedLoginRefusedError(RiskBaseError, ValueError):
    """Логин нельзя сделать общим: он миграционный, роль-владелец схемы или не существует."""


class ApplicationSchemasPresentError(RiskBaseError, RuntimeError):
    """Схемы сервисов на месте: снимать роли можно только после `alembic downgrade`."""


class RoleOwnsObjectsError(RiskBaseError, RuntimeError):
    """Роль чем-то владеет: `DROP OWNED BY` удалил бы эти объекты вместе с данными."""


# Драйверы с серверной подстановкой параметров: пароль доезжает до сервера как `$1`.
_SERVER_SIDE_PARAM_DRIVERS: Final[frozenset[str]] = frozenset({"asyncpg", "psycopg"})
# Драйвер, под которым бутстрап ходит в БД. Админский URL приходит от оператора и может быть
# записан с любым драйвером — приводим его к безопасному, а не отвергаем команду деплоя.
_BOOTSTRAP_DRIVERNAME: Final[str] = "postgresql+asyncpg"
# `GRANT ... WITH SET FALSE` появился в PostgreSQL 16. Без него членство в прежнем владельце
# отдаёт `risk_migrations` право `SET ROLE` в суперпользователя — молча понижать защиту нельзя.
_MINIMAL_SERVER_VERSION_NUM: Final[int] = 160000

# Логины, которые можно завести или обновить по одному (`bootstrap_logins`).
SELECTABLE_LOGIN_ROLES: Final[tuple[str, ...]] = (*LOGIN_ROLES, MIGRATION_ROLE)

_ROLE_EXISTS = text("SELECT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :role)")

_SERVER_VERSION = text("SELECT current_setting('server_version_num')::int")


async def bootstrap_roles_at_url(
    admin_url: str,
    credentials: "RoleCredentials",
    legacy_owner: str | None = None,
    shared_login: str | None = None,
) -> None:
    """Заводит роли по админскому URL, открывая соединение на безопасном драйвере.

    Драйвер из переданного URL игнорируется: пароли рантаймов обязаны уехать на сервер
    связанными параметрами, а это свойство драйвера, а не вызывающего кода.
    """
    engine = create_async_engine(make_url(admin_url).set(drivername=_BOOTSTRAP_DRIVERNAME))
    try:
        async with engine.begin() as connection:
            await connection.run_sync(
                bootstrap_roles, credentials, legacy_owner=legacy_owner, shared_login=shared_login
            )
    finally:
        await engine.dispose()


def bootstrap_roles(
    connection: Connection,
    credentials: RoleCredentials,
    legacy_owner: str | None = None,
    shared_login: str | None = None,
) -> None:
    """Приводит набор ролей к целевому состоянию. Повторный запуск безопасен и только обновляет пароли.

    `legacy_owner` — роль, которой сейчас принадлежат таблицы в `public` (в развёрнутой БД это
    `POSTGRES_USER`). Миграционный логин получает членство в ней, иначе `ALTER TABLE ... SET SCHEMA`
    на уже существующих таблицах упадёт: переносить таблицу может только её владелец. Членство
    выдаётся без права `SET ROLE`, поэтому суперпользователем миграционный логин не становится —
    отсюда требование к версии сервера.

    `shared_login` — логин, под которым в режиме общего логина подключаются все процессы (стенд
    тестирования, где отдельных логинов на процесс нет). Он получает членство в остальных
    рантайм-логинах — см. `_grant_shared_login`.

    Соединение обязано быть на драйвере с серверной подстановкой параметров — иначе пароли
    рантаймов попадут в текст запроса, а оттуда в `pg_stat_activity` и в серверный лог.
    """
    _require_server_side_parameters(connection)
    if shared_login is not None:
        _refuse_privileged_shared_login(shared_login)

    server_version = connection.execute(_SERVER_VERSION).scalar_one()
    if server_version < _MINIMAL_SERVER_VERSION_NUM:
        raise UnsupportedServerVersionError(
            f"Server version {server_version} is below {_MINIMAL_SERVER_VERSION_NUM}: 'GRANT ... WITH SET FALSE'"
            f" is unavailable, so '{MIGRATION_ROLE}' would be able to SET ROLE into the legacy table owner."
        )

    logins = credentials.as_login_map()
    _require_passwords(logins)

    for owner_role in sorted(set(SCHEMA_OWNER_ROLES.values())):
        connection.execute(_SET_ROLE_NAME, {"role": owner_role})
        connection.execute(_ENSURE_OWNER_ROLE)

    _ensure_logins(connection, logins)

    owner_roles = sorted(set(SCHEMA_OWNER_ROLES.values()))
    for granted_role in owner_roles:
        connection.execute(_SET_ROLE_NAME, {"role": granted_role})
        connection.execute(_GRANT_ROLE_TO_MIGRATIONS)
    if legacy_owner:
        connection.execute(_SET_ROLE_NAME, {"role": legacy_owner})
        connection.execute(_GRANT_LEGACY_OWNER_TO_MIGRATIONS)
    granted_to_migrations = [*owner_roles, *([legacy_owner] if legacy_owner else [])]
    granted_to_shared = _grant_shared_login(connection, shared_login) if shared_login is not None else []

    notice(
        "db.roles.bootstrapped",
        context={
            "owner_roles": sorted(set(SCHEMA_OWNER_ROLES.values())),
            "login_roles": sorted(logins),
            "granted_to_migrations": granted_to_migrations,
            "shared_login": shared_login,
            "granted_to_shared_login": granted_to_shared,
        },
    )


def _refuse_privileged_shared_login(shared_login: str) -> None:
    """Миграционный логин входит во все роли-владельцы и видит физические таблицы в обход
    изоляции; роль-владелец владеет объектами схемы. Ни тот, ни другой общим быть не может."""
    if shared_login == MIGRATION_ROLE or shared_login in SCHEMA_OWNER_ROLES.values():
        raise SharedLoginRefusedError(
            f"'{shared_login}' cannot be the shared login: it is the migration login or a schema owner role"
        )


def _grant_shared_login(connection: Connection, shared_login: str) -> list[str]:
    """Даёт общему логину право переключиться в каждый рантайм-логин, кроме самого себя.

    Членство `WITH INHERIT FALSE, SET TRUE`: неявно права рантаймов общий логин не получает, а
    переключается в них стартовым параметром `role` в процессе своей роли. Миграционный логин и
    роли-владельцы в выдачу не входят. Повторная выдача идемпотентна.
    """
    _refuse_privileged_shared_login(shared_login)
    if not connection.execute(_ROLE_EXISTS, {"role": shared_login}).scalar_one():
        raise SharedLoginRefusedError(f"Shared login '{shared_login}' does not exist")
    granted = [role for role in LOGIN_ROLES if role != shared_login]
    connection.execute(_SET_MEMBER_NAME, {"role": shared_login})
    for role in granted:
        connection.execute(_SET_ROLE_NAME, {"role": role})
        connection.execute(_GRANT_RUNTIME_LOGIN_TO_SHARED)
    return granted


async def bootstrap_logins_at_url(admin_url: str, logins: Mapping[str, SecretStr]) -> None:
    """Заводит или обновляет только перечисленные логины — см. `bootstrap_logins`."""
    engine = create_async_engine(make_url(admin_url).set(drivername=_BOOTSTRAP_DRIVERNAME))
    try:
        async with engine.begin() as connection:
            await connection.run_sync(bootstrap_logins, logins)
    finally:
        await engine.dispose()


def bootstrap_logins(connection: Connection, logins: Mapping[str, SecretStr]) -> None:
    """Заводит или обновляет только перечисленные логины, не трогая пароли остальных.

    Нужен, когда релиз добавляет новый логин или ротируется пароль одного из них: полный
    `bootstrap_roles` перезаписывает пароли всех логинов и требует их все. Логин получает то же,
    что при полном прогоне: `LOGIN`, пароль и `CONNECT` на базу (миграционный — ещё `CREATE`).

    Роли-владельцы схем и членство миграционного логина в них выдаёт только полный прогон.
    Поэтому миграционный логин здесь можно лишь обновить: заведённый с нуля, он остался бы без
    членства, и первая же миграция упала бы на правах.
    """
    _require_server_side_parameters(connection)

    unknown = sorted(set(logins) - set(SELECTABLE_LOGIN_ROLES))
    if unknown:
        raise UnknownLoginRoleError(
            f"Unknown login roles: {', '.join(unknown)}. Known: {', '.join(SELECTABLE_LOGIN_ROLES)}."
        )
    if not logins:
        raise UnknownLoginRoleError("No login roles requested.")
    _require_passwords(logins)
    if MIGRATION_ROLE in logins and not connection.execute(_ROLE_EXISTS, {"role": MIGRATION_ROLE}).scalar_one():
        raise MissingMigrationRoleError(
            f"Role '{MIGRATION_ROLE}' does not exist: run the full bootstrap, it also grants the schema owner roles."
        )

    _ensure_logins(connection, logins)

    notice("db.roles.logins_bootstrapped", context={"login_roles": sorted(logins)})


def _require_server_side_parameters(connection: Connection) -> None:
    driver = connection.dialect.driver
    if driver not in _SERVER_SIDE_PARAM_DRIVERS:
        raise UnsafeBootstrapDriverError(
            f"Driver '{driver}' substitutes bind parameters client-side: role passwords would reach"
            f" the server as literals. Use one of: {', '.join(sorted(_SERVER_SIDE_PARAM_DRIVERS))}."
        )


def _require_passwords(logins: Mapping[str, SecretStr]) -> None:
    empty = sorted(role for role, password in logins.items() if not password.get_secret_value())
    if empty:
        raise EmptyRolePasswordError(f"Empty password supplied for roles: {', '.join(empty)}")


def _ensure_logins(connection: Connection, logins: Mapping[str, SecretStr]) -> None:
    for role, password in logins.items():
        connection.execute(_SET_ROLE_NAME, {"role": role})
        connection.execute(_SET_PASSWORD, {"password": password.get_secret_value()})
        connection.execute(_ENSURE_LOGIN_ROLE)

    # Пароль в GUC больше не нужен; транзакция всё равно его сбросит, но не держим лишний такт.
    connection.execute(_SET_PASSWORD, {"password": ""})  # nosec B105 — сброс GUC, а не пароль

    for role in logins:
        connection.execute(_SET_ROLE_NAME, {"role": role})
        connection.execute(_GRANT_DATABASE_ACCESS)


async def drop_roles_at_url(admin_url: str) -> None:
    """Снимает роли изоляции схем по админскому URL. Запускается ПОСЛЕ `alembic downgrade`."""
    engine = create_async_engine(make_url(admin_url).set(drivername=_BOOTSTRAP_DRIVERNAME))
    try:
        async with engine.begin() as connection:
            await connection.run_sync(drop_roles)
    finally:
        await engine.dispose()


def drop_roles(connection: Connection) -> None:
    """Удаляет роли изоляции схем, не трогая ни одного объекта с данными.

    Два предохранителя, оба обязательны:

    1. Схемы сервисов обязаны быть уже сняты. После `alembic downgrade` их нет — значит таблицы
       вернулись в `public` и принадлежат прежнему владельцу.
    2. Каждая роль перед `DROP OWNED BY` проверяется на собственность. Эта команда не только
       отзывает права, но и УДАЛЯЕТ объекты роли: на роли-владельце схемы она снесла бы схему
       вместе с таблицами. На роли, которая ничем не владеет, удалять нечего, и остаётся ровно
       отзыв прав. Проверка ловит и забытый в какой-нибудь миграции `ALTER TABLE ... OWNER TO`:
       такая таблица осталась бы за `risk_migrations`.

    Отзыв нужен всем ролям, а не только логинам. Гранты переживают и `SET SCHEMA`, и снятие
    схемы: после отката владельцы схем уже ничем не владеют, но право, выданное владельцу
    представления на таблицу-источник, лежит на вернувшейся в `public` таблице и держит `DROP
    ROLE`. Логины сверх того держит `CONNECT` на базу.

    Прежний общий владелец таблиц (`POSTGRES_USER`) в список не входит и не может в него попасть:
    роли заданы константами, а не аргументами. Ему принадлежат вернувшиеся в `public` таблицы.

    Установка «с нуля» — отдельный случай: там таблицы создал `risk_migrations`, он же ими
    владеет, и снятие ролей упрётся в проверку собственности. Это верное поведение: удалять там
    нечего, кроме самих данных.

    Повторный запуск безопасен: отсутствующие роли пропускаются.
    """
    present = connection.execute(_PRESENT_APPLICATION_SCHEMAS, {"schemas": list(APPLICATION_SCHEMAS)}).scalars().all()
    if present:
        raise ApplicationSchemasPresentError(
            f"Application schemas still exist: {', '.join(present)}."
            " Run 'alembic downgrade' before dropping the roles that own them."
        )

    roles = (*LOGIN_ROLES, MIGRATION_ROLE, *sorted(set(SCHEMA_OWNER_ROLES.values())))
    for role in roles:
        owned = connection.execute(_OWNED_OBJECTS, {"role": role}).scalars().all()
        if owned:
            raise RoleOwnsObjectsError(
                f"Role '{role}' still owns: {', '.join(owned)}."
                " DROP OWNED BY would delete these objects; reassign them first."
            )
        connection.execute(_SET_ROLE_NAME, {"role": role})
        connection.execute(_DROP_OWNED_PRIVILEGES)
        connection.execute(_DROP_ROLE)

    notice("db.roles.dropped", context={"roles": list(roles)})
