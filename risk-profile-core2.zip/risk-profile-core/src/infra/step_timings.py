"""Общая база sink'ов по-шаговых замеров: один шаг — одна строка `with sink.step("name")`.

Sink'и живут в доменах (`StepTimings`/`LoadTimings` в src/calc/timings.py,
`InterpretationTimings`/`InterpretationLoadTimings` в src/interpretation/timings.py) — здесь только
механика, общая для всех четырёх: флаг `enabled` с рекурсивным каскадом по вложенным sink'ам и сам
замер.

Выключенный сбор ничего не стоит: `step()` отдаёт общий no-op контекст-менеджер — ни `perf_counter`,
ни аллокации, ни арифметики. Именно поэтому боевой путь (sink не передан → общий выключенный объект)
может звать `step()` безусловно, без парных `if measure:` вокруг каждого шага.

Вложенные шаги ОДНОГО sink'а вычитаются из родителя: `with t.step("formula")`, внутри которого
открылся `with t.step("cvd")`, запишет в `formula_ms` только время без cvd. Шаги разных sink'ов
независимы — под-шаги `t.load` из `load_ms` не вычитаются (см. LoadTimings: остаток до `load_ms` —
in-memory работа, под-шаги в сумму не входят).
"""

from contextlib import AbstractContextManager
from dataclasses import dataclass, fields
from time import perf_counter
from types import TracebackType


class _NoOpStep(AbstractContextManager[None]):
    """Шаг при выключенном сборе: ничего не замеряет и ничего не пишет.

    Один общий экземпляр на процесс — состояния у него нет, поэтому переиспользуется всеми
    sink'ами и всеми вложенными `with` одновременно.
    """

    __slots__ = ()

    def __enter__(self) -> None:
        return None

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        return None


_NOOP_STEP = _NoOpStep()


class _Step(AbstractContextManager[None]):
    """Замер одного шага: пишет длительность в поле `<name>_ms` своего sink'а.

    Пишет в `__exit__`, а не после успешного выхода, — время потрачено и на упавшем шаге
    (внешний вызов, откатившаяся транзакция). Исключение не подавляется.
    """

    __slots__ = ("_sink", "_field", "_start", "_nested_ms")

    def __init__(self, sink: "TimingSink", field_name: str) -> None:
        self._sink = sink
        self._field = field_name
        self._nested_ms = 0.0
        self._start = 0.0
        # Ранняя проверка имени шага: иначе опечатка всплыла бы только на выходе из `with`.
        getattr(sink, field_name)

    def __enter__(self) -> None:
        self._sink._open.append(self)
        self._start = perf_counter()
        return None

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        elapsed_ms = (perf_counter() - self._start) * 1000
        open_steps = self._sink._open
        open_steps.pop()
        if open_steps:
            # Родитель учитывает наше полное время как вложенное и вычтет его из своего.
            open_steps[-1]._nested_ms += elapsed_ms
        setattr(self._sink, self._field, getattr(self._sink, self._field) + elapsed_ms - self._nested_ms)
        return None


@dataclass
class TimingSink:
    """База sink'а замеров: флаг сбора и открытие шагов.

    `enabled` по умолчанию `True` — объект, собранный руками (тесты отчёта, diag-скрипты),
    представляет уже измеренные данные; реальное состояние проставляет хендлер каскадом.
    """

    enabled: bool = True

    def __post_init__(self) -> None:
        # Стек открытых шагов — не поле dataclass'а специально: обходчики полей (отчёт playground'а,
        # тесты) видят только замеры, а не служебное состояние.
        self._open: list[_Step] = []

    def enable(self, enabled: bool) -> None:
        """Проставляет состояние сбора себе и рекурсивно всем вложенным sink'ам."""
        self.enabled = enabled
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, TimingSink):
                value.enable(enabled)

    def step(self, name: str) -> AbstractContextManager[None]:
        """Контекст шага, накапливающий длительность в поле `<name>_ms`.

        При выключенном сборе — общий no-op: вызывать безусловно можно и на боевом пути.
        """
        if not self.enabled:
            return _NOOP_STEP
        return _Step(self, f"{name}_ms")


def resolve_sink[SinkT: TimingSink](passed: SinkT | None, disabled: SinkT) -> SinkT:
    """Sink вызывающего либо общий выключенный объект, если сбор никому не нужен.

    Sink'а не передали — результат прочитать некому, поэтому мерить не для кого: возвращаем общий
    выключенный экземпляр вместо аллокации дерева sink'ов на каждый вызов. Писать в него не может
    никто: все записи идут через `step()`, который при `enabled=False` не пишет.
    """
    return passed if passed is not None else disabled
