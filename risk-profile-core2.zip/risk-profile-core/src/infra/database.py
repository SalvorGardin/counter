from collections.abc import AsyncGenerator, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

from fastapi import Request
from pydantic import SecretStr
from sqlalchemy import MetaData, text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from src.config import ServiceRuntime, db_url_env, require_db_url, settings
from src.exceptions import RiskBaseError
from src.infra.db_schemas import (
    BULK_RECALC_ROLE,
    BULK_RECALC_SCHEMA_MAP,
    CALCULATION_ROLE,
    CALCULATION_SCHEMA_MAP,
    EHR_ROLE,
    EHR_SCHEMA_MAP,
    PROFILE_ROLE,
    PROFILE_SCHEMA_MAP,
)
from src.logger import alert, notice

if TYPE_CHECKING:
    # Imported under TYPE_CHECKING only: src.models.* import Base from this module, so a runtime
    # import of the catalog package (which imports the models) would be circular.
    from src.infra.catalog.calc import CalcCatalog
    from src.infra.catalog.http import HttpCatalog
    from src.infra.catalog.interpretation import InterpretationCatalog


def _pool_recycle_seconds(configured: int) -> int:
    """Maps the setting onto SQLAlchemy's encoding: 0 means "never recycle", which SQLAlchemy spells -1."""
    return configured if configured > 0 else -1


@dataclass(frozen=True)
class DatabaseRuntime:
    """Движок и фабрика сессий одной database identity: логин + карта схем.

    Карта фиксируется в момент создания рантайма и дальше не меняется — выбрать её из тела
    запроса или сообщения нельзя, иначе граница между сервисами перестала бы быть границей.
    """

    engine: AsyncEngine
    session_factory: async_sessionmaker[AsyncSession]

    async def dispose(self) -> None:
        await self.engine.dispose()


@dataclass(frozen=True)
class RuntimeIdentity:
    """Статичные факты о роли процесса в БД — единственное место, где роль описана.

    Логин, карта схем и имя переменной строки подключения меняются только вместе: запись на роль
    вместо параллельных словарей не даёт завести роль, забыв одно из трёх.
    """

    runtime: ServiceRuntime
    # Логин роли: с ним сверяется `current_user`, и на него переключается сессия в режиме общего логина.
    login: str
    # Карта трансляции схем: какие объекты видят ORM-модели этого рантайма.
    schema_map: Mapping[str, str]
    # Имя переменной строки подключения — для сообщений об ошибках.
    url_env: str


def _identity(runtime: ServiceRuntime, login: str, schema_map: Mapping[str, str]) -> RuntimeIdentity:
    return RuntimeIdentity(runtime=runtime, login=login, schema_map=schema_map, url_env=db_url_env(runtime))


RUNTIME_IDENTITIES: Mapping[ServiceRuntime, RuntimeIdentity] = MappingProxyType(
    {
        ServiceRuntime.PROFILE: _identity(ServiceRuntime.PROFILE, PROFILE_ROLE, PROFILE_SCHEMA_MAP),
        ServiceRuntime.CALCULATION: _identity(ServiceRuntime.CALCULATION, CALCULATION_ROLE, CALCULATION_SCHEMA_MAP),
        ServiceRuntime.EHR: _identity(ServiceRuntime.EHR, EHR_ROLE, EHR_SCHEMA_MAP),
        ServiceRuntime.BULK_RECALC: _identity(ServiceRuntime.BULK_RECALC, BULK_RECALC_ROLE, BULK_RECALC_SCHEMA_MAP),
    }
)


def _connect_args(identity: RuntimeIdentity) -> dict[str, Any]:
    """Параметры соединения asyncpg. Непусты только в режиме общего логина.

    Стартовый параметр `role` PostgreSQL применяет при открытии соединения — до первой команды и
    вне транзакции, поэтому `ROLLBACK` его не отменяет и соединение из пула остаётся под ролью
    процесса. `SET ROLE` в событии `connect` так не работает: SQLAlchemy над asyncpg открывает
    транзакцию на первой команде, и `SET` откатился бы вместе с ней.
    """
    if not settings.db_assume_runtime_role:
        return {}
    return {"server_settings": {"role": identity.login}}


def create_database_runtime(identity: RuntimeIdentity, url: SecretStr) -> DatabaseRuntime:
    """Собирает рантайм роли. Секрет разворачивается ровно здесь и никуда не уезжает.

    SQLAlchemy connection pools are lazy — no real connections are opened until the first query.
    """
    engine = create_async_engine(
        url.get_secret_value(),
        pool_size=5,
        max_overflow=10,
        # Одна и та же модель адресует либо свою таблицу, либо локальное представление сервиса:
        # решает эта карта, а не код репозитория.
        execution_options={"schema_translate_map": dict(identity.schema_map)},
        connect_args=_connect_args(identity),
        # Discard a pooled connection once it is older than the configured age and open a fresh one.
        # Covers the "connection died while idle in the pool" class of OperationalError/InterfaceError —
        # matters most for the long-lived calc_consumer, whose connections can sit idle between Kafka
        # batches long enough for Postgres/a pooler/NAT to reap them. Mid-transaction failures (deadlock,
        # drop during a query) are out of scope here — TransactionalRetryExecutor covers those.
        #
        # Deliberately NOT pool_pre_ping: the asyncpg dialect implements the ping as an explicit
        # transaction that always ends in ROLLBACK (sqlalchemy/dialects/postgresql/asyncpg.py,
        # `_async_ping`), so every checkout registered a rolled-back transaction in
        # pg_stat_database.xact_rollback — one per request, successful writes included. Recycling by age
        # closes the same failure window without a round-trip and without a transaction.
        pool_recycle=_pool_recycle_seconds(settings.db_pool_recycle_seconds),
    )
    return DatabaseRuntime(engine=engine, session_factory=async_sessionmaker(engine, expire_on_commit=False))


def create_calculation_runtime(url: SecretStr) -> DatabaseRuntime:
    """Рантайм логина расчёта. Нужен API в инлайн-режиме: пересчёт идёт под ролью расчёта."""
    return create_database_runtime(RUNTIME_IDENTITIES[ServiceRuntime.CALCULATION], url)


# Рантайм БД расчёта в процессе API: отдельный движок под логином расчёта со своей картой схем и
# собственным пулом — так профильные и расчётные соединения не могут обменяться ни личностью,
# ни картой. Нужен двум потребителям: инлайн-пересчёту (`kafka.enabled=false`) и синхронному
# запуску расчёта из testing-API. Оба пишут результаты, а профильному логину на них выдан только
# `SELECT, DELETE` через представления. На конфигурации без обоих потребителей не поднимается:
# в проде пересчёт выполняет consumer-воркер, и второе подключение API не нужно вовсе.
_calculation_runtime: DatabaseRuntime | None = None


def init_calculation_runtime() -> DatabaseRuntime:
    """Поднимает рантайм расчёта. Идемпотентна; при отсутствии URL падает конфигурационной ошибкой."""
    global _calculation_runtime
    if _calculation_runtime is None:
        _calculation_runtime = create_calculation_runtime(require_db_url(ServiceRuntime.CALCULATION))
    return _calculation_runtime


async def shutdown_calculation_runtime() -> None:
    """Закрывает пул расчёта в процессе API. Ничего не делает, если он не поднимался."""
    global _calculation_runtime
    if _calculation_runtime is not None:
        await _calculation_runtime.dispose()
        _calculation_runtime = None


class ServiceRuntimeMismatchError(RiskBaseError, RuntimeError):
    """Процесс поднят не под своей ролью: карта схем и логин БД не те, что нужны этому сервису."""


class PrimaryRuntimeNotInitializedError(RiskBaseError, RuntimeError):
    """К БД обратились до `init_primary_runtime` — ошибка порядка старта процесса."""


@dataclass(frozen=True)
class _Primary:
    runtime: ServiceRuntime
    database: DatabaseRuntime


# Основной рантайм процесса. Роль объявляет точка входа (`init_primary_runtime` в lifespan API,
# в `_main()` воркеров и playground), а не окружение: в общем пуле переменных все поды получают
# одно и то же. Тот, кто поднял рантайм, закрывает его на shutdown (`shutdown_primary_runtime`).
_primary: _Primary | None = None


def init_primary_runtime(runtime: ServiceRuntime) -> DatabaseRuntime:
    """Создаёт основной рантайм процесса под логином и картой схем роли. Соединений не открывает.

    Повторный вызов с той же ролью возвращает уже созданный рантайм. С другой ролью — отказ: двух
    основных рантаймов в процессе быть не может, и вторая роль означала бы ошибку в точке входа.
    Строка подключения обязательна только своя: без неё — `DatabaseConfigError` с именем переменной.
    """
    global _primary
    if _primary is not None:
        if _primary.runtime is not runtime:
            raise ServiceRuntimeMismatchError(
                f"primary database runtime is already initialized as '{_primary.runtime.value}', "
                f"cannot initialize it as '{runtime.value}'"
            )
        return _primary.database
    database = create_database_runtime(RUNTIME_IDENTITIES[runtime], require_db_url(runtime))
    _primary = _Primary(runtime=runtime, database=database)
    return database


def get_primary_runtime() -> DatabaseRuntime:
    """Основной рантайм процесса. До `init_primary_runtime` — ошибка, а не подключение наугад."""
    if _primary is None:
        raise PrimaryRuntimeNotInitializedError(
            "primary database runtime is not initialized: the process entrypoint must call "
            "init_primary_runtime() before any database access"
        )
    return _primary.database


async def shutdown_primary_runtime() -> None:
    """Закрывает пул основного рантайма и сбрасывает его. Ничего не делает, если он не поднимался."""
    global _primary
    if _primary is not None:
        primary, _primary = _primary, None
        await primary.database.dispose()


async def verify_runtime_login(engine: AsyncEngine, expected: ServiceRuntime) -> None:
    """Спрашивает у БД, под кем процесс на самом деле соединился, и падает на чужом логине.

    Карта схем — не граница: она лишь переименовывает объекты в запросе. Границу держат права
    логина, а его в процесс приносит строка подключения. Подставленный по ошибке
    `deploy/db/migrations.env` поднял бы API под `risk_migrations` — членом всех ролей-владельцев,
    видящим все физические таблицы мимо изоляции, — и ничего бы не сломалось заметным образом.

    В режиме общего логина сверяется тоже `current_user`: сессия уже переключена на логин роли, и
    проверка проходит без изменений. Пулер, отбросивший стартовый параметр `role`, оставил бы
    сессию под общим логином — и старт упал бы здесь, а не тихо работал не под той ролью.

    Проверка делается один раз на старте, на своём соединении: она же первая проба доступности БД.
    Расхождение уходит `alert()`-ом до падения: процесс умирает раньше первого `notice`, и без
    этого события инцидент не попал бы в структурированный лог вовсе.
    """
    identity = RUNTIME_IDENTITIES[expected]
    async with engine.connect() as connection:
        actual, session_user = (await connection.execute(text("SELECT current_user, session_user"))).one()
    if actual != identity.login:
        alert(
            "runtime login mismatch",
            {
                "check": "runtime_login",
                "runtime": expected.value,
                "expected": identity.login,
                "actual": actual,
            },
        )
        raise ServiceRuntimeMismatchError(
            f"{identity.url_env} connects as '{actual}', but runtime '{expected.value}' "
            f"must connect as '{identity.login}'"
        )
    if settings.db_assume_runtime_role:
        notice(
            "db runtime role assumed",
            context={"runtime": expected.value, "session_user": session_user, "current_user": actual},
        )


_NAMING_CONVENTION = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(referred_table_name)s_%(column_0_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=_NAMING_CONVENTION)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    async with get_primary_runtime().session_factory() as session:
        yield session


def get_calc_catalog(request: Request) -> "CalcCatalog":
    """FastAPI DI: the calc-specific catalog views built once in main.py lifespan."""
    return request.app.state.catalogs.calc


def get_interpretation_catalog(request: Request) -> "InterpretationCatalog":
    """FastAPI DI: the interpretation-specific catalog views built once in main.py lifespan."""
    return request.app.state.catalogs.interpretation


def get_http_catalog(request: Request) -> "HttpCatalog":
    """FastAPI DI: the immutable HTTP reference projection built during lifespan."""
    return request.app.state.catalogs.http
