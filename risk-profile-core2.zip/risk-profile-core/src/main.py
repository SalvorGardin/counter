"""Risk Model ML Service."""

import asyncio
import json
import os
import time
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from prometheus_client import CONTENT_TYPE_LATEST
from sqlalchemy.exc import IntegrityError
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import ClientDisconnect
from starlette.types import Scope

from src.api.consts import API_V1_PREFIX
from src.api.errors import (
    InvalidClientIdError,
    catalog_consistency_handler,
    client_gender_not_found_handler,
    client_not_found_handler,
    examination_category_invalid_handler,
    gender_and_birth_date_required_handler,
    http_exception_handler,
    integrity_error_handler,
    invalid_answer_type_handler,
    invalid_client_id_handler,
    invalid_event_type_handler,
    invalid_option_code_handler,
    missing_required_field_handler,
    question_not_found_handler,
    question_not_skippable_handler,
    system_code_not_found_handler,
    system_code_required_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from src.api.middleware import StripTrailingSlashMiddleware, make_metrics_middleware
from src.api.v1.risk_communication.router import router as risk_communication_router
from src.api.v1.risk_event.router import router as risk_event_router
from src.api.v1.risk_init.router import router as risk_init_router
from src.api.v1.risk_profile.router import router as risk_profile_router
from src.api.v2.risk_communication.router import router as risk_communication_v2_router
from src.calc.infra.cvd_client import init_cvd_client, shutdown_cvd_client
from src.calc.version import CalculationVersionError, calculation_version, require_calculation_version
from src.config import ServiceRuntime, calculation_runtime_required, settings
from src.constants import HEADER_AUTHORIZATION, HEADER_ENABLE_DEBUG, HEADER_REQUEST_ID
from src.infra.catalog.builder import catalog_builder
from src.infra.database import (
    init_calculation_runtime,
    init_primary_runtime,
    shutdown_calculation_runtime,
    shutdown_primary_runtime,
    verify_runtime_login,
)
from src.infra.kafka import init_kafka_producer, shutdown_kafka_producer
from src.infra.kafka.lag_probe import RecalcLagProbe
from src.logger import (
    FingersBuffer,
    alert,
    authorization_var,
    body_for_log,
    body_marker,
    debug_enabled_var,
    fingers_crossed_var,
    logger,
    notice,
    request_id_var,
    x_enable_debug_var,
)
from src.metrics import LOCAL_REGISTRY, init_metrics, render
from src.profiling import RollingProfiler
from src.services.risk_communication.domain.exceptions import (
    CatalogConsistencyError,
    ClientNotFoundError,
    InvalidAnswerTypeError,
    InvalidOptionCodeError,
    QuestionNotFoundError,
    QuestionNotSkippableError,
)
from src.services.risk_communication.domain.exceptions import (
    SystemCodeNotFoundError as RiskCommunicationSystemCodeNotFoundError,
)
from src.services.risk_event.domain.exceptions import (
    InvalidEventTypeError,
    SystemCodeRequiredError,
)
from src.services.risk_event.domain.exceptions import (
    SystemCodeNotFoundError as RiskEventSystemCodeNotFoundError,
)
from src.services.risk_init.domain.exceptions import GenderAndBirthDateRequiredError, MissingRequiredFieldError
from src.services.risk_profile.domain.exceptions import ClientGenderNotFoundError, ExaminationCategoryInvalidError

# Глобальный профайлер процесса: создаётся в lifespan только при settings.profiler.enabled.
_profiler: RollingProfiler | None = None
# Проба лага очереди пересчёта: поднимается в lifespan только при kafka.enabled и metrics.enabled.
# Опрашивается на скрейпе /metrics (см. хендлер), метрики отдаёт через LOCAL_REGISTRY.
_lag_probe: RecalcLagProbe | None = None
# Флаг drain-режима: True после получения сигнала остановки, до закрытия сервисов.
# /readiness возвращает 503, пока флаг установлен — load balancer исключает pod из ротации.
_is_shutting_down: bool = False


def _service_version() -> str:
    try:
        data = json.loads(Path("version.json").read_text())
        return str(data.get("version", "unknown"))
    except Exception:
        logger.warning("failed to read version.json", exc_info=True)
        return "unknown"


async def _init_lag_probe() -> None:
    """Поднимает пробу лага очереди пересчёта, если включены и Kafka, и экспозиция метрик.

    Best-effort: сбой старта пробы НЕ должен ронять приложение (метрики — обзервабилити, не
    бизнес-функция). Если проба не поднялась — работаем без лаг-метрик, остальная выдача цела.
    """
    global _lag_probe
    if not (settings.kafka.enabled and settings.metrics.enabled):
        return
    probe = RecalcLagProbe(settings.kafka)
    # Коллектор регистрируем СРАЗУ, до старта клиентов: тогда `recalc_queue_lag_ok` присутствует в
    # выдаче (=0) даже если Kafka/ACL на старте недоступны — дашборд заказчика видит «опрос не
    # удаётся», а не «ряда нет». start() best-effort: его сбой не роняет приложение (метрики —
    # обзервабилити, не бизнес-функция).
    LOCAL_REGISTRY.register(probe)
    _lag_probe = probe
    try:
        await probe.start()
    except Exception:
        logger.warning("recalc lag probe failed to start; lag_ok will report 0 until restart", exc_info=True)


async def _shutdown_lag_probe() -> None:
    global _lag_probe
    if _lag_probe is None:
        return
    LOCAL_REGISTRY.unregister(_lag_probe)
    try:
        await _lag_probe.stop()
    except Exception:
        # Сбой закрытия клиентов пробы (битый коннект к брокеру на shutdown) НЕ должен сорвать
        # остальной teardown: _teardown обёрнут только в except TimeoutError, и пробрось отсюда
        # пропустил бы дренаж продюсера и engine.dispose(). Логируем и продолжаем.
        logger.warning("recalc lag probe stop failed during shutdown", exc_info=True)
    _lag_probe = None


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    request_id_var.set(f"startup-{os.getpid()}")
    # API — профильный процесс: роль объявляет точка входа, строку подключения даёт переменная роли.
    # Выполняется в каждом uvicorn-воркере: рантайм у каждого процесса свой.
    database = init_primary_runtime(ServiceRuntime.PROFILE)
    # Логин приносит строка подключения. Сверяем с БД, а не верим на слово.
    await verify_runtime_login(database.engine, ServiceRuntime.PROFILE)
    global _is_shutting_down
    _is_shutting_down = False
    version = _service_version()
    notice(
        "service starting",
        context={
            "version": version,
            "kafka_enabled": settings.kafka.enabled,
            "cvd_enabled": settings.cvd.enabled,
        },
    )
    # ПЕРВЫЙ шаг инициализации. Статические каталоги справочников строятся ОДИН раз на старте
    # (после миграций/сидов) и обслуживают «чистые» catalog-методы из RAM; пустой/непрогруженный
    # каталог → CatalogLoadError → приложение не стартует (никогда не отдаём пустой каталог).
    # Заморозка стартового heap'а — внутри catalog_builder, поэтому вызов идёт первым: всё
    # созданное ниже (клиенты, метрики, профайлер) остаётся под сборщиком и переживает
    # переподключения без утечек (см. freeze_startup_heap).
    app.state.catalogs = await catalog_builder()
    # Метку ставим сразу после сборки: по ней потребитель `/health` отличает процесс, который
    # уже перечитал справочники, от того, который поднялся со старым каталогом.
    app.state.catalog_loaded_at = datetime.now(UTC).isoformat()

    # Версию и число воркеров отдаём параметрами: src/metrics.py намеренно не знает ни про main,
    # ни про config. workers — ЭФФЕКТИВНОЕ число (профайлер форсит 1, см. src/__main__.py), нужно
    # /proc-коллектору для выбора мастера при workers=1+multiproc.
    effective_workers = 1 if settings.profiler.enabled else settings.workers
    init_metrics(version, workers=effective_workers)
    await init_kafka_producer()
    await init_cvd_client()
    await _init_lag_probe()

    # Расчёт может исполняться в этом процессе — инлайн-пересчётом при выключенной Kafka или
    # синхронным запуском из testing-API, — но всегда под логином расчёта. Движок поднимаем на
    # старте: нехватка учётных данных — конфигурационная ошибка, и узнать о ней надо до приёма
    # запросов, а не на первом пересчёте. Соединений он при создании не открывает.
    if calculation_runtime_required():
        # Логин второго движка сверяется отдельно: перепутать в конфигурации можно именно его,
        # а под профильным логином расчёт упёрся бы в отказ в правах на первом апсерте результата.
        await verify_runtime_login(init_calculation_runtime().engine, ServiceRuntime.CALCULATION)
        # Расчёт штампует реестр версий, поэтому процессу, который его исполняет, версия нужна
        # на старте: без неё он проставил бы в реестр мусор, и когорта пересчёта стала бы
        # неопределимой. В прод-конфигурации API не считает и этой проверки не проходит.
        require_calculation_version()

    global _profiler
    if settings.profiler.enabled:
        _profiler = RollingProfiler(
            retention_minutes=settings.profiler.retention_minutes,
            bucket_seconds=settings.profiler.bucket_seconds,
        )
        await _profiler.start()

    try:
        yield
    finally:
        request_id_var.set(f"shutdown-{os.getpid()}")
        _is_shutting_down = True
        notice("service stopping", context={})
        # Ненулевая задержка даёт load balancer время заметить 503 на /readiness до обрыва соединений.
        # К этому моменту Uvicorn уже дренировал in-flight запросы; sleep нужен для балансировщиков,
        # которые продолжают опрашивать /readiness после старта shutdown. В k8s роль этой задержки
        # лучше берёт на себя preStop-хук (sleep N в pod spec) — в таком случае здесь ставить 0.
        if settings.shutdown_grace_delay > 0:
            await asyncio.sleep(settings.shutdown_grace_delay)
        if _profiler is not None:
            await _profiler.stop()
            _profiler = None
        # Бюджет на teardown = shutdown_timeout минус уже потраченный grace_delay.
        # Все операции оборачиваем вместе: httpx2-aclose, kafka-drain и оба engine.dispose()
        # могут зависнуть при TCP-blackhole — uvicorn timeout_graceful_shutdown lifespan не покрывает.
        teardown_budget = settings.shutdown_timeout - settings.shutdown_grace_delay

        async def _teardown() -> None:
            await _shutdown_lag_probe()
            await shutdown_cvd_client()
            await shutdown_kafka_producer(drain_timeout=teardown_budget)
            await shutdown_primary_runtime()
            await shutdown_calculation_runtime()

        try:
            await asyncio.wait_for(_teardown(), timeout=teardown_budget)
        except TimeoutError:
            alert(
                "service shutdown timed out, some resources may not have been released cleanly",
                {"timeout_s": teardown_budget},
            )


app = FastAPI(title="Risk Model Service", lifespan=lifespan)

# Нормализуем хвостовой слеш у /api/* ДО роутинга: иначе POST на путь со слешем ловит 307 на
# абсолютный URL без слеша и «падает с 404» за прокси/в Postman (см. StripTrailingSlashMiddleware).
# Добавлено здесь (до @app.middleware ниже) намеренно: логирующая мидлварь остаётся внешней и
# пишет в "request completed" path РОВНО как прислал клиент (со слешем), а роутер видит уже без.
app.add_middleware(StripTrailingSlashMiddleware)

# Starlette типизирует handler как (Request, Exception) -> Response, наши хендлеры
# точнее (RequestValidationError / HTTPException) — это сужение, безопасное в рантайме.
app.add_exception_handler(RequestValidationError, validation_exception_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(StarletteHTTPException, http_exception_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(InvalidClientIdError, invalid_client_id_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(ClientNotFoundError, client_not_found_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(QuestionNotFoundError, question_not_found_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(QuestionNotSkippableError, question_not_skippable_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(InvalidAnswerTypeError, invalid_answer_type_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(InvalidOptionCodeError, invalid_option_code_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(CatalogConsistencyError, catalog_consistency_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(ClientGenderNotFoundError, client_gender_not_found_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(ExaminationCategoryInvalidError, examination_category_invalid_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(MissingRequiredFieldError, missing_required_field_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(GenderAndBirthDateRequiredError, gender_and_birth_date_required_handler)  # ty: ignore[invalid-argument-type]
# Оба домена поднимают свою копию SystemCodeNotFoundError — общий хендлер на 404 для обеих.
app.add_exception_handler(RiskEventSystemCodeNotFoundError, system_code_not_found_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(RiskCommunicationSystemCodeNotFoundError, system_code_not_found_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(SystemCodeRequiredError, system_code_required_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(InvalidEventTypeError, invalid_event_type_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(IntegrityError, integrity_error_handler)  # ty: ignore[invalid-argument-type]
app.add_exception_handler(Exception, unhandled_exception_handler)
app.include_router(risk_init_router)
app.include_router(risk_profile_router)
app.include_router(risk_communication_router)
app.include_router(risk_communication_v2_router)
app.include_router(risk_event_router)
if settings.testing_api_enabled:
    from src.api.v1.testing.router import testing_router  # noqa: PLC0415

    app.include_router(testing_router)
    # Статический опросник для ручного прогона risk-communication; только при включённом testing API.
    _questionnaire_dir = Path(__file__).resolve().parent.parent / "web" / "questionnaire"

    @app.get("/questionnaire/config.js", include_in_schema=False)
    async def questionnaire_config_js() -> Response:
        """Отдаёт опроснику `X-Test-Api-Key` из настроек, чтобы не вводить его руками в форме.

        Роут объявлен до `app.mount` — иначе запрос перехватит StaticFiles. Токен уходит в браузер
        без авторизации, поэтому эндпоинт живёт только внутри `testing_api_enabled` (локальная разработка).
        """
        token = json.dumps(settings.test_api_key.get_secret_value())
        return Response(
            content=f"window.TEST_TOKEN = {token};\n",
            media_type="application/javascript",
            headers={"Cache-Control": "no-store"},
        )

    class _NoCacheStaticFiles(StaticFiles):
        """StaticFiles без `Cache-Control`, поэтому браузер кэширует файлы по эвристике и держит старый JS/CSS.

        `no-cache` не запрещает кэш, а требует перепроверки на каждом запросе: ETag/Last-Modified
        остаются, неизменённые файлы отдаются как 304. Правки опросника видны без ручного сброса кэша.
        """

        def file_response(
            self,
            full_path: str | os.PathLike[str],
            stat_result: os.stat_result,
            scope: Scope,
            status_code: int = 200,
        ) -> Response:
            response = super().file_response(full_path, stat_result, scope, status_code)
            response.headers["Cache-Control"] = "no-cache"
            return response

    app.mount("/questionnaire", _NoCacheStaticFiles(directory=_questionnaire_dir, html=True), name="questionnaire")

if settings.profiler.enabled:
    from src.api.v1.testing.auth import verify_test_token  # noqa: PLC0415

    @app.get(f"{API_V1_PREFIX}/debug/profile", include_in_schema=False, dependencies=[Depends(verify_test_token)])
    async def debug_profile(reset: bool = False) -> Response:
        """Отдаёт скользящее окно yappi-профиля как pstat-файл (.prof). `?reset=true` чистит окно."""
        if _profiler is None:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="profiler not started")
        data = await _profiler.dump_pstats(reset=reset)
        return Response(
            content=data,
            media_type="application/octet-stream",
            headers={"Content-Disposition": 'attachment; filename="risk-model.prof"'},
        )


def custom_openapi() -> dict[str, Any]:
    """Lazy-сборка спеки: дефолтный 422 не соответствует контракту вики (envelope + 400)."""
    if app.openapi_schema:
        return app.openapi_schema
    schema = get_openapi(title=app.title, version="0.1.0", routes=app.routes)
    for path_item in schema.get("paths", {}).values():
        for operation in path_item.values():
            operation.get("responses", {}).pop("422", None)
    app.openapi_schema = schema
    return schema


app.openapi = custom_openapi  # ty: ignore[invalid-assignment]


# Пути, которые не логируются телом и не попадают в HTTP-метрики: пробы балансировщика и сам
# скрейп метрик. /metrics здесь, чтобы Prometheus (раз в 15 с, вечно) не забивал логи и не
# накручивал собственную латентность в гистограмму запросов.
_PROBE_PATHS = {"/health", "/readiness", "/liveness", "/", "/metrics"}

_DEBUG_TRUTHY_VALUES = frozenset({"1", "true", "yes"})


def _is_debug_enabled(raw_header: str) -> bool:
    """Решение о debug-режиме на границе доверия. Принимаем только короткий whitelist truthy-значений
    — это и гейтит DEBUG локально, и блокирует прокидку любого мусора в downstream (см. middleware)."""
    return raw_header.lower() in _DEBUG_TRUTHY_VALUES


async def _request_body_for_log(request: Request) -> dict[str, Any] | None:
    """Тело запроса для лога — с защитой от выедания памяти: request.body() буферит ВСЁ тело
    в RAM, а log_body_max_bytes режет только то, что попадёт в лог. Заведомо нелогируемое
    не читаем вовсе: Content-Length сверх лимита → маркер без чтения (иначе клиент без
    авторизации выедает память гигабайтным POST на любой путь, включая 404); тело без
    Content-Length (chunked) → тоже маркер, его размер не узнать не читая. Сбой чтения
    не роняет запрос: логирование тела — best-effort диагностика.

    Возвращает dict|None (маркеры через body_marker) — единый тип поля для ES, см. body_marker."""
    declared = request.headers.get("content-length")
    if declared is not None:
        try:
            length = int(declared)
        except ValueError:
            return body_marker("invalid content-length")
        if length > settings.log_body_max_bytes:
            return body_marker(f"{length} bytes > {settings.log_body_max_bytes} cap")
    elif "transfer-encoding" in request.headers:
        return body_marker("no content-length (chunked)")
    try:
        return body_for_log(
            await request.body(),
            settings.log_body_max_bytes,
            request.headers.get("content-type", ""),
        )
    except ClientDisconnect:
        return None
    except Exception:
        logger.warning("failed to read request body for logging", exc_info=True)
        return body_marker("body read error")


async def _replay_chunks(chunks: list[Any]) -> AsyncGenerator[Any, None]:
    """Повторно отдаёт уже вычитанные чанки: `body_iterator` одноразовый, и после вычитки
    тела для лога клиенту нужно проиграть ровно то, что мы прочитали. Сохраняет НЕ-bytes
    элементы как есть (ASGI-сообщения pathsend) — `_StreamingResponse.__call__` сам отличит
    dict от тела, так что file/streaming-ответ не искажается."""
    for chunk in chunks:
        yield chunk


async def _response_body_for_log(response: Response) -> tuple[Response, dict[str, Any] | None]:
    """Тело ответа для лога. Возвращает (response, dict|None) — тот же `_StreamingResponse`
    от `call_next`, но с переустановленным `body_iterator` (он одноразовый: чтобы тело попало
    в лог, его надо вычитать, поэтому клиенту проигрываем прочитанное заново через
    `_replay_chunks`). Сам объект ответа сохраняется — заголовки/фон/info остаются на месте.

    Симметрично `_request_body_for_log`, заведомо проблемное не буферим (в лог — dict-маркер,
    единый тип поля для ES, см. `body_marker`; `body_iterator` при этом не трогаем):
    нет Content-Length (стрим), битый Content-Length, тело сверх лимита, не-JSON Content-Type.

    Если среди вычитанных чанков оказался не-bytes (ASGI-сообщение pathsend от FileResponse,
    прошедшего бы только при JSON Content-Type), тело не логируем (`b"".join` по dict упал бы),
    но поток проигрываем без искажения — клиент получает корректный ответ.

    Фоновые задачи живут на ВНУТРЕННЕМ ответе (coro в `BaseHTTPMiddleware`), а не на этом
    `_StreamingResponse`, поэтому вычитка/повтор их не теряет — гарантирует
    `test_risk_calculation_dispatches_full_recalc`."""
    declared = response.headers.get("content-length")
    if declared is None:
        return response, body_marker("no content-length (streaming response)")
    try:
        length = int(declared)
    except ValueError:
        return response, body_marker("invalid content-length")
    if length > settings.log_body_max_bytes:
        return response, body_marker(f"{length} bytes > {settings.log_body_max_bytes} cap")
    content_type = response.headers.get("content-type", "")
    if content_type.split(";")[0].strip().lower() != "application/json":
        return response, body_marker(f"non-JSON response, content-type={content_type or 'unknown'}")

    chunks: list[Any] = []
    try:
        # body_iterator — контракт стриминга BaseHTTPMiddleware (call_next всегда отдаёт
        # _StreamingResponse), но на базовом типе Response он не объявлен — отсюда ty: ignore.
        async for chunk in response.body_iterator:  # ty: ignore[unresolved-attribute]
            chunks.append(chunk)
    except Exception:
        # Поток мог прерваться на середине — отдаём клиенту то, что успели прочитать (не
        # «выпитый» итератор), запрос не роняем; маркер фиксирует факт сбоя для разбора.
        logger.warning("failed to read response body for logging", exc_info=True)
        response.body_iterator = _replay_chunks(chunks)  # ty: ignore[unresolved-attribute]
        return response, body_marker("body read error")

    response.body_iterator = _replay_chunks(chunks)  # ty: ignore[unresolved-attribute]
    if not all(isinstance(c, bytes) for c in chunks):
        return response, body_marker("non-buffered streaming response")
    return response, body_for_log(b"".join(chunks), settings.log_body_max_bytes, content_type)


@app.middleware("http")
async def request_middleware(
    request: Request,
    call_next: Callable[[Request], Awaitable[Response]],
) -> Response:
    """Устанавливает request-контекст и логирует duration_ms каждого запроса."""
    req_id = request.headers.get(HEADER_REQUEST_ID) or str(uuid.uuid4())
    auth_raw = request.headers.get(HEADER_AUTHORIZATION)
    auth = f"{auth_raw.split(' ', 1)[0]} ***" if auth_raw else None
    x_debug_raw = request.headers.get(HEADER_ENABLE_DEBUG, "")
    debug = _is_debug_enabled(x_debug_raw)

    request_id_var.set(req_id)
    authorization_var.set(auth)
    debug_enabled_var.set(debug)
    # Нормализуем X-Enable-Debug на границе доверия: сырое значение из заголовка не уходит наружу.
    # Downstream получит детерминистский "true"/"" — это даёт cap длины и блокирует мусор/инъекции
    # в headers Kafka и будущих httpx2-вызовов. См. requirements/logging.md (сквозная трассировка).
    x_enable_debug_var.set("true" if debug else "")
    # Fingers-crossed: per-request буфер INFO. ContextVar/try-finally изолируют буфер между
    # параллельными async-запросами и гарантируют сброс, даже если call_next бросит исключение.
    fc_token = fingers_crossed_var.set(FingersBuffer())

    try:
        logger.debug(
            "request started",
            extra={"log_context": {"method": request.method, "path": request.url.path}},
        )

        is_probe = request.url.path in _PROBE_PATHS
        # Таймер — до чтения тела: duration_ms включает и приём тела от медленного клиента.
        start = time.perf_counter()
        # Тело читаем ДО call_next: Starlette (_CachedRequest) кэширует его и отдаёт хендлеру
        # повторно. После call_next stream уже выпит и body() недоступен. Probe-пути не трогаем.
        request_body = None
        if not is_probe:
            request_body = await _request_body_for_log(request)

        response = await call_next(request)
        duration_ms = round((time.perf_counter() - start) * 1000, 2)

        if is_probe:
            logger.debug(
                "probe request",
                extra={"log_context": {"path": request.url.path, "duration_ms": duration_ms}},
            )
        else:
            # Тело/заголовки запроса И тело ответа — для QA на стенде (решение от 11.06.2026):
            # значения ключей из RISK_MODEL_LOG_MASK_KEYS маскирует MonologFormatter рекурсивно,
            # секреты (Authorization, X-Test-Api-Key, Cookie) маскируются в любом окружении.
            # Тело ответа требует вычитать одноразовый body_iterator → он переустанавливается
            # на повтор прочитанного (см. _response_body_for_log), клиент получает то же тело.
            response, response_body = await _response_body_for_log(response)
            notice(
                "request completed",
                context={
                    "method": request.method,
                    "path": request.url.path,
                    # Полный URL с хостом (scheme://host:port/path?query из Host-заголовка) —
                    # path оставляем как есть (низкокардинальный, под агрегации/фильтры Kibana).
                    "url": str(request.url),
                    "status_code": response.status_code,
                    "duration_ms": duration_ms,
                    "request_headers": dict(request.headers),
                    "request_body": request_body,
                    "response_body": response_body,
                },
            )

        response.headers[HEADER_REQUEST_ID] = req_id
        return response
    finally:
        fingers_crossed_var.reset(fc_token)


# HTTP-метрики регистрируем ПОСЛЕ request_middleware намеренно: add_middleware вставляет в начало
# стека, поэтому последняя зарегистрированная миддлварь — самый внешний слой. Метрики снаружи
# логирования → duration гистограммы включает накладные логирования (буферизацию тел ответа),
# что и есть честная server-side латентность (см. make_metrics_middleware).
app.middleware("http")(make_metrics_middleware(_PROBE_PATHS))


@app.get("/")
def greet() -> dict[str, str]:
    """Greeting endpoint."""
    return {"message": "Привет от Risk Model Service!"}


def _calculation_version_for_probe() -> str | None:
    """Версия расчёта для пробы. Недоступность файла пробу не роняет: она обязана отвечать всегда,
    а процесс, которому версия действительно нужна, до приёма запросов уже не дошёл бы."""
    try:
        return calculation_version()
    except CalculationVersionError:
        return None


@app.get("/health")
def health() -> dict[str, str | None]:
    """Healthcheck. `catalog_loaded_at` — момент сборки резидентного каталога этим процессом.

    Метка нужна тому, кто перезапускает контейнеры ради пересборки справочников
    (см. `src/workers/restarter.py`): «контейнер отвечает» и «каталог перечитан из БД» —
    разные события, и по одному коду 200 второе не отличить. До прогона lifespan атрибута ещё
    нет, поэтому читаем через getattr: проба обязана отвечать всегда.

    При workers>1 соседние запросы попадают в РАЗНЫЕ процессы со своими метками — чтобы убедиться,
    что каталог пересобрали все воркеры, пробу надо опросить несколько раз.

    `calculation_version` — версия расчёта этого процесса (артефакт релиза, см.
    `src/calc/version.py`). Стоит рядом с меткой каталога намеренно: обе отвечают на один вопрос —
    чем именно считает работающий процесс, — и по ним снаружи проверяется завершённость раската
    перед массовым пересчётом. `null`, если файл версии недоступен.
    """
    return {
        "status": "ok",
        "catalog_loaded_at": getattr(app.state, "catalog_loaded_at", None),
        "calculation_version": _calculation_version_for_probe(),
    }


@app.get("/readiness")
def readiness() -> Response:
    """Readiness probe."""
    if _is_shutting_down:
        return JSONResponse(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, content={"status": "shutting_down"})
    return JSONResponse(content={"status": "ready"})


@app.get("/liveness")
def liveness() -> dict[str, str]:
    """Liveness probe."""
    return {"status": "alive"}


@app.get("/metrics")
async def metrics() -> Response:
    """Экспозиция Prometheus (text format). Без авторизации — по тем же основаниям, что /health:
    PII в метриках нет, только агрегаты и шаблоны роутов. Лаг очереди пересчёта опрашивается тут
    же, на скрейпе (single-flight + кэш 10 с в самой пробе), — свежий снимок к моменту render()."""
    if not settings.metrics.enabled:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Metrics endpoint is disabled")
    if _lag_probe is not None:
        await _lag_probe.refresh()
    # render() синхронный и в проде читает mmap всех воркеров + генерирует до ~МБ тела: уносим в
    # threadpool, чтобы не блокировать event loop воркера. Ручка неавторизована (см. T7.1a), так
    # что держать её вне loop важнее, чем сэкономить переключение потока.
    body = await run_in_threadpool(render)
    return Response(content=body, media_type=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    # `python -m src.main` — не команда запуска: это модуль приложения, и к этой строке он уже
    # импортировал `src.metrics`, то есть в multiprocess-режиме открыл файлы метрик, — очищать
    # директорию поздно. Сервер запускает `python -m src` (src/__main__.py). Без явного отказа
    # команда молча завершалась бы с кодом 0, и оркестратор перезапускал бы контейнер по кругу без
    # единой строки о причине.
    raise SystemExit("src.main is the application module, not an entry point: start the service with python -m src")
