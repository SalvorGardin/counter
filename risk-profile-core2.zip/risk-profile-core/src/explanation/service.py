"""Объяснение одного случая и пересчёт несработавших факторов риска.

Только логика: SELECT-ы живут в `src/explanation/infra/reader.py` и в общих читателях
(`PatientsReader`, `RiskProfileReader`), справочные формы — в резидентных каталогах,
формулировки причин — в `src/explanation/domain/reasons.py`. Эндпоинты read-only: ни репозитория, ни `session.begin()`
здесь нет (так же, как в `RiskProfileService`).

Главное правило сборки: состав ответа определяет КАТАЛОГ, а собранные строки его наполняют.
Медработник, разбирающий один случай, смотрит на экран целиком, и любая дыра читается как
заключение модели — поэтому отсутствие строки сбора превращается в явное состояние, а не в пустое
место.
"""

from collections.abc import Mapping
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.explanation.schemas import (
    CaseExplanationResponse,
    InstrumentExplanation,
    InstrumentParameterExplanation,
    ReferenceItem,
    ResultReason,
    RiskFactorCondition,
    RiskFactorExplanation,
    SystemExplanation,
    UnmatchedRiskFactor,
    UnmatchedRiskFactorsResponse,
)
from src.constants import BIOMARKER_CLINREC_INSTRUMENT_CODE, PARAMETER_CODE_GENDER
from src.domain.biomarker_duplicates import instrument_parameter_values
from src.domain.risk_factor_conditions import condition_matches
from src.explanation.domain.exceptions import DiagnosticsTableMissingError
from src.explanation.domain.models import (
    CalcStatusView,
    CandidateSources,
    InstrumentResultView,
    InterpretationStatusView,
    ParameterSelection,
    RiskFactorMatchView,
)
from src.explanation.domain.readiness import instrument_explanation_state, system_explanation_state
from src.explanation.domain.reasons import (
    describe_calc_reason,
    describe_instrument_state,
    describe_interpretation_reason,
    describe_system_state,
    describe_unmatched_reason,
)
from src.explanation.domain.unmatched import unmatched_candidates
from src.explanation.infra.reader import ExplanationReader
from src.infra.catalog.calc import CalcCatalog
from src.infra.catalog.dtos import DiseaseDTO
from src.infra.catalog.http import HttpCatalog
from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.patients.reader import PatientsReader
from src.interpretation.domain.clinrec_factors import applicable_clinrec_disease_codes, select_clinrec_factors
from src.interpretation.domain.models import RiskFactorRow
from src.interpretation.domain.risk_factors import select_scored_factors
from src.interpretation.domain.scores import pick_score
from src.interpretation.infra.reader import InterpretationReader
from src.logger import notice
from src.services.risk_communication.domain.constants import COMMON_SYSTEM_CODE
from src.services.risk_communication.domain.exceptions import ClientNotFoundError, SystemCodeNotFoundError
from src.services.risk_profile.domain.doctors import resolve_doctor_specs
from src.services.risk_profile.domain.models import InterpretationView, SystemView
from src.services.risk_profile.infra.reader import RiskProfileReader

_NO_REASON = ResultReason()


class ExplanationService:
    def __init__(
        self,
        session: AsyncSession,
        http_catalog: HttpCatalog,
        calc_catalog: CalcCatalog,
        interpretation_catalog: InterpretationCatalog,
    ) -> None:
        self._reader = ExplanationReader(session)
        # Строки результатов читаются тем же читателем, что и в интерпретации: вход второго блока
        # факторов — сохранённая применимость групп `biomarker_kr` (§4.3, шаг 1б.1), и второй
        # запрос за той же выборкой разошёлся бы с ней при первой правке.
        self._interpretation_reader = InterpretationReader(session)
        self._patients_reader = PatientsReader(session)
        self._rp_reader = RiskProfileReader(session)
        self._http_catalog = http_catalog
        self._calc_catalog = calc_catalog
        self._interpretation_catalog = interpretation_catalog

    async def explain_case(self, patient_id: str) -> CaseExplanationResponse:
        """Цепочка вывода по пациенту целиком: системы, инструменты, факторы, врачи и причины."""
        notice("explanation: case requested", {"patient_id": patient_id})
        await self._require_patient(patient_id)

        systems = [
            SystemView(code=row.code, name=row.description, rang=row.rang)
            for row in self._http_catalog.ordered_systems
            if row.code != COMMON_SYSTEM_CODE
        ]
        system_codes = [system.code for system in systems]
        # Активные инструменты каталога — детерминированный порядок обхода и полнота состава.
        instrument_codes = sorted(self._calc_catalog.instrument_configs)
        systems_by_instrument = self._calc_catalog.system_codes_by_instrument

        statuses, interpretation_statuses, matches, diagnostics_available = await self._load_diagnostics(
            patient_id, instrument_codes, system_codes
        )
        results = await self._reader.get_result_times(patient_id, instrument_codes)
        interpretations = await self._rp_reader.get_interpretations_by_patient(patient_id)
        answers = await self._load_answers(patient_id)

        instrument_names = await self._reader.get_instrument_names(instrument_codes)
        doctor_codes = {code for view in interpretations.values() for code in (view.doctors_code or ())}
        doctor_names = resolve_doctor_specs(self._http_catalog.doctors, doctor_codes)
        instrument_parameter_codes = {
            parameter_code
            for definition in self._calc_catalog.instrument_configs.values()
            for parameter_code in (*definition.required_parameter_codes, *definition.optional_parameter_codes)
        }
        parameter_names = await self._reader.get_parameter_names(
            self._referenced_parameter_codes(statuses, matches) | instrument_parameter_codes
        )

        now = datetime.now(tz=UTC)
        entries = {
            code: self._instrument_entry(
                instrument_code=code,
                status=statuses.get(code),
                result=results.get(code),
                system_codes=list(systems_by_instrument.get(code, ())),
                answers=answers,
                instrument_names=instrument_names,
                parameter_names=parameter_names,
                now=now,
            )
            for code in instrument_codes
        }

        system_items = [
            self._system_item(
                system_code=system.code,
                system_name=system.name,
                interpretation=interpretations.get(system.code),
                status=interpretation_statuses.get(system.code),
                matches=matches.get(system.code, []),
                instruments=[
                    entries[code] for code in instrument_codes if system.code in systems_by_instrument.get(code, ())
                ],
                answers=answers,
                doctor_names={code: view.name for code, view in doctor_names.items()},
                instrument_names=instrument_names,
                parameter_names=parameter_names,
                now=now,
            )
            for system in systems
        ]

        return CaseExplanationResponse(
            patient_id=patient_id,
            generated_at=now,
            diagnostics_available=diagnostics_available,
            systems=system_items,
            instruments_outside_systems=[
                entries[code] for code in instrument_codes if not systems_by_instrument.get(code)
            ],
        )

    async def recompute_unmatched_risk_factors(
        self, *, patient_id: str, system_code: str
    ) -> UnmatchedRiskFactorsResponse:
        """Кандидаты в факторы риска, которые НЕ сработали бы на текущих данных, с причиной.

        Ответ помечен как пересчёт: он отвечает на вопрос «сработало бы сейчас», а сохранённое
        объяснение — на вопрос «что произошло тогда». Смешивать их в одном ответе значит
        гарантировать неверный вывод в тот единственный момент, когда они разойдутся. В БД пересчёт
        не пишет ничего.

        Источников факторов два, и пересчёт обязан пройти оба (§4.3, шаги 1а и 1б): условие,
        поднятое клинрек-биомаркером, первый источник не отбирает, и без второго блока диагностика
        объявила бы несработавшим фактор, который интерпретация включила.
        """
        notice("explanation: unmatched recompute requested", {"patient_id": patient_id, "system_code": system_code})
        await self._require_patient(patient_id)
        if system_code not in self._http_catalog.systems:
            raise SystemCodeNotFoundError([system_code])

        active_parameters = await self._patients_reader.get_active_parameters(patient_id)
        answers = {code: parameter.value for code, parameter in active_parameters.items()}
        gender = answers.get(PARAMETER_CODE_GENDER)
        catalog = self._interpretation_catalog
        system_parameter_codes = catalog.param_codes_by_system.get(system_code, frozenset())
        score_rows = catalog.score_rows_for(system_code, system_parameter_codes)

        # Отбор обоих блоков — те же чистые функции, что и в интерпретации, на текущих данных
        # пациента и текущем справочнике. Диагностические таблицы здесь не читаются вовсе.
        system_candidates = await self._reader.get_system_risk_factors(system_code)
        system_answers: dict[str, str] = {}
        system_excluded: set[str] = set()
        scored_trigger_codes: set[str] = set()
        for instrument_code in catalog.instrument_codes_by_system.get(system_code, ()):
            instrument_params = catalog.parameter_codes_by_instrument.get(instrument_code, frozenset())
            excluded = catalog.excluded_biomarker_parameter_codes(active_parameters.values(), instrument_code)
            instrument_answers = instrument_parameter_values(active_parameters, instrument_params, excluded)
            if gender is not None:
                instrument_answers[PARAMETER_CODE_GENDER] = gender
            system_answers.update(instrument_answers)
            system_excluded |= excluded
            scored = select_scored_factors(
                system_candidates=(
                    candidate for candidate in system_candidates if candidate.parameter_code in instrument_params
                ),
                score_rows=catalog.score_rows_for(system_code, instrument_params),
                patient_params=instrument_answers,
            )
            scored_trigger_codes.update(row.trigger_code for row in scored.ranked)
        # Параметр, вытесненный в одном инструменте, но оставшийся в выборке другого, первый источник
        # всё равно проверяет.
        system_selection = ParameterSelection(system_answers, frozenset(system_excluded - system_answers.keys()))

        clinrec_by_disease = await self._clinrec_candidates(patient_id, system_code)
        clinrec_excluded = catalog.excluded_biomarker_parameter_codes(
            active_parameters.values(), BIOMARKER_CLINREC_INSTRUMENT_CODE
        )
        clinrec_answers = instrument_parameter_values(
            active_parameters,
            catalog.parameter_codes_by_instrument.get(BIOMARKER_CLINREC_INSTRUMENT_CODE, frozenset()),
            clinrec_excluded,
        )
        clinrec = select_clinrec_factors(
            candidates_by_disease=clinrec_by_disease,
            patient_params=clinrec_answers,
            gender=gender,
        )
        # Пол в выборку `biomarker_kr` не входит, но проверка условия по полу читает его из ответов.
        clinrec_selection = ParameterSelection(
            {**clinrec_answers, PARAMETER_CODE_GENDER: gender} if gender is not None else clinrec_answers,
            clinrec_excluded,
        )

        # Разбираем оба набора кандидатов вместе: условие второго блока может стоять на триггере
        # чужой системы (§4.3, шаг 1б.3), поэтому в выборке по системе его нет вовсе. Дедупликация
        # по коду условия — на случай фактора, поднятого сразу несколькими группами.
        clinrec_candidates = [row for rows in clinrec_by_disease.values() for row in rows]
        clinrec_trigger_codes = frozenset(row.trigger_code for row in clinrec_candidates)
        candidates = {row.trigger_code: row for row in [*system_candidates, *clinrec_candidates]}
        unmatched = unmatched_candidates(
            candidates=candidates.values(),
            sources=CandidateSources(
                system_parameter_codes=frozenset(system_parameter_codes),
                scored_parameter_codes=frozenset(score_rows),
                clinrec_trigger_codes=clinrec_trigger_codes,
                clinrec_parameter_codes=catalog.clinrec_parameter_codes,
            ),
            patient_answers=system_selection.answers,
            matched_trigger_codes=scored_trigger_codes | clinrec.matched_trigger_codes,
            selections_by_trigger_code={
                trigger_code: clinrec_selection if trigger_code in clinrec_trigger_codes else system_selection
                for trigger_code in candidates
            },
        )

        parameter_names = await self._reader.get_parameter_names(
            {candidate.factor.parameter_code for candidate in unmatched}
        )
        return UnmatchedRiskFactorsResponse(
            patient_id=patient_id,
            system_code=system_code,
            recomputed_at=datetime.now(tz=UTC),
            items=[
                UnmatchedRiskFactor(
                    trigger_code=candidate.factor.trigger_code,
                    risk_factor_code=candidate.factor.code,
                    name=candidate.factor.description,
                    reasoning=candidate.factor.reasoning,
                    parameter_code=candidate.factor.parameter_code,
                    parameter_name=parameter_names.get(candidate.factor.parameter_code),
                    condition=_condition(candidate.factor),
                    modifiability=candidate.factor.modifiability,
                    answer=answers.get(candidate.factor.parameter_code),
                    reason_code=candidate.reason_code.value,
                    reason_text=describe_unmatched_reason(candidate.reason_code),
                )
                for candidate in unmatched
            ],
        )

    async def _clinrec_candidates(self, patient_id: str, system_code: str) -> dict[str, tuple[RiskFactorRow, ...]]:
        """Кандидаты второго блока §4.3 по группам заболеваний системы, применимым на последнем расчёте.

        Применимость группы — сохранённая: строка `results` пересчитывается только по триггеру
        расчёта, и пересчитывать её здесь пересчёт кандидатов не вправе (§4.2.1, шаг 2). Условия при
        этом проверяются по действующим ответам пациента, поэтому истёкший биомаркер фактор не
        поднимает даже при применимой строке (§4.3, шаг 1б.3).
        """
        results = await self._interpretation_reader.get_results_for_systems(patient_id, [system_code])
        return {
            disease_code: self._interpretation_catalog.clinrec_factors_for(system_code, disease_code)
            for disease_code in applicable_clinrec_disease_codes(results.get(system_code, []))
        }

    async def _load_answers(self, patient_id: str) -> dict[str, str]:
        """Текущие ответы пациента — его действующие параметры, а не копия из диагностики.

        Копия ответа в диагностической таблице была бы вторым источником правды, поэтому её там и
        нет: сохраняются только данные справочника и коды.
        """
        active = await self._patients_reader.get_active_parameters(patient_id)
        return {code: parameter.value for code, parameter in active.items()}

    async def _require_patient(self, patient_id: str) -> None:
        if await self._patients_reader.find_patient(patient_id) is None:
            notice("explanation: patient not found", {"patient_id": patient_id})
            raise ClientNotFoundError(patient_id)

    async def _load_diagnostics(
        self, patient_id: str, instrument_codes: list[str], system_codes: list[str]
    ) -> tuple[
        dict[str, CalcStatusView],
        dict[str, InterpretationStatusView],
        dict[str, list[RiskFactorMatchView]],
        bool,
    ]:
        """Диагностические таблицы читаются первыми и все три сразу.

        Отсутствие таблицы (миграция сбора не применена) гасится здесь: состав ответа определяет
        каталог, поэтому ответ остаётся полным, а признак `diagnostics_available` говорит, что
        наполнять его было нечем. Частичной картины не отдаём — читающая сторона иначе показала бы
        причины расчёта без причин интерпретации, а проверяющий принял бы пробел за вывод модели.

        Признак отвечает ровно на один вопрос — есть ли сбор в этой базе, — и не зависит от того,
        накопились ли строки по конкретному пациенту. Иначе «сбор недоступен» и «по пациенту ещё
        не считали» пришли бы одним значением, а различать их обязательно: пусто у всех пациентов
        сразу после включения сбора и после перезаливки диагностики (0120). «Считали или нет» по
        каждому инструменту и системе несёт `explanationState`.
        """
        try:
            statuses = await self._reader.get_calc_statuses(patient_id, instrument_codes)
            interpretation_statuses = await self._reader.get_interpretation_statuses(patient_id, system_codes)
            matches = await self._reader.get_risk_factor_matches(patient_id, system_codes)
        except DiagnosticsTableMissingError:
            return {}, {}, {}, False
        return statuses, interpretation_statuses, matches, True

    @staticmethod
    def _referenced_parameter_codes(
        statuses: Mapping[str, CalcStatusView],
        matches: Mapping[str, list[RiskFactorMatchView]],
    ) -> set[str]:
        codes = {code for status in statuses.values() for code in (status.missing_parameter_codes or ())}
        codes |= {match.parameter_code for system_matches in matches.values() for match in system_matches}
        return codes

    def _instrument_entry(
        self,
        *,
        instrument_code: str,
        status: CalcStatusView | None,
        result: InstrumentResultView | None,
        system_codes: list[str],
        answers: Mapping[str, str],
        instrument_names: Mapping[str, str],
        parameter_names: Mapping[str, str],
        now: datetime,
    ) -> InstrumentExplanation:
        state = instrument_explanation_state(
            status_at=status.date_time if status is not None else None,
            result_at=result.date_time if result is not None else None,
            now=now,
            questionnaire_started=self._has_any_answer(instrument_code, answers),
        )
        # При наличии строки сбора отдаём её данные и для `PREVIOUS_RUN`: состояние уже
        # сообщает, что объяснение относится к прошлому прогону.
        definition = self._calc_catalog.instrument_configs.get(instrument_code)
        required_codes = definition.required_parameter_codes if definition is not None else ()
        optional_codes = definition.optional_parameter_codes if definition is not None else ()
        return InstrumentExplanation(
            instrument_code=instrument_code,
            instrument_name=instrument_names.get(instrument_code),
            system_codes=system_codes,
            status=status.status if status is not None else None,
            reason_code=status.reason_code if status is not None else None,
            reason_text=describe_calc_reason(status.reason_code) if status is not None else None,
            parameters=[
                InstrumentParameterExplanation(
                    code=code,
                    name=parameter_names.get(code),
                    required=required,
                    answer=answers.get(code),
                )
                for required, codes in ((True, required_codes), (False, optional_codes))
                for code in codes
            ],
            missing_parameters=(
                _reference_items(status.missing_parameter_codes or (), parameter_names) if status is not None else []
            ),
            applicable_questions=status.applicable_questions if status is not None else None,
            progressed_questions=status.progressed_questions if status is not None else None,
            recorded_at=status.date_time if status is not None else None,
            result_at=result.date_time if result is not None else None,
            explanation_state=state.value,
            explanation_state_text=describe_instrument_state(state),
        )

    def _has_any_answer(self, instrument_code: str, answers: Mapping[str, str]) -> bool:
        """Есть ли хотя бы один действующий ответ по показателям инструмента.

        Отличает «расчёт не выполнялся» от «опросник не начат»: расчёт по опросникам идёт от
        ответов, и инструмента, которого пациент не касался, он не посещает вовсе.
        """
        definition = self._calc_catalog.instrument_configs.get(instrument_code)
        if definition is None:
            return False
        codes = (*definition.required_parameter_codes, *definition.optional_parameter_codes)
        return any(code in answers for code in codes)

    def _system_item(
        self,
        *,
        system_code: str,
        system_name: str,
        interpretation: InterpretationView | None,
        status: InterpretationStatusView | None,
        matches: list[RiskFactorMatchView],
        instruments: list[InstrumentExplanation],
        answers: Mapping[str, str],
        doctor_names: Mapping[str, str],
        instrument_names: Mapping[str, str],
        parameter_names: Mapping[str, str],
        now: datetime,
    ) -> SystemExplanation:
        state = system_explanation_state(
            status_at=status.date_time if status is not None else None,
            interpretation_at=interpretation.date_time if interpretation is not None else None,
            now=now,
        )
        return SystemExplanation(
            system_code=system_code,
            system_name=system_name,
            risk_level=interpretation.risk_level if interpretation is not None else None,
            explanation_state=state.value,
            explanation_state_text=describe_system_state(state),
            interpreted_at=interpretation.date_time if interpretation is not None else None,
            recorded_at=status.date_time if status is not None else None,
            risk_level_reason=_result_reason(
                status.risk_level_status if status is not None else None,
                status.risk_level_reason_code if status is not None else None,
            ),
            diseases_reason=_result_reason(
                status.diseases_status if status is not None else None,
                status.diseases_reason_code if status is not None else None,
            ),
            risk_factors_reason=_result_reason(
                status.risk_factors_status if status is not None else None,
                status.risk_factors_reason_code if status is not None else None,
            ),
            doctors_reason=_result_reason(
                status.doctors_status if status is not None else None,
                status.doctors_reason_code if status is not None else None,
            ),
            blocking_instruments=_reference_items(
                status.blocking_instrument_codes or () if status is not None else (), instrument_names
            ),
            diseases=_disease_items(
                interpretation.diseases or () if interpretation is not None else (),
                self._http_catalog.diseases_by_code,
            ),
            instruments=instruments,
            risk_factors=[
                self._risk_factor_item(
                    system_code=system_code,
                    match=match,
                    answers=answers,
                    parameter_names=parameter_names,
                )
                for match in matches
            ],
            doctors=_reference_items(
                interpretation.doctors_code or () if interpretation is not None else (), doctor_names
            ),
        )

    def _risk_factor_item(
        self,
        *,
        system_code: str,
        match: RiskFactorMatchView,
        answers: Mapping[str, str],
        parameter_names: Mapping[str, str],
    ) -> RiskFactorExplanation:
        answer = answers.get(match.parameter_code)
        # Ответ мог измениться после расчёта: показывать совпадение, которого нет на текущих
        # данных, нельзя — иначе чтение утверждает то, чего не проверяло.
        matches_condition = answer is not None and _snapshot_matches(match, answer, answers.get("gender"))
        score_rows = self._interpretation_catalog.score_rows_for(system_code, {match.parameter_code})
        return RiskFactorExplanation(
            trigger_code=match.trigger_code,
            risk_factor_code=match.risk_factor_code,
            name=match.factor_description,
            reasoning=match.reasoning,
            parameter_code=match.parameter_code,
            parameter_name=parameter_names.get(match.parameter_code),
            condition=_condition(match),
            modifiability=match.modifiability,
            answer=answer,
            answer_matches_condition=matches_condition,
            is_representative=match.is_representative,
            # Оценки самой по себе наружу нет — только признак того, что строки под условие в
            # справочнике оценок не нашлось.
            score_reference_incomplete=pick_score(score_rows.get(match.parameter_code, ()), answer) is None,
        )


def _result_reason(status: str | None, reason_code: str | None) -> ResultReason:
    if status is None and reason_code is None:
        return _NO_REASON
    return ResultReason(
        status=status,
        reason_code=reason_code,
        reason_text=describe_interpretation_reason(reason_code),
    )


def _reference_items(codes: tuple[str, ...] | list[str], names: Mapping[str, str]) -> list[ReferenceItem]:
    return [ReferenceItem(code=code, name=names.get(code)) for code in codes]


def _disease_items(
    codes: tuple[str, ...] | list[str], diseases_by_code: Mapping[str, DiseaseDTO]
) -> list[ReferenceItem]:
    """Заболевания системы: код из `interpretations.diseases` и название из справочника.

    В отличие от публичного ответа, код вне справочника здесь не выбрасывается, а отдаётся с
    незаполненным названием: разбор случая начинается с сохранённого значения, и молчаливое
    исчезновение строки скрыло бы как раз то расхождение, ради которого в ответ и смотрят.
    """
    return [
        ReferenceItem(code=code, name=disease.description if (disease := diseases_by_code.get(code)) else None)
        for code in codes
    ]


def _condition(factor: RiskFactorRow | RiskFactorMatchView) -> RiskFactorCondition:
    return RiskFactorCondition(
        value_type=factor.value_type,
        operator=factor.operator,
        value_num=_decimal_text(factor.value_num),
        min_value=_decimal_text(factor.min_value),
        max_value=_decimal_text(factor.max_value),
        value_text=factor.value_text,
        gender=factor.gender,
    )


def _decimal_text(value: object | None) -> str | None:
    return str(value) if value is not None else None


def _snapshot_matches(match: RiskFactorMatchView, answer: str, gender: str | None) -> bool:
    """Сработал бы снимок условия на текущем ответе — то же сравнение, что и в отборе.

    Реализация одна на оба места (`src/domain/risk_factor_conditions.py`): здесь сверяется снимок
    справочника из диагностики, там — живая строка справочника, и расходиться они не должны.
    """
    return condition_matches(match, answer, gender)
