"""Статусы расчёта по пациенту: полный каталог активных инструментов с исходами расчёта.

Только логика: строки `calculation_statuses` и названия инструментов читает
`src/explanation/infra/reader.py`, привязку инструментов к системам отдаёт резидентный каталог.

Отсутствующая строка становится `not_started` — исход, которого в БД нет. Неоднозначность
отсутствующей строки (инструмент не посещался, частичный пересчёт, сбор был выключен) разбирается
здесь и наружу не протекает; развёрнутое различение случаев — у объяснения случая
(`ExplanationService.explain_case`), которое сверяется ещё и со временем результата.
"""

from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.testing.calc_status.schemas import CalcStatusInstrument
from src.explanation.domain.constants import OUTCOME_NOT_STARTED
from src.explanation.domain.exceptions import DiagnosticsTableMissingError
from src.explanation.infra.reader import ExplanationReader
from src.infra.catalog.calc import CalcCatalog
from src.infra.patients.reader import PatientsReader
from src.logger import notice
from src.services.risk_communication.domain.exceptions import ClientNotFoundError


class CalcStatusService:
    def __init__(self, session: AsyncSession, catalog: CalcCatalog) -> None:
        self._reader = ExplanationReader(session)
        self._patients_reader = PatientsReader(session)
        self._catalog = catalog

    async def get_statuses(self, patient_id: str) -> list[CalcStatusInstrument]:
        """Полный список активных инструментов с исходами расчёта для пациента.

        При отсутствующей таблице `calculation_statuses` (миграция сбора не применена) отдаёт весь
        каталог в `not_started`, а не 500: состав ответа определяет каталог, и без строк сбора он
        остаётся полным. ERROR-строку в лог пишет читатель, в котором сбой и возник.
        """
        if await self._patients_reader.find_patient(patient_id) is None:
            notice("testing.calc_status: patient not found", {"patient_id": patient_id})
            raise ClientNotFoundError(patient_id)

        # Порядок — по коду инструмента: ответ должен быть стабилен между вызовами.
        instrument_codes = sorted(self._catalog.instrument_configs)
        names = await self._reader.get_instrument_names(instrument_codes)
        try:
            statuses = await self._reader.get_calc_statuses(patient_id, instrument_codes)
        except DiagnosticsTableMissingError:
            statuses = {}

        items: list[CalcStatusInstrument] = []
        for code in instrument_codes:
            status = statuses.get(code)
            items.append(
                CalcStatusInstrument(
                    instrument_code=code,
                    instrument_description=names.get(code),
                    system_codes=list(self._catalog.system_codes_by_instrument.get(code, ())),
                    status=status.status if status is not None else OUTCOME_NOT_STARTED,
                    reason_code=status.reason_code if status is not None else None,
                    missing_parameter_codes=(
                        list(status.missing_parameter_codes)
                        if status is not None and status.missing_parameter_codes is not None
                        else None
                    ),
                    applicable_questions=status.applicable_questions if status is not None else None,
                    progressed_questions=status.progressed_questions if status is not None else None,
                    date_time=status.date_time if status is not None else None,
                )
            )
        return items
