"""Parse semicolon-delimited CSV files into dicts ready for DB insertion."""

import csv
from pathlib import Path


def load_csv(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open(encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        return [{k: v.strip() for k, v in row.items()} for row in reader]
