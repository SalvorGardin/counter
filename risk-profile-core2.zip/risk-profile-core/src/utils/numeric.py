"""Разбор числового ответа пациента — единственное место, где допускается десятичная запятая."""

from decimal import Decimal


def parse_answer_decimal(value: str) -> Decimal | None:
    """Число из ответа пациента или None, если ответ числом не является.

    Запятая как десятичный разделитель — та же договорённость, по которой живёт
    `coerce_numeric_answer` в risk_communication: ответы приходят и как `29,9`, и как `29.9`, а
    пороги справочника хранятся числами. Без замены сравнение молча не срабатывало бы на части
    ответов, поэтому нормализация собрана здесь, а не повторяется в каждом сравнении.

    `NaN` и `Infinity` — валидный вход для `Decimal`, но не число ответа: сравнение с `NaN` бросает
    `InvalidOperation` уже за пределами разбора, поэтому они отсекаются здесь заодно с нечислами.
    """
    try:
        number = Decimal(value.replace(",", "."))
    except (ValueError, ArithmeticError):
        return None
    return number if number.is_finite() else None
