"""Глобальный формат ошибок API: envelope `{isSuccess, error: {code, message}}`."""

from typing import Annotated, Any, Literal

from fastapi import Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import Field
from sqlalchemy.exc import IntegrityError
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.api.schemas import ERROR_CODE_MAX_LENGTH, ERROR_MESSAGE_MAX_LENGTH, CamelModel
from src.exceptions import RiskBaseError
from src.logger import logger
from src.services.risk_communication.domain.exceptions import (
    CatalogConsistencyError,
    ClientNotFoundError,
    InvalidAnswerTypeError,
    InvalidOptionCodeError,
    QuestionNotFoundError,
    QuestionNotSkippableError,
)
from src.services.risk_event.domain.exceptions import (
    InvalidEventTypeError,
    SystemCodeRequiredError,
)
from src.services.risk_init.domain.exceptions import GenderAndBirthDateRequiredError, MissingRequiredFieldError
from src.services.risk_profile.domain.exceptions import ClientGenderNotFoundError, ExaminationCategoryInvalidError


class InvalidClientIdError(RiskBaseError):
    """clientId не соответствует формату (длина/допустимые символы). Валидация на границе API
    (см. src.api.dependencies.validate_client_id) — поднимается до вызова доменного сервиса."""


class ErrorPayload(CamelModel):
    code: Annotated[str, Field(max_length=ERROR_CODE_MAX_LENGTH)]
    message: Annotated[str, Field(max_length=ERROR_MESSAGE_MAX_LENGTH)]


class ErrorEnvelope(CamelModel):
    is_success: Literal[False] = False
    error: ErrorPayload


class SuccessEnvelope(CamelModel):
    is_success: Literal[True] = True
    error: None = None  # всегда null при успехе; поле обязательно в контракте (симметрия с ErrorEnvelope)


def _error_code(loc: tuple[Any, ...]) -> str:
    # При коллизии имён в path/body коды совпадут — в текущем контракте таких полей нет.
    parts = [str(p) for p in loc if p not in ("body", "query", "path")]
    if not parts:
        return "INVALID_REQUEST"
    return ("INVALID_" + "_".join(parts)).upper()[:ERROR_CODE_MAX_LENGTH]


def _envelope(code: str, message: str) -> dict[str, Any]:
    return ErrorEnvelope(
        error=ErrorPayload(code=code[:ERROR_CODE_MAX_LENGTH], message=message[:ERROR_MESSAGE_MAX_LENGTH])
    ).model_dump(
        by_alias=True,
    )


def _internal_error_envelope() -> dict[str, Any]:
    """Общий ответ на внутреннюю ошибку: детали остаются в логе, наружу уходит один и тот же код."""
    return _envelope(code="INTERNAL_ERROR", message="Internal server error")


async def validation_exception_handler(
    _request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    """Pydantic-ошибки валидации → 400 + envelope."""
    first = exc.errors()[0]
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code=_error_code(tuple(first["loc"])),
            message=str(first["msg"]),
        ),
    )


async def http_exception_handler(
    _request: Request,
    exc: StarletteHTTPException,
) -> JSONResponse:
    """HTTPException (включая Starlette routing 404) → envelope с исходным статусом."""
    return JSONResponse(
        status_code=exc.status_code,
        content=_envelope(
            code=f"HTTP_{exc.status_code}",
            message=str(exc.detail),
        ),
    )


async def unhandled_exception_handler(
    request: Request,
    exc: Exception,
) -> JSONResponse:
    """Любая необработанная ошибка → 500 + envelope, детали — только в логах."""
    logger.error(
        "unhandled error in request handler",
        extra={"log_context": {"method": request.method, "path": request.url.path}},
        exc_info=exc,
    )
    return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content=_internal_error_envelope())


async def integrity_error_handler(_request: Request, exc: IntegrityError) -> JSONResponse:
    logger.warning("integrity error mapped to 409", extra={"log_context": {"error": str(exc.orig)}})
    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content=_envelope(code="CONFLICT", message="Resource already exists"),
    )


async def invalid_client_id_handler(_request: Request, exc: InvalidClientIdError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="INVALID_CLIENT_ID",
            message="Идентификатор клиента должен содержать от 5 до 36 символов.",
        ),
    )


async def client_not_found_handler(_request: Request, exc: ClientNotFoundError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content=_envelope(code="CLIENT_NOT_FOUND", message="Клиент с указанным clientId не найден."),
    )


async def question_not_found_handler(_request: Request, exc: QuestionNotFoundError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content=_envelope(code="QUESTION_NOT_FOUND", message="Вопрос с указанным questionCode не найден."),
    )


async def invalid_answer_type_handler(_request: Request, exc: InvalidAnswerTypeError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(code="INVALID_ANSWER_TYPE", message=str(exc)),
    )


async def question_not_skippable_handler(_request: Request, exc: QuestionNotSkippableError) -> JSONResponse:
    logger.warning("question not skippable", extra={"log_context": {"question_code": exc.question_code}})
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(code="QUESTION_NOT_SKIPPABLE", message="Данный вопрос не может быть пропущен."),
    )


async def invalid_option_code_handler(_request: Request, exc: InvalidOptionCodeError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="INVALID_OPTION_CODE",
            message="Один или несколько переданных optionCodes не принадлежат указанному вопросу.",
        ),
    )


async def catalog_consistency_handler(_request: Request, exc: CatalogConsistencyError) -> JSONResponse:
    """Ответ принять не удалось из-за справочника, а не из-за запроса клиента → 500. Коды вопроса
    и параметра остаются в логе: по ним разбирают, какая строка каталога рассогласована."""
    logger.error(
        "catalog inconsistency: answer was not stored",
        extra={"log_context": {"question_code": exc.question_code, "parameter_code": exc.parameter_code}},
        exc_info=exc,
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=_envelope(
            code="CATALOG_INCONSISTENCY",
            message="Ответ не сохранён: справочник не согласован.",
        ),
    )


# Поднимается обоими доменами (risk_event.answers-reset и risk_communication.выбор системы)
# своими копиями SystemCodeNotFoundError; хендлер не читает поля exc, поэтому типизирован базой.
async def system_code_not_found_handler(
    _request: Request,
    exc: RiskBaseError,
) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content=_envelope(
            code="SYSTEM_CODE_NOT_FOUND",
            message="Система организма с указанным кодом не найдена.",
        ),
    )


async def invalid_event_type_handler(
    _request: Request,
    exc: InvalidEventTypeError,
) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="INVALID_EVENT_TYPE",
            message="Недопустимый тип события. Допустимые значения: risk-calculation, pregnancy-end, answers-reset.",
        ),
    )


async def system_code_required_handler(
    _request: Request,
    exc: SystemCodeRequiredError,
) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="SYSTEM_CODE_REQUIRED",
            message="Параметр systemCode обязателен для события answers-reset.",
        ),
    )


async def missing_required_field_handler(
    _request: Request,
    exc: MissingRequiredFieldError,
) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="MISSING_REQUIRED_FIELD",
            message="Необходимо передать хотя бы один из параметров: heightCm, weightKg, birthDate, gender.",
        ),
    )


async def gender_and_birth_date_required_handler(
    _request: Request,
    exc: GenderAndBirthDateRequiredError,
) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(
            code="GENDER_AND_BIRTH_DATE_REQUIRED",
            message="Для нового клиента необходимо передать birthDate и gender.",
        ),
    )


async def client_gender_not_found_handler(_request: Request, exc: ClientGenderNotFoundError) -> JSONResponse:
    """Общий чек-ап подбирается по полу клиента, а пола нет — подобрать нечего, это 500, а не 404
    по запросу клиента. `reason` разводит случаи «не задавали», «протух» и «вне словаря»;
    само значение уходит под маскируемым ключом — это персональные данные."""
    logger.error(
        "CLIENT_GENDER_NOT_FOUND: client gender parameter is missing, expired or not recognized",
        extra={
            "log_context": {
                "client_id": exc.client_id,
                "reason": exc.reason,
                "gender_value": exc.gender_value,
            }
        },
        exc_info=exc,
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=_envelope(code="CLIENT_GENDER_NOT_FOUND", message="Не удалось определить пол клиента."),
    )


async def examination_category_invalid_handler(request: Request, exc: ExaminationCategoryInvalidError) -> JSONResponse:
    """Категория исследования разошлась с его типом — отдать перечень нельзя. Коды группы и
    исследования остаются в логе: по ним разбирают, какая строка справочника рассогласована.
    clientId берётся из пути, чтобы не тащить его через чистые функции подбора."""
    logger.error(
        "EXAMINATION_CATEGORY_INVALID: examination category does not match the examination type",
        extra={
            "log_context": {
                "client_id": request.path_params.get("clientId"),
                "system_code": exc.system_code,
                "disease_code": exc.disease_code,
                "examination_code": str(exc.examination_code),
                "category": exc.category,
            }
        },
        exc_info=exc,
    )
    return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content=_internal_error_envelope())


common_responses: dict[int | str, dict[str, Any]] = {
    400: {"model": ErrorEnvelope, "description": "Validation failed"},
    404: {"model": ErrorEnvelope, "description": "Not found"},
    409: {"model": ErrorEnvelope, "description": "Conflict"},
    500: {"model": ErrorEnvelope, "description": "Internal error"},
}
