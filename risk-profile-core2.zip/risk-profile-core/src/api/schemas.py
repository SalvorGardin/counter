"""Базовые схемы для API: общая модель и общие константы валидации."""

from typing import Annotated

from fastapi import Query
from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

from src.constants import FULL_COMPLETION_PERCENTAGE, ID_PATTERN

# Пределы длин строковых полей контракта. Одно значение = один смысл: одинаковое число у
# полей разного смысла (например 64 у patientId и у кода инструмента) остаётся двумя разными
# константами, чтобы правка предела одного поля не двигала молча другое.
NON_EMPTY_MIN_LENGTH = 1
# Коды справочников в публичном контракте: systemCode, questionCode, optionCode.
CATALOG_ID_MAX_LENGTH = 36
SYSTEM_CODE_MIN_LENGTH = 2  # seeded-система "GI" — код из двух символов
QUESTION_CODE_MIN_LENGTH = 3
# patientId и коды в тестовом контракте (instrumentCode, parameterCode, source).
PATIENT_ID_MAX_LENGTH = 64
CODE_MAX_LENGTH = 64
# Тексты: название/заголовок, значение ответа, формулировка вопроса, развёрнутое описание.
TITLE_MAX_LENGTH = 100
VALUE_MAX_LENGTH = 255
QUESTION_TEXT_MAX_LENGTH = 500
DESCRIPTION_MAX_LENGTH = 2000
# Envelope ошибки: длины code/message из контракта (см. src.api.errors).
ERROR_CODE_MAX_LENGTH = 100
ERROR_MESSAGE_MAX_LENGTH = 255
# systemPriority = systems.rang: верхняя граница — число систем в справочнике.
SYSTEM_PRIORITY_MAX = 13

# Проценты прохождения опросника: та же шкала, что и у доменных FULL_COMPLETION_PERCENTAGE.
PERCENTAGE_MIN = 0
PERCENTAGE_MAX = FULL_COMPLETION_PERCENTAGE

SystemCodeQuery = Annotated[
    str | None,
    Query(alias="systemCode", min_length=SYSTEM_CODE_MIN_LENGTH, max_length=CATALOG_ID_MAX_LENGTH),
]
QuestionCodeQuery = Annotated[
    str | None,
    Query(
        alias="questionCode",
        min_length=QUESTION_CODE_MIN_LENGTH,
        max_length=CATALOG_ID_MAX_LENGTH,
        pattern=ID_PATTERN,
    ),
]
PatientIdQuery = Annotated[
    str,
    Query(alias="patientId", min_length=NON_EMPTY_MIN_LENGTH, max_length=PATIENT_ID_MAX_LENGTH),
]
OptionCode = Annotated[
    str,
    Field(min_length=NON_EMPTY_MIN_LENGTH, max_length=CATALOG_ID_MAX_LENGTH, pattern=ID_PATTERN),
]
SystemCode = Annotated[str, Field(min_length=SYSTEM_CODE_MIN_LENGTH, max_length=CATALOG_ID_MAX_LENGTH)]
PatientId = Annotated[str, Field(min_length=NON_EMPTY_MIN_LENGTH, max_length=PATIENT_ID_MAX_LENGTH)]
CompletionPercentage = Annotated[int, Field(ge=PERCENTAGE_MIN, le=PERCENTAGE_MAX)]


class CamelModel(BaseModel):
    """Базовая модель API: snake_case в Python, camelCase в JSON, лишние поля запрещены."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        extra="forbid",
    )
