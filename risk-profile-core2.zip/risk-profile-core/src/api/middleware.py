"""ASGI-мидлвари уровня API."""

import time
from collections.abc import Awaitable, Callable
from collections.abc import Set as AbstractSet

from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp, Receive, Scope, Send

from src.metrics import HOSTNAME, HTTP_REQUEST_DURATION

_API_PREFIX = "/api/"

# Лейбл `method` — только этот белый список; остальное схлопывается в "other". Ручка /metrics
# неавторизована, а метод клиент задаёт напрямую: с httptools до middleware долетают ~33 метода,
# с h11 — вообще произвольная строка любой длины. Без cap это бомба кардинальности от анонима.
_ALLOWED_METHODS = frozenset({"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"})
_OTHER_METHOD = "other"
# Литерал для несматченного роута. НИКОГДА не подставляем сырой request.url.path — путь с
# path-параметрами/мусором от анонима раздул бы число рядов неограниченно.
_UNMATCHED_PATH = "unmatched"
# Скрытые роуты (include_in_schema=False, напр. /api/v1/debug/profile) схлопываем сюда: их
# существование не должно утекать через лейбл path неавторизованной ручки /metrics.
_HIDDEN_PATH = "other"


class StripTrailingSlashMiddleware:
    """Снимает хвостовой `/` с путей `/api/*` ДО роутинга, чтобы `/api/v1/.../anthropometry/`
    попадал в тот же хендлер, что и без слеша.

    Без этого FastAPI (redirect_slashes=True по умолчанию) отвечает 307 на абсолютный URL без
    слеша. На POST это ломается: часть клиентов/прокси не повторяет тело на редирект, а за nginx
    в Location уезжает внутренний host:port — тестер видит «упали с 404». Нормализуем прозрачно,
    без редиректа.

    Трогаем только `/api/*`: у статического mount `/questionnaire` хвостовой слеш значим
    (`/questionnaire/` отдаёт index.html), пробы (`/health` и т.п.) — точные пути без параметров,
    корень `/` под префикс не подпадает. После rstrip путь всегда непуст: префикс гарантирует
    как минимум `/api`."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            path: str = scope["path"]
            if path.startswith(_API_PREFIX) and path.endswith("/"):
                scope["path"] = path.rstrip("/")
                # raw_path — оригинальные (percent-encoded) байты пути без query-строки;
                # подрезаем тот же хвост, не перекодируя, чтобы остаться консистентными с path.
                raw_path = scope.get("raw_path")
                if isinstance(raw_path, bytes):
                    scope["raw_path"] = raw_path.rstrip(b"/")
        await self.app(scope, receive, send)


def _path_label(request: Request) -> str:
    """Низкокардинальный лейбл `path` для histogram — только шаблон роута, никогда сырой путь.

    После роутинга Starlette кладёт сматченный роут в `scope["route"]`, а для статического
    mount'а (`/questionnaire`) — не кладёт роут вовсе, но выставляет `scope["root_path"]` в
    префикс маунта. Оба источника низкокардинальны (число роутов конечно), а сырой путь с
    path-параметрами — нет. См. требования безопасности T2 в docs/spec-prometheus-metrics.md.
    """
    route = request.scope.get("route")
    if route is not None:
        # Скрытый роут не раскрываем существованием через неавторизованный /metrics.
        if getattr(route, "include_in_schema", True) is False:
            return _HIDDEN_PATH
        # Route/APIRoute имеют path_format ("/api/v1/testing/patients/{patient_id}").
        return getattr(route, "path_format", "") or _UNMATCHED_PATH
    # Роута в scope нет: либо mount статики (root_path = префикс маунта, напр. "/questionnaire"),
    # либо путь вообще не сматчен (root_path пуст) → "unmatched".
    return request.scope.get("root_path", "") or _UNMATCHED_PATH


def make_metrics_middleware(
    probe_paths: AbstractSet[str],
) -> Callable[[Request, Callable[[Request], Awaitable[Response]]], Awaitable[Response]]:
    """Фабрика HTTP-метрик-миддлвари. `probe_paths` замыкаются здесь, а не импортируются из main
    (иначе цикл main→middleware→main). Регистрируется в main.py ПОСЛЕ логирующей миддлвари, чтобы
    оказаться внешним слоем: duration тогда включает и накладные логирования (буферизацию тел) —
    честная server-side латентность.
    """

    async def metrics_middleware(
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        # Пробы балансировщика и сам скрейп /metrics не наблюдаем (probe_paths включает /metrics).
        if request.url.path in probe_paths:
            return await call_next(request)

        method = request.method if request.method in _ALLOWED_METHODS else _OTHER_METHOD
        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            # Необработанное исключение долетело до внешнего слоя (штатно ExceptionMiddleware —
            # внутри и вернул бы 500-ответ, но внутренние миддлвари могли перебросить): наблюдаем
            # как 500 и пробрасываем. Взаимоисключающе с веткой ниже — двойного счёта нет.
            _observe(method, request, "500", start)
            raise
        _observe(method, request, str(response.status_code), start)
        return response

    return metrics_middleware


def _observe(method: str, request: Request, status: str, start: float) -> None:
    HTTP_REQUEST_DURATION.labels(
        method=method,
        path=_path_label(request),
        status=status,
        host=HOSTNAME,
    ).observe(time.perf_counter() - start)
