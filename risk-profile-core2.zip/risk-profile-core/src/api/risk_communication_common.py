"""Общая логика роутеров risk-communication для v1 и v2.

Обе версии метода `POST /clients/{clientId}/questions/answers` совпадают по контракту запроса/ответа
и по всей обработке — кроме одного поведенческого различия (bug #132): при ответе на последний вопрос
запрошенной системы v1 подбирает следующую систему, а v2 отдаёт завершение именно этой системы. Различие
выражено флагом `complete_on_requested_system_done`, который роутер прокидывает в доменный сервис. Всё
остальное — валидация, DI сервиса, постановка пересчёта в фон — здесь, чтобы версии не расходились молча.
"""

from typing import Annotated

from fastapi import BackgroundTasks, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.v1.risk_communication.schemas import AnswerRequest, AnswerResponse
from src.calc.dispatcher import DispatcherCallable
from src.infra.catalog.http import HttpCatalog
from src.infra.database import get_http_catalog, get_session
from src.logger import with_request_context
from src.services.risk_communication.domain.exceptions import InvalidAnswerTypeError
from src.services.risk_communication.service import RiskCommunicationService


def get_risk_communication_service(
    session: Annotated[AsyncSession, Depends(get_session)],
    catalog: Annotated[HttpCatalog, Depends(get_http_catalog)],
) -> RiskCommunicationService:
    return RiskCommunicationService(session, catalog)


def validate_cross_fields(question_code: str | None, body: AnswerRequest) -> None:
    """Cross-field-валидация: query+body завязаны друг на друга, в pydantic-модели тела не выразить."""
    # is_skipped=False семантически = «не пропускаю» = нет ответа; считаем заполненным только True.
    body_filled = sum(v is not None for v in (body.option_codes, body.answer)) + (1 if body.is_skipped is True else 0)
    if question_code is None:
        if body_filled > 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="body must be empty when questionCode is not provided",
            )
        return
    if body_filled == 0:
        # Контракт Risk-communication: questionCode передан, но ни одного типа ответа → INVALID_ANSWER_TYPE.
        raise InvalidAnswerTypeError(
            "При передаче questionCode необходимо указать один из параметров: optionCodes, answer или isSkipped.",
        )


async def handle_answer(
    *,
    client_id: str,
    body: AnswerRequest,
    background: BackgroundTasks,
    service: RiskCommunicationService,
    dispatcher: DispatcherCallable,
    question_code: str | None,
    system_code: str | None,
    complete_on_requested_system_done: bool,
) -> AnswerResponse:
    """Общее тело обработчика ответа для обеих версий. Различие версий — только в одноимённом флаге."""
    validate_cross_fields(question_code, body)
    response, signal = await service.handle(
        client_id=client_id,
        question_code=question_code,
        system_code=system_code,
        body=body,
        complete_on_requested_system_done=complete_on_requested_system_done,
    )
    if signal.pregnancy_flipped:
        # Flip беременности влияет на applicability всех калькуляторов — полный пересчёт.
        # Не дублируем «частичный» по parameter_codes, т.к. он входит в полный.
        background.add_task(with_request_context(dispatcher), client_id, None)
    elif signal.parameter_codes:
        background.add_task(with_request_context(dispatcher), client_id, set(signal.parameter_codes))
    return response
