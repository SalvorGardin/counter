"""Переиспользуемые FastAPI-зависимости для слоя API."""

import re
from collections.abc import Callable, Coroutine
from typing import Annotated, Any

from fastapi import Depends, HTTPException, Path, Query, Request, status

from src.api.errors import InvalidClientIdError
from src.api.schemas import CATALOG_ID_MAX_LENGTH, SYSTEM_CODE_MIN_LENGTH
from src.constants import CLIENT_ID_MAX_LENGTH, CLIENT_ID_MIN_LENGTH, ID_PATTERN
from src.services.risk_communication.domain.exceptions import SystemCodeNotFoundError

_CLIENT_ID_RE = re.compile(ID_PATTERN)


def validate_client_id(
    client_id: Annotated[
        str,
        Path(
            alias="clientId",
            # Констрейнты только для OpenAPI: pydantic их НЕ применяет (иначе ошибка ушла бы в
            # generic RequestValidationError-хендлер). Реальную проверку делаем ниже и поднимаем
            # InvalidClientIdError → контрактный код INVALID_CLIENT_ID. См. docs-спеку 2026-06-10.
            json_schema_extra={
                "minLength": CLIENT_ID_MIN_LENGTH,
                "maxLength": CLIENT_ID_MAX_LENGTH,
                "pattern": ID_PATTERN,
            },
        ),
    ],
) -> str:
    if not (CLIENT_ID_MIN_LENGTH <= len(client_id) <= CLIENT_ID_MAX_LENGTH) or not _CLIENT_ID_RE.fullmatch(client_id):
        raise InvalidClientIdError
    return client_id


# Общий тип path-параметра clientId для всех роутеров: валидация + контрактная ошибка.
ClientIdPath = Annotated[str, Depends(validate_client_id)]


def validate_system_code_lookup(
    system_code: Annotated[
        str | None,
        Query(
            alias="systemCode",
            # Констрейнты только для OpenAPI: применённые pydantic'ом, они дали бы
            # 400 INVALID_SYSTEMCODE, как у SystemCodeQuery. Реальную проверку делаем ниже.
            json_schema_extra={
                "minLength": SYSTEM_CODE_MIN_LENGTH,
                "maxLength": CATALOG_ID_MAX_LENGTH,
            },
        ),
    ] = None,
) -> str | None:
    """systemCode там, где контракт требует 404 SYSTEM_CODE_NOT_FOUND на любое значение вне
    справочника, включая не прошедшее формат.

    Границы 2–36 проверяются здесь и дают 404, а не 400 INVALID_SYSTEMCODE, как дали бы
    pydantic-ограничения `SystemCodeQuery`. Проверка формата идёт зависимостью, поэтому
    выполняется до поиска клиента — шаг 1 контракта; корректное по формату, но неизвестное
    справочнику значение доходит до сервиса и не находится в каталоге — шаг 3.
    """
    if system_code is not None and not (SYSTEM_CODE_MIN_LENGTH <= len(system_code) <= CATALOG_ID_MAX_LENGTH):
        raise SystemCodeNotFoundError([system_code])
    return system_code


SystemCodeLookupQuery = Annotated[str | None, Depends(validate_system_code_lookup)]


def forbid_extra_query_params(allowed: set[str]) -> Callable[[Request], Coroutine[Any, Any, None]]:
    """Фабрика route-зависимости: 400, если в query есть параметры вне `allowed`.

    FastAPI/Starlette по умолчанию молча игнорируют неизвестные query-параметры — из-за этого
    опечатка в имени (`systemCod` вместо `systemCode`) проходит валидацию «успешно», а реальный
    параметр считается непереданным. Зависимость закрывает границу: любой неожиданный ключ → 400.

    `allowed` — имена параметров как они приходят в query (JSON-алиасы, напр. {"systemCode"}).
    """
    allowed_frozen = frozenset(allowed)

    async def _dependency(request: Request) -> None:
        extra = sorted(set(request.query_params.keys()) - allowed_frozen)
        if extra:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"unexpected query parameters: {', '.join(extra)}",
            )

    return _dependency
