"""Константы без зависимостей от других модулей src.

Модуль хранит значения двух видов.

1. Словари, общие сразу для нескольких доменов: одна сторона пишет значение в БД, другая
   читает его строковым сравнением. Литерал объявлен здесь один раз, а каждый домен даёт ему
   собственное семантическое имя в своём модуле констант и связывает с этим значением —
   бизнес-код домена работает только со своим именем и отсюда ничего не импортирует.
2. Маск-лист логирования — он живёт здесь, а не в logger/config: config зависеть от logger'а
   не должен (инверсия), а logger'у нужен fallback-дефолт на случай невалидного конфига
   (boot-order). Оба импортируют отсюда.
"""

from enum import StrEnum

# Булев ответ опросника: `patients_parameters.value` хранит текст выбранной опции, а не флаг.
# Пишет значение risk-communication (multi-вопрос помечает выбранные/невыбранные опции),
# читают калькуляторы calc/ и подбор врачей interpretation/ — строковым равенством.
ANSWER_YES: str = "Да"
ANSWER_NO: str = "Нет"

# Пол пациента в том виде, в каком он лежит в `patients_parameters.value`. Пишет значение
# risk-init (перекодировка из "male"/"female" контракта API), читают строковым равенством
# калькуляторы calc/ и подбор врачей interpretation/. Смена литерала здесь — смена данных
# в БД, поэтому она обязана сопровождаться миграцией ремапа ответов.
GENDER_MALE: str = "Мужской"
GENDER_FEMALE: str = "Женский"

# Коды параметров каталога (`parameters.code`, lowercase — см. wiki: Справочники/Справочник-
# параметров), которые читает или пишет больше одного домена: демография и антропометрия.
# Коды, живущие внутри одного домена, объявлены в константах этого домена — сюда поднимаются
# только общие, чтобы имя параметра не разъезжалось между доменами.
PARAMETER_CODE_HEIGHT: str = "height"
PARAMETER_CODE_WEIGHT: str = "weight"
PARAMETER_CODE_BIRTHDATE: str = "birthdate"
PARAMETER_CODE_GENDER: str = "gender"
PARAMETER_CODE_AGE: str = "age"
PARAMETER_CODE_BMI: str = "bmi"

# Канонический код единственного инструмента расчёта по клиническим рекомендациям.
BIOMARKER_CLINREC_INSTRUMENT_CODE: str = "biomarker_kr"

# Префикс кодов параметров-биомаркеров (`parameters.code`): значение биомаркера пишется в параметр
# `biomarker_<code>` (см. справочник `biomarkers`).
BIOMARKER_PARAMETER_PREFIX: str = "biomarker_"

# Балл фактора риска в группе заболеваний (`risk_factor_scores.score`), при котором фактор считается
# клинрек-фактором этой группы. Одно значение на весь сервис: расчёт по нему решает, входит ли фактор
# в `n3`, а интерпретация — какими факторами объяснён посчитанный результат. Разойдись эти два места,
# и результат остался бы без объяснения.
CLINREC_FACTOR_SCORE: int = 3

# Ограничения идентификаторов внешних контрактов: паттерн задаёт допустимый алфавит кодов и
# идентификаторов (буквы, цифры, дефисы, подчёркивания), пределы — длину clientId. Значения читают
# оба входа сервиса: HTTP-схемы (src/api/schemas.py, src/api/dependencies.py) и валидация сообщений
# топика emr-biomarkers (src/emr_biomarkers/). Живут здесь, а не в слое API, чтобы Kafka-домен не
# импортировал из src/api/ и оба входа отклоняли один и тот же clientId по одному правилу.
# На HTTP границы clientId проверяются вручную в src.api.dependencies.validate_client_id (а не
# pydantic-констрейнтом), чтобы отдать контрактный код INVALID_CLIENT_ID; те же значения уходят
# в json_schema_extra path-параметра, поэтому OpenAPI остаётся корректным.
ID_PATTERN: str = r"^[A-Za-z0-9_-]+$"
CLIENT_ID_MIN_LENGTH: int = 5
CLIENT_ID_MAX_LENGTH: int = 36

# Заголовки сквозной трассировки. Одно и то же имя ходит по двум транспортам: HTTP (входящий
# запрос, ответ клиенту, вызов downstream) и Kafka (заголовки сообщения пересчёта). Читать
# HTTP-заголовок можно в любом регистре, а ключ заголовка Kafka регистрозначим и зафиксирован
# контракта lowercase — поэтому lowercase-форма выведена из канонической, а не написана заново.
HEADER_REQUEST_ID: str = "X-Request-ID"
HEADER_ENABLE_DEBUG: str = "X-Enable-Debug"
HEADER_AUTHORIZATION: str = "Authorization"

KAFKA_HEADER_REQUEST_ID: str = HEADER_REQUEST_ID.lower()
KAFKA_HEADER_ENABLE_DEBUG: str = HEADER_ENABLE_DEBUG.lower()

# Шкала завершённости опросника в процентах: 100 = полное прохождение. Значение отдают наружу
# и risk-communication (systemCompletionPercentage), и risk-profile (шаги 4/6 wiki).
FULL_COMPLETION_PERCENTAGE: int = 100


class ResultInterpretationStatus(StrEnum):
    """Значения `results.interpretation_status` — что интерпретации ещё предстоит сделать с
    показателем. Пишет их calc (расчёт и заглушки), переводит `ready` → `done` interpretation
    после успешной записи интерпретаций. Словарь общий для двух доменов, а зависеть друг от
    друга они не должны, поэтому живёт здесь.

    Хранится строкой, а не PG-enum: набор пополняется без ALTER TYPE (как risk_level).
    """

    # Показатель рассчитан, интерпретация по нему ещё не выполнена.
    READY = "ready"
    # Заглушка неприменимого инструмента (formula.make_dummy) — интерпретировать нечего.
    NOT_REQUIRED = "not_required"
    # Интерпретация выполнена и записана.
    DONE = "done"


class RiskLevel(StrEnum):
    """Shared `risk_level` vocabulary written by calc and consumed by downstream domains.

    The database deliberately stores these values as VARCHAR rather than a PostgreSQL enum,
    but application code treats the vocabulary as closed.
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# Секреты транспорта: обязаны маскироваться в ЛЮБОМ окружении. Валидатор Settings
# принудительно вливает их в RISK_MODEL_LOG_MASK_KEYS — оператор не может случайно
# включить логирование bearer-токенов, задав env только с PII-ключами.
REQUIRED_LOG_MASK_KEYS: str = "authorization,cookie,set-cookie,x-test-api-key,x-restarter-api-key"

# Прод-безопасный дефолт маск-листа (env RISK_MODEL_LOG_MASK_KEYS, CSV).
# Ключи сравниваются в нормализованной форме: lowercase, без "-" и "_" — так один элемент
# списка ("birthdate") покрывает birthDate/birth_date/Birth-Date в телах и заголовках.
DEFAULT_LOG_MASK_KEYS: str = (
    # ПДн: антропометрия и контакты (исторический список _PII_KEYS). patient_id/client_id
    # в дефолте НЕТ намеренно: хендлеры логируют их в context для трассировки пациента,
    # маскирование в дефолте ослепило бы прод-диагностику. На стендах сужаем/расширяем через env.
    "birthdate,dob,date_of_birth,gender,age,sex,"
    "height,weight,bmi,phone,phone_number,mobile,email,passport,passport_number,"
    "snils,inn,fio,full_name,first_name,last_name,middle_name,patronymic,"
    # wire-ключи тел запросов (camelCase нормализуется в те же формы): антропометрия,
    # ответы опросника, обмен с cvd (riskFactors маскируется целиком как объект)
    "height_cm,weight_kg,answer,option_codes,risk_factors,risk_percentage,score,"
    # Результаты лабораторных исследований из ЭМК в логах разбора топика emr-biomarkers:
    # название биомаркера рядом с client_id — медицинские данные (название качественного
    # биомаркера называет исследуемую инфекцию, значение — её наличие). biomarker_id,
    # biomarker_code, biomarker_unit и biomarker_unit_code остаются открытыми: это коды
    # справочников и подпись единицы, по ним запись трассируется, а чувствительного в них нет.
    # Для диагностики на стенде ключи убирают из RISK_MODEL_LOG_MASK_KEYS — префикс biomarker_
    # не задевает остальные name/value в логах.
    "biomarker_name,biomarker_value,"
    # События подбора исследований: группа заболеваний клиента из interpretations.diseases и
    # значение параметра пола рядом с client_id — тот же класс данных, что и название биомаркера.
    # Ключ `gender` этот случай не покрывает: нормализация (см. `normalize_mask_key`) убирает
    # только "-" и "_", поэтому `gender_value` даёт `gendervalue` и с `gender` не совпадает.
    # Коды системы, интерпретации и исследования, а также причина ошибки остаются открытыми.
    "disease_value,gender_value,"
    # IP клиента — тоже ПДн (152-ФЗ/GDPR)
    "x-forwarded-for,forwarded,x-real-ip," + REQUIRED_LOG_MASK_KEYS
)


def normalize_mask_key(key: str) -> str:
    """Нормализация ключа для сравнения с маск-листом: lowercase, без "-" и "_"."""
    return key.lower().replace("-", "").replace("_", "")
