"""Sink по-шаговых замеров интерпретации.

Отдельный модуль, а не часть `handler.py`: типы нужны и фазе загрузки, и координатору, а также
`src/calc/timings.py` — держать их рядом с хендлером значило бы получить цикл импортов.
"""

from dataclasses import dataclass, field

from src.infra.step_timings import TimingSink


@dataclass
class InterpretationLoadTimings(TimingSink):
    """Разбивка read-фазы `run_for` по отдельным async-читателям, в миллисекундах.

    Меряем только `await`-и к БД. `results` — `get_results_for_systems`, `active_params` —
    `get_active_parameters`; последний выполняется, только когда вызывающий НЕ передал
    `patient_values` (на calc-пути передаёт, и строка стабильно 0). Справочников здесь нет:
    их отдаёт резидентный каталог синхронно, мерить нечего.

    `enabled` — см. `InterpretationTimings.enabled`; проставляется каскадом из `TimingSink.enable`.
    """

    results_ms: float = 0.0
    active_params_ms: float = 0.0


@dataclass
class InterpretationTimings(TimingSink):
    """Sub-step durations of the interpretation pass (milliseconds), accumulated across the
    per-patient `run_for` calls of one calc dispatch.

    Filled only when a sink is passed to `run_for`; prod callers pass nothing (measurement stays
    local and is discarded). Owned by calc's `StepTimings` (see src/calc/timings.py) — calc already
    depends on interpretation, so the dependency direction stays inward. The three fields mirror the
    phases of `run_for` worth measuring: `load` (reader read-phase), `compute` (per-system §4.1-4.3
    loop, in-memory), `upsert` (batched write transaction, or the per-system
    fallback). The `session.commit` between compute and upsert is intentionally unattributed, so the
    three need not sum to calc's `interpretation_ms`.

    Не меряем: построение обратного индекса systems-by-instrument и фазу `mark done`. Первое —
    чистый in-memory проход (0.0мс на всех перцентилях за 8000 команд), второе на штатном (batched)
    пути вообще не выполняется: пометка результатов идёт внутри транзакции пачки и уже учтена в
    `upsert`. Обе строки в отчёте были стабильными нулями и только зашумляли breakdown.

    Сбор целиком за флагом `settings.step_timings_enabled` (по умолчанию выключен): на боевом пути
    не должен исполняться код профилирования — только код расчёта. `enabled` проставляет вызывающий
    (на calc-пути — каскадом из `TimingSink.enable`), а каждая запись идёт через `step()`, который
    при выключенном сборе не пишет и не замеряет. Дефолт `True`: объект, собранный руками,
    представляет уже измеренные данные.
    """

    load_ms: float = 0.0
    compute_ms: float = 0.0
    upsert_ms: float = 0.0
    # Разбивка load_ms по отдельным async-читателям read-фазы (см. InterpretationLoadTimings).
    load: InterpretationLoadTimings = field(default_factory=InterpretationLoadTimings)


# Общий sink для выключенного сбора (см. `_DISABLED_TIMINGS` в src/calc/timings.py): при
# `enabled=False` в него никто не пишет (`step()` отдаёт no-op), поэтому standalone-вызовы
# `run_for` не аллоцируют пару dataclass'ов на пациента.
_DISABLED_TIMINGS = InterpretationTimings()
_DISABLED_TIMINGS.enable(False)
