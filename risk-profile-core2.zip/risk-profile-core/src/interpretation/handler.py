"""Оркестратор interpretation §1-4.3.

Запускается как продолжение процесса калькуляторов в [src/calc/handler.py] после успешного
upsert results. Считает §4.1-4.3 в памяти и сохраняет одну запись на (patient_id, system_code)
в `interpretations` (с архивом в `interpretations_history`).

Сам прогон разложен на три фазы, каждая в своём модуле: чтение (`loading.py`), расчёт
(`computing.py`, синхронный и без обращений к БД) и запись (`persistence.py`). Здесь остаётся
координатор — порядок фаз, граница транзакций и инварианты, которые видны только целиком.
"""

from collections.abc import Collection, Iterable, Mapping
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.patients.dtos import ActiveParameter
from src.infra.step_timings import resolve_sink
from src.interpretation.computing import SystemInterpreter
from src.interpretation.domain.models import SystemInterpretation
from src.interpretation.loading import InterpretationLoader
from src.interpretation.persistence import InterpretationWriter
from src.interpretation.reason_collector import InterpretationReasonCollector
from src.interpretation.timings import _DISABLED_TIMINGS, InterpretationTimings
from src.logger import notice


class InterpretationHandler:
    def __init__(
        self,
        session: AsyncSession,
        *,
        catalog: InterpretationCatalog,
        reason_collector: InterpretationReasonCollector | None = None,
        session_factory: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        self._session = session
        # Диагностический сбор причин. Создаётся всегда: он сам no-op при выключенном флаге,
        # поэтому ни один call-site не проверяет состояние сбора. Своя сессия (не `session`) —
        # запись идёт отдельной транзакцией после коммита интерпретаций. Фабрика приходит сверху:
        # у собственной транзакции обязана быть та же database identity, что у самого расчёта.
        self._reasons = (
            reason_collector if reason_collector is not None else InterpretationReasonCollector(session_factory)
        )
        self._loader = InterpretationLoader(session)
        self._interpreter = SystemInterpreter(catalog, self._reasons)
        self._writer = InterpretationWriter(session)

    async def run_for(
        self,
        patient_id: str,
        system_codes: Iterable[str],
        *,
        patient_parameters: dict[str, ActiveParameter] | None = None,
        excluded_by_instrument: Mapping[str, Collection[str]] | None = None,
        timings: InterpretationTimings | None = None,
    ) -> dict[str, SystemInterpretation]:
        """Вычисляет §4.1-4.3 для каждой системы пациента и сохраняет в `interpretations`.

        Возвращает интерпретации ТОЛЬКО тех систем, которые записаны. По возврату вызывающий
        публикует команду `interpretation` (см. CalcHandler._publish_interpretation), а она —
        обещание потребителю, что данные в `interpretations` лежат: посчитанная, но не записанная
        система в этом обещании означала бы, что потребитель прочитает прошлую интерпретацию или
        не найдёт ничего. Считаются по-прежнему все запрошенные системы — расходится только то,
        что видит вызывающий, и `interpretation.run: complete` печатает оба числа.

        `patient_parameters` — снимок «отвеченных» параметров пациента, если
        вызывающий их уже прочитал. Ровно то, что вернул бы `get_active_parameters`: value
        IS NOT NULL и expiration_date >= now(). Calc передаёт свой снимок (см. CalcHandler._load —
        то же чтение, те же фильтры), экономя round-trip за данными, которые уже в памяти;
        None → читаем сами (интеграционные тесты и прочие вызывающие). Разойтись значения могут
        только на параметрах, истёкших между чтением calc'а и этим вызовом, — интерпретация
        пишется по тем же данным, по которым посчитаны результаты, что скорее корректнее.

        `excluded_by_instrument` — повторы биомаркера, уже исключённые вызывающим из выборок
        инструментов по этому же снимку; инструмента без ключа отсев не коснулся. None → отсев
        считается здесь по `patient_parameters`.

        `timings` — необязательный sink по-шаговых замеров (аккумулируется по вызовам); боевые
        вызывающие не передают. Условия сбора и владение флагом — см. `InterpretationTimings`.
        """
        # Sink'а никто не передал — результат прочитать некому, поэтому общий выключенный объект.
        it = resolve_sink(timings, _DISABLED_TIMINGS)
        systems = sorted(set(system_codes))
        notice("interpretation.run: started", {"patient_id": patient_id, "systems": len(systems)})

        if not systems:
            notice("interpretation.run: complete", {"patient_id": patient_id, "computed_systems": 0})
            return {}

        # Cutoff фиксируется ДО read-фазы: любой `Result.date_time > cutoff` записан параллельным
        # calc уже после нашего снапшота — он не попал в эту интерпретацию, и его статус мы не
        # трогаем. Захват после read был бы небезопасен: за окно read↔mark concurrent calc успел бы
        # обновить запись, а мы пометили бы её `done` без реальной интерпретации. NB: cutoff и
        # `Result.date_time` оба пишутся Python-clock (см. CalcRepository.upsert_results_batch), так
        # что инвариант держится, пока calc и интерпретация живут в одном процессе; для multi-worker
        # деплоя обеим сторонам понадобится DB-clock (`func.now()`).
        results_cutoff = datetime.now(tz=UTC)

        loaded = await self._loader.load(
            patient_id,
            systems,
            patient_parameters=patient_parameters,
            excluded_by_instrument=excluded_by_instrument,
            timings=it,
        )
        with it.step("compute"):
            computed = self._interpreter.interpret(patient_id, loaded)

        # Закрываем read-транзакцию: запись идёт своими транзакциями, а не продолжает чтение.
        await self._session.commit()

        # Буфер причин пациента снимается в любом исходе фазы записи: хендлер живёт весь диспатч и
        # обходит пациентов по одному, а строки, не снятые из-за исключения, записаны уже не будут и
        # копились бы в памяти до конца обхода. `discard_patient` после `flush_patient` — no-op.
        try:
            outcome = await self._writer.persist(
                patient_id,
                computed.plans,
                loaded.systems_by_instrument,
                results_cutoff=results_cutoff,
                timings=it,
            )
            if outcome.batched:
                # Строго после успешного коммита пачки и ВНЕ её транзакции: у диагностики не должно
                # быть способа задержать или откатить `interpretations`. На пути деградации причины
                # не пишем вовсе — частичная картина хуже отсутствующей, проверяющий примет пробел
                # за вывод модели.
                await self._reasons.flush_patient(patient_id)
        finally:
            self._reasons.discard_patient(patient_id)

        persisted = {
            system_code: interpretation
            for system_code, interpretation in computed.interpretations.items()
            if system_code in outcome.succeeded_systems
        }
        notice(
            "interpretation.run: complete",
            {
                "patient_id": patient_id,
                "computed_systems": len(computed.interpretations),
                "persisted": len(persisted),
            },
        )
        return persisted
