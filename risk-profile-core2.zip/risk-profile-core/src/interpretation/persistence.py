"""Write-фаза интерпретации: пачка, деградация на посистемную запись, пометка результатов."""

from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.constants import BIOMARKER_CLINREC_INSTRUMENT_CODE
from src.infra.db_retry import TransactionalRetryExecutor, tolerate_retriable_db_error
from src.interpretation.domain.models import SystemPlan
from src.interpretation.infra.repository import InterpretationRepository
from src.interpretation.timings import InterpretationTimings
from src.logger import logger


@dataclass(frozen=True, slots=True)
class PersistOutcome:
    """Исход фазы записи.

    `batched=False` означает, что пачка откатилась и прогон писал системы по одной. Вызывающему
    этот факт нужен не ради статистики: по нему принимается решение о записи диагностических
    причин — частичная картина причин хуже отсутствующей.
    """

    batched: bool
    succeeded_systems: set[str]


class InterpretationWriter:
    """Пишет интерпретации пациента и помечает участвовавшие результаты."""

    def __init__(self, session: AsyncSession) -> None:
        self._repo = InterpretationRepository(session)
        self._executor = TransactionalRetryExecutor(session)

    async def persist(
        self,
        patient_id: str,
        plans: list[SystemPlan],
        systems_by_instrument: dict[str, set[str]],
        *,
        results_cutoff: datetime,
        timings: InterpretationTimings,
    ) -> PersistOutcome:
        """Пишет ВСЮ пачку систем ОДНОЙ транзакцией (history + upsert + пометка результатов).

        Прежняя схема «транзакция на систему» стоила ~2мс на систему при ~0.5мс собственно
        запросов — на 13 системах пациента это 26мс из 34мс всей интерпретации (замер:
        playground/_diag_upsert.py). Партиальная устойчивость сохранена деградацией: если пачка
        не прошла, идём по системам по одной, как раньше.

        Пометка `done` в шаг замеров `upsert` НЕ входит: на штатном пути её делает сама пачка и
        она уже учтена, а на пути деградации это отдельная транзакция за границей шага.
        """
        with timings.step("upsert"):
            now = datetime.now(tz=UTC)
            # Пачка коммитится целиком, поэтому в успешном случае у КАЖДОГО инструмента прогона все
            # участвующие системы сохранены — subset-условие пометки выполняется тривиально, и её
            # можно делать в той же транзакции. На пути деградации список сужается по факту.
            all_instruments = list(systems_by_instrument)
            # Пометка по группам заболеваний нужна только системам, у которых в этом прогоне
            # действительно есть строки клинрек-расчёта: снимок собран из тех же строк, что и
            # помечаются, поэтому у остальных систем UPDATE заведомо не нашёл бы ничего и стоил
            # бы лишнего round trip на каждом пациенте.
            biomarker_systems = systems_by_instrument.get(BIOMARKER_CLINREC_INSTRUMENT_CODE, set())
            # Деградация осмысленна только для транзиентного сбоя: перманентный (NonRetriable)
            # повторится и посистемно, поэтому он проходит наружу и обрывает прогон пациента.
            with tolerate_retriable_db_error(
                "interpretation.upsert_batch: failed, falling back to per-system writes",
                patient_id=patient_id,
                systems=len(plans),
            ) as batch:
                await self._executor.run(
                    self._repo.upsert_interpretations_batch,
                    patient_id=patient_id,
                    plans=plans,
                    date_time=now,
                    instrument_codes=all_instruments,
                    system_codes=[plan.system_code for plan in plans if plan.system_code in biomarker_systems],
                    results_cutoff=results_cutoff,
                )
            if not batch.failed:
                return PersistOutcome(batched=True, succeeded_systems={plan.system_code for plan in plans})
            # Пачка откатилась целиком (ни интерпретаций, ни `done`) — идём на прежний посистемный
            # путь: одна битая система не должна блокировать остальные.
            succeeded_systems = await self._upsert_per_system(patient_id, plans, now)

        # Пометка `done` — только на пути деградации: в успешной пачке результаты уже помечены в её
        # же транзакции. Помечаем инструменты, у которых ВСЕ участвующие в этом прогоне системы
        # попали в `succeeded_systems`. Инструмент, чья хотя бы одна система упала, остаётся в
        # `ready` — следующий прогон интерпретации перезапишет интерпретацию упавшей системы и тогда
        # пометит результат `done`. `syss` уже ограничен системами прогона по построению (см.
        # фазу загрузки), так что достаточно проверить subset-отношение.
        instruments_to_mark = [
            instrument_code for instrument_code, syss in systems_by_instrument.items() if syss <= succeeded_systems
        ]
        await self._mark_results_done(
            patient_id, instruments_to_mark, sorted(succeeded_systems & biomarker_systems), results_cutoff
        )
        return PersistOutcome(batched=False, succeeded_systems=succeeded_systems)

    async def _mark_both(
        self,
        *,
        patient_id: str,
        instrument_codes: list[str],
        system_codes: list[str],
        results_cutoff: datetime,
    ) -> None:
        """Обе пометки одной транзакцией ретрая: повтор не должен закрывать половину строк."""
        await self._repo.mark_results_done(
            patient_id=patient_id, instrument_codes=instrument_codes, results_cutoff=results_cutoff
        )
        await self._repo.mark_biomarker_results_done(
            patient_id=patient_id, system_codes=system_codes, results_cutoff=results_cutoff
        )

    async def _upsert_per_system(self, patient_id: str, plans: list[SystemPlan], date_time: datetime) -> set[str]:
        """Деградация после отката пачки: своя транзакция на систему, как было до батчинга.

        Возвращает коды систем, которые реально сохранились: транзиентное падение одной не
        блокирует остальные (поведение симметрично CalcHandler.run). Перманентный сбой обрывает
        обход — повторять его на каждой оставшейся системе бессмысленно.
        """
        succeeded: set[str] = set()
        for plan in plans:
            with tolerate_retriable_db_error(
                "interpretation.system: upsert failed",
                patient_id=patient_id,
                system_code=plan.system_code,
            ) as attempt:
                await self._executor.run(
                    self._repo.upsert_interpretation,
                    patient_id=patient_id,
                    system_code=plan.system_code,
                    risk_level=plan.risk_level,
                    diseases=plan.diseases,
                    risk_factors_code=plan.risk_factors_code,
                    doctors_code=plan.doctors_code,
                    date_time=date_time,
                )
            if not attempt.failed:
                succeeded.add(plan.system_code)
        return succeeded

    async def _mark_results_done(
        self,
        patient_id: str,
        instrument_codes: list[str],
        system_codes: list[str],
        results_cutoff: datetime,
    ) -> None:
        """Отдельная транзакция пометки `done` — путь деградации (в пачке это делает сам батч).

        Два отбора вместо одного: обычные инструменты помечаются по коду инструмента (и только
        те, у которых записались ВСЕ участвующие системы), строки по группам заболеваний — по
        системе группы. Упавшая система остаётся `ready` в обоих отборах и будет помечена
        следующим прогоном.
        """
        if not instrument_codes and not system_codes:
            return
        logger.debug(
            "interpretation.mark_results_done: marking",
            extra={
                "log_context": {
                    "patient_id": patient_id,
                    "instrument_codes": instrument_codes,
                    "system_codes": system_codes,
                    "results_cutoff": results_cutoff.isoformat(),
                }
            },
        )
        # Транзиентный сбой (deadlock, connection drop) не страшен: результаты остаются `ready`,
        # следующий прогон интерпретации попытается пометить снова.
        with tolerate_retriable_db_error(
            "interpretation.mark_results_done: failed",
            patient_id=patient_id,
            instrument_count=len(instrument_codes),
            system_count=len(system_codes),
        ):
            await self._executor.run(
                self._mark_both,
                patient_id=patient_id,
                instrument_codes=instrument_codes,
                system_codes=system_codes,
                results_cutoff=results_cutoff,
            )
