"""Сбор причин интерпретации — единственная точка записи в `interpretation_statuses`
и `risk_factor_matches`.

Отвечает на вопрос «почему по системе пуст этот результат» и «откуда взялся этот фактор риска».
Механика — та же, что у сбора статусов расчёта (`src/calc/status_collector.py`), и по тем же
причинам:

* **Флаг проверяется здесь, а не на call-site'ах.** `InterpretationHandler` вызывает коллектор
  безусловно; при выключенном сборе каждый метод — no-op: ни сессии, ни буфера в памяти. Так
  состояние флага физически не может протечь в ветвление интерпретации. Флаг общий с расчётом
  (`settings.calc_status_collection_enabled`) — стенд включает сбор целиком.
* **Запись — отдельной транзакцией, после коммита интерпретаций.** У диагностики нет способа
  задержать или откатить `interpretations` и пометку результатов `done`.

Отличие от сбора статусов расчёта одно: `risk_factor_matches` перед вставкой чистится по
системам этого прогона. Строки прошлого прогона не перекрываются upsert'ом — фактор мог
перестать срабатывать, и его строка осталась бы висеть как «сработал», противореча профилю.
"""

from collections.abc import Iterable, Sequence
from datetime import UTC, datetime

from sqlalchemy import bindparam, delete
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.config import settings
from src.infra.database import get_primary_runtime
from src.infra.isolated_write import run_isolated
from src.infra.sql import any_of_param
from src.interpretation.domain.models import InterpretationReasonCode, Reasoned, RiskFactorMatch
from src.models.interpretation_status import InterpretationStatus
from src.models.risk_factor_match import RiskFactorMatch as RiskFactorMatchRow

# Стейтменты собираются ОДИН раз на модуль и переиспользуются с executemany-параметрами — так они
# попадают в compiled-кэш SQLAlchemy (тот же приём, что у `_UPSERT_RESULT` в
# `src/calc/infra/repository.py`).
# `__table__` типизирован как FromClause, хотя в рантайме это Table (ограничение стабов SQLAlchemy).
_insert_status = insert(InterpretationStatus.__table__)  # ty: ignore[invalid-argument-type]
_UPSERT_INTERPRETATION_STATUS = _insert_status.on_conflict_do_update(
    constraint="uq_interpretation_statuses_patient_id_system_code",
    # `excluded.*`, а не литералы строки: иначе стейтмент зависел бы от данных и не
    # переиспользовался бы на всю пачку. Ключ конфликта в set_ не входит.
    set_={
        "risk_level_status": _insert_status.excluded.risk_level_status,
        "risk_level_reason_code": _insert_status.excluded.risk_level_reason_code,
        "diseases_status": _insert_status.excluded.diseases_status,
        "diseases_reason_code": _insert_status.excluded.diseases_reason_code,
        "risk_factors_status": _insert_status.excluded.risk_factors_status,
        "risk_factors_reason_code": _insert_status.excluded.risk_factors_reason_code,
        "doctors_status": _insert_status.excluded.doctors_status,
        "doctors_reason_code": _insert_status.excluded.doctors_reason_code,
        "blocking_instrument_codes": _insert_status.excluded.blocking_instrument_codes,
        "date_time": _insert_status.excluded.date_time,
    },
)

_INSERT_RISK_FACTOR_MATCH = insert(RiskFactorMatchRow.__table__)  # ty: ignore[invalid-argument-type]

# Чистка перед вставкой: по системам этого прогона, одним запросом на пациента. Тот же стейтмент
# переиспользует `delete_for_systems` — там это чистка не «перед вставкой», а насовсем, но условие
# отбора строк ровно то же: пациент × системы.
_DELETE_RISK_FACTOR_MATCHES = delete(RiskFactorMatchRow).where(
    RiskFactorMatchRow.patient_id == bindparam("target_patient_id"),
    any_of_param(RiskFactorMatchRow.system_code, "target_system_codes"),
)

_DELETE_INTERPRETATION_STATUSES = delete(InterpretationStatus).where(
    InterpretationStatus.patient_id == bindparam("target_patient_id"),
    any_of_param(InterpretationStatus.system_code, "target_system_codes"),
)


class InterpretationReasonCollector:
    """Буфер причин текущего пациента плюс запись их одной отдельной транзакцией.

    Живёт один прогон интерпретации. Буфер — на пациента: `flush_patient` записывает и очищает
    его, поэтому память не растёт по мере обхода пациентов.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession] | None = None) -> None:
        self._session_factory = (
            session_factory if session_factory is not None else get_primary_runtime().session_factory
        )
        self._statuses: dict[tuple[str, str], dict[str, object]] = {}
        self._matches: dict[tuple[str, str, str], dict[str, object]] = {}

    @property
    def enabled(self) -> bool:
        return settings.calc_status_collection_enabled

    def record_system(
        self,
        patient_id: str,
        system_code: str,
        *,
        risk_level: Reasoned[str | None],
        diseases: Reasoned[list[str] | None],
        risk_factors: Reasoned[list[str] | None],
        doctors: Reasoned[list[str] | None],
        matches: Sequence[RiskFactorMatch] = (),
    ) -> None:
        """Запомнить причины по системе и сработавшие факторы.

        Причины приходят готовыми из домена — коллектор их НЕ перевычисляет: иначе правило
        «почему пусто» существовало бы в двух экземплярах и разошлось бы при первой правке.
        """
        if not self.enabled:
            return
        self._statuses[(patient_id, system_code)] = {
            "patient_id": patient_id,
            "system_code": system_code,
            "risk_level_status": risk_level.status.value,
            "risk_level_reason_code": _reason(risk_level.reason_code),
            "diseases_status": diseases.status.value,
            "diseases_reason_code": _reason(diseases.reason_code),
            "risk_factors_status": risk_factors.status.value,
            "risk_factors_reason_code": _reason(risk_factors.reason_code),
            "doctors_status": doctors.status.value,
            "doctors_reason_code": _reason(doctors.reason_code),
            # Заболевания другими инструментами больше не обнуляются, деталь выставлять нечем. Колонка
            # остаётся ради строк, записанных раньше: запись NULL снимает устаревшую деталь при
            # перезаписи статуса системы.
            "blocking_instrument_codes": None,
        }
        for match in matches:
            factor = match.factor
            self._matches[(patient_id, system_code, factor.trigger_code)] = {
                "patient_id": patient_id,
                "system_code": system_code,
                "trigger_code": factor.trigger_code,
                "risk_factor_code": factor.code,
                "factor_description": factor.description,
                "reasoning": factor.reasoning,
                "parameter_code": factor.parameter_code,
                "value_type": factor.value_type,
                "operator": factor.operator,
                "value_num": factor.value_num,
                "min_value": factor.min_value,
                "max_value": factor.max_value,
                "value_text": factor.value_text,
                "gender": factor.gender,
                "modifiability": factor.modifiability,
                "is_representative": match.is_representative,
            }

    def pending(
        self,
    ) -> tuple[dict[tuple[str, str], dict[str, object]], dict[tuple[str, str, str], dict[str, object]]]:
        """Накопленное, но ещё не записанное: статусы систем и сработавшие факторы.

        Только для чтения (тесты, диагностика): интерпретация этим представлением не пользуется.
        """
        return dict(self._statuses), dict(self._matches)

    def discard_patient(self, patient_id: str) -> None:
        """Забыть накопленное по пациенту, не записывая (пачка интерпретаций откатилась)."""
        for key in [key for key in self._statuses if key[0] == patient_id]:
            del self._statuses[key]
        for match_key in [key for key in self._matches if key[0] == patient_id]:
            del self._matches[match_key]

    async def flush_patient(self, patient_id: str) -> None:
        """Записать причины пациента отдельной транзакцией на собственной сессии.

        Вызывается ПОСЛЕ успешного сохранения пачки интерпретаций и вне её транзакции. Любой сбой
        записи гасится здесь: диагностика не влияет на исход интерпретации.
        """
        if not self.enabled:
            self.discard_patient(patient_id)
            return

        statuses = [row for key, row in self._statuses.items() if key[0] == patient_id]
        matches = [row for key, row in self._matches.items() if key[0] == patient_id]
        self.discard_patient(patient_id)
        if not statuses:
            return

        now = datetime.now(tz=UTC)
        for row in statuses:
            row["date_time"] = now
        for row in matches:
            row["date_time"] = now
        system_codes = [str(row["system_code"]) for row in statuses]

        async def write(session: AsyncSession) -> None:
            await session.execute(_UPSERT_INTERPRETATION_STATUS, statuses)
            # Чистим по всем системам прогона, включая те, где не сработало ничего: иначе
            # факторы прошлого прогона пережили бы систему, в которой их больше нет.
            await session.execute(
                _DELETE_RISK_FACTOR_MATCHES,
                {"target_patient_id": patient_id, "target_system_codes": system_codes},
            )
            if matches:
                await session.execute(_INSERT_RISK_FACTOR_MATCH, matches)

        await run_isolated(
            self._session_factory,
            write,
            failure_message="interpretation.reason_collector: write failed, reasons for this patient are lost",
            failure_log_context={
                "patient_id": patient_id,
                "system_count": len(statuses),
                "match_count": len(matches),
            },
        )

    async def delete_for_systems(self, patient_id: str, system_codes: Iterable[str]) -> None:
        """Удаляет статусы и сработавшие факторы по системам, чьи `interpretations` снесены
        вне прогона интерпретации.

        Вызывается из risk-event (answers-reset/pregnancy-end) ПОСЛЕ коммита удаления
        `interpretations`: строки диагностики не переживают исчезновение того, что они объясняют
        (то же решение и по той же причине, что у `CalcStatusCollector.delete_for_instruments`).
        Иначе `interpretation_statuses` продолжает утверждать `computed`, а `risk_factor_matches` —
        полный список сработавших факторов для системы, у которой интерпретации уже нет вовсе;
        сверка по `date_time` тут не спасает, потому что сравнивать не с чем. Пересчёт после сброса
        полный, но переписать эти строки он обязан не всегда: интерпретация идёт только по системам
        тех инструментов, по которым пересчёт записал результат, а инструмент, оставшийся без
        актуальных ответов и без прежнего результата, не даёт ни того, ни другого, — так что ждать
        перезаписи строк через `flush_patient` нельзя.

        Своя сессия, как у `flush_patient`: сброс ответов не должен упасть из-за диагностики.
        Следующая интерпретация по системе восстановит строки с нуля.
        """
        if not self.enabled:
            return
        codes = list(system_codes)
        if not codes:
            return
        params = {"target_patient_id": patient_id, "target_system_codes": codes}

        async def purge(session: AsyncSession) -> None:
            # Факторы удаляются вместе со статусами и в одной транзакции: строка `risk_factor_matches`
            # без своего статуса — та же осиротевшая диагностика, только на уровень ниже.
            await session.execute(_DELETE_INTERPRETATION_STATUSES, params)
            await session.execute(_DELETE_RISK_FACTOR_MATCHES, params)

        await run_isolated(
            self._session_factory,
            purge,
            failure_message="interpretation.reason_collector: delete failed, stale reasons were not cleared",
            failure_log_context={"patient_id": patient_id, "system_codes": codes},
        )


def _reason(reason_code: InterpretationReasonCode | None) -> str | None:
    return reason_code.value if reason_code is not None else None
