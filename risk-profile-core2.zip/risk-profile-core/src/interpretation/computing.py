"""Расчётная фаза интерпретации §4.1-4.4 — чистая, без обращений к БД.

Все данные пациента уже прочитаны фазой загрузки, все справочники отдаёт резидентный каталог
синхронно. Поэтому фаза синхронна и проверяется модульными тестами без базы.
"""

from collections.abc import Collection, Mapping
from dataclasses import dataclass

from src.constants import BIOMARKER_CLINREC_INSTRUMENT_CODE
from src.domain.biomarker_duplicates import instrument_parameter_values
from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.patients.dtos import ActiveParameter
from src.interpretation.domain.clinrec_factors import applicable_clinrec_disease_codes, select_clinrec_factors
from src.interpretation.domain.constants import GENDER_PARAMETER_CODE, MEDIUM_HIGH_LEVELS
from src.interpretation.domain.diseases import InstrumentDiseaseResolver
from src.interpretation.domain.doctors import resolve_doctors_code
from src.interpretation.domain.models import (
    InterpretationReasonCode,
    Reasoned,
    RiskFactorRanked,
    RiskFactorSelection,
    SystemInterpretation,
    SystemPlan,
)
from src.interpretation.domain.risk_factors import select_by_code, select_scored_factors, sort_ranked_factors
from src.interpretation.domain.risk_level import aggregate_risk_level
from src.interpretation.loading import LoadedInterpretationData
from src.interpretation.reason_collector import InterpretationReasonCollector
from src.logger import logger

# Гейт по уровню риска не пройден — блок отбора факторов не выполнялся вовсе. Общие неизменяемые
# объекты: у системы вне medium/high ни кандидатов, ни совпадений нет по построению, и
# аллоцировать на каждую такую систему пустой набор незачем.
_NO_RISK_FACTORS = RiskFactorSelection(codes=None, matches=())
_RISK_FACTORS_GATED: Reasoned[list[str] | None] = Reasoned(None, InterpretationReasonCode.RISK_LEVEL_NOT_MEDIUM_HIGH)


def _risk_factors_reason(selection: RiskFactorSelection, *, has_candidates: bool) -> Reasoned[list[str] | None]:
    """Причина пустого списка факторов у системы, для которой отбор ВЫПОЛНЯЛСЯ.

    Различает «в справочнике нет кандидатов по параметрам системы» и «кандидаты были, но ни один
    не сработал на ответах пациента»: для проверяющего это разные дефекты — пробел в справочнике
    против несовпадения условия.
    """
    if selection.codes is not None:
        return Reasoned(selection.codes)
    if not has_candidates:
        return Reasoned(None, InterpretationReasonCode.NO_CANDIDATES)
    return Reasoned(None, InterpretationReasonCode.NO_CANDIDATE_MATCHED)


@dataclass(frozen=True, slots=True)
class SystemRiskFactors:
    """Итог блока §4.3 по одной системе: что запомнить в памяти, что записать, чем объяснить пустоту.

    `clinrec_disease_codes` — группы заболеваний, за которые отвечают отобранные клинрек-факторы.
    Пара «группа × её факторы» держится до конца расчёта системы: группа попадает в заболевания
    только вместе со своим фактором (wiki «Интерпретация» §4.2.1, шаг 2).
    """

    ranked: list[RiskFactorRanked]
    selection: RiskFactorSelection
    reasoned: Reasoned[list[str] | None]
    clinrec_disease_codes: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ComputedSystems:
    """Результат расчётной фазы: что вернуть вызывающему и что отдать на запись."""

    interpretations: dict[str, SystemInterpretation]
    plans: list[SystemPlan]


class SystemInterpreter:
    """Считает §4.1-4.4 по каждой системе прогона и фиксирует причины пустых результатов."""

    def __init__(self, catalog: InterpretationCatalog, reasons: InterpretationReasonCollector) -> None:
        self._catalog = catalog
        self._reasons = reasons
        self._diseases = InstrumentDiseaseResolver(catalog.disease_codes_by_system_instrument)

    def interpret(self, patient_id: str, loaded: LoadedInterpretationData) -> ComputedSystems:
        interpretations: dict[str, SystemInterpretation] = {}
        plans: list[SystemPlan] = []
        for system_code in loaded.systems:
            interpretation, plan = self._interpret_system(patient_id, system_code, loaded)
            interpretations[system_code] = interpretation
            plans.append(plan)
        return ComputedSystems(interpretations=interpretations, plans=plans)

    def _interpret_system(
        self, patient_id: str, system_code: str, loaded: LoadedInterpretationData
    ) -> tuple[SystemInterpretation, SystemPlan]:
        results = loaded.results_by_system.get(system_code, [])
        # Строки клинрек-расчёта отделяются от остальных один раз, здесь. Они дают системе высокий
        # риск наравне с прочими (§4.1), но заболевания приносят свои собственные, поэтому в
        # определение групп по разметке инструментов (§4.2) не передаются, а служат входом второго
        # блока факторов (§4.3, шаг 1б) и источником заболеваний, который сливается с итогом первого.
        grouped_rows = [row for row in results if row.instrument_code != BIOMARKER_CLINREC_INSTRUMENT_CODE]
        applicable_disease_codes = applicable_clinrec_disease_codes(results)
        # Доменные функции отдают значение вместе с причиной пустоты; распаковываем ЗДЕСЬ, на
        # месте вызова. Объект с причиной дальше по пути записи не идёт: он всегда истинен, а ниже
        # стоят проверки на истинность, схлопывающие пустой список в отсутствующее значение.
        risk_level_reasoned = aggregate_risk_level(results)
        risk_level = risk_level_reasoned.value
        diseases_reasoned = self._diseases.resolve(system_code, grouped_rows)
        diseases = diseases_reasoned.value

        factors = self._select_risk_factors(
            system_code,
            risk_level,
            loaded.patient_parameters,
            loaded.excluded_by_instrument,
            loaded.gender,
            applicable_disease_codes,
        )
        # Заболевания системы — объединение двух независимых источников: группы, подтверждённые
        # калькуляторами и опросниками по их разметке, и группы клинрек-расчёта. Причина пустоты остаётся от первого
        # источника: она объясняет именно его, а второй источник её не отменяет, а дополняет.
        diseases = _merge_diseases(diseases, list(factors.clinrec_disease_codes))
        if diseases:
            diseases_reasoned = Reasoned(diseases)

        doctors_reasoned = resolve_doctors_code(
            system_code=system_code,
            risk_level=risk_level,
            gender=loaded.gender,
            patient_values=loaded.patient_values,
            recommended_by_system_level=self._catalog.recommended_doctors_by_system_level,
        )

        # Коллектор вызывается безусловно: состояние флага он проверяет сам, поэтому на пути
        # интерпретации ветвления по сбору нет.
        self._reasons.record_system(
            patient_id,
            system_code,
            risk_level=risk_level_reasoned,
            diseases=diseases_reasoned,
            risk_factors=factors.reasoned,
            doctors=doctors_reasoned,
            matches=factors.selection.matches,
        )

        logger.debug(
            "interpretation.system: computed",
            extra={
                "log_context": {
                    "system_code": system_code,
                    "risk_level": risk_level,
                    "diseases_count": len(diseases) if diseases else 0,
                    "risk_factors_count": len(factors.ranked),
                    "results_count": len(results),
                }
            },
        )

        interpretation = SystemInterpretation(
            system_code=system_code,
            risk_level=risk_level,
            diseases=diseases,
            risk_factors=factors.ranked,
        )
        plan = SystemPlan(
            system_code=system_code,
            risk_level=risk_level,
            diseases=diseases,
            # Дедуп по code вынесен в `select_by_code`: правило выбора представителя прежнее
            # (первый по рангу), но вытесненные строки теперь не исчезают.
            risk_factors_code=factors.selection.codes,
            doctors_code=doctors_reasoned.value,
        )
        return interpretation, plan

    def _select_risk_factors(
        self,
        system_code: str,
        risk_level: str | None,
        patient_parameters: dict[str, ActiveParameter],
        excluded_by_instrument: Mapping[str, Collection[str]] | None,
        gender: str | None,
        applicable_disease_codes: tuple[str, ...],
    ) -> SystemRiskFactors:
        """§4.3 за гейтом по уровню риска: ниже medium отбор не выполняется вовсе.

        Источников два, и они идут подряд: сначала факторы опросников и калькуляторов, затем
        клинрек-факторы биомаркеров. Дедупликацию по коду делает `select_by_code` уже над
        соединённой последовательностью, поэтому фактор, попавший в оба блока, остаётся на своей
        позиции в первом.
        """
        if risk_level not in MEDIUM_HIGH_LEVELS:
            return SystemRiskFactors(ranked=[], selection=_NO_RISK_FACTORS, reasoned=_RISK_FACTORS_GATED)

        catalog = self._catalog

        def instrument_values(instrument_code: str) -> dict[str, str]:
            # Отсев, посчитанный расчётом по тому же снимку, берётся готовым; иначе считается здесь.
            excluded: Collection[str]
            if excluded_by_instrument is not None:
                excluded = excluded_by_instrument.get(instrument_code, ())
            else:
                excluded = catalog.excluded_biomarker_parameter_codes(patient_parameters.values(), instrument_code)
            instrument_params = catalog.parameter_codes_by_instrument.get(instrument_code, frozenset())
            return instrument_parameter_values(patient_parameters, instrument_params, excluded)

        has_scored_candidates = False
        scored_ranked: dict[str, RiskFactorRanked] = {}
        for instrument_code in self._catalog.instrument_codes_by_system.get(system_code, ()):
            instrument_params = self._catalog.parameter_codes_by_instrument.get(instrument_code, frozenset())
            values = instrument_values(instrument_code)
            if gender is not None:
                values[GENDER_PARAMETER_CODE] = gender
            scored = select_scored_factors(
                system_candidates=self._catalog.risk_factors_for(system_code, instrument_params),
                score_rows=self._catalog.score_rows_for(system_code, instrument_params),
                patient_params=values,
            )
            has_scored_candidates = has_scored_candidates or bool(scored.candidates)
            scored_ranked.update((row.trigger_code, row) for row in scored.ranked)
        ranked = list(scored_ranked.values())
        sort_ranked_factors(ranked)

        clinrec_values = instrument_values(BIOMARKER_CLINREC_INSTRUMENT_CODE)
        clinrec = select_clinrec_factors(
            candidates_by_disease={
                disease_code: self._catalog.clinrec_factors_for(system_code, disease_code)
                for disease_code in applicable_disease_codes
            },
            patient_params=clinrec_values,
            gender=gender,
        )
        combined = ranked + clinrec.factors
        selection = select_by_code(combined)
        return SystemRiskFactors(
            ranked=combined,
            selection=selection,
            reasoned=_risk_factors_reason(
                selection, has_candidates=has_scored_candidates or bool(applicable_disease_codes)
            ),
            clinrec_disease_codes=clinrec.disease_codes,
        )


def _merge_diseases(system_diseases: list[str] | None, clinrec_diseases: list[str]) -> list[str] | None:
    """Объединение кодов заболеваний двух источников без дублей, с сохранением порядка первого.

    Оба источника оперируют `diseases.code`, поэтому дедупликация идёт по коду напрямую, без
    разворачивания в название: название собирается на чтении, на границе ответа.

    Пустой итог схлопывается в отсутствующее значение — так же, как у каждого из источников по
    отдельности: разница между «заболеваний нет» и «блока заболеваний нет» доходит до контракта API.
    """
    merged = list(dict.fromkeys((system_diseases or []) + clinrec_diseases))
    return merged or None
