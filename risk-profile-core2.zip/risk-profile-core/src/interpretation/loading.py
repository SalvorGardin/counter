"""Read-фаза интерпретации: всё, что стоило обращения к БД.

Справочники сюда не попадают — их отдаёт резидентный каталог синхронно, и потребитель
(`SystemInterpreter`) берёт их сам. Здесь только данные пациента и выведенный из них индекс.
"""

from collections.abc import Collection, Mapping
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from src.infra.patients.dtos import ActiveParameter
from src.infra.patients.reader import PatientsReader
from src.interpretation.domain.constants import GENDER_PARAMETER_CODE
from src.interpretation.domain.models import ResultRow
from src.interpretation.infra.reader import InterpretationReader
from src.interpretation.timings import InterpretationTimings


@dataclass(frozen=True, slots=True)
class LoadedInterpretationData:
    """Снимок данных пациента для одного прогона интерпретации.

    `systems_by_instrument` — обратный индекс: один инструмент может участвовать в нескольких
    системах прогона (например, findrisk_t участвует и в ENDO, и в CARDIO). Нужен фазе записи —
    пометить `done` только те инструменты, у которых ВСЕ участвующие системы сохранились. Строится
    здесь, потому что выводится целиком из `results_by_system`.

    `excluded_by_instrument` — отсев повторов биомаркера, посчитанный вызывающим по тому же снимку;
    None — отсев считается при отборе факторов.
    """

    systems: tuple[str, ...]
    results_by_system: dict[str, list[ResultRow]]
    patient_parameters: dict[str, ActiveParameter]
    patient_values: dict[str, str]
    gender: str | None
    systems_by_instrument: dict[str, set[str]]
    excluded_by_instrument: Mapping[str, Collection[str]] | None = None


class InterpretationLoader:
    """Читает результаты пациента и, при необходимости, его активные параметры."""

    def __init__(self, session: AsyncSession) -> None:
        self._reader = InterpretationReader(session)
        self._patients_reader = PatientsReader(session)

    async def load(
        self,
        patient_id: str,
        systems: list[str],
        *,
        patient_parameters: dict[str, ActiveParameter] | None,
        excluded_by_instrument: Mapping[str, Collection[str]] | None = None,
        timings: InterpretationTimings,
    ) -> LoadedInterpretationData:
        """Собирает снимок под расчёт. Открывает собственный шаг замеров `load` и его под-шаги."""
        with timings.step("load"):
            with timings.load.step("results"):
                results_by_system = await self._reader.get_results_for_systems(patient_id, systems)

            with timings.load.step("active_params"):
                if patient_parameters is None:
                    patient_parameters = await self._patients_reader.get_active_parameters(patient_id)
                    # Готовый отсев относится к чужому снимку, а не к только что прочитанному.
                    excluded_by_instrument = None

        patient_values = {code: parameter.value for code, parameter in patient_parameters.items()}

        systems_by_instrument: dict[str, set[str]] = {}
        for system_code, results in results_by_system.items():
            for result in results:
                systems_by_instrument.setdefault(result.instrument_code, set()).add(system_code)

        return LoadedInterpretationData(
            systems=tuple(systems),
            results_by_system=results_by_system,
            patient_parameters=patient_parameters,
            patient_values=patient_values,
            gender=patient_values.get(GENDER_PARAMETER_CODE),
            systems_by_instrument=systems_by_instrument,
            excluded_by_instrument=excluded_by_instrument,
        )
