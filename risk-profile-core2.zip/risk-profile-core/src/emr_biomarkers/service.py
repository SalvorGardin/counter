"""Обработка одной записи топика `emr-biomarkers`: разбор, обработка биомаркеров, логи.

Обработчик НЕ бросает на невалидных данных: код причины должен попасть в лог отсюда, а не из
общего перехвата исключений консюмера, который знает только «обработка записи не удалась».
Исключения оставлены инфраструктурным сбоям — это же различие («данные плохие» → лог и выход,
«мы не смогли» → наверх) отделяет ретраибельный сбой базы, который гасится ретраями и `alert`,
от неустранимого, который тоже пишет `alert`, но затем обязан дойти наверх с трассировкой.

Уровень записей об ошибках валидации — WARNING, не ERROR: сервис здоров, кривые данные прислал
внешний продюсер, а любая запись уровня ERROR+ инкрементит `risk_profile_core_errors_total` —
шумный продюсер загонял бы метрику ошибок сервиса в красное.

Логи пишутся здесь, а не по ходу обработки: пропуски разбора и пропуски сверки со справочником
делят один лимит поштучных записей на сообщение (читателю лога важно число строк, а не то, каким
шагом биомаркер отбракован), а обработка идёт в транзакции с ретраями, где запись в лог
повторялась бы на каждой попытке.
"""

from collections import Counter
from collections.abc import Awaitable, Callable, Mapping, Sequence
from typing import Any

from src.emr_biomarkers.domain.constants import (
    BIOMARKER_LOG_VALUE_MAX_LENGTH,
    BIOMARKER_SKIP_LOG_LIMIT,
    EmrBiomarkerErrorCode,
)
from src.emr_biomarkers.domain.exceptions import InvalidBiomarkerError, InvalidMessageError
from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.domain.validation import parse_biomarker, parse_message
from src.emr_biomarkers.processing import ProcessingReport
from src.logger import business, logger

# Хвост, которым помечается обрезанное значение: без него по логу не отличить короткое значение
# от начала длинного.
_TRUNCATION_MARKER = "...[truncated]"

# Обработка принятых биомаркеров. Инжектируется, а не импортируется: разбор ничего не знает
# ни о базе, ни об очереди команд, и тем же швом обработка подменяется в тестах.
type BiomarkerProcessor = Callable[[str, Sequence[EmrBiomarker]], Awaitable[ProcessingReport]]


def _truncate(text: str) -> str:
    """Режет строку по потолку логируемого значения, помечая обрезку."""
    if len(text) <= BIOMARKER_LOG_VALUE_MAX_LENGTH:
        return text
    return text[:BIOMARKER_LOG_VALUE_MAX_LENGTH] + _TRUNCATION_MARKER


def _log_value(raw: Any) -> str | None:
    """Готовит значение поля биомаркера к укладке в `log_context`.

    Значение приходит от внешнего продюсера и не ограничено ни типом, ни длиной — а в эту ветку
    попадают ровно те элементы, чьи значения ограничения контракта нарушили. Поэтому:

    - строкой отдаём любое скалярное значение: на проводе поле бывает любого типа (именно это
      часто и есть причина пропуска), а один тип ключа нужен, чтобы поле оставалось пригодным
      для фильтрации в хранилище логов;
    - массив или объект вместо скаляра — само по себе нарушение формата, поэтому кладём тип,
      а не содержимое: диагностической ценности в нём нет, а размер ничем не ограничен;
    - длину режем по потолку, иначе одно сообщение раздувает лог-строку без всякого предела.
    """
    if raw is None:
        return None
    if isinstance(raw, str):
        return _truncate(raw)
    if isinstance(raw, bool | int | float):
        return _truncate(str(raw))
    return f"<{type(raw).__name__}>"


def _raw_fields(raw: Any) -> Mapping[str, Any]:
    """Поля биомаркера, не собравшегося моделью: брать их больше неоткуда, кроме сырого элемента.
    Элемент, не являющийся объектом, оставляет поля пустыми — код ошибки и причина говорят сами
    за себя."""
    return raw if isinstance(raw, dict) else {}


def _matched_fields(biomarker: EmrBiomarker) -> Mapping[str, Any]:
    """Те же поля у биомаркера, прошедшего разбор и отбракованного сверкой со справочником.

    Имена ключей — контрактные (как на проводе), чтобы обе ветки логировали одно и то же.
    `value` — исходная строка сообщения: приведённого значения у пропущенного биомаркера нет.
    """
    return {
        "id": biomarker.id,
        "biomarkerCode": biomarker.biomarker_code,
        "name": biomarker.name,
        "unit": biomarker.unit,
        "unitCode": biomarker.unit_code,
        "value": biomarker.value,
    }


def _log_skipped_biomarker(client_id: str, fields: Mapping[str, Any], exc: InvalidBiomarkerError) -> None:
    """Пишет причину пропуска одного биомаркера.

    Поля биомаркера именуются с префиксом `biomarker_`: контракт требует их в логе, но `name`
    качественного биомаркера рядом с `client_id` — медицинские данные. `biomarker_name`
    и `biomarker_value` поэтому маскируются дефолтным маск-листом, а префикс позволяет снять
    маскировку именно с них через `RISK_MODEL_LOG_MASK_KEYS`, не задевая остальные `name`
    и `value` в логах сервиса.
    """
    logger.warning(
        "emr.biomarkers: biomarker skipped",
        extra={
            "log_context": {
                "client_id": client_id,
                "biomarker_id": _log_value(fields.get("id")),
                "biomarker_code": _log_value(fields.get("biomarkerCode")),
                "biomarker_name": _log_value(fields.get("name")),
                "biomarker_unit": _log_value(fields.get("unit")),
                "biomarker_unit_code": _log_value(fields.get("unitCode")),
                "biomarker_value": _log_value(fields.get("value")),
                "error_code": exc.code,
                "reason": _truncate(exc.reason),
            }
        },
    )


async def handle_emr_biomarkers_record(payload: bytes | None, *, process: BiomarkerProcessor) -> None:
    """Разбирает запись топика и передаёт принятые биомаркеры обработке.

    Нарушение уровня сообщения отбрасывает сообщение целиком (биомаркеры не обрабатываются),
    нарушение уровня биомаркера пропускает только этот элемент. Принятые биомаркеры сохраняют
    исходный порядок массива — от него зависят правила свежести и приоритета.

    Пропуски описываются поштучно до `BIOMARKER_SKIP_LOG_LIMIT` на сообщение, дальше остаются
    только в счётчиках итогового бизнес-события: одно сообщение не должно вытеснять из логов
    всё остальное. Число не описанных поштучно пропусков — в поле `skipped_not_logged`.
    """
    try:
        message = parse_message(payload)
    except InvalidMessageError as exc:
        _log_message_rejected(exc.code, exc.reason)
        return

    accepted: list[EmrBiomarker] = []
    accepted_ids: set[int] = set()
    skipped: Counter[str] = Counter()
    logged = _SkipLog(message.client_id)
    for raw in message.biomarkers:
        try:
            biomarker = parse_biomarker(raw)
            if biomarker.id in accepted_ids:
                raise InvalidBiomarkerError(
                    EmrBiomarkerErrorCode.INVALID_BIOMARKER_FORMAT,
                    f"id {biomarker.id} is duplicated within biomarkers",
                )
            accepted_ids.add(biomarker.id)
            accepted.append(biomarker)
        except InvalidBiomarkerError as exc:
            skipped[exc.code] += 1
            logged.add(_raw_fields(raw), exc)

    report = await process(message.client_id, accepted)
    for skip in report.skips:
        skipped[skip.error.code] += 1
        logged.add(_matched_fields(skip.biomarker), skip.error)
    # «Принято» — прошедшее ВЕСЬ входной контроль, а не только разбор: биомаркер, отбракованный
    # сверкой со справочником, уже посчитан в пропусках, и без этой поправки счётчики сообщения
    # не сходились бы с числом его элементов.
    accepted_count = len(accepted) - len(report.skips)

    if report.error_code is not None:
        _log_message_rejected(report.error_code, report.reason, client_id=message.client_id)
        return
    if not report.completed:
        # Сбой обработки: `alert` уже записан, итогового события у сообщения нет — иначе счётчики
        # читались бы как «обработано без записей».
        return

    total_skipped = sum(skipped.values())
    business(
        "emr.biomarkers: message validated",
        {
            "client_id": message.client_id,
            "total": len(message.biomarkers),
            "accepted": accepted_count,
            "skipped": total_skipped,
            # Разбивка по причинам — чтобы по сообщению с пропусками сверх лимита поштучных записей
            # было видно, что именно не прошло, а не только сколько.
            "skipped_by_code": dict(skipped),
            # Сколько пропусков остались без поштучной записи: без этого числа неполнота
            # поштучных логов не видна и читается как «пропусков было столько, сколько записей».
            "skipped_not_logged": max(0, total_skipped - BIOMARKER_SKIP_LOG_LIMIT),
            # Принятый биомаркер и сохранённый — не одно и то же: дубль и устаревшее значение
            # проходят сверку и не меняют ничего. Без этих двух счётчиков по логу их не различить.
            "written": len(report.written_parameters),
            "recalc_requested": report.recalc_requested,
        },
    )


def _log_message_rejected(error_code: str, reason: str, *, client_id: str | None = None) -> None:
    """Причина, по которой сообщение не обработано целиком: `INVALID_MESSAGE` разбора либо
    `CLIENT_NOT_FOUND` обработки. `client_id` кладётся, когда он уже разобран."""
    context: dict[str, Any] = {"error_code": error_code, "reason": _truncate(reason)}
    if client_id is not None:
        context["client_id"] = client_id
    logger.warning("emr.biomarkers: message rejected", extra={"log_context": context})


class _SkipLog:
    """Поштучные записи о пропусках под общим на сообщение лимитом.

    Лимит общий для пропусков разбора и пропусков сверки: на сообщении, где не прошёл ни один
    биомаркер, записи повторяют одну причину и топят остальные логи, а причина у них может быть
    из разных шагов. Полная картина при этом не теряется — она в счётчиках итогового события.
    """

    def __init__(self, client_id: str) -> None:
        self._client_id = client_id
        self._written = 0

    def add(self, fields: Mapping[str, Any], exc: InvalidBiomarkerError) -> None:
        if self._written >= BIOMARKER_SKIP_LOG_LIMIT:
            return
        self._written += 1
        _log_skipped_biomarker(self._client_id, fields, exc)
