"""Обработка принятых биомаркеров — шаги 2 и 4–7 контракта.

Границы транзакции: чтение состояния и все записи одного сообщения идут одной транзакцией через
`TransactionalRetryExecutor`. Читать до транзакции нельзя — повторная попытка строила бы план по
устаревшему снимку; писать по биомаркеру нельзя — сбой на середине оставил бы сообщение
применённым наполовину, а история получила бы промежуточные значения.

Пересчёт заказывается ПОСЛЕ фиксации транзакции: команда уходит в другой топик, её берёт другой
воркер, и до коммита он прочитал бы состояние без записанных значений.

Логи пишутся не отсюда, а из обработчика записи, по возвращённому отчёту: внутри транзакции они
повторялись бы на каждой попытке ретрая. Исключение — `alert` о сбое базы и предупреждение о
неприменимой строке разметки: первый пишется по факту сбоя (исчерпание попыток либо перманентная
ошибка), второе — уже после фиксации.
"""

from collections.abc import Awaitable, Callable, Sequence
from contextlib import AbstractAsyncContextManager
from dataclasses import dataclass, field
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.emr_biomarkers.domain.constants import BiomarkerOperationType, EmrBiomarkerErrorCode
from src.emr_biomarkers.domain.exceptions import InvalidBiomarkerError
from src.emr_biomarkers.domain.matching import MatchedBiomarker, match_biomarker
from src.emr_biomarkers.domain.models import EmrBiomarker
from src.emr_biomarkers.domain.planning import MessagePlan, plan_writes
from src.emr_biomarkers.infra.reader import EmrBiomarkersReader
from src.emr_biomarkers.infra.repository import (
    EmrBiomarkersRepository,
    PatientParameterWriter,
    insert_through_ehr_view,
)
from src.exceptions import NonRetriableDbError, RetriableDbError
from src.infra.catalog.emr_biomarkers import EmrBiomarkersCatalog
from src.infra.db_retry import TransactionalRetryExecutor
from src.logger import alert, logger

_EMPTY_PLAN = MessagePlan(writes=(), skipped_mappings=())

# Открытие сессии и заказ пересчёта — контракты, а не конкретные функции: обработка биомаркеров
# не зависит ни от пакета расчёта, ни от того, как устроена фабрика сессий. Связывает их воркер,
# который и так знает обе стороны; иначе доменный путь тянул бы за собой весь граф импортов
# `src.calc` (вплоть до FastAPI) ради одного псевдонима типа.
type SessionFactory = Callable[[], AbstractAsyncContextManager[AsyncSession]]
type RecalcDispatcher = Callable[[str, set[str] | None], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class BiomarkerSkip:
    """Биомаркер, пропущенный сверкой со справочником, и причина пропуска.

    Отдаётся наружу данными, а не записью в лог: поштучные записи ограничены общим на сообщение
    лимитом вместе с пропусками разбора, и решает это обработчик записи.
    """

    biomarker: EmrBiomarker
    error: InvalidBiomarkerError


@dataclass(frozen=True, slots=True)
class ProcessingReport:
    """Итог обработки сообщения — вход для логирования и для решения о пересчёте."""

    # Код уровня сообщения, из-за которого обработка не состоялась (сейчас — только
    # `CLIENT_NOT_FOUND`). Пишет его в лог обработчик записи, вместе с прочими причинами.
    error_code: EmrBiomarkerErrorCode | None = None
    reason: str = ""
    # Сбой инфраструктуры: `alert` уже записан здесь, итогового события у сообщения быть не должно.
    failed: bool = False
    skips: tuple[BiomarkerSkip, ...] = ()
    written_parameters: tuple[str, ...] = ()
    recalc_requested: bool = False

    @property
    def completed(self) -> bool:
        """Дошла ли обработка до конца: пациент найден и запись выполнена."""
        return self.error_code is None and not self.failed


@dataclass(frozen=True, slots=True)
class _Outcome:
    """Результат транзакции: что не так с сообщением, что пропущено и что записано."""

    client_found: bool
    skips: tuple[BiomarkerSkip, ...] = ()
    plan: MessagePlan = field(default=_EMPTY_PLAN)


class EmrBiomarkersProcessor:
    """Шаги 2 и 4–7 над принятыми биомаркерами одного сообщения.

    Зависимости инжектируются: фабрика сессий — потому что обработка живёт в consumer-воркере,
    где запросной сессии нет; заказ пересчёта — потому что подменяется в тестах и потому что
    публикация команды не должна прорастать в доменный код; способ записи параметра — потому что
    у процесса-владельца этих данных и у консюмера ЭМК разные права в БД.
    """

    def __init__(
        self,
        session_factory: SessionFactory,
        catalog: EmrBiomarkersCatalog,
        dispatch: RecalcDispatcher,
        writer: PatientParameterWriter = insert_through_ehr_view,
    ) -> None:
        self._session_factory = session_factory
        self._catalog = catalog
        self._dispatch = dispatch
        # Способ записи параметра зависит от процесса: у консюмера ЭМК есть только его
        # представление, у testing-API в процессе API — прямой доступ к таблицам профиля.
        self._writer = writer

    async def process(self, client_id: str, biomarkers: Sequence[EmrBiomarker]) -> ProcessingReport:
        """Обрабатывает принятые биомаркеры сообщения и отдаёт отчёт для лога.

        Биомаркеры с `operationType = delete` отсеиваются здесь: контракт их обработку отложил,
        и до сверки со справочником они не доходят. Поиск пациента при этом выполняется всегда —
        это шаг уровня сообщения.
        """
        savable = [item for item in biomarkers if item.operation_type == BiomarkerOperationType.SAVE]
        async with self._session_factory() as session:
            executor = TransactionalRetryExecutor(session)
            try:
                outcome = await executor.run(self._apply, session, client_id, savable)
            except RetriableDbError as exc:
                # Сообщение остаётся необработанным: оффсет коммитится и без нас, передоставки
                # не будет. Поднимаем alert — по `client_id` и времени сообщение ещё можно найти
                # в топике, пока не истёк retention.
                alert(
                    "emr.biomarkers: message processing failed, message skipped",
                    {"client_id": client_id, "attempts": exc.attempts},
                    exc_info=exc,
                )
                return ProcessingReport(failed=True)
            except NonRetriableDbError as exc:
                # Перманентный дефект — нарушение ограничения, права, расхождение схемы: ретраи его
                # не лечат, и сообщение остаётся необработанным так же, как при исчерпании попыток.
                # Наверху его ждёт общий перехват обработчика записи консюмера, который логирует
                # любой сбой одинаково («record handling failed, skipped») и коммитит оффсет, —
                # там дефект базы неотличим от невалидного сообщения внешнего продюсера. Поэтому
                # alert пишем здесь, пока известен `client_id`, а исключение поднимаем дальше:
                # оно не про данные сообщения, и трассировка с координатами записи топика нужна
                # тому, кто будет чинить.
                alert(
                    "emr.biomarkers: message processing failed, database error is permanent",
                    {"client_id": client_id, "attempts": exc.attempts},
                    exc_info=exc,
                )
                raise

        if not outcome.client_found:
            return ProcessingReport(
                error_code=EmrBiomarkerErrorCode.CLIENT_NOT_FOUND,
                reason="no patient with this clientId",
            )

        for skipped in outcome.plan.skipped_mappings:
            # Дефект справочника, а не данных пациента: биомаркер сохранён, а правило применить
            # нечем. Уровень WARNING — сервис здоров, но строку разметки нужно чинить.
            logger.warning(
                "emr.biomarkers: mapping skipped",
                extra={
                    "log_context": {
                        "client_id": client_id,
                        "biomarker_parameter_code": skipped.biomarker_parameter_code,
                        "parameter_code": skipped.parameter_code,
                        "reason": skipped.reason,
                    }
                },
            )

        written = tuple(write.parameter_code for write in outcome.plan.writes)
        if written:
            # Шаг 7: одна команда на сообщение, областью — коды записанных параметров.
            await self._dispatch(client_id, set(written))
        return ProcessingReport(skips=outcome.skips, written_parameters=written, recalc_requested=bool(written))

    async def _apply(self, session: AsyncSession, client_id: str, biomarkers: Sequence[EmrBiomarker]) -> _Outcome:
        """Тело транзакции: поиск пациента, сверка, план и запись.

        Вызывается `TransactionalRetryExecutor`, поэтому целиком повторяется на ретраибельном
        сбое — и чтение, и планирование, и запись. Побочных эффектов вне базы здесь нет ровно
        поэтому.
        """
        reader = EmrBiomarkersReader(session)
        if not await reader.patient_exists(client_id):
            return _Outcome(client_found=False)

        entries = self._catalog.entries_by_biomarker_code
        matched: list[MatchedBiomarker] = []
        skips: list[BiomarkerSkip] = []
        for item in biomarkers:
            try:
                matched.append(match_biomarker(item, entries.get(item.biomarker_code, ())))
            except InvalidBiomarkerError as exc:
                skips.append(BiomarkerSkip(biomarker=item, error=exc))

        source_codes = {item.entry.parameter_code for item in matched}
        mappings = {code: self._catalog.mappings_by_biomarker_parameter_code.get(code, ()) for code in source_codes}
        # Снимок читается по всем кодам, которых сообщение может коснуться: свои параметры
        # биомаркеров и цели разметки. Одним запросом — правила сравнивают даты, а не читают
        # строки по одной.
        touched = source_codes | {row.parameter_code for rows in mappings.values() for row in rows}
        stored = await reader.load_stored_parameters(client_id, touched)

        plan = plan_writes(matched, mappings=mappings, stored=stored, now=datetime.now(tz=UTC))
        repository = EmrBiomarkersRepository(session, self._writer)
        await repository.apply_writes(patient_id=client_id, writes=plan.writes)
        return _Outcome(client_found=True, skips=tuple(skips), plan=plan)
