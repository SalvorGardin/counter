import os
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from src.constants import DEFAULT_LOG_MASK_KEYS, REQUIRED_LOG_MASK_KEYS, normalize_mask_key
from src.exceptions import RiskBaseError
from src.logger import notice

_ALLOWED_SECURITY_PROTOCOLS = {"PLAINTEXT", "SSL", "SASL_PLAINTEXT", "SASL_SSL"}
_ALLOWED_SASL_MECHANISMS = {"PLAIN", "SCRAM-SHA-256", "SCRAM-SHA-512"}
_ALLOWED_AUTO_OFFSET_RESET = {"earliest", "latest"}
_RESTARTER_API_KEY_MIN_LEN = 16
_RESTARTER_API_KEY_MAX_LEN = 64


class KafkaTopicsSettings(BaseModel):
    """Названия Kafka-топиков — единый источник правды для приложения и init-воркера."""

    test: str = "risk-profile.test"
    # Топик РЕЗУЛЬТАТОВ расчёта (контракт с downstream): сюда воркер шлёт события
    # calculation/interpretation после пересчёта. Читают внешние потребители.
    risk_calculation: str = "risk-calculation"
    # Топик КОМАНД на пересчёт (внутренняя очередь работ): API кладёт сюда команду
    # вместо того, чтобы считать в своём event loop; consumer-воркер её разбирает и считает.
    # Ключ сообщения = patient_id → все команды одного пациента в одной партиции → строгий
    # порядок пересчётов на пациента (без гонок upsert результатов).
    recalc_commands: str = "risk-profile.recalc-commands"
    # Топик результатов лабораторных исследований из ЭМК (контракт с внешним продюсером —
    # вики «Внешние-контракты-API/Emr-biomarkers»). Читает отдельный воркер-процесс.
    emr_biomarkers: str = "emr-biomarkers"


class KafkaConsumerSettings(BaseModel):
    """Конфиг одного consumer-воркера: его группа и параметры poll'а его топика.

    Экземпляр заводится на топик (`consumer` — команды пересчёта, `emr_biomarkers_consumer` —
    биомаркеры ЭМК), и `group_id` у экземпляров обязаны различаться: с общей группой воркеры
    разных топиков сели бы в одну группу и отбирали бы друг у друга партиции. Используется
    ТОЛЬКО процессами-воркерами; API-процесс consumer не поднимает.

    Параллелизм обработки = min(число партиций топика, число инстансов группы,
    `max_concurrency` каждого инстанса).
    """

    # Одна consumer-группа на очередь работ (competing consumers): инстансы группы ДЕЛЯТ
    # партиции между собой. НЕ заводить несколько групп под один топик — каждая лишняя
    # группа получит ПОЛНУЮ копию сообщений (для команд пересчёта это дублирующий пересчёт).
    # Масштабирование — числом инстансов внутри одной группы (cap = число партиций топика).
    group_id: str = "risk-recalc-workers"
    # Сколько команд тянуть за один poll (getmany). Батч обрабатывается, затем коммитится оффсет.
    max_poll_records: int = 50
    # Сколько партиций (= независимых потоков пациентов) один инстанс обрабатывает параллельно.
    # Каждый пересчёт берёт 1 сессию из пула БД (pool_size 5 + overflow 10 = 15) — 4 с запасом.
    max_concurrency: int = 4
    # Максимальное ожидание накопления батча, мс. Меньше → ниже задержка пересчёта, чаще poll'ы.
    fetch_max_wait_ms: int = 500
    # at-least-once: коммитим оффсет ТОЛЬКО после обработки батча (enable_auto_commit=False в воркере).
    auto_offset_reset: str = "earliest"
    session_timeout_ms: int = 30_000
    heartbeat_interval_ms: int = 3_000
    # Должен превышать worst-case время обработки одного батча, иначе брокер исключит инстанс
    # из группы и переразложит партиции (дубль-обработка). 5 мин — щедрый запас для батча из 50.
    max_poll_interval_ms: int = 300_000

    @field_validator("max_poll_records", "max_concurrency", "fetch_max_wait_ms")
    @classmethod
    def _validate_positive(cls, v: int, info: Any) -> int:
        if v < 1:
            raise ValueError(f"{info.field_name} must be >= 1, got {v}")
        return v

    @field_validator("auto_offset_reset")
    @classmethod
    def _validate_auto_offset_reset(cls, v: str) -> str:
        if v not in _ALLOWED_AUTO_OFFSET_RESET:
            raise ValueError(f"auto_offset_reset must be one of {sorted(_ALLOWED_AUTO_OFFSET_RESET)}, got {v!r}")
        return v

    @field_validator("heartbeat_interval_ms")
    @classmethod
    def _validate_heartbeat_below_session(cls, v: int, info: Any) -> int:
        # Kafka требует heartbeat_interval_ms < session_timeout_ms (рекомендуется ~1/3).
        session = info.data.get("session_timeout_ms")
        if session is not None and v >= session:
            raise ValueError(f"heartbeat_interval_ms ({v}) must be < session_timeout_ms ({session})")
        return v


class KafkaSettings(BaseModel):
    """Конфиг Kafka-клиента. `enabled=False` отключает продюсер (например, в unit-тестах)."""

    enabled: bool = False
    # CSV "host1:9092,host2:9092" — поддерживает N брокеров на стенде без правок compose.
    bootstrap_servers: str = ""
    security_protocol: str = "SASL_SSL"
    # SASL/SCRAM-аутентификация: дефолт — SCRAM-SHA-512 (надёжнее PLAIN, пароль не передаётся открытым текстом).
    sasl_mechanism: str = "SCRAM-SHA-512"
    sasl_username: str = ""
    # SecretStr: pydantic не отдаёт значение в repr/model_dump — пароль не попадёт в логи отладочной сериализации.
    sasl_password: SecretStr = SecretStr("")
    # TLS: путь к CA (для верификации брокера). Клиентский сертификат опционален и нужен только при чистом mTLS.
    ssl_cafile: str = ""
    ssl_certfile: str = ""
    ssl_keyfile: str = ""
    ssl_password: SecretStr | None = None
    ssl_check_hostname: bool = True
    client_id: str = "risk-profile-core"
    acks: str = "all"
    request_timeout_ms: int = 30_000
    max_pending_publishes: int = 256
    topics: KafkaTopicsSettings = KafkaTopicsSettings()
    # Число партиций топика команд recalc_commands (создаётся kafka-init). Это потолок
    # параллелизма пересчёта: consumer-группа не задействует больше инстансов, чем партиций.
    # Дев-стенд (16 vCPU, один брокер): 6 — запас на рост числа инстансов 1→6 без репартиции.
    recalc_commands_partitions: int = 6
    consumer: KafkaConsumerSettings = KafkaConsumerSettings()
    # Приём топика `emr-biomarkers` отдельным воркером. Флаг независим от `enabled`: топик и ACL
    # провижинятся отдельно, и до их выкатки воркер должен простаивать, а не уходить в бесконечный
    # ретрай по ошибке авторизации. Выключен по умолчанию.
    emr_biomarkers_enabled: bool = False
    # Своя группа у воркера биомаркеров: общая с пересчётом посадила бы оба воркера в одну группу
    # и они делили бы партиции чужих топиков.
    emr_biomarkers_consumer: KafkaConsumerSettings = KafkaConsumerSettings(group_id="risk-emr-biomarkers-workers")

    @field_validator("recalc_commands_partitions")
    @classmethod
    def _validate_partitions(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"recalc_commands_partitions must be >= 1, got {v}")
        return v

    @field_validator("security_protocol")
    @classmethod
    def _validate_security_protocol(cls, v: str) -> str:
        if v not in _ALLOWED_SECURITY_PROTOCOLS:
            raise ValueError(f"security_protocol must be one of {sorted(_ALLOWED_SECURITY_PROTOCOLS)}, got {v!r}")
        return v

    @field_validator("sasl_mechanism")
    @classmethod
    def _validate_sasl_mechanism(cls, v: str, info: Any) -> str:
        # Проверяем только когда SASL реально используется — иначе stale RISK_MODEL_KAFKA__SASL_MECHANISM
        # в env уронит старт сервиса, хотя поле в этой конфигурации игнорируется.
        if info.data.get("security_protocol") not in {"SASL_PLAINTEXT", "SASL_SSL"}:
            return v
        if v not in _ALLOWED_SASL_MECHANISMS:
            raise ValueError(f"sasl_mechanism must be one of {sorted(_ALLOWED_SASL_MECHANISMS)}, got {v!r}")
        return v

    @field_validator("sasl_password")
    @classmethod
    def _reject_comma_in_sasl_password(cls, v: SecretStr) -> SecretStr:
        # bitnami-брокер принимает KAFKA_CLIENT_PASSWORDS как CSV; запятая в одном из паролей сдвинет
        # маппинг user→password, и проблема всплывёт только как невнятный SASL auth-fail на стенде.
        # Тот же запрет на стороне app — чтобы пароли двух сторон точно совпадали.
        if "," in v.get_secret_value():
            raise ValueError("sasl_password must not contain ',' — comma breaks broker CSV bootstrap")
        return v


class CvdSettings(BaseModel):
    """Конфиг клиента внешнего ML-сервиса риска ССЗ (risk-profile-cvd).

    `enabled=False` (дефолт, как у Kafka) отключает обращение к сервису — калькулятор `airi_ssz`
    тогда пропускается. На стенде включается через `RISK_MODEL_CVD__ENABLED=true` + базовый URL.
    """

    enabled: bool = False
    base_url: str = "http://cvd:8000"
    # Таймаут одного запроса к /api/v1/calculate, сек. Инференс быстрый (~десятки мс), запас на сеть.
    timeout: float = 10.0
    # Горизонт прогноза по умолчанию ("Y5" — 5 лет, "Y2" — 2 года).
    default_period: str = "Y5"

    # --- Окно наблюдений, по которому воркер считает сервис насыщенным ---
    # Насыщение закрывает фоновую ёмкость: команды массового пересчёта отбрасываются, пока сервис
    # не отвечает в пределах порогов. Значения подбираются по проду и меняются через окружение без
    # пересборки образа (см. `src/calc/infra/cvd_saturation.py`).
    # Ширина окна, сек: наблюдения старше горизонта из окна выпадают.
    saturation_window_seconds: float = 60.0
    # Минимум наблюдений, до которого насыщения нет: иначе один медленный вызов после простоя
    # закрывал бы фоновую ёмкость целиком.
    saturation_min_observations: int = 10
    # Порог среднего времени ответа по окну, мс.
    saturation_latency_ms: float = 2000.0
    # Порог доли сбойных вызовов по окну (0..1). Ответ 400 (данные пациента) в окно не попадает.
    saturation_error_rate: float = 0.2
    # Потолок разброса задержки возврата фоновой ёмкости, сек. Каждый процесс выбирает свою
    # задержку в пределах потолка один раз, чтобы реплики не возобновляли фон одновременно.
    saturation_recovery_jitter_seconds: float = 30.0

    @field_validator("saturation_window_seconds", "saturation_latency_ms")
    @classmethod
    def _validate_positive_threshold(cls, v: float, info: Any) -> float:
        if v <= 0:
            raise ValueError(f"{info.field_name} must be > 0, got {v}")
        return v

    @field_validator("saturation_min_observations")
    @classmethod
    def _validate_min_observations(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"saturation_min_observations must be >= 1, got {v}")
        return v

    @field_validator("saturation_error_rate")
    @classmethod
    def _validate_error_rate(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError(f"saturation_error_rate must be within 0..1, got {v}")
        return v

    @field_validator("saturation_recovery_jitter_seconds")
    @classmethod
    def _validate_recovery_jitter(cls, v: float) -> float:
        if v < 0:
            raise ValueError(f"saturation_recovery_jitter_seconds must be >= 0, got {v}")
        return v

    @field_validator("default_period")
    @classmethod
    def _validate_period(cls, v: str) -> str:
        if v not in {"Y2", "Y5"}:
            raise ValueError(f"default_period must be one of ['Y2', 'Y5'], got {v!r}")
        return v


class ProfilerSettings(BaseModel):
    """yappi-профилировщик под feature-flag. По умолчанию выключен.

    При `enabled=True` приложение принудительно стартует в один воркер (см. `src/__main__.py`):
    статистика yappi копится per-process, иначе она фрагментировалась бы по воркерам, а
    `/api/v1/debug/profile` отдавал бы данные случайного процесса.
    """

    enabled: bool = False
    # Скользящее окно хранения сэмплов, мин. Данные старше окна отбрасываются.
    retention_minutes: int = 20
    # Интервал ротации бакета, сек. Число бакетов в окне = retention_minutes*60 / bucket_seconds.
    bucket_seconds: int = 60

    @field_validator("retention_minutes")
    @classmethod
    def _validate_retention(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"retention_minutes must be >= 1, got {v}")
        return v

    @field_validator("bucket_seconds")
    @classmethod
    def _validate_bucket(cls, v: int, info: Any) -> int:
        if v < 1:
            raise ValueError(f"bucket_seconds must be >= 1, got {v}")
        retention_minutes = info.data.get("retention_minutes")
        if retention_minutes is not None and v > retention_minutes * 60:
            raise ValueError(f"bucket_seconds ({v}) must not exceed retention window {retention_minutes * 60}s")
        return v


class MetricsSettings(BaseModel):
    """Экспозиция метрик Prometheus (`GET /metrics`).

    `enabled=False` отдаёт на ручке 404 — аварийный рубильник, чтобы отключить экспозицию
    без релиза (например, если внешний Prometheus зачастит скрейпами). Гейт стоит ТОЛЬКО на
    экспозиции: сам сбор дешёвый и остаётся включённым, иначе после включения флага счётчики
    показывали бы разрыв вместо честной истории.

    Флаг общий для обеих экспозиций: `/metrics` процесса app и `/metrics` на порту проб
    consumer-воркера (см. `consumer_health_port`) — у каждого процесса своя выдача, но рубильник
    один, и выключается всё сразу.
    """

    enabled: bool = True


class RestarterSettings(BaseModel):
    """Ручка перезапуска контейнеров ядра для пересборки резидентных каталогов (стенд тестирования).

    Каталоги справочников строятся один раз на старте процесса и живут в RAM (см.
    `catalog_builder`), поэтому правка справочника прямо в БД не видна работающим процессам.
    Перезапуск контейнеров — единственный способ заставить их перечитать БД.

    Процесс слушает unix-сокет и поднимается с `network_mode: none`: ни порта, ни адреса в
    compose-сети у него нет, снаружи он доступен только через проброс сокета по SSH.
    """

    # Путь unix-сокета, на котором слушает сам процесс (см. `python -m src.workers.restarter`).
    # Ограничение sun_path — 108 байт, поэтому каталог монтирования держим коротким.
    uds_path: str = "/run/restarter/restarter.sock"
    # Сокет Docker Engine API. Смонтирован в контейнер; сетевого доступа не требует.
    docker_socket: str = "/var/run/docker.sock"
    # Ключ ручки перезапуска (заголовок X-Restarter-Api-Key). ОТДЕЛЬНЫЙ от test_api_key:
    # тот при включённом тестовом API отдаётся браузеру без авторизации через
    # /questionnaire/config.js, а перезапуск контейнеров — привилегированная операция
    # (сокет демона равносилен root на хосте), и её ключ раскрывать клиенту нельзя.
    # Пустое значение = ручка отдаёт 401 на любой запрос. Env: RISK_MODEL_RESTARTER__API_KEY.
    api_key: SecretStr = SecretStr("")
    # Бюджет graceful stop контейнера, сек (параметр `t` у Engine API). Дефолт демона — 10 с,
    # чего мало для дренажа: демон пришлёт SIGKILL посреди штатной остановки. Значение обязано
    # быть НЕ МЕНЬШЕ бюджета остановки самих процессов (shutdown_timeout /
    # consumer_shutdown_timeout) — проверяется в Settings._validate_restarter_stop_timeout.
    stop_timeout_s: int = 60
    # Имя compose-проекта: по нему и по имени сервиса контейнеры ищутся через label-фильтр.
    # Совпадает с `name:` в docker-compose.yml.
    compose_project: str = "risk-profile-core"

    @field_validator("api_key")
    @classmethod
    def _api_key_length(cls, v: SecretStr) -> SecretStr:
        """Непустой ключ обязан быть длиной 16..64 символа.

        Ручка равносильна root на хосте (см. докстринг класса), поэтому короткий ключ вроде `1`
        перебирается мгновенно; верхняя граница отсекает случайно вставленный в переменную мусор
        (файл, многострочный вывод) вместо ключа. Пустое значение по-прежнему допустимо — это
        штатный способ выключить ручку.
        """
        secret = v.get_secret_value()
        if secret and not (_RESTARTER_API_KEY_MIN_LEN <= len(secret) <= _RESTARTER_API_KEY_MAX_LEN):
            raise ValueError(
                f"RISK_MODEL_RESTARTER__API_KEY must be between {_RESTARTER_API_KEY_MIN_LEN} "
                f"and {_RESTARTER_API_KEY_MAX_LEN} characters"
            )
        return v


class BulkRecalcSettings(BaseModel):
    """Разовый прогон массового пересчёта (`python -m src.workers.bulk_recalc`).

    Все значения меняются через окружение без пересборки образа: пороги подбираются по проду
    после первого прогона. Носитель запуска — k8s CronJob, поэтому расписание и параллельность
    прогонов здесь не задаются: их держат `schedule`, `concurrencyPolicy: Forbid` и
    `activeDeadlineSeconds` самого объекта.
    """

    # Выключатель прогона. Дефолт — выключен: CronJob заводится заранее, а включают его отдельно
    # и осознанно, после проверки раската и ACL.
    enabled: bool = False
    # Сколько команд публикуется одной пачкой, между пачками — пауза. Вместе они задают темп
    # заливки когорты в очередь.
    batch_size: int = 500
    pause_seconds: float = 1.0
    # Жёсткий потолок времени прогона, сек. Согласуется с `activeDeadlineSeconds` CronJob'а:
    # процесс обязан завершиться сам раньше, чем его убьёт Kubernetes.
    time_budget_seconds: float = 3600.0
    # Проверочный батч завершённости раската: фоновые команды, как и вся когорта; прогон ждёт
    # появления штампа текущей версии в реестре.
    canary_size: int = 5
    canary_timeout_seconds: float = 120.0
    canary_poll_interval_seconds: float = 2.0
    # Потолок одного обращения прогона к БД, сек. Потолок времени прогона проверяется между
    # пачками, и зависший запрос до этой проверки не дал бы дойти: без таймаута сдерживал бы его
    # только `activeDeadlineSeconds` CronJob'а.
    query_timeout_seconds: float = 30.0

    @field_validator("batch_size", "canary_size")
    @classmethod
    def _validate_positive_size(cls, v: int, info: Any) -> int:
        if v < 1:
            raise ValueError(f"{info.field_name} must be >= 1, got {v}")
        return v

    @field_validator(
        "time_budget_seconds", "canary_timeout_seconds", "canary_poll_interval_seconds", "query_timeout_seconds"
    )
    @classmethod
    def _validate_positive_seconds(cls, v: float, info: Any) -> float:
        if v <= 0:
            raise ValueError(f"{info.field_name} must be > 0, got {v}")
        return v

    @field_validator("pause_seconds")
    @classmethod
    def _validate_pause(cls, v: float) -> float:
        if v < 0:
            raise ValueError(f"pause_seconds must be >= 0, got {v}")
        return v


class ServiceRuntime(StrEnum):
    """Какому сервису принадлежит процесс. Определяет и логин БД, и карту локальных представлений.

    Значение объявляет точка входа процесса (API, воркер, playground) один раз на старте — не
    окружение: в Kubernetes все поды сервиса получают один и тот же набор переменных. Выбирать
    database identity из окружения, запроса или сообщения нельзя — граница сервисов должна быть
    свойством процесса, а не данных.
    """

    PROFILE = "profile"
    CALCULATION = "calculation"
    EHR = "ehr"
    # Разовый процесс массового пересчёта: читает реестр версий и публикует команды.
    # Своих таблиц и локальных представлений у роли нет.
    BULK_RECALC = "bulk_recalc"


class Settings(BaseSettings):
    # Источник переменных — только окружение процесса (os.environ). .env-файл pydantic не читает:
    # на стенде compose сам инжектит .env в окружение контейнера (env_file: .env), а локально
    # разработчик подгружает переменные через direnv / `set -a; . .env; set +a`.
    model_config = SettingsConfigDict(
        env_prefix="RISK_MODEL_",
        env_nested_delimiter="__",
        extra="ignore",
        validate_default=True,
    )

    host: str = "127.0.0.1"
    port: int = 8000
    # Число uvicorn-воркеров (RISK_MODEL_WORKERS). При включённом профайлере форсируется в 1.
    workers: int = 4
    # Строки подключения — по одной на database identity, у каждой своё имя переменной: в общем пуле
    # переменных пода каждый процесс находит свою и не пересекается с чужими. Все необязательны при
    # загрузке — обязательность своей проверяет процесс на старте (`require_db_url`): в compose
    # каждому сервису подключается только его файл, и чужой переменной у него нет.
    # SecretStr: URL несёт пароль логина, и repr(settings)/model_dump() не должны его отдавать.
    # Разворачивается только при создании движка (src/infra/database.py) и в migrations/env.py.
    # API. Env: RISK_MODEL_PROFILE_DB_URL.
    profile_db_url: SecretStr | None = None
    # Логин расчёта: консюмер пересчёта, calc-playground и расчёт в процессе API — инлайн-пересчёт
    # (kafka.enabled=false) и синхронный запуск из testing-API. Env: RISK_MODEL_CALCULATION_DB_URL.
    calculation_db_url: SecretStr | None = None
    # Консюмер ЭМК. Env: RISK_MODEL_EHR_DB_URL.
    ehr_db_url: SecretStr | None = None
    # Массовый пересчёт. Env: RISK_MODEL_BULK_RECALC_DB_URL.
    bulk_recalc_db_url: SecretStr | None = None
    # Логин миграций (migrations/env.py). Входит во все роли-владельцы схем и видит физические
    # таблицы в обход изоляции: задаётся только в секрете задачи миграций, не в общем пуле подов.
    # Env: RISK_MODEL_MIGRATIONS_DB_URL.
    migrations_db_url: SecretStr | None = None
    # Режим общего логина: строки подключения разных ролей могут указывать на один логин, а сессия
    # сразу переключается на логин роли процесса стартовым параметром PostgreSQL `role`. Только для
    # окружений без отдельных логинов на процесс (стенд тестирования); общему логину членство в
    # рантайм-логинах выдаёт `scripts/bootstrap_db_roles.py --shared-login`.
    # Env: RISK_MODEL_DB_ASSUME_RUNTIME_ROLE.
    db_assume_runtime_role: bool = False
    # Максимальный возраст соединения в пуле, сек. Соединение старше отбрасывается на чекауте и
    # открывается заново — так пул не отдаёт соединение, которое успело простоять дольше, чем его
    # готовы держать Postgres / пулер / NAT. Значение должно быть МЕНЬШЕ самого короткого
    # idle-таймаута на пути до БД. 0 отключает пересоздание по возрасту.
    # Env: RISK_MODEL_DB_POOL_RECYCLE_SECONDS.
    db_pool_recycle_seconds: int = 300
    testing_api_enabled: bool = False
    # Сбор по-шаговых замеров (StepTimings) в calc/interpretation. Выключен по умолчанию: на боевом
    # пути не должен исполняться код профилирования — только код расчёта. При False шаги отдают
    # общий no-op контекст: ни perf_counter, ни арифметики, ни дерева sink-ов
    # (см. src/infra/step_timings.py).
    # Включают calc-playground и diag-скрипты, которым эта разбивка и нужна.
    step_timings_enabled: bool = False
    # Диагностический сбор статусов расчёта (таблица `calculation_statuses`): по какой причине
    # инструмент не дал показателя. Выключен по умолчанию и в проде — данные нужны внешнему
    # тестированию, а не боевому потоку. Состояние флага не наблюдается в расчёте: `results`,
    # сообщения `risk_calculation` и счётчики `CalcRunResult` одинаковы при любом его значении.
    # Таблица существует всегда (см. docs/requirements/calc-statuses.md); флаг управляет только
    # записью в неё.
    calc_status_collection_enabled: bool = False
    # Сколько фоновых команд пересчёта (команд массового прогона) процесс-воркер выполняет
    # одновременно. Абсолютное число, а не доля `kafka.consumer.max_concurrency`: доля молча
    # выросла бы при изменении конкурентности. Ноль закрывает фон в этом процессе целиком.
    # Ёмкость команд БЕЗ признака фоновой этим значением не уменьшается.
    # Env: RISK_MODEL_BACKGROUND_RECALC_CAPACITY.
    background_recalc_capacity: int = 1
    # Минимум секунд между началами двух фоновых команд в одном процессе — верхняя граница их
    # ТЕМПА, тогда как ёмкость выше ограничивает их ОДНОВРЕМЕННОСТЬ. Нужны оба: короткие пересчёты
    # при capacity=1 идут вплотную и выбирают пропускную способность базы и risk-profile-cvd, не
    # выходя за один слот. Темп по сервису = число реплик consumer × 1/значение. Ноль снимает
    # ограничение. Команда, пришедшая раньше интервала, отбрасывается (причина `rate_limited`),
    # а не ждёт: ожидание застопорило бы партицию вместе с пользовательскими командами.
    # Env: RISK_MODEL_BACKGROUND_RECALC_MIN_INTERVAL_SECONDS.
    background_recalc_min_interval_seconds: float = 0.0
    # Путь файла с версией расчёта (см. `src/calc/version.py`). Значение едет в образе рядом с
    # кодом, а env-переменная задаёт только его местоположение — тесты подсовывают свой файл.
    # Env: RISK_MODEL_CALCULATION_VERSION_FILE.
    calculation_version_file: str = "calculation-version.json"
    # SecretStr: значение не светится в repr(settings)/model_dump() — тот же подход, что у sasl_password.
    test_api_key: SecretStr = SecretStr("")
    # Уровень логирования читается из env `LOG_LEVEL` без префикса RISK_MODEL_ —
    # требование заказчика: универсальное имя переменной, общее для всех сервисов в инфраструктуре.
    log_level: str = Field(default="NOTICE", validation_alias="LOG_LEVEL")
    # CSV-список ключей, значения которых маскируются в логах (тела, заголовки, context).
    # Сравнение нормализованное (lowercase, без -/_): "birthdate" покрывает birthDate/birth_date.
    # Дефолт прод-безопасный (ПДн + секреты заголовков); на стенде сужается через env без правки кода.
    # Секреты транспорта (REQUIRED_LOG_MASK_KEYS) валидатор вливает принудительно: оператор
    # не может случайно включить логирование bearer-токенов, задав список только с PII-ключами.
    log_mask_keys: str = DEFAULT_LOG_MASK_KEYS
    # Потолок тела запроса в логе, байт. Сверх лимита тело логируется усечённой строкой.
    log_body_max_bytes: int = 8192
    kafka: KafkaSettings = KafkaSettings()
    cvd: CvdSettings = CvdSettings()
    profiler: ProfilerSettings = ProfilerSettings()
    metrics: MetricsSettings = MetricsSettings()
    restarter: RestarterSettings = RestarterSettings()
    bulk_recalc: BulkRecalcSettings = BulkRecalcSettings()
    # Таймаут завершения активных запросов при штатной остановке (uvicorn timeout_graceful_shutdown).
    # Должен превышать самый долгий BackgroundTask: Kafka request_timeout_ms = 30 с.
    shutdown_timeout: int = 60
    # Задержка (сек) после перехода в drain-режим до закрытия сервисов.
    # Даёт load balancer время заметить 503 на /readiness до обрыва соединений.
    # В k8s предпочтителен preStop-хук (sleep N в pod spec) — тогда здесь оставить 0.
    shutdown_grace_delay: float = 0.0
    # Таймаут дренажа батча и teardown в consumer-воркере (отдельный от uvicorn shutdown_timeout,
    # чтобы операторы могли тюнить их независимо и однозначно считать terminationGracePeriodSeconds).
    # Если не задан явно — наследует значение shutdown_timeout (см. _inherit_consumer_shutdown_timeout).
    # Env: RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT.
    consumer_shutdown_timeout: int = 60
    # Порт HTTP-проб здоровья consumer-воркера (/health, /readiness, /liveness) и его экспозиции
    # метрик (/metrics, гейтится флагом metrics.enabled). Воркер не публичный сервис, поэтому
    # дефолт совпадает с портом API (8000): контейнеры разные, коллизии нет. Слушает на
    # settings.host (в контейнере 0.0.0.0 из Dockerfile → доступно k8s httpGet).
    # Env: RISK_MODEL_CONSUMER_HEALTH_PORT.
    consumer_health_port: int = 8000
    # Порт HTTP-проб здоровья воркера биомаркеров ЭМК. Отдельное поле, а не общее с
    # consumer_health_port: воркеры масштабируются независимо, и порт одного не должен двигаться
    # при тюнинге другого. Дефолт совпадает с портом API по той же причине — контейнеры разные.
    # Env: RISK_MODEL_EMR_CONSUMER_HEALTH_PORT.
    emr_consumer_health_port: int = 8000

    @model_validator(mode="before")
    @classmethod
    def _inherit_consumer_shutdown_timeout(cls, data: Any) -> Any:
        """Если RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT не задан — берём значение shutdown_timeout.

        mode="before" запускается после слияния источников (env / args), но до field-валидаторов,
        поэтому data содержит уже загруженные Python-имена полей без значений по умолчанию.
        Хардкод 60 — резервный дефолт на случай, когда оба поля отсутствуют в data.
        """
        if not isinstance(data, dict):
            return data
        if "consumer_shutdown_timeout" not in data:
            data = dict(data)
            data["consumer_shutdown_timeout"] = data.get("shutdown_timeout", 60)
        return data

    @field_validator("background_recalc_capacity")
    @classmethod
    def _validate_background_capacity(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"background_recalc_capacity must be >= 0 (0 disables background recalc), got {v}")
        return v

    @field_validator("background_recalc_min_interval_seconds")
    @classmethod
    def _validate_background_min_interval(cls, v: float) -> float:
        # Отрицательное значение выглядело бы как «отрицательная пауза», а работало бы как ноль:
        # отказ на старте честнее молча снятого ограничения темпа.
        if v < 0:
            raise ValueError(
                f"background_recalc_min_interval_seconds must be >= 0 (0 disables the rate ceiling), got {v}"
            )
        return v

    @field_validator("workers")
    @classmethod
    def _validate_workers(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"RISK_MODEL_WORKERS must be >= 1, got {v}")
        return v

    @field_validator("shutdown_timeout")
    @classmethod
    def _validate_shutdown_timeout(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"shutdown_timeout must be >= 1, got {v}")
        return v

    @field_validator("shutdown_grace_delay")
    @classmethod
    def _validate_shutdown_grace_delay(cls, v: float) -> float:
        if v < 0:
            raise ValueError(f"shutdown_grace_delay must be >= 0, got {v}")
        return v

    @field_validator("consumer_shutdown_timeout")
    @classmethod
    def _validate_consumer_shutdown_timeout(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"consumer_shutdown_timeout must be >= 1, got {v}")
        return v

    @field_validator("consumer_health_port", "emr_consumer_health_port")
    @classmethod
    def _validate_health_port(cls, v: int, info: Any) -> int:
        if not (1 <= v <= 65535):
            raise ValueError(f"{info.field_name} must be in 1..65535, got {v}")
        return v

    @field_validator(
        "profile_db_url", "calculation_db_url", "ehr_db_url", "bulk_recalc_db_url", "migrations_db_url", mode="before"
    )
    @classmethod
    def _blank_db_url_is_unset(cls, v: object) -> object:
        """Пустая строка — то же, что «не задано». Загрузку `Settings` проходят все процессы, а
        строка подключения нужна каждому только своя: пустая чужая переменная в общем наборе
        переменных пода (например, `RISK_MODEL_MIGRATIONS_DB_URL`, перекрытая пустым значением)
        не должна ронять процесс. Свою переменную проверяет `require_db_url` на старте."""
        if isinstance(v, str) and not v.strip():
            return None
        return v

    @field_validator("db_pool_recycle_seconds")
    @classmethod
    def _validate_db_pool_recycle_seconds(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"db_pool_recycle_seconds must be >= 0 (0 disables recycling), got {v}")
        return v

    @field_validator("log_mask_keys")
    @classmethod
    def _enforce_required_mask_keys(cls, v: str) -> str:
        """Принудительно вливает секреты транспорта (Authorization, Cookie, X-Test-Api-Key)
        в маск-лист: их отсутствие в env — ошибка оператора, а не способ включить
        логирование токенов. Сравнение — в нормализованной форме, как в маскировщике."""
        present = {normalize_mask_key(k.strip()) for k in v.split(",") if k.strip()}
        missing = [k for k in REQUIRED_LOG_MASK_KEYS.split(",") if normalize_mask_key(k) not in present]
        if not missing:
            return v
        base = v.strip().strip(",")
        return ",".join(([base] if base else []) + missing)

    @field_validator("log_body_max_bytes")
    @classmethod
    def _validate_log_body_max_bytes(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"RISK_MODEL_LOG_BODY_MAX_BYTES must be >= 1, got {v}")
        return v

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, v: str) -> str:
        from src.logger import _LEVEL_NAME_TO_NUM  # noqa: PLC0415

        if v.upper() not in _LEVEL_NAME_TO_NUM:
            raise ValueError(f"log_level must be one of {sorted(_LEVEL_NAME_TO_NUM)}, got {v!r}")
        return v.upper()

    @field_validator("test_api_key")
    @classmethod
    def test_api_key_not_empty_when_enabled(cls, v: SecretStr, info: Any) -> SecretStr:
        if info.data.get("testing_api_enabled"):
            secret = v.get_secret_value()
            if not secret:
                raise ValueError("RISK_MODEL_TEST_API_KEY must not be empty when testing API is enabled")
            if len(secret) < 16:
                raise ValueError("RISK_MODEL_TEST_API_KEY must be at least 16 characters")
        return v

    @field_validator("kafka")
    @classmethod
    def _kafka_required_when_enabled(cls, v: KafkaSettings) -> KafkaSettings:
        if not v.enabled:
            return v
        required: list[tuple[str, str]] = [("bootstrap_servers", v.bootstrap_servers)]
        # ssl_cafile опционален: если пустой — клиент верифицирует брокера по системному truststore
        # (см. _build_ssl_context). Требуем явный путь только для чистого mTLS (SSL без SASL).
        if v.security_protocol == "SSL":
            required += [
                ("ssl_cafile", v.ssl_cafile),
                ("ssl_certfile", v.ssl_certfile),
                ("ssl_keyfile", v.ssl_keyfile),
            ]
        if v.security_protocol in {"SASL_PLAINTEXT", "SASL_SSL"}:
            required += [
                ("sasl_username", v.sasl_username),
                ("sasl_password", v.sasl_password.get_secret_value()),
            ]
        missing = [name for name, value in required if not value]
        if missing:
            raise ValueError(
                f"RISK_MODEL_KAFKA__{{{','.join(m.upper() for m in missing)}}} must be set when kafka.enabled=true"
            )
        return v

    @model_validator(mode="after")
    def _validate_restarter_stop_timeout(self) -> "Settings":
        """`t` рестарта не может быть меньше бюджета штатной остановки перезапускаемых процессов.

        Демон шлёт SIGKILL через `t` секунд после SIGTERM. Если `t` меньше, чем процесс закладывает
        на дренаж, остановка обрывается посередине: у `emr-consumer` между записью биомаркеров и
        публикацией команды пересчёта есть окно, и оборванный на нём процесс оставляет
        сохранённые значения без пересчёта риска.
        """
        budget = max(self.shutdown_timeout, self.consumer_shutdown_timeout)
        if self.restarter.stop_timeout_s < budget:
            raise ValueError(
                f"restarter.stop_timeout_s ({self.restarter.stop_timeout_s}s) must be >= "
                f"max(shutdown_timeout, consumer_shutdown_timeout) ({budget}s): "
                "a shorter budget lets Docker SIGKILL a process mid-drain"
            )
        return self

    _MIN_TEARDOWN_BUDGET: int = 5

    @model_validator(mode="after")
    def _validate_shutdown_delays(self) -> "Settings":
        max_grace = self.shutdown_timeout - self._MIN_TEARDOWN_BUDGET
        if self.shutdown_grace_delay > max_grace:
            raise ValueError(
                f"shutdown_grace_delay ({self.shutdown_grace_delay}s) must be <= "
                f"shutdown_timeout - {self._MIN_TEARDOWN_BUDGET} "
                f"({max_grace}s) to leave at least {self._MIN_TEARDOWN_BUDGET}s for teardown"
            )
        return self


settings = Settings()


class DatabaseConfigError(RiskBaseError, ValueError):
    """Процессу нужна строка подключения его database identity, а переменная не задана.

    `ValueError` остаётся в предках: это ошибка валидации конфигурации.
    """


def calculation_runtime_required() -> bool:
    """Нужно ли API-процессу второе подключение под логином расчёта.

    Два независимых потребителя, и хватает любого: инлайн-пересчёт при выключенной Kafka и
    синхронный запуск расчёта из testing-API. Оба пишут результаты, а профильному логину на них
    выдан только `SELECT, DELETE` через представления. В прод-конфигурации не выполняется ни одно
    условие: Kafka включена, testing-API выключен, пересчёт выполняет consumer-воркер.
    """
    return not settings.kafka.enabled or settings.testing_api_enabled


# Поле `Settings` со строкой подключения каждой роли. Имя переменной окружения выводится из имени
# поля (`RISK_MODEL_` + поле в верхнем регистре) — оно же попадает в сообщение об ошибке.
_DB_URL_FIELDS: dict[ServiceRuntime, str] = {
    ServiceRuntime.PROFILE: "profile_db_url",
    ServiceRuntime.CALCULATION: "calculation_db_url",
    ServiceRuntime.EHR: "ehr_db_url",
    ServiceRuntime.BULK_RECALC: "bulk_recalc_db_url",
}


def db_url_env(runtime: ServiceRuntime) -> str:
    """Имя переменной окружения со строкой подключения роли."""
    return f"RISK_MODEL_{_DB_URL_FIELDS[runtime].upper()}"


def require_db_url(runtime: ServiceRuntime) -> SecretStr:
    """Строка подключения роли. Проверяется на старте процесса, до первого соединения с БД.

    Пустое значение при загрузке `Settings` становится `None`, поэтому отказ здесь покрывает оба
    случая: переменной нет и переменная пустая.
    """
    url = getattr(settings, _DB_URL_FIELDS[runtime])
    if url is None:
        raise DatabaseConfigError(
            f"{db_url_env(runtime)} must be set and non-empty: the '{runtime.value}' runtime connects with it"
        )
    return url


# TODO(2026-09-30): добавлено 30.09.2026, когда строки подключения разнесены по переменным ролей.
# После 30.12.2026 окружения всех стендов вычищены от прежних переменных — константу и
# `notice_legacy_db_env` (вместе с её вызовами в точках входа) можно удалить.
LEGACY_DB_ENV_VARS: tuple[str, ...] = ("RISK_MODEL_DB_URL", "RISK_MODEL_SERVICE_RUNTIME")


def notice_legacy_db_env() -> None:
    """Сообщает о прежних переменных БД, оставшихся в окружении. Сами значения не читаются.

    Процесс их игнорирует: роль объявляет точка входа, строку подключения — переменная роли. В
    событие уходят только имена: в `RISK_MODEL_DB_URL` лежит пароль.
    """
    present = [name for name in LEGACY_DB_ENV_VARS if name in os.environ]
    if present:
        notice(
            "legacy database env variables are ignored",
            context={"variables": present, "action": "remove them from the environment"},
        )
