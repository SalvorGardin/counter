"""yappi-профилировщик под feature-flag (`settings.profiler`).

Стратегия — глобальный профайлер на весь процесс со скользящим окном хранения:

- при старте: `yappi.set_clock_type("wall")` + `yappi.start()` (wall-clock ловит и CPU,
  и ожидания I/O — БД/cvd/kafka, что нужно для анализа latency request-path);
- раз в `bucket_seconds` фоновая задача снимает срез (`get_func_stats`), сохраняет его
  ystat-бакетом и `clear_stats()` обнуляет счётчики;
- хранится не более `retention_minutes` (в бакетах) — старые удаляются. Так в памяти/на диске
  всегда лежит только недавнее окно, а не статистика с момента старта процесса;
- эндпоинт `/api/v1/debug/profile` сливает все бакеты + текущий незакрытый срез в один
  pstat-файл (`.prof`, читается snakeviz / gprof2dot / pstats).

Профилируется весь процесс, но в выдачу через `filter_callback` попадают только функции
проекта, относящиеся к 4 основным request-path и модулю `src/calc` — см.
`_PROFILED_PATH_FRAGMENTS`.

yappi-статистика копится per-process, поэтому при `enabled=True` приложение принудительно
запускается в один воркер (см. `src/__main__.py`).
"""

from __future__ import annotations

import asyncio
import cProfile
import math
import os
import shutil
import tempfile
from collections import deque
from pathlib import Path
from typing import Any

from src.logger import logger, notice

# Фрагменты путей модулей, попадающих в выдачу профайлера: модуль расчёта (src/calc)
# и 4 основные request-path (роутер + доменный код каждого). Всё остальное (fastapi,
# sqlalchemy, starlette, stdlib) отсекается, чтобы .prof содержал только наш код.
_PROFILED_PATH_FRAGMENTS: tuple[str, ...] = (
    "src/calc",
    "src/api/v1/risk_init",
    "src/services/risk_init",
    "src/api/v1/risk_profile",
    "src/services/risk_profile",
    "src/api/v1/risk_event",
    "src/services/risk_event",
    "src/api/v1/risk_communication",
    "src/services/risk_communication",
)


def _keep_project_func(stat: Any) -> bool:
    """filter_callback для yappi: оставляем только функции из профилируемых модулей проекта."""
    module = (getattr(stat, "module", "") or "").replace(os.sep, "/")
    return any(fragment in module for fragment in _PROFILED_PATH_FRAGMENTS)


def _empty_pstats_bytes() -> bytes:
    """Валидный пустой .prof — когда данных в окне ещё нет (yappi не умеет save пустого pstat)."""
    profiler = cProfile.Profile()
    profiler.enable()
    profiler.disable()
    fd, tmp_name = tempfile.mkstemp(suffix=".prof")
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        profiler.dump_stats(str(tmp))
        return tmp.read_bytes()
    finally:
        tmp.unlink(missing_ok=True)


class RollingProfiler:
    """Глобальный yappi-профайлер со скользящим окном из ystat-бакетов на диске."""

    def __init__(self, retention_minutes: int, bucket_seconds: int) -> None:
        self._bucket_seconds = bucket_seconds
        # Сколько бакетов держим в окне (минимум 1).
        self._max_buckets = max(1, math.ceil(retention_minutes * 60 / bucket_seconds))
        self._buckets: deque[Path] = deque()
        self._dir: Path | None = None
        self._task: asyncio.Task[None] | None = None
        # Сериализует ротацию (snapshot+clear) и слияние в эндпоинте — они оба трогают
        # глобальное состояние yappi и общий deque бакетов.
        self._lock = asyncio.Lock()
        self._seq = 0

    async def start(self) -> None:
        # Ленивый импорт: yappi — C-расширение, грузим его только в воркере, где профайлер
        # реально включён, а не во всех прод-воркерах при выключенном feature-flag (дефолт).
        import yappi  # noqa: PLC0415

        self._dir = Path(tempfile.mkdtemp(prefix="risk-profiler-"))
        yappi.set_clock_type("wall")
        yappi.start()
        self._task = asyncio.create_task(self._rotate_loop())
        notice(
            "profiler started",
            context={
                "clock": "wall",
                "retention_buckets": self._max_buckets,
                "bucket_seconds": self._bucket_seconds,
            },
        )

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        # Берём lock, чтобы дождаться завершения возможной in-flight ротации/слияния
        # (dump_pstats держит lock и await-ит to_thread) — иначе rmtree снёс бы каталог
        # из-под работающего в потоке _merge_window и тот упал бы на missing-file.
        import yappi  # noqa: PLC0415

        async with self._lock:
            yappi.stop()
            yappi.clear_stats()
            if self._dir is not None:
                shutil.rmtree(self._dir, ignore_errors=True)
                self._dir = None
            self._buckets.clear()
        notice("profiler stopped", context={})

    async def _rotate_loop(self) -> None:
        while True:
            await asyncio.sleep(self._bucket_seconds)
            try:
                await self._rotate()
            except Exception:
                # Сбой ротации не должен ронять фоновую задачу — иначе окно "застынет".
                logger.warning("profiler bucket rotation failed", exc_info=True)

    async def _rotate(self) -> None:
        import yappi  # noqa: PLC0415

        async with self._lock:
            if self._dir is None:
                return
            # get_func_stats/clear_stats трогают глобальное состояние yappi — держим на loop.
            # Дисковую запись и удаление старого бакета уводим в поток, чтобы не блокировать loop.
            stats = yappi.get_func_stats(filter_callback=_keep_project_func)
            yappi.clear_stats()
            path = self._dir / f"bucket-{self._seq:06d}.ystat"
            self._seq += 1
            await asyncio.to_thread(stats.save, str(path), "ystat")
            self._buckets.append(path)
            while len(self._buckets) > self._max_buckets:
                old = self._buckets.popleft()
                await asyncio.to_thread(old.unlink, missing_ok=True)

    def _merge_window(self, bucket_paths: list[Path], live: Any) -> bytes:
        """Слияние бакетов + текущего среза в pstat-байты. Только дисковые операции —
        выполняется в отдельном потоке (см. dump_pstats), без обращений к глобальному yappi."""
        import yappi  # noqa: PLC0415

        merged = yappi.YFuncStats()
        for bucket in bucket_paths:
            merged.add(str(bucket), type="ystat")

        # Текущий ещё не сброшенный срез: сохраняем во временный ystat и подмешиваем.
        if self._dir is not None:
            live_path = self._dir / "live.ystat"
            try:
                live.save(str(live_path), type="ystat")
                merged.add(str(live_path), type="ystat")
            finally:
                live_path.unlink(missing_ok=True)

        if not list(merged):
            return _empty_pstats_bytes()

        out = (self._dir or Path(tempfile.gettempdir())) / "merged.prof"
        try:
            merged.save(str(out), type="pstat")
            return out.read_bytes()
        finally:
            out.unlink(missing_ok=True)

    async def dump_pstats(self, reset: bool = False) -> bytes:
        """Слить окно (бакеты + текущий незакрытый срез) в один pstat и вернуть его байты."""
        import yappi  # noqa: PLC0415

        async with self._lock:
            bucket_paths = [bucket for bucket in self._buckets if bucket.exists()]
            # Снимок текущего среза трогает глобальный yappi — забираем на loop, дальше только файлы.
            live = yappi.get_func_stats(filter_callback=_keep_project_func)
            data = await asyncio.to_thread(self._merge_window, bucket_paths, live)

            if reset:
                for bucket in self._buckets:
                    await asyncio.to_thread(bucket.unlink, missing_ok=True)
                self._buckets.clear()
                yappi.clear_stats()

            return data
