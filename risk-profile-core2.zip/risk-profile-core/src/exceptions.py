class RiskBaseError(Exception):
    pass


class DbOperationError(RiskBaseError):
    def __init__(self, message: str, *, cause: BaseException, attempts: int) -> None:
        super().__init__(message)
        self.cause = cause
        self.attempts = attempts


class RetriableDbError(DbOperationError):
    pass


class NonRetriableDbError(DbOperationError):
    pass
