"""Условие срабатывания фактора риска — единственная реализация сравнения на весь сервис.

Условие сравнивается в трёх местах: при отборе факторов интерпретации (`rank_risk_factors`, §4.3),
при расчёте клинрек-факторов биомаркеров и при чтении объяснения, где снимок условия из
`risk_factor_matches` перепроверяется на текущих ответах пациента. Стороны работают с разными
типами (`RiskFactorRow`, `RiskFactorTriggerDTO`, `RiskFactorMatchView`), но с одним и тем же
набором полей условия, поэтому сравнение описано здесь через протокол: смена семантики оператора
(например, включительности границ `between`) не может попасть в одно место и не попасть в другое.

Модуль нейтрален к домену: он не импортирует ни calc, ни interpretation, ни infra — только общий
разбор числового ответа. Так одну реализацию может звать любая доменная ветка, не заводя
зависимости на чужой домен.
"""

from decimal import Decimal
from enum import StrEnum
from typing import Protocol

from src.utils.numeric import parse_answer_decimal


class RiskFactorOperator(StrEnum):
    """Stored vocabulary for normalized risk-factor trigger conditions."""

    EQ = "eq"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    BETWEEN = "between"


class TriggerCondition(Protocol):
    """Поля условия срабатывания — общая часть строки справочника и её снимка в диагностике."""

    @property
    def operator(self) -> str: ...

    @property
    def value_num(self) -> Decimal | None: ...

    @property
    def min_value(self) -> Decimal | None: ...

    @property
    def max_value(self) -> Decimal | None: ...

    @property
    def value_text(self) -> str | None: ...

    @property
    def gender(self) -> str | None: ...


class ParameterCondition(TriggerCondition, Protocol):
    """Условие вместе с кодом параметра, по которому берётся ответ пациента.

    Нужен там, где условия проверяются не по одному заранее известному параметру, а по снимку
    ответов: сторона сама достаёт значение по `parameter_code` и передаёт его в сравнение.
    """

    @property
    def parameter_code(self) -> str: ...


def condition_matches(condition: TriggerCondition, value: str, gender: str | None) -> bool:
    """Сработало ли условие на ответе пациента.

    Пустой `gender` в условии означает «без ограничения по полу»; заполненный требует точного
    совпадения с полом пациента — при неизвестном поле такое условие не срабатывает.
    """
    if condition.gender is not None and condition.gender != gender:
        return False
    if condition.operator == RiskFactorOperator.EQ:
        return value == condition.value_text
    number = parse_answer_decimal(value)
    if number is None:
        return False
    if condition.operator == RiskFactorOperator.GTE:
        return condition.value_num is not None and number >= condition.value_num
    if condition.operator == RiskFactorOperator.GT:
        return condition.value_num is not None and number > condition.value_num
    if condition.operator == RiskFactorOperator.LTE:
        return condition.value_num is not None and number <= condition.value_num
    if condition.operator == RiskFactorOperator.LT:
        return condition.value_num is not None and number < condition.value_num
    # `between` включает обе границы.
    return (
        condition.operator == RiskFactorOperator.BETWEEN
        and condition.min_value is not None
        and condition.max_value is not None
        and condition.min_value <= number <= condition.max_value
    )
