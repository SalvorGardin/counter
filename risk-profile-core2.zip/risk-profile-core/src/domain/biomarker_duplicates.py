"""Отсев повторных представлений биомаркера в выборке одного инструмента."""

from collections.abc import Collection, Iterable, Mapping
from datetime import datetime
from typing import Protocol


class ParameterRow(Protocol):
    """Минимальный общий контракт снимков расчёта и интерпретации."""

    @property
    def parameter_code(self) -> str: ...

    @property
    def date_time(self) -> datetime: ...

    @property
    def patient_parameter_id(self) -> int: ...

    @property
    def value(self) -> str | None: ...


class ParameterValueRow(ParameterRow, Protocol):
    """Строка снимка с непустым значением параметра."""

    @property
    def value(self) -> str: ...


def excluded_biomarker_parameter_codes(
    rows: Iterable[ParameterRow],
    instrument_code: str,
    parameter_codes_by_instrument: Mapping[str, Collection[str]],
    biomarker_code_by_parameter: Mapping[str, int],
    competing_parameter_codes: Collection[str],
    required_parameter_codes_by_instrument: Mapping[str, Collection[str]],
) -> frozenset[str]:
    """Возвращает вытесненные коды параметров в выборке одного инструмента.

    Для каждого кода биомаркера остаётся строка, наибольшая по порядку
    `is_required DESC, date_time DESC, patient_parameter_id ASC`: обязательный для ЭТОГО
    инструмента параметр не вытесняется более свежей записью необязательного, иначе инструмент
    пропускался бы по нехватке параметра, запись которого у пациента есть. Порядок задан кортежем
    сравнения, а не отдельным проходом по обязательным записям: второе место, где живёт порядок
    отбора, разошлось бы с первым при следующей правке. Параметры без однозначного кода биомаркера
    не участвуют.

    Строка с пустым значением — пропущенный вопрос — в выборку калькулятора не входит, поэтому в
    отсеве не участвует: иначе пропуск, записанный позже, вытеснял бы настоящее значение.
    """
    instrument_parameters = parameter_codes_by_instrument.get(instrument_code, ())
    required_parameters = required_parameter_codes_by_instrument.get(instrument_code, ())
    # Ранг сравнивается как кортеж, поэтому «меньший id выигрывает» записан отрицательным id.
    winners: dict[int, tuple[tuple[bool, datetime, int], ParameterRow]] = {}
    excluded: set[str] = set()

    for row in rows:
        if not row.value:
            continue
        parameter_code = row.parameter_code
        if parameter_code not in instrument_parameters or parameter_code not in competing_parameter_codes:
            continue
        biomarker_code = biomarker_code_by_parameter.get(parameter_code)
        if biomarker_code is None:
            continue
        rank = (parameter_code in required_parameters, row.date_time, -row.patient_parameter_id)
        winner = winners.get(biomarker_code)
        if winner is None:
            winners[biomarker_code] = (rank, row)
            continue
        winner_rank, winner_row = winner
        if rank > winner_rank:
            excluded.add(winner_row.parameter_code)
            winners[biomarker_code] = (rank, row)
        else:
            excluded.add(parameter_code)

    return frozenset(excluded)


def instrument_parameter_values(
    parameters: Mapping[str, ParameterValueRow],
    instrument_parameters: Collection[str],
    excluded_parameter_codes: Collection[str],
) -> dict[str, str]:
    """Значения снимка в выборке одного инструмента без вытесненных повторов биомаркера."""
    return {
        code: row.value
        for code, row in parameters.items()
        if code in instrument_parameters and code not in excluded_parameter_codes
    }
