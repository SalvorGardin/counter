"""Контракт сообщения-команды пересчёта (топик `recalc_commands`).

Единый источный правды кодирования/декодирования между продюсером (`dispatch_recalc`,
API-процесс) и консюмером (`src/workers/calc_consumer.py`, воркер-процесс).

Семантика `parameter_codes`:
    None        → полный пересчёт (все активные инструменты)        → JSON `parameterCodes: null`
    {"a", "b"}  → частичный пересчёт по инструментам этих параметров → JSON `parameterCodes: ["a","b"]`
Пустой set командой не публикуется (диспетчер коротит его в no-op до публикации).

`background` — необязательный признак фоновой команды: её опубликовал массовый прогон пересчёта
(`src/workers/bulk_recalc`), а не пользовательский сценарий. Команда БЕЗ признака считается
пользовательской и обрабатывается приоритетно; фоновую воркер вправе отбросить без расчёта
(см. `src/calc/background_admission.py`). Поле совместимо в обе стороны: разбор неизвестные ключи
игнорирует, поэтому во время раската воркер прошлой версии посчитает фоновую команду как обычную.

`enqueuedAt` — необязательная отметка постановки команды в очередь (секунды Unix-эпохи с дробной
частью, часы процесса-продюсера). Служит только замерам времени пересчёта: продюсер и консюмер
живут в разных процессах, поэтому отметка настенная, а не монотонная. Команда без поля (старое
сообщение, сторонний продюсер) обрабатывается как обычно, просто без замера.
"""

import math
from dataclasses import dataclass
from typing import Any, cast

# messageType команды — отличает её от событий-результатов (calculation/interpretation)
# в топике risk_calculation, если кто-то перепутает топики при отладке.
RECALC_MESSAGE_TYPE = "recalc"

_CLIENT_ID_KEY = "clientId"
_PARAMETER_CODES_KEY = "parameterCodes"
_MESSAGE_TYPE_KEY = "messageType"
_ENQUEUED_AT_KEY = "enqueuedAt"
_BACKGROUND_KEY = "background"


@dataclass(frozen=True, slots=True)
class RecalcCommand:
    """Разобранная команда пересчёта.

    Структура, а не кортеж: полей стало четыре, и распаковка по позиции на стороне воркера
    молча поехала бы при добавлении следующего.
    """

    patient_id: str
    parameter_codes: set[str] | None
    enqueued_at: float | None
    # True только у команды массового прогона. Отсутствие и непригодное значение признака дают
    # False: команда пересчёта клинического риск-профиля не должна терять приоритет из-за
    # кривого поля приоритета.
    background: bool


class RecalcMessageError(ValueError):
    """Невалидный payload команды пересчёта (битый JSON-объект, отсутствует/кривой clientId)."""


def encode_command(
    patient_id: str,
    parameter_codes: set[str] | None,
    enqueued_at: float | None = None,
    *,
    background: bool = False,
) -> dict[str, Any]:
    """Сериализует команду пересчёта в JSON-совместимый dict.

    set не сериализуется в JSON — отдаём отсортированный список (детерминизм + читаемость в логах).

    `enqueued_at` — отметка постановки в очередь; ключ сериализуется всегда (`null` при None),
    симметрично `parameterCodes`. Часы читает вызывающий, а не эта функция: так она остаётся
    чистой и детерминированной.

    `background` сериализуется тоже всегда — по той же причине симметрии. Дефолт False: команду
    без явного признака обязан порождать пользовательский путь, а не наоборот.
    """
    return {
        _CLIENT_ID_KEY: patient_id,
        _PARAMETER_CODES_KEY: sorted(parameter_codes) if parameter_codes is not None else None,
        _MESSAGE_TYPE_KEY: RECALC_MESSAGE_TYPE,
        _ENQUEUED_AT_KEY: enqueued_at,
        _BACKGROUND_KEY: background,
    }


def _enqueued_at(raw: Any) -> float | None:
    """Отметка постановки в очередь из сырого значения; всё непригодное — `None`.

    `bool` отсекаем явно: он подтип `int`, но отметкой времени не является. NaN/Inf отсекаем,
    потому что они отравили бы арифметику замера (разность дала бы NaN в гистограмме).

    Неположительные значения отсекаем по той же причине, что и NaN: отметка на эпохе или раньше
    неё — не время постановки команды, а разность с ней даёт десятилетия. Обрезка отрицательных
    значений в замере от такого не спасает (она страхует только противоположный случай — отметку
    из будущего), а одно аномальное наблюдение искажает `_sum` гистограммы до рестарта процесса.
    """
    if isinstance(raw, bool) or not isinstance(raw, int | float):
        return None
    return float(raw) if math.isfinite(raw) and raw > 0 else None


def decode_command(value: Any) -> RecalcCommand:
    """Разбирает payload команды в `RecalcCommand`.

    Бросает `RecalcMessageError` на структурно невалидном сообщении (poison message) —
    консюмер такие пропускает и коммитит, чтобы не блокировать очередь.

    `enqueued_at` из этого правила исключён: поле необязательное и служит только замерам времени
    пересчёта. Отсутствие ключа, `null`, строка, `bool`, NaN/Inf, неположительное число — всё это
    даёт `None` (пересчёт идёт без замера), но НЕ делает сообщение poison: ронять команду
    клинического пересчёта из-за отметки времени нельзя.

    `background` исключён по той же причине: отсутствие ключа и непригодное (не булево) значение
    дают False, то есть команда обрабатывается как пользовательская — приоритетно.

    Фоновая команда всегда полная: массовый прогон частичных не публикует, и на этом держится
    отсутствие рядов `scope="partial"` × `source="background"` в метриках (см. `src/metrics.py`).
    Сочетание признака с непустым `parameterCodes` приходит, значит, не от прогона, и признак у
    такой команды сбрасывается: частичный пересчёт считается как пользовательский. Отбрасывать её
    как poison нельзя по той же причине — это команда клинического пересчёта.
    """
    if not isinstance(value, dict):
        raise RecalcMessageError(f"recalc command must be a JSON object, got {type(value).__name__}")

    # messageType намеренно не проверяем как фильтр маршрутизации: топик recalc_commands —
    # выделенный (single-purpose), поле информационное (отладка/совместимость). Жёсткий reject
    # неизвестных типов сломал бы forward-compat, если появятся новые типы команд (ревью !79, 2457).
    patient_id = value.get(_CLIENT_ID_KEY)
    if not isinstance(patient_id, str) or not patient_id:
        raise RecalcMessageError("recalc command missing non-empty clientId")

    enqueued_at = _enqueued_at(value.get(_ENQUEUED_AT_KEY))
    raw_background = value.get(_BACKGROUND_KEY)
    background = raw_background if isinstance(raw_background, bool) else False

    raw_codes = value.get(_PARAMETER_CODES_KEY)
    if raw_codes is None:
        return RecalcCommand(patient_id, None, enqueued_at, background)
    if not isinstance(raw_codes, list) or not all(isinstance(c, str) for c in raw_codes):
        raise RecalcMessageError("recalc command parameterCodes must be null or a list of strings")
    # Элементы провалидированы выше как str; cast снимает сужение до set[object].
    return RecalcCommand(patient_id, cast(set[str], set(raw_codes)), enqueued_at, background=False)
