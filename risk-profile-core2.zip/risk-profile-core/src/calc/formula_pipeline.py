from collections.abc import Collection, Mapping

from src.calc.domain.exceptions import FormulaCalculationError
from src.calc.domain.formula import Formula
from src.calc.domain.formula_policy import resolve_formula_input
from src.calc.domain.formulas.airi_ssz import AiriSszFormula
from src.calc.domain.models import (
    CalcReasonCode,
    CalcRejection,
    FormulaResult,
    InstrumentDefinition,
    InstrumentInput,
    InstrumentsCodes,
)
from src.calc.infra.cvd_client import CvdClient, CvdServiceError
from src.calc.outcomes import CalcRunResult, ResultBatch
from src.calc.status_collector import CalcStatusCollector
from src.calc.timings import StepTimings
from src.calc.tracing import trace
from src.logger import logger


class FormulaPipeline:
    """Config-driven formula computation for one patient.

    Walks the configured formula instruments (or, on a partial recalc, the requested subset),
    builds each input, applies the pregnancy + applicability gates, and appends results to the
    batch. airi_ssz is computed via the external cvd service. Instruments that can't be computed —
    missing required parameters for a non-pregnant patient, or a calculation error — are left
    without a result and increment the run's skipped counter.

    `unsupported_codes` — активные инструменты типа `calc`, формулы для которых в реестре нет.
    Считать их нечем, поэтому pipeline отчитывается по ним ошибкой (один раз на прогон) и
    пропускает КАЖДЫЙ ПО ОТДЕЛЬНОСТИ: остальные инструменты пациента считаются как обычно.
    """

    def __init__(
        self,
        formula: Formula,
        cvd: CvdClient | None,
        configs: Mapping[str, InstrumentDefinition],
        statuses: CalcStatusCollector,
        unsupported_codes: Collection[str] = (),
    ) -> None:
        self._formula = formula
        self._cvd = cvd
        self._configs = configs
        self._unsupported_codes = tuple(sorted(unsupported_codes))
        # Дефект справочника один на прогон, а не на пациента: ERROR о нём пишется один раз,
        # иначе полный пересчёт превратил бы одну строку справочника в ERROR на каждого
        # пациента пачки и утопил бы остальные логи прогона.
        self._unsupported_reported: set[str] = set()
        # Коллектор вызывается безусловно: проверка флага сбора — внутри его методов, чтобы
        # состояние флага не создавало ветвлений на боевом пути расчёта.
        self._statuses = statuses

    async def process(
        self,
        patient_id: str,
        patient_values: dict[str, str | None],
        is_pregnant: bool,
        allowed_instruments: frozenset[str] | None,
        batch: ResultBatch,
        outcome: CalcRunResult,
        timings: StepTimings,
        excluded_by_instrument: Mapping[str, Collection[str]] | None = None,
    ) -> None:
        formula = self._formula  # Hoist out of the per-instrument loop.
        excluded = excluded_by_instrument or {}
        if allowed_instruments is None:
            candidates = self._configs.items()
        else:
            # Partial recalc: walk only the requested instruments that run a formula.
            candidates = [(c, self._configs[c]) for c in allowed_instruments if c in self._configs]

        statuses = self._statuses
        self._report_unsupported(patient_id, allowed_instruments, outcome)
        for instrument_code, definition in candidates:
            excluded_codes = excluded.get(instrument_code, ())
            # Pregnancy gate lives in formula_policy.resolve_formula_input.
            resolved = resolve_formula_input(
                definition,
                patient_values,
                is_pregnant,
                patient_id,
                excluded_parameter_codes=excluded_codes,
            )
            if isinstance(resolved, CalcRejection):
                statuses.record_rejection(patient_id, instrument_code, resolved)
                # Non-pregnant patient with missing required params. Вырожденный случай устаревшей
                # интерпретации (для формул сознательно НЕ чиним — в отличие от симметричного блока
                # очистки опросников ниже). Если по этому инструменту уже лежит строка results
                # (например, not_required-заглушка, записанная во время беременности), а параметров
                # всё ещё нет — пропускаем его и НЕ добавляем его системы в `affected`. Интерпретация
                # по системе не перезапустится, и старая «не применимо (беременность)» висит до
                # следующего полноценного расчёта по любому инструменту этой системы. Окно
                # закрывается само в обычном потоке; «навсегда» — только если по системе больше
                # никогда ничего не считается.
                outcome.skipped += 1
                continue

            input = resolved
            trace("calc.formula: attempt", instrument_code=instrument_code, patient_id=patient_id)

            applicable = formula.is_applicable(input)
            # Причина неприменимости считается один раз на инструмент и БЕЗ гейта debug_enabled():
            # она нужна не только DEBUG-логу, но и диагностическому статусу, который собирается
            # независимо от режима логирования запроса.
            inapplicability = None if applicable else formula.inapplicability_reason(input)
            if inapplicability is not None:
                trace(
                    "calc.formula: inapplicable",
                    instrument_code=instrument_code,
                    patient_id=patient_id,
                    reason=inapplicability,
                )

            try:
                if not applicable:
                    formula_result = formula.make_dummy(input)
                elif instrument_code == InstrumentsCodes.AIRI_SSZ:
                    # Единственный инструмент с внешним вызовом — меряем его отдельным шагом.
                    # Шаг закрывается и на упавшем запросе: время потрачено (см. StepTimings.cvd_ms).
                    with timings.step("cvd"):
                        formula_result = await self._calculate_airi(input)
                else:
                    formula_result = formula.calculate(input)
            except FormulaCalculationError as e:
                # Специфичную причину сбоя cvd уже зарегистрировал `_calculate_airi`; здесь
                # остаётся общий код — первая запись по паре выигрывает (см. коллектор).
                statuses.record_rejection(
                    patient_id, instrument_code, CalcRejection(reason_code=CalcReasonCode.CALCULATION_ERROR)
                )
                logger.error(
                    "calc.formula: calculation failed",
                    extra={
                        "log_context": {
                            "instrument_code": instrument_code,
                            "patient_id": patient_id,
                            "error": str(e.cause),
                        }
                    },
                    exc_info=e,
                )
                outcome.skipped += 1
                continue

            if inapplicability is not None:
                statuses.record_rejection(patient_id, instrument_code, CalcRejection(reason_code=inapplicability))
            else:
                # `cvd_disabled` регистрируется глубже (в `_calculate_airi`) и этой записью
                # не затирается: заглушка выключенного сервиса расчётом не является.
                statuses.record_calculated(patient_id, instrument_code)
            batch.add(formula_result, instrument_code)

    def _report_unsupported(
        self, patient_id: str, allowed_instruments: frozenset[str] | None, outcome: CalcRunResult
    ) -> None:
        """Инструмент типа `calc` без формулы в реестре: ошибка в лог, пустой результат, идём дальше.

        Это дыра в справочнике, а не клиническая неприменимость: тихий пропуск оставил бы пациента
        без показателя и без следа. Отказ и счётчик — поштучные, по каждому пациенту: по ним
        считают охват. ERROR — один на прогон и на код инструмента: он описывает справочник, а не
        пациента, и повтор его на каждом пациенте пачки только прятал бы остальные логи. Значения
        параметров в контекст НЕ кладутся — в логе только код инструмента.
        """
        for instrument_code in self._unsupported_codes:
            if allowed_instruments is not None and instrument_code not in allowed_instruments:
                continue
            self._statuses.record_rejection(
                patient_id, instrument_code, CalcRejection(reason_code=CalcReasonCode.CALCULATION_ERROR)
            )
            outcome.skipped += 1
            if instrument_code not in self._unsupported_reported:
                self._unsupported_reported.add(instrument_code)
                logger.error(
                    "calc.formula: unsupported calc instrument",
                    extra={"log_context": {"instrument_code": instrument_code}},
                )

    async def _calculate_airi(self, input: InstrumentInput) -> FormulaResult:
        """Расчёт airi_ssz через внешний сервис: факторы риска (домен) → вызов cvd → результат (домен).

        cvd выключен в конфиге → ожидаемое состояние (не сбой): make_dummy, без ERROR-лога.
        Сбой включённого сервиса → FormulaCalculationError (инструмент пропускается, без тихого 0).

        Оба исхода регистрируются здесь, а не у вызывающего: выше по стеку выключенный сервис
        неотличим от заглушки по клиническим рамкам, а его сбой — от любой другой ошибки расчёта.
        Обе записи переживают более общие записи вызывающего (первая запись по паре выигрывает).
        """
        if self._cvd is None:
            self._statuses.record_rejection(
                input.patient_id, input.instrument_code, CalcRejection(reason_code=CalcReasonCode.CVD_DISABLED)
            )
            dummy = self._formula.make_dummy(input)
            assert isinstance(dummy, FormulaResult)
            return dummy
        risk_factors = AiriSszFormula.build_risk_factors(input)
        try:
            risk_percentage = await self._cvd.calculate(risk_factors)
        except CvdServiceError as e:
            self._statuses.record_rejection(
                input.patient_id, input.instrument_code, CalcRejection(reason_code=CalcReasonCode.CVD_ERROR)
            )
            raise FormulaCalculationError(input.instrument_code, e) from e
        return AiriSszFormula.to_result(input, risk_percentage)
