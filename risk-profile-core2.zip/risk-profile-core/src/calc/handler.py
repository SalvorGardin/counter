from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.calc.biomarker_pipeline import BiomarkerClinrecPipeline
from src.calc.domain.biomarker_clinrec import DiseaseResultState
from src.calc.domain.formula import Formula
from src.calc.domain.models import (
    CalculationRequest,
    InstrumentDefinition,
    PatientParameterRow,
    QuestionnaireEligibility,
    QuestionnaireScoreRow,
    normalize_calculation_requests,
)
from src.calc.domain.questionnaire import QuestionnaireCalculator
from src.calc.formula_pipeline import FormulaPipeline
from src.calc.infra.cvd_client import CvdClient, get_cvd_client
from src.calc.infra.reader import CalcReader, active_parameters_by_patient
from src.calc.infra.repository import CalcRepository
from src.calc.outcomes import CalcRunResult, ResultBatch
from src.calc.questionnaire_pipeline import QuestionnairePipeline
from src.calc.status_collector import CalcStatusCollector
from src.calc.timings import _DISABLED_TIMINGS, LoadTimings, StepTimings
from src.config import settings
from src.domain.biomarker_duplicates import excluded_biomarker_parameter_codes
from src.infra.catalog.calc import CalcCatalog
from src.infra.catalog.interpretation import InterpretationCatalog
from src.infra.db_retry import TransactionalRetryExecutor, tolerate_retriable_db_error
from src.infra.kafka.producer import KafkaProducer
from src.infra.patients.dtos import ActiveParameter
from src.infra.step_timings import resolve_sink
from src.interpretation.handler import InterpretationHandler
from src.logger import logger, notice

__all__ = ["CalcHandler"]


@dataclass(frozen=True)
class LoadedCalcData:
    """Everything read for one calc dispatch, plus the derived views the per-patient loop walks.

    Produced once by `CalcHandler._load`; the loop depends on this single object instead of a
    dozen loose locals. `instrument_filter[patient]` is None when all instruments are allowed,
    or a set for a partial recalc.
    """

    patient_ids: list[str]
    instrument_filter: dict[str, frozenset[str] | None]
    # configs/system_codes — read-only вью каталога (не копии), см. CalcReader; отдаём как Mapping.
    configs: Mapping[str, InstrumentDefinition]
    # patients.is_pregnant как есть: None = не отвечала (см. CalcReader.load_patient_snapshot).
    patient_data: dict[str, bool | None]
    grouped: dict[str, dict[str, str | None]]
    active_parameters: dict[str, dict[str, ActiveParameter]]
    # patient_id → instrument_code → параметры, исключённые из выборки инструмента как повторы
    # одного биомаркера. Есть только у пар, где отсев что-то исключил.
    excluded_by_patient: dict[str, dict[str, frozenset[str]]]
    # formula/questionnaire_configs — как и `configs`, read-only вью каталога: разбиение инструментов
    # по типу расчёта выводится из справочника и свёрнуто на его сборке (см. CalcCatalog).
    formula_configs: Mapping[str, InstrumentDefinition]
    questionnaire_configs: Mapping[str, InstrumentDefinition]
    # Активные инструменты типа `calc` без формулы в реестре: считать их нечем, но пропускать
    # молча нельзя — каждый даёт ERROR и пустой результат по себе одному.
    unsupported_calc_codes: frozenset[str]
    biomarker_configs: Mapping[str, InstrumentDefinition]
    # patient_id → disease_code → бизнес-состояние уже записанной строки `biomarker_kr`.
    # Пациента без строк в словаре нет — расчёт трактует отсутствие как «строк ещё нет».
    existing_biomarker_results: dict[str, dict[str, DiseaseResultState]]
    questionnaire_scores: dict[tuple[str, str], QuestionnaireScoreRow]
    eligibility: dict[tuple[str, str], QuestionnaireEligibility]
    system_codes: Mapping[str, tuple[str, ...]]
    existing_result_keys: frozenset[tuple[str, str]]


def _build_excluded_by_patient(
    rows: list[PatientParameterRow],
    catalog: CalcCatalog,
) -> dict[str, dict[str, frozenset[str]]]:
    """Отсев повторов биомаркера по уже прочитанному снимку.

    Строки с конкурирующим кодом параметра группируются по пациенту, а для каждого инструмента,
    затронутого этими кодами, отсев считается по своей выборке (см.
    src/domain/biomarker_duplicates.py). Пациент/инструмент попадают в результат, только если
    отсев что-то исключил — пустых записей результат не содержит. Каждое непустое исключение
    также пишется в лог notice-уровня — иначе разбор спорного результата расчёта был бы возможен
    только через отдельный вызов explanation-API.
    """
    competing_rows_by_patient: dict[str, list[PatientParameterRow]] = defaultdict(list)
    competing_codes = catalog.competing_biomarker_parameter_codes
    for row in rows:
        if row.parameter_code in competing_codes:
            competing_rows_by_patient[row.patient_id].append(row)

    excluded_by_patient: dict[str, dict[str, frozenset[str]]] = {}
    for patient_id, competing_rows in competing_rows_by_patient.items():
        instrument_codes = catalog.instrument_codes_for_parameters({row.parameter_code for row in competing_rows})
        for instrument_code in instrument_codes:
            excluded = excluded_biomarker_parameter_codes(
                competing_rows,
                instrument_code,
                catalog.parameter_codes_by_instrument,
                catalog.biomarker_code_by_parameter,
                competing_codes,
                catalog.required_parameter_codes_by_instrument,
            )
            if excluded:
                excluded_by_patient.setdefault(patient_id, {})[instrument_code] = excluded
                notice(
                    "calc.biomarker_duplicates: excluded",
                    {
                        "patient_id": patient_id,
                        "instrument_code": instrument_code,
                        "excluded_parameter_codes": sorted(excluded),
                    },
                )
    return excluded_by_patient


class CalcHandler:
    def __init__(
        self,
        session: AsyncSession,
        catalog: CalcCatalog,
        kafka_producer: KafkaProducer | None = None,
        cvd_client: CvdClient | None = None,
        *,
        interpretation_catalog: InterpretationCatalog,
        status_collector: CalcStatusCollector | None = None,
        session_factory: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        self._session = session
        self._catalog = catalog
        self._reader = CalcReader(session, catalog)
        self._repo = CalcRepository(session)
        self._formula = Formula()
        self._questionnaire = QuestionnaireCalculator()
        self._executor = TransactionalRetryExecutor(session)
        self._kafka = kafka_producer
        self._interpretation_catalog = interpretation_catalog
        # Резидентный клиент cvd-сервиса (None если cvd выключен) — для async-калькулятора airi_ssz.
        self._cvd = cvd_client if cvd_client is not None else get_cvd_client()
        # Диагностический сбор статусов. Создаётся всегда: он сам no-op при выключенном флаге,
        # поэтому ни один call-site не проверяет состояние сбора. Своя сессия (не `session`) —
        # запись идёт отдельной транзакцией после коммита результатов.
        # Фабрика сессий диагностических записей приходит сверху: собственные транзакции сбора
        # обязаны идти под той же ролью БД, что и сам расчёт (в API-процессе это НЕ роль профиля).
        self._session_factory = session_factory
        self._statuses = status_collector if status_collector is not None else CalcStatusCollector(session_factory)

    async def run(
        self,
        requests: list[CalculationRequest],
        *,
        timings: StepTimings | None = None,
    ) -> CalcRunResult:
        """Пересчитывает пациентов и возвращает единый исход запуска.

        `processed_codes` содержит коды успешно закоммиченных инструментов в порядке расчёта.
        Счётчики `processed` / `skipped` / `failed` позволяют вызывающему отличить пустой успешный
        запуск от сбоя записи без отдельного изменяемого sink-аргумента.

        `timings` — необязательный sink для по-шаговых замеров (load / formula / questionnaire /
        upsert / interpretation). Боевые вызывающие не передают ничего. Сам сбор — за флагом
        `settings.step_timings_enabled` (по умолчанию выключен): при выключенном флаге не
        выполняется ни одного `perf_counter` и не аллоцируется ни одного sink'а, даже если
        вызывающий его передал. Playground передаёт свой `StepTimings` (и включает флаг через env)
        и агрегирует их по командам.

        """
        # Состояние сбора читаем один раз на диспатч и раздаём каскадом по вложенным sink'ам.
        # Переданный sink узнаёт реальное состояние — по нему playground печатает «disabled».
        # `ran` отмечает сам факт входа в хендлер и не зависит от сбора: по нему playground
        # отличает выключенный сбор от команд, до которых хендлер не дошёл. Пишем только в
        # переданный sink — `_DISABLED_TIMINGS` общий, в него нельзя писать.
        if timings is not None:
            timings.enable(settings.step_timings_enabled)
            timings.ran = True
        t = resolve_sink(timings, _DISABLED_TIMINGS)
        normalized_requests = normalize_calculation_requests(requests)
        with t.step("load"):
            data = await self._load(normalized_requests, t.load)

        notice(
            "calc.run: started",
            {"patient_count": len(data.patient_ids), "instrument_count": len(data.configs)},
        )

        outcome = CalcRunResult()
        affected: dict[str, set[str]] = defaultdict(set)

        # Hoist instance-attribute lookups out of the per-patient loop — each `self.x` is an
        # attribute resolution; bind once to locals.
        executor = self._executor
        upsert_results_batch = self._repo.upsert_results_batch
        publish = self._publish

        system_codes = data.system_codes

        statuses = self._statuses
        formula_pipeline = FormulaPipeline(
            self._formula, self._cvd, data.formula_configs, statuses, data.unsupported_calc_codes
        )
        biomarker_pipeline = BiomarkerClinrecPipeline(
            data.biomarker_configs,
            self._catalog.biomarker_parameter_codes,
            self._catalog.biomarker_triggers_by_factor,
            self._catalog.clinrec_diseases_by_factor,
            self._catalog.system_code_by_disease,
        )
        questionnaire_pipeline = QuestionnairePipeline(
            self._questionnaire,
            data.questionnaire_configs,
            data.eligibility,
            data.questionnaire_scores,
            data.existing_result_keys,
            statuses,
        )

        for patient_id in data.patient_ids:
            batch = await self._process_patient(
                patient_id, data, formula_pipeline, questionnaire_pipeline, biomarker_pipeline, outcome, t
            )
            if not batch.results:
                # Считать по пациенту было нечего — статусы всё равно записываем: «инструмент
                # пропущен, потому что …» и есть тот случай, ради которого сбор заведён.
                await statuses.flush_patient(patient_id)
                continue

            # One transaction per patient. All-or-nothing: a DB failure (after retries) rolls back
            # this patient's whole batch — nothing published, no interpretation, the idempotent
            # retry reruns it cleanly. Other patients are isolated (their own batch/transaction).
            # Шаг закрывается независимо от исхода: время потрачено и при откате.
            with t.step("upsert"):
                # Транзиентный сбой изолирован пациентом: идемпотентный повтор команды перезапишет
                # его батч. Перманентный (NonRetriable) проходит наружу — он повторится на каждом
                # следующем пациенте, и прогон обязан оборваться трассировкой, а не намолотить
                # `failed` по всему списку.
                with tolerate_retriable_db_error(
                    "calc.upsert_batch: failed", patient_id=patient_id, result_count=len(batch.results)
                ) as upsert:
                    await executor.run(upsert_results_batch, batch.results)
                if upsert.failed:
                    # Батч результатов откатился — статусы по пациенту не пишем: они описывали бы
                    # расчёт, которого в базе нет.
                    statuses.discard_patient(patient_id)
                    outcome.failed += len(batch.publish_codes)
                else:
                    outcome.processed += len(batch.publish_codes)
                    outcome.processed_codes.extend(batch.publish_codes)
                    for instrument_code in batch.publish_codes:
                        # Область интерпретации спрашиваем у батча: у `biomarker_kr` она уже
                        # каталожной — только системы изменившихся групп заболеваний. Событие
                        # расчёта при этом несёт ВСЕ системы инструмента, как и раньше.
                        affected[patient_id].update(batch.interpretation_systems(instrument_code, system_codes))
                        publish(patient_id, instrument_code, system_codes)

            # Строго после успешного коммита результатов и ВНЕ его транзакции (шаг `upsert` уже
            # закрыт): у диагностики не должно быть способа задержать или откатить `results`.
            await statuses.flush_patient(patient_id)

        if affected:
            with t.step("interpretation"):
                interp = InterpretationHandler(
                    self._session,
                    catalog=self._interpretation_catalog,
                    session_factory=self._session_factory,
                )
                for patient_id, sys_codes in affected.items():
                    # Параметры пациента отдаём из своего снимка: интерпретации нужны ровно
                    # «отвеченные» параметры (см. run_for), а это те же строки, что уже прочитаны
                    # в _load теми же фильтрами — иначе она перечитывала бы их из БД (~2.8мс). Отсев
                    # повторов биомаркера по этим строкам уже посчитан там же и передаётся готовым.
                    # `.get`: у пациента может не быть ни одного параметра и всё равно быть результаты
                    # (беременная получает inapplicable по всем опросникам от флага, а не от ответов).
                    try:
                        computed = await interp.run_for(
                            patient_id,
                            sys_codes,
                            patient_parameters=data.active_parameters.get(patient_id, {}),
                            excluded_by_instrument=data.excluded_by_patient.get(patient_id, {}),
                            timings=t.interpretation,
                        )
                    except Exception:
                        logger.exception(
                            "calc.interpretation: failed",
                            extra={"log_context": {"patient_id": patient_id, "systems": sorted(sys_codes)}},
                        )
                    else:
                        if computed:
                            self._publish_interpretation(patient_id, sorted(computed.keys()))

        notice(
            "calc.run: complete",
            {
                "patient_count": len(data.patient_ids),
                "processed": outcome.processed,
                "skipped": outcome.skipped,
                "failed": outcome.failed,
            },
        )
        return outcome

    async def _process_patient(
        self,
        patient_id: str,
        data: LoadedCalcData,
        formula_pipeline: FormulaPipeline,
        questionnaire_pipeline: QuestionnairePipeline,
        biomarker_pipeline: BiomarkerClinrecPipeline,
        outcome: CalcRunResult,
        timings: StepTimings,
    ) -> ResultBatch:
        """Compute one patient's formula + questionnaire + clinrec results into a single batch.

        Resolves the per-patient invariants (pregnancy, requested-instrument filter) once, then
        runs the formula pipeline followed by the questionnaire pipeline against a shared batch.
        Both pipelines bump `outcome.skipped` for instruments they skip; the caller owns the flush
        and the processed/failed counters. Returns the batch to flush in one transaction — empty
        when nothing was computed for this patient.
        """
        patient_values = data.grouped.get(patient_id, {})
        excluded_by_instrument = data.excluded_by_patient.get(patient_id, {})
        allowed_instruments = data.instrument_filter.get(patient_id)
        # Invariant per patient — resolve once, shared by both pipelines. NULL (не отвечала) для
        # формул эквивалентен False: они переключаются только при True.
        is_pregnant = bool(data.patient_data.get(patient_id))

        batch = ResultBatch()
        # Шаг `cvd` открывается внутри этого шага на том же sink'е, поэтому вычитается из `formula`
        # автоматически: `formula` показывает только in-process расчёт (см. StepTimings).
        with timings.step("formula"):
            await formula_pipeline.process(
                patient_id,
                patient_values,
                is_pregnant,
                allowed_instruments,
                batch,
                outcome,
                timings,
                excluded_by_instrument=excluded_by_instrument,
            )

        with timings.step("questionnaire"):
            questionnaire_pipeline.process(patient_id, is_pregnant, allowed_instruments, batch, outcome)

        # Клинрек-расчёт идёт по тому же снимку и добавляет в батч только изменившиеся строки
        # групп заболеваний: неизменившееся состояние батч не увеличивает и последствий не имеет.
        biomarker_pipeline.process(
            patient_id,
            patient_values,
            is_pregnant,
            allowed_instruments,
            data.existing_biomarker_results.get(patient_id, {}),
            batch,
            excluded_by_instrument=excluded_by_instrument,
        )
        return batch

    async def _load(self, requests: list[CalculationRequest], lt: LoadTimings) -> LoadedCalcData:
        """Read everything one dispatch needs and build the derived views the loop walks.

        Flushes the read transaction via the repository at the end so locks release before the
        per-patient writes (the session lifecycle stays in infra, not the handler).

        `lt` — sink по-читательской разбивке (см. LoadTimings); каждый `await`
        к БД меряется отдельно, синхронные читатели каталога — нет. Сам сбор за флагом
        `settings.step_timings_enabled` — при выключенном ни один `perf_counter` не вызывается.
        """
        # The Beck score map is populated once when CalcCatalog is built (after migrations/seeds),
        # alongside every other catalog view — no lazy first-use load here.
        patient_ids = [request.patient_id for request in requests]
        instrument_filter = {request.patient_id: request.instrument_codes for request in requests}

        configs = self._catalog.instrument_configs

        with lt.step("parameters"):
            snapshot = await self._reader.load_patient_snapshot(patient_ids)
        rows = snapshot.rows
        patient_data = snapshot.patient_data
        active_parameters = active_parameters_by_patient(rows)
        excluded_by_patient = _build_excluded_by_patient(rows, self._catalog)

        # Questionnaire pipeline data — оба шага считаются в памяти из уже прочитанных
        # rows/patient_data, справочная часть джойнов свёрнута в CalcCatalog:
        #   STEP 1+2+4(sum) — build_questionnaire_scores: per-row scores summed per (patient, instrument)
        #   STEP 3 counts   — build_questionnaire_eligibility: per-instrument applicable/answered
        #                     QUESTION counts. Fed the already-loaded `rows` and `patient_data` on
        #                     purpose: the gate must see exactly the answers the formulas see, and
        #                     the counts are derived in Python — no extra per-patient query.
        with lt.step("quest_scores"):
            questionnaire_rows = self._reader.build_questionnaire_scores(rows, excluded_by_patient)

        with lt.step("quest_eligibility"):
            eligibility = self._reader.build_questionnaire_eligibility(
                patient_ids,
                rows,
                patient_data,
                excluded_by_patient,
                active_by_patient=active_parameters,
            )

        system_codes = self._catalog.system_codes_by_instrument
        # Existing result rows per (patient, instrument). The non-pregnant questionnaire path
        # uses this to overwrite a stale `not_required` dummy it can no longer recompute (answers
        # expired/reset) — but ONLY for instruments that already have a row, so we never spawn
        # dummies for questionnaires the patient never engaged with. Keyed by (patient, instrument):
        # a questionnaire code maps to exactly one questionnaire result row, so no indicator filter.
        with lt.step("existing_keys"):
            existing_result_keys = await self._reader.load_existing_result_keys(patient_ids)

        # Существующие строки `biomarker_kr` — одним чтением на пачку: расчёт сравнивает желаемое
        # состояние группы с текущим в памяти и по группам в БД не ходит.
        with lt.step("existing_biomarker"):
            existing_biomarker_results = await self._reader.load_biomarker_clinrec_results(patient_ids)

        questionnaire_rows = [
            row
            for row in questionnaire_rows
            if (f := instrument_filter.get(row.patient_id)) is None or row.instrument_code in f
        ]

        # patient_id → {parameter_code: value}; used as the parameter lookup for InstrumentInput.build
        grouped: dict[str, dict[str, str | None]] = defaultdict(dict)
        for row in rows:
            grouped[row.patient_id][row.parameter_code] = row.value

        # The questionnaire loop is config-driven. A score row exists only for an instrument the
        # patient engaged with, so index rows for O(1) lookup while visiting each configured code.
        questionnaire_scores = {(row.patient_id, row.instrument_code): row for row in questionnaire_rows}

        with lt.step("commit"):
            await self._repo.commit()

        return LoadedCalcData(
            patient_ids=patient_ids,
            instrument_filter=instrument_filter,
            configs=configs,
            patient_data=patient_data,
            grouped=dict(grouped),
            active_parameters=active_parameters,
            excluded_by_patient=excluded_by_patient,
            formula_configs=self._catalog.formula_configs,
            questionnaire_configs=self._catalog.questionnaire_configs,
            unsupported_calc_codes=self._catalog.unsupported_calc_codes,
            biomarker_configs=self._catalog.biomarker_clinrec_configs,
            existing_biomarker_results=existing_biomarker_results,
            questionnaire_scores=questionnaire_scores,
            eligibility=eligibility,
            system_codes=system_codes,
            existing_result_keys=existing_result_keys,
        )

    def _publish(self, patient_id: str, instrument_code: str, system_codes: Mapping[str, tuple[str, ...]]) -> None:
        if self._kafka is None:
            return
        self._kafka.send_background(
            topic=settings.kafka.topics.risk_calculation,
            value={
                "clientId": patient_id,
                "systemCodes": list(system_codes.get(instrument_code, ())),
                "messageType": "calculation",
            },
            key=patient_id,
        )

    def _publish_interpretation(self, patient_id: str, system_codes: list[str]) -> None:
        if self._kafka is None or not system_codes:
            return
        self._kafka.send_background(
            topic=settings.kafka.topics.risk_calculation,
            value={
                "clientId": patient_id,
                "systemCodes": system_codes,
                "messageType": "interpretation",
            },
            key=patient_id,
        )
