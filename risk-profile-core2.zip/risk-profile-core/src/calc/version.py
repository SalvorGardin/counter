"""Версия расчёта — артефакт релиза, по которому определяется устаревший риск-профиль.

Версия лежит в отдельном файле репозитория (`calculation-version.json`) и едет в образе вместе
с кодом и миграциями справочников. Поэтому «текущая версия» тождественна «версии работающего
релиза»: процесс не может проштамповать реестр версией, которой не соответствуют его резидентные
каталоги (они строятся из БД один раз на старте, см. `catalog_builder`).

Бампится вручную в том же изменении, что и миграция, меняющая справочники, — см.
`manual_skills/release.md` и `.claude/rules/catalog-migrations.md`. Версия сервиса (`version.json`)
и ревизия alembic для этого не годятся: они двигаются на каждом релизе, включая те, что
справочников не касаются, и любой релиз помечал бы устаревшими все посчитанные профили.

Значение читается один раз за процесс и кэшируется: расчёт зовёт его на каждую команду, а файл
после старта контейнера не меняется.
"""

import json
from functools import lru_cache
from pathlib import Path

from src.config import settings
from src.exceptions import RiskBaseError
from src.logger import alert

_VERSION_KEY = "version"
# Версия-заглушка, которой бутстрап-миграция заполняет реестр по уже посчитанным пациентам:
# профили считались разными поколениями справочников, и объявлять их актуальными нельзя.
# Значение обязано отличаться от любой настоящей версии — отсюда проверка в загрузчике.
BOOTSTRAP_CALCULATION_VERSION = "bootstrap"
# Потолок длины — защита от «в переменную/файл попал не тот текст»: версия уезжает в колонку
# реестра и в метки наблюдаемости, и многокилобайтный мусор там не нужен.
_MAX_VERSION_LENGTH = 64


class CalculationVersionError(RiskBaseError, ValueError):
    """Файл версии расчёта отсутствует или его значение непригодно."""


def load_calculation_version(path: Path) -> str:
    """Читает версию расчёта из файла. Любая непригодность — `CalculationVersionError`.

    Пригодное значение — непустая строка без пробельных символов длиной до 64 символов. Число,
    `null` и объект отвергаются намеренно: версия участвует в сравнении на равенство, и молчаливое
    приведение `1` к `"1"` дало бы когорту, которая то пуста, то нет, в зависимости от того, чем
    её проштамповали.
    """
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise CalculationVersionError(f"calculation version file is not readable: {path}") from exc
    except json.JSONDecodeError as exc:
        raise CalculationVersionError(f"calculation version file is not valid JSON: {path}") from exc

    if not isinstance(raw, dict):
        raise CalculationVersionError(f"calculation version file must contain a JSON object: {path}")
    value = raw.get(_VERSION_KEY)
    if not isinstance(value, str):
        raise CalculationVersionError(f"calculation version must be a string, got {type(value).__name__}: {path}")
    if not value or value.strip() != value or any(c.isspace() for c in value):
        raise CalculationVersionError(f"calculation version must not be empty or contain whitespace: {path}")
    if value == BOOTSTRAP_CALCULATION_VERSION:
        raise CalculationVersionError(
            f"calculation version must not be the bootstrap sentinel {BOOTSTRAP_CALCULATION_VERSION!r}: "
            "it marks profiles calculated before the registry existed, and a release claiming it "
            "would empty the recalculation cohort"
        )
    if len(value) > _MAX_VERSION_LENGTH:
        raise CalculationVersionError(f"calculation version must be at most {_MAX_VERSION_LENGTH} characters: {path}")
    return value


@lru_cache(maxsize=1)
def calculation_version() -> str:
    """Версия расчёта этого процесса. Читается один раз, дальше отдаётся из кэша."""
    return load_calculation_version(Path(settings.calculation_version_file))


def require_calculation_version() -> str:
    """Проверка на входе в процесс, который считает риск или выбирает когорту пересчёта.

    Без версии процесс штамповал бы реестр мусором, и когорта стала бы неопределимой, — поэтому
    отказ происходит на старте, а не на первой команде. Событие уходит `alert()`-ом до падения:
    исключение на старте видно только в stderr контейнера, а сбой релизного артефакта обязан
    попасть в структурированный лог.
    """
    try:
        return calculation_version()
    except CalculationVersionError as exc:
        alert(
            "calculation version unavailable",
            {"check": "calculation_version", "path": settings.calculation_version_file, "error": str(exc)},
        )
        raise
