from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field

from src.calc.domain.models import FormulaResult


class ResultBatch:
    """One patient's computed results plus the instrument codes to publish post-commit.

    Keeps the two lists in sync at a single point: a list-result formula extends `results`
    but publishes its instrument once (not per row), in compute order. The whole batch is
    flushed in one transaction; `publish_codes` drives the post-commit side effects.

    У инструмента две РАЗНЫЕ области систем, и батч различает их явно. Событие расчёта несёт все
    системы инструмента по каталогу — потребитель узнаёт, что показатель пересчитан. Интерпретация
    же запускается только по системам, картина которых действительно изменилась: у `biomarker_kr`
    одна строка относится к одной группе заболеваний, и пересчитывать по ней все системы
    инструмента значило бы переписывать чужие интерпретации без причины. Для обычных инструментов
    области совпадают, поэтому область интерпретации задаётся только там, где она уже, — иначе
    сохраняется прежнее поведение.
    """

    def __init__(self) -> None:
        self.results: list[FormulaResult] = []
        self.publish_codes: list[str] = []
        self._interpretation_scopes: dict[str, frozenset[str]] = {}

    def add(self, result: FormulaResult | list[FormulaResult], instrument_code: str) -> None:
        if isinstance(result, list):
            self.results.extend(result)
        else:
            self.results.append(result)
        self.publish_codes.append(instrument_code)

    def add_scoped(
        self, results: Iterable[FormulaResult], instrument_code: str, interpretation_system_codes: frozenset[str]
    ) -> None:
        """Строки инструмента, интерпретация которых ограничена собственной областью.

        Вызывается только когда область непуста: инструмент без изменившихся строк в батч не
        попадает вовсе (ни строки, ни кода публикации).
        """
        rows = list(results)
        if not rows:
            return
        self.add(rows, instrument_code)
        self._interpretation_scopes[instrument_code] = interpretation_system_codes

    def interpretation_systems(
        self, instrument_code: str, catalog_systems: Mapping[str, tuple[str, ...]]
    ) -> frozenset[str]:
        """Системы, которым после коммита нужна интерпретация этого инструмента.

        По умолчанию — все системы инструмента по каталогу (прежнее поведение); у инструмента с
        собственной областью — только она.
        """
        scope = self._interpretation_scopes.get(instrument_code)
        if scope is not None:
            return scope
        return frozenset(catalog_systems.get(instrument_code, ()))


@dataclass
class CalcRunResult:
    """Committed instrument codes and outcome counters for one calculation run."""

    processed_codes: list[str] = field(default_factory=list)
    processed: int = 0
    skipped: int = 0
    failed: int = 0
