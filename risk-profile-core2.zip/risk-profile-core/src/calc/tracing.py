from src.logger import debug_enabled, logger


def trace(event: str, /, **context: object) -> None:
    """Record a per-request DEBUG milestone when buffered debug logging is enabled."""
    if debug_enabled():
        logger.debug(event, extra={"log_context": context})
