from collections.abc import Mapping

from src.calc.domain.exceptions import QuestionnaireCalculationError
from src.calc.domain.models import (
    CalcReasonCode,
    CalcRejection,
    InstrumentDefinition,
    QuestionnaireEligibility,
    QuestionnaireScoreRow,
)
from src.calc.domain.questionnaire import QuestionnaireCalculator
from src.calc.domain.questionnaire_registry import GATED_QUESTIONNAIRE_CODES
from src.calc.outcomes import CalcRunResult, ResultBatch
from src.calc.status_collector import CalcStatusCollector
from src.calc.tracing import trace
from src.logger import logger, notice


class QuestionnairePipeline:
    """Questionnaire computation for one patient in one pass over the configured instruments.

    Each in-scope instrument is visited once. Pregnancy forces a dummy; an answered instrument is
    gated and calculated; an unanswered gated instrument records a rejection. On a non-pregnant
    full recalc, any existing result that was not recomputed is cleared with a dummy.
    """

    def __init__(
        self,
        questionnaire: QuestionnaireCalculator,
        configs: Mapping[str, InstrumentDefinition],
        eligibility: dict[tuple[str, str], QuestionnaireEligibility],
        scores: dict[tuple[str, str], QuestionnaireScoreRow],
        existing_result_keys: frozenset[tuple[str, str]],
        statuses: CalcStatusCollector,
    ) -> None:
        self._questionnaire = questionnaire
        self._configs = configs
        self._eligibility = eligibility
        self._scores = scores
        self._existing_result_keys = existing_result_keys
        # Вызывается безусловно: проверка флага сбора — внутри методов коллектора.
        self._statuses = statuses

    def process(
        self,
        patient_id: str,
        is_pregnant: bool,
        allowed_instruments: frozenset[str] | None,
        batch: ResultBatch,
        outcome: CalcRunResult,
    ) -> None:
        questionnaire = self._questionnaire  # Hoist out of the per-row loop.
        configs = self._configs
        statuses = self._statuses

        if allowed_instruments is None:
            candidates = configs
        else:
            candidates = (code for code in allowed_instruments if code in configs)

        for instrument_code in candidates:
            if is_pregnant:
                trace(
                    "calc.questionnaire: inapplicable (pregnant)",
                    instrument_code=instrument_code,
                    patient_id=patient_id,
                )
                statuses.record_rejection(
                    patient_id, instrument_code, CalcRejection(reason_code=CalcReasonCode.PREGNANT)
                )
                batch.add(questionnaire.make_dummy(patient_id, instrument_code), instrument_code)
                continue

            row = self._scores.get((patient_id, instrument_code))
            if row is None:
                if instrument_code in GATED_QUESTIONNAIRE_CODES:
                    trace(
                        "calc.questionnaire: skipped (no answers)",
                        instrument_code=instrument_code,
                        patient_id=patient_id,
                    )
                    statuses.record_rejection(
                        patient_id,
                        instrument_code,
                        CalcRejection(reason_code=CalcReasonCode.NO_ANSWERED_PARAMETERS),
                    )
                    outcome.skipped += 1
            else:
                trace(
                    "calc.questionnaire: attempt",
                    instrument_code=instrument_code,
                    patient_id=patient_id,
                )
                reason = questionnaire.ineligibility_reason(
                    instrument_code, self._eligibility.get((patient_id, instrument_code))
                )
                if reason is not None:
                    statuses.record_rejection(patient_id, instrument_code, reason)
                    trace(
                        "calc.questionnaire: skipped (ineligible)",
                        instrument_code=instrument_code,
                        patient_id=patient_id,
                        reason=reason.reason_code,
                        applicable_questions=reason.applicable_questions,
                        progressed_questions=reason.progressed_questions,
                    )
                    outcome.skipped += 1
                else:
                    try:
                        result = questionnaire.calculate(row)
                    except QuestionnaireCalculationError as e:
                        statuses.record_rejection(
                            patient_id,
                            instrument_code,
                            CalcRejection(reason_code=CalcReasonCode.CALCULATION_ERROR),
                        )
                        logger.error(
                            "calc.questionnaire: calculation failed",
                            extra={
                                "log_context": {
                                    "instrument_code": instrument_code,
                                    "patient_id": patient_id,
                                    "error": str(e.cause),
                                }
                            },
                            exc_info=e,
                        )
                        outcome.skipped += 1
                    else:
                        statuses.record_calculated(patient_id, instrument_code)
                        batch.add(result, instrument_code)
                        continue

            # A full non-pregnant recalculation clears an existing questionnaire result whenever
            # the instrument could not be recomputed, including eligibility and calculation errors.
            if allowed_instruments is None and (patient_id, instrument_code) in self._existing_result_keys:
                statuses.record_rejection(
                    patient_id,
                    instrument_code,
                    CalcRejection(reason_code=CalcReasonCode.MISSING_REQUIRED_PARAMETERS),
                )
                notice(
                    "calc.questionnaire: clearing stale result (no recompute)",
                    {"instrument_code": instrument_code, "patient_id": patient_id},
                )
                batch.add(questionnaire.make_dummy(patient_id, instrument_code), instrument_code)
