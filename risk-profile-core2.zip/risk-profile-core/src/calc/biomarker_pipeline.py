from collections.abc import Collection, Mapping

from src.calc.domain.biomarker_clinrec import (
    BiomarkerClinrecCalculator,
    BiomarkerClinrecInput,
    DiseaseResultState,
)
from src.calc.domain.consts import PARAM_GENDER
from src.calc.domain.models import InstrumentDefinition
from src.calc.outcomes import ResultBatch
from src.calc.tracing import trace
from src.domain.risk_factor_conditions import ParameterCondition


class BiomarkerClinrecPipeline:
    """Расчёт `biomarker_kr` одного пациента поверх уже прочитанного снимка.

    Собственных чтений у pipeline нет: значения биомаркеров, пол, беременность и существующие
    строки результата приходят из снимка фазы загрузки, а справочник — из резидентных индексов
    каталога, свёрнутых в калькулятор на старте диспатча.

    Диагностические статусы расчёта (`calculation_statuses`) здесь не пишутся: их словарь описывает
    исход ОДНОГО инструмента у пациента («рассчитан», «не хватает ответов», …), а `biomarker_kr`
    даёт исход по каждой группе заболеваний отдельно, причём чаще всего — «ничего не изменилось».
    Свести это к одному статусу без потери смысла нельзя, а придуманный статус ввёл бы в
    заблуждение проверяющего.
    """

    def __init__(
        self,
        configs: Mapping[str, InstrumentDefinition],
        biomarker_parameter_codes: frozenset[str],
        triggers_by_factor: Mapping[str, tuple[ParameterCondition, ...]],
        diseases_by_factor: Mapping[str, tuple[str, ...]],
        system_code_by_disease: Mapping[str, str],
    ) -> None:
        self._biomarker_parameter_codes = biomarker_parameter_codes
        # По калькулятору на инструмент: код инструмента входит в каждую строку результата, а
        # справочные индексы у них общие.
        self._calculators = {
            code: BiomarkerClinrecCalculator(
                triggers_by_factor=triggers_by_factor,
                diseases_by_factor=diseases_by_factor,
                system_code_by_disease=system_code_by_disease,
                instrument_code=code,
            )
            for code in configs
        }

    def process(
        self,
        patient_id: str,
        patient_values: Mapping[str, str | None],
        is_pregnant: bool,
        allowed_instruments: frozenset[str] | None,
        existing_results: Mapping[str, DiseaseResultState],
        batch: ResultBatch,
        excluded_by_instrument: Mapping[str, Collection[str]] | None = None,
    ) -> None:
        """Добавляет в батч только изменившиеся строки групп заболеваний.

        Неизменившееся состояние не даёт ни строки, ни кода публикации: инструмент, у которого
        ничего не изменилось, не считается записанным — ни события, ни интерпретации по нему нет.
        """
        # Отбор инструментов идёт до снятия значений: частичный расчёт без `biomarker_kr`
        # не должен просматривать снимок ответов пациента вовсе.
        scheduled = [
            (code, calculator)
            for code, calculator in self._calculators.items()
            if allowed_instruments is None or code in allowed_instruments
        ]
        if not scheduled:
            return
        gender = patient_values.get(PARAM_GENDER)
        excluded = excluded_by_instrument or {}
        for instrument_code, calculator in scheduled:
            excluded_codes = excluded.get(instrument_code, ())
            biomarker_values = {
                code: value
                for code, value in patient_values.items()
                if value and code in self._biomarker_parameter_codes and code not in excluded_codes
            }
            trace("calc.biomarker_clinrec: attempt", instrument_code=instrument_code, patient_id=patient_id)
            outcome = calculator.calculate(
                BiomarkerClinrecInput(
                    patient_id=patient_id,
                    is_pregnant=is_pregnant,
                    biomarker_values=biomarker_values,
                    gender=gender,
                    existing_results=existing_results,
                )
            )
            batch.add_scoped(outcome.results, instrument_code, outcome.changed_system_codes)
