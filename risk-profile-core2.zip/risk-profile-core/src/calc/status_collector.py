"""Сбор диагностических статусов расчёта — единственная точка записи в `calculation_statuses`.

Отвечает на вопрос «почему по инструменту нет показателя»: исход, код причины и типизированные
детали по каждой паре «пациент × инструмент», которую расчёт РЕАЛЬНО рассматривал. Обход
инструментов сбор не расширяет: опросник, которого пациент не касался, цикл не посещает, и строки
по нему не появляется (отсутствие строки разбирает читающая сторона сверкой с каталогом).

Две причины, ради которых это отдельный класс, а не пара вызовов внутри пайплайнов:

* **Флаг проверяется здесь, а не на call-site'ах.** Пайплайны и хендлер вызывают коллектор
  безусловно; при выключенном `settings.calc_status_collection_enabled` каждый метод — no-op:
  ни сессии, ни буфера в памяти. Так состояние флага физически не может протечь в ветвление
  расчёта.
* **Запись — отдельной транзакцией, после коммита результатов пациента.** У диагностики нет
  способа задержать или откатить `results`: `flush` вызывается вне транзакции результатов и на
  собственной сессии. Цена — падение процесса между двумя коммитами оставит статусы на один
  пересчёт позади; следующий пересчёт по пациенту это выравнивает.
"""

from collections.abc import Iterable
from datetime import UTC, datetime

from sqlalchemy import delete
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.calc.domain.models import CalcRejection, CalcStatus
from src.config import settings
from src.infra.database import get_primary_runtime
from src.infra.isolated_write import run_isolated
from src.infra.sql import any_of
from src.models.calculation_status import CalculationStatus

# Стейтмент собирается ОДИН раз на модуль и переиспользуется с executemany-параметрами — так он
# попадает в compiled-кэш SQLAlchemy (тот же приём и та же форма, что у `_UPSERT_RESULT`
# в `src/calc/infra/repository.py`).
# `__table__` типизирован как FromClause, хотя в рантайме это Table (ограничение стабов SQLAlchemy).
_insert_status = insert(CalculationStatus.__table__)  # ty: ignore[invalid-argument-type]
_UPSERT_STATUS = _insert_status.on_conflict_do_update(
    constraint="uq_calculation_statuses_patient_id_instrument_code",
    # `excluded.*`, а не литералы строки: иначе стейтмент зависел бы от данных и не
    # переиспользовался бы на всю пачку. Ключ конфликта в set_ не входит.
    set_={
        "status": _insert_status.excluded.status,
        "reason_code": _insert_status.excluded.reason_code,
        "date_time": _insert_status.excluded.date_time,
        "missing_parameter_codes": _insert_status.excluded.missing_parameter_codes,
        "applicable_questions": _insert_status.excluded.applicable_questions,
        "progressed_questions": _insert_status.excluded.progressed_questions,
    },
)


class CalcStatusCollector:
    """Буфер статусов текущего пациента плюс запись их одним батч-upsert'ом.

    Живёт один диспатч (создаётся вместе с `CalcHandler`). Буфер — на пациента: `flush_patient`
    записывает и очищает его, поэтому память не растёт по мере обхода пациентов.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession] | None = None) -> None:
        self._session_factory = (
            session_factory if session_factory is not None else get_primary_runtime().session_factory
        )
        self._rows: dict[tuple[str, str], dict[str, object]] = {}

    @property
    def enabled(self) -> bool:
        return settings.calc_status_collection_enabled

    def record_calculated(self, patient_id: str, instrument_code: str) -> None:
        """Результат записан — причины нет."""
        self._record(patient_id, instrument_code, CalcStatus.CALCULATED, None)

    def record_rejection(self, patient_id: str, instrument_code: str, rejection: CalcRejection) -> None:
        """Показателя нет по причине `rejection`.

        Первая запись по паре выигрывает: специфичную причину регистрирует тот, кто её знает
        (например, `cvd_disabled` — вызов cvd внутри пайплайна), а более общая запись вызывающего
        («рассчитано», `calculation_error`) не должна её затирать.
        """
        self._record(patient_id, instrument_code, rejection.status, rejection)

    def _record(
        self,
        patient_id: str,
        instrument_code: str,
        status: CalcStatus,
        rejection: CalcRejection | None,
    ) -> None:
        if not self.enabled:
            return
        key = (patient_id, instrument_code)
        if key in self._rows:
            return
        self._rows[key] = {
            "patient_id": patient_id,
            "instrument_code": instrument_code,
            "status": status.value,
            "reason_code": rejection.reason_code.value if rejection is not None else None,
            "missing_parameter_codes": (
                list(rejection.missing_parameter_codes)
                if rejection is not None and rejection.missing_parameter_codes is not None
                else None
            ),
            "applicable_questions": rejection.applicable_questions if rejection is not None else None,
            "progressed_questions": rejection.progressed_questions if rejection is not None else None,
        }

    def pending(self) -> dict[tuple[str, str], dict[str, object]]:
        """Накопленное, но ещё не записанное — по ключу «пациент × инструмент».

        Только для чтения (тесты, диагностика): расчёт этим представлением не пользуется.
        """
        return dict(self._rows)

    def discard_patient(self, patient_id: str) -> None:
        """Забыть накопленное по пациенту, не записывая (батч результатов откатился)."""
        if not self._rows:
            return
        for key in [key for key in self._rows if key[0] == patient_id]:
            del self._rows[key]

    async def flush_patient(self, patient_id: str) -> None:
        """Записать статусы пациента отдельной транзакцией на собственной сессии.

        Вызывается ПОСЛЕ успешного коммита результатов пациента и вне его транзакции. Любой сбой
        записи гасится здесь: диагностика не влияет на исход пересчёта.
        """
        if not self.enabled:
            self.discard_patient(patient_id)
            return

        rows = [row for key, row in self._rows.items() if key[0] == patient_id]
        self.discard_patient(patient_id)
        if not rows:
            return

        now = datetime.now(tz=UTC)
        for row in rows:
            row["date_time"] = now

        async def write(session: AsyncSession) -> None:
            await session.execute(_UPSERT_STATUS, rows)

        await run_isolated(
            self._session_factory,
            write,
            failure_message="calc.status_collector: write failed, statuses for this patient are lost",
            failure_log_context={"patient_id": patient_id, "status_count": len(rows)},
        )

    async def delete_for_instruments(self, patient_id: str, instrument_codes: Iterable[str]) -> None:
        """Удаляет статусы по инструментам, чьи `results` снесены вне обхода калькулятора.

        Вызывается из risk-event (answers-reset/pregnancy-end) ПОСЛЕ коммита удаления `results`:
        та строка `calculation_statuses` не переживает исчезновение своего результата, иначе она
        продолжает молчать `status=calculated` про инструмент, у которого уже нет ни результата,
        ни ответов, — ровно то, ради объяснения чего заведена эта таблица. Своя сессия, как у
        `flush_patient`: сброс ответов не должен упасть из-за диагностики. Следующий расчёт,
        который реально коснётся инструмента, восстановит строку с нуля.
        """
        if not self.enabled:
            return
        codes = list(instrument_codes)
        if not codes:
            return
        statement = delete(CalculationStatus).where(
            CalculationStatus.patient_id == patient_id,
            any_of(CalculationStatus.instrument_code, codes),
        )

        async def purge(session: AsyncSession) -> None:
            await session.execute(statement)

        await run_isolated(
            self._session_factory,
            purge,
            failure_message="calc.status_collector: delete failed, stale statuses were not cleared",
            failure_log_context={"patient_id": patient_id, "instrument_codes": codes},
        )
