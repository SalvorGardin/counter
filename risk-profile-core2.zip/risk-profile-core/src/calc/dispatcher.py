"""Диспетчер пересчёта по [wiki Триггеры](Аналитика/Триггеры-для-запуска-расчета-риск-профилей).

Точка входа для роутеров — `dispatch_recalc` (вызывается из FastAPI BackgroundTasks после
коммита транзакции записи параметров пациента). Она НЕ считает риск в event loop API-процесса,
а кладёт команду в Kafka-топик `recalc_commands`; собственно расчёт выполняет отдельный
consumer-воркер (`src/workers/calc_consumer.py`) в своём процессе. Так event loop API не
забивается CPU-bound формулами и DB-тяжёлым пересчётом.

Если Kafka выключена намеренно (`kafka.enabled=False` — unit-тесты / локальный запуск без брокера),
считаем синхронно в текущем процессе (`run_recalc`) — но в БД при этом ходим под ЛОГИНОМ РАСЧЁТА,
а не под логином профиля: инлайн-режим меняет только место исполнения, а не границу сервисов.
Если Kafka включена, но опубликовать команду нельзя (продюсер не поднят или publish упал) —
поднимаем `alert()` и НЕ деградируем на inline: под нагрузкой синхронный пересчёт забивает
event loop API-процесса (ровно то, ради чего сделан offload).

`run_recalc` — собственно расчёт (резолв инструментов → `CalcHandler.run`). Вызывается воркером
и веткой `kafka.enabled=False`. Открывает собственную сессию: запросная закрыта к моменту запуска.
"""

import asyncio
import contextlib
import functools
import time
from collections.abc import Awaitable, Callable

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from src.calc.handler import CalcHandler
from src.calc.infra.reader import CalcReader
from src.calc.infra.version_registry import VersionRegistry
from src.calc.outcomes import CalcRunResult
from src.calc.recalc_message import encode_command
from src.calc.timings import StepTimings
from src.calc.version import calculation_version
from src.config import settings
from src.infra.catalog.builder import Catalogs, build_catalogs
from src.infra.database import get_primary_runtime, init_calculation_runtime
from src.infra.kafka.exceptions import KafkaInitError, KafkaPublishError
from src.infra.kafka.producer import get_kafka_producer
from src.logger import alert, logger, notice
from src.metrics import (
    RECALC_ANSWER_TO_RESULT,
    RECALC_DURATION,
    RECALC_OUTCOME_EMPTY,
    RECALC_OUTCOME_FAILED,
    RECALC_OUTCOME_WRITTEN,
    RECALC_QUEUE_WAIT,
    RECALC_SCOPE_FULL,
    RECALC_SCOPE_PARTIAL,
    RECALC_SOURCE_BACKGROUND,
    RECALC_SOURCE_USER,
)

# Кап на конкурентные пересчёты В API-ПРОЦЕССЕ (ветка kafka.enabled=False): пул соединений =
# pool_size(5) + max_overflow(10) = 15; семафор оставляет запас на API-запросы. В consumer-воркере
# конкурентность governed `KafkaTopicConsumer._sem` (=max_concurrency), поэтому воркер зовёт
# run_recalc с semaphore=None, иначе этот кап(5) молча резал бы max_concurrency>5 (см. ревью !79).
_MAX_CONCURRENT_DISPATCHES = 5
_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_DISPATCHES)

type DispatcherCallable = Callable[[str, set[str] | None], Awaitable[None]]


async def dispatch_recalc(
    patient_id: str,
    parameter_codes: set[str] | None,
    *,
    catalogs: Catalogs | None = None,
) -> None:
    """Поставить пересчёт в очередь Kafka (или выполнить локально, если Kafka отключена).

    parameter_codes=None → полный пересчёт (все активные инструменты).
    parameter_codes=set() → no-op.
    Иначе → пересчёт только для инструментов, связанных с переданными parameter_code.

    `catalogs` — статические каталоги справочников API-процесса (см. `get_dispatcher`). Прокидываются
    в inline-ветку (`kafka.enabled=False`), чтобы переиспользовать построенные на старте проекции, а
    не пересобирать их из БД на каждый пересчёт: `calc` идёт в расчёт, `interpretation`
    (recommended_doctors / risk_factors / parameter_scores / diseases) — в `InterpretationHandler`,
    чтобы его reference-чтения шли из RAM.
    """
    if parameter_codes is not None and not parameter_codes:
        return

    if not settings.kafka.enabled:
        # Kafka отключена намеренно (unit-тесты / локальный запуск без брокера) — считаем здесь.
        # Очереди нет, но отметку ставим: время пересчёта меряется и на этом пути, просто ожидание
        # в очереди у него околонулевое.
        await run_recalc(
            patient_id,
            parameter_codes,
            catalogs=catalogs,
            enqueued_at=time.time(),
            session_factory=init_calculation_runtime().session_factory,
        )
        return

    # Kafka включена: пересчёт идёт ТОЛЬКО через топик recalc_commands. Синхронного fallback нет —
    # под нагрузкой inline-пересчёт забивал event loop (ровно проблема, ради которой сделан offload).
    # Если опубликовать команду нельзя — фиксируем ошибку и выходим, inline не считаем.
    await _enqueue(patient_id, parameter_codes)


async def _enqueue(patient_id: str, parameter_codes: set[str] | None) -> None:
    """Опубликовать команду пересчёта в Kafka. При невозможности публикации — поднимаем alert.

    Синхронного fallback на `run_recalc` нет: при `kafka.enabled=True` пересчёт обязан идти через
    топик. Невозможность опубликовать команду (продюсер не поднят или publish упал) — это сбой
    важного компонента: команда пересчёта клинического риск-профиля теряется без расчёта. Поднимаем
    `alert()` (требует вмешательства — под нагрузкой может сыпаться на каждый сабмит и тихо копить
    непосчитанные профили), затем выходим. Осознанный трейд-офф против деградации на inline-расчёт.
    """
    try:
        producer = get_kafka_producer()
    except KafkaInitError as exc:
        alert(
            "calc.dispatch: kafka enabled but producer unavailable, recalc command dropped",
            {"patient_id": patient_id},
            exc_info=exc,
        )
        return

    try:
        # send_and_wait (acks=all) — durable-публикация: при затяжной недоступности брокера таск
        # ждёт до request_timeout_ms и поднимает KafkaPublishError. Это I/O-await (event loop CPU
        # не забивает, исходную проблему offload'а не возвращает).
        await producer.send(
            topic=settings.kafka.topics.recalc_commands,
            value=encode_command(patient_id, parameter_codes, enqueued_at=time.time()),
            key=patient_id,
        )
    except KafkaPublishError:
        # send() уже залогировал exception с traceback; здесь поднимаем alert о потере команды.
        alert(
            "calc.dispatch: failed to enqueue recalc command, recalc command dropped",
            {"patient_id": patient_id},
        )
        return

    notice("calc.dispatch: recalc command enqueued", {"patient_id": patient_id})


async def run_recalc(
    patient_id: str,
    parameter_codes: set[str] | None,
    *,
    semaphore: asyncio.Semaphore | None = _semaphore,
    catalogs: Catalogs | None = None,
    timings: StepTimings | None = None,
    enqueued_at: float | None = None,
    background: bool = False,
    session_factory: async_sessionmaker[AsyncSession] | None = None,
) -> CalcRunResult:
    """Выполнить пересчёт здесь и сейчас. Вызывается consumer-воркером и веткой kafka.enabled=False.

    `semaphore` — кап на конкурентность. По умолчанию модульный `_semaphore` (fallback в API-процессе).
    Воркер передаёт None: его конкурентность уже ограничена `KafkaTopicConsumer._sem` (max_concurrency).

    `catalogs` — статические каталоги справочников. Воркер строит их ОДИН раз на старте процесса и
    передаёт сюда (горячий путь не пересобирает справочники на каждую команду). Хендлеру нужны обе
    проекции сразу, поэтому они и приходят одним контейнером; если его не передали (ветка
    kafka.enabled=False в API-процессе, тесты) — собираем из одной загрузки базового каталога по
    открытой ниже сессии.

    `timings` — необязательный sink по-шаговых замеров, прокидывается в `CalcHandler.run`. Заполняется
    только когда до хендлера дошло (no-op закорачивает раньше) И включён флаг
    `RISK_MODEL_STEP_TIMINGS_ENABLED` (см. StepTimings): на боевом пути код замеров не исполняется.
    Боевые вызывающие sink не передают; читает его calc-playground для по-шаговой сводки.

    `enqueued_at` — отметка постановки команды в очередь (секунды Unix-эпохи, часы продюсера). Если
    передана, по завершении пишутся гистограммы времени пересчёта; если нет — код замера не
    исполняется вовсе, ни одного обращения к часам (пути без постановки в очередь — playground,
    прямые вызовы — не меряются). В `duration` входит всё, что делает эта функция: ожидание
    модульного семафора (только ветка kafka.enabled=False) и построение одноразовых каталогов
    (только вызовы без переданного каталога). Воркер передаёт каталоги и не использует семафор,
    поэтому у него `duration` — почти чистая обработка команды.

    `background` — команду породил массовый прогон (`src/workers/bulk_recalc.py`), а не
    пользовательский сценарий. Значение уходит лейблом `source` в гистограммы времени пересчёта:
    у фоновой команды нет ответа пациента, с которого начинается отсчёт, и нет человека, который
    ждёт результата, поэтому в общих рядах с пользовательскими она подменяла бы собой SLI.
    Второе следствие — явный штамп версии при пустом исходе (см. `_stamp_version`). На сам расчёт
    признак не влияет: фоновая команда считает то же и так же.

    Возврат — единый исход запуска (см. `CalcHandler.run`), включая коды реально записанных
    инструментов и счётчики исходов. Боевые вызывающие возврат игнорируют, его читает
    calc-playground для отчёта.

    `session_factory` — фабрика сессий расчёта. Воркер и playground её не передают: их основной
    рантайм процесса уже расчётный. Передаёт её API в инлайн-ветке, где основной рантайм —
    профильный, а весь граф вызовов расчёта обязан идти под логином расчёта: и эта сессия, и
    независимые транзакции сбора статусов и причин интерпретации.
    """
    if parameter_codes is not None and not parameter_codes:
        return CalcRunResult()
    sessions = session_factory if session_factory is not None else get_primary_runtime().session_factory

    # Замер открывается после no-op-короткого замыкания: пустой набор кодов командой не публикуется,
    # мерить там нечего. `queue_wait` считается сразу, а пишется в конце — метка `outcome` известна
    # только по завершении обработки.
    queue_wait = 0.0
    started_mono = 0.0
    if enqueued_at is not None:
        queue_wait = time.time() - enqueued_at
        started_mono = time.perf_counter()

    notice(
        "calc.run_recalc: started",
        {"patient_id": patient_id, "parameter_codes": sorted(parameter_codes) if parameter_codes else None},
    )

    result = CalcRunResult()
    crashed = False
    async with semaphore or contextlib.nullcontext():
        try:
            async with sessions() as session:
                if catalogs is None:
                    # Одноразовые каталоги на одну команду: строим через build_catalogs, а НЕ через
                    # catalog_builder — тот замораживает стартовый heap, и здесь заморозка утекала бы
                    # по одной на команду (см. freeze_startup_heap).
                    catalogs = await build_catalogs(session)
                request = CalcReader(session, catalogs.calc).build_request(patient_id, parameter_codes)
                if request.instrument_codes is not None and not request.instrument_codes:
                    notice(
                        "calc.run_recalc: no instruments resolved, skipped",
                        {"patient_id": patient_id},
                    )
                else:
                    try:
                        producer = get_kafka_producer()
                    except KafkaInitError:
                        producer = None
                        if settings.kafka.enabled:
                            logger.warning(
                                "calc.run_recalc: kafka producer unavailable, result publishing disabled",
                                extra={"log_context": {"patient_id": patient_id}},
                            )
                        else:
                            logger.debug(
                                "calc.run_recalc: kafka not enabled, result publishing skipped",
                                extra={"log_context": {"patient_id": patient_id}},
                            )

                    handler = CalcHandler(
                        session,
                        catalogs.calc,
                        producer,
                        interpretation_catalog=catalogs.interpretation,
                        session_factory=session_factory,
                    )
                    result = await handler.run([request], timings=timings)
                    await _stamp_version(
                        session, patient_id, parameter_codes=parameter_codes, result=result, background=background
                    )
        except Exception:
            logger.exception(
                "calc.run_recalc: failed",
                extra={"log_context": {"patient_id": patient_id}},
            )
            crashed = True

    if enqueued_at is not None:
        _observe_recalc_timings(
            answer_to_result=time.time() - enqueued_at,
            queue_wait=queue_wait,
            duration=time.perf_counter() - started_mono,
            outcome=_recalc_outcome(crashed=crashed, result=result),
            scope=RECALC_SCOPE_FULL if parameter_codes is None else RECALC_SCOPE_PARTIAL,
            source=RECALC_SOURCE_BACKGROUND if background else RECALC_SOURCE_USER,
        )

    if crashed:
        return CalcRunResult()

    notice("calc.run_recalc: complete", {"patient_id": patient_id})
    return result


async def _stamp_version(
    session: AsyncSession,
    patient_id: str,
    *,
    parameter_codes: set[str] | None,
    result: CalcRunResult,
    background: bool = False,
) -> None:
    """Отметить в реестре версий, что профиль пациента посчитан версией этого процесса.

    Штампуются исходы `written` и `empty`: отсутствие применимых инструментов (беременная
    пациентка) — законный результат расчёта, и пациент с таким исходом обязан считаться
    обработанным, иначе он остался бы в когорте навсегда и публиковался бы каждым прогоном.
    Совпадение результата с прежним — тоже выполненный пересчёт.

    Исход `failed` (батч откатился либо обработка упала выше) реестр не трогает: пациент остаётся
    устаревшим и вернётся в когорту. Устойчиво сбойный пациент из неё не выйдет — это видно по
    неуменьшающемуся остатку и требует человека, что и есть желаемое поведение.

    Частичный пересчёт не штампует вовсе: он покрывает только инструменты изменённых параметров,
    и отметка о текущей версии была бы ложной для остальных.

    Ошибка штампа не гасится: она уходит в общий `except` выше, команда учитывается как `failed`,
    а пациент остаётся в когорте — ровно то, что верно, когда отметка не записалась.

    Политика штампования одна для всех команд; `background` влияет только на журнал. Фоновая
    команда, не записавшая ни одного инструмента, оставляет запись: именно такой штамп отвечает
    за сходимость прогона, и без записи его было бы не отличить от побочного эффекта исхода
    «писать было нечего».
    """
    if parameter_codes is not None or result.failed > 0:
        return
    await _bump_version(session, patient_id)
    if background and not result.processed_codes:
        notice(
            "calc.run_recalc: background command wrote nothing, version bumped",
            {"patient_id": patient_id, "calculation_version": calculation_version()},
        )


async def _bump_version(session: AsyncSession, patient_id: str) -> None:
    """Записать пациенту версию расчёта этого процесса и закрыть транзакцию.

    Единственное место записи реестра на пути пересчёта: решение «штамповать ли» принимает
    `_stamp_version`, а сама запись выглядит одинаково независимо от того, что именно посчитал
    этот прогон — версия описывает поколение справочников, а не объём записанного.
    """
    await VersionRegistry(session).stamp(patient_id, calculation_version())
    await session.commit()


def _recalc_outcome(*, crashed: bool, result: CalcRunResult) -> str:
    """Судьба записи результатов команды — значение лейбла `outcome` (правила по приоритету).

    Пустой список инструментов сам по себе неоднозначен: так выглядит и «считать было нечего», и
    «расчёт упал». Поэтому исход берётся не из возврата, а из того, чем закончилась обработка:

    1. исключение поймано выше → `failed`;
    2. `result.failed > 0` → `failed`: батч результатов откатился внутри `CalcHandler.run`;
    3. записанные инструменты есть → `written`;
    4. иначе → `empty` (инструменты не отрезолвились либо писать было нечего).

    Правило 2 приоритетнее правила 3: в проде команда — это один пациент с атомарным батчем, и
    категории не пересекаются, а смешанный мультипациентный прогон считаем сбойным консервативно.
    """
    if crashed or result.failed > 0:
        return RECALC_OUTCOME_FAILED
    return RECALC_OUTCOME_WRITTEN if result.processed_codes else RECALC_OUTCOME_EMPTY


def _observe_recalc_timings(
    *, answer_to_result: float, queue_wait: float, duration: float, outcome: str, scope: str, source: str
) -> None:
    """Единственное место записи гистограмм времени пересчёта.

    Настенные значения (`answer_to_result`, `queue_wait`) считаются по часам двух процессов: при
    расхождении часов разность может выйти отрицательной. Такое значение обрезается в ноль, а не
    отбрасывается — команда действительно обработана, и `_count` обязан её учесть.

    `outcome` описывает судьбу записи `results`. Сбой фазы интерпретаций его не меняет: он ловится
    внутри `CalcHandler.run`, попадает в журнал уровнем ERROR (и в счётчик ошибок), а результаты к
    тому моменту уже записаны. При этом замер закрывается после фазы интерпретаций — именно её
    завершение и есть конец обработки команды.

    `source` разделяет пользовательские команды и команды массового прогона. Смотреть SLI ответа
    пациенту нужно по `source="user"`: фоновые ряды ведут себя иначе по построению, а не из-за
    деградации сервиса.
    """
    RECALC_ANSWER_TO_RESULT.labels(outcome, scope, source).observe(max(0.0, answer_to_result))
    RECALC_QUEUE_WAIT.labels(outcome, scope, source).observe(max(0.0, queue_wait))
    RECALC_DURATION.labels(outcome, scope, source).observe(max(0.0, duration))


def get_dispatcher(request: Request) -> DispatcherCallable:
    """FastAPI DI: подменяется в тестах через `app.dependency_overrides`.

    Привязывает построенные на старте каталоги (`app.state.catalogs`) к `dispatch_recalc`, чтобы
    inline-ветка (`kafka.enabled=False`) не пересобирала справочники из БД на каждый пересчёт.
    """
    return functools.partial(dispatch_recalc, catalogs=request.app.state.catalogs)
