from dataclasses import dataclass, field

from src.infra.step_timings import TimingSink
from src.interpretation.timings import InterpretationTimings


@dataclass
class LoadTimings(TimingSink):
    """Разбивка шага `load` (`CalcHandler._load`) по отдельным читателям, в миллисекундах.

    Меряем то, что уходит в БД (`await`): синхронные вью `CalcCatalog` читаются из RAM и стабильно
    дают 0 — отдельные строки под них только зашумляли бы отчёт. `commit` — закрытие
    read-транзакции в конце `_load` (тоже round-trip к БД, поэтому мерим). Остаток до `load_ms` —
    чистые in-memory группировки (grouped/filter/derived-вью), они в сумму под-шагов не входят.

    Исключение — `quest_scores` и `quest_eligibility`: с переводом STEP-1/2/4 и STEP-3 в память
    (`build_questionnaire_scores`, `build_questionnaire_eligibility`) это уже не БД, а расчёт по
    загруженным `rows`. Строки оставляем: вместе они снимали 6.7мс из 11.4мс `load` пятью
    round-trip'ами, и их видимость — страховка от регресса (рост здесь означает, что счётчики
    снова стали дорогими или что в каталоге распухли производные вью).

    `enabled` — см. `StepTimings.enabled`; проставляется каскадом из `TimingSink.enable`.
    """

    # `parameters` — один запрос за ответами пациентов И `patients.is_pregnant`
    # (см. CalcReader.load_patient_snapshot); отдельной строки patient_data больше нет.
    parameters_ms: float = 0.0
    quest_scores_ms: float = 0.0
    quest_eligibility_ms: float = 0.0
    existing_keys_ms: float = 0.0
    # `existing_biomarker` — чтение бизнес-состояния уже записанных строк `biomarker_kr`
    # (см. CalcReader.load_biomarker_clinrec_results): одно на пачку, а не по группе заболеваний.
    existing_biomarker_ms: float = 0.0
    commit_ms: float = 0.0


@dataclass
class StepTimings(TimingSink):
    """Optional per-run step-duration sink filled by `CalcHandler.run` (milliseconds).

    Сбор целиком за флагом `settings.step_timings_enabled` (по умолчанию выключен): на боевом пути
    не должен исполняться код профилирования — только код расчёта. `enabled` проставляет
    `CalcHandler.run` из настроек (каскадом, см. `TimingSink.enable`), и КАЖДАЯ запись длительности
    в этот объект идёт через `step()`, который при выключенном сборе не пишет и не замеряет. Именно
    поэтому выключенный хендлер может переиспользовать один общий `_DISABLED_TIMINGS` вместо
    аллокации: длительностей в него никто не пишет, а `ran` ставится только на переданный sink.

    Prod callers pass nothing — без sink'а результат читать некому, поэтому сбор не идёт вовсе
    (`run` берёт общий выключенный объект, независимо от флага); the calc-playground
    passes one per command and aggregates. `formula`/`cvd`/`questionnaire`/`upsert` accumulate across
    patients within the dispatch; `load` is the single up-front read; `interpretation` is the
    post-commit pass (stays 0 when nothing was affected). `ran` gates aggregation so no-op /
    invalid commands (handler never entered) don't pollute the samples. Он отмечает вход в хендлер,
    а не факт замера: при выключенном сборе `ran=True` и нулевые длительности означают «хендлер
    отработал, но замеров нет» — по этой паре playground печатает «disabled» вместо таблицы нулей.

    Дефолт `enabled=True` — объект, собранный руками (тесты playground'а, diag-скрипты), представляет
    уже измеренные данные; реальное состояние всегда проставляет хендлер.

    `cvd` — время в вызовах внешнего сервиса ССЗ (airi_ssz), НЕ входящее в `formula`. Вызов физически
    живёт внутри цикла инструментов (FormulaPipeline._calculate_airi), поэтому без разделения сетевой
    round-trip маскировался бы под счёт формул: на замере 8000 команд `formula` показывал
    p99 8.2 / max 57.8мс, и весь max был одним 56.6мс-ответом cvd, а не нашим CPU. Шаг `cvd`
    открывается внутри шага `formula` на этом же sink'е, поэтому вычитается из него автоматически
    (см. TimingSink): `formula` показывает только in-process расчёт инструментов, а хвост внешнего
    сервиса виден отдельной строкой.
    """

    ran: bool = False
    load_ms: float = 0.0
    formula_ms: float = 0.0
    cvd_ms: float = 0.0
    questionnaire_ms: float = 0.0
    upsert_ms: float = 0.0
    interpretation_ms: float = 0.0
    # Разбивка load_ms по отдельным async-читателям `_load` (см. LoadTimings).
    load: LoadTimings = field(default_factory=LoadTimings)
    # Разбивка interpretation_ms по фазам InterpretationHandler.run_for (аккумулируется по пациентам).
    interpretation: InterpretationTimings = field(default_factory=InterpretationTimings)


# Общий sink для выключенного сбора: при `enabled=False` в него не пишет никто (`step()` отдаёт
# no-op), поэтому боевой путь может переиспользовать один объект вместо аллокации дерева
# из четырёх dataclass'ов на каждый диспатч.
_DISABLED_TIMINGS = StepTimings()
_DISABLED_TIMINGS.enable(False)
