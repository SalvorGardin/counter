"""Monolog-compatible JSON logger for Risk Model Service."""

import functools
import json
import logging
import os
import sys
import urllib.parse
import uuid
from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any

from pydantic import ValidationError

from src.constants import DEFAULT_LOG_MASK_KEYS, normalize_mask_key

# --- Per-request context vars ---
# Точки входа (lifespan, calc_consumer._main) устанавливают осмысленный ID вида
# "startup-<pid>" / "shutdown-<pid>" / "calc-consumer-<pid>" до первого notice().
# Middleware переопределяет значение для каждого входящего запроса.
# UUID-дефолт — страховочный fallback для кода, запущенного вне любого из этих контекстов.
request_id_var: ContextVar[str] = ContextVar("request_id", default=str(uuid.uuid4()))
authorization_var: ContextVar[str | None] = ContextVar("authorization", default=None)
debug_enabled_var: ContextVar[bool] = ContextVar("debug_enabled", default=False)
# Нормализованное значение X-Enable-Debug для прокидывания в downstream-сервисы.
# Middleware приводит к canonical "true"/"" — сырое клиентское значение наружу не уходит
# (защита от длинных пэйлоадов и инъекций в headers, см. main.py:request_middleware).
x_enable_debug_var: ContextVar[str] = ContextVar("x_enable_debug", default="")


# --- Fingers-crossed (per-request INFO buffer) ---
# Паттерн из Monolog: INFO копится в буфере и выводится только если в этом же запросе
# случился ERROR+. Реализован через ContextVar — буферы разных запросов изолированы (async-safe).
# Только для HTTP — для фоновых задач спека прямо запрещает: длинный процесс может копить
# буфер бесконечно. Middleware создаёт буфер на входе и сбрасывает на выходе.
class FingersBuffer:
    __slots__ = ("records", "triggered")

    def __init__(self) -> None:
        self.records: list[logging.LogRecord] = []
        self.triggered: bool = False


fingers_crossed_var: ContextVar[FingersBuffer | None] = ContextVar("fingers_crossed", default=None)

# --- Business channel ---
# Спека (стр. 5, checklist стр. 7): INFO + channel="business" — единственный легальный путь
# писать info в проде постоянно, в обход fingers-crossed. Используется для бизнес-событий
# (questionnaire completed, kafka produced) и аудит-точек.
BUSINESS_CHANNEL = "business"

# --- Custom Monolog levels (не покрытые стандартным logging) ---
NOTICE = 25
ALERT = 55
EMERGENCY = 60

logging.addLevelName(NOTICE, "NOTICE")
logging.addLevelName(ALERT, "ALERT")
logging.addLevelName(EMERGENCY, "EMERGENCY")

_MONOLOG_CODES: dict[int, int] = {
    logging.DEBUG: 100,
    logging.INFO: 200,
    NOTICE: 250,
    logging.WARNING: 300,
    logging.ERROR: 400,
    logging.CRITICAL: 500,
    ALERT: 550,
    EMERGENCY: 600,
}

_LEVEL_NAME_TO_NUM: dict[str, int] = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "NOTICE": NOTICE,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
    "ALERT": ALERT,
    "EMERGENCY": EMERGENCY,
}

# --- PII guard ---
# Превентивная маскировка значений по ключам в context. Список конфигурируется через env
# RISK_MODEL_LOG_MASK_KEYS (CSV, см. config.log_mask_keys) — на стенде сужается/расширяется
# без правки кода; секреты транспорта валидатор Settings вливает принудительно.
# Дефолт и нормализация — src/constants.py (без зависимостей: config и logger импортируют оттуда).
# Точечные утечки фиксятся в коде, санитайзер — последний рубеж.
# Stacktrace в context["exception"] не маскируется — это известное ограничение,
# не логируем переменные в исключениях, см. CLAUDE.md.
_PII_MASK = "***"
# Глубина рекурсии маскировки: тела запросов у нас плоские либо с 1-2 уровнями вложенности,
# лимит защищает от патологически глубокого JSON на входе.
_MASK_MAX_DEPTH = 8

# Кэш распарсенного маск-листа, ключ — сырая CSV-строка: повторный split на каждую запись
# лога не нужен, а monkeypatch settings.log_mask_keys в тестах инвалидирует кэш сменой ключа.
_mask_keys_cache: tuple[str, frozenset[str]] | None = None
# Одноразовый маркер срабатывания fallback: иначе кастомный RISK_MODEL_LOG_MASK_KEYS,
# молча проигнорированный из-за невалидного конфига, недиагностируем по выводу сервиса.
_mask_keys_fallback_reported = False


def _mask_keys() -> frozenset[str]:
    """Лениво читает список ключей из settings; если конфиг ещё не загружается (boot-order:
    ошибку самого конфига негде было бы залогировать) — работаем по прод-безопасному дефолту.
    Ловим только два ожидаемых сбоя: ImportError (цикл/отсутствие модуля на раннем старте)
    и ValidationError (невалидный env, Settings() падает при импорте). Остальное пробрасываем."""
    global _mask_keys_cache, _mask_keys_fallback_reported
    try:
        from src.config import settings  # noqa: PLC0415
    except (ImportError, ValidationError):
        raw = DEFAULT_LOG_MASK_KEYS
        if not _mask_keys_fallback_reported:
            _mask_keys_fallback_reported = True
            # В stderr, не через logging: _mask_keys() вызывается из форматтера — лог отсюда
            # ушёл бы в рекурсию. Одноразово: маркер нужен для диагностики, не для шума.
            sys.stderr.write("logger: settings unavailable, masking with DEFAULT_LOG_MASK_KEYS (boot-order fallback)\n")
    else:
        raw = settings.log_mask_keys
    if _mask_keys_cache is not None and _mask_keys_cache[0] == raw:
        return _mask_keys_cache[1]
    parsed = frozenset(normalize_mask_key(k.strip()) for k in raw.split(",") if k.strip())
    _mask_keys_cache = (raw, parsed)
    return parsed


def _mask_recursive(value: Any, keys: frozenset[str], depth: int) -> Any:
    if depth >= _MASK_MAX_DEPTH:
        # Не отдаём немаскированное поддерево: глубже лимита может прятаться ключ из списка.
        return "...[depth limit]"
    if isinstance(value, dict):
        return {
            k: (
                _PII_MASK
                if isinstance(k, str) and normalize_mask_key(k) in keys
                else _mask_recursive(v, keys, depth + 1)
            )
            for k, v in value.items()
        }
    if isinstance(value, list | tuple):
        return [_mask_recursive(item, keys, depth + 1) for item in value]
    return value


# Контекст-ключи, чьи значения сериализуются в ОДНУ JSON-строку после маскировки.
# Зачем строка, а не объект: (1) в Kibana объект не выводится одной колонкой (ячейка пустая) —
# строку видно целиком; (2) единый тип text во всех индексах (нет ES type=conflict);
# (3) нет mapping explosion от произвольных ключей тел (например мусорные JSON-RPC-пэйлоады).
# Цена: по под-полям (request_body.gender) фильтровать нельзя — только полнотекст по строке.
_BLOB_CONTEXT_KEYS: frozenset[str] = frozenset({"request_body", "response_body", "request_headers"})


def _sanitize_context(ctx: dict[str, Any]) -> dict[str, Any]:
    """Маскирует значения ключей из env-списка (config.log_mask_keys) рекурсивно по вложенным
    dict/list, затем сериализует blob-поля (тело/заголовки) в одну JSON-строку. Маскировка идёт
    ДО сериализации — внутри строки ключи уже `***`, формат­тер в неё повторно не зайдёт."""
    if not ctx:
        return ctx
    masked = _mask_recursive(ctx, _mask_keys(), 0)
    return {
        k: (json.dumps(v, ensure_ascii=False) if k in _BLOB_CONTEXT_KEYS and isinstance(v, dict | list) else v)
        for k, v in masked.items()
    }


def body_marker(reason: str) -> dict[str, str]:
    """Маркер «тело не залогировано как структура» — ВСЕГДА dict, не строка.

    Контракт типа для Elasticsearch: ES выводит маппинг поля динамически по первому документу
    индекса. Если `context.request_body` окажется в одном индексе строкой (маркер), а в другом
    объектом — поле across индексов становится `type=conflict`, и Kibana делает его неюзабельным
    (нельзя фильтровать / добавить колонкой / агрегировать). Поэтому ВСЕ маркеры — dict.
    """
    return {"_omitted": reason}


def body_for_log(raw: bytes, max_bytes: int, content_type: str = "") -> dict[str, Any] | None:
    """Готовит тело HTTP-запроса/ответа к укладке в log_context.

    ВСЕГДА возвращает dict или None (см. body_marker про контракт типа для ES). JSON-объект
    кладётся как есть и маскируется по ключам в _sanitize_context; form-urlencoded парсится
    в dict; не-объектный JSON (скаляр/массив — ключей для маскировки нет) оборачивается в
    {"_value": ...}; plaintext/бинарь/сверхлимит → dict-маркер. Пустое тело → None.
    """
    if not raw:
        return None
    if len(raw) > max_bytes:
        return body_marker(f"{len(raw)} bytes > {max_bytes} cap")
    try:
        parsed = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        pass
    else:
        # JSON-объект — как есть; скаляр/массив оборачиваем, чтобы поле осталось object-типа
        # (маскировка по ключам всё равно отработает: _mask_recursive заходит в list/dict).
        return parsed if isinstance(parsed, dict) else {"_value": parsed}
    if content_type.split(";")[0].strip().lower() == "application/x-www-form-urlencoded":
        pairs = urllib.parse.parse_qsl(raw.decode("utf-8", errors="replace"), keep_blank_values=True)
        return dict(pairs)
    return body_marker(f"unstructured {len(raw)} bytes, content-type={content_type or 'unknown'}")


def _resolve_level(name: str) -> int:
    return _LEVEL_NAME_TO_NUM.get(name.upper(), NOTICE)


def _threshold() -> int:
    """Лениво читает порог из settings. Если конфиг ещё не валиден (например, пустая строка
    подключения на старте), не роняем логгер — иначе саму ошибку конфига негде залогировать."""
    try:
        from src.config import settings  # noqa: PLC0415
    except Exception:
        return NOTICE
    return _resolve_level(settings.log_level)


class MonologFilter(logging.Filter):
    """Гейтит DEBUG (только при X-Enable-Debug). Внутри request-контекста (fingers_crossed_var
    установлен) пропускает все INFO+ — финальное решение (вывести/буферизовать/слить) принимает
    FingersCrossedHandler. Вне request-контекста — прежняя логика: уровень >= settings.log_level.

    Исключение по спеке (стр. 5, checklist стр. 7): INFO с channel="business" выходит всегда,
    независимо от threshold и fingers-crossed — это узаконенный канал для «всегда писать»
    бизнес-событий (questionnaire completed, kafka message produced, аудит-точки)."""

    def filter(self, record: logging.LogRecord) -> bool:
        if debug_enabled_var.get():
            return True
        if record.levelno < logging.INFO:
            return False
        if getattr(record, "channel", "app") == BUSINESS_CHANNEL:
            return True
        if fingers_crossed_var.get() is not None:
            return True
        return record.levelno >= _threshold()


class FingersCrossedHandler(logging.Handler):
    """Per-request буфер INFO. Логи ниже штатного порога копятся в FingersBuffer из ContextVar;
    при появлении ERROR+ в том же запросе — буфер сливается в хронологическом порядке, после чего
    handler работает passthrough до конца запроса. Без триггера буфер выбрасывается при сбросе
    ContextVar (в middleware). Вне request-контекста или с X-Enable-Debug — passthrough сразу."""

    def __init__(self, target: logging.Handler) -> None:
        super().__init__()
        self._target = target

    def emit(self, record: logging.LogRecord) -> None:
        # Используем target.handle() (не emit) — handle берёт target.lock перед записью в stdout.
        # При concurrent выводе из threadpool (BackgroundTasks) прямой emit() порождал бы
        # interleaved-байты на уровне stream, ломая отдельные JSON-строки. См. MemoryHandler.flush.
        buf = fingers_crossed_var.get()
        if buf is None or debug_enabled_var.get():
            self._target.handle(record)
            return

        # channel="business" — постоянный канал по спеке, мимо буфера: бизнес-событие
        # должно дойти в Kibana независимо от error-цепочки запроса.
        if getattr(record, "channel", "app") == BUSINESS_CHANNEL:
            self._target.handle(record)
            return

        # ERROR+ триггерит буфер: выводим всё накопленное в хронологическом порядке до самой записи.
        if record.levelno >= logging.ERROR and not buf.triggered:
            buf.triggered = True
            for rec in buf.records:
                self._target.handle(rec)
            buf.records.clear()

        if buf.triggered or record.levelno >= _threshold():
            self._target.handle(record)
        else:
            buf.records.append(record)


class MonologFormatter(logging.Formatter):
    """Форматирует записи в JSON по стандарту Monolog."""

    def format(self, record: logging.LogRecord) -> str:
        context: dict[str, Any] = _sanitize_context(dict(getattr(record, "log_context", {})))
        if record.exc_info:
            context["exception"] = self.formatException(record.exc_info)

        # record.created — момент вызова logger.X(); важно для буферизованных записей,
        # которые форматируются позже (на флаше из FingersCrossedHandler) — иначе все INFO
        # получили бы timestamp ошибки и потеряли хронологию в Kibana/ELK.
        entry = {
            "message": record.getMessage(),
            "level": _MONOLOG_CODES.get(record.levelno, 200),
            "level_name": logging.getLevelName(record.levelno),
            "channel": getattr(record, "channel", "app"),
            "datetime": datetime.fromtimestamp(record.created, tz=UTC).astimezone().isoformat(timespec="microseconds"),
            "context": context,
            "extra": {
                "requestId": request_id_var.get(),
                "authorization": authorization_var.get(),
            },
        }
        return json.dumps(entry, ensure_ascii=False)


def _component_from_record(record: logging.LogRecord) -> str:
    """Пакет-квалифицированное имя модуля-источника для лейбла `component`.

    `record.module` — только имя файла, поэтому `calc/handler.py` и `interpretation/handler.py`
    оба дали бы `component="handler"` и по метрике не различить домен сбоя. Берём путь
    относительно каталога `src/`: `calc.handler`, `interpretation.handler`. Кардинальность
    остаётся ограниченной (число модулей), значение — из своего же кода, не из ввода клиента.
    Код вне `src/` (тесты, сторонние библиотеки) — как есть, по `record.module`.
    """
    path = record.pathname or ""
    marker = f"{os.sep}src{os.sep}"
    idx = path.rfind(marker)
    if idx == -1:
        return record.module
    rel = path[idx + len(marker) :].removesuffix(".py")
    return rel.replace(os.sep, ".") or record.module


class _MetricsHandler(logging.Handler):
    """Инкрементит `risk_profile_core_errors_total` на каждый лог-рекорд уровня ERROR и выше.

    Ловит и «200-но-ошибка»: фоновый сбой ПОСЛЕ отданного ответа (например, фейл enqueue в
    Kafka) — это тоже ERROR-запись, а значит попадёт в счётчик без ручных инкрементов в
    бизнес-коде. Лейблы: level (error/critical/alert/emergency) и component — пакет-квалифицированный
    модуль вызвавшего кода (для верного модуля хелперы прокидывают stacklevel, см. _log/business).

    Подключается НАПРЯМУЮ к логгеру, а не внутрь FingersCrossedHandler: счётчик должен видеть
    ERROR независимо от буферизации fingers-crossed. Метрику не форматирует и вывод не пишет.
    """

    def emit(self, record: logging.LogRecord) -> None:
        if record.levelno < logging.ERROR:
            return
        try:
            # Ленивый импорт: metrics самодостаточен (не тянет config/logger), но держим завязку
            # logger→metrics ленивой из тех же соображений boot-order, что и весь модуль metrics.
            from src.metrics import ERRORS_TOTAL  # noqa: PLC0415

            ERRORS_TOTAL.labels(level=record.levelname.lower(), component=_component_from_record(record)).inc()
        except Exception:
            # Инкремент счётчика — некритичный побочный эффект логирования: любой его сбой НЕ
            # должен всплыть в вызов logger.error(...). Молча (handleError печатал бы в stderr).
            self.handleError(record)

    def handleError(self, record: logging.LogRecord) -> None:  # noqa: N802 — override stdlib Handler.handleError
        # Тихо: сбой инкремента метрики не стоит stderr-трейса на каждую запись (иначе во время
        # инцидента, который и так сыплет ERROR, каждый сбой удваивал бы вывод). Имя camelCase —
        # обязательное, это переопределение метода logging.Handler.
        return


def _make_logger() -> logging.Logger:
    log = logging.getLogger("app")
    if log.handlers:
        return log
    log.setLevel(logging.DEBUG)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(MonologFormatter())
    # Filter — на FingersCrossedHandler, чтобы DEBUG отсекался до буфера и не оседал в нём.
    fc = FingersCrossedHandler(stream)
    fc.addFilter(MonologFilter())
    log.addHandler(fc)
    # Счётчик ошибок — отдельным handler'ом напрямую на логгере (не внутри fingers-crossed):
    # ERROR+ инкрементит метрику вне зависимости от того, буферизуется запись или нет. Без
    # фильтра — сам гейтит уровень в emit; DEBUG/INFO до inc() не доходят.
    log.addHandler(_MetricsHandler())
    log.propagate = False
    return log


logger = _make_logger()


def debug_enabled() -> bool:
    """True, если для текущего запроса включён DEBUG (X-Enable-Debug).

    Логгер "app" поднят на уровне DEBUG (гейтинг делает MonologFilter, а не уровень логгера),
    поэтому logger.isEnabledFor(DEBUG) всегда True и для пропуска работы не годится. Реальное
    условие, при котором logger.debug(...) что-то выведет, — этот флаг: вне DEBUG-режима
    MonologFilter отсекает DEBUG-запись ещё до вывода и до fingers-crossed буфера. На горячем
    пути дорогую сборку log_context можно пропустить под этим гейтом без потери логов."""
    return debug_enabled_var.get()


def _log(
    level: int,
    message: str,
    context: dict[str, Any] | None = None,
    *,
    exc_info: BaseException | bool | None = None,
) -> None:
    # stacklevel=3: user → notice/alert/emergency → _log → logger.log. Чтобы record.module
    # (лейбл component у errors_total) указывал на реального вызывающего, а не на logger.py.
    # На JSON-вывод не влияет — MonologFormatter модуль/строку не печатает.
    logger.log(level, message, extra={"log_context": context or {}}, exc_info=exc_info, stacklevel=3)


def notice(message: str, context: dict[str, Any] | None = None) -> None:
    _log(NOTICE, message, context)


def business(message: str, context: dict[str, Any] | None = None) -> None:
    """Бизнес-событие на канале "business". INFO-уровень, но выходит всегда (мимо fingers-crossed
    и порога) — по спеке стр. 5: «логи info постоянно — отправлять в channel: business»."""
    # stacklevel=2: user → business → logger.log (business зовёт logger.log напрямую, без _log),
    # чтобы record.module указывал на вызывающего. INFO в счётчик ошибок не попадает.
    logger.log(
        logging.INFO,
        message,
        extra={"log_context": context or {}, "channel": BUSINESS_CHANNEL},
        stacklevel=2,
    )


def alert(message: str, context: dict[str, Any] | None = None, *, exc_info: BaseException | bool | None = None) -> None:
    _log(ALERT, message, context, exc_info=exc_info)


def emergency(
    message: str, context: dict[str, Any] | None = None, *, exc_info: BaseException | bool | None = None
) -> None:
    _log(EMERGENCY, message, context, exc_info=exc_info)


def with_request_context[T](task: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """Snapshot request-ContextVar'ов сейчас + восстановление при вызове в фоновой задаче.

    Зачем: спека требует сквозного requestId для логов фоновых операций, порождённых
    API-запросом (стр. 5-6, «Сквозное логирование»). FastAPI BackgroundTasks для async-задач
    обычно сохраняет ContextVar'ы через event loop, но это implementation detail Starlette —
    при апдейте фреймворка / переходе задачи на sync (run_in_threadpool) — пропагация молча
    ломается. Явный wrapper закрывает обе схемы и делает контракт самодокументирующим.

    Снимаем все request-vars кроме fingers_crossed_var: для фоновых задач спека прямо
    запрещает fingers-crossed (риск бесконечного буфера в долгом процессе). Изоляция от
    исходного FC-буфера — структурная (force-set в None внутри wrapped), а не таймингом
    middleware-finally: иначе при вложенном вызове / тесте без полной имитации middleware
    буфер протёк бы в фоновую задачу.

    Использование:
        background.add_task(with_request_context(dispatcher), client_id, codes)
    """
    req_id = request_id_var.get()
    auth = authorization_var.get()
    debug = debug_enabled_var.get()
    x_debug = x_enable_debug_var.get()

    @functools.wraps(task)
    async def wrapped(*args: object, **kwargs: object) -> T:
        t_req = request_id_var.set(req_id)
        t_auth = authorization_var.set(auth)
        t_dbg = debug_enabled_var.set(debug)
        t_x = x_enable_debug_var.set(x_debug)
        t_fc = fingers_crossed_var.set(None)
        try:
            return await task(*args, **kwargs)
        finally:
            fingers_crossed_var.reset(t_fc)
            x_enable_debug_var.reset(t_x)
            debug_enabled_var.reset(t_dbg)
            authorization_var.reset(t_auth)
            request_id_var.reset(t_req)

    return wrapped
