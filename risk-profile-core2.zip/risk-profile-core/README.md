# risk-model

ML-сервис оценки рисков. Предоставляет HTTP API для инференса модели.

- Репозиторий: https://gitverse.ru/health-industry-center/risk-model
- Зеркало: https://github.com/Health-Industry-Center/risk-model

---

## 1. Архитектура и pipeline

Сервис реализован на FastAPI и запускается через Uvicorn. Входящий запрос проходит следующий pipeline:

```
HTTP-запрос → валидация входных данных → предобработка → инференс модели → постобработка → JSON-ответ
```

Каждый шаг логирует время выполнения (`duration_ms`) в stdout в формате JSON (Monolog).

Сервис работает в CPU-only режиме, без GPU.

---

## 2. Техническое описание модели

| Параметр | Значение |
|---|---|
| Тип модели | — |
| Формат весов | OCI-артефакт |
| Входные данные | JSON-объект с признаками |
| Выходные данные | JSON-объект с оценкой риска и вероятностью |
| Предобработка | Нормализация, кодирование категориальных признаков |
| Постобработка | Калибровка вероятности |
| Размер модели | — |

> Детали заполняются после финализации модели.

---

## 3. Коды ошибок

| HTTP-код | Описание |
|---|---|
| 200 | Успешный ответ |
| 422 | Ошибка валидации входных данных |
| 500 | Внутренняя ошибка сервиса |

---

## 4. Сборка и запуск Docker-образа

```bash
# Сборка
docker build -f docker/Dockerfile -t risk-model:latest .

# Запуск
docker run --rm -p 8000:8000 risk-model:latest
```

Образ собирается под `linux/amd64`, базовый образ `python:3.12-slim-bookworm`.

---

## 4.0. Деплой: app-tier и инфраструктура — раздельные compose-проекты

Compose разбит на два **независимых проекта** в одной папке:

| Файл | Проект | Сервисы | Жизненный цикл |
|---|---|---|---|
| `docker-compose.yml` | `risk-profile-core` | `db`, `migrations`, `app`, `consumer`, `emr-consumer` (+ профиль `cvd`) | пересобирается каждым релизом |
| `docker-compose.infra.yml` | `risk-profile-infra` | `kafka`, `kafka-init`, `kafka-acls-init`, `kafka-ui`, ELK (`elasticsearch`/`es-setup`/`kibana`/`filebeat`) (+ профиль `llm`: `llm-redis`, `llm-gateway-1`, `llm-gateway-2`) | долгоживущая, поднимается вручную |

Зачем разделение: релиз гоняет **только** app-tier
(`docker compose -f docker-compose.yml up -d --build`, см. [.gitlab-ci.yml](.gitlab-ci.yml)),
поэтому физически не может остановить брокер или ELK — даже `down`/`--remove-orphans`
не выходят за пределы проекта `risk-profile-core`. Раньше Kafka/ELK висели профилями в
том же файле, и частичный реконсайл при деплое ронял брокер, а `consumer` уходил в
restart-loop, не видя Kafka.

> **Важно:** имя проекта compose берёт из имени папки, а флаг `-f` его не меняет.
> Поэтому в обоих файлах имя зафиксировано через top-level `name:` — иначе два файла
> в одной папке слились бы в один проект и считали бы контейнеры друг друга orphan'ами.

Связь между проектами — общая external-сеть `risk-net` (по ней `app`, `consumer` и
`emr-consumer` резолвят брокер по hostname `kafka`):

```bash
docker network create risk-net          # один раз на хосте

make infra-up                           # поднять Kafka + ELK (создаёт risk-net, если нет)
make infra-down                         # погасить инфраструктуру (релиз её не трогает)
```

`make infra-up` / `infra-down` — обёртки над `docker compose -f docker-compose.infra.yml
up -d` / `down`. Тома Kafka/ES запинены на прежние имена (`risk-profile-core_kafka-data`,
`risk-profile-core_es-data`), поэтому топики/оффсеты/индексы переезжают без потерь.
Провижининг встроен в сам стек: `kafka-init` создаёт топики, `kafka-acls-init` раздаёт ACL для
`risk-app`, а `es-setup` настраивает пользователей, ILM и index template (все one-shot,
идемпотентны). `infra-up` **блокируется** до их завершения
([scripts/wait_oneshot.sh](scripts/wait_oneshot.sh)) и возвращает управление, только когда
инфраструктура настроена. Это важно на стенде/проде: app-tier деплой, запущенный после `infra-up`,
стартует с готовыми ACL, а не ловит `unauthorized` (aiokafka кэширует его без ретрая). Руками
`kafka-acls` дёргать не нужно.

Локальный быстрый путь (`make docker-up`, см. §4.1) поднимает оба проекта разом —
Kafka из infra-проекта (без ELK) и приложение из core — и настраивает ACL.

### LLM gateway (профиль `llm`)

`llm-gateway-1`, `llm-gateway-2` и их `llm-redis` — HTTP-шлюз к GigaChat для клиентов вне ядра;
ядро его не вызывает. Образ собирается из копии репозитория `zozh/ml/zozh_giga_gateway`, которую
кладут и обновляют вручную (`LLM_GATEWAY_CONTEXT`, по умолчанию `../risk-profile-llm-gateway`).
Реплики слушают хост-порты 18010 и 18011 (`LLM_GATEWAY_PORT_1`/`LLM_GATEWAY_PORT_2`) и делят
через Redis общий пул параллельных запросов к GigaChat.

Gateway в этом стеке — только для dev-стенда, не для прода: на проде он общий для всех сервисов
и разворачивается отдельно от этого репозитория, профиль `llm` там не включать.

Локально gateway не нужен, поэтому сервисы под профилем `llm`: без него `make infra-up` и
`make infra-down` их не трогают. На dev-стенде профиль включается один раз в `.env`, и дальше
`make infra-up` собирает (если образа ещё нет) и поднимает gateway вместе с Redis:

```bash
# исходники gateway уже лежат в ../risk-profile-llm-gateway
cp deploy/llm-gateway/gateway.env.example deploy/llm-gateway/gateway.env   # токен, учётные данные GigaChat
cp deploy/llm-gateway/redis.env.example deploy/llm-gateway/redis.env       # пароль Redis
echo 'COMPOSE_PROFILES=llm' >> .env
make infra-up
```

`COMPOSE_PROFILES` читают оба compose-проекта этой папки. В `docker-compose.yml` профиля `llm`
нет, поэтому на релиз ядра значение не влияет.

Секреты gateway лежат в `deploy/llm-gateway/*.env`, а не в `.env`: `.env` целиком попадает в
контейнеры приложения. `redis.env` подключён к Redis и к gateway, `gateway.env` — только к gateway.

После обновления копии исходников — `make llm-gateway-rebuild`: пересборка обеих реплик, Redis
не пересоздаётся. Копию обновлять целиком, вместе с `.dockerignore`: он не пускает в сборку `.env`.

Требование к версии копии: в `app/limiter/redis_semaphore.py` должна быть обработка
`NoScriptError` (проверить: `grep -c NoScriptError app/limiter/redis_semaphore.py` больше нуля).
Перезапуск стирает из Redis загруженные gateway Lua-скрипты. Без этой обработки после того, как
Redis перезапустился сам, каждый запрос генерации получает 500, пока gateway не перезапустят
вручную, а Docker при этом считает gateway здоровым и сам его не перезапускает.

Что происходит, когда Redis останавливается:

- Redis завершился сам, в том числе штатно по SIGTERM, — Docker поднимает его по
  `restart: unless-stopped`. Gateway не перезапускается: пока фоновая проверка не увидит Redis
  снова (около 30 с), запросы генерации получают `503 limiter_unavailable`, затем работа
  продолжается (при версии копии из требования выше).
- `docker compose -f docker-compose.infra.yml restart llm-redis` перезапускает и gateway
  (`depends_on` с `restart: true`).
- Остановленный вручную (`docker stop`) Redis политика рестарта не поднимает — его поднимает
  `make infra-up`.

Данные Redis хранятся в томе `llm-redis-data` и переживают пересоздание контейнера.

### Очистка логов ELK на dev-сервере

Только контейнеры `elasticsearch` и `kibana` ограничивают собственные `json-file`-логи: по
умолчанию три файла по 50 MB. Лимиты можно изменить через `DOCKER_LOG_MAX_SIZE` и
`DOCKER_LOG_MAX_FILE`; новые значения применяются после пересоздания этих контейнеров. Логирование
сервисов из `docker-compose.yml` не меняется.

`es-setup` идемпотентно создаёт для `docker-logs-*` deletion-only ILM policy с retention 30 дней,
index template с одной primary shard и без replicas и подключает policy к существующим индексам.
Индексы старше 30 дней могут быть удалены при следующем проходе ILM; dev-логи не архивируются.

Docker build cache находится на хосте и не относится к Compose volumes или Elasticsearch ILM. На
dev-сервере для него можно один раз установить user-cron текущего пользователя:

```bash
make infra-install-cache-prune
```

Команда идемпотентно создаёт или обновляет одну cron-запись с маркером
`risk-profile-build-cache-prune`. По умолчанию очистка запускается ежедневно в 03:17, резервирует
1 GB cache, ограничивает cache значением 5 GB и старается оставить на диске не менее 10 GB. Скрипт
не вызывает очистку контейнеров, application images или volumes. Одновременные запуски блокируются
через `flock`, журнал находится в
`~/.local/state/risk-profile/build-cache-prune.log`.

Расписание и пределы фиксируются в cron-записи в момент установки и могут быть переопределены:

```bash
DOCKER_BUILD_CACHE_PRUNE_SCHEDULE="17 3 * * *" \
DOCKER_BUILD_CACHE_RESERVED_SPACE=1gb \
DOCKER_BUILD_CACHE_MAX_USED_SPACE=5gb \
DOCKER_BUILD_CACHE_MIN_FREE_SPACE=10gb \
make infra-install-cache-prune
```

Ручной запуск и удаление задания:

```bash
make infra-prune-build-cache
make infra-remove-cache-prune
```

Для новых версий Buildx используются space-aware параметры. На старой версии Docker скрипт
автоматически переключается на совместимый `docker builder prune --keep-storage` и пишет
предупреждение, потому что этот режим не умеет гарантировать минимальное свободное место.

---

## 4.1. Локальный Kafka (SASL_SSL + SCRAM-SHA-512 + ACL)

Для разработки приложение умеет публиковать сообщения в Kafka. Локальный брокер живёт
в `docker-compose.infra.yml` (проект `risk-profile-infra`, см. §4.0) и поднимается
через `make infra-up`. На dev-стенде и проде Kafka разворачивается так же — отдельным
проектом, релиз ядра её не трогает.

Аутентификация: **SASL/SCRAM-SHA-512 поверх TLS**. Клиент идентифицируется
логином/паролем, транспорт шифруется. Сертификат нужен только серверный — чтобы
клиент мог удостовериться в идентичности брокера; mTLS не используется.

> **Быстрый путь:** `make docker-up` ([scripts/docker_up.sh](scripts/docker_up.sh)) делает
> всё разом — генерит сертификаты, поднимает инфра-стек (Kafka + провижининг топиков и ACL
> сервисами `kafka-init`/`kafka-acls-init`), дожидается их завершения и запускает приложение
> (включая `consumer` и `emr-consumer`). `make docker-down` — снести всё. Ниже — те же шаги
> вручную, для понимания.
>
> **Итерация по коду:** `make docker-rebuild` пересобирает и перезапускает только app-tier
> (`docker-compose.yml`), не трогая Kafka и ELK, — одна команда, чтобы поднять контейнеры
> с текущими изменениями. Ограничить набор сервисов: `make docker-rebuild ARGS="app consumer"`.

### Шаг 1. Сгенерить серверный TLS-cert

```bash
./scripts/generate_kafka_certs.sh
```

Скрипт создаёт в `./certs/` (gitignored):
- `ca.crt` / `ca.key` — корневой CA окружения (10 лет)
- `kafka.crt` / `kafka.key` — сертификат брокера (SAN: `kafka, localhost, 127.0.0.1`)

CA локальной разработки и CA dev-стенда — **независимы**: не переносите ключи
между окружениями.

> Скрипт ставит файлам `chmod 644`. App работает под non-root внутри контейнера,
> у него UID отличается от хостового владельца — без world-read загрузка CA в
> ssl-контекст упадёт с `PermissionError`. Для dev приемлемо; на проде использовать
> managed-секреты или `chown` на UID контейнерного пользователя.

### Шаг 2. Задать пароли и поднять Kafka

В `.env` (см. [.env.example](.env.example)) выставить:

```
RISK_MODEL_KAFKA__ENABLED=true
RISK_MODEL_KAFKA__SASL_USERNAME=risk-app
RISK_MODEL_KAFKA__SASL_PASSWORD=<пароль app>
KAFKA_ADMIN_PASSWORD=<пароль admin>
KAFKA_APP_PASSWORD=<тот же пароль app>
```

`KAFKA_ADMIN_PASSWORD` / `KAFKA_APP_PASSWORD` нужны только compose'у — он
прокидывает их в брокер на старте и в `kafka-init` для подключения под admin.
`RISK_MODEL_KAFKA__SASL_PASSWORD` — то, под чем коннектится приложение.

```bash
docker compose -f docker-compose.infra.yml up -d --build

# Проверить, что топики созданы и ACL выданы (оба сервиса завершились с кодом 0)
docker compose -f docker-compose.infra.yml logs kafka-init kafka-acls-init
```

`kafka-init` подключается под `risk-admin` (super.user) и идемпотентно создаёт
топики из `KafkaTopicsSettings` ([src/config.py](src/config.py)).

### Шаг 3. ACL для приложения (выдаются автоматически)

Дефолтная политика брокера — `allow.everyone.if.no.acl.found=false`, поэтому без ACL
`risk-app` (не super.user) ничего не сможет. Права раздаёт one-shot-сервис
**`kafka-acls-init`** при подъёме infra (идемпотентно, под `risk-admin`). Он выдаёт
`User:risk-app`:

- `--producer` на `risk-profile.test` и `risk-calculation` (`Write` + `Describe`);
- `--producer --consumer` на `risk-profile.recalc-commands` + `Read` на группу
  `risk-recalc-workers` (API пишет команды, consumer-воркер читает).

Имена топиков/группы и principal берутся из тех же `RISK_MODEL_KAFKA__*` в `.env`, что и у
приложения, — единый источник, руками `kafka-acls` при обычном подъёме дёргать не нужно.

Посмотреть/отладить ACL (например завести доп. принципала) можно внутри контейнера `kafka` —
CLI и admin-креда там доступны. Кладём admin-properties (подставляя пароль из `.env`) и
смотрим список:

```bash
docker compose -f docker-compose.infra.yml exec -T kafka bash -c "cat > /tmp/admin.properties <<EOF
security.protocol=SASL_SSL
sasl.mechanism=SCRAM-SHA-512
sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username=\"risk-admin\" password=\"${KAFKA_ADMIN_PASSWORD}\";
ssl.truststore.location=/opt/bitnami/kafka/config/certs/kafka.truststore.pem
ssl.truststore.type=PEM
EOF"

docker compose -f docker-compose.infra.yml exec kafka \
  /opt/bitnami/kafka/bin/kafka-acls.sh \
  --bootstrap-server kafka:9093 --command-config /tmp/admin.properties --list
```

`--producer` — шорткат: `Write` + `Describe` на топик (+ `IdempotentWrite` на cluster при
idempotence). `--consumer` — `Read` + `Describe` на топик + `Read` на группу.

> **Смена ACL на живом брокере:** aiokafka-продюсер кэширует «unauthorized»-топик и не
> сбрасывает его на metadata-refresh — после выдачи прав уже поднятым `app`/`consumer`
> нужен рестарт, чтобы продюсер переинициализировался. При свежем подъёме проблемы нет:
> `kafka-acls-init` отрабатывает до старта приложения.

### Шаг 4. Опубликовать тестовое сообщение

```bash
# нужен RISK_MODEL_TESTING_API_ENABLED=true
curl -X POST \
  -H "X-Test-Api-Key: $RISK_MODEL_TEST_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"key":"k1","payload":{"hello":"world"}}' \
  http://localhost:9001/api/v1/testing/kafka/produce
```

### Особенности

- 1 брокер, KRaft (без Zookeeper).
- SASL_SSL + SCRAM-SHA-512. Клиент аутентифицируется логином/паролем; транспорт шифруется TLS.
- SCRAM-юзеры (`risk-admin`, `risk-app`) поднимаются compose'ом из `KAFKA_CLIENT_USERS` / `KAFKA_CLIENT_PASSWORDS` — на старте брокер регистрирует их в KRaft-метадате.
- super.users: `User:risk-admin` (для `kafka-init` и `kafka-acls`) и `User:ANONYMOUS` (KRaft controller на PLAINTEXT без identity).
- Автосоздание топиков отключено; список — в `KafkaTopicsSettings`, выкат — `python -m src.workers.kafka_init`.
- Подключение к N брокерам — через CSV в `RISK_MODEL_KAFKA__BOOTSTRAP_SERVERS`, без правок compose.

---

## 4.2. Пересчёт риска через Kafka (consumer-воркер)

Пересчёт риск-профиля — CPU-bound (формулы SCORE2/FINDRISC/BCRAT/…) и DB-тяжёлый.
Раньше он выполнялся как FastAPI BackgroundTask **в том же event loop**, что и HTTP —
под нагрузкой loop забивался, и страдала обработка запросов. Теперь расчёт вынесен в Kafka:

```
POST /clients/{id}/...  ──► API публикует команду в topic risk-profile.recalc-commands
                                  (ключ = patient_id, acks=all; event loop API свободен)
                                            │
                                            ▼
        consumer-воркер (python -m src.workers.calc_consumer, отдельный процесс)
          ── разбирает команду ── считает риск ── upsert результатов ──
          ── публикует события calculation/interpretation в topic risk-calculation ─► downstream
```

- **Очередь работ** — одна consumer-группа `risk-recalc-workers` (competing consumers).
  Масштабирование — числом инстансов: `docker compose up -d --scale consumer=N`
  (`N ≤ RECALC_COMMANDS_PARTITIONS`). Несколько ГРУПП под одну задачу заводить нельзя —
  каждая получит полную копию команд (дубль-пересчёт).
- **Порядок на пациента** сохраняется: ключ сообщения = `patient_id` → все его команды
  в одной партиции → последовательная обработка (без гонок upsert результатов).
- **at-least-once**: оффсет коммитится только после обработки батча; пересчёт идемпотентен
  (upsert), поэтому повторная доставка после сбоя безопасна.
- **Fallback**: если `kafka.enabled=false` (локальная разработка без брокера) или брокер
  недоступен — API считает пересчёт inline в своём процессе, как раньше (команда не теряется).
  При `kafka.enabled=false` воркер просто простаивает.
- Параметры воркера (`MAX_CONCURRENCY`, `MAX_POLL_RECORDS`, тайм-ауты группы) — в `.env`,
  секция `RISK_MODEL_KAFKA__CONSUMER__*`. Подобраны под дев-стенд (16 vCPU, один брокер).
- Топик `risk-profile.recalc-commands` создаётся `python -m src.workers.kafka_init`
  с `RECALC_COMMANDS_PARTITIONS` партициями; ACL для `risk-app` — см. Шаг 3 выше.

---

## 4.3. Биомаркеры ЭМК из Kafka (consumer-воркер)

СберЗдоровье публикует результаты лабораторных исследований клиента в топик `emr-biomarkers`
(контракт — вики «Внешние-контракты-API/Emr-biomarkers»). Сервис читает топик отдельным
процессом и валидирует сообщения:

```
внешний продюсер ──► topic emr-biomarkers
                            │
                            ▼
   consumer-воркер (python -m src.workers.emr_biomarkers_consumer, отдельный процесс)
     ── разбор JSON ── валидация уровня сообщения ── валидация каждого биомаркера ──
     ── коды причин в логах (INVALID_MESSAGE / INVALID_BIOMARKER_FORMAT / INVALID_OPERATION_TYPE)
```

- **Свой процесс и своя consumer-группа** `risk-emr-biomarkers-workers`. Группа обязана
  отличаться от группы пересчёта: с общей группой воркеры отбирали бы друг у друга партиции.
- **Два уровня валидации**: нарушение на уровне сообщения (`clientId`, `biomarkers`) отбрасывает
  сообщение целиком, нарушение на уровне элемента массива пропускает только этот биомаркер.
  Отброшенное сообщение всё равно коммитит оффсет: передоставка кривых данных их не исправит.
- **Уровень логов — WARNING**: невалидные данные внешнего продюсера не должны инкрементировать
  `risk_profile_core_errors_total`. Итог разбора сообщения — `business`-событие со счётчиками
  «всего / принято / пропущено».
- **Название и значение биомаркера маскируются в логах по умолчанию**: `biomarker_name`
  и `biomarker_value` входят в `DEFAULT_LOG_MASK_KEYS` — рядом с `client_id` это медицинские
  данные. `biomarker_id`, `biomarker_code`, `biomarker_unit` и `biomarker_unit_code` остаются
  открытыми, по ним запись о пропуске трассируется. Чтобы увидеть значения при разборе инцидента
  на стенде, эти два ключа убирают из `RISK_MODEL_LOG_MASK_KEYS`.
- **Выключен по умолчанию** (`RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=false`): процесс
  простаивает, консюмер не создаётся, пробы зелёные.

**Порядок включения на стенде** (нарушение порядка = бесконечный бэкофф по ошибке авторизации
при внешне здоровом контейнере):

1. Прогнать провижининг: `make infra-up` (или `docker compose -f docker-compose.infra.yml up -d
   kafka-init kafka-acls-init`) — `kafka-init` создаст топик, `kafka-acls-init` выдаст `risk-app`
   Read на топик и на consumer-группу. Оба сервиса идемпотентны и берут имя топика и группы из тех
   же значений по умолчанию, что и код, поэтому правка `.env` для этого шага не нужна: переменные
   секции «Consumer-воркер биомаркеров ЭМК» в `.env.example` нужны только чтобы переопределить
   значение по умолчанию.
2. Выставить `RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=true` и перезапустить сервис
   `emr-consumer`. В логах должно появиться `kafka.consumer started` с топиком `emr-biomarkers`
   и группой `risk-emr-biomarkers-workers`.

Откат — выключить флаг и перезапустить воркер: consumer-группа сохранит оффсет.

---

## 5. Запуск тестов

```bash
# Установить зависимости
pip install -e ".[dev]"

# Запустить тесты
pytest

# Линтинг
ruff check src/ tests/
ruff format --check src/ tests/

# Проверка типов
ty check src/

# SAST
bandit -r src/ -c pyproject.toml
semgrep scan --config auto src/
```

---

## 6. Пользовательская документация

Сервис принимает запросы на порту `8000`. Все запросы и ответы — в формате JSON.

Для включения DEBUG-логирования передайте заголовок `X-Enable-Debug: true`.

---

## 7. API

### `GET /`

Приветственный эндпоинт.

```python
import httpx

response = httpx.get("http://localhost:8000/")
print(response.json())
# {"message": "Привет от Risk Model Service!"}
```

### `GET /health`

Healthcheck.

```python
response = httpx.get("http://localhost:8000/health")
print(response.json())
# {"status": "ok"}
```

### `GET /readiness`

Readiness probe — проверяет готовность сервиса к приёму трафика.

```python
response = httpx.get("http://localhost:8000/readiness")
print(response.json())
# {"status": "ready"}
```

### `GET /liveness`

Liveness probe — проверяет, что процесс жив.

```python
response = httpx.get("http://localhost:8000/liveness")
print(response.json())
# {"status": "alive"}
```

---

## 8. Владелец сервиса

Владелец: Health Industry Center

---

## Соответствие требованиям

| Требование | Статус | Примечание |
|---|---|---|
| Python 3.12+ | ✅ | |
| Базовый образ `python:3.12-slim-bookworm` | ✅ | |
| Non-root пользователь | ✅ | `appuser` |
| Минимум пакетов ОС | ✅ | |
| Версии зависимостей зафиксированы | ✅ | `==` в pyproject.toml |
| `version.json` в корне | ✅ | |
| `GET /health`, `/readiness`, `/liveness` | ✅ | |
| JSON-логирование (Monolog) | ✅ | `src/logger.py` |
| `extra.requestId` (UUID), `extra.authorization` | ✅ | |
| `duration_ms` в логах | ✅ | middleware |
| `X-Enable-Debug` header | ✅ | |
| CI: ruff, ty, bandit, semgrep, pytest | ✅ | |
| CI: SBOM + проверка лицензий | ✅ | |
| CI: Trivy | N/A | Не поддерживается облачными сборщиками Gitverse |
