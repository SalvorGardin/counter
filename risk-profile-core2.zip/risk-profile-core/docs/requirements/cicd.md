Источник требований: «Требования к ML-моделям v1.2» (статус: Согласование).
Имя требования: CI/CD — обязательные проверки

---

## CI/CD — обязательные проверки

Каждый ml-сервис должен проходить все четыре блока:

### 1. SAST
- `semgrep scan --config auto src/`
- `bandit -r src/ -c pyproject.toml`

### 2. Качество кода
- `pytest` — тесты
- `ruff check` + `ruff format --check` — линтинг и форматирование
- `ty check src/` — проверка типов (не mypy)

### 3. Зависимости
- Генерация SBOM через `cyclonedx-py environment --output-format JSON -o sbom.json`
- Проверка лицензий: `python scripts/check_licenses.py`

### 4. Сканирование образа
- Trivy: `trivy image --exit-code 1 --severity CRITICAL,HIGH --vuln-type os,library`
