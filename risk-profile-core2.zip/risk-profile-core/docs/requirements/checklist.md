Источник требований: «Требования к ML-моделям v1.2» (статус: Согласование).
Имя требования: Checklist перед PR

---

## Checklist перед PR

- [ ] Python 3.12+
- [ ] Базовый образ Debian 13 (bookworm)
- [ ] Non-root пользователь в Dockerfile
- [ ] `version.json` в корне
- [ ] Версии зависимостей зафиксированы
- [ ] Все лицензии MIT/Apache-2.0/BSD (нет GPL)
- [ ] `GET /health`, `/readiness`, `/liveness` реализованы
- [ ] Логи в stdout в JSON (Monolog), есть `extra.requestId`
- [ ] Каждый шаг логирует время выполнения
- [ ] Нет персональных данных в логах
- [ ] Поддержка `X-Enable-Debug`
- [ ] CI проходит: semgrep, bandit, ruff, ty, pytest, SBOM, trivy
