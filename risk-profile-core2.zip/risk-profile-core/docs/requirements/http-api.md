Источник требований: «Требования к ML-моделям v1.2» (статус: Согласование).
Имя требования: HTTP API

---

## HTTP API

- Входные и выходные параметры — **только JSON**.
- Обязательные эндпоинты:
  - `GET /health` — healthcheck
  - `GET /readiness` — readiness probe
  - `GET /liveness` — liveness probe
