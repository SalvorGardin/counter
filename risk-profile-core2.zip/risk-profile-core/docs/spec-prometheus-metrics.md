# Спека: метрики Prometheus для risk-profile-core (итерация 1 — app-процесс)

Статус: **APPROVED — к реализации**. Дата: 2026-07-16.
Ветка реализации: `feature/prometheus-metrics` (от `origin/develop`). Один MR в `develop`.

---

## 0. Протокол работы исполнителя (читать первым в каждой сессии)

Эта спека рассчитана на выполнение в **нескольких независимых сессиях** (Claude Code / Opus 4.8).
Контекст предыдущих сессий НЕ доступен — вся память живёт в этом файле.

Алгоритм сессии:

1. Прочитай разделы 0–4 целиком, затем таблицу Checkpoint (раздел 1) и Журнал сессий (раздел 8).
2. Возьми **первую сверху** задачу со статусом `TODO` (или продолжи `IN_PROGRESS`). Задачи
   T2–T5 независимы друг от друга, но не начинай их до `DONE` у T0 и T1.
3. Перед началом: `git status` — если рабочее дерево грязное чужими изменениями (не твоей
   задачей), остановись и спроси пользователя. Не переключай ветки, если есть чужая
   незакоммиченная работа.
4. Выполни задачу по её разделу (раздел 5). Definition of Done у каждой задачи свой + общие
   правила (раздел 4).
5. По завершении: обнови статус в Checkpoint, допиши строку в Журнал сессий (дата, что сделано,
   хеш коммита, обнаруженные нюансы/отклонения от спеки), закоммить **код вместе с обновлённой
   спекой** одним коммитом.
6. Если по ходу выяснился факт, ломающий спеку (API aiokafka не такой, конфликт миграций и
   т.п.) — не молчи: запиши в Журнал, скорректируй план в рамках зафиксированных решений
   (раздел 3) или остановись и спроси пользователя, если решение выходит за их рамки.

Статусы: `TODO` → `IN_PROGRESS` → `DONE`. Ещё есть `BLOCKED(<причина>)`.

---

## 1. Checkpoint

| #  | Задача                                                    | Статус |
|----|-----------------------------------------------------------|--------|
| T0 | Bootstrap: ветка, коммит спеки                            | DONE   |
| T1 | Каркас: зависимость, конфиг, src/metrics.py, GET /metrics | DONE   |
| T2 | HTTP-метрики входящих запросов (middleware)               | DONE   |
| T3 | Счётчик ошибок на логгере (errors_total)                  | DONE   |
| T4 | CPU/RAM: /proc-коллектор                                  | DONE   |
| T5 | Lag очереди recalc_commands (Kafka admin)                 | DONE   |
| T6 | docs/metrics.md + черновик ответа заказчику               | DONE   |
| T7 | Финализация: checks-all, security-ревизия, MR             | DONE   |

---

## 2. Контекст и границы

### 2.1. Откуда задача

Заказчик (@AlekseyShaposhnikov) просил эндпойнты Prometheus для дашборда: «сколько расчётов в
очереди, частота ошибок и на каком уровне». Финальный перечень из переписки:

1. Запросы во внешние сервисы (risk-profile-airi-cvd): сервис, метод, время ответа, ошибка.
2. Время расчётов рисков (калькуляция/интерпретация + общее, разрез по калькуляторам и
   типу пересчёта полный/частичный).
3. Запросы от внешних сервисов: cpu, ram, latency, errors (включая «ответили 200, но была ошибка»).

Уточнения заказчика: histogram latency в секундах со стандартными бакетами
`0.005, 0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0, 7.5, 10.0`
(это в точности дефолт `prometheus_client` — используем дефолт, не задаём вручную);
ошибки внешних вызовов трёх видов раздельно (сеть/таймаут, 4xx/5xx; вариант «200 c
isSuccess=false» контрактами не предусмотрен — не учитываем); префикс метрик — имя сервиса,
разделитель `_`; рекомендуемые лейблы latency: `method, host, path`; для запросов —
`method, host, path, status`.

### 2.2. In scope (эта итерация)

Только **процесс app** (FastAPI, uvicorn workers=4). Метрики — раздел 3.2.
Плюс lag очереди пересчёта, измеряемый со стороны app через Kafka admin API
(закрывает «сколько расчётов в очереди» без изменений consumer).

### 2.3. Out of scope (решение пользователя, зафиксировано)

- **Время расчётов, разрез по калькуляторам, full/partial, запросы в CVD** — эти события
  происходят в процессе consumer (`python -m src.workers.calc_consumer`): на стенде
  `kafka.enabled=true` и весь пайплайн `run_recalc` (включая httpx-вызовы CVD) исполняется
  там. Consumer в этой итерации **не трогаем вообще** (ни кода, ни compose). Пункты 1–2
  заказчика отложены до решения по экспозиции метрик consumer'а; в ответе заказчику это
  говорится явно (см. T6).
- Экспозиция метрик consumer (порты/replicas/прокси) — отдельная итерация.
- Grafana-дашборд — делает заказчик.
- Живой прогон на стенде/локальном compose — не входит (только тесты и линтеры).

### 2.4. Топология скрейпа (принято)

Prometheus заказчика — внешний, скрейпит по хост-портам. `/metrics` — на app-порту
(`${RISK_MODEL_PORT}`, на стенде 9001), **без авторизации** (как `/health`; в метриках нет
PII — только агрегаты и шаблоны роутов, которые и так видны в OpenAPI).

Уточнение по факту проверки (security-ревизия T1, 2026-07-17): отсутствие PII/секретов в выдаче
подтверждено (реальные `db_url`/`test_api_key`/`sasl_password` залиты в settings → в выдаче ноль
вхождений; секретам неоткуда взяться по конструкции — `src/metrics.py` не импортирует config).
А вот оговорка «и так видны в OpenAPI» **неточна** и не должна переиспользоваться как прецедент:
(1) роуты с `include_in_schema=False` в OpenAPI не видны — см. требования к T2; (2)
`build_info{version}` раскроет реальную версию (`0.7.0`), тогда как OpenAPI отдаёт захардкоженный
плейсхолдер `0.1.0` (`custom_openapi`), т.е. наружу она попадёт впервые. Риск признан низким
(сервис не публичный), решение об отсутствии авторизации в силе; компенсирующий контроль — T7.1a.

---

## 3. Зафиксированные решения

Эти решения приняты с пользователем и **не пересматриваются исполнителем**:

| # | Решение |
|---|---------|
| Р1 | Библиотека: голый `prometheus_client`, без instrumentator'ов. |
| Р2 | Мультипроцессность (workers=4): multiprocess-режим `prometheus_client` через `PROMETHEUS_MULTIPROC_DIR`. |
| Р3 | Consumer не трогаем. Lag очереди меряем из app по Kafka admin API. |
| Р4 | Префикс всех метрик: `risk_profile_core_`. |
| Р5 | Входящие HTTP: одна histogram `{method, path, status, host}`; `path` — шаблон роута (не сырой URL), `unmatched` для несматченных; `host` — hostname контейнера (`socket.gethostname()`), НЕ Host-заголовок клиента (кардинальность/безопасность). Пробы (`/`, `/health`, `/readiness`, `/liveness`) и сам `/metrics` не считаются. Бакеты — дефолт prometheus_client. |
| Р6 | «200-но-ошибка»: счётчик на логгере — каждый лог-рекорд уровня ERROR+ (ERROR/CRITICAL/ALERT/EMERGENCY) инкрементит `errors_total{level, component}`. Без ручных инкрементов в бизнес-коде. |
| Р7 | Lag: считается на скрейпе (в handler'е `/metrics`), кэш 10 с, таймаут 2 с, gauge per-partition + флаг-gauge доступности данных. При `kafka.enabled=false` lag-метрик в выдаче нет. |
| Р8 | CPU/RAM: свой коллектор по `/proc` (мастер uvicorn + воркеры, суммарно), без psutil. На не-Linux тихо отключается. |
| Р9 | `/metrics` открыт на app-порту, добавляется в `_PROBE_PATHS` (не логируем, не метрикуем). |
| Р10 | Верификация: юнит/интеграционные тесты + `make checks-all`. Без живого прогона. |
| Р11 | Деливерабл заказчику: `docs/metrics.md` (RU) + черновик сообщения в чат (в этой спеке, раздел 7). |

### 3.1. Архитектура реализации

Новый модуль **`src/metrics.py`** — единственное место, где создаются метрики.
Жёсткое правило: `src/metrics.py` **не импортирует** `src.config` и `src.logger` на уровне
модуля (см. антипаттерн из MR !41 — связка logger↔settings ломала boot-order; всё, что нужно
из конфига/версии, передаётся параметрами в init-функции).

Два реестра:

1. **Счётные метрики** (HTTP histogram, errors counter) — создаются обычным способом (default
   REGISTRY). В multiprocess-режиме (`PROMETHEUS_MULTIPROC_DIR` задан) prometheus_client сам
   пишет значения в mmap-файлы каждого воркера.
2. **`LOCAL_REGISTRY = CollectorRegistry()`** — scrape-time метрики процесса, обслуживающего
   запрос: `build_info`, /proc-коллектор, lag. Они одинаковы/валидны из любого воркера,
   агрегировать их между воркерами не нужно и нельзя (lag задублировался бы).

   **ИНВАРИАНТ (уточнён в T1 по факту проверки библиотеки, 2026-07-17): в `LOCAL_REGISTRY`
   регистрируются ТОЛЬКО кастомные коллекторы** (класс с `collect()` → `GaugeMetricFamily` /
   `CounterMetricFamily`), но НЕ объекты `Gauge`/`Counter`. Причина: value-class prometheus_client
   глобальный — он выбирается по env `PROMETHEUS_MULTIPROC_DIR` при импорте и **не зависит от
   реестра**, в который метрика зарегистрирована. В контейнере `Gauge`, созданный на
   `LOCAL_REGISTRY`, писал бы значение ещё и в mmap-файл, откуда его подхватил бы
   `MultiProcessCollector`: метрика попала бы в выдачу дважды — мусорный ряд с лейблом `pid` плюс
   ряд без него, два блока `HELP`/`TYPE` на одно имя. Строгие парсеры такую выдачу отвергают
   («second TYPE line»), нестрогие молча сливают ряды — то есть в лучшем случае метрика врёт
   (для lag это удвоение очереди). Насколько именно строг скрейпер заказчика — на живом Prometheus
   НЕ проверялось, и утверждать «отвергнет скрейп целиком» нельзя; на выбор решения это не влияет.
   Локально (single-process) дефект невидим вообще, ломается только на стенде. Контракт наружу не
   меняется: `GaugeMetricFamily` отдаёт тот же `# TYPE ... gauge`.

   Инвариант закреплён тестом `test_render_in_multiprocess_mode` (подпроцесс — в одном процессе
   режим не переключить). Проверять дубли ТОЛЬКО по сырому тексту (`# TYPE`-строки + отсутствие
   `pid=`): `text_string_to_metric_families` молча склеивает СМЕЖНЫЕ одноимённые семейства, и
   ассерт на его выводе ловит дубль лишь при удачном порядке коллекторов (обожглись в T1).

Функция `render() -> bytes`:

- multiproc-режим: `reg = CollectorRegistry(); MultiProcessCollector(reg)` (читает mmap-файлы
  всех воркеров) → `generate_latest(reg) + generate_latest(LOCAL_REGISTRY)`.
- single-process (локальный дев, тесты): `generate_latest(REGISTRY) + generate_latest(LOCAL_REGISTRY)`;
  при инициализации в этом режиме отрегистрировать стандартные `PROCESS_COLLECTOR`,
  `PLATFORM_COLLECTOR`, `GC_COLLECTOR` из default REGISTRY — чтобы выдача была одинаковой
  в обоих режимах (метрики без нашего префикса не отдаём).

В multiproc-реестре **нет Gauge** (только Counter/Histogram) — поэтому `mark_process_dead` и
`multiprocess_mode=` не нужны. Не добавляй Gauge в default REGISTRY без пересмотра этого пункта
(в `LOCAL_REGISTRY` — тем более, см. инвариант выше).

Принцип агрегации (закреплено по ревью спеки 2026-07-17): **метрики отдаются с позиции
сервиса, без разбивки по внутренним процессам.** Multiprocess-режим суммирует Counter/Histogram
всех воркеров в единые временные ряды — per-PID/per-worker лейблов в выдаче нет (лейбл `pid=`
прямо запрещён и отлавливается тестом `test_render_in_multiprocess_mode`); /proc-коллектор
отдаёт cpu/rss одним суммарным рядом по мастеру и воркерам, а `process_count` — не разрез, а
одно агрегатное число (индикатор падения воркера). Правило действует и на будущие итерации:
метрики consumer-процесса, когда появятся, используют те же имена с тем же префиксом
`risk_profile_core_` — различать скрейп-таргеты будет Prometheus лейблом `instance`;
отдельные имена/префиксы/лейблы под внутренние процессы не заводить.

Ещё одно следствие глобального value-class (T1, проверено): в multiproc-режиме prometheus_client
открывает mmap-файл **в момент создания метрики**. Метрику с лейблами это не задевает (файл
создаётся лениво, на первом `.labels()`), а метрика БЕЗ лейблов открыла бы файл прямо при импорте
`src/metrics.py` — то есть раньше, чем `__main__` создаст директорию, и контейнер падал бы на
старте с `FileNotFoundError`. Поэтому `src/metrics.py` делает `os.makedirs(exist_ok=True)` при
импорте (`_ensure_multiproc_dir`, только создание), а `prepare_multiproc_dir()` из `__main__`
отвечает за очистку `*.db`. Не убирать makedirs при импорте.

Очистка mmap-директории: в `src/main.py` `__main__`, **до** `uvicorn.run()` (то есть до спавна
воркеров): если `PROMETHEUS_MULTIPROC_DIR` задан — `os.makedirs(exist_ok=True)` + удалить
`*.db` внутри. Env задаётся в Dockerfile (`ENV PROMETHEUS_MULTIPROC_DIR=/tmp/prometheus-multiproc`) —
ФС контейнера писабельна (hardening — только `no-new-privileges`), процесс живёт под `appuser`,
`/tmp` доступен. Локально без env всё работает в single-process режиме.

НФТ — жизненный цикл mmap-директории (добавлено по ревью ПМа 2026-07-17):

- **После любого рестарта контейнера директория очищается полностью.** Очистка привязана к
  старту процесса (CMD контейнера = `python -m src.main`), поэтому срабатывает и после
  аварийного завершения (crash / OOM-kill / `docker restart`): ФС контейнера переживает
  рестарт и старые `*.db` физически остаются, но повторный запуск CMD удаляет их до спавна
  воркеров. Очистка сознательно на старте, а НЕ на shutdown — при аварийном завершении
  shutdown-код не выполняется никогда, старт выполняется всегда.
- Счётчики после рестарта начинаются с нуля — штатный counter reset Prometheus;
  `rate()`/`increase()` обрабатывают его автоматически, NFR-проблемы нет.
- Рост директории в пределах одной жизни контейнера: при смерти и респавне uvicorn-воркера
  новый PID создаёт новый комплект файлов, а файлы мёртвого PID сохраняются — это корректное
  поведение prometheus_client (вклад умершего воркера в счётчики не должен пропадать).
  Принятое ограничение: единицы МБ на респавн, вычищается следующим рестартом контейнера;
  крашлуп воркера виден по `risk_profile_core_process_count`. Механизмов компактации
  counter-файлов у prometheus_client нет — свои не изобретать.

Важно про порядок импортов: prometheus_client выбирает value-class по env **при импорте**.
Env приходит из Dockerfile — он установлен до старта python в контейнере, тем более до
импорта модулей воркерами (uvicorn спавнит воркеры отдельными процессами с наследованием env).
Программно задавать env в `__main__` НЕЛЬЗЯ (модули уже импортированы) — только снаружи.

### 3.2. Перечень метрик (контракт)

| Метрика | Тип | Лейблы | Семантика |
|---|---|---|---|
| `risk_profile_core_http_request_duration_seconds` | Histogram | `method`, `path`, `status`, `host` | Латентность входящих HTTP-запросов, дефолтные бакеты. `_count` = счётчик запросов; ошибки — по `status` (4xx/5xx). |
| `risk_profile_core_errors_total` | Counter | `level` (`error`/`critical`/`alert`/`emergency`), `component` (модуль-источник) | Каждый лог-рекорд уровня ≥ ERROR. Ловит и «200-но-ошибка» (например, фейл фонового enqueue в Kafka после отправленного ответа). |
| `risk_profile_core_recalc_queue_lag` | Gauge (LOCAL) | `topic`, `partition` | end_offset − committed_offset группы `risk-recalc-workers` по топику `risk-profile.recalc-commands`, на момент скрейпа (кэш 10 с). |
| `risk_profile_core_recalc_queue_lag_ok` | Gauge (LOCAL) | — | 1 — lag опрошен успешно; 0 — ошибка/таймаут опроса. При `kafka.enabled=false` обе lag-метрики отсутствуют в выдаче. |
| `risk_profile_core_process_cpu_seconds_total` | Counter-семантика (из /proc-коллектора, LOCAL) | — | Суммарное CPU-время (utime+stime) uvicorn-мастера и всех воркеров. |
| `risk_profile_core_process_resident_memory_bytes` | Gauge (LOCAL) | — | Суммарный RSS мастера + воркеров. |
| `risk_profile_core_process_count` | Gauge (LOCAL) | — | Число процессов (мастер + воркеры); полезно ловить падение воркера. |
| `risk_profile_core_build_info` | Gauge (LOCAL) | `version` | Константа 1; версия из `version.json`. Для аннотаций деплоев. |

Тип «Gauge (LOCAL)» в таблице — это тип **в выдаче** (`# TYPE ... gauge`). Реализуются такие
метрики кастомными коллекторами, а не объектами `Gauge` (инвариант `LOCAL_REGISTRY`, см. 3.1).

Значения лейблов:
- `path`: `route.path_format` FastAPI (например `/api/v1/testing/patients/{patient_id}`);
  для запросов без сматченного роута — литерал `unmatched`. Статика `/questionnaire` (mount) —
  считается одним значением `/questionnaire`.
- `status`: строка HTTP-кода (`"200"`); если хендлер бросил необработанное исключение — `"500"`.
- `host`: `socket.gethostname()` (id контейнера), вычисляется один раз при импорте.
- `component`: имя модуля вызвавшего кода (см. Т3 про `stacklevel`).

---

## 4. Общие правила для всех задач

- Рабочая директория — корень репозитория `risk-profile-core`, в котором лежит эта спека
  (`docs/spec-prometheus-metrics.md`): та директория, где находятся `pyproject.toml`, `src/`,
  `Makefile`. Все пути в спеке — относительно неё. Абсолютные пути конкретной машины в спеку
  не вносить.
- Стиль кода/комментариев — как в соседних файлах (русские комментарии «почему», не «что»).
  Логи — по принципу проекта: entry/exit/error, request_id уже прокидывается.
- Никаких секретов и PII в именах/лейблах/значениях метрик. `SecretStr` не разворачивать.
- Каждая задача = отдельный коммит (или несколько логичных), сообщение в стиле `git log`
  репозитория, вместе с обновлением Checkpoint/Журнала этой спеки.
- Тесты кладутся по конвенции репо: `tests/unit/...`, `tests/api/...`, интеграция app-уровня —
  рядом с `tests/test_main.py`. Локальный запуск: `.venv/bin/python -m pytest` (см. память об
  окружении: uv sync может падать на yappi — не чинить, гонять pytest напрямую).
- Линтеры по ходу: `ruff check --fix . && ruff format .`; полный прогон — в T7.
- Не трогать: код consumer (`src/workers/calc_consumer.py`, `src/infra/kafka/consumer.py`),
  `docker-compose.yml` (кроме случая, если T1 потребует прокинуть env — НЕ требуется, env
  задаётся в Dockerfile), миграции, каталог.

---

## 5. Задачи

### T0. Bootstrap

1. `git fetch origin`, проверить `git status` (см. протокол, п.3).
2. Создать ветку: `git switch -c feature/prometheus-metrics origin/develop`.
3. Добавить этот файл (`docs/spec-prometheus-metrics.md`) в ветку, закоммитить.
4. DoD: ветка существует, спека закоммичена, Checkpoint обновлён (T0=DONE).

### T1. Каркас: зависимость, конфиг, src/metrics.py, GET /metrics

1. Зависимость: `prometheus-client`, пин точной актуальной версией в `pyproject.toml`
   (стиль пинов — `==`, как у остальных), обновить `uv.lock` (`uv lock` / `uv add`).
2. `src/config.py`: `class MetricsSettings(BaseModel): enabled: bool = True` + поле
   `metrics: MetricsSettings = MetricsSettings()` в `Settings` (env: `RISK_MODEL_METRICS__ENABLED`).
   Докстринг-комментарий в стиле файла (зачем флаг: аварийное отключение экспозиции без релиза).
3. Создать `src/metrics.py` по архитектуре раздела 3.1:
   - `SERVICE_PREFIX = "risk_profile_core"`;
   - `HTTP_REQUEST_DURATION` (Histogram, лейблы `method, path, status, host`, дефолтные бакеты);
   - `ERRORS_TOTAL` (Counter, лейблы `level, component`);
   - `LOCAL_REGISTRY`, `build_info`-Gauge; `init_metrics(version: str)` — вызывается из
     lifespan (`src/main.py`), версия — из уже существующего чтения `version.json`
     (`_service_version()` в main.py; не импортировать main из metrics — передать строку);
   - `render() -> bytes` (+ выбор режима по `PROMETHEUS_MULTIPROC_DIR`, unregister стандартных
     коллекторов в single-process режиме);
   - `HOSTNAME = socket.gethostname()`.
4. `src/main.py`:
   - route `GET /metrics` (рядом с `/health`): если `settings.metrics.enabled` — `Response(
     content=render(...), media_type=CONTENT_TYPE_LATEST)`; если выключено — 404;
   - `/metrics` добавить в `_PROBE_PATHS`;
   - в `__main__` до `uvicorn.run()`: подготовка/очистка `PROMETHEUS_MULTIPROC_DIR` (3.1).
5. `docker/Dockerfile`: `ENV PROMETHEUS_MULTIPROC_DIR=/tmp/prometheus-multiproc` (в существующий
   ENV-блок).
6. Тесты (`tests/test_main.py` или новый `tests/test_metrics_endpoint.py`):
   - `GET /metrics` → 200, `Content-Type` прометеевский, тело содержит
     `risk_profile_core_build_info`;
   - при `metrics.enabled=false` (monkeypatch settings) → 404;
   - `/metrics` не попадает в лог «request completed» (по образцу существующих тестов проб).
7. DoD: тесты зелёные, `ruff` чистый, Checkpoint обновлён.

### T2. HTTP-метрики входящих запросов

🔒 **Требования безопасности (добавлено security-ревизией T1, 2026-07-17; проверено запуском).**
Ручка `/metrics` неавторизована, поэтому лейблы = поверхность атаки на кардинальность. Дыру
вносит именно T2 — на T1 её нет:

- **`method` — только белый список** `{GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS}`, всё
  остальное → литерал `"other"`. Не полагаться на HTTP-парсер: с httptools (прод) до middleware
  долетают 33 метода (`PROPFIND`, `QUERY`, …), а с h11 — **произвольные**, включая метод длиной
  100 символов (проверено). Клиент управляет методом напрямую.
- **`path` — НИКОГДА `request.url.path`.** Только `route.path_format` при сматченном роуте, иначе
  литерал `"unmatched"`. Фолбэк на сырой путь = готовая бомба кардинальности от анонима.
- **Статика `/questionnaire`**: `Mount.matches()` **не кладёт `route` в scope** (проверено:
  child_scope без ключа `route`) → наивная реализация даст `"unmatched"` вопреки Р5. Брать
  префикс маунта явно — но не из сырого пути.
- **Скрытые роуты**: `/api/v1/debug/profile` объявлен `include_in_schema=False` и закрыт 401 —
  через лейбл `path` неавторизованный `/metrics` раскроет его существование. Роуты с
  `include_in_schema=False` схлопывать в `"other"`. (Посылка Р5 «шаблоны роутов и так видны в
  OpenAPI» для них неверна.)
- **Тест на кардинальность как контракт**: N мусорных URL × M нестандартных методов → число
  лейбл-сетов НЕ растёт. Существующей проверки «два мусорных URL → один лейбл» мало: она не
  покрывает `method`.
- Бюджет рядов посчитать явно: `методы × (роуты+2) × статусы`. Без потолка по методам худший
  случай — 833 лейбл-сета → 14 161 ряд → тело 1.7 MiB (замерено); mmap не компактится до
  рестарта контейнера.

1. Отдельная **стандартная FastAPI-миддлварь** (по ревью спеки 2026-07-17; прежнее указание
   «врезаться в `request_middleware`» отменено):
   - `async def metrics_middleware(request, call_next)` — положить в `src/api/middleware.py`
     (рядом со `StripTrailingSlashMiddleware`), регистрация в `src/main.py` рядом с остальными
     миддлварями: `app.middleware("http")(metrics_middleware)` либо
     `app.add_middleware(BaseHTTPMiddleware, dispatch=metrics_middleware)` — выбрать то, что
     чище ложится в существующий порядок регистрации;
   - `request_middleware` (логирование) **не трогаем вообще** — плюс подхода: нулевой дифф в
     PII-чувствительном коде логирования. Время меряем своим `time.perf_counter()`;
   - порядок стека: метрики-миддлварь — **внешняя** по отношению к `request_middleware`,
     чтобы duration включал и накладные расходы логирования (буферизация тел) — это честная
     server-side латентность. Проверить фактический порядок (последняя зарегистрированная
     `@app.middleware("http")` — внешняя) и закрепить комментарием у регистрации;
   - пропуск проб: путь из `_PROBE_PATHS` (и `/metrics`) — не наблюдать;
   - обернуть `call_next` так, чтобы **необработанное исключение** тоже давало наблюдение с
     `status="500"` (и re-raise);
   - после ответа: `route = request.scope.get("route")`; `path_label = route.path_format` если
     роут сматчен, иначе `"unmatched"`; для mount'а статики (`/questionnaire`) — префикс маунта;
   - `HTTP_REQUEST_DURATION.labels(method, path_label, str(status), HOSTNAME).observe(...)`.

   Трактовка «где возможно» из замечания: миддлварь покрывает только HTTP-метрики. Lag-проба
   (T5), /proc-коллектор (T4) и логгер-хук (T3) по своей природе не миддлвари — остаются как
   спроектированы.
2. Проверить взаимодействие со `StripTrailingSlashMiddleware` (она чисто-ASGI и внешняя —
   конфликтов быть не должно, но тест на латентность запроса со слэшем не помешает).
3. Тесты:
   - шаблонный путь: запрос к параметризованному роуту → в выдаче `/metrics` лейбл
     `path="/api/v1/.../{...}"`, НЕ сырой путь (использовать testing-роуты с включённым
     `testing_api_enabled` в тестовом окружении, либо любой существующий параметризованный роут);
   - 404 на несуществующий URL → `path="unmatched"`, кардинальность не растёт от разных URL
     (два разных мусорных URL → один лейбл-сет);
   - роут, бросающий исключение (добавить временный роут в тестовом app) → `status="500"`;
   - пробы (`/health`) не увеличивают histogram.
4. DoD: тесты зелёные; в выдаче нет ни одного лейбла с сырым path-параметром.

### T3. Счётчик ошибок на логгере

⚠️ **Открытый вопрос к пользователю, решить ДО начала T3** (найдено ревью T1, 2026-07-17).
`ENV PROMETHEUS_MULTIPROC_DIR` задан в `docker/Dockerfile`, а образ общий для `app`, `consumer`
(`replicas: 2`) и `migrations`. Сегодня это безвредно: `src.metrics` в consumer не импортируется
(проверено). Но T3 импортирует `ERRORS_TOTAL` **в `src/logger.py`**, а логгер consumer использует
— и тогда consumer молча уедет в multiprocess-режим: каждый ERROR начнёт писать `counter_<pid>.db`
в `/tmp/prometheus-multiproc`, которые **никто не читает** (HTTP-ручки у consumer нет, §2.3) и
**никто не чистит** (`prepare_multiproc_dir()` живёт в `__main__` у `src/main.py`, а CMD consumer —
`python -m src.workers.calc_consumer`). Файлы копятся по комплекту на PID при каждом рестарте.
Варианты: (а) перенести env из Dockerfile в `docker-compose.yml` на сервис `app` — env всё равно
выставляется до старта процесса, так что обоснование «из `__main__` было бы поздно» compose не
запрещает; минус — образ перестаёт быть самодостаточным вне compose (без env воркеры молча отдают
каждый свои счётчики); (б) позвать `prepare_multiproc_dir()` в `__main__` consumer — упирается в
Р3 «consumer не трогаем». **Не решать молча: это выходит за рамки зафиксированных решений.**

1. `src/logger.py`:
   - в `_log()` добавить `stacklevel=3`, в `business()` — `stacklevel=2`, чтобы
     `record.module` указывал на реального вызывающего, а не на `logger.py`. Формат JSON-логов
     не изменится (MonologFormatter модуль/строку не выводит) — но проверить тестами, что
     существующие тесты логов не сломались;
   - новый `class _MetricsHandler(logging.Handler)`: `emit()` → если
     `record.levelno >= logging.ERROR`: `ERRORS_TOTAL.labels(level=record.levelname.lower(),
     component=record.module).inc()`. Импорт `ERRORS_TOTAL` — **внутри** `emit` или модуля
     metrics без завязки на config (правило 3.1); никаких исключений наружу (переопределить
     `handleError`/обернуть try);
   - подключить handler в `_make_logger()` НАПРЯМУЮ к логгеру `app` (не внутрь
     FingersCrossedHandler — счётчик должен видеть записи независимо от буферизации).
2. Прогнать `make lint-logger` (`scripts/check_logger_info.py`) — убедиться, что скрипт не
   ругается на изменения.
3. Тесты (`tests/unit/` рядом с тестами логгера, либо `tests/test_logging_gaps.py` по соседству):
   - `error("x")` из тестового модуля → `errors_total{level="error", component="<имя модуля>"}` +1;
   - `alert("x")` → `level="alert"`;
   - `notice()`/`warning()`/`business()` счётчик НЕ трогают;
   - fingers-crossed: ERROR внутри запроса инкрементит счётчик ровно один раз (не задвоение
     из-за буфера).
4. DoD: тесты зелёные, `make lint-logger` чистый, существующие тесты логгера не сломаны.

### T4. CPU/RAM: /proc-коллектор

1. В `src/metrics.py` — `class ProcStatsCollector` (кастомный collector, регистрируется в
   `LOCAL_REGISTRY` при `init_metrics`):
   - определить «мастера»: если `PROMETHEUS_MULTIPROC_DIR` задан (докер, multi-worker) —
     `os.getppid()`, иначе `os.getpid()`;
   - собрать pids: мастер + все процессы из `/proc/*/stat` с `ppid == мастер`;
   - `/proc/<pid>/stat`: парсить ПОСЛЕ последней `)` (имя процесса может содержать пробелы);
     utime — поле 14, stime — 15 (в тиках; делить на `os.sysconf("SC_CLK_TCK")`);
   - RSS: `/proc/<pid>/statm`, второе поле × `os.sysconf("SC_PAGE_SIZE")`;
   - отдавать `CounterMetricFamily`/`GaugeMetricFamily` с именами из 3.2; исчезнувший между
     листингом и чтением pid — пропускать молча;
   - нет `/proc` (macOS) → `collect()` возвращает пусто.
2. Тесты: `@pytest.mark.skipif(sys.platform != "linux", ...)` — значения cpu > 0, rss > 0,
   count ≥ 1; на macOS — тест, что выдача `/metrics` не падает и просто не содержит
   `process_cpu`.
3. DoD: тесты зелёные (linux-часть проверится в CI), локально `/metrics` не ломается.

### T5. Lag очереди recalc_commands

🔒 **Требования безопасности (security-ревизия T1):** `/metrics` неавторизована, а T5 вешает на
скрейп поход в Kafka — то есть аноним получает рычаг на брокер.
- **Single-flight на опрос**: кэша 10 с мало — в момент истечения N параллельных скрейпов уйдут
  в Kafka одновременно (stampede). Опрос должен быть один, остальные ждут его результат.
- **Кэшировать и ОТРИЦАТЕЛЬНЫЙ результат** (ошибку/таймаут) на те же 10 с: иначе при лежащем
  брокере каждый скрейп платит полные 2 с таймаута.

1. Новый модуль `src/infra/kafka/lag_probe.py` (или в `src/metrics.py`, если выйдет компактно, —
   но подключение к Kafka логичнее держать в `src/infra/kafka/`):
   - `class RecalcLagProbe`: держит `AIOKafkaAdminClient` + группоless `AIOKafkaConsumer`
     (для `end_offsets`); параметры подключения переиспользовать из общего билдера kwargs
     продюсера (`src/infra/kafka/` — найти существующий helper security-настроек, не
     дублировать SASL/SSL-код);
   - `async def refresh()`: если с прошлого успешного опроса < 10 с — no-op; иначе под
     `asyncio.timeout(2.0)`: партиции топика `settings.kafka.topics.recalc_commands`,
     `end_offsets`, `list_consumer_group_offsets("risk-recalc-workers")`
     (group_id брать из `settings.kafka.consumer.group_id`); lag партиции =
     `end − (committed or 0)`, не меньше 0;
   - результат публикуется через **кастомный коллектор** в `LOCAL_REGISTRY` (`GaugeMetricFamily`
     из последнего снимка), а НЕ через объект `Gauge` — см. инвариант в 3.1, иначе выдача на
     стенде дублируется и Prometheus отвергает скрейп. Снимок заменяется целиком (не мержится),
     чтобы не оставались ряды исчезнувших партиций;
   - ошибка/таймаут: снимок = «нет данных» (lag-рядов нет), `lag_ok` = 0, лог `warning`
     (НЕ error — иначе каждый скрейп при лежащей Kafka зашумит errors_total);
   - `start()/stop()` — вызвать из lifespan `src/main.py` при
     `settings.kafka.enabled and settings.metrics.enabled`; выключено → пробы нет, метрик нет.
2. Handler `GET /metrics`: перед `render()` — `await probe.refresh()` (если проба создана).
3. Тесты (`tests/unit/infra/`, по образцу `test_kafka_consumer.py` — моки aiokafka):
   - happy path: моки возвращают end=110/committed=100 → gauge 10 у партиции, `lag_ok=1`;
   - группа без коммитов (committed None) → lag = end;
   - таймаут/исключение → `lag_ok=0`, lag-рядов нет;
   - `kafka.enabled=false` → в `/metrics` нет `recalc_queue_lag*` вообще;
   - кэш: два refresh подряд → один поход в Kafka.
4. DoD: тесты зелёные; при выключенной Kafka `/metrics` работает как раньше.

### T6. docs/metrics.md + черновик ответа заказчику

1. Создать `docs/metrics.md` (по-русски): как подключаться (`GET http://<host>:<port>/metrics`,
   рекомендуемый scrape_interval 15 с), полная таблица метрик из 3.2 (актуализировать по
   факту реализации!), значения лейблов, примеры PromQL для дашборда:
   - RPS: `sum(rate(risk_profile_core_http_request_duration_seconds_count[5m]))`;
   - p95: `histogram_quantile(0.95, sum by (le) (rate(..._bucket[5m])))`;
   - доля 5xx + скрытые ошибки: `rate(..._count{status=~"5.."}[5m])` и
     `rate(risk_profile_core_errors_total[5m])`;
   - очередь — три основных показателя дашборда (по ревью ПМа): общий lag —
     `sum(risk_profile_core_recalc_queue_lag)`; максимальный lag по партиции (перекос) —
     `max(risk_profile_core_recalc_queue_lag)`; число отстающих партиций —
     `count(risk_profile_core_recalc_queue_lag > 0)`;
   - cpu/ram: `rate(risk_profile_core_process_cpu_seconds_total[5m])`,
     `risk_profile_core_process_resident_memory_bytes`.
2. Заполнить черновик ответа заказчику в разделе 7 этой спеки (заготовка там), сверив с
   реализацией. Не отправлять — отправляет пользователь.
3. DoD: docs/metrics.md соответствует фактической выдаче `/metrics` (сверить с тестовой
   выдачей), раздел 7 заполнен.

### T7. Финализация

1. `make checks-all` — всё зелёное (format, ruff, ty, bandit, semgrep, lint-logger, тесты,
   deps-check). Semgrep/bandit-находки по новому коду — починить, не глушить. NB: semgrep в
   локальном `.venv` не установлен (T1) — либо поставить, либо зафиксировать, что SAST = bandit.

1a. 🔒 **Компенсирующий контроль к неавторизованной ручке (security-ревизия T1) — обсудить с
   пользователем/девопсом.** Рейт-лимита нет, обратного прокси перед app нет, порт публикуется в
   `0.0.0.0:9001` (для сравнения: `db` осознанно закрыт на `127.0.0.1`). Замер на живом uvicorn
   при кардинальности после T2 (833 лейбл-сета, 4 потока в цикле по `/metrics`): p50 `/health`
   0.8 мс → **95 мс**, p95 1.1 мс → **296 мс** (деградация ×119/×280); усиление трафика ×29 000
   (60 байт запроса → 1.7 MiB ответа); стенд — 2 vCPU. На T1 этого нет (скрейп 0.2 мс), риск
   материализуется вместе с T2/T4/T5. Правильный фикс — не авторизация (решено, что её нет), а
   сетевое ограничение источника скрейпа до IP Prometheus заказчика (firewall / bind на
   внутренний интерфейс). Учесть: `/metrics` в `_PROBE_PATHS`, поэтому в логах app такая атака
   следов не оставит.
2. Security-ревизия глазами: grep выдачи `/metrics` и кода на предмет секретов/PII в лейблах;
   убедиться, что `test_api_key`/`sasl_password` нигде не всплывают.
3. Просмотреть весь дифф ветки целиком (`git diff origin/develop...HEAD`) — на полноту и
   случайные хвосты.
4. MR: `glab mr create --target-branch develop` с описанием (что добавлено, перечень метрик,
   ссылка на docs/metrics.md, out-of-scope пункты). Ревьюер — по практике проекта.
5. DoD: MR создан, pipeline зелёный, Checkpoint весь DONE, журнал заполнен.

---

## 6. Справочник фактов кодовой базы (чтобы не искать заново)

- FastAPI 0.135.2, uvicorn 0.42.0 (workers из `settings.workers`, дефолт 4, uvloop),
  Python 3.12 (Docker `python:3.12-slim-bookworm`), пакетный менеджер uv, деп-пины `==`.
- App: `src/main.py` — `app = FastAPI(...)` (строка ~166), lifespan ~101–163,
  `request_middleware` ~338–410 (perf_counter, status_code, `_PROBE_PATHS` ~237,
  X-Request-ID), пробы `/`, `/health`, `/readiness`, `/liveness` ~413–437,
  `__main__` с `uvicorn.run("src.main:app", ...)` ~439–457.
- Версия сервиса: `version.json` → `_service_version()` в main.py.
- Конфиг: `src/config.py`, `Settings(BaseSettings)` c `env_prefix="RISK_MODEL_"`,
  `env_nested_delimiter="__"`. Kafka: `settings.kafka` (enabled=False по умолчанию;
  `topics.recalc_commands="risk-profile.recalc-commands"`; `recalc_commands_partitions=6`;
  `consumer.group_id="risk-recalc-workers"`; SASL_SSL/SCRAM-SHA-512, `SecretStr` пароли).
- Логгер: `src/logger.py` — единый логгер `"app"`, `FingersCrossedHandler(StreamHandler)` +
  `MonologFilter`; кастомные уровни NOTICE=25, ALERT=55, EMERGENCY=60; хелперы
  `notice()/business()/alert()/error()` зовут `_log()` → `logger.log(...)`. JSON-формат не
  содержит module/lineno.
- Исходящий HTTP: только `src/calc/infra/cvd_client.py` (httpx, event_hooks) — в этой
  итерации НЕ трогаем.
- Consumer: `src/workers/calc_consumer.py` (отдельный процесс, без HTTP) — НЕ трогаем.
- Compose: `docker-compose.yml` (проект `risk-profile-core`), app публикует
  `${RISK_MODEL_PORT}:${RISK_MODEL_PORT}`; hardening — только `no-new-privileges` (ФС
  писабельна); consumer с `deploy.replicas` и без портов. Dockerfile: `docker/Dockerfile`,
  ENV-блок в начале, `USER appuser`, `CMD ["python", "-m", "src.main"]`.
- Тесты: `tests/test_main.py` — паттерн `TestClient(app)` без lifespan, моки `notice` для
  проверки логов; conftest верхнего уровня; маркеры `db`, `test_internal`; testcontainers
  для БД. Локально: `.venv/bin/python -m pytest` (Python 3.14, yappi не собирается —
  `test_profiling.py` падает по-окруженчески, это известно и не чинится).
- Makefile: `checks-all` (полный прогон), `lint-logger`, `test`, `secure-scan`.
- Стенд: деплой CI по мержу в `develop` (SSH + `docker compose up -d --build`),
  app на `5.42.105.101:9001`.

---

## 7. Черновик ответа заказчику (заполняется в T6)

> Шаблон; T6 актуализирует по факту реализации и вписывает финальный текст сюда.

```
Привет! Сделали первую итерацию метрик — ручка GET /metrics (Prometheus text format) на порту
приложения (<host>:9001/metrics), без авторизации. Рекомендуемый scrape_interval 15s.

Доступно сейчас (процесс API):
- risk_profile_core_http_request_duration_seconds{method, path, status, host} — histogram со
  стандартными бакетами; path — шаблон роута; count/latency/ошибки по status из неё же;
- risk_profile_core_errors_total{level, component} — внутренние ошибки, включая случаи
  «ответили 200, но ошибка случилась после ответа» (например, фоновая постановка пересчёта);
- risk_profile_core_recalc_queue_lag{topic, partition} (+ ..._lag_ok) — сколько команд
  пересчёта ждёт в очереди;
- risk_profile_core_process_cpu_seconds_total / _resident_memory_bytes / _process_count — cpu/ram;
- risk_profile_core_build_info{version}.

Полное описание с примерами PromQL — docs/metrics.md в репозитории.

Что сознательно отложили: время расчётов (калькуляция/интерпретация, разрез по калькуляторам
и полный/частичный) и метрики запросов в risk-profile-airi-cvd. Эти события происходят в
отдельном consumer-процессе, у которого пока нет HTTP-эндпойнта для скрейпа — обсудим
отдельно, как вам удобнее его забирать (отдельные порты консюмеров или агрегация через API),
и добавим следующей итерацией.

Отклонение от вашей рекомендации по лейблам: у входящих запросов host — это hostname
контейнера сервиса (Host-заголовок клиента в лейблы класть нельзя — неограниченная
кардинальность).
```

---

## 8. Журнал сессий

> Формат: `- YYYY-MM-DD: <задача> — <что сделано, коммит, нюансы/отклонения>`.

- 2026-07-16: спека создана и утверждена пользователем (grilling-сессия: 13 решений, раздел 3).
- 2026-07-17: правки по ревью ПМа: (1) НФТ жизненного цикла mmap-директории в раздел 3.1 —
  очистка при каждом старте контейнера покрывает и аварийные рестарты (механика уже была
  заложена, теперь описана явно + принятое ограничение роста при респавне воркеров);
  (2) в T6 добавлены основные показатели лага для дашборда (sum / max / count>0).
  Кода и решений раздела 3 правки не меняют.
- 2026-07-17: ревью спеки, замечание 1 — убран абсолютный путь конкретной машины из раздела 4;
  рабочая директория теперь определяется как корень репозитория со спекой (маркеры:
  pyproject.toml, src/, Makefile).
- 2026-07-17: ревью спеки, замечание 2 («метрики с позиции сервиса, без разделения на
  процессы») — принцип агрегации закреплён явным блоком в 3.1. По факту дизайн уже
  соответствовал (multiproc суммирует воркеров, /proc-коллектор отдаёт суммы, `pid=` запрещён
  тестом из T1); добавлено правило на будущее: consumer-метрики — те же имена/префикс,
  различение инстансов лейблом `instance` на стороне Prometheus.
- 2026-07-17: ревью спеки, замечание 3 — T2 переписан: HTTP-метрики реализуются ОТДЕЛЬНОЙ
  стандартной FastAPI-миддлварью (в `src/api/middleware.py`, регистрация в main.py), а не
  врезкой в `request_middleware`; прежнее указание отменено. Бонус: логирующая миддлварь
  (PII-чувствительная зона) остаётся без диффа. Порядок: метрики — внешний слой, duration
  включает накладные логирования. «Где возможно» трактовано так: lag-проба (T5),
  /proc-коллектор (T4) и логгер-хук (T3) миддлварями не являются, остаются как спроектированы.
  Требования безопасности T2 (белый список method, запрет сырого path и т.д.) не изменились.
- 2026-07-17: T0 — ветка `feature/prometheus-metrics` создана от `origin/develop` (a0c91cc),
  спека закоммичена. Рабочее дерево было чистое по трекнутым файлам.
- 2026-07-17: T1 — каркас готов. `prometheus-client==0.25.0` (актуальная на дату, `uv.lock`
  обновлён), `MetricsSettings.enabled`, `src/metrics.py`, `GET /metrics`, `/metrics` в
  `_PROBE_PATHS`, `PROMETHEUS_MULTIPROC_DIR` в Dockerfile, `tests/test_metrics_endpoint.py`
  (11 тестов). Дефолтные бакеты библиотеки сверены — совпадают с перечнем заказчика (2.1),
  задавать вручную не потребовалось.

  **Отклонение от спеки (обязательное, ломало прод):** `build_info` реализован кастомным
  коллектором, а не объектом `Gauge` на `LOCAL_REGISTRY`, как предписывал раздел 3.1.
  Проверка библиотеки показала: value-class выбирается по env глобально и НЕ зависит от реестра,
  поэтому Gauge на `LOCAL_REGISTRY` в контейнере попадал бы в выдачу дважды (из mmap с `pid` и из
  `LOCAL_REGISTRY`) → два блока HELP/TYPE на имя → Prometheus отвергает скрейп целиком. Локально
  и в тестах (single-process) дефект невидим — зелёные тесты его бы не поймали. Разделы 3.1, 3.2 и
  T5 поправлены: инвариант «в LOCAL_REGISTRY только кастомные коллекторы» + указание для T5 (lag).
  Решения раздела 3 не затронуты — контракт наружу (`# TYPE ... gauge`) прежний.

  **Хардненинг сверх спеки:** `_ensure_multiproc_dir()` (makedirs при импорте `src/metrics.py`).
  Без него метрика БЕЗ лейблов, заведённая будущей задачей, открыла бы mmap-файл при импорте —
  раньше, чем `__main__` создаст директорию, — и контейнер не стартовал бы (FileNotFoundError,
  воспроизведено). Очистка `*.db` осталась там, где предписано, — в `__main__`.

  **Тесты:** добавлен `test_render_in_multiprocess_mode` — подпроцесс с `PROMETHEUS_MULTIPROC_DIR`
  (в одном процессе режим не переключить: он фиксируется при импорте). Это единственный тест,
  проверяющий выдачу в том режиме, в котором сервис реально работает на стенде; мутационно
  подтверждено, что он падает при нарушении инвариантов (обычные тесты — нет).

  Локально `tests/unit/test_profiling.py` падает по-окруженчески (yappi не собирается на
  Python 3.14) — известно, к задаче отношения не имеет. Остальные 964 теста зелёные.
- 2026-07-17: T1 — ревью двумя субагентами (корректность+полнота / security) и фиксы по нему:
  - **Страж инварианта был липовым.** Проверка дублей через `text_string_to_metric_families`
    молча склеивает СМЕЖНЫЕ одноимённые семейства — мутация ловилась лишь потому, что дубль
    случайно оказался несмежным. Переписано на сырой текст (`# TYPE`-строки + запрет `pid=`);
    мутационно перепроверено — теперь падает. Правило записано в 3.1.
  - **`render()` читала env в рантайме**, хотя value-class фиксируется при импорте: патч env
    в тесте уводил `render()` в multiproc-ветку → пустая, но валидная с виду выдача. Снимок
    `_MULTIPROC_PATH` при импорте.
  - `_drop_default_process_collectors()` перенесён из `init_metrics` в импорт: иначе выдача
    зависела от того, поднимался ли lifespan (`TestClient(app)` без него — паттерн репо).
  - Добавлен тест агрегации между воркерами (3 spawn-процесса × 5 инкрементов → 15.0) —
    свойство, ради которого существует весь multiproc, до этого не проверялось ничем.
    Попутно подтверждено: spawn-дети переисполняют модуль как `__mp_main__`, поэтому
    `prepare_multiproc_dir()` под guard'ом `__main__` отрабатывает строго в мастере.
  - `RISK_MODEL_METRICS__ENABLED` задокументирован в `.env.example` (был единственным
    недокументированным флагом; ср. bug #138 — цена этого уже плачена).
  - Смягчено непроверенное утверждение «Prometheus отвергает скрейп целиком» (на живом
    Prometheus не проверялось) — в 3.1 и в комментарии кода.
  - В спеку внесены требования безопасности к T2 (белый список `method`, запрет сырого пути,
    `Mount` без `route`, скрытые роуты, тест кардинальности), к T5 (single-flight + кэш
    отрицательного результата) и к T7 (сетевое ограничение источника скрейпа), а также
    уточнение неточной посылки «и так видны в OpenAPI» в 2.4.
  - ⚠️ **Не сделано намеренно, нужно решение пользователя:** env `PROMETHEUS_MULTIPROC_DIR` в
    Dockerfile распространяется на consumer/migrations (общий образ). Безвредно сейчас, но
    T3 (импорт `ERRORS_TOTAL` в logger) уведёт consumer в multiproc-режим с нечитаемыми и
    неочищаемыми mmap-файлами. Развёрнуто описано в шапке T3.
  - Проверено ревью и в порядке (не перепроверять): FD-ликов от `MultiProcessCollector` нет
    (200 скрейпов: 11→11); параллельные `render()` в 8 потоков — чисто; `/metrics` без
    lifespan отдаёт 200, не 500; лицензия `prometheus-client` (Apache-2.0) проходит
    `check_licenses`; бамп `risk-model` в `uv.lock` 0.4.0→0.5.0 — не хвост, лок догнал
    протухший `pyproject.toml` из develop.
- 2026-07-21: T2–T6 реализованы в одной сессии, все линтеры/тесты зелёные (989 passed, 67 skipped;
  единственные 2 фейла — `test_profiling.py`, yappi не собран, окруженческое). Детали:
  - **T3 open-question РЕШЁН (env `PROMETHEUS_MULTIPROC_DIR`): вариант (а) — перенос из
    `docker/Dockerfile` в `docker-compose.yml` на сервис `app`.** Обоснование: (1) прод-деплой идёт
    `docker compose -f docker-compose.yml up -d --build` (`.gitlab-ci.yml`) — env на сервисе `app`
    выставляется до старта процесса, import-time-детект режима отрабатывает штатно; (2) проверено:
    и consumer (прямо), и migrations (через `src.config`→валидатор→`src.logger`) транзитивно
    импортируют `src.logger`, а после T3 — и `src.metrics`; убрав env из общего образа, оба
    остаются single-process, сирот-mmap нет, Р3 соблюдён; (3) «образ не самодостаточен вне compose»
    — не проблема: заказчик наш образ не запускает (скрейпит /metrics по сети), а весь наш деплой —
    через этот compose. prometheus_client 0.25.0 включает multiproc по САМОМУ наличию env, поэтому
    обнулить через compose-override нельзя — только физическое отсутствие у consumer (вариант (а)).
  - **T2**: HTTP-метрики — отдельной миддлварью `make_metrics_middleware` в `src/api/middleware.py`,
    регистрация в main.py ПОСЛЕ `request_middleware` (внешний слой, duration включает логирование).
    `path` берётся из `scope["route"].path_format`; для mount статики — из `scope["root_path"]`
    (проверено: Mount не кладёт `route`, но выставляет `root_path`=`/questionnaire`); скрытые роуты
    (`include_in_schema=False`) → `other`; `method` — белый список, иначе `other`. Тест кардинальности
    (мусорные URL × нестандартные методы → число рядов не растёт) — есть. Логирующую миддлварь не
    трогал (нулевой дифф в PII-зоне).
  - **T3**: `_MetricsHandler` напрямую на логгере "app" (мимо fingers-crossed); `stacklevel=3/2` в
    `_log`/`business`, чтобы `component`=модуль вызывающего. `handleError` переопределён в no-op
    (тихо; `# noqa: N802` — override stdlib-метода). Импорт `ERRORS_TOTAL` ленивый (boot-order).
  - **T4**: `_ProcStatsCollector` по `/proc` (мастер=getppid при multiproc, иначе getpid; воркеры —
    ppid==мастер). Парсинг stat — после последней `)`. На не-Linux collect() пуст. Чистые парсеры
    покрыты кросс-платформенными тестами, живые значения — skipif linux (CI).
  - **T5**: `src/infra/kafka/lag_probe.py` — `RecalcLagProbe` (Collector). Опрос на скрейпе с
    single-flight (asyncio.Lock) + кэш 10 с (в т.ч. отрицательный) + таймаут 2 с; ошибка → warning,
    lag_ok=0, рядов лага нет. Снимок заменяется целиком. Старт из lifespan best-effort (сбой не
    роняет app). Хендлер `/metrics` стал async, делает `await probe.refresh()` перед render().
    NB (по факту): проба живёт per-worker (LOCAL_REGISTRY рендерится тем воркером, что обслужил
    скрейп) — каждый воркер держит свои admin+consumer к Kafka; для стенда приемлемо.
  - **T6**: `docs/metrics.md` (RU) сверен с реальной выдачей `/metrics`; раздел 7 актуализирован.
  - Правки прод-кода T2–T5 не меняют инвариантов T1 (LOCAL_REGISTRY только кастомные коллекторы:
    build_info, /proc, lag — все `*MetricFamily`; счётные HTTP/errors — в default REGISTRY).
- 2026-07-21: T7 — ревью субагентом на Fable (полнота+хардненинг, не «баги в диффе») и фиксы:
  - **#1 (medium)**: `RecalcLagProbe.start()` тёк started-consumer, если падал `admin.start()`
    (поля присваивались только после обоих start → `stop()` был no-op). Починено:
    `_cleanup_failed_start` прибирает поднятое при частичном старте, ошибку пробрасывает.
  - **#2 (medium)**: при недоступности Kafka/ACL на старте пробы был не `lag_ok=0`, а ОТСУТСТВИЕ
    ряда (дашборд заказчика показал бы «нет данных» вместо тревоги). Починено: коллектор
    регистрируется в LOCAL_REGISTRY ДО старта клиентов, `start()` best-effort — `lag_ok=0` виден
    сразу. Ленивый self-heal-reconnect сознательно НЕ делал: продюсер и так хард-требует Kafka на
    старте, а lazy-start под `asyncio.timeout` тянет edge-кейсы с отменой/утечкой; восстановление —
    по рестарту на следующем деплое (частые), `lag_ok=0` до него виден.
  - **#5 (low)**: хендлер `/metrics` стал async (ради `await refresh()`), из-за чего `render()`
    поехал на event loop; вернул в threadpool через `run_in_threadpool(render)` — ручка
    неавторизована (T7.1a), держать рендер вне loop важнее.
  - **#6 (nit)**: `_last_poll_at` обновлялся в `finally` → при отмене скрейпа (CancelledError)
    устаревший снимок помечался «свежим» на 10 с. Перенёс обновление из finally в тело (успех/
    пойманная ошибка), CancelledError теперь метку не трогает.
  - **#3/#4**: добавлены тесты, которых не хватало: кросс-продукт кардинальности
    (методы×URL → число рядов ограничено), single-flight (два параллельных refresh → один опрос),
    `lag_ok=0` до первого опроса, уборка при частичном старте, реальная проводка
    `_init/_shutdown_lag_probe` (регистрация→render→снятие). #8/#7: docs/metrics.md — примеры
    `component` на app-модули (`producer`/`main`, не consumer-овый `cvd_client`) + заметка про
    counter-reset `process_cpu` при смерти воркера.
  - **Verified OK ревьюером** (эмпирически, не перепроверять): T2-кардинальность (200 враждебных
    запросов → 2 шаблонных лейбл-сета, сырых путей/методов нет); mount→`/questionnaire` через
    `scope["root_path"]` устойчиво (Starlette 1.0 мутирует тот же scope-dict); метрики-миддлварь —
    внешний слой (duration включает логирование); `stacklevel` даёт правильный `component`;
    fingers-crossed не задваивает; секретов/PII в выдаче нет; LOCAL_REGISTRY-инвариант держится.
  - Финал: ruff/ty/bandit/semgrep/lint-logger чисто; 994 passed, 67 skipped (2 фейла — yappi,
    окруженческое). Новых зависимостей нет (prometheus-client заведён в T1).
- 2026-07-21: ревью Филиппа на MR !138 (7 замечаний) — фиксы, коммит `2a6ad31`:
  - [reliability] `_shutdown_lag_probe`: `probe.stop()` обёрнут в try/except+warning — сбой
    закрытия клиентов пробы на shutdown не срывает дренаж продюсера/`engine.dispose()`.
  - [reliability] `/proc`-мастер: `_master_pid(workers)` — `getppid()` только при
    `_MULTIPROC_PATH and workers>1`, иначе `getpid()`. При workers=1+multiproc (форс профайлера)
    `getppid()`=PID 1 контейнера тянул посторонних детей init. `effective_workers` прокинут через
    `init_metrics(version, workers=...)`; config в metrics.py по-прежнему не импортируется.
  - [reliability] per-worker проба (×N коннектов на под) — подтверждено осознанным: `LOCAL_REGISTRY`
    рендерится обслужившим скрейп воркером, общий снимок между процессами prometheus_client не шарит;
    проба group-less (ребаланса нет), опросы лёгкие. Свести к одной — только вынеся lag на
    собственный `/metrics` консюмера (следующая итерация).
  - [observability] `component` errors_total — пакет-квалифицированный от `src/`
    (`calc.handler` vs `interpretation.handler`), `_component_from_record`.
  - [observability] `_cleanup_failed_start`: debug→warning (старт без per-request флага, MonologFilter
    резал sub-INFO → утечка была невидима).
  - [testing] +тест отмены `_poll()` (CancelledError не помечает кэш свежим); +тест суммирования
    по ЖИВЫМ воркерам-детям (linux, fork+barrier); +юнит-тест выбора мастера; +тест component.
  - Отдельно (замечание ty ранее): CI гоняет `ty check src/`, а `make lint-ty` = `ty check .`
    (с tests/) — тест-файлы типизируются только Makefile-таргетом. Гоняю его перед пушем.
