# Review Conventions — findings & prevention plan

Analysis of the exported merge-request review comments in `pr_comments/*.txt` (92 MRs,
48 with comments, 196 dated comments), and the prevention work derived from it.
Goal: stop the most common issues from ever reaching review.

---

## 1. What the review history actually contains

- **92 MRs** exported; **48 carried review comments**, 44 merged clean.
- Severity markers across substantive findings: **21 🔴 blockers, 99 ⚠️ warnings, 9 💡 nits**.
- **24 author acknowledgement/fix replies** ("спасибо за ревью / поправил / fixed in <sha>") — healthy fix-back rate.
- Deep reviews are mostly **@light_77 via an AI orchestrator** (tags `pr-reliability`, `pr-architecture`,
  `criterion=#N`). **@tayamarn** gives short pragmatic human comments; **@smlsn** is mostly an author.
- Most-cited single criterion: **`#9` test quality (7×)**, then `#5` reliability and `#10` data integrity (4× each).
- Rules cited as authority: `testing.md` (11), `architecture.md` (10), `security.md` (9),
  `error-handling.md` (8), `api-conventions.md` (2), `dependencies.md` (2), `linting.md` (1).

## 2. Issue categories, ranked by prevalence

1. **Database / migration safety** *(most prevalent, most 🔴)* — `ADD COLUMN NOT NULL` without default;
   destructive/irreversible `downgrade`; bare `DELETE`/`UPDATE` without `WHERE`; missing `ON CONFLICT`
   (re-run duplicates); non-idempotent migrations; `SET lock_timeout` scoped too wide; missing indexes.
2. **Test quality (not coverage %)** — mocking what should run locally; `patch.object` instead of
   `app.dependency_overrides`; unit tests in `tests/integration/`; vacuously-passing assertions
   (`if x is not None: assert ...`); missing test branches for the new path; dead `pytestmark=skip`
   scaffolding giving false coverage.
3. **Reliability & error handling** — swallowed exceptions; missing `exc_info`; over-broad `except`
   catching non-retriable errors; missing fail-fast guards; silent worker crash / event drop.
4. **Architecture / layering** — SQLAlchemy in routers; business logic in routers; `domain → infra`
   import inversion; cross-domain reader coupling; dead exports; abstraction leaks.
5. **Spec / wiki mismatch (analytics correctness)** — wrong threshold boundaries (`>=` vs `>`); wrong
   constants (AtypHyper 0.93 vs 1.0); renamed/merged parameters diverging from wiki; `group_code`
   breaking the eligibility gate.
6. **Security / PII / secrets** — hardcoded test API key; token served without auth; `str` instead of
   `SecretStr` for passwords; PII in logs/error messages; no auth on debug endpoint; unnormalized
   trust-boundary input.
7. **Performance / N+1** — per-system query amplification; missing `DISTINCT` on `IN`; extra round-trips;
   unindexed filter predicates.
8. **Concurrency / deployment config** *(Kafka-era)* — semaphore capping concurrency; `num_partitions=1`;
   missing healthcheck; `deploy.replicas` ignored by plain compose; service-start ordering.
9. **Minor / clarity** — magic constants, stale comments, topic-name typos, duplicate seed rows, naming.

## 3. The key insight that shapes prevention

**For at least 4 of the top 6 categories, a rule already existed in `.claude/rules/` and was violated anyway:**

- `architecture.md` already bans logic/SQL in routers and `domain → infra` — violated (MR27, MR53).
- `testing.md` already bans mocking-the-DB, mandates `dependency_overrides` and `unit/`/`integration/` split — violated (MR27, MR45).
- `error-handling.md` already bans `except Exception: pass` and mandates traceback — violated.
- `security.md` already bans secrets in code — violated (MR27 hardcoded key).

**Conclusion:** adding *more prohibitions* for things already prohibited is noise — it dilutes attention
and doesn't change behavior, because the rule wasn't salient at generation time. A new rule only helps
where there's a genuine recall gap *with no existing rule*. Everything else needs **deterministic
enforcement** (a failing check the agent sees in-loop), not more prose.

Note also a non-trivial **AI-reviewer false-positive rate**, concentrated in infra/compose
(`deploy.replicas` "агент попутал", "коды правильные — ложное срабатывание", a premature index
suggestion deferred). Do **not** gate CI on the infra/compose lens; keep it advisory or human.

## 4. Prevention: where each mechanism fits

| Category | Best mechanism | Why not "just a rule" |
|---|---|---|
| Migration safety (🔴) | `check_migration_safety.py` + post-edit hook + (future) upgrade→downgrade→upgrade harness | Irreversible damage — probabilistic adherence unacceptable |
| Layering | `import-linter` contracts *(recommended, not yet added)* | Rule existed, still violated |
| Blind/over-broad except, missing `exc_info` | ruff `BLE`/`TRY`/`LOG` rules *(recommended)* + rule line added | Rule existed, still violated |
| Hardcoded secrets | `gitleaks`/`detect-secrets` pre-commit *(recommended)* | Rule existed, still violated |
| Mock-the-DB / test placement / vacuous asserts | custom linter + ruff `PT` + diff-coverage + mutation testing *(recommended)* | Rule existed, still violated |
| `SecretStr` for credential fields | rule line added (genuine gap) + custom semgrep *(recommended)* | No prior rule — real recall gap |
| Spec/wiki mismatch | machine-readable thresholds → generated tests; analyst-signoff label | Agent can't know external facts |
| Infra/compose | human review / dedicated narrow reviewer | AI reviewer false-positives here |

## 5. What was implemented in this pass

**Migration-safety linter — `scripts/check_migration_safety.py`** (mirrors `check_logger_info.py`):
- `M1` `add_column(nullable=False)` without `server_default`
- `M2` `INSERT INTO` without `ON CONFLICT` (non-idempotent seed)
- `M3` `DELETE FROM` without `WHERE` (destructive)
- `M4` `UPDATE ... SET` without `WHERE` (excludes `ON CONFLICT DO UPDATE` upserts)
- `M5` empty / `pass` / no-op `downgrade()`
- SQL checks parse only `sa.text(...)` literals via AST (no docstring/comment false positives).
- Per-line suppression: `# migration-safety: ok <reason>`.
- Run: `make lint-migrations ARGS="migrations/versions/<file>.py"` or with no args for all.
- **Deliberately NOT in the aggregate `make lint`** — the legacy backlog has known "replace-seed" hits;
  the target is new migrations + the hook. A baseline/grandfather file is a possible follow-up if it
  should gate CI.

**Post-edit hook — `.claude/hooks/post_edit_lint.sh`** (wired in `.claude/settings.local.json`,
`PostToolUse` on `Edit|Write|MultiEdit`):
- On `migrations/versions/*.py` → runs the migration-safety linter.
- On `src|scripts/**/*.py` → runs `ruff check` + the logger linter (scoped to the edited file).
- Exits `2` with findings on stderr → the agent gets immediate feedback and self-corrects **before review**.
  This is the lever that closes the "rule existed but wasn't salient" gap.

**Skill — `.claude/skills/postgres-migrations/SKILL.md`:**
- New "Seeding Reference Tables (idempotency + reversibility)" section with the canonical safe seed
  (the 0040 pattern) and the NOT-NULL / DELETE-WHERE / downgrade / lock_timeout rules.
- New "Pre-finish self-review checklist".

**Rules (only genuine gaps — no restating existing ones):**
- `error-handling.md`: `exc_info=` required on `logger.error` in `except`; don't catch broader than
  the recoverable subtype.
- `security.md`: `SecretStr` for credential pydantic fields; test secrets never hardcoded.

## 6. Recommended follow-ups (not yet done)

1. **Migration test harness** in CI — seed a non-empty table, run `upgrade → downgrade → upgrade` against
   a testcontainer Postgres. Catches M1/M2/M3 *semantically*, beyond the linter's heuristics. Highest ROI.
2. **`import-linter`** contracts encoding `architecture.md` (forbid `*.domain → *.infra`,
   `*.routers → sqlalchemy`; domain independence).
3. **Enable ruff rule families** `BLE`, `TRY`, `LOG`, `PT` in `pyproject.toml`.
4. **`gitleaks`/`detect-secrets`** as a pre-commit hook (repo already uses pre-commit on pre-push).
5. **Custom semgrep**: credential field must be `SecretStr`; PII keys in `log_context=`/`context=`.
6. **Mutation testing on the diff** (`mutmut`, changed files only) + **diff-coverage** gate — the only
   tools that reliably catch vacuous/wrong-thing tests (category #2).
7. **Machine-readable thresholds** from the analyst wiki → generated table-driven tests, so calc
   constants can't silently diverge from spec (category #5). Add an analyst-signoff MR label as a stopgap.
8. **Separate narrow reviewer** for `docker/` + `.gitlab-ci` (the AI reviewer false-positives on infra).
