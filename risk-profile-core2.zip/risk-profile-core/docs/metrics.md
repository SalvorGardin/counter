# Метрики Prometheus — risk-profile-core

Порядок проверки массового пересчёта, включая адреса ручек app и consumer, приведён в
[`bulk-recalc-metrics-check.md`](bulk-recalc-metrics-check.md).

Метрики отдаются в формате Prometheus text на ручке `GET /metrics`. Есть два типа ручек —
по одной на каждый процесс соответствующего типа:

- процесс `app` (FastAPI, uvicorn workers=4) — на порту приложения, на стенде
  `http://5.42.105.101:9001/metrics`: HTTP-латентность, лаг очереди пересчёта, CPU/RAM, версия;
- процесс `consumer` (воркер пересчёта) — на порту его HTTP-проб
  (`RISK_MODEL_CONSUMER_HEALTH_PORT`, публикуется диапазоном `CONSUMER_HEALTH_PORT_RANGE`):
  время пересчёта и ошибки этого процесса. Сам пересчёт живёт там, поэтому и метрики его — там.

**Без авторизации** — в выдаче нет ПДн, только агрегаты и шаблоны роутов. Рекомендуемый
`scrape_interval` — **15 с**.

Аварийный рубильник: `RISK_MODEL_METRICS__ENABLED=false` → ручка отдаёт 404 (сбор при этом не
трогаем, чтобы после включения не было разрыва в истории счётчиков). Флаг общий: выключает обе
ручки сразу, пробы воркера при этом продолжают отвечать.

## Скрейп-конфиг Prometheus

```yaml
scrape_configs:
  - job_name: risk-profile-core
    scrape_interval: 15s
    static_configs:
      - targets: ["5.42.105.101:9001"]

  - job_name: risk-profile-core-consumer
    scrape_interval: 15s
    static_configs:
      # Пример для двух реплик: по одной цели на каждый фактический хост-порт.
      # При другом числе реплик список целей нужно обновить.
      - targets: ["5.42.105.101:9101", "5.42.105.101:9102"]
```

Это пример, а не перечень работающих реплик: после пересоздания контейнеров порты могут
перераспределиться. Для текущего dev-стенда сверяйте цели по
[`bulk-recalc-metrics-check.md`](bulk-recalc-metrics-check.md).

Метрики отдаются **с позиции сервиса**, без разбивки по внутренним процессам: multiprocess-режим
prometheus_client суммирует счётчики всех uvicorn-воркеров app в единые ряды (лейбла `pid` нет),
CPU/RAM — суммарно по мастеру и воркерам. Реплики воркера пересчёта — отдельные цели скрейпа,
и различает их Prometheus лейблом `instance`; на графиках их обычно складывают (`sum by (le)`),
потому что интересует время пересчёта сервиса, а не конкретной реплики. Какой реплике достался
какой хост-порт, между рестартами не фиксировано.

## Перечень метрик

| Метрика | Тип | Лейблы | Семантика |
|---|---|---|---|
| `risk_profile_core_http_request_duration_seconds` | Histogram | `method`, `path`, `status`, `host` | Латентность входящих HTTP-запросов, дефолтные бакеты (`0.005…10` с). `_count` = число запросов, `_sum` = суммарное время; доля ошибок — по `status`. |
| `risk_profile_core_errors_total` | Counter | `level`, `component` | Число лог-записей уровня ERROR и выше. Ловит и «200-но-ошибка»: фоновый сбой ПОСЛЕ отданного ответа (например, фейл фонового enqueue в Kafka) — это ERROR-запись. |
| `risk_profile_core_recalc_queue_lag` | Gauge | `topic`, `partition` | Лаг очереди пересчёта по партиции: `end_offset − committed_offset` группы `risk-recalc-workers` на топике `risk-profile.recalc-commands`, на момент скрейпа (кэш 10 с). Есть только при включённой Kafka. |
| `risk_profile_core_recalc_queue_lag_ok` | Gauge | — | `1` — лаг опрошен успешно, `0` — ошибка/таймаут опроса. При выключенной Kafka обе `recalc_queue_lag*` в выдаче отсутствуют. |
| `risk_profile_core_recalc_answer_to_result_seconds` | Histogram | `outcome`, `scope`, `source` | Время от постановки команды пересчёта в очередь до записи результатов и интерпретаций. Отдаёт процесс `consumer`. |
| `risk_profile_core_recalc_queue_wait_seconds` | Histogram | `outcome`, `scope`, `source` | Часть этого времени, проведённая командой в очереди до начала обработки. |
| `risk_profile_core_recalc_duration_seconds` | Histogram | `outcome`, `scope`, `source` | Часть этого времени, потраченная на саму обработку команды. |
| `risk_profile_core_recalc_background_commands_total` | Counter | `decision`, `reason` | Решения политики допуска фоновых команд в воркере: допущена или отброшена и почему. `admitted` увеличивается до расчёта, поэтому завершение проверять также по гистограммам и размеру когорты; размер когорты может уменьшать пользовательский трафик. |
| `risk_profile_core_cvd_saturated` | Gauge | — | `1` — процесс считает risk-profile-cvd насыщенным и отбрасывает фоновые команды пересчёта, `0` — нет. Решение принимается по скользящему окну вызовов этого процесса: среднее время ответа выше `RISK_MODEL_CVD__SATURATION_LATENCY_MS` или доля сбоев выше `RISK_MODEL_CVD__SATURATION_ERROR_RATE` (сеть, таймаут, любой не-2xx, кроме 400, или `isSuccess=false`), при числе вызовов не ниже `RISK_MODEL_CVD__SATURATION_MIN_OBSERVATIONS`. Показание процесса, обслужившего скрейп, а не сумма по процессам. Включает задержку возврата: после того как пороги вернулись в норму, значение остаётся `1`, пока не истечёт собственная задержка процесса. Метрика — следствие решения о допуске, снятие показаний его не меняет. |
| `risk_profile_core_process_cpu_seconds_total` | Counter | — | Суммарное CPU-время (utime+stime) uvicorn-мастера и всех воркеров, секунды. Только Linux. |
| `risk_profile_core_process_resident_memory_bytes` | Gauge | — | Суммарный RSS мастера и воркеров, байты. Только Linux. |
| `risk_profile_core_process_count` | Gauge | — | Число процессов сервиса (мастер + воркеры); проседание = упавший воркер. Только Linux. |
| `risk_profile_core_build_info` | Gauge | `version` | Константа `1`, версия сервиса из `version.json` — под аннотации деплоев в Grafana. |

### Значения лейблов

- **`path`** — ШАБЛОН роута, а не сырой URL: `/api/v1/testing/patients/{patient_id}`, не
  `/api/v1/testing/patients/abc-123`. Несматченный путь → литерал `unmatched`; статика опросника
  (`/questionnaire/*`) → одно значение `/questionnaire`; скрытые служебные роуты → `other`. Так
  число рядов ограничено числом роутов, а не URL-ами анонимных клиентов.
- **`method`** — только `GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS`; любой другой метод → `other`.
- **`status`** — строка HTTP-кода (`"200"`, `"401"`, `"404"`); необработанное исключение → `"500"`.
- **`host`** — hostname контейнера сервиса (`socket.gethostname()`), НЕ `Host`-заголовок клиента.
- **`level`** — `error` / `critical` / `alert` / `emergency`.
- **`component`** — имя модуля-источника лог-записи. На ручке app это модули app-процесса
  (например `producer`, `main`), на ручке воркера — модули процесса пересчёта (например
  `calc.handler`, `cvd_client`): раньше эти сбои были видны только в журналах.
- Пробы (`/`, `/health`, `/readiness`, `/liveness`) и сам `/metrics` в гистограмму НЕ попадают.
- **`outcome`** — чем закончилась команда пересчёта: `written` — результаты записаны;
  `empty` — записывать было нечего (инструменты не отрезолвились либо у пациента нет данных для
  них); `failed` — расчёт упал или батч результатов откатился. На графиках времени по умолчанию
  смотреть `outcome="written"`: быстрые `empty`-команды составляют основную массу и вытягивают
  картину в оптимистичную сторону.
- **`scope`** — `full` (пересчёт всех активных инструментов) или `partial` (только инструменты,
  связанные с изменившимися параметрами).
- **`source`** — кто породил команду: `user` — пользовательский сценарий (ответ пациента, ЭМК,
  ручной запрос), `background` — массовый пересчёт устаревших профилей
  (`python -m src.workers.bulk_recalc`). **Время ответа пациенту смотреть по `source="user"`.**
  Фоновые ряды ведут себя иначе по построению, а не из-за деградации: у такой команды нет
  ответа пациента, с которого начинается отсчёт `answer_to_result`, и нет человека, который
  ждёт результата, а `queue_wait` у неё равен глубине завала прогона. В общих рядах прогон
  подменял бы собой пользовательский SLI ровно на то время, когда за ним и надо следить.
  Пары `scope="partial"` × `source="background"` не существует: прогон публикует только
  команды полного пересчёта. Команды проверочного батча прогона — тоже фоновые и идут рядами
  `source="background"`.
- **`decision`** / **`reason`** (`recalc_background_commands_total`) — `admitted` с `reason=none`
  либо `dropped` с причиной: `cvd_saturated` (внешний ML-сервис риска считается насыщенным),
  `no_slot` (фоновая ёмкость процесса занята), `rate_limited` (с прошлой допущенной команды
  прошло меньше минимального интервала). Отброшенная команда не потеряна: пациент остался
  в когорте и вернётся следующим прогоном. Команды проверочного батча проходят через политику
  допуска наравне с остальными фоновыми и учитываются здесь же.
- Шкала корзин у всех трёх гистограмм пересчёта общая и своя, а не дефолтная:
  `0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 20, 30` секунд — ожидание в очереди под нагрузкой уходит
  в десятки секунд и в дефолтную шкалу (верхняя конечная корзина 10 с) не помещается.

## Примеры PromQL для дашборда

**RPS (общий и по роуту):**
```promql
sum(rate(risk_profile_core_http_request_duration_seconds_count[5m]))
sum by (path) (rate(risk_profile_core_http_request_duration_seconds_count[5m]))
```

**p95-латентность (общая):**
```promql
histogram_quantile(0.95, sum by (le) (rate(risk_profile_core_http_request_duration_seconds_bucket[5m])))
```

**Доля 5xx + скрытые ошибки (в т.ч. «200-но-ошибка»):**
```promql
sum(rate(risk_profile_core_http_request_duration_seconds_count{status=~"5.."}[5m]))
  / sum(rate(risk_profile_core_http_request_duration_seconds_count[5m]))
sum(rate(risk_profile_core_errors_total[5m]))
```

**Очередь пересчёта — три ключевых показателя:**
```promql
sum(risk_profile_core_recalc_queue_lag)                 # общий лаг очереди
max(risk_profile_core_recalc_queue_lag)                 # максимальный перекос по партиции
count(risk_profile_core_recalc_queue_lag > 0)           # число отстающих партиций
min(risk_profile_core_recalc_queue_lag_ok)              # 0 → опрос лага не удаётся (брокер?)
```

**Полное время пользователя — от отправки ответа до готового результата:**
```promql
histogram_quantile(0.95, sum by (le) (rate(
  risk_profile_core_http_request_duration_seconds_bucket{method="POST",path=~"/api/v[12]/clients/\\{clientId\\}/questions/answers"}[5m])))
+
histogram_quantile(0.95, sum by (le) (rate(
  risk_profile_core_recalc_answer_to_result_seconds_bucket{outcome="written",source="user"}[5m])))
```
Первое слагаемое — сохранение ответа с ответом клиенту, второе — пересчёт. Время обработки
HTTP-запроса во вторую метрику НЕ входит: её отсчёт начинается с постановки команды в очередь,
то есть сразу после сохранения ответа (разница — единицы миллисекунд).

**Очередь или расчёт — что именно тормозит:**
```promql
histogram_quantile(0.95, sum by (le) (rate(risk_profile_core_recalc_queue_wait_seconds_bucket{outcome="written",source="user"}[5m])))
histogram_quantile(0.95, sum by (le) (rate(risk_profile_core_recalc_duration_seconds_bucket{outcome="written",source="user"}[5m])))
```

**Доля сбойных пересчётов:**
```promql
sum(rate(risk_profile_core_recalc_answer_to_result_seconds_count{outcome="failed"}[5m]))
  / sum(rate(risk_profile_core_recalc_answer_to_result_seconds_count[5m]))
```

**Массовый пересчёт: сделал ли прогон работу и что его сдерживает:**
```promql
sum(rate(risk_profile_core_recalc_background_commands_total{decision="admitted"}[5m]))
sum by (reason) (rate(risk_profile_core_recalc_background_commands_total{decision="dropped"}[5m]))
```
Первый ряд — темп фоновых пересчётов, второй показывает, что его ограничивает: насыщение
внешнего сервиса, занятая ёмкость или верхняя граница темпа. Нулевой первый ряд при растущем
втором — фон голодает; смотреть после этого на остаток когорты в логе прогона.

**CPU / RAM:**
```promql
rate(risk_profile_core_process_cpu_seconds_total[5m])   # доля CPU (ядер) в среднем за окно
risk_profile_core_process_resident_memory_bytes         # суммарный RSS сервиса
risk_profile_core_process_count                         # ожидается workers+1 (мастер)
```

## Пример выдачи (фрагмент)

Процесс app:

```text
# TYPE risk_profile_core_http_request_duration_seconds histogram
risk_profile_core_http_request_duration_seconds_count{host="app-7c9d",method="GET",path="/api/v1/testing/patients/{patient_id}",status="200"} 42.0
risk_profile_core_http_request_duration_seconds_count{host="app-7c9d",method="GET",path="unmatched",status="404"} 3.0
# TYPE risk_profile_core_errors_total counter
risk_profile_core_errors_total{component="producer",level="error"} 2.0
# TYPE risk_profile_core_recalc_queue_lag gauge
risk_profile_core_recalc_queue_lag{partition="0",topic="risk-profile.recalc-commands"} 12.0
risk_profile_core_recalc_queue_lag_ok 1.0
# TYPE risk_profile_core_process_cpu_seconds_total counter
risk_profile_core_process_cpu_seconds_total 137.4
risk_profile_core_process_resident_memory_bytes 5.28482304e+08
risk_profile_core_process_count 5.0
# TYPE risk_profile_core_build_info gauge
risk_profile_core_build_info{version="0.7.0"} 1.0
```

Процесс consumer (та же выдача, но своя — метрики HTTP-запросов и версии в ней нет):

```text
# TYPE risk_profile_core_recalc_answer_to_result_seconds histogram
risk_profile_core_recalc_answer_to_result_seconds_bucket{le="0.5",outcome="written",scope="partial",source="user"} 118.0
risk_profile_core_recalc_answer_to_result_seconds_bucket{le="+Inf",outcome="written",scope="partial",source="user"} 124.0
risk_profile_core_recalc_answer_to_result_seconds_count{outcome="written",scope="partial",source="user"} 124.0
risk_profile_core_recalc_answer_to_result_seconds_sum{outcome="written",scope="partial",source="user"} 47.9
risk_profile_core_recalc_answer_to_result_seconds_count{outcome="written",scope="full",source="background"} 1840.0
# TYPE risk_profile_core_recalc_queue_wait_seconds histogram
risk_profile_core_recalc_queue_wait_seconds_count{outcome="empty",scope="partial",source="user"} 2103.0
# TYPE risk_profile_core_recalc_duration_seconds histogram
risk_profile_core_recalc_duration_seconds_count{outcome="written",scope="partial",source="user"} 124.0
# TYPE risk_profile_core_recalc_background_commands_total counter
risk_profile_core_recalc_background_commands_total{decision="admitted",reason="none"} 1840.0
risk_profile_core_recalc_background_commands_total{decision="dropped",reason="rate_limited"} 9312.0
# TYPE risk_profile_core_errors_total counter
risk_profile_core_errors_total{component="calc.handler",level="error"} 1.0
```

## Эксплуатационные заметки

- **Счётчики обнуляются на рестарте контейнера** — штатный counter reset Prometheus,
  `rate()`/`increase()` его обрабатывают.
- **`process_cpu_seconds_total` может «проседать» при смерти воркера**: это сумма по живым PID, и
  уход воркера убирает его накопленные тики → Prometheus видит counter reset ровно в момент, когда
  просело `process_count`. `rate()` это сглаживает, но всплеск-артефакт на графике возможен.
- **Multiprocess-директория** (`/tmp/prometheus-multiproc`, задаётся сервису `app` в
  `docker-compose.yml`) чистится на старте контейнера точкой входа `python -m src` — до загрузки
  приложения. Поэтому выдача полна при любом числе воркеров, в том числе при одном
  (`RISK_MODEL_WORKERS=1` или включённый профайлер, который форсирует один воркер): ряды процесса,
  обслуживающего запросы, и предынициализированные ряды на месте, а значения прошлого запуска в
  выдачу не попадают. При крашлупе воркера рост директории в единицах МБ вычищается следующим
  рестартом, крашлуп виден по `risk_profile_core_process_count`.
- **Опрос лага** висит на скрейпе `/metrics`: single-flight + кэш 10 с + таймаут 2 с. При
  недоступной Kafka `recalc_queue_lag_ok` = 0, ряды лага отсутствуют, `errors_total` при этом НЕ
  растёт (опрос логируется как warning, не error).
- **Сетевое ограничение источника скрейпа** (firewall / bind на внутренний интерфейс до IP
  Prometheus) — рекомендуемый компенсирующий контроль к неавторизованной ручке (см. MR / спека
  T7.1a). Ручка в `_PROBE_PATHS`, поэтому в логах app скрейпы следов не оставляют. К порту проб
  воркера это относится в той же мере: он публикуется наружу ради опроса метрик, авторизации на
  нём нет.
- **Всплеск времени пересчёта после выката** при непустой очереди приходится на `queue_wait`:
  воркер перезапустился, накопленные команды ждали. Смотреть квантили, а не максимум, и
  сопоставлять с `risk_profile_core_build_info` процесса app.
- **Расхождение часов** между процессом, ставящим команду в очередь, и воркером даёт
  отрицательную разность — такие значения обрезаются в ноль (наблюдение не теряется, `_count`
  его учитывает). Сегодня оба процесса живут на одной машине.
- **Повторно доставленная команда** (rebalance до коммита оффсета) замеряется со старой отметкой
  и не фильтруется: она честно отражает, когда результат стал виден.
- **При `RISK_MODEL_KAFKA__ENABLED=false`** пересчёт идёт в процессе app, и его замеры видны на
  ручке app, а не воркера. Ожидание в очереди на этом пути околонулевое.
- **Нулевые ряды `recalc_*` на ручке app при включённой Kafka** — норма: ряды всех комбинаций
  меток заводятся при старте любого процесса, чтобы `increase()` видел рождение счётчика в нуле.
  Расчётов в app это не означает.
