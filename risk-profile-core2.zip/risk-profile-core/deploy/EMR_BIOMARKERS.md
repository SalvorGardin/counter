# Развёртывание приёма биомаркеров ЭМК (`release_biomarkers`)

Целевая платформа — Kubernetes. `docker-compose.yml` и `docker-compose.infra.yml` служат
примерами для локальной разработки и dev-стенда. Эта инструкция описывает код ветки
`release_biomarkers`. У каждого процесса своя переменная строки подключения к БД, роль процесса
задаёт его точка входа: `app` — `RISK_MODEL_PROFILE_DB_URL`, `consumer` —
`RISK_MODEL_CALCULATION_DB_URL`, `emr-consumer` — `RISK_MODEL_EHR_DB_URL`, миграции —
`RISK_MODEL_MIGRATIONS_DB_URL` (подробно — [`deploy/db/README.md`](db/README.md)).

## Репозитории и состав

Основной репозиторий — `git@gitlab.tywys.ru:risk-profile/risk-profile-core.git`.
Один образ из [`docker/Dockerfile`](../docker/Dockerfile) используется для:

| Процесс | Команда | Назначение |
|---|---|---|
| `migrations` | `alembic upgrade head` | Обновляет схему и справочники PostgreSQL. |
| `app` | `python -m src` | Предоставляет API риск-профиля. |
| `consumer` | `python -m src.workers.calc_consumer` | Выполняет пересчёт риска из Kafka-команд. |
| `emr-consumer` | `python -m src.workers.emr_biomarkers_consumer` | Принимает биомаркеры ЭМК и заказывает пересчёт. |

Kafka и ELK для dev-стенда описаны в [`docker-compose.infra.yml`](../docker-compose.infra.yml),
приложение и PostgreSQL — в [`docker-compose.yml`](../docker-compose.yml). Для расчёта риска
ССЗ при `RISK_MODEL_CVD__ENABLED=true` дополнительно нужен образ из репозитория
`git@gitlab.tywys.ru:risk-profile/risk-profile-cvd.git`. Redis в схеме этой ветки не используется.
Формат входного сообщения описан в вики `risk-profile-core`:
`Аналитика/Внешние-контракты-API/Emr-biomarkers`.

## Зависимости и настройки `emr-consumer`

- PostgreSQL: в Compose используется образ `postgres:16-alpine`. `emr-consumer` читает строку
  подключения из `RISK_MODEL_EHR_DB_URL` (драйвер `postgresql+asyncpg`, логин `risk_ehr_app`);
  переменные других процессов ему не нужны и на него не влияют, поэтому все они могут лежать в
  одном пуле переменных пода. Строку подключения передавать через Kubernetes Secret. На старте
  процесс сверяет `current_user` с `risk_ehr_app` и под чужим логином не поднимается. На стенде без
  отдельных логинов — режим общего логина `RISK_MODEL_DB_ASSUME_RUNTIME_ROLE=true`
  (см. [`deploy/db/README.md`](db/README.md)); в проде не включать.
- Kafka: использовать стандартные настройки подключения площадки. Кодовые значения по умолчанию —
  `SASL_SSL` и `SCRAM-SHA-512`; остальные параметры клиента и чтения можно оставить по умолчанию.
  Если у брокера собственный CA, смонтировать сертификат и задать путь к нему.
- **Отдельно нужен топик `emr-biomarkers` с одной партицией.** Внешний продюсер пишет в него
  сообщения с ключом `clientId`. `emr-consumer` читает его в группе
  `risk-emr-biomarkers-workers` и публикует команды в `risk-profile.recalc-commands`.
  Для полного пути пересчёта нужны также выходной топик `risk-calculation`, работающие
  `consumer` и `app`. Названия топиков и группы должны совпадать с Kafka ACL.
- Разворачивать одну реплику `emr-consumer`: дополнительные реплики в той же группе не получат
  партицию. Для новой группы `auto_offset_reset=earliest` по умолчанию: первый запуск обработает
  сохранившиеся в топике сообщения, если у группы ещё нет зафиксированного смещения.

### Переменные окружения `emr-consumer`

В таблице перечислены переменные для запуска воркера, настройки эксплуатации и параметр
`kafka-init`, который используется при создании топика команд. Для стандартного запуска
достаточно задать строки с пометкой «Обязательно»; «по умолчанию» означает, что переменную
можно не передавать. Значения Secret хранить в
Kubernetes Secret, остальные заданные значения — в ConfigMap. Пароли из
[`.env.example`](../.env.example) не использовать при развёртывании.

| Переменная | Значение и назначение | Когда задавать |
|---|---|---|
| `RISK_MODEL_EHR_DB_URL` | URL PostgreSQL с драйвером `postgresql+asyncpg`, логин `risk_ehr_app` | Обязательно, Secret |
| `RISK_MODEL_KAFKA__ENABLED` | `true`: включает Kafka-клиенты | Обязательно |
| `RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED` | `true`: включает чтение биомаркеров; по умолчанию `false` | Обязательно после создания топика и ACL |
| `RISK_MODEL_KAFKA__BOOTSTRAP_SERVERS` | Адреса брокеров, разделённые запятыми | Обязательно |
| `RISK_MODEL_KAFKA__SASL_USERNAME` | Логин Kafka | Обязательно при стандартном `SASL_SSL` |
| `RISK_MODEL_KAFKA__SASL_PASSWORD` | Пароль Kafka | Обязательно при стандартном `SASL_SSL`, Secret |
| `RISK_MODEL_KAFKA__SECURITY_PROTOCOL` | По умолчанию `SASL_SSL` | Если протокол площадки отличается |
| `RISK_MODEL_KAFKA__SASL_MECHANISM` | По умолчанию `SCRAM-SHA-512` | Если механизм площадки отличается |
| `RISK_MODEL_KAFKA__SSL_CAFILE` | Путь к смонтированному CA брокера; по умолчанию системный CA | Если у брокера собственный CA |
| `RISK_MODEL_KAFKA__TOPICS__EMR_BIOMARKERS` | По умолчанию `emr-biomarkers` | Если топик назван иначе |
| `RISK_MODEL_KAFKA__TOPICS__RECALC_COMMANDS` | По умолчанию `risk-profile.recalc-commands` | Если топик команд назван иначе |
| `RISK_MODEL_KAFKA__EMR_BIOMARKERS_CONSUMER__GROUP_ID` | По умолчанию `risk-emr-biomarkers-workers` | Если группа названа иначе |
| `RISK_MODEL_KAFKA__EMR_BIOMARKERS_CONSUMER__AUTO_OFFSET_RESET` | По умолчанию `earliest` для группы без смещения | Если согласовано иное начальное смещение |
| `RISK_MODEL_KAFKA__RECALC_COMMANDS_PARTITIONS` | По умолчанию `6` партиций топика команд | Только для `kafka-init`, если выбрано другое число партиций |
| `RISK_MODEL_HOST` | Адрес HTTP-проб; в образе по умолчанию `0.0.0.0` | Если переопределён адрес образа |
| `RISK_MODEL_EMR_CONSUMER_HEALTH_PORT` | Порт `/health`, `/liveness`, `/readiness`, `/metrics`; по умолчанию `8000` | Если выбран другой порт |
| `RISK_MODEL_METRICS__ENABLED` | По умолчанию `true`, включает `/metrics` | Если метрики нужно отключить |
| `LOG_LEVEL` | По умолчанию `NOTICE`, без префикса `RISK_MODEL_` | Если нужен другой уровень логирования |
| `RISK_MODEL_DB_POOL_RECYCLE_SECONDS` | По умолчанию `300`; срок переоткрытия соединения БД | Если таймаут сети или пулера меньше 300 секунд |
| `RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT` | По умолчанию `60` секунд на завершение обработки | Если меняется бюджет остановки Pod |

`EMR_CONSUMER_HEALTH_PORT` без префикса используется только в Compose для проброса порта
на хост; контейнер читает `RISK_MODEL_EMR_CONSUMER_HEALTH_PORT`. Параметр числа партиций
команд не настраивает потребление биомаркеров.

## Порядок запуска в Kubernetes

1. Подготовить PostgreSQL и Kafka. Создать топики `emr-biomarkers` (одна партиция),
   `risk-profile.recalc-commands` (число партиций из
   `RISK_MODEL_KAFKA__RECALC_COMMANDS_PARTITIONS`) и `risk-calculation` (одна партиция).
   `python -m src.workers.kafka_init` можно выполнить отдельным Job из образа ядра под
   Kafka admin. Job нужны `RISK_MODEL_KAFKA__ENABLED=true` и настройки Kafka; строка
   подключения к БД ему не нужна.
   Команда создаёт также тестовый топик и задаёт replication factor 1. Для
   многоброкерного кластера число реплик топиков определить по правилам площадки и создать
   топики административным способом.
2. Выдать Kafka-клиенту воркера Read на `emr-biomarkers` и группу
   `risk-emr-biomarkers-workers`, Write на `risk-profile.recalc-commands`. Проверить права
   внешнего продюсера на запись во входной топик и права воркера пересчёта на его топики.
   В dev-примере права выдаёт `kafka-acls-init` из инфраструктурного Compose-проекта.
3. Выполнить `alembic upgrade head` отдельным Kubernetes Job с `RISK_MODEL_MIGRATIONS_DB_URL`
   (только в секрете этого Job, не в общем пуле подов) до запуска
   процессов нового образа. Миграции справочников проводить в окно обслуживания. После
   их успешного завершения перезапустить `app`, `consumer` и `emr-consumer`, которые
   загружают справочники в память при старте. Общие замечания о миграциях есть в
   [`DEPLOY.txt`](DEPLOY.txt).
4. Развернуть `app` и `consumer`, затем Deployment `emr-consumer` с одной репликой,
   командой `python -m src.workers.emr_biomarkers_consumer` и `RISK_MODEL_EHR_DB_URL` для той же БД.
   Включить `RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=true` только после проверки топика
   и ACL. Иначе процесс может повторять попытки подключения: `/liveness` и `/health`
   при этом отвечают 200, а `/readiness` — 503 до успешного старта consumer-группы.
5. В контейнере воркера настроить `livenessProbe` на `/liveness`, `readinessProbe` на
   `/readiness`, сбор Prometheus с `/metrics`. Все ручки слушают
   `RISK_MODEL_EMR_CONSUMER_HEALTH_PORT` (по умолчанию 8000). Ограничить доступ внутренней
   сетью. `terminationGracePeriodSeconds` должен превышать
   `RISK_MODEL_CONSUMER_SHUTDOWN_TIMEOUT` (по умолчанию 60 секунд), чтобы завершить батч.
6. Проверить лог `kafka.consumer started` с ожидаемыми топиком и группой. После валидного
   тестового сообщения для существующего клиента проверить запись параметра в PostgreSQL и
   результат пересчёта. Проверка только `/readiness` недостаточна: при выключенном флаге
   биомаркеров воркер простаивает, но возвращает 200. Сверить смещение группы с концом
   входного топика и бизнес-событие `emr.biomarkers: message validated` с ожидаемым результатом.
   Тестовое сообщение должно содержать `operationType=save`: удаление (`delete`) в этой версии
   принимается по формату, но не обрабатывается.

Для остановки приёма выставить `RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=false` и перезапустить
`emr-consumer`. Смещение группы сохраняется. Возврат предыдущего образа после миграции БД
требует отдельного плана совместимости схемы и резервной копии данных.

Для локального запуска и dev-стенда порядок описан в [`README.md`](../README.md), раздел 4.3.
После подготовки `.env` с `RISK_MODEL_KAFKA__ENABLED=true` и сертификата Kafka пример команд:

```bash
make infra-up
# После успешного завершения kafka-init и kafka-acls-init установить в .env
# RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=true.
docker compose -f docker-compose.yml up -d --build
docker compose -f docker-compose.yml logs -f emr-consumer
```

## Ресурсы, логи и метрики

Для `emr-consumer` достаточно стандартных минимальных requests/limits CPU и RAM платформы.
Большая нагрузка не ожидается, точных замеров пока нет; числовых лимитов в Compose не задано.
При обработке сообщения воркер не рассчитывает риск и не строит интерпретации: он проверяет
пациента, одним запросом читает затрагиваемые параметры и для каждого записываемого параметра
выполняет два SQL-запроса (архивирование и upsert). При наличии сопоставленных кодов это
`2 + 2 × N` запросов на сообщение, где `N` — число разных записываемых параметров;
при сбое транзакция может быть повторена.

Пул PostgreSQL одного процесса допускает до 15 соединений (`pool_size=5`, `max_overflow=10`).
После первого запуска проверить фактическое потребление CPU/RAM и скорректировать лимиты,
если стандартный минимум не покрывает загрузку справочников и обработку сообщений.

Процесс пишет JSON-логи в stdout; для production задан уровень `LOG_LEVEL=NOTICE` или выше.
Dev-стенд собирает логи Filebeat в Elasticsearch (`docker-logs-*`). В Kubernetes использовать
штатный сбор stdout. Название и значение биомаркера маскируются по умолчанию; `client_id`
остаётся видимым в логах для трассировки. Бизнес-событие
`emr.biomarkers: message validated` содержит числа полученных, принятых, пропущенных и
записанных биомаркеров. Ошибки входных данных пишутся как WARNING, сбой обработки БД — как
`ALERT`.
Поле `recalc_requested=true` означает попытку заказать пересчёт, а не подтверждение публикации
команды: при ошибке Kafka `dispatch_recalc` пишет `ALERT` и завершает вызов без исключения.
Параметры при этом уже могут быть сохранены, а смещение входного сообщения — зафиксировано.

`GET /metrics` отдаёт метрики Prometheus без авторизации при
`RISK_MODEL_METRICS__ENABLED=true`. Воркер отдаёт общий счётчик
`risk_profile_core_errors_total` для логов уровня ERROR и выше. Отдельных метрик числа
обработанных биомаркеров и лага группы `risk-emr-biomarkers-workers` в коде нет. Пример
Prometheus-конфигурации в [`docs/metrics.md`](../docs/metrics.md) включает API и воркер
пересчёта; цель `emr-consumer` нужно добавить отдельно.

## Открытые вопросы к команде развёртывания

1. Нужны ли алерты по `ALERT`-логам,
   счётчику ошибок, лагу Kafka-группы и отсутствию обработки? Какие пороги, окна и получатели?
   Согласованных значений пока нет.
2. При `RISK_MODEL_KAFKA__EMR_BIOMARKERS_ENABLED=false` воркер не принимает сообщения, но
   `/readiness` возвращает 200. После успешного старта ошибки Kafka poll также могут
   повторяться при зелёной `/readiness`. Нужно ли изменить пробу или контролировать приём
   отдельным сигналом?
3. При сбое обработчика запись может быть пропущена с коммитом Kafka-offset. Для сбоя БД
   пишется `ALERT`, но автоматической повторной доставки после коммита нет. Достаточно ли
   алерта и ручного разбора сообщения до истечения Kafka retention, или требуется изменить
   обработку таких сбоев? Какой срок хранения входного топика для этого нужен? Как
   восстанавливать пересчёт, если параметры сохранены, а команда в Kafka не опубликована?
