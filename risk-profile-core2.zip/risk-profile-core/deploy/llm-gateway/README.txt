LLM GATEWAY НА DEV-СТЕНДЕ (профиль llm в docker-compose.infra.yml)

Сервер: ssh -p 2022 risk-profile@5.42.105.101, каталог ~/risk-profile-core.

Только для dev-стенда, не для прода: на проде gateway общий для всех сервисов и разворачивается
отдельно от этого репозитория, профиль llm там не включать.

Исходники gateway — копия в ~/risk-profile-llm-gateway, её обновляют вручную. Требование к версии
копии и поведение при остановке Redis — README, раздел «LLM gateway». После обновления копии
пересобрать обе реплики (Redis не трогается):

   make llm-gateway-rebuild

Готовность реплик (200 — Redis и GigaChat доступны, 503 — в теле указано, что именно нет):

   curl -s localhost:18010/readyz
   curl -s localhost:18011/readyz
