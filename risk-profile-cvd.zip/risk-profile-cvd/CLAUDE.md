# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

ML inference service that computes **cardiovascular-disease (CVD) risk** from biomarkers.
It originated as a one-shot CLI batch script (the "baseline") and is being reworked into a
**stateless FastAPI microservice** called over the network by the main product,
`risk-profile-core` (a separate FastAPI/Postgres/Kafka monolith on gitlab.tywys.ru, group
`risk-profile`). The ML stack (numpy/scipy/scikit-learn) is too heavy and CPU-bound to live
inside the core, hence this separate service.

Read these before doing integration work — they are the source of truth for scope and decisions:
- [SPEC.md](SPEC.md) — overview: what the service is, why, and the target architecture.
- [INTEGRATION_DECISIONS.md](INTEGRATION_DECISIONS.md) — locked decisions, open questions, and the
  **full feature lists with medians and core-catalog mappings** (the appendix is the canonical
  feature contract).
- [README_baseline.md](README_baseline.md) — the original baseline README (historical).

Project docs and all user-facing output strings are in **Russian**; keep that convention.

## Current state vs. target

The service is now **CVD-only** (BIOAGE removed) and is a **FastAPI microservice**
(`src/main.py` + `src/api/` + `src/calc/`). The original CLI batch (`src/calculator.py` +
`scripts/run_calculation.py`) has been **removed** (2026-06-02). Source of truth for scope/progress:
SPEC.md § "Объём работ" and the checklist in INTEGRATION_DECISIONS.md.

Done:

- ✅ **Wrapped in FastAPI** — `POST /api/v1/calculate` + `/health`/`/readiness`/`/liveness`, pydantic
  validation, errors in an envelope `{isSuccess, error:{code, message}}`. Layered like core.
- ✅ **Model cached in process memory** — loaded once in `lifespan` into `app.state.calculator`
  (the legacy per-request `joblib.load(...)` defect does not apply to the new path).
- ✅ **Explicit errors instead of silent `0.0`** — inference failure raises `CalculationError` → HTTP 422.
- ✅ **Concurrency knobs parameterized** — worker processes via `CVD_WORKERS` (default 1,
  `uvicorn --workers`) and an in-worker inference cap via `CVD_MAX_CONCURRENCY` (default 5,
  `asyncio.Semaphore`). The route is `async` and offloads the blocking inference with
  `run_in_threadpool`. Both tuned empirically under load; cap overflow waits (not dropped).
- ✅ **Logging ported 1:1 from core** (`src/logger.py`): Monolog-JSON, `business`/`notice`/`alert`/
  `emergency`, NOTICE+ in prod, fingers-crossed (INFO buffered, flushed on ERROR+), PII masking
  (incl. the 12 feature values — **never log biomarker values**), requestId/authorization auto-injected.
  Direct INFO calls are forbidden and caught by `make lint-logger` (`scripts/check_logger_info.py`,
  run alongside `ruff check` in `make lint`). Tests: `tests/test_logger.py`, `tests/scripts/test_check_logger_info.py`.
- ✅ **requestId + X-Enable-Debug** — middleware accepts/generates/echoes `X-Request-ID`, normalizes
  `X-Enable-Debug` to `"true"`/`""` at the trust boundary and gates DEBUG. Leaf service (no downstream
  calls yet); `with_request_context` is ready for background tasks.

Remaining planned work:

- **Imputation — decided: OFF by default** (2026-06-02). Core calls only when all data is present,
  so `/calculate` requires all 12 features **non-null** (`float`, not `float | None`; `null` is
  rejected by validation). Median imputation is left as a **commented-out hook** in
  `src/calc/domain/calculator.py` — enable it only if we decide some params may arrive empty (then
  switch the feature type to `float | None` and flag imputed fields in the response).
- **Mapping/adapter layer**: core parameter codes → model feature names + value re-encoding
  (sex / yes-no → 1/0). This belongs on the **core side** (adapter before calling `/calculate`),
  not in this service. For `FAM_IHD_CVA` the target param is `family_acute_cvd` (clarified), but
  it is **not yet described in analytics**.
Done (2026-06-02): **CI/CD** (`.gitlab-ci.yml`). Stage `checks` (ruff format/check + `lint-logger` +
**bandit** + pytest) on MR/any push; stage `deploy` on `develop` — SSH to the dev stand,
`git reset --hard origin/develop` + `docker compose up -d --build` (mirrors core). Repo is cloned on
the stand at `/home/sberuser/risk-profile-cvd` (git over SSH). Deploy mechanics verified by running the
exact deploy commands manually (container healthy on :8000). Two out-of-code prerequisites for full
automation: (1) set CI variables `SSH_PRIVATE_KEY` (file) + `SSH_KNOWN_HOSTS` in the cvd project —
copying core's key was blocked by policy, the owner sets them; (2) then a push to `develop` auto-deploys.
The project's CI runner is the shared one (id 1, same as core).

Done (2026-06-02): **docker-compose for local + dev stand**. cvd compose tags `risk-profile-cvd:latest`,
optional `.env` (`env_file required:false`), `.env.example`, `.dockerignore` (model NOT excluded).
Core compose extended with a `cvd` service under profile `cvd` (`docker compose --profile cvd up`) —
brought up alongside core, reachable in-network at `http://cvd:8000`. Image built & verified
(`docker build` exit 0, 553 MB; `/health`/`/calculate` OK, JSON logs, no sklearn warning).

Done (contract finalized 2026-06-02): `POST /api/v1/calculate` request `{period?, features{12 non-null}}`
→ response `{isSuccess, period, score, riskPercentage, calculatedAt}`; errors in envelope. Success
response subclasses `SuccessEnvelope` (symmetric to errors, core style). Full contract in
INTEGRATION_DECISIONS.md § "Контракт API (финал)".

## Commands

### Run the FastAPI service (primary)

```bash
uv venv --python 3.12 .venv && . .venv/bin/activate
uv pip install -e ".[dev]"
PYTHONPATH=. uvicorn src.main:app --reload --port 8000   # run from repo root so `src`/`utils` resolve
# probe: curl localhost:8000/health
# POST localhost:8000/api/v1/calculate  body: {"period":"Y5","features":{"AGE":..., "SEX":1, ... all 12 ...}}
```

`docker compose up --build` now starts the **service** (uvicorn, port `CVD_PORT`, default 8000),
not the old batch — tags `risk-profile-cvd:latest`, reads an optional `.env` (see `.env.example`).
Config is via env (prefix `CVD_`, e.g. `CVD_PORT`, `CVD_WORKERS`, `CVD_MAX_CONCURRENCY`,
`CVD_DEFAULT_PERIOD`; plus `LOG_LEVEL`). The model is baked into the image (`COPY src/`).

To run **alongside the core** (`risk-profile-core` repo), its compose has a `cvd` service under
profile `cvd`: `docker compose --profile cvd up -d --build` (build context defaults to the sibling
checkout `../../risk-profile-cvd`, override with `CVD_CONTEXT`). Core reaches it at `http://cvd:8000`.

> Note: the healthcheck lives in `docker-compose.yml`, not the Dockerfile — a bare `docker run`
> has no health status (the container still works; probe `/health` manually).

### Checks (mirror `risk-profile-core`)

```bash
make format       # ruff format .
make lint         # ruff check --fix  +  lint-logger  +  bandit
make lint-logger  # scripts/check_logger_info.py — forbids direct INFO-level logging
make test         # pytest
make checks       # format + lint + test (run before finishing work)
```

> `make lint-logger` is the custom logging guard ported from core: it fails CI if anyone uses
> `logger.info(...)` / `logging.info(...)` / `logger.log(logging.INFO|20, ...)` in `src/`/`scripts/`.
> Always-on INFO must go through `business(...)`; production-visible logs through `notice(...)`.

## Architecture

### FastAPI service (primary path)

Layered like `risk-profile-core` (api → domain → infra), DI via FastAPI `Depends()`:

- `src/main.py` — app + `lifespan` (loads all available period models once via
  `src/calc/infra/model_loader.load_models` into `app.state.calculator`), request middleware
  (`X-Request-ID`), health probes, exception handlers (envelope).
- `src/api/v1/calculation/router.py` — `POST /api/v1/calculate`, an **async** route that holds an
  `asyncio.Semaphore` (per-worker cap, `CVD_MAX_CONCURRENCY`) and offloads the blocking inference
  with `run_in_threadpool` (off the event loop). Request/response schemas in `schemas.py`
  (`{period, features}` → `{period, score, riskPercentage, calculatedAt}`).
- `src/calc/domain/calculator.py` — `CvdCalculator.calculate(period, features)`: builds a one-row
  DataFrame in exact `CVD_FEATURES` order → `predict_proba(...)[:,1]*100` → `table_to_risk_AIRI`.
  Failures raise `CalculationError` (→ HTTP 422). Feature names/periods in `src/calc/domain/consts.py`.
- `src/config.py` (pydantic-settings, prefix `CVD_`), `src/logger.py` (full Monolog-JSON logger
  ported from core: fingers-crossed, PII masking, business/notice channels, requestId).
- `src/calc/infra/model_loader.py` — loads `src/models/{Y5,Y2}_model.pkl` (via `joblib`) +
  `src/data/{Y5,Y2}_incidence.csv` (2-level header) once at startup. `table_to_risk_AIRI`
  (`utils/modeling.py`) maps the model score to a risk % by cubic interpolation over the incidence table.

### Gotchas

- **Feature names are exact and case/form-sensitive** and must match what the model was trained on,
  in order. CVD uses these 12 uppercase keys: `AGE`, `SEX`, `BMI`, `SBP`, `LPA`, `HDL_CHOL`,
  `LDL_CHOL`, `LIPID_DRUGS`, `AS`, `DM`, `FAM_IHD_CVA`, `FAM_HYPCHOL`. See the feature appendix in
  INTEGRATION_DECISIONS.md for units, medians, and core-catalog mappings.
- All feature values are **numeric**; categoricals (sex, yes/no) are pre-encoded as 1/0 (CVD `SEX`
  median is `1.0` — confirm which value means male).
- Imports are `from src.* import ...` and `from utils.modeling import ...`; run from the repo root
  (or with `PYTHONPATH=.`) so both `src` and the top-level `utils` package resolve. The Docker image
  sets `PYTHONPATH=/app`.
- **Model artifacts require custom classes to unpickle**: `src/models/*.pkl` are `BinaryStratifiedModel`
  wrapping `ClinicalLogisticRegression`, both defined in `utils/modeling.py`. They must be importable at
  load time or `joblib.load` fails — keep `utils/` shipped with the service (it's `COPY`'d into the image).
- **sklearn is pinned** to `==1.6.1` in `pyproject.toml` — the version the `*.pkl` models were
  trained on (otherwise `joblib.load` emits `InconsistentVersionWarning` and risks invalid results).
  Models are baked into the image and not versioned separately (decided 2026-06-02); update = rebuild.
  Note: an existing local `.venv` may still have a newer sklearn — re-sync it to load cleanly.
