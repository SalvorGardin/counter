"""Схемы эндпоинта расчёта риска ССЗ.

Контракт финализирован (см. «Контракт API (финал)» в INTEGRATION_DECISIONS.md). Клиент
(risk-profile-core) вызывает сервис, только когда собраны ВСЕ данные: все 12 фич обязательны
и **NOT NULL** (тип `float`, не `float | None` — pydantic отклонит `null` на входе).

Импутация пропусков медианой обучающей выборки сейчас **выключена**. Если решим, что часть
параметров может приходить пустой, её можно включить — см. закомментированный хук в
`src/calc/domain/calculator.py`; тогда тип фич здесь меняем на `float | None`.
"""

from datetime import datetime

from pydantic import Field, field_validator

from src.api.errors import SuccessEnvelope
from src.api.schemas import CamelModel
from src.calc.domain.consts import CVD_FEATURES, Period


class CalculateRequest(CamelModel):
    # Период модели; если не указан — берётся settings.default_period.
    period: Period | None = None
    # Значения фич по точным именам модели (см. CVD_FEATURES). Все 12 обязательны и NOT NULL.
    features: dict[str, float] = Field(description="Значения фич CVD-модели по точным именам (все 12, не null)")

    @field_validator("features")
    @classmethod
    def _validate_features(cls, v: dict[str, float]) -> dict[str, float]:
        missing = [f for f in CVD_FEATURES if f not in v]
        if missing:
            raise ValueError(f"missing features: {', '.join(missing)}")
        unknown = [k for k in v if k not in CVD_FEATURES]
        if unknown:
            raise ValueError(f"unknown features: {', '.join(unknown)}")
        return v


class CalculateResponse(SuccessEnvelope):
    # Наследует isSuccess=true от SuccessEnvelope — симметрично ErrorEnvelope, как в core.
    period: str
    score: float
    risk_percentage: float
    calculated_at: datetime
