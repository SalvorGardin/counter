"""Роутер расчёта риска ССЗ."""

import asyncio
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from starlette.concurrency import run_in_threadpool

from src.api.errors import common_responses
from src.api.v1.calculation.schemas import CalculateRequest, CalculateResponse
from src.calc.domain.calculator import CvdCalculator
from src.config import settings
from src.logger import business

router = APIRouter(prefix="/api/v1", tags=["calculation"])


def get_calculator(request: Request) -> CvdCalculator:
    """DI: калькулятор с резидентной моделью, поднятый в lifespan (app.state.calculator)."""
    return request.app.state.calculator


def get_semaphore(request: Request) -> asyncio.Semaphore:
    """DI: семафор-cap на одновременные инференсы внутри воркера (app.state.calc_semaphore)."""
    return request.app.state.calc_semaphore


# Async-эндпоинт: cap держим семафором, а блокирующий CPU-bound инференс уводим в threadpool
# (run_in_threadpool), чтобы event loop не вставал. Число воркеров и cap — конфигом (CVD_WORKERS,
# CVD_MAX_CONCURRENCY).
@router.post(
    "/calculate",
    response_model=CalculateResponse,
    responses=common_responses,
    summary="Рассчитать риск сердечно-сосудистых заболеваний",
)
async def post_calculate(
    payload: CalculateRequest,
    calculator: Annotated[CvdCalculator, Depends(get_calculator)],
    semaphore: Annotated[asyncio.Semaphore, Depends(get_semaphore)],
) -> CalculateResponse:
    period = payload.period or settings.default_period
    async with semaphore:
        result = await run_in_threadpool(calculator.calculate, period, payload.features)
    # PII не логируем — только факт и период (значения биомаркеров наружу не уходят).
    business("cvd.calculate: completed", {"period": result.period})
    return CalculateResponse(
        period=result.period,
        score=result.score,
        risk_percentage=result.risk_percentage,
        calculated_at=datetime.now(UTC),
    )
