"""Доменный сервис расчёта риска ССЗ.

Модель резидентна в памяти (загружена при старте) — на каждый запрос с диска ничего не читаем.
Сам инференс синхронный и CPU-bound; роутер вызывает его в threadpool (sync-эндпоинт FastAPI),
чтобы не блокировать event loop. Тонкая настройка конкуренности — отдельная задача.
"""

import pandas as pd

from src.calc.domain.consts import CVD_FEATURES
from src.calc.domain.exceptions import CalculationError
from src.calc.domain.models import CvdResult
from src.calc.infra.model_loader import LoadedModel
from utils.modeling import table_to_risk_AIRI


class CvdCalculator:
    def __init__(self, models: dict[str, LoadedModel]) -> None:
        self._models = models

    def supported_periods(self) -> list[str]:
        return sorted(self._models)

    def calculate(self, period: str, features: dict[str, float]) -> CvdResult:
        loaded = self._models.get(period)
        if loaded is None:
            raise CalculationError(f"unsupported period: {period!r}")

        try:
            row = {name: float(features[name]) for name in CVD_FEATURES}
        except KeyError as e:
            raise CalculationError(f"missing feature: {e.args[0]}") from e
        except (TypeError, ValueError) as e:
            raise CalculationError(f"non-numeric feature value: {e}") from e

        # --- Импутация медианой (ВЫКЛЮЧЕНА) ------------------------------------------------
        # Сейчас контракт требует все 12 фич non-null, поэтому подстановка не нужна.
        # Если решим разрешить null на входе (тип фич → float | None в схеме запроса),
        # включаем заполнение пропусков медианой обучающей выборки. Значения медиан — в
        # INTEGRATION_DECISIONS.md (приложение, колонка «Медиана»); их надо вынести в
        # константу/артефакт и прокинуть сюда. Пример:
        #
        #   row = {
        #       name: float(v) if (v := features.get(name)) is not None else _CVD_MEDIANS[name]
        #       for name in CVD_FEATURES
        #   }
        # -----------------------------------------------------------------------------------

        # Строка строго в порядке CVD_FEATURES — порядок важен для вложенных оценщиков.
        df = pd.DataFrame([row], columns=list(CVD_FEATURES))

        try:
            proba = loaded.model.predict_proba(df)[:, 1][0]
            score = float(proba) * 100.0
            risk = float(table_to_risk_AIRI(score, loaded.incidence))
        except Exception as e:
            raise CalculationError(f"model inference failed: {e}") from e

        return CvdResult(period=period, score=round(score, 1), risk_percentage=round(risk, 1))
