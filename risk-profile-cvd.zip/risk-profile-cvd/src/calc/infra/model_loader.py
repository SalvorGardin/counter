"""Загрузка артефактов модели с диска. Вызывается один раз при старте сервиса (lifespan).

Распаковка `*.pkl` требует, чтобы кастомные классы из `utils.modeling`
(`BinaryStratifiedModel`, `ClinicalLogisticRegression`) были импортируемы — иначе joblib упадёт.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import joblib
import pandas as pd

from src.calc.domain.consts import PERIOD_ARTIFACTS
from src.calc.domain.exceptions import CalculationError


@dataclass(frozen=True, slots=True)
class LoadedModel:
    """Модель периода + её таблица заболеваемости (score → риск %), резидентно в памяти."""

    model: Any
    incidence: pd.DataFrame


def load_models(models_dir: Path, data_dir: Path) -> dict[str, LoadedModel]:
    """Загрузить все периоды, для которых есть и файл модели, и таблица заболеваемости.

    Период без артефактов пропускается (например, окружение только с Y5). Если не нашлось
    ни одного — это ошибка конфигурации, поднимаем `CalculationError`.
    """
    loaded: dict[str, LoadedModel] = {}
    for period, (model_file, incidence_file) in PERIOD_ARTIFACTS.items():
        model_path = models_dir / model_file
        incidence_path = data_dir / incidence_file
        if not model_path.exists() or not incidence_path.exists():
            continue
        model = joblib.load(model_path)
        # Таблица заболеваемости с двухуровневым заголовком (как в baseline).
        incidence = pd.read_csv(incidence_path, index_col=0, header=[0, 1]).round(2)
        loaded[period] = LoadedModel(model=model, incidence=incidence)

    if not loaded:
        raise CalculationError(f"no CVD model artifacts found in {models_dir} / {data_dir}")
    return loaded
