"""Risk Profile CVD Service — FastAPI-обёртка вокруг ML-калькулятора риска ССЗ."""

import asyncio
import time
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.api.errors import (
    calculation_error_handler,
    http_exception_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from src.api.v1.calculation.router import router as calculation_router
from src.calc.domain.calculator import CvdCalculator
from src.calc.domain.exceptions import CalculationError
from src.calc.infra.model_loader import load_models
from src.config import settings
from src.logger import (
    FingersBuffer,
    authorization_var,
    debug_enabled_var,
    fingers_crossed_var,
    logger,
    notice,
    request_id_var,
    x_enable_debug_var,
)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Грузим модель один раз при старте и держим резидентно в app.state."""
    notice("service starting", {"default_period": settings.default_period})
    models = load_models(settings.models_dir, settings.data_dir)
    app.state.calculator = CvdCalculator(models)
    # Cap на одновременные инференсы внутри воркера — семафор создаётся в живом event loop.
    app.state.calc_semaphore = asyncio.Semaphore(settings.max_concurrency)
    notice(
        "models loaded",
        {
            "periods": app.state.calculator.supported_periods(),
            "max_concurrency": settings.max_concurrency,
        },
    )
    try:
        yield
    finally:
        notice("service stopping")


app = FastAPI(title="Risk Profile CVD Service", lifespan=lifespan)

app.add_exception_handler(RequestValidationError, validation_exception_handler)  # type: ignore[arg-type]
app.add_exception_handler(StarletteHTTPException, http_exception_handler)  # type: ignore[arg-type]
app.add_exception_handler(CalculationError, calculation_error_handler)  # type: ignore[arg-type]
app.add_exception_handler(Exception, unhandled_exception_handler)
app.include_router(calculation_router)

_PROBE_PATHS = {"/health", "/readiness", "/liveness", "/"}
_DEBUG_TRUTHY_VALUES = frozenset({"1", "true", "yes"})


def _is_debug_enabled(raw_header: str) -> bool:
    """Решение о debug-режиме на границе доверия. Принимаем только короткий whitelist truthy-значений
    — гейтит DEBUG локально и блокирует прокидку мусора в downstream."""
    return raw_header.lower() in _DEBUG_TRUTHY_VALUES


@app.middleware("http")
async def request_middleware(
    request: Request,
    call_next: Callable[[Request], Awaitable[Response]],
) -> Response:
    """Устанавливает request-контекст (requestId, authorization, debug, fingers-crossed)
    и логирует duration_ms каждого запроса."""
    req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    auth_raw = request.headers.get("Authorization")
    auth = f"{auth_raw.split(' ', 1)[0]} ***" if auth_raw else None
    debug = _is_debug_enabled(request.headers.get("X-Enable-Debug", ""))

    request_id_var.set(req_id)
    authorization_var.set(auth)
    debug_enabled_var.set(debug)
    # Нормализуем X-Enable-Debug на границе доверия: сырое значение наружу не уходит — downstream
    # получит детерминистский "true"/"" (cap длины, защита от инъекций в headers).
    x_enable_debug_var.set("true" if debug else "")
    # Fingers-crossed: per-request буфер INFO. ContextVar/try-finally изолируют буфер между
    # параллельными async-запросами и гарантируют сброс, даже если call_next бросит исключение.
    fc_token = fingers_crossed_var.set(FingersBuffer())

    try:
        logger.debug(
            "request started",
            extra={"log_context": {"method": request.method, "path": request.url.path}},
        )
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = round((time.perf_counter() - start) * 1000, 2)

        if request.url.path in _PROBE_PATHS:
            logger.debug(
                "probe request",
                extra={"log_context": {"path": request.url.path, "duration_ms": duration_ms}},
            )
        else:
            notice(
                "request completed",
                context={
                    "method": request.method,
                    "path": request.url.path,
                    "status_code": response.status_code,
                    "duration_ms": duration_ms,
                },
            )
        response.headers["X-Request-ID"] = req_id
        return response
    finally:
        fingers_crossed_var.reset(fc_token)


@app.get("/health")
def health() -> dict[str, str]:
    """Healthcheck."""
    return {"status": "ok"}


@app.get("/readiness")
def readiness() -> dict[str, str]:
    """Readiness probe."""
    return {"status": "ready"}


@app.get("/liveness")
def liveness() -> dict[str, str]:
    """Liveness probe."""
    return {"status": "alive"}


if __name__ == "__main__":
    # При workers > 1 uvicorn требует приложение строкой-импортом (форкает процессы сам).
    uvicorn.run(
        "src.main:app",
        host=settings.host,
        port=settings.port,
        workers=settings.workers,
    )
