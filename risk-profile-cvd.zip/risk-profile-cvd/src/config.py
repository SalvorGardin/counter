"""Конфигурация сервиса. Источник значений — окружение процесса (env_prefix `CVD_`).

Аналогично `risk-profile-core`: pydantic-settings, .env не читаем напрямую — переменные
инжектит compose (`env_file`) или разработчик локально (`set -a; . .env; set +a`).
"""

from pathlib import Path

from pydantic import Field, field_validator
from pydantic_core.core_schema import ValidationInfo
from pydantic_settings import BaseSettings, SettingsConfigDict

# Каталоги артефактов резолвятся относительно пакета `src`, а не cwd — сервис стартует одинаково
# из любой рабочей директории (uvicorn, docker, pytest).
_SRC_DIR = Path(__file__).resolve().parent
_DEFAULT_MODELS_DIR = _SRC_DIR / "models"
_DEFAULT_DATA_DIR = _SRC_DIR / "data"

_LOG_LEVELS = {"DEBUG", "INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL"}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="CVD_",
        env_nested_delimiter="__",
        extra="ignore",
        validate_default=True,
    )

    host: str = "127.0.0.1"
    port: int = 8000

    # Число воркеров-процессов uvicorn. По умолчанию 1; в проде задаётся по числу ядер пода
    # (модель резидентна в памяти каждого воркера — см. INTEGRATION_DECISIONS.md, п. «Воркеры/конкурентность»).
    workers: int = 1

    # Cap на одновременные инференсы ВНУТРИ одного воркера (семафор). Инференс CPU-bound,
    # поэтому осмысленное значение невелико; дефолт 5, подбирается под нагрузкой.
    max_concurrency: int = 5

    # Период модели по умолчанию, если клиент не указал явно. Поддерживаются "Y5" и "Y2".
    default_period: str = "Y5"

    models_dir: Path = _DEFAULT_MODELS_DIR
    data_dir: Path = _DEFAULT_DATA_DIR

    # Универсальное имя переменной для всех сервисов инфраструктуры (как в core) — без префикса CVD_.
    log_level: str = Field(default="NOTICE", validation_alias="LOG_LEVEL")

    @field_validator("workers", "max_concurrency")
    @classmethod
    def _validate_positive(cls, v: int, info: ValidationInfo) -> int:
        if v < 1:
            raise ValueError(f"{info.field_name} must be >= 1, got {v}")
        return v

    @field_validator("default_period")
    @classmethod
    def _validate_period(cls, v: str) -> str:
        if v not in {"Y5", "Y2"}:
            raise ValueError(f"default_period must be one of ['Y2', 'Y5'], got {v!r}")
        return v

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, v: str) -> str:
        if v.upper() not in _LOG_LEVELS:
            raise ValueError(f"log_level must be one of {sorted(_LOG_LEVELS)}, got {v!r}")
        return v.upper()


settings = Settings()
