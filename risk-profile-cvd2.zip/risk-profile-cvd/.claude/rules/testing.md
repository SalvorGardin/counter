# Testing

- Фреймворк: pytest, без альтернатив
- HTTP-слой тестируется через `TestClient` поверх `src.main:app`
- Подмена зависимостей в тестах — через `app.dependency_overrides` (FastAPI DI override), а не через `mock.patch`
- Router-тесты могут подменять калькулятор и семафор через `dependency_overrides` (`get_calculator`,
  `get_semaphore`) и не запускать `lifespan` — так проверяется HTTP-контракт. Сам расчёт так не проверяется:
  модели (`src/models/*.pkl`) лежат в репозитории, и корректность `score`/`riskPercentage` проверяется на реальной
  модели, а не на заглушке `predict_proba`
- Структура: тесты в `tests/` (`test_<модуль>.py`), тесты скриптов — в `tests/scripts/`; JSON-фикстуры —
  в `tests/test_data/`. Общие фикстуры — в `conftest.py` соответствующего уровня
- Ожидаемый `output` в `tests/test_data/input_cvd.json` устарел — не использовать как эталон для assert
