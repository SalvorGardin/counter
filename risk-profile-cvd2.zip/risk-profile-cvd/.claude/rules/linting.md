# Статический анализ и линтинг

- Форматирование кода и сортировка импортов: `ruff format` (`make format`)
- Линтинг: `ruff check` (`make lint-ruff`)
- Запрет прямых INFO-логов: `make lint-logger` (`scripts/check_logger_info.py`) — в `src/` и `scripts/`
  нельзя `logger.info(...)` / `logging.info(...)` / `logger.log(logging.INFO, ...)`
- SAST: `bandit -r src scripts -c pyproject.toml` (`make lint-bandit`)
- `make lint` = ruff + lint-logger + bandit; `make checks` = format + lint + pytest — прогонять перед завершением работы,
  то же самое запускает стадия `checks` в `.gitlab-ci.yml`
- Максимальная длина строки: 120 символов (секция `[tool.ruff]` в `pyproject.toml`)
- Легаси CLI (`src/calculator.py`, `scripts/run_calculation.py`) содержит старые ошибки ruff и идёт под удаление —
  новые замечания к нему не предъявляются, но и нового кода туда не добавляем
