# API Conventions

- Точка входа — `src/main.py`, подключение роутеров через `include_router`
- Роутеры группируются по доменным областям: `src/api/v1/{domain}/router.py`, схемы — рядом в `schemas.py`
- Десериализация — встроенная через Pydantic, не писать ручной парсинг
- Версионирование API через prefix: `/api/v1/`, `/api/v2/`
- Middleware добавлять в `src/main.py`
- Конфигурация приложения — pydantic-settings (`src/config.py`), загрузка из env / .env файла
- Response-модели указывать явно в декораторе роута: `response_model=SomeSchema`
- Ответы — в конверте: успех наследует `SuccessEnvelope`, ошибка — `{isSuccess: false, error: {code, message}}`;
  поля в JSON — camelCase
- Контракт `POST /api/v1/calculate` потребляет `risk-profile-core`; его каноническое описание —
  `INTEGRATION_DECISIONS.md`, раздел «Контракт API (финал)». Любое изменение формы запроса/ответа
  согласуется с клиентом в core и отражается там
