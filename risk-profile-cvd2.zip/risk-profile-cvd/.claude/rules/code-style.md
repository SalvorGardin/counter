# Code Style

- CamelCase для классов, snake_case для всего остального (функции, переменные, модули)
- Type hints обязательны для всех публичных функций и методов
- Async-first: использовать async def по умолчанию, sync — только если нет async-альтернативы.
  Блокирующий CPU-bound инференс (`predict_proba`) вызывается из async-роута через `run_in_threadpool`,
  а не напрямую в event loop
- Маппинг между слоями — вручную через конструктор или classmethod-фабрику, без библиотек маппинга
  (пример: `CvdRiskFactors.to_model_row()`)
- Pydantic-модели для всех входных/выходных данных API
- Строки — double quotes
- Максимальная длина строки — 120 символов
