---
name: pr-review
description: Use when asked to review a merge request or pull request — launches the pr-review-orchestrator agent which dispatches specialized lens agents, deduplicates findings, and posts inline comments to GitLab. Accepts an optional MR number argument.
---

# pr-review

Orchestrates a full multi-agent code review of a GitLab MR by delegating to the `pr-review-orchestrator` agent.

## Usage

```
/pr-review [MR_NUMBER]
```

- With MR number: `/pr-review 293` — reviews the specified MR
- Without argument: reviews the MR for the current branch (if one exists)

## Instructions

1. Parse the MR number from `args` (may be empty).
2. Invoke the `pr-review-orchestrator` agent via the Agent tool with:
   - If an MR number was provided: include `"Review MR <number>"` in the prompt
   - If no MR number was provided: include `"Review the MR for the current branch"` in the prompt
3. The orchestrator handles everything else: fetching the diff, dispatching lens agents, deduplication, ranking, and posting inline comments.

## Example prompt to pass to the agent

```
Review MR 293 on gitlab.tywys.ru project risk-profile/risk-profile-cvd. Run all relevant lens agents, deduplicate findings, and post only 🔴 serious and ⚠️ medium inline comments.
```
