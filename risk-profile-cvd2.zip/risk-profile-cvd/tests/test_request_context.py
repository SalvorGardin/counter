"""HTTP-контракт: корреляция/приватность ошибок и независимый oracle реальной модели."""

import asyncio
import io
import json
import logging
from collections.abc import AsyncIterator, Iterator
from uuid import UUID

import httpx2 as httpx
import joblib
import pandas as pd
import pytest
from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import StreamingResponse
from fastapi.testclient import TestClient
from starlette.concurrency import run_in_threadpool

from src import logger as logmod
from src.api.errors import unhandled_exception_handler
from src.api.request_context import RequestContextMiddleware
from src.calc.domain.consts import PERIOD_ARTIFACTS
from src.config import settings
from src.main import app as calculation_app
from utils.modeling import table_to_risk_AIRI


@pytest.fixture
def log_output(monkeypatch: pytest.MonkeyPatch) -> Iterator[io.StringIO]:
    output = io.StringIO()
    stream = logging.StreamHandler(output)
    stream.setFormatter(logmod.MonologFormatter())
    handler = logmod.FingersCrossedHandler(stream)
    handler.addFilter(logmod.MonologFilter())
    monkeypatch.setattr(logmod.logger, "handlers", [handler])
    yield output


def _app() -> FastAPI:
    app = FastAPI()
    app.add_exception_handler(Exception, unhandled_exception_handler)
    app.add_middleware(RequestContextMiddleware, probe_paths={"/health"})
    return app


def _logs(output: io.StringIO) -> list[dict]:
    return [json.loads(line) for line in output.getvalue().splitlines()]


def test_parallel_requests_keep_debug_and_thread_logs_isolated(log_output: io.StringIO) -> None:
    app = _app()

    @app.get("/context")
    async def context(request: Request) -> dict:
        await asyncio.sleep(0)

        def from_thread() -> dict:
            logmod.business("thread observation")
            logmod.logger.debug("debug observation")
            return {
                "id": logmod.request_id_var.get(),
                "authorization": logmod.authorization_var.get(),
                "debug": logmod.debug_enabled_var.get(),
                "debugHeader": logmod.x_enable_debug_var.get(),
            }

        return await run_in_threadpool(from_thread)

    async def exercise() -> list[httpx.Response]:
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://test") as client:
            return await asyncio.gather(
                client.get(
                    "/context",
                    headers={"X-Request-ID": "first", "Authorization": "Bearer SECRET", "X-Enable-Debug": "YeS"},
                ),
                client.get("/context", headers={"X-Request-ID": "second", "X-Enable-Debug": "false"}),
            )

    first, second = asyncio.run(exercise())
    assert first.json() == {"id": "first", "authorization": "Bearer ***", "debug": True, "debugHeader": "true"}
    assert second.json() == {"id": "second", "authorization": None, "debug": False, "debugHeader": ""}
    assert first.headers["X-Request-ID"] == "first"
    assert second.headers["X-Request-ID"] == "second"
    records = _logs(log_output)
    assert {record["extra"]["requestId"] for record in records if record["message"] == "thread observation"} == {
        "first",
        "second",
    }
    assert {record["extra"]["requestId"] for record in records if record["message"] == "debug observation"} == {"first"}
    assert "SECRET" not in log_output.getvalue()


def test_generated_request_id_and_context_restore_after_response(log_output: io.StringIO) -> None:
    app = _app()

    @app.get("/context")
    async def context() -> dict[str, str]:
        return {"id": logmod.request_id_var.get()}

    async def exercise() -> None:
        previous_buffer = logmod.FingersBuffer()
        previous_values = (
            (logmod.request_id_var, "outer"),
            (logmod.authorization_var, "outer authorization"),
            (logmod.debug_enabled_var, True),
            (logmod.x_enable_debug_var, "outer debug"),
            (logmod.fingers_crossed_var, previous_buffer),
        )
        tokens = [(variable, variable.set(value)) for variable, value in previous_values]
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://test") as client:
                response = await client.get("/context", headers={"X-Enable-Debug": "untrusted"})
            req_id = response.headers["X-Request-ID"]
            UUID(req_id)
            assert response.json() == {"id": req_id}
            assert [(variable, variable.get()) for variable, _ in previous_values] == list(previous_values)
            assert all(record["extra"]["requestId"] == req_id for record in _logs(log_output))
        finally:
            for variable, token in reversed(tokens):
                variable.reset(token)

    asyncio.run(exercise())


def test_unhandled_error_keeps_request_id_and_fingers_crossed_diagnostics(log_output: io.StringIO) -> None:
    app = _app()

    @app.get("/fail")
    async def fail() -> None:
        logmod.logger.info("diagnostic before failure")
        raise RuntimeError("synthetic error")

    with TestClient(app, raise_server_exceptions=False) as client:
        response = client.get("/fail", headers={"X-Request-ID": "failed-request"})

    assert response.status_code == 500
    assert response.headers["X-Request-ID"] == "failed-request"
    assert response.json() == {
        "isSuccess": False,
        "error": {"code": "INTERNAL_ERROR", "message": "Internal server error"},
    }
    records = _logs(log_output)
    assert {record["extra"]["requestId"] for record in records} == {"failed-request"}
    assert any(record["message"] == "diagnostic before failure" for record in records)
    assert "synthetic error" not in response.text


@pytest.mark.parametrize(
    ("raw", "kept"),
    [
        ("3fa85f64-5717-4562-b3fc-2c963f66afa6", True),
        ("calc.Y5_retry-2", True),
        ("r" * 64, True),
        ("r" * 65, False),
        ("has space", False),
        ("id;drop", False),
        ("", False),
    ],
)
def test_request_id_accepted_only_if_short_and_safe(raw: str, kept: bool, log_output: io.StringIO) -> None:
    """X-Request-ID принимается, только если это 1–64 символа из [A-Za-z0-9._-]; иначе запрос получает
    сгенерированный UUID. Принятое или сгенерированное значение — одно и то же в контексте запроса, в
    заголовке ответа и в записях лога."""
    app = _app()

    @app.get("/context")
    async def context() -> dict[str, str]:
        return {"id": logmod.request_id_var.get()}

    with TestClient(app) as client:
        response = client.get("/context", headers={"X-Request-ID": raw})

    req_id = response.headers["X-Request-ID"]
    if kept:
        assert req_id == raw
    else:
        UUID(req_id)
    assert response.json() == {"id": req_id}
    assert {record["extra"]["requestId"] for record in _logs(log_output)} == {req_id}


def test_error_after_response_start_is_logged(log_output: io.StringIO) -> None:
    """Исключение после начала ответа (тело отдаётся потоком) оставляет запись ERROR `request aborted after
    response start` с методом, путём, начатым статусом, requestId и traceback; ответ при этом обрывается."""
    app = _app()

    @app.get("/stream")
    async def stream() -> StreamingResponse:
        async def body() -> AsyncIterator[bytes]:
            yield b"partial"
            raise RuntimeError("stream failure")

        return StreamingResponse(body())

    with TestClient(app, raise_server_exceptions=False) as client:
        client.get("/stream", headers={"X-Request-ID": "aborted-request"})

    aborted = [record for record in _logs(log_output) if record["message"] == "request aborted after response start"]
    assert len(aborted) == 1
    assert aborted[0]["level_name"] == "ERROR"
    assert aborted[0]["extra"]["requestId"] == "aborted-request"
    assert {key: aborted[0]["context"][key] for key in ("method", "path", "status_code")} == {
        "method": "GET",
        "path": "/stream",
        "status_code": 200,
    }
    assert "RuntimeError: stream failure" in aborted[0]["context"]["exception"]


def test_non_http_application_lifecycle_passes_through(log_output: io.StringIO) -> None:
    app = _app()

    @app.websocket("/socket")
    async def socket(websocket: WebSocket) -> None:
        await websocket.accept()
        await websocket.send_text("connected")
        await websocket.close()

    with TestClient(app) as client:
        with client.websocket_connect("/socket") as socket:
            assert socket.receive_text() == "connected"
    assert log_output.getvalue() == ""


def _risk_factors(sex: float = 1.0) -> dict[str, float]:
    return {
        "famHypchol": 1.0,
        "ldlChol": 4.9,
        "age": 47.0,
        "lipidDrugs": 0.0,
        "hdlChol": 1.7,
        "sex": sex,
        "bmi": 31.3,
        "systolicBp": 173.0,
        "atherosclerosis": 1.0,
        "diabetes": 0.0,
        "lipoproteinA": 73.0,
        "famIhdCva": 0.0,
    }


@pytest.mark.parametrize("period", ["Y2", "Y5"])
@pytest.mark.parametrize("sex", [0.0, 1.0])
def test_real_http_input_matches_original_model_feature_mapping(
    period: str, sex: float, log_output: io.StringIO
) -> None:
    # Результат HTTP сверяется с исходным DataFrame/Pipeline, независимо от нового row-adapter.
    # Перестановку полей с равными значениями (бинарные 0.0) и после округления до 0.1 этот
    # тест не различит — позицию каждого поля закрепляет
    # test_to_model_values_puts_each_field_at_its_feature_position.
    payload = _risk_factors(sex)
    oracle_features = {
        "AGE": 47.0,
        "SEX": sex,
        "BMI": 31.3,
        "SBP": 173.0,
        "LPA": 73.0,
        "HDL_CHOL": 1.7,
        "LDL_CHOL": 4.9,
        "LIPID_DRUGS": 0.0,
        "AS": 1.0,
        "DM": 0.0,
        "FAM_IHD_CVA": 0.0,
        "FAM_HYPCHOL": 1.0,
    }
    with TestClient(calculation_app) as client:
        model_file, incidence_file = PERIOD_ARTIFACTS[period]
        original_model = joblib.load(settings.models_dir / model_file)
        original_incidence = pd.read_csv(settings.data_dir / incidence_file, index_col=0, header=[0, 1]).round(2)
        raw_score = float(original_model.predict_proba(pd.DataFrame([oracle_features]))[0, 1]) * 100
        raw_risk = float(table_to_risk_AIRI(raw_score, original_incidence))
        response = client.post(
            "/api/v1/calculate",
            json={"period": period, "riskFactors": payload},
            headers={"X-Request-ID": "real-calculation"},
        )
    assert response.status_code == 200
    body = response.json()
    assert body["period"] == period
    assert body["score"] == round(raw_score, 1)
    assert body["riskPercentage"] == round(raw_risk, 1)
    completion = next(record for record in _logs(log_output) if record["message"] == "request completed")
    assert completion["extra"]["requestId"] == "real-calculation"
    assert set(completion["context"]) == {
        "method",
        "path",
        "status_code",
        "duration_ms",
        "http_duration_ms",
        "period",
        "calc_semaphore_wait_ms",
        "calc_thread_wait_ms",
        "calc_duration_ms",
    }
    for key in ("duration_ms", "http_duration_ms", "calc_semaphore_wait_ms", "calc_thread_wait_ms", "calc_duration_ms"):
        assert completion["context"][key] >= 0


@pytest.mark.parametrize(("field", "value"), [("lipoproteinA", float("inf"))])
def test_model_rejection_logs_no_biomarker_values(field: str, value: float, log_output: io.StringIO) -> None:
    # Дробный пол сюда не доходит: категориальные признаки принимают только 0 или 1 на границе (400).
    payload = {**_risk_factors(), field: value}
    with TestClient(calculation_app) as client:
        response = client.post(
            "/api/v1/calculate",
            content=json.dumps({"period": "Y5", "riskFactors": payload}),
            headers={"Content-Type": "application/json", "X-Request-ID": "rejected-calculation"},
        )
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "CALCULATION_FAILED"
    assert response.headers["X-Request-ID"] == "rejected-calculation"
    error = next(record for record in _logs(log_output) if record["message"] == "calculation failed")
    assert error["extra"]["requestId"] == "rejected-calculation"
    assert str(value) not in error["context"]["reason"]
