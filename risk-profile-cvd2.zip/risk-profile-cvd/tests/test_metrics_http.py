"""HTTP-гистограмма входящих запросов: наблюдения, статусы и допустимые значения лейблов.

Гистограмма общая для всего процесса тестов, поэтому проверки строятся на приращениях значений до и
после запроса. Лейблы — поверхность открытой ручки /metrics: значения обязаны браться из
ограниченного набора и никогда из данных запроса.
"""

import logging
import socket
import time
from collections.abc import Callable
from typing import NoReturn

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from prometheus_client import REGISTRY
from prometheus_client.parser import text_string_to_metric_families

import src.api.middleware as middleware_module
import src.api.request_context as request_context_module
from src.api.middleware import MetricsMiddleware
from src.calc.domain.exceptions import CalculationError
from src.metrics import render

_METRIC = "risk_profile_cvd_http_request_duration_seconds"


def _sample(suffix: str, labels: dict[str, str]) -> float:
    value = REGISTRY.get_sample_value(f"{_METRIC}{suffix}", labels)
    return 0.0 if value is None else value


def _total_count() -> float:
    """Сумма `_count` по всем рядам гистограммы — число учтённых запросов."""
    return sum(
        sample.value
        for family in REGISTRY.collect()
        if family.name == _METRIC
        for sample in family.samples
        if sample.name == f"{_METRIC}_count"
    )


def _path_label_values() -> set[str]:
    return {
        sample.labels["path"]
        for family in REGISTRY.collect()
        if family.name == _METRIC
        for sample in family.samples
        if sample.name == f"{_METRIC}_count"
    }


def _labels(method: str, path: str, status: str) -> dict[str, str]:
    return {"method": method, "path": path, "status": status, "host": socket.gethostname()}


@pytest.mark.parametrize(
    ("method", "path", "body_kind", "calculator_error", "http_status", "status_label", "path_label"),
    [
        pytest.param("POST", "/api/v1/calculate", "valid", None, 200, "200", "/api/v1/calculate", id="200"),
        pytest.param("POST", "/api/v1/calculate", "invalid", None, 400, "400", "/api/v1/calculate", id="400"),
        pytest.param("POST", "/api/v1/calculate", "valid", CalculationError, 422, "422", "/api/v1/calculate", id="422"),
        pytest.param("GET", "/api/v1/calculate", None, None, 405, "405", "/api/v1/calculate", id="405"),
        pytest.param("GET", "/no-such/route", None, None, 404, "404", "unmatched", id="404"),
        pytest.param(
            "POST", "/api/v1/calculate", "valid", RuntimeError, 500, "500", "/api/v1/calculate", id="500-exception"
        ),
    ],
)
def test_request_observed_once_with_actual_status(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
    method: str,
    path: str,
    body_kind: str | None,
    calculator_error: type[Exception] | None,
    http_status: int,
    status_label: str,
    path_label: str,
) -> None:
    """Запрос даёт ровно одно наблюдение в ряду со своим статусом: `_count` и корзина `+Inf` ряда
    растут на 1, `_sum` растёт, `host` — имя хоста, а суммарный `_count` всех рядов растёт ровно на 1.
    Необработанное исключение калькулятора (клиент получает 500) учитывается со `status="500"`."""
    client = make_client(calculator_error, raise_server_exceptions=False)
    labels = _labels(method, path_label, status_label)
    count_before = _sample("_count", labels)
    inf_before = _sample("_bucket", {**labels, "le": "+Inf"})
    sum_before = _sample("_sum", labels)
    total_before = _total_count()
    bodies = {
        "valid": {"period": "Y5", "riskFactors": valid_risk_factors},
        "invalid": {"period": "Y5", "riskFactors": {**valid_risk_factors, "sex": 99}},
    }

    response = client.request(method, path, json=bodies[body_kind] if body_kind else None)

    assert response.status_code == http_status
    assert _sample("_count", labels) == count_before + 1
    assert _sample("_bucket", {**labels, "le": "+Inf"}) == inf_before + 1
    assert _sample("_sum", labels) > sum_before
    assert _total_count() == total_before + 1


@pytest.mark.parametrize("path", ["/", "/health", "/readiness", "/liveness", "/metrics"])
def test_probe_and_scrape_paths_not_observed(make_client: Callable[..., TestClient], path: str) -> None:
    """Пробы и скрейп `/metrics` не меняют суммарный `_count` гистограммы."""
    client = make_client()
    total_before = _total_count()

    client.get(path)

    assert _total_count() == total_before


def test_unknown_paths_and_methods_collapse_into_two_series(make_client: Callable[..., TestClient]) -> None:
    """15 запросов на 15 разных несуществующих путей методами GET, PROPFIND и методом из 80 символов
    ложатся ровно в два ряда: `GET`/`unmatched`/`404` (+5) и `other`/`unmatched`/`404` (+10) —
    суммарный `_count` вырос на 15, других рядов эти запросы не дали."""
    client = make_client()
    get_labels = _labels("GET", "unmatched", "404")
    other_labels = _labels("other", "unmatched", "404")
    get_before = _sample("_count", get_labels)
    other_before = _sample("_count", other_labels)
    total_before = _total_count()

    for method in ("GET", "PROPFIND", "M" * 80):
        for i in range(5):
            assert client.request(method, f"/no-such/{method[:8]}/{i}/leaf").status_code == 404

    assert _sample("_count", get_labels) == get_before + 5
    assert _sample("_count", other_labels) == other_before + 10
    assert _total_count() == total_before + 15


def test_request_data_never_reaches_exposition(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
) -> None:
    """Значения из хвоста пути, query-строки, тела и заголовка `Host` не встречаются в выдаче,
    а `host` всех рядов — имя хоста сервиса, а не заголовок клиента."""
    client = make_client()
    body = {"period": "Y5", "riskFactors": {**valid_risk_factors, "lipoproteinA": 31.7315}}
    headers = {"Host": "host-marker-315"}

    assert client.post("/api/v1/calculate?trace=query-marker-315", json=body, headers=headers).status_code == 200
    assert client.post("/api/v1/calculate/tail-marker-315", json=body, headers=headers).status_code == 404

    exposition = render().decode()
    for marker in ("tail-marker-315", "query-marker-315", "host-marker-315", "31.7315"):
        assert marker not in exposition
    hosts = {
        sample.labels["host"] for family in text_string_to_metric_families(exposition) for sample in family.samples
    }
    assert hosts == {socket.gethostname()}


@pytest.mark.parametrize("path", ["/docs", "/openapi.json"])
def test_hidden_routes_labeled_other(make_client: Callable[..., TestClient], path: str) -> None:
    """Служебные маршруты, скрытые из схемы API, учитываются с `path="other"`; их путь лейблом не становится."""
    client = make_client()
    labels = _labels("GET", "other", "200")
    count_before = _sample("_count", labels)

    assert client.get(path).status_code == 200

    assert _sample("_count", labels) == count_before + 1
    assert path not in _path_label_values()


def test_parameterized_route_labeled_with_template() -> None:
    """Маршрут с параметром пути учитывается шаблоном `/items/{item_id}`, значение из URL в выдачу не попадает."""
    test_app = FastAPI()

    @test_app.get("/items/{item_id}")
    def read_item(item_id: str) -> dict[str, str]:
        return {"item": item_id}

    test_app.add_middleware(MetricsMiddleware, probe_paths=frozenset())
    labels = _labels("GET", "/items/{item_id}", "200")
    count_before = _sample("_count", labels)

    assert TestClient(test_app).get("/items/value-marker-315").status_code == 200

    assert _sample("_count", labels) == count_before + 1
    assert "value-marker-315" not in render().decode()


def test_duration_includes_request_logging(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Наблюдение заканчивается, когда приложение закончило обработку запроса. Запись `request completed`
    в `RequestContextMiddleware` (она выводится после отправки тела ответа) подменена на запись с задержкой
    0.2 с — эта задержка входит в наблюдение: `_sum` ряда расчёта вырос не меньше чем на 0.2 с. Наблюдение,
    законченное на заголовках ответа или на последнем фрагменте тела, задержку бы не включило."""
    real_notice = request_context_module.notice

    def slow_notice(message: str, context: dict[str, object] | None = None) -> None:
        time.sleep(0.2)
        real_notice(message, context)

    monkeypatch.setattr(request_context_module, "notice", slow_notice)
    client = make_client()
    labels = _labels("POST", "/api/v1/calculate", "200")
    sum_before = _sample("_sum", labels)

    assert client.post("/api/v1/calculate", json={"riskFactors": valid_risk_factors}).status_code == 200

    assert _sample("_sum", labels) - sum_before >= 0.2


class _UnwritableHistogram:
    """Гистограмма, запись в которую падает, как при сбое файла значений в multiprocess-режиме."""

    def labels(self, **_labels: str) -> NoReturn:
        raise FileNotFoundError(2, "No such file or directory")


def test_failed_observation_keeps_successful_response(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
    monkeypatch: pytest.MonkeyPatch,
    app_log_records: list[logging.LogRecord],
) -> None:
    """Запись наблюдения падает с OSError: клиент получает 200 с результатом расчёта, исключение из
    приложения не выходит (клиент теста пробросил бы его), а сбой записан в лог одной записью ERROR
    `metrics observation failed` с исключением."""
    monkeypatch.setattr(middleware_module, "HTTP_REQUEST_DURATION", _UnwritableHistogram())
    client = make_client()

    response = client.post("/api/v1/calculate", json={"riskFactors": valid_risk_factors})

    assert response.status_code == 200
    assert response.json()["riskPercentage"] == 45.6
    failures = [record for record in app_log_records if record.getMessage() == "metrics observation failed"]
    assert len(failures) == 1
    assert failures[0].levelno == logging.ERROR
    assert failures[0].exc_info is not None
    assert isinstance(failures[0].exc_info[1], OSError)


def _app_failing_before_response() -> FastAPI:
    """Приложение только с мидлварью метрик: `GET /fail` бросает RuntimeError до начала ответа.

    В сервисе такую ошибку RequestContextMiddleware превращает в 500-ответ сама, и мидлварь метрик видит
    обычный ответ. Здесь исключение выходит из приложения через мидлварь метрик — так проверяется её ветка
    исключения: в сервисе туда попадает исключение, вышедшее из RequestContextMiddleware.
    """
    test_app = FastAPI()

    @test_app.get("/fail")
    def fail() -> None:
        raise RuntimeError("handler failure")

    test_app.add_middleware(MetricsMiddleware, probe_paths=frozenset())
    return test_app


def test_exception_escaping_app_observed_once_as_500() -> None:
    """Исключение, вышедшее из приложения до начала ответа, учтено одним наблюдением со `status="500"`:
    `_count` ряда `/fail` и суммарный `_count` выросли ровно на 1."""
    labels = _labels("GET", "/fail", "500")
    count_before = _sample("_count", labels)
    total_before = _total_count()

    response = TestClient(_app_failing_before_response(), raise_server_exceptions=False).get("/fail")

    assert response.status_code == 500
    assert _sample("_count", labels) == count_before + 1
    assert _total_count() == total_before + 1


def test_failed_observation_keeps_original_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    """Из приложения выходит RuntimeError обработчика, и запись наблюдения тоже падает: наружу выходит
    исходное RuntimeError — ошибка записи метрики его не подменяет."""
    monkeypatch.setattr(middleware_module, "HTTP_REQUEST_DURATION", _UnwritableHistogram())
    client = TestClient(_app_failing_before_response())

    with pytest.raises(RuntimeError, match="handler failure"):
        client.get("/fail")
