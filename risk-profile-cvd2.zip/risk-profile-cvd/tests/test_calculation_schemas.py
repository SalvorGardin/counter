"""Тесты контракта запроса /api/v1/calculate: объект `riskFactors` вместо мапы фич.

Чистый слой pydantic — модель не грузим (быстро, без артефактов). Проверяем валидацию
(обязательность/non-null/лишние поля) и маппинг полей объекта в строку фич модели.
"""

import pytest
from pydantic import ValidationError

from src.api.v1.calculation.schemas import CalculateRequest, CvdRiskFactors
from src.calc.domain.consts import CVD_FEATURES

# Валидный объект факторов риска (camelCase, как на проводе от core).
_VALID: dict[str, float] = {
    "age": 63,
    "sex": 1,
    "bmi": 27.4,
    "systolicBp": 145,
    "lipoproteinA": 30,
    "hdlChol": 1.1,
    "ldlChol": 3.6,
    "lipidDrugs": 0,
    "atherosclerosis": 0,
    "diabetes": 0,
    "famIhdCva": 1,
    "famHypchol": 0,
}


def test_valid_request_parses_with_optional_period():
    req = CalculateRequest.model_validate({"riskFactors": _VALID})
    assert req.period is None
    assert isinstance(req.risk_factors, CvdRiskFactors)

    req_with_period = CalculateRequest.model_validate({"period": "Y2", "riskFactors": _VALID})
    assert req_with_period.period == "Y2"


# Контракт API: поле `riskFactors` (имя на проводе от core) → признак модели. Таблица записана
# независимо от CvdRiskFactors._FIELD_TO_FEATURE, чтобы тест ловил и ошибку в самом соответствии.
_WIRE_FIELD_TO_FEATURE = {
    "age": "AGE",
    "sex": "SEX",
    "bmi": "BMI",
    "systolicBp": "SBP",
    "lipoproteinA": "LPA",
    "hdlChol": "HDL_CHOL",
    "ldlChol": "LDL_CHOL",
    "lipidDrugs": "LIPID_DRUGS",
    "atherosclerosis": "AS",
    "diabetes": "DM",
    "famIhdCva": "FAM_IHD_CVA",
    "famHypchol": "FAM_HYPCHOL",
}
_BINARY_FIELDS = frozenset({"sex", "lipidDrugs", "atherosclerosis", "diabetes", "famIhdCva", "famHypchol"})
# Непрерывные поля — попарно разные значения, ни одно не равно 0, 1 или отметке ниже.
_CONTINUOUS = {"age": 63.0, "bmi": 27.4, "systolicBp": 145.0, "lipoproteinA": 30.0, "hdlChol": 1.1, "ldlChol": 3.6}


@pytest.mark.parametrize(("field", "feature"), list(_WIRE_FIELD_TO_FEATURE.items()))
def test_to_model_values_puts_each_field_at_its_feature_position(field: str, feature: str):
    """Поле `riskFactors` попадает в позицию своего признака в CVD_FEATURES. Отмечаемое поле получает значение,
    которого нет ни в одном другом поле (бинарное — 1.0 при остальных бинарных 0.0, непрерывное — 77.7),
    поэтому любая перестановка полей, включая равные по значению бинарные, сдвигает отметку. Округление
    HTTP-риска такую перестановку может скрыть, поэтому контракт проверяется на численном входе модели."""
    marker = 1.0 if field in _BINARY_FIELDS else 77.7
    values = {name: 0.0 for name in _BINARY_FIELDS} | _CONTINUOUS | {field: marker}

    row = CvdRiskFactors.model_validate(values).to_model_values()

    assert [index for index, value in enumerate(row) if value == marker] == [CVD_FEATURES.index(feature)]
    assert all(isinstance(value, float) for value in row)


def test_accepts_snake_case_field_names():
    # populate_by_name=True (CamelModel) — принимаем и имя поля, и camelCase-алиас.
    snake = {k: v for k, v in _VALID.items() if k != "systolicBp"}
    snake["systolic_bp"] = 145
    assert CvdRiskFactors.model_validate(snake).systolic_bp == 145.0


def test_missing_field_rejected():
    incomplete = {k: v for k, v in _VALID.items() if k != "hdlChol"}
    with pytest.raises(ValidationError):
        CvdRiskFactors.model_validate(incomplete)


def test_extra_field_rejected():
    # extra="forbid" в CamelModel — лишнее поле (в т.ч. старое имя фичи) отклоняется.
    with pytest.raises(ValidationError):
        CvdRiskFactors.model_validate({**_VALID, "AGE": 63})


def test_null_value_rejected():
    with pytest.raises(ValidationError):
        CvdRiskFactors.model_validate({**_VALID, "sex": None})


def test_non_numeric_value_rejected():
    with pytest.raises(ValidationError):
        CvdRiskFactors.model_validate({**_VALID, "ldlChol": "не число"})


@pytest.mark.parametrize(
    ("field", "bad"),
    [
        ("sex", 99),  # флаг вне [0,1]
        ("sex", -1),
        ("lipidDrugs", 2),
        ("famIhdCva", -5),
        ("age", -1),  # непрерывные вне правдоподобных рамок
        ("age", 200),
        ("bmi", 0),
        ("systolicBp", 500),
        ("lipoproteinA", -0.1),  # липиды — неотрицательны
        ("hdlChol", -1),
    ],
)
def test_out_of_domain_value_rejected(field: str, bad: float):
    # Вне-доменные значения отсекаются на границе доверия, а не уходят в модель (Bug: garbage→isSuccess).
    with pytest.raises(ValidationError):
        CvdRiskFactors.model_validate({**_VALID, field: bad})


@pytest.mark.parametrize("ok", [0, 1])
def test_flag_boundaries_accepted(ok: float):
    assert CvdRiskFactors.model_validate({**_VALID, "sex": ok}).sex == float(ok)


def test_invalid_period_rejected():
    with pytest.raises(ValidationError):
        CalculateRequest.model_validate({"period": "Y10", "riskFactors": _VALID})
