"""Сравнение расчёта с исходными артефактами и безопасные отказы калькулятора."""

import json
import logging
import shutil
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pytest
from scipy.optimize import brentq
from sklearn.pipeline import Pipeline

from src.calc.domain.calculator import CvdCalculator
from src.calc.domain.consts import CVD_FEATURES
from src.calc.domain.exceptions import CalculationError
from src.calc.domain.inference import CvdInference, LoadedModel
from src.calc.infra.model_loader import ModelArtifactError, load_models
from src.logger import MonologFormatter
from utils.modeling import table_to_risk_AIRI

_ROOT = Path(__file__).resolve().parents[1]
_ROW = (63.0, 1.0, 27.4, 145.0, 30.0, 1.1, 3.6, 0.0, 0.0, 0.0, 1.0, 0.0)


@pytest.fixture(scope="module")
def models() -> dict[str, LoadedModel]:
    return load_models(_ROOT / "src/models", _ROOT / "src/data")


@pytest.mark.parametrize("period", ["Y2", "Y5"])
def test_probabilities_and_rounded_risk_match_original_pipeline(period: str, models: dict[str, LoadedModel]):
    reference = joblib.load(_ROOT / f"src/models/{period}_model.pkl")
    incidence = pd.read_csv(_ROOT / f"src/data/{period}_incidence.csv", index_col=0, header=[0, 1]).round(2)
    calculator = CvdCalculator(models)
    rng = np.random.default_rng(310)
    rows = rng.uniform(size=(128, len(CVD_FEATURES)))
    rows *= [120, 0, 90, 250, 1000, 20, 30, 1, 1, 1, 1, 1]
    rows += [0, 0, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0]
    rows[:, 1] = rng.integers(0, 2, len(rows))
    extremes = np.array(
        [
            [0, 0, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0],
            [120, 0, 100, 300, 1e6, 0, 1e6, 1, 1, 1, 1, 1],
            [120, 0, 100, 300, 0, 1e6, 0, 1, 1, 1, 1, 1],
            _ROW,
        ],
        dtype=np.float64,
    )
    for sex in (0.0, 1.0):
        extremes[:, 1] = sex
        rows = np.vstack([rows, extremes])

        def row_at_age(age: float, group: float = sex) -> np.ndarray:
            return np.array((age, group, *_ROW[2:]), dtype=np.float64)

        def original_score(age: float) -> float:
            frame = pd.DataFrame([row_at_age(age)], columns=CVD_FEATURES)
            return float(reference.predict_proba(frame)[0, 1]) * 100.0

        def original_risk(age: float) -> float:
            return float(table_to_risk_AIRI(original_score(age), incidence))

        # Проверяем и соседние float64 у границ округления score и итогового риска.
        for function in (original_score, original_risk):
            low, high = function(0), function(120)
            for target in (25.05, 50.05, 75.05, 90.05):
                if low < target < high:
                    age = brentq(lambda value, goal=target, fn=function: fn(value) - goal, 0, 120)
                    neighbors = [age]
                    for direction in (-np.inf, np.inf):
                        neighbor = age
                        for _ in range(8):
                            neighbor = np.nextafter(neighbor, direction)
                            neighbors.append(neighbor)
                    rows = np.vstack([rows, [row_at_age(value) for value in neighbors]])

    for row in rows:
        probability = reference.predict_proba(pd.DataFrame([row], columns=CVD_FEATURES))[0, 1]
        assert models[period].model.predict_probability(row) == pytest.approx(probability, rel=0, abs=1e-14)
        score = float(probability) * 100.0
        risk = float(table_to_risk_AIRI(score, incidence))
        result = calculator.calculate_row(period, tuple(row))
        assert (result.period, result.score, result.risk_percentage) == (period, round(score, 1), round(risk, 1))


@pytest.mark.parametrize("period", ["Y2", "Y5"])
@pytest.mark.parametrize("sex", [0.25, 0.5, 0.999])
def test_fractional_sex_remains_unsupported(period: str, sex: float, models: dict[str, LoadedModel]):
    row = (*_ROW[:1], sex, *_ROW[2:])
    reference = joblib.load(_ROOT / f"src/models/{period}_model.pkl")
    with pytest.raises(ValueError):
        reference.predict_proba(pd.DataFrame([row], columns=CVD_FEATURES))
    with pytest.raises(CalculationError, match="unsupported model group"):
        CvdCalculator(models).calculate_row(period, row)


@pytest.mark.parametrize("value", [np.inf, -np.inf, np.nan])
def test_non_finite_features_fail_safely(value: float, models: dict[str, LoadedModel]):
    row = (*_ROW[:4], value, *_ROW[5:])
    with pytest.raises(CalculationError, match="invalid model row"):
        CvdCalculator(models).calculate_row("Y5", row)


def test_errors_do_not_include_feature_values(
    models: dict[str, LoadedModel],
    monkeypatch: pytest.MonkeyPatch,
    app_log_records: list[logging.LogRecord],
):
    """Численная ошибка на строке (ValueError) даёт CalculationError с фиксированным текстом и запись ERROR
    `model inference failed` с периодом, типом исключения и стеком вызовов. Текст исключения — здесь в нём
    значение признака — не попадает ни в CalculationError, ни в лог."""
    calculator = CvdCalculator(models)
    marker = "private-feature-2468013579"
    with pytest.raises(CalculationError) as error:
        calculator.calculate_row("Y5", (*_ROW[:4], marker, *_ROW[5:]))
    assert marker not in str(error.value)

    def fail(_model: CvdInference, _row: np.ndarray) -> float:
        raise ValueError(marker)

    monkeypatch.setattr(CvdInference, "predict_probability", fail)
    with pytest.raises(CalculationError) as error:
        calculator.calculate_row("Y5", _ROW)
    assert marker not in str(error.value)
    assert error.value.__suppress_context__

    failures = [record for record in app_log_records if record.getMessage() == "model inference failed"]
    assert len(failures) == 2
    for record in failures:
        assert record.levelno == logging.ERROR
        assert record.log_context == {"period": "Y5"}
        logged = MonologFormatter().format(record)
        assert marker not in logged
        exception = json.loads(logged)["context"]["exception"]
        assert "in calculate_row" in exception
        assert exception.rstrip().endswith("ValueError")


def test_non_numeric_errors_are_not_turned_into_calculation_errors(
    models: dict[str, LoadedModel], monkeypatch: pytest.MonkeyPatch
):
    """Исключение, не относящееся к численному расчёту (ошибка кода), не превращается в CalculationError
    (HTTP 422) и уходит из калькулятора как есть."""

    def fail(_model: CvdInference, _row: np.ndarray) -> float:
        raise RuntimeError("defect")

    monkeypatch.setattr(CvdInference, "predict_probability", fail)
    with pytest.raises(RuntimeError, match="defect"):
        CvdCalculator(models).calculate_row("Y5", _ROW)


@pytest.mark.parametrize(
    ("change", "check"),
    [
        ("pipeline", "pipeline_steps"),
        ("feature_order", "scaler_features"),
        ("clip", "scaler_settings"),
        ("classes", "group_0_estimator"),
        ("coefficient_shape", "group_0_coef"),
        ("non_finite", "scaler_scale"),
        ("multinomial", "group_0_estimator"),
    ],
)
def test_incompatible_artifacts_prevent_startup(
    change: str, check: str, tmp_path: Path, app_log_records: list[logging.LogRecord]
):
    """Несовместимый артефакт останавливает загрузку: ModelArtifactError с кодом сорвавшейся проверки уходит из
    load_models как есть, а в логе — запись ERROR `model load failed` с периодом, кодом и traceback."""
    model = joblib.load(_ROOT / "src/models/Y5_model.pkl")
    if change == "pipeline":
        model = Pipeline([*model.steps, ("extra", "passthrough")])
    elif change == "feature_order":
        model[0].feature_names_in_ = model[0].feature_names_in_[::-1]
    elif change == "clip":
        model[0].clip = True
    elif change == "classes":
        model[1].models[0.0].classes_ = np.array([True, False])
    elif change == "coefficient_shape":
        model[1].models[0.0].coef_ = np.ones((1, 12))
    elif change == "non_finite":
        model[0].scale_[0] = np.nan
    elif change == "multinomial":
        model[1].models[0.0].multi_class = "multinomial"
    joblib.dump(model, tmp_path / "Y5_model.pkl")
    shutil.copy(_ROOT / "src/data/Y5_incidence.csv", tmp_path / "Y5_incidence.csv")
    with pytest.raises(ModelArtifactError) as error:
        load_models(tmp_path, tmp_path)

    assert error.value.check == check
    failures = [record for record in app_log_records if record.getMessage() == "model load failed"]
    assert len(failures) == 1
    assert failures[0].levelno == logging.ERROR
    assert failures[0].log_context["period"] == "Y5"
    assert failures[0].log_context["check"] == check
    assert failures[0].exc_info is not None
    assert failures[0].exc_info[1] is error.value


def test_missing_artifacts_prevent_startup(tmp_path: Path, app_log_records: list[logging.LogRecord]):
    """Ни одного периода с файлом модели и таблицей заболеваемости: загрузка останавливает запуск с кодом
    `not_found` и записью ERROR `model load failed`."""
    with pytest.raises(ModelArtifactError) as error:
        load_models(tmp_path, tmp_path)

    assert error.value.check == "not_found"
    assert [
        record.log_context["check"] for record in app_log_records if record.getMessage() == "model load failed"
    ] == ["not_found"]


def test_startup_cross_check_catches_small_deviation(monkeypatch: pytest.MonkeyPatch):
    """Сверка с исходным Pipeline при загрузке ловит отклонение численного расчёта на 1e-9 по решающей функции
    (на умеренных профилях это ~2.5e-10 по вероятности): допуск сверки не настолько широк, чтобы пропустить
    малое расхождение расчёта с исходной моделью."""
    exact = CvdInference.predict_probability

    def shifted(model: CvdInference, row: np.ndarray) -> float:
        probability = exact(model, row)
        return probability + probability * (1.0 - probability) * 1e-9

    monkeypatch.setattr(CvdInference, "predict_probability", shifted)
    with pytest.raises(ModelArtifactError) as error:
        load_models(_ROOT / "src/models", _ROOT / "src/data")
    assert error.value.check == "reference_mismatch"


def test_unsupported_period_and_wrong_row_length_fail(models: dict[str, LoadedModel]):
    calculator = CvdCalculator(models)
    with pytest.raises(CalculationError, match="unsupported period"):
        calculator.calculate_row("Y10", _ROW)
    with pytest.raises(CalculationError, match="invalid model row"):
        calculator.calculate_row("Y5", _ROW[:-1])
