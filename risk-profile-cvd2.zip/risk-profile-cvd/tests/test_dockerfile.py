"""Запуск образа: multiprocess-режим метрик и точка входа с очисткой директории значений.

Образ в CI не собирается, поэтому изменение `ENV` или `CMD` в Dockerfile проверить больше негде:
без переменной суммирования по воркерам нет, а прежний `CMD` (`uvicorn src.main:app ...`) обходил бы
очистку директории, и после рестарта контейнера в выдачу попадали бы значения прежнего запуска.
"""

import json
import re
from pathlib import Path

_DOCKERFILE = Path(__file__).resolve().parent.parent / "Dockerfile"


def _instructions() -> list[tuple[str, str]]:
    """Инструкции Dockerfile как пары (имя, аргументы): без комментариев, переносы `\\` склеены."""
    lines = [line for line in _DOCKERFILE.read_text(encoding="utf-8").splitlines() if not line.lstrip().startswith("#")]
    joined = re.sub(r"\\\n", " ", "\n".join(lines))
    instructions = []
    for line in joined.splitlines():
        if line.strip():
            name, _, arguments = line.strip().partition(" ")
            instructions.append((name.upper(), arguments.strip()))
    return instructions


def test_image_enables_multiprocess_metrics_and_starts_via_entrypoint() -> None:
    """`ENV` задаёт непустую `PROMETHEUS_MULTIPROC_DIR`, а `CMD` — `["python", "-m", "src"]`."""
    env: dict[str, str] = {}
    cmd: list[str] = []
    for name, arguments in _instructions():
        if name == "ENV":
            env.update(pair.split("=", 1) for pair in arguments.split())
        elif name == "CMD":
            cmd = json.loads(arguments)

    assert env.get("PROMETHEUS_MULTIPROC_DIR")
    assert cmd == ["python", "-m", "src"]
