"""Multiprocess-режим метрик: подготовка директории значений, суммирование по процессам, запуск сервиса.

Режим выбирается prometheus_client при импорте по переменной окружения, поэтому внутри процесса
тестов (однопроцессный режим) его не включить: проверки суммирования идут в подпроцессах.
"""

import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pytest
from prometheus_client.parser import text_string_to_metric_families

from src.metrics import MULTIPROC_ENV, prepare_multiproc_dir

_REPO_ROOT = Path(__file__).resolve().parent.parent
_METRIC = "risk_profile_cvd_http_request_duration_seconds"
# С запасом на холодный импорт ML-библиотек в подпроцессе.
_SUBPROCESS_TIMEOUT_S = 180
_STARTUP_DEADLINE_S = 120
_STOP_TIMEOUT_S = 30

# Процесс в роли uvicorn-воркера: свой файл значений, запросы через реальное приложение.
_WORKER_SCRIPT = """
import asyncio
import json
import os
import sys

from fastapi.testclient import TestClient

from src.api.v1.calculation.router import get_calculator, get_semaphore
from src.calc.domain.models import CvdResult
from src.main import app


class StubCalculator:
    def calculate_row(self, period, features):
        return CvdResult(period=period, score=12.3, risk_percentage=45.6)


app.dependency_overrides[get_calculator] = StubCalculator
app.dependency_overrides[get_semaphore] = lambda: asyncio.Semaphore(1)
client = TestClient(app)
body = json.loads(os.environ["CVD_TEST_BODY"])
for _ in range(3):
    status = client.post("/api/v1/calculate", json=body).status_code
    if status != 200:
        sys.exit(f"unexpected status {status}")
"""

# Процесс, обслуживающий скрейп: выдачу собирает из файлов значений всех процессов.
_RENDER_SCRIPT = "import sys; from src.metrics import render; sys.stdout.write(render().decode())"


def test_prepare_multiproc_dir_removes_only_metric_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Файлы значений прежнего запуска (`*.db`) удаляются, посторонние файлы директории остаются."""
    (tmp_path / "histogram_7.db").write_bytes(b"stale")
    (tmp_path / "counter_1.db").write_bytes(b"stale")
    (tmp_path / "notes.txt").write_text("не файл метрик")
    monkeypatch.setenv(MULTIPROC_ENV, str(tmp_path))

    prepare_multiproc_dir()

    assert sorted(p.name for p in tmp_path.iterdir()) == ["notes.txt"]


def test_prepare_multiproc_dir_creates_missing_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Свежий контейнер: директории ещё нет — она создаётся."""
    target = tmp_path / "prometheus-multiproc"
    monkeypatch.setenv(MULTIPROC_ENV, str(target))

    prepare_multiproc_dir()

    assert target.is_dir()


def test_prepare_multiproc_dir_without_env_does_nothing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Без переменной (локальный однопроцессный запуск) функция ничего не создаёт и не падает."""
    monkeypatch.delenv(MULTIPROC_ENV, raising=False)
    monkeypatch.chdir(tmp_path)

    prepare_multiproc_dir()

    assert list(tmp_path.iterdir()) == []


def test_render_sums_observations_of_all_processes(tmp_path: Path, valid_risk_factors: dict[str, float]) -> None:
    """Два процесса с общей директорией значений сделали по 3 успешных расчёта. Выдача, собранная
    третьим процессом, содержит один ряд `_count` = 6 с лейблами этого запроса, без лейбла `pid`,
    с одной строкой `# HELP` и одной `# TYPE`."""
    env = {
        **os.environ,
        "PYTHONPATH": str(_REPO_ROOT),
        MULTIPROC_ENV: str(tmp_path / "prometheus-multiproc"),
        "CVD_TEST_BODY": json.dumps({"period": "Y5", "riskFactors": valid_risk_factors}),
    }
    logs = [tmp_path / f"worker-{i}.log" for i in range(2)]
    workers: list[subprocess.Popen[bytes]] = []
    try:
        for log_path in logs:
            with log_path.open("wb") as log:
                workers.append(
                    subprocess.Popen(
                        [sys.executable, "-c", _WORKER_SCRIPT],
                        cwd=_REPO_ROOT,
                        env=env,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                    )
                )
        for worker, log_path in zip(workers, logs, strict=True):
            assert worker.wait(timeout=_SUBPROCESS_TIMEOUT_S) == 0, log_path.read_text(errors="replace")
    finally:
        # Упавшая проверка не должна оставлять живые процессы.
        for worker in workers:
            if worker.poll() is None:
                worker.kill()
                worker.wait()

    rendered = subprocess.run(
        [sys.executable, "-c", _RENDER_SCRIPT],
        cwd=_REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=_SUBPROCESS_TIMEOUT_S,
        check=False,
    )
    assert rendered.returncode == 0, rendered.stderr
    exposition = rendered.stdout

    counts = [
        (sample.labels, sample.value)
        for family in text_string_to_metric_families(exposition)
        for sample in family.samples
        if sample.name == f"{_METRIC}_count"
    ]
    assert counts == [
        ({"method": "POST", "path": "/api/v1/calculate", "status": "200", "host": socket.gethostname()}, 6.0)
    ]
    assert "pid=" not in exposition
    assert [line for line in exposition.splitlines() if line.startswith("# HELP ")] == [
        f"# HELP {_METRIC} Латентность входящих HTTP-запросов"
    ]
    assert [line for line in exposition.splitlines() if line.startswith("# TYPE ")] == [f"# TYPE {_METRIC} histogram"]


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _http(method: str, url: str, body: dict[str, Any] | None = None) -> tuple[int, str]:
    data = None if body is None else json.dumps(body).encode()
    request = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status, response.read().decode()


def _wait_until_healthy(process: subprocess.Popen[bytes], base_url: str, log_path: Path) -> None:
    deadline = time.monotonic() + _STARTUP_DEADLINE_S
    while time.monotonic() < deadline:
        if process.poll() is not None:
            pytest.fail(f"сервис завершился при старте с кодом {process.returncode}:\n{log_path.read_text()}")
        try:
            if _http("GET", f"{base_url}/health")[0] == 200:
                return
        except OSError:
            # Сервис ещё не слушает порт или не закончил старт — ждём дальше.
            time.sleep(0.2)
    pytest.fail(f"сервис не ответил на /health за {_STARTUP_DEADLINE_S} с:\n{log_path.read_text()}")


def _stop(process: subprocess.Popen[bytes]) -> None:
    """Штатная остановка (SIGTERM мастеру uvicorn), при зависании — SIGKILL всей группе процессов."""
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=_STOP_TIMEOUT_S)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    # Воркеры, пережившие мастер, не должны оставаться после теста.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        return


@contextmanager
def _service(workers: int, multiproc_dir: Path, log_path: Path) -> Iterator[str]:
    """Сервис, запущенный штатной точкой входа `python -m src`; отдаёт базовый URL и гасит процессы на выходе."""
    port = _free_port()
    env = {
        **os.environ,
        "PYTHONPATH": str(_REPO_ROOT),
        MULTIPROC_ENV: str(multiproc_dir),
        "CVD_HOST": "127.0.0.1",
        "CVD_PORT": str(port),
        "CVD_WORKERS": str(workers),
        "LOG_LEVEL": "NOTICE",
    }
    with log_path.open("wb") as log:
        process = subprocess.Popen(
            [sys.executable, "-m", "src"],
            cwd=_REPO_ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    try:
        base_url = f"http://127.0.0.1:{port}"
        _wait_until_healthy(process, base_url, log_path)
        yield base_url
    finally:
        _stop(process)


def _scraped_total_count(base_url: str) -> float:
    """Сумма `_count` по всем рядам гистограммы в выдаче `/metrics` работающего сервиса."""
    status, text = _http("GET", f"{base_url}/metrics")
    assert status == 200
    return sum(
        sample.value
        for family in text_string_to_metric_families(text)
        for sample in family.samples
        if sample.name == f"{_METRIC}_count"
    )


def test_entrypoint_sums_workers_and_drops_previous_run(tmp_path: Path, valid_risk_factors: dict[str, float]) -> None:
    """Сервис, запущенный `python -m src` с `CVD_WORKERS=2`, после 6 расчётов отдаёт суммарный `_count`
    = 6 при любом распределении запросов по воркерам. Перед вторым запуском в директорию значений
    подложен файл процесса с PID, которого в ОС не бывает. После запуска с той же директорией и
    `CVD_WORKERS=1` этого файла нет, а два расчёта дают `_count` = 2: данные прежнего запуска не
    подмешаны, а наблюдения процесса, который сам очистил директорию, видны. Access-строк uvicorn в
    выводе обоих запусков нет."""
    multiproc_dir = tmp_path / "prometheus-multiproc"
    body = {"period": "Y5", "riskFactors": valid_risk_factors}
    first_log, second_log = tmp_path / "first.log", tmp_path / "second.log"

    with _service(2, multiproc_dir, first_log) as base_url:
        for _ in range(6):
            assert _http("POST", f"{base_url}/api/v1/calculate", body)[0] == 200
        first_total = _scraped_total_count(base_url)

    # Копия файла значений первого запуска под PID выше максимального в Linux и macOS: имя не совпадёт
    # ни с одним процессом второго запуска, поэтому файл может исчезнуть только при очистке директории.
    stale = multiproc_dir / "histogram_999999999.db"
    shutil.copyfile(next(multiproc_dir.glob("histogram_*.db")), stale)

    with _service(1, multiproc_dir, second_log) as base_url:
        for _ in range(2):
            assert _http("POST", f"{base_url}/api/v1/calculate", body)[0] == 200
        second_total = _scraped_total_count(base_url)

    first_output, second_output = first_log.read_text(), second_log.read_text()
    assert first_total == 6.0, f"первый запуск: _count={first_total}\n{first_output}"
    assert not stale.exists(), f"файл прежнего запуска не удалён при старте\n{second_output}"
    assert second_total == 2.0, f"второй запуск: _count={second_total}\n{second_output}"
    assert ' HTTP/1.1" ' not in first_output
    assert ' HTTP/1.1" ' not in second_output
