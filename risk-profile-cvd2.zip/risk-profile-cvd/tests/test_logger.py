"""Поведенческие тесты логгера: fingers-crossed, PII-маскирование, business-канал."""

from __future__ import annotations

import json
import logging

from src import logger as logmod


class _Capture(logging.Handler):
    """Фейковый target: складывает записи, пришедшие через handle() (как делает FingersCrossedHandler)."""

    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def handle(self, record: logging.LogRecord) -> bool:
        self.records.append(record)
        return True


def _rec(level: int, msg: str, channel: str = "app") -> logging.LogRecord:
    r = logging.LogRecord("app", level, __file__, 1, msg, None, None)
    r.channel = channel
    r.log_context = {}
    return r


def _msgs(cap: _Capture) -> list[str]:
    return [r.getMessage() for r in cap.records]


def test_fingers_crossed_buffers_until_error() -> None:
    """INFO/DEBUG копятся в буфере; ERROR сливает накопленное в хронологическом порядке."""
    cap = _Capture()
    fc = logmod.FingersCrossedHandler(cap)
    token = logmod.fingers_crossed_var.set(logmod.FingersBuffer())
    try:
        fc.emit(_rec(logging.INFO, "i1"))
        fc.emit(_rec(logging.DEBUG, "d1"))
        assert _msgs(cap) == []  # ничего не вышло — ошибки не было
        fc.emit(_rec(logging.ERROR, "boom"))
        assert _msgs(cap) == ["i1", "d1", "boom"]  # буфер слит + сама ошибка
    finally:
        logmod.fingers_crossed_var.reset(token)


def test_business_channel_bypasses_buffer() -> None:
    """channel=business выходит всегда, мимо fingers-crossed."""
    cap = _Capture()
    fc = logmod.FingersCrossedHandler(cap)
    token = logmod.fingers_crossed_var.set(logmod.FingersBuffer())
    try:
        fc.emit(_rec(logging.INFO, "biz", channel=logmod.BUSINESS_CHANNEL))
        assert _msgs(cap) == ["biz"]
    finally:
        logmod.fingers_crossed_var.reset(token)


def test_notice_passes_threshold_without_error() -> None:
    """NOTICE (>= порога по умолчанию) выходит сразу, без триггера ошибкой."""
    cap = _Capture()
    fc = logmod.FingersCrossedHandler(cap)
    token = logmod.fingers_crossed_var.set(logmod.FingersBuffer())
    try:
        fc.emit(_rec(logmod.NOTICE, "n1"))
        assert _msgs(cap) == ["n1"]
    finally:
        logmod.fingers_crossed_var.reset(token)


def test_sanitize_masks_biomarkers_and_pii() -> None:
    """Значения биомаркеров/PII маскируются по ключу, прочее остаётся."""
    out = logmod._sanitize_context({"bmi": 25.6, "ldl_chol": 3.4, "features": {"AGE": 41}, "status": "ok"})
    assert out["bmi"] == "***"
    assert out["ldl_chol"] == "***"
    assert out["features"] == "***"
    assert out["status"] == "ok"


def test_formatter_masks_pii_and_injects_request_id() -> None:
    """JSON-формат: PII в context замаскирован, requestId проставлен в extra."""
    fmt = logmod.MonologFormatter()
    r = _rec(logmod.NOTICE, "calc done")
    r.log_context = {"features": {"AGE": 41}, "period": "Y5"}
    out = json.loads(fmt.format(r))
    assert out["context"]["features"] == "***"
    assert out["context"]["period"] == "Y5"  # не PII — остаётся
    assert out["level_name"] == "NOTICE"
    assert out["extra"]["requestId"]
