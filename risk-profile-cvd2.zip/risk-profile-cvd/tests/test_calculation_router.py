"""Router-уровень тесты POST /api/v1/calculate (через TestClient).

Проверяют разбор запроса FastAPI, проводку camelCase-алиасов и envelope-хендлер валидации —
то, что не видно на чистом pydantic-слое (test_calculation_schemas.py). Это ломающее изменение
контракта (ключ `features` ушёл), поэтому отдельно фиксируем: новый `riskFactors` → 200, старый
`features` → 400.

Модель не грузим: TestClient используем БЕЗ контекст-менеджера, поэтому lifespan (load_models)
не запускается; калькулятор и семафор подменяем через app.dependency_overrides.
"""

import asyncio
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient

from src.api.v1.calculation.router import get_calculator, get_semaphore
from src.calc.domain.models import CvdResult
from src.main import app

_VALID_RISK_FACTORS = {
    "age": 63,
    "sex": 1,
    "bmi": 27.4,
    "systolicBp": 145,
    "lipoproteinA": 30,
    "hdlChol": 1.1,
    "ldlChol": 3.6,
    "lipidDrugs": 0,
    "atherosclerosis": 0,
    "diabetes": 0,
    "famIhdCva": 1,
    "famHypchol": 0,
}


class _StubCalculator:
    """Подменяет резидентный калькулятор: фиксированный результат, без загрузки ML-модели."""

    def calculate_row(self, period: str, features: tuple[float, ...]) -> CvdResult:
        return CvdResult(period=period, score=12.3, risk_percentage=45.6)


@pytest.fixture
def client() -> Iterator[TestClient]:
    app.dependency_overrides[get_calculator] = lambda: _StubCalculator()
    app.dependency_overrides[get_semaphore] = lambda: asyncio.Semaphore(1)
    # Без `with` — lifespan (load_models) не запускается; нужные зависимости подменены выше.
    yield TestClient(app)
    app.dependency_overrides.clear()


def test_new_risk_factors_body_returns_200(client: TestClient):
    resp = client.post("/api/v1/calculate", json={"period": "Y5", "riskFactors": _VALID_RISK_FACTORS})
    assert resp.status_code == 200
    body = resp.json()
    assert body["isSuccess"] is True
    assert body["period"] == "Y5"
    assert body["riskPercentage"] == 45.6  # camelCase-алиас в ответе


def test_old_features_key_returns_400_envelope(client: TestClient):
    # Старый контракт (`features`-мапа) теперь невалиден: features — лишнее поле, riskFactors нет.
    resp = client.post("/api/v1/calculate", json={"period": "Y5", "features": {"AGE": 63, "SEX": 1}})
    assert resp.status_code == 400
    body = resp.json()
    assert body["isSuccess"] is False
    assert "error" in body and "code" in body["error"]


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("sex", 99),
        ("sex", 0.543210123),
        ("lipidDrugs", 0.543210123),
        ("atherosclerosis", 0.543210123),
        ("diabetes", 0.543210123),
        ("famIhdCva", 0.543210123),
        ("famHypchol", 0.543210123),
    ],
)
def test_binary_flag_other_than_zero_or_one_returns_400_with_field(client: TestClient, field: str, value: float):
    """Категориальный признак принимает только 0 или 1: иное значение — вне [0, 1] или дробное — даёт 400 с кодом
    поля, до калькулятора запрос не доходит, а само значение в ответ не попадает."""
    resp = client.post(
        "/api/v1/calculate",
        json={"period": "Y5", "riskFactors": {**_VALID_RISK_FACTORS, field: value}},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == f"INVALID_RISKFACTORS_{field.upper()}"
    assert str(value) not in resp.text
