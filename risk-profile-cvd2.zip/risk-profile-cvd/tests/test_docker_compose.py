"""Собственный `docker-compose.yml`: на каком адресе хоста публикуется порт сервиса."""

from pathlib import Path

import yaml

_COMPOSE = Path(__file__).resolve().parent.parent / "docker-compose.yml"


def test_standalone_compose_publishes_port_on_localhost_only() -> None:
    """`/api/v1/calculate` и `/metrics` работают без авторизации, поэтому порт публикуется только на
    127.0.0.1 — как у сервиса cvd в compose ядра. Публикация без адреса открыла бы их на всех
    интерфейсах хоста."""
    compose = yaml.safe_load(_COMPOSE.read_text(encoding="utf-8"))

    assert compose["services"]["cvd"]["ports"] == ["127.0.0.1:${CVD_PORT:-8000}:${CVD_PORT:-8000}"]
