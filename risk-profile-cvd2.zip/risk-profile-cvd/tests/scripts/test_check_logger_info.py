"""Регресс-проверки для scripts/check_logger_info.py."""

from __future__ import annotations

import importlib.util
import subprocess  # nosec B404
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPT_PATH = REPO_ROOT / "scripts" / "check_logger_info.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("check_logger_info", SCRIPT_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _make_repo(tmp_path: Path, files: dict[str, str | bytes]) -> Path:
    """Собирает мини-репозиторий с src/ и scripts/ в tmp_path для изолированного сканирования."""
    for rel, content in files.items():
        path = tmp_path / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            path.write_bytes(content)
        else:
            path.write_text(content, encoding="utf-8")
    return tmp_path


def test_passes_on_current_repo() -> None:
    """Базовая страховка: текущий код не содержит запрещённых паттернов."""
    result = subprocess.run(  # nosec B603
        [sys.executable, str(SCRIPT_PATH)],
        capture_output=True,
        text=True,
        check=False,
        cwd=str(REPO_ROOT),
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_scan_detects_logger_info(tmp_path: Path) -> None:
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text('logger.info("nope")\n', encoding="utf-8")
    violations = mod._scan_file(f)
    assert len(violations) == 1
    assert "logger.info" in violations[0][1]


def test_scan_detects_logging_info(tmp_path: Path) -> None:
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text('logging.info("nope")\n', encoding="utf-8")
    violations = mod._scan_file(f)
    assert len(violations) == 1
    assert "logging.info" in violations[0][1]


def test_scan_detects_logger_log_with_logging_info_constant(tmp_path: Path) -> None:
    """logger.log(logging.INFO, ...) — обход через generic-API."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text('logger.log(logging.INFO, "sneaky")\n', encoding="utf-8")
    violations = mod._scan_file(f)
    assert len(violations) == 1


def test_scan_detects_logger_log_with_numeric_info_constant(tmp_path: Path) -> None:
    """logger.log(20, ...) — обход через сырое число."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text('logger.log(20, "raw")\n', encoding="utf-8")
    violations = mod._scan_file(f)
    assert len(violations) == 1


def test_scan_ignores_comments(tmp_path: Path) -> None:
    """Закомментированная строка — не нарушение."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text('# logger.info("docstring example, not real call")\n', encoding="utf-8")
    violations = mod._scan_file(f)
    assert violations == []


def test_scan_ignores_business_helper(tmp_path: Path) -> None:
    """business(...) / notice(...) — каноничные хелперы, не должны триггерить линтер."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text(
        'business("event", context={"k": "v"})\nnotice("event", context={"k": "v"})\n',
        encoding="utf-8",
    )
    violations = mod._scan_file(f)
    assert violations == []


def test_scan_ignores_warning_and_error(tmp_path: Path) -> None:
    """logger.warning/.error/.critical/.debug — допустимые уровни, не INFO."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_text(
        'logger.warning("w")\nlogger.error("e")\nlogger.critical("c")\nlogger.debug("d")\n',
        encoding="utf-8",
    )
    violations = mod._scan_file(f)
    assert violations == []


def test_scan_skips_non_utf8_file_with_warn(tmp_path: Path, capsys) -> None:
    """Non-UTF-8 байты не должны крашить линтер."""
    mod = _load_module()
    f = tmp_path / "x.py"
    f.write_bytes(b"\xff\xfe garbage \xff bytes\n")
    violations = mod._scan_file(f)
    assert violations == []
    captured = capsys.readouterr()
    assert "non-UTF-8" in captured.err


def test_scan_function_detects_violation_in_isolated_repo(tmp_path: Path) -> None:
    """End-to-end через scan(repo_root) на изолированном tmp_path — не пишем в реальный src/."""
    mod = _load_module()
    fake_root = _make_repo(
        tmp_path,
        {
            "src/bad.py": 'from src.logger import logger\nlogger.info("bad")\n',
            "src/ok.py": 'from src.logger import business\nbusiness("ok")\n',
        },
    )
    findings = mod.scan(fake_root)
    assert len(findings) == 1
    assert "src/bad.py" in findings[0]
    assert "logger.info" in findings[0]


def test_scan_function_respects_allowlist(tmp_path: Path) -> None:
    """src/logger.py — в allowlist, нарушения внутри не считаются."""
    mod = _load_module()
    fake_root = _make_repo(
        tmp_path,
        {
            "src/logger.py": 'import logging\nlogger.log(logging.INFO, "ok")\n',
        },
    )
    findings = mod.scan(fake_root)
    assert findings == []
