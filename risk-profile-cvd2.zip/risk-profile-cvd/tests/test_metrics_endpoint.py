"""Ручка `GET /metrics`: формат выдачи, выключатель экспозиции и логирование скрейпа."""

import socket
from collections.abc import Callable
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient
from prometheus_client import CONTENT_TYPE_LATEST
from prometheus_client.parser import text_string_to_metric_families

import src.api.request_context as request_context_module
from src.config import Settings, settings

_METRIC = "risk_profile_cvd_http_request_duration_seconds"


def _calculation_count(exposition: str) -> float:
    """`_count` ряда успешного `POST /api/v1/calculate` в тексте выдачи (0, если ряда ещё нет)."""
    labels = {"method": "POST", "path": "/api/v1/calculate", "status": "200", "host": socket.gethostname()}
    for family in text_string_to_metric_families(exposition):
        for sample in family.samples:
            if sample.name == f"{_METRIC}_count" and sample.labels == labels:
                return sample.value
    return 0.0


def test_metrics_exposes_request_histogram_in_prometheus_text(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
) -> None:
    """После расчёта `/metrics` отвечает 200 в текстовом формате Prometheus. Единственное семейство —
    гистограмма запросов с префиксом сервиса (счётчика запросов нет), ряды только `_bucket`, `_sum`
    и `_count`, границы корзин — стандартные от 0.005 до 10 с и `+Inf`."""
    client = make_client()
    assert client.post("/api/v1/calculate", json={"riskFactors": valid_risk_factors}).status_code == 200

    response = client.get("/metrics")

    assert response.status_code == 200
    # Сверяем с константой библиотеки, а не с литералом: зависимость без верхней границы, и новая
    # версия prometheus-client с другой версией формата в заголовке уронила бы тест без изменений в коде.
    assert response.headers["content-type"] == CONTENT_TYPE_LATEST
    families = list(text_string_to_metric_families(response.text))
    assert [(family.name, family.type) for family in families] == [(_METRIC, "histogram")]
    samples = families[0].samples
    assert {sample.name for sample in samples} == {f"{_METRIC}_bucket", f"{_METRIC}_sum", f"{_METRIC}_count"}
    calculation_bounds = [
        sample.labels["le"]
        for sample in samples
        if sample.name == f"{_METRIC}_bucket"
        and sample.labels["path"] == "/api/v1/calculate"
        and sample.labels["method"] == "POST"
        and sample.labels["status"] == "200"
    ]
    assert calculation_bounds == [
        "0.005",
        "0.01",
        "0.025",
        "0.05",
        "0.075",
        "0.1",
        "0.25",
        "0.5",
        "0.75",
        "1.0",
        "2.5",
        "5.0",
        "7.5",
        "10.0",
        "+Inf",
    ]


def test_disabled_exposition_returns_404_and_collection_continues(
    make_client: Callable[..., TestClient],
    valid_risk_factors: dict[str, float],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """С `CVD_METRICS__ENABLED=false` ручка отвечает 404 в формате ошибок сервиса, а запрос расчёта,
    обработанный в это время, учтён: после включения экспозиции его `_count` виден в выдаче (+1)."""
    client = make_client()
    count_before = _calculation_count(client.get("/metrics").text)

    with monkeypatch.context() as patched:
        patched.setenv("CVD_METRICS__ENABLED", "false")
        # Настройки читаются из окружения при создании; подменяем раздел в общем объекте настроек,
        # чтобы выключатель увидел любой код, который его читает.
        patched.setattr(settings, "metrics", Settings().metrics)
        disabled = client.get("/metrics")
        assert client.post("/api/v1/calculate", json={"riskFactors": valid_risk_factors}).status_code == 200

    assert disabled.status_code == 404
    assert disabled.json() == {
        "isSuccess": False,
        "error": {"code": "HTTP_404", "message": "Metrics endpoint is disabled"},
    }
    assert _calculation_count(client.get("/metrics").text) == count_before + 1


def test_scrape_not_logged_as_request_completed(
    make_client: Callable[..., TestClient],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Из двух запросов — скрейпа `/metrics` и обычного запроса на неизвестный путь — запись
    `request completed` получает только обычный запрос."""
    recorded_notice = MagicMock()
    monkeypatch.setattr(request_context_module, "notice", recorded_notice)
    client = make_client()

    assert client.get("/metrics").status_code == 200
    assert client.get("/no-such/route").status_code == 404

    completed_paths = [
        call.kwargs["context"]["path"]
        for call in recorded_notice.call_args_list
        if call.args and call.args[0] == "request completed"
    ]
    assert completed_paths == ["/no-such/route"]
