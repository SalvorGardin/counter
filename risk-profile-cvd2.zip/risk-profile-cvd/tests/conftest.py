"""Общие фикстуры тестов: валидное тело расчёта, клиент приложения без загрузки модели и записи
логгера сервиса."""

import asyncio
import logging
from collections.abc import Callable, Iterator

import pytest
from fastapi.testclient import TestClient

from src.api.v1.calculation.router import get_calculator, get_semaphore
from src.calc.domain.models import CvdResult
from src.main import app


class _StubCalculator:
    """Подменяет резидентный калькулятор: без ML-модели, фиксированный результат либо заданное исключение."""

    def __init__(self, error: type[Exception] | None) -> None:
        self._error = error

    def calculate_row(self, period: str, features: tuple[float, ...]) -> CvdResult:
        if self._error is not None:
            raise self._error("stub calculator failure")
        return CvdResult(period=period, score=12.3, risk_percentage=45.6)


@pytest.fixture
def valid_risk_factors() -> dict[str, float]:
    """12 факторов риска, проходящих валидацию `POST /api/v1/calculate`."""
    return {
        "age": 63,
        "sex": 1,
        "bmi": 27.4,
        "systolicBp": 145,
        "lipoproteinA": 30,
        "hdlChol": 1.1,
        "ldlChol": 3.6,
        "lipidDrugs": 0,
        "atherosclerosis": 0,
        "diabetes": 0,
        "famIhdCva": 1,
        "famHypchol": 0,
    }


@pytest.fixture
def make_client() -> Iterator[Callable[..., TestClient]]:
    """Фабрика клиента приложения без lifespan: калькулятор и семафор подменены через dependency_overrides.

    `calculator_error` — класс исключения, которое бросит калькулятор; `raise_server_exceptions=False`
    отдаёт 500-ответ телом, а не пробрасывает исключение в тест.
    """

    def _make(
        calculator_error: type[Exception] | None = None,
        *,
        raise_server_exceptions: bool = True,
    ) -> TestClient:
        app.dependency_overrides[get_calculator] = lambda: _StubCalculator(calculator_error)
        app.dependency_overrides[get_semaphore] = lambda: asyncio.Semaphore(1)
        return TestClient(app, raise_server_exceptions=raise_server_exceptions)

    yield _make
    app.dependency_overrides.clear()


class _RecordList(logging.Handler):
    """Собирает записи логгера сервиса: он не передаёт их корневому логгеру, поэтому caplog их не видит."""

    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


@pytest.fixture
def app_log_records() -> Iterator[list[logging.LogRecord]]:
    """Записи логгера сервиса `app`, сделанные во время теста."""
    handler = _RecordList()
    app_logger = logging.getLogger("app")
    app_logger.addHandler(handler)
    yield handler.records
    app_logger.removeHandler(handler)
