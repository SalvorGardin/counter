# risk-profile-cvd — спека

> Обзорный документ: что это за сервис, зачем он, и что мы с ним делаем.
> Детальные решения и список фич модели — в [INTEGRATION_DECISIONS.md](./INTEGRATION_DECISIONS.md).
> Дальше работа продолжается отдельным агентом.

## Что это

ML-сервис расчёта **риска сердечно-сосудистых заболеваний (ССЗ)** по биомаркерам.

Происхождение: пришёл как «baseline» — одноразовый CLI-скрипт (батч по JSON-файлам),
не сервис: считал синхронно, без параллелизма, грузил модель с диска на каждый вызов.
Исходный baseline-README сохранён как [README_baseline.md](./README_baseline.md).

В baseline было две модели — биологический возраст (BIOAGE) и риск ССЗ (CVD).
**Оставляем только CVD.** BIOAGE выпиливается (см. ниже).

### Модель CVD

- Артефакты: `src/models/Y5_model.pkl` / `Y2_model.pkl` (классификаторы риска на 5 и 2 года),
  `src/data/Y5_incidence.csv` / `Y2_incidence.csv` (таблицы заболеваемости: перевод score → %).
- Загрузка через `joblib`; распаковка требует кастомных классов из `utils/modeling.py`
  (`BinaryStratifiedModel`, `ClinicalLogisticRegression`). **`lifelines` не нужен** (он был
  только у BIOAGE/Cox-модели).
- Вход: 12 числовых фич (см. приложение в INTEGRATION_DECISIONS.md). Категориальные (пол,
  да/нет) закодированы в 1/0. Пропуски заполняются медианой из обучающей выборки.
- Выход: риск ССЗ в процентах + готовый человекочитаемый текст.

## Зачем (контекст)

Основной продукт — **`risk-profile-core`** (репозиторий рядом, на gitlab.tywys.ru в группе
`risk-profile`): FastAPI async-монолит (Postgres/asyncpg, aiokafka), где калькуляторы риска —
это обычные Python-формулы (STAI, BDI, FINDRISC, SCORE2, …), **без ML-зависимостей**.

Нужно поддержать ML-калькулятор ССЗ. Он тяжёлый (numpy/scipy/scikit-learn) и CPU-bound,
поэтому тащить его внутрь лёгкого ядра нельзя. Решение — **отдельный stateless-микросервис**
(этот репозиторий), который ядро вызывает по сети.

## Цель

Превратить CLI-батч в нормальный **масштабируемый inference-сервис** и интегрировать его с
`risk-profile-core`.

## Как это будет работать

```
risk-profile-core                         risk-profile-cvd (этот сервис)
─────────────────                         ──────────────────────────────
собрал ВСЕ показатели по ССЗ
(вызов только когда данные полные)
        │  HTTP (сервис-к-сервису, внутр. сеть)
        └──────── POST /calculate ───────►  валидация входа (pydantic, все 12 фич non-null)
                                            инференс модели (в памяти)
                                            [импутация медианой — выкл., хук в коде]
        ◄──────── риск % + текст ─────────  ответ
нормализует в FormulaResult
ставит systemCode (ССЗ)
upsert + публикация в Kafka
(risk_calculation → интерпретация)
```

- Один вызов = весь набор фич сразу (не «вопрос-ответ по одному»). Сбор/опрос — на стороне ядра.
- Масштаб: воркеров-процессов = ядрам пода; горизонтально — репликами подов (HPA); при росте
  нагрузки — переход на Kafka-консьюмеров.

## Объём работ (что делаем с сервисом)

См. чек-лист в [INTEGRATION_DECISIONS.md](./INTEGRATION_DECISIONS.md). Кратко:

1. ✅ **Обернуть в FastAPI** *(сделано 2026-06-02)*: `POST /api/v1/calculate` + `/health`/`/readiness`/`/liveness`,
   pydantic-валидация, ошибки в envelope `{isSuccess, error}`. Слоистая структура как в core
   (`api` → `calc/domain` → `calc/infra`), запуск через `uvicorn src.main:app`. Проверено живым запуском
   (`score` совпадает с фикстурой).
2. ✅ **Кешировать модель** *(сделано вместе с #1)*: модель грузится один раз в `lifespan`, резидентна в `app.state`.
3. ✅ **Воркеры/конкурентность** *(сделано 2026-06-02)*: число воркеров — `CVD_WORKERS` (дефолт 1,
   `uvicorn --workers`); cap на одновременные инференсы внутри воркера — `CVD_MAX_CONCURRENCY`
   (дефолт 5, `asyncio.Semaphore`); блокирующий инференс уведён в threadpool (`run_in_threadpool`).
   Значения подбираются под нагрузкой. Переполнение cap — ожидание, не отбрасывание.
4. ✅ **Импутация — решено: по умолчанию выключена** *(2026-06-02)*: ядро вызывает сервис, только
   когда собраны все данные → контракт требует все 12 фич **non-null** (`null` отклоняется валидацией).
   Подстановка медианы оставлена закомментированным хуком в `calculator.py` — включаем, если решим
   разрешить `null` на входе (тогда тип фич → `float | None` + пометка импутированных полей).
5. **Слой-маппинг**: коды параметров ядра → фичи модели + перекодировка значений в числа. *(Ждёт аналитику.)*
6. ✅ **Убрать тихий `0.0`** *(сделано в новом пути)*: сбой модели → `CalculationError` → HTTP 422 в envelope.
   Легаси `src/calculator.py` не трогали (уйдёт с ретайром CLI).
7. ✅ **`requestId` + `X-Enable-Debug`** *(сделано 2026-06-02)*: middleware принимает/генерит/возвращает
   `X-Request-ID`, нормализует `X-Enable-Debug` на границе доверия (`"true"`/`""`) и выставляет
   `debug_enabled`/`x_enable_debug` в ContextVar. Сервис — лист (downstream-вызовов нет), проброс
   наружу включится автоматически, когда появятся (хелпер `with_request_context` для фоновых задач готов).
8. ✅ **Логирование по правилам core** *(сделано 2026-06-02)*: `src/logger.py` портирован 1:1 со стиля
   core — Monolog-JSON, уровни `business`/`notice`/`alert`/`emergency`, NOTICE+ в проде, fingers-crossed
   (INFO копится, сливается при ERROR+), маскирование PII (включая значения 12 фич — биомаркеры не логируем),
   сквозной requestId. Прямые INFO-логи запрещены и ловятся `make lint-logger`
   (`scripts/check_logger_info.py`). Тесты: `tests/test_logger.py`, `tests/scripts/test_check_logger_info.py`.
9. ✅ **Выпилить BIOAGE** *(сделано 2026-06-02)*: удалены ветка `process_biological_age`
   (и `_calculate_biological_age`), `risk_model.pickle` (~12 МБ), `age_model.pkl`, зависимость
   `lifelines`, фикстура `input_bioage.json` и таргет `make test-bioage`. CVD не тронут
   (проверено `make test-cvd`).
10. ✅ **CI/CD** *(сделано 2026-06-02)*: `.gitlab-ci.yml` — стадия `checks` (ruff format/check +
    `lint-logger` + **bandit** + pytest) на MR/любой push, затем стадия `deploy` на `develop`
    (SSH на дев-стенд → `git reset --hard origin/develop` + `docker compose up -d --build`, зеркало
    core). Репозиторий склонирован на стенде в `/home/sberuser/risk-profile-cvd` (git по SSH).
    **Деплой-механика проверена вручную тем же скриптом**: образ собран на стенде, контейнер
    `risk-profile-cvd` healthy на :8000, `/health`/`/readiness` 200, логи JSON, sklearn-варнинга нет.
    Сетевая доступность из контейнера: ✅ core через host-gateway (`:9001`), ✅ внешний egress;
    прямой IP core-контейнера недоступен (разные bridge-сети — закроется общей сетью при интеграции).
    Осталось вне кода: (1) задать в CI cvd переменные `SSH_PRIVATE_KEY`(file)+`SSH_KNOWN_HOSTS`
    (копирование чужого ключа заблокировано политикой — ставит владелец); (2) после этого пуш в
    `develop` авто-деплоит. CI-раннер у проекта — общий с core (id1), джоба ждёт его очереди.
11. ✅ **docker-compose: локальное тестирование + дев-стенд** *(сделано 2026-06-02)*: compose в cvd
    (`image: risk-profile-cvd:latest`, `env_file` необязателен, healthcheck, все `CVD_*` через env),
    `.env.example` + `.dockerignore` (модель НЕ исключена). Compose ядра расширен сервисом `cvd`
    под профилем `cvd` (`docker compose --profile cvd up`) — поднимается рядом, ядро зовёт по сети
    `http://cvd:8000`. **Образ собран и проверен**: `docker build` (exit 0, 553 МБ); контейнер
    отдаёт `/health`/`/readiness` 200 и `/calculate` Y5 → `{score 52.1, risk 48.5}`, логи JSON с
    requestId без PII, sklearn-варнинга нет (пин 1.6.1 в образе).
12. ✅ **Метрики Prometheus** *(сделано 2026-10-01)*: `GET /metrics` в текстовом формате Prometheus без
    авторизации — гистограмма `risk_profile_cvd_http_request_duration_seconds{method,path,status,host}`
    со стандартными бакетами, контракт как у ядра. Значения суммируются по воркерам: образ задаёт
    `PROMETHEUS_MULTIPROC_DIR`, точка входа `python -m src` очищает директорию до запуска воркеров.
    `CVD_METRICS__ENABLED=false` отключает экспозицию (404). Описание, PromQL и проверка на стенде —
    [docs/metrics.md](./docs/metrics.md).

## Открытые вопросы

*Технические вопросы закрыты (2026-06-02). Остаётся только зона аналитики/ядра.*

- ✅ **Источник модели — решено**: вшиваем в образ (`COPY src/`), версионирование не делаем
  (обновление = пересборка образа). Следствие — `scikit-learn==1.6.1` запинен под версию обучения.
- ✅ **Контракт `/calculate` — финализирован** (см. «Контракт API (финал)» в INTEGRATION_DECISIONS.md):
  `{period?, riskFactors{12 non-null}}` → `{isSuccess, period, score, riskPercentage, calculatedAt}`,
  ошибки в envelope. Альбина подтянет в аналитику по факту.
- **Маппинг фич ↔ параметры каталога** — ответственность **core-сервиса** (адаптер перед
  вызовом `/calculate`), не данного сервиса. По `FAM_IHD_CVA` уточнено: целевой параметр —
  `family_acute_cvd`, но он пока не описан в аналитике.

## Текущее состояние репозитория

**FastAPI-сервис (основной путь):**
- `src/__main__.py` — точка входа процесса (`python -m src`, `CMD` образа): подготовка директории
  метрик и запуск uvicorn.
- `src/main.py` — приложение: `lifespan` грузит модель один раз, middleware с `requestId` и
  middleware метрик, `/health`/`/readiness`/`/liveness`, `/metrics`, обработчики ошибок (envelope).
- `src/metrics.py`, `src/api/middleware.py` — метрики Prometheus (см. [docs/metrics.md](./docs/metrics.md)).
- `src/config.py` — pydantic-settings (префикс `CVD_`, `LOG_LEVEL`).
- `src/logger.py` — полный логгер в стиле core (Monolog-JSON, fingers-crossed, маск. PII,
  `business`/`notice`/`alert`/`emergency`, requestId).
- `scripts/check_logger_info.py` — линтер запрета прямых INFO-логов (`make lint-logger`).
- `tests/test_logger.py`, `tests/scripts/test_check_logger_info.py` — тесты логгера и линтера.
- `src/api/` — `schemas.py` (CamelModel), `errors.py` (envelope + handlers),
  `v1/calculation/` (`POST /api/v1/calculate` + схемы).
- `src/calc/domain/` — `calculator.py` (CvdCalculator), `consts.py` (CVD_FEATURES, периоды),
  `models.py`, `exceptions.py`; `src/calc/infra/model_loader.py` — загрузка артефактов.
- `Dockerfile`, `docker-compose.yml`, `.dockerignore`, `.env.example` — запуск через `python -m src`
  (non-root), модель вшита в образ (`COPY src/`). Локально: `docker compose up --build`,
  `python -m src` или `uvicorn src.main:app`. Рядом с ядром: `docker compose --profile cvd up` из репо ядра.

**Легаси (под ретайр):**
- `src/calculator.py` + `scripts/run_calculation.py` — старый CLI-батч (ещё работает, будет удалён).

**Артефакты и общее:**
- `utils/modeling.py` — кастомные классы для распаковки моделей.
- `src/models/`, `src/data/` — артефакты моделей и incidence-таблицы.
- `tests/test_data/input_cvd.json` — пример входа/выхода (baseline-контракт, illustrative).
- `Makefile`, `pyproject.toml` — от baseline; `pyproject` дополнен fastapi/uvicorn/pydantic-settings.
