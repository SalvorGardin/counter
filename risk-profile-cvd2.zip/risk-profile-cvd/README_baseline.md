# Biomarker Calculator

Калькулятор для расчета биологического возраста и кардиориска по биомаркерам.

## Быстрый старт

```bash
# Запустить все тесты
make up

# Результаты появятся в tests/output/
```

## 📝 Как использовать

1. Положить JSON с данными в `tests/test_data/`
2. Запустить `make up`
3. Результаты в `tests/output/`

## 📊 Формат входного JSON

```json
{
  "input": {
    "biomarker_entries": [...],
    "model_metadata": {
      "model_type": "biological_age",  // или "cardiovascular_risk"
      "ba_model_path": "src/models/age_model.pkl",
      "risk_model_path": "src/models/risk_model.pickle"
    }
  }
}
```

## 🛠️ Команды

```bash
make build      # Собрать Docker образ
make up         # Запустить расчеты
make test       # Запустить тесты
make clean      # Очистить все
```

## 📁 Структура

```
├── src/
│   ├── calculator.py    # Основной код
│   ├── models/          # Модели
│   └── data/            # Данные
├── tests/
│   ├── test_data/       # Входные JSON
│   └── output/          # Результаты
└── scripts/             # CLI скрипт
└── utils/               # Утилиты для расчета кардиориска
    └── __init__.py
    └── modeling.py
```