"""Risk Profile CVD Service — FastAPI-обёртка вокруг ML-калькулятора риска ССЗ.

Процесс запускается через `python -m src` (см. `src/__main__.py`).
"""

import asyncio
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Response, status
from fastapi.exceptions import RequestValidationError
from prometheus_client import CONTENT_TYPE_LATEST
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.api.errors import (
    calculation_error_handler,
    http_exception_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from src.api.middleware import MetricsMiddleware
from src.api.request_context import RequestContextMiddleware
from src.api.v1.calculation.router import router as calculation_router
from src.calc.domain.calculator import CvdCalculator
from src.calc.domain.exceptions import CalculationError
from src.calc.infra.model_loader import load_models
from src.config import settings
from src.logger import notice
from src.metrics import render


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Грузим модель один раз при старте и держим резидентно в app.state."""
    notice("service starting", {"default_period": settings.default_period})
    models = load_models(settings.models_dir, settings.data_dir)
    app.state.calculator = CvdCalculator(models)
    # Cap на одновременные инференсы внутри воркера — семафор создаётся в живом event loop.
    app.state.calc_semaphore = asyncio.Semaphore(settings.max_concurrency)
    notice(
        "models loaded",
        {
            "periods": app.state.calculator.supported_periods(),
            "max_concurrency": settings.max_concurrency,
        },
    )
    try:
        yield
    finally:
        notice("service stopping")


app = FastAPI(title="Risk Profile CVD Service", lifespan=lifespan)

app.add_exception_handler(RequestValidationError, validation_exception_handler)  # type: ignore[arg-type]
app.add_exception_handler(StarletteHTTPException, http_exception_handler)  # type: ignore[arg-type]
app.add_exception_handler(CalculationError, calculation_error_handler)  # type: ignore[arg-type]
app.add_exception_handler(Exception, unhandled_exception_handler)
app.include_router(calculation_router)

# Пробы и скрейп метрик: в лог они пишутся DEBUG-записью `probe request` вместо NOTICE
# `request completed` и не учитываются в HTTP-гистограмме. /metrics здесь, потому что Prometheus
# опрашивает его по расписанию бессрочно — иначе скрейп засорял бы логи и метрики запросов.
_PROBE_PATHS = {"/health", "/readiness", "/liveness", "/", "/metrics"}
app.add_middleware(RequestContextMiddleware, probe_paths=_PROBE_PATHS)
# Мидлварь метрик регистрируется после RequestContextMiddleware намеренно: последняя зарегистрированная
# мидлварь — внешний слой, поэтому наблюдение включает отправку ответа и запись `request completed`.
# Обе мидлвари — чистый ASGI: через `@app.middleware("http")` (BaseHTTPMiddleware) каждый запрос нёс бы
# накладные расходы call_next, а наблюдение заканчивалось бы на заголовках ответа, до отправки тела и лога.
app.add_middleware(MetricsMiddleware, probe_paths=_PROBE_PATHS)


@app.get("/health")
def health() -> dict[str, str]:
    """Healthcheck."""
    return {"status": "ok"}


@app.get("/readiness")
def readiness() -> dict[str, str]:
    """Readiness probe."""
    return {"status": "ready"}


@app.get("/liveness")
def liveness() -> dict[str, str]:
    """Liveness probe."""
    return {"status": "alive"}


@app.get("/metrics")
def metrics() -> Response:
    """Метрики Prometheus в текстовом формате.

    Без авторизации, как и пробы: в выдаче только агрегаты и шаблоны маршрутов, данных запросов
    нет. Обработчик синхронный — FastAPI исполняет его в пуле потоков, и чтение файлов значений
    воркеров не блокирует event loop. При `CVD_METRICS__ENABLED=false` ручка отвечает 404, а сбор
    наблюдений продолжается.
    """
    if not settings.metrics.enabled:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Metrics endpoint is disabled")
    return Response(content=render(), media_type=CONTENT_TYPE_LATEST)
