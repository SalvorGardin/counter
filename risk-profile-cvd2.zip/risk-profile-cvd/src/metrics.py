"""Метрики Prometheus сервиса: единственное место, где они создаются.

Экспозиция — `GET /metrics` (`src/main.py`), подготовка директории multiprocess-режима — точка
входа `src/__main__.py`.

Модуль не импортирует `src.config` и `src.logger`: из конфигурации ему нужна только переменная
окружения библиотеки, а без этих связей его можно импортировать отдельно от приложения (точка
входа, подпроцессы тестов) и без риска цикла импортов.
"""

import os
import socket
from glob import glob

from prometheus_client import (
    GC_COLLECTOR,
    PLATFORM_COLLECTOR,
    PROCESS_COLLECTOR,
    REGISTRY,
    CollectorRegistry,
    Histogram,
    disable_created_metrics,
    generate_latest,
)
from prometheus_client.multiprocess import MultiProcessCollector

SERVICE_PREFIX = "risk_profile_cvd"

# Лейбл `host` — имя хоста контейнера сервиса. Считается один раз: внутри процесса оно не меняется.
# Заголовок `Host` запроса для этого не годится: его значение задаёт клиент.
HOSTNAME = socket.gethostname()

# Переменная, включающая multiprocess-режим prometheus_client (задаётся в Dockerfile). Библиотека
# читает её при импорте и по ней выбирает, где хранить значения метрик, поэтому включить режим из
# кода приложения нельзя — только окружением процесса.
MULTIPROC_ENV = "PROMETHEUS_MULTIPROC_DIR"

# Снимок режима, сделанный одновременно с выбором хранилища значений внутри prometheus_client.
# render() опирается на снимок, а не на окружение в момент скрейпа: иначе он мог бы собирать выдачу
# из файлов, пока значения лежат в памяти процесса (или наоборот), и отдать пустую, но валидную выдачу.
_MULTIPROC_PATH = os.environ.get(MULTIPROC_ENV, "")


def _ensure_multiproc_dir() -> None:
    """Создаёт директорию multiprocess-режима, если она задана.

    Штатно её готовит точка входа (`prepare_multiproc_dir`), но при запуске в обход неё
    (`uvicorn src.main:app`) директории может не быть: тогда первый `.labels()` упал бы при
    открытии файла значений, и запрос получил бы 500.
    """
    path = os.environ.get(MULTIPROC_ENV, "")
    if path:
        os.makedirs(path, exist_ok=True)


_ensure_multiproc_dir()

# ПРАВИЛО: здесь только метрики с лейблами, и ряды не заводятся через `.labels()` при импорте.
# В multiprocess-режиме процесс открывает свой файл значений при первом `.labels()` (метрика без
# лейблов — сразу при создании). При CVD_WORKERS=1 точка входа очищает директорию в том же процессе,
# который затем обслуживает запросы: файл, открытый до очистки, был бы удалён, и все наблюдения
# процесса пропали бы из выдачи.
HTTP_REQUEST_DURATION = Histogram(
    f"{SERVICE_PREFIX}_http_request_duration_seconds",
    "Латентность входящих HTTP-запросов",
    ["method", "path", "status", "host"],
)


def _align_with_multiprocess_output() -> None:
    """Делает однопроцессную выдачу такой же, как multiprocess-выдача в контейнере.

    В multiprocess-режиме выдача собирается только из файлов значений: штатных метрик процесса
    (`process_*`, `python_*`) и рядов `_created` в ней нет. Без этого шага локальный запуск и тесты
    видели бы больше, чем отдаёт контейнер.
    """
    for collector in (PROCESS_COLLECTOR, PLATFORM_COLLECTOR, GC_COLLECTOR):
        try:
            REGISTRY.unregister(collector)
        except KeyError:
            # Коллектор уже снят — повторный вызов не ошибка.
            continue
    disable_created_metrics()


_align_with_multiprocess_output()


def prepare_multiproc_dir() -> None:
    """Готовит директорию multiprocess-режима к новому запуску: создаёт её и удаляет `*.db`.

    Вызывается точкой входа до запуска воркеров uvicorn. ФС контейнера переживает рестарт, а PID
    процессов в новом запуске совпадают с прежними: без очистки prometheus_client продолжил бы счёт
    в прежних файлах, а файлы процессов, которых больше нет, попали бы в сумму. Очистка именно при
    старте: при аварийном завершении код остановки не выполняется. Из воркера вызывать нельзя —
    удалит файлы работающих соседей. Без переменной окружения ничего не делает.
    """
    path = os.environ.get(MULTIPROC_ENV, "")
    if not path:
        return
    os.makedirs(path, exist_ok=True)
    for stale in glob(os.path.join(path, "*.db")):
        os.remove(stale)


def render() -> bytes:
    """Тело ответа `GET /metrics` в текстовом формате Prometheus."""
    if _MULTIPROC_PATH:
        # Новый реестр на каждый скрейп: коллектор читает файлы всех процессов в момент сборки,
        # и суммы по процессам считаются при каждом чтении заново.
        registry = CollectorRegistry()
        MultiProcessCollector(registry, path=_MULTIPROC_PATH)
        return generate_latest(registry)
    return generate_latest(REGISTRY)
