"""Monolog-совместимый JSON-логгер для risk-profile-cvd.

Портирован 1:1 со стиля `risk-profile-core` (см. там `src/logger.py` и
`docs/requirements/logging.md`): единая точка входа `logger` + хелперы `notice`/`business`/
`alert`/`emergency`, кастомные Monolog-уровни, fingers-crossed буфер на запрос, маскирование
PII и сквозной requestId/authorization из ContextVar'ов.

PII-замечание для этого сервиса: значения биомаркеров (12 фич CVD) — чувствительные данные,
их НЕЛЬЗЯ логировать. Сервис по дизайну пишет только факт/период/статус. Санитайзер ниже —
последний рубеж: если кто-то положит фичи в `context`, значения замаскируются.
"""

import functools
import json
import logging
import sys
import uuid
from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any, TypeVar

# PEP 695 (`def f[T]`) — только с 3.12; сервис таргетит 3.11, поэтому классический TypeVar.
T = TypeVar("T")

# --- Per-request context vars ---
# Вне request-контекста все логи разделяют один startup-UUID для корреляции.
# Middleware переопределяет значение для каждого входящего запроса.
request_id_var: ContextVar[str] = ContextVar("request_id", default=str(uuid.uuid4()))
authorization_var: ContextVar[str | None] = ContextVar("authorization", default=None)
debug_enabled_var: ContextVar[bool] = ContextVar("debug_enabled", default=False)
# Нормализованное значение X-Enable-Debug для прокидывания в downstream-сервисы.
# Middleware приводит к canonical "true"/"" — сырое клиентское значение наружу не уходит
# (защита от длинных пэйлоадов и инъекций в headers, см. src/api/request_context.py).
x_enable_debug_var: ContextVar[str] = ContextVar("x_enable_debug", default="")


# --- Fingers-crossed (per-request INFO buffer) ---
# Паттерн из Monolog: INFO копится в буфере и выводится только если в этом же запросе
# случился ERROR+. Реализован через ContextVar — буферы разных запросов изолированы (async-safe).
# Только для HTTP — для фоновых задач спека прямо запрещает: длинный процесс может копить
# буфер бесконечно. Middleware создаёт буфер на входе и сбрасывает на выходе.
class FingersBuffer:
    __slots__ = ("records", "triggered")

    def __init__(self) -> None:
        self.records: list[logging.LogRecord] = []
        self.triggered: bool = False


fingers_crossed_var: ContextVar[FingersBuffer | None] = ContextVar("fingers_crossed", default=None)

# --- Business channel ---
# INFO + channel="business" — единственный легальный путь писать info в проде постоянно,
# в обход fingers-crossed. Для бизнес-событий и аудит-точек.
BUSINESS_CHANNEL = "business"

# --- Custom Monolog levels (не покрытые стандартным logging) ---
NOTICE = 25
ALERT = 55
EMERGENCY = 60

logging.addLevelName(NOTICE, "NOTICE")
logging.addLevelName(ALERT, "ALERT")
logging.addLevelName(EMERGENCY, "EMERGENCY")

_MONOLOG_CODES: dict[int, int] = {
    logging.DEBUG: 100,
    logging.INFO: 200,
    NOTICE: 250,
    logging.WARNING: 300,
    logging.ERROR: 400,
    logging.CRITICAL: 500,
    ALERT: 550,
    EMERGENCY: 600,
}

_LEVEL_NAME_TO_NUM: dict[str, int] = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "NOTICE": NOTICE,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
    "ALERT": ALERT,
    "EMERGENCY": EMERGENCY,
}

# --- PII guard ---
# Превентивная маскировка значений по ключам в context (сравнение по lowercase). Список —
# доменно-стабилен, правится через code-review. Точечные утечки фиксятся в коде, санитайзер —
# последний рубеж. Stacktrace в context["exception"] не маскируется — не логируем переменные
# в исключениях. Для CVD добавлены имена 12 фич модели: их значения — чувствительные данные.
_PII_KEYS: frozenset[str] = frozenset(
    {
        # антропометрия / контакты / идентификаторы (как в core)
        "birthdate",
        "dob",
        "date_of_birth",
        "height",
        "weight",
        "bmi",
        "phone",
        "phone_number",
        "mobile",
        "email",
        "passport",
        "passport_number",
        "snils",
        "inn",
        "fio",
        "full_name",
        "first_name",
        "last_name",
        "middle_name",
        "patronymic",
        # значения фич CVD-модели (биомаркеры) — не логировать значения
        "features",
        "age",
        "sex",
        "sbp",
        "lpa",
        "hdl_chol",
        "ldl_chol",
        "lipid_drugs",
        "as",
        "dm",
        "fam_ihd_cva",
        "fam_hypchol",
    }
)
_PII_MASK = "***"


def _sanitize_context(ctx: dict[str, Any]) -> dict[str, Any]:
    """Маскирует значения ключей из _PII_KEYS (сравнение по lowercase)."""
    if not ctx:
        return ctx
    return {k: (_PII_MASK if k.lower() in _PII_KEYS else v) for k, v in ctx.items()}


def exception_without_message(exc: BaseException) -> BaseException:
    """Исключение того же типа без текста, с исходным traceback — для `exc_info` там, где текст может
    содержать ПДн.

    В лог попадают тип исключения и стек вызовов, а сообщение — нет: у библиотек оно может включать
    значения входных данных (например, значение признака, на котором упал расчёт). Связанные
    исключения (`__cause__`, `__context__`) в копию не переносятся по той же причине.
    """
    try:
        redacted = type(exc).__new__(type(exc))
    except TypeError:
        # Тип требует аргументов уже при создании — остаётся только его имя.
        redacted = Exception(type(exc).__name__)
    return redacted.with_traceback(exc.__traceback__)


def _resolve_level(name: str) -> int:
    return _LEVEL_NAME_TO_NUM.get(name.upper(), NOTICE)


def _threshold() -> int:
    """Лениво читает порог из settings. Если конфиг ещё не валиден на старте, не роняем логгер —
    иначе саму ошибку конфига негде залогировать."""
    try:
        from src.config import settings  # noqa: PLC0415
    except Exception:
        return NOTICE
    return _resolve_level(settings.log_level)


class MonologFilter(logging.Filter):
    """Гейтит DEBUG (только при X-Enable-Debug). Внутри request-контекста (fingers_crossed_var
    установлен) пропускает все INFO+ — финальное решение принимает FingersCrossedHandler. Вне
    request-контекста — уровень >= settings.log_level.

    Исключение: INFO с channel="business" выходит всегда, независимо от threshold и
    fingers-crossed — узаконенный канал для «всегда писать» бизнес-событий."""

    def filter(self, record: logging.LogRecord) -> bool:
        if debug_enabled_var.get():
            return True
        if record.levelno < logging.INFO:
            return False
        if getattr(record, "channel", "app") == BUSINESS_CHANNEL:
            return True
        if fingers_crossed_var.get() is not None:
            return True
        return record.levelno >= _threshold()


class FingersCrossedHandler(logging.Handler):
    """Per-request буфер INFO. Логи ниже штатного порога копятся в FingersBuffer из ContextVar;
    при появлении ERROR+ в том же запросе — буфер сливается в хронологическом порядке, после чего
    handler работает passthrough до конца запроса. Без триггера буфер выбрасывается при сбросе
    ContextVar (в middleware). Вне request-контекста или с X-Enable-Debug — passthrough сразу."""

    def __init__(self, target: logging.Handler) -> None:
        super().__init__()
        self._target = target

    def emit(self, record: logging.LogRecord) -> None:
        # Используем target.handle() (не emit) — handle берёт target.lock перед записью в stdout.
        # При concurrent выводе из threadpool прямой emit() порождал бы interleaved-байты на
        # уровне stream, ломая отдельные JSON-строки.
        buf = fingers_crossed_var.get()
        if buf is None or debug_enabled_var.get():
            self._target.handle(record)
            return

        # channel="business" — постоянный канал, мимо буфера.
        if getattr(record, "channel", "app") == BUSINESS_CHANNEL:
            self._target.handle(record)
            return

        # ERROR+ триггерит буфер: выводим всё накопленное в хронологическом порядке до самой записи.
        if record.levelno >= logging.ERROR and not buf.triggered:
            buf.triggered = True
            for rec in buf.records:
                self._target.handle(rec)
            buf.records.clear()

        if buf.triggered or record.levelno >= _threshold():
            self._target.handle(record)
        else:
            buf.records.append(record)


class MonologFormatter(logging.Formatter):
    """Форматирует записи в JSON по стандарту Monolog."""

    def format(self, record: logging.LogRecord) -> str:
        context: dict[str, Any] = _sanitize_context(dict(getattr(record, "log_context", {})))
        if record.exc_info:
            context["exception"] = self.formatException(record.exc_info)

        # record.created — момент вызова logger.X(); важно для буферизованных записей,
        # которые форматируются позже (на флаше из FingersCrossedHandler) — иначе все INFO
        # получили бы timestamp ошибки и потеряли хронологию.
        entry = {
            "message": record.getMessage(),
            "level": _MONOLOG_CODES.get(record.levelno, 200),
            "level_name": logging.getLevelName(record.levelno),
            "channel": getattr(record, "channel", "app"),
            "datetime": datetime.fromtimestamp(record.created, tz=UTC).astimezone().isoformat(timespec="microseconds"),
            "context": context,
            "extra": {
                "requestId": request_id_var.get(),
                "authorization": authorization_var.get(),
            },
        }
        return json.dumps(entry, ensure_ascii=False)


def _make_logger() -> logging.Logger:
    log = logging.getLogger("app")
    if log.handlers:
        return log
    log.setLevel(logging.DEBUG)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(MonologFormatter())
    # Filter — на FingersCrossedHandler, чтобы DEBUG отсекался до буфера и не оседал в нём.
    fc = FingersCrossedHandler(stream)
    fc.addFilter(MonologFilter())
    log.addHandler(fc)
    log.propagate = False
    return log


logger = _make_logger()


def _log(level: int, message: str, context: dict[str, Any] | None = None) -> None:
    logger.log(level, message, extra={"log_context": context or {}})


def notice(message: str, context: dict[str, Any] | None = None) -> None:
    """Штатное отклонение, видимое в проде (NOTICE — всегда выходит)."""
    _log(NOTICE, message, context)


def business(message: str, context: dict[str, Any] | None = None) -> None:
    """Бизнес-событие на канале "business". INFO-уровень, но выходит всегда (мимо fingers-crossed
    и порога) — единственный легальный способ писать info в проде постоянно."""
    logger.log(
        logging.INFO,
        message,
        extra={"log_context": context or {}, "channel": BUSINESS_CHANNEL},
    )


def alert(message: str, context: dict[str, Any] | None = None) -> None:
    _log(ALERT, message, context)


def emergency(message: str, context: dict[str, Any] | None = None) -> None:
    _log(EMERGENCY, message, context)


def with_request_context(task: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """Snapshot request-ContextVar'ов сейчас + восстановление при вызове в фоновой задаче.

    Зачем: сквозной requestId для логов фоновых операций, порождённых API-запросом. FastAPI
    BackgroundTasks обычно сохраняет ContextVar'ы через event loop, но это implementation detail
    Starlette; явный wrapper делает контракт самодокументирующим и переживает переход задачи на
    sync (run_in_threadpool).

    Снимаем все request-vars кроме fingers_crossed_var: для фоновых задач fingers-crossed
    запрещён (риск бесконечного буфера в долгом процессе) — изолируем force-set в None.

    Использование:
        background.add_task(with_request_context(task), *args)
    """
    req_id = request_id_var.get()
    auth = authorization_var.get()
    debug = debug_enabled_var.get()
    x_debug = x_enable_debug_var.get()

    @functools.wraps(task)
    async def wrapped(*args: object, **kwargs: object) -> T:
        t_req = request_id_var.set(req_id)
        t_auth = authorization_var.set(auth)
        t_dbg = debug_enabled_var.set(debug)
        t_x = x_enable_debug_var.set(x_debug)
        t_fc = fingers_crossed_var.set(None)
        try:
            return await task(*args, **kwargs)
        finally:
            fingers_crossed_var.reset(t_fc)
            x_enable_debug_var.reset(t_x)
            debug_enabled_var.reset(t_dbg)
            authorization_var.reset(t_auth)
            request_id_var.reset(t_req)

    return wrapped
