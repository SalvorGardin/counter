from typing import Union
import json
import pandas as pd
import joblib
from datetime import datetime
import warnings
from pathlib import Path
from utils.modeling import table_to_risk_AIRI

warnings.filterwarnings('ignore', category=UserWarning)


class UniversalBiomarkerCalculator:
    @staticmethod
    def _normalize_path(path: str) -> str:
        if not path:
            return path
        
        path = str(path).replace('\\', '/')
        
        if path.startswith('./'):
            path = path[2:]
        
        if not path.startswith('src/'):
            if path.startswith('models/') or path.startswith('data/'):
                path = f'src/{path}'
        
        print(f"🔄 Путь нормализован: {path}")
        return path
    
    def _calculate_score(self, model_path: str, input_data: pd.DataFrame) -> float:
        try:
            model_path = self._normalize_path(model_path)
            print(f"🔍 Загрузка модели из: {model_path}")
            print(f"📊 Входные данные: {input_data.to_dict()}")
            
            from pathlib import Path
            if not Path(model_path).exists():
                print(f"❌ Файл не найден: {model_path}")
                return 0.0
            
            model = joblib.load(model_path)
            print(f"✅ Модель загружена: {type(model)}")
            
            risk = model.predict_proba(input_data)[:, 1][0]
            print(f"📈 Рассчитанный риск: {risk * 100:.2f}%")
            return float(risk * 100)
        except FileNotFoundError as e:
            print(f"❌ Error: Model file not found: {model_path}")
            print(f"   Exception: {e}")
            return 0.0
        except AttributeError as e:
            print(f"❌ Error: Model doesn't have predict_proba method: {e}")
            print(f"   Model type: {type(model) if 'model' in locals() else 'N/A'}")
            return 0.0
        except Exception as e:
            print(f"❌ Error in risk calculation: {e}")
            print(f"   Type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return 0.0
    
    def _calculate_risk_from_intervals(self, intervals: list, value: float) -> float:
        for interval in intervals:
            if interval["left"] <= value <= interval["right"]:
                return float(interval["risk"])
        return 0.0
    
    def _prepare_dataframe(self, biomarker_entries: list) -> pd.DataFrame:
        biomarkers_data = {}
        
        for entry in biomarker_entries:
            key = entry["biomarker"]["key"]
            value = entry["value"]["value"]
            
            if value is None:
                biomarkers_data[key] = entry["biomarker"]["median"]
            else:
                biomarkers_data[key] = float(value)
        
        return pd.DataFrame([biomarkers_data])
    
    def _format_imputation_message(self, biomarker_entries: list) -> str:
        imputed = [e for e in biomarker_entries if e["value"]["status"] == "imputed"]
        
        if not imputed:
            return ""
        
        lines = [
            "**Обратите внимание:** Некоторые значения были заполнены автоматически "
            "на основе средних показателей:"
        ]
        
        for entry in imputed:
            bm = entry["biomarker"]
            value = entry["value"]["value"] or bm["median"]
            
            if bm["key"] in ["SEX", "sex"]:
                display = "мужской" if value == 1 else "женский"
            else:
                display = f"{float(value):{bm['fmt']}} {bm['unit']}".strip()
            
            lines.append(f"• {bm['name']}: **{display}**")
        
        return "\n".join(lines) + "\n\n"
    
    def _count_filled_imputed(self, biomarker_entries: list) -> tuple[int, int]:
        filled = sum(1 for e in biomarker_entries if e["value"]["status"] == "filled")
        imputed = sum(1 for e in biomarker_entries if e["value"]["status"] == "imputed")
        return filled, imputed
    
    def process_cardiovascular_risk(self, input_data: dict) -> dict:
        biomarker_entries = input_data["biomarker_entries"]
        metadata = input_data["model_metadata"]
        
        df = self._prepare_dataframe(biomarker_entries)

        if metadata.get("table_incidence"):
            score = self._calculate_score(metadata["risk_model_path"], df)
            incidence_path = self._normalize_path(metadata["table_incidence"])
            df_incidence = pd.read_csv(
                incidence_path,
                index_col=0,
                header=[0, 1]
            ).round(2)
            risk_percentage = table_to_risk_AIRI(score, df_incidence)
        else:
            score = self._calculate_score(metadata["risk_model_path"], df)
            risk_percentage = self._calculate_risk_from_intervals(
                metadata["intervals"],
                score
            )
        
        filled_count, imputed_count = self._count_filled_imputed(biomarker_entries)
        imputed_msg = self._format_imputation_message(biomarker_entries)
        
        result_msg = (
            f"**Результат оценки риска ССЗ ({metadata['name']}):**\n"
            f"Ваш риск сердечно-сосудистых заболеваний: **{risk_percentage:.1f}%**\n"
            "Оценка риска завершена."
        )
        
        chronological_age = None
        for entry in biomarker_entries:
            if entry["biomarker"]["key"] in ["AGE", "Age"]:
                chronological_age = entry["value"]["value"] or entry["biomarker"]["median"]
                break
        
        return {
            "output": {
                "interview_state": {
                    "last_marker_asked": None,
                    "status": "COMPLETED",
                    "filled_count": filled_count,
                    "imputed_count": imputed_count
                },
                "final_message": f"{imputed_msg}{result_msg}",
                "calculation_results": {
                    "score": round(score, 1),
                    "risk_percentage": round(risk_percentage, 1),
                    "calculated_at": datetime.now().isoformat(),
                    "biological_age": None,
                    "chronological_age": chronological_age,
                    "delta": None,
                    "trend": None
                }
            }
        }
    
    def process(self, input_json: Union[str, dict]) -> dict:
        if isinstance(input_json, str):
            data = json.loads(input_json)
        else:
            data = input_json
        
        input_data = data["input"]
        model_type = input_data["model_metadata"]["model_type"]
        
        if model_type == "cardiovascular_risk":
            return self.process_cardiovascular_risk(input_data)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")