"""Схемы эндпоинта расчёта риска ССЗ.

Контракт финализирован (см. «Контракт API (финал)» в INTEGRATION_DECISIONS.md). Клиент
(risk-profile-core) вызывает сервис, только когда собраны ВСЕ данные: 12 факторов риска —
обязательные поля объекта `riskFactors`, каждый NOT NULL (тип `float`, не `float | None` —
pydantic отклонит `null` на входе). Отсутствующее/лишнее поле → 400 (валидация pydantic,
`extra="forbid"` в CamelModel; см. validation_exception_handler) — отдельный самописный валидатор
больше не нужен.

Имена полей — по фичам CVD-модели (camelCase в JSON: `systolicBp`, `lipoproteinA`, …); их
соответствие точным именам модели (`CVD_FEATURES`) задаёт `CvdRiskFactors._FIELD_TO_FEATURE`,
а порядок строки для инференса — сам `CVD_FEATURES` (источник истины порядка).

Импутация пропусков медианой обучающей выборки сейчас **выключена**. Если решим, что часть
факторов может приходить пустой, её можно включить — см. закомментированный хук в
`src/calc/domain/calculator.py`; тогда типы полей здесь меняем на `float | None`.
"""

from datetime import datetime
from typing import Annotated, ClassVar

from pydantic import AfterValidator, Field, WithJsonSchema
from pydantic_core import PydanticCustomError

from src.api.errors import SuccessEnvelope
from src.api.schemas import CamelModel
from src.calc.domain.consts import CVD_FEATURES, Period


def _zero_or_one(value: float) -> float:
    if value not in (0.0, 1.0):
        raise PydanticCustomError("binary_flag", "Input should be 0 or 1")
    return value


# Категориальный признак, закодированный адаптером core: только 0 или 1. Иное значение — вне кодировки:
# для пола расчёт всё равно откажет (пол выбирает подмодель), а для остальных флагов модель молча дала бы
# результат по невалидному входу. Поэтому оно отклоняется на границе — 400 с кодом поля.
BinaryFlag = Annotated[float, AfterValidator(_zero_or_one), WithJsonSchema({"type": "number", "enum": [0, 1]})]


class CvdRiskFactors(CamelModel):
    """12 факторов риска CVD-модели — уже закодированные числа.

    Перекодировка (пол / «Да»-«Нет» → 1/0), агрегация и `str → float` — ответственность
    адаптера в core; сюда приходят готовые `float`. Все поля обязательны и NOT NULL.
    Категориальные: `sex` (1=муж, 0=жен); `lipid_drugs` / `atherosclerosis` / `diabetes` /
    `fam_*` (1=«Да», 0=«Нет»).
    """

    # Границы на входе — защита на границе доверия: вне-доменные значения (sex=99, bmi=-5) иначе
    # молча уходят в модель и дают мусорный скор как isSuccess=true. Флаги — только 0 или 1; непрерывные —
    # правдоподобные клинические рамки. Лимиты широкие, чтобы не отсекать реальные выбросы (липиды —
    # только неотрицательность: верх не ограничиваем, Lp(a)/ЛПНП бывают высокими).
    age: float = Field(ge=0, le=120, description="Возраст, лет")  # AGE
    sex: BinaryFlag = Field(description="Пол: 1=муж, 0=жен")  # SEX
    bmi: float = Field(ge=10, le=100, description="Индекс массы тела, кг/м²")  # BMI
    systolic_bp: float = Field(ge=50, le=300, description="Систолическое АД, мм рт.ст.")  # SBP
    lipoprotein_a: float = Field(ge=0, description="Липопротеин (а), мг/дл")  # LPA
    hdl_chol: float = Field(ge=0, description="ЛПВП («хороший» холестерин), ммоль/л")  # HDL_CHOL
    ldl_chol: float = Field(ge=0, description="ЛПНП («плохой» холестерин), ммоль/л")  # LDL_CHOL
    lipid_drugs: BinaryFlag = Field(description="Приём липидоснижающих препаратов: 1/0")  # LIPID_DRUGS
    atherosclerosis: BinaryFlag = Field(description="Атеросклероз: 1/0")  # AS
    diabetes: BinaryFlag = Field(description="Сахарный диабет (1/2 типа): 1/0")  # DM
    fam_ihd_cva: BinaryFlag = Field(description="Семейный анамнез раннего ССЗ: 1/0")  # FAM_IHD_CVA
    fam_hypchol: BinaryFlag = Field(description="Семейная гиперхолестеринемия: 1/0")  # FAM_HYPCHOL

    # Имя поля → точное имя фичи модели. Порядок численной строки задаёт CVD_FEATURES.
    _FIELD_TO_FEATURE: ClassVar[dict[str, str]] = {
        "age": "AGE",
        "sex": "SEX",
        "bmi": "BMI",
        "systolic_bp": "SBP",
        "lipoprotein_a": "LPA",
        "hdl_chol": "HDL_CHOL",
        "ldl_chol": "LDL_CHOL",
        "lipid_drugs": "LIPID_DRUGS",
        "atherosclerosis": "AS",
        "diabetes": "DM",
        "fam_ihd_cva": "FAM_IHD_CVA",
        "fam_hypchol": "FAM_HYPCHOL",
    }

    def to_model_values(self) -> tuple[float, ...]:
        """Численная строка в порядке CVD_FEATURES без промежуточных словарей."""
        return tuple(getattr(self, self._FEATURE_TO_FIELD[name]) for name in CVD_FEATURES)

    _FEATURE_TO_FIELD: ClassVar[dict[str, str]] = {feature: field for field, feature in _FIELD_TO_FEATURE.items()}


class CalculateRequest(CamelModel):
    # Период модели; если не указан — берётся settings.default_period.
    period: Period | None = None
    # 12 факторов риска (объект `riskFactors`). Обязательность/типы/non-null валидирует CvdRiskFactors.
    risk_factors: CvdRiskFactors


class CalculateResponse(SuccessEnvelope):
    # Наследует isSuccess=true от SuccessEnvelope — симметрично ErrorEnvelope, как в core.
    period: str
    score: float
    risk_percentage: float
    calculated_at: datetime
