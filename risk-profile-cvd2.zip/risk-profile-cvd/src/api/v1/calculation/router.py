"""Роутер расчёта риска ССЗ."""

import asyncio
import time
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from starlette.concurrency import run_in_threadpool

from src.api.errors import common_responses
from src.api.v1.calculation.schemas import CalculateRequest, CalculateResponse
from src.calc.domain.calculator import CvdCalculator
from src.calc.domain.models import CvdResult
from src.config import settings
from src.logger import business

router = APIRouter(prefix="/api/v1", tags=["calculation"])


async def get_calculator(request: Request) -> CvdCalculator:
    """DI: калькулятор с резидентной моделью, поднятый в lifespan (app.state.calculator)."""
    return request.app.state.calculator


async def get_semaphore(request: Request) -> asyncio.Semaphore:
    """DI: семафор-cap на одновременные инференсы внутри воркера (app.state.calc_semaphore)."""
    return request.app.state.calc_semaphore


# Async-эндпоинт: cap держим семафором, а блокирующий CPU-bound инференс уводим в threadpool
# (run_in_threadpool), чтобы event loop не вставал. Число воркеров и cap — конфигом (CVD_WORKERS,
# CVD_MAX_CONCURRENCY).
@router.post(
    "/calculate",
    response_model=CalculateResponse,
    responses=common_responses,
    summary="Рассчитать риск сердечно-сосудистых заболеваний",
)
async def post_calculate(
    payload: CalculateRequest,
    request: Request,
    calculator: Annotated[CvdCalculator, Depends(get_calculator)],
    semaphore: Annotated[asyncio.Semaphore, Depends(get_semaphore)],
) -> CalculateResponse:
    period = payload.period or settings.default_period
    timings: dict[str, float | str] = {"period": period}
    request.state.calc_timings = timings
    wait_started = time.perf_counter()
    async with semaphore:
        timings["calc_semaphore_wait_ms"] = (time.perf_counter() - wait_started) * 1000
        row = payload.risk_factors.to_model_values()
        dispatched = time.perf_counter()

        def calculate() -> CvdResult:
            started = time.perf_counter()
            timings["calc_thread_wait_ms"] = (started - dispatched) * 1000
            try:
                return calculator.calculate_row(period, row)
            finally:
                timings["calc_duration_ms"] = (time.perf_counter() - started) * 1000

        result = await run_in_threadpool(calculate)
    # PII не логируем — только факт и период (значения биомаркеров наружу не уходят).
    business("cvd.calculate: completed", {"period": result.period})
    return CalculateResponse(
        period=result.period,
        score=result.score,
        risk_percentage=result.risk_percentage,
        calculated_at=datetime.now(UTC),
    )
