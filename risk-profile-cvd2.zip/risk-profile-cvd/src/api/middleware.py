"""ASGI-мидлварь метрик входящих HTTP-запросов."""

import time
from collections.abc import Set as AbstractSet

from starlette.routing import BaseRoute, Match, Route
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from src.logger import logger
from src.metrics import HOSTNAME, HTTP_REQUEST_DURATION

# Лейбл `method` — только белый список, остальное схлопывается в "other". Ручка /metrics открыта
# без авторизации, а метод задаёт клиент: без ограничения число рядов росло бы от его запросов.
_ALLOWED_METHODS = frozenset({"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"})
_OTHER_METHOD = "other"
# Запрос, не попавший ни в один маршрут. Сырой путь в лейбл не попадает никогда: его задаёт клиент.
_UNMATCHED_PATH = "unmatched"
# Маршруты, скрытые из схемы API (include_in_schema=False): их пути через /metrics не раскрываются.
_HIDDEN_PATH = "other"
# Статус запроса, на который приложение не начало ответ: его обработка завершилась необработанным
# исключением, и 500-ответ строит обработчик ошибок снаружи этой мидлвари.
_NO_RESPONSE_STATUS = "500"


class MetricsMiddleware:
    """Записывает одно наблюдение гистограммы на каждый HTTP-запрос, кроме `probe_paths`.

    Регистрируется в `src/main.py` после `RequestContextMiddleware` и потому оказывается внешним слоем.
    Наблюдение пишется, когда приложение закончило обработку запроса: ответ целиком передан HTTP-серверу
    и запись `request completed` выведена в лог. Статус берётся из начала ответа (`http.response.start`).
    Пути проб передаются параметром, а не импортом из `src.main`, чтобы не было цикла импортов.
    """

    def __init__(self, app: ASGIApp, probe_paths: AbstractSet[str]) -> None:
        self.app = app
        self.probe_paths = probe_paths

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        # Пробы и скрейп /metrics приходят постоянно и по расписанию: в гистограмме они бы
        # перевешивали запросы расчёта и искажали латентность сервиса.
        if scope["type"] != "http" or scope["path"] in self.probe_paths:
            await self.app(scope, receive, send)
            return

        method = scope["method"] if scope["method"] in _ALLOWED_METHODS else _OTHER_METHOD
        status = _NO_RESPONSE_STATUS
        start = time.perf_counter()

        async def send_with_status(message: Message) -> None:
            nonlocal status
            if message["type"] == "http.response.start":
                status = str(message["status"])
            await send(message)

        try:
            await self.app(scope, receive, send_with_status)
        except Exception:
            # Ошибку до начала ответа RequestContextMiddleware сама превращает в 500-ответ, поэтому сюда
            # доходят только исключения, которые вышли из неё. Статус — код начатого ответа, а если ответ
            # не начат — 500. Ветка ниже при этом не выполняется: запрос учитывается ровно один раз.
            _observe(scope, method, status, start)
            raise
        _observe(scope, method, status, start)


def _observe(scope: Scope, method: str, status: str, start: float) -> None:
    """Записывает наблюдение; сбой записи логируется и на обработку запроса не влияет.

    В multiprocess-режиме значение пишется в файл значений процесса, и запись может упасть с OSError
    (например, директорию значений удалили). В обычной ветке ответ к этому моменту уже отправлен, и проброс
    такой ошибки вывел бы её из приложения к HTTP-серверу; в ветке исключения он подменил бы исходное
    исключение запроса.
    """
    try:
        HTTP_REQUEST_DURATION.labels(
            method=method,
            path=_path_label(scope),
            status=status,
            host=HOSTNAME,
        ).observe(time.perf_counter() - start)
    except OSError as exc:
        logger.error("metrics observation failed", exc_info=exc)


def _path_label(scope: Scope) -> str:
    """Шаблон маршрута запроса; `unmatched` — маршрута нет; `other` — маршрут скрыт из схемы API.

    Маршрут ищется после обработки запроса: `scope["route"]` заполняет роутер приложения.
    """
    route = scope.get("route") or _match_starlette_route(scope)
    if route is None:
        return _UNMATCHED_PATH
    if getattr(route, "include_in_schema", True) is False:
        return _HIDDEN_PATH
    return getattr(route, "path_format", None) or _UNMATCHED_PATH


def _match_starlette_route(scope: Scope) -> BaseRoute | None:
    """Маршрут Starlette, совпавший с запросом, когда в `scope["route"]` ничего нет.

    FastAPI записывает в `scope["route"]` только свои маршруты. Служебные `/docs`, `/redoc`,
    `/openapi.json` и `/docs/oauth2-redirect` он добавляет обычными маршрутами Starlette, и без этого
    поиска они получали бы `unmatched`, хотя это известные маршруты, скрытые из схемы.
    """
    for route in scope["app"].router.routes:
        if isinstance(route, Route) and route.matches(scope)[0] is not Match.NONE:
            return route
    return None
