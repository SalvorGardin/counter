"""Базовые схемы API: общая модель (snake_case в Python, camelCase в JSON)."""

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class CamelModel(BaseModel):
    """Базовая модель API: snake_case внутри, camelCase в JSON, лишние поля запрещены."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        extra="forbid",
    )
