"""ASGI middleware: контекст запроса и длительности без диспетчеризации call_next."""

import re
import time
import uuid

from starlette.datastructures import Headers, MutableHeaders
from starlette.requests import Request
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from src.api.errors import unhandled_exception_handler
from src.logger import (
    FingersBuffer,
    authorization_var,
    debug_enabled_var,
    fingers_crossed_var,
    logger,
    notice,
    request_id_var,
    x_enable_debug_var,
)

# X-Request-ID задаёт клиент, а значение попадает в каждую запись лога и в заголовок ответа. Принимается
# только короткий идентификатор из безопасных символов (UUID и подобные), иначе генерируется свой —
# решение на границе доверия, как для X-Enable-Debug.
_REQUEST_ID_PATTERN = re.compile(r"[A-Za-z0-9._-]{1,64}")


def _request_id(raw: str | None) -> str:
    if raw is not None and _REQUEST_ID_PATTERN.fullmatch(raw):
        return raw
    return str(uuid.uuid4())


class RequestContextMiddleware:
    def __init__(self, app: ASGIApp, probe_paths: set[str]) -> None:
        self.app = app
        self.probe_paths = probe_paths

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        started = time.perf_counter()
        headers = Headers(scope=scope)
        req_id = _request_id(headers.get("X-Request-ID"))
        auth_raw = headers.get("Authorization")
        auth = f"{auth_raw.split(' ', 1)[0]} ***" if auth_raw else None
        debug = headers.get("X-Enable-Debug", "").lower() in {"1", "true", "yes"}
        tokens = (
            (request_id_var, request_id_var.set(req_id)),
            (authorization_var, authorization_var.set(auth)),
            (debug_enabled_var, debug_enabled_var.set(debug)),
            (x_enable_debug_var, x_enable_debug_var.set("true" if debug else "")),
            (fingers_crossed_var, fingers_crossed_var.set(FingersBuffer())),
        )
        response_started = False
        status_code = 500
        duration_ms = 0.0
        http_duration_ms = 0.0

        async def send_response(message: Message) -> None:
            nonlocal response_started, status_code, duration_ms, http_duration_ms
            if message["type"] == "http.response.start":
                response_started = True
                status_code = message["status"]
                duration_ms = (time.perf_counter() - started) * 1000
                MutableHeaders(scope=message)["X-Request-ID"] = req_id
            await send(message)
            if message["type"] == "http.response.body" and not message.get("more_body", False):
                http_duration_ms = (time.perf_counter() - started) * 1000

        try:
            logger.debug(
                "request started",
                extra={"log_context": {"method": scope["method"], "path": scope["path"]}},
            )
            try:
                await self.app(scope, receive, send_response)
            except Exception as exc:
                if response_started:
                    # Ответ уже начат, заменить его на 500 нельзя — соединение оборвётся. Без этой записи
                    # обрыв не оставил бы в логе сервиса ни ошибки, ни `request completed`.
                    logger.error(
                        "request aborted after response start",
                        extra={
                            "log_context": {
                                "method": scope["method"],
                                "path": scope["path"],
                                "status_code": status_code,
                            }
                        },
                        exc_info=exc,
                    )
                    raise
                # Ответ 500 строится до сброса контекста, поэтому лог ошибки и заголовок
                # получают requestId именно этого запроса.
                response = await unhandled_exception_handler(Request(scope), exc)
                await response(scope, receive, send_response)

            if scope["path"] in self.probe_paths:
                logger.debug(
                    "probe request",
                    extra={"log_context": {"path": scope["path"], "duration_ms": round(duration_ms, 2)}},
                )
            else:
                timings = scope.get("state", {}).get("calc_timings", {})
                notice(
                    "request completed",
                    context={
                        "method": scope["method"],
                        "path": scope["path"],
                        "status_code": status_code,
                        "duration_ms": round(duration_ms, 3),
                        "http_duration_ms": round(http_duration_ms, 3),
                        **{
                            name: round(value, 3) if isinstance(value, float) else value
                            for name, value in timings.items()
                        },
                    },
                )
        finally:
            for variable, token in reversed(tokens):
                variable.reset(token)
