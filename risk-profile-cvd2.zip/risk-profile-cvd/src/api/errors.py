"""Глобальный формат ошибок API: envelope `{isSuccess, error: {code, message}}` (как в core)."""

from typing import Annotated, Any, Literal

from fastapi import Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import Field
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.api.schemas import CamelModel
from src.calc.domain.exceptions import CalculationError
from src.logger import logger


class ErrorPayload(CamelModel):
    code: Annotated[str, Field(max_length=100)]
    message: Annotated[str, Field(max_length=255)]


class ErrorEnvelope(CamelModel):
    is_success: Literal[False] = False
    error: ErrorPayload


class SuccessEnvelope(CamelModel):
    is_success: Literal[True] = True


common_responses: dict[int | str, dict[str, Any]] = {
    400: {"model": ErrorEnvelope, "description": "Validation failed"},
    422: {"model": ErrorEnvelope, "description": "Calculation failed"},
    500: {"model": ErrorEnvelope, "description": "Internal error"},
}


def _error_code(loc: tuple[Any, ...]) -> str:
    parts = [str(p) for p in loc if p not in ("body", "query", "path")]
    if not parts:
        return "INVALID_REQUEST"
    return ("INVALID_" + "_".join(parts)).upper()[:100]


def _envelope(code: str, message: str) -> dict[str, Any]:
    return ErrorEnvelope(error=ErrorPayload(code=code[:100], message=message[:255])).model_dump(by_alias=True)


async def validation_exception_handler(_request: Request, exc: RequestValidationError) -> JSONResponse:
    """Pydantic-ошибки валидации входа → 400 + envelope."""
    first = exc.errors()[0]
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content=_envelope(code=_error_code(tuple(first["loc"])), message=str(first["msg"])),
    )


async def http_exception_handler(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
    """HTTPException (включая 404 роутинга) → envelope с исходным статусом."""
    return JSONResponse(
        status_code=exc.status_code,
        content=_envelope(code=f"HTTP_{exc.status_code}", message=str(exc.detail)),
    )


async def calculation_error_handler(_request: Request, exc: CalculationError) -> JSONResponse:
    """Сбой расчёта модели → 422 + envelope. Заменяет молчаливый `0.0` baseline-версии."""
    logger.error("calculation failed", extra={"log_context": {"reason": str(exc)}})
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=_envelope(code="CALCULATION_FAILED", message="Не удалось рассчитать риск ССЗ."),
    )


async def unhandled_exception_handler(_request: Request, exc: Exception) -> JSONResponse:
    """Любая необработанная ошибка → 500 + envelope, детали — только в логах."""
    logger.error("unhandled error in request handler", exc_info=exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=_envelope(code="INTERNAL_ERROR", message="Internal server error"),
    )
