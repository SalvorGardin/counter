"""Точка входа процесса сервиса: `python -m src` (CMD образа).

Перед запуском uvicorn готовит директорию multiprocess-режима метрик — удаляет файлы значений
прежнего запуска (см. `prepare_multiproc_dir`). Это делается здесь, до запуска воркеров: в самом
воркере очистка удалила бы файлы уже работающих соседей.

Модуль намеренно не импортирует приложение: `src.main` тянет pandas и scikit-learn. При
CVD_WORKERS > 1 этот процесс — только супервизор uvicorn, приложение загружает каждый воркер сам, а
модуль `__main__` пакета дочерние процессы не переисполняют. Так супервизор не держит в памяти
ML-библиотеки, которыми не пользуется.
"""

import uvicorn

from src.config import settings
from src.metrics import prepare_multiproc_dir

if __name__ == "__main__":
    prepare_multiproc_dir()
    # Приложение передаётся строкой импорта: при нескольких воркерах uvicorn загружает его в каждом
    # воркере сам. access_log=False — без не-JSON строк access-лога uvicorn: завершённые запросы
    # логирует RequestContextMiddleware.
    uvicorn.run(
        "src.main:app",
        host=settings.host,
        port=settings.port,
        workers=settings.workers,
        access_log=False,
    )
