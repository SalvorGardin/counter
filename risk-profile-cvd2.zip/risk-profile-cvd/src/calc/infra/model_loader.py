"""Загрузка артефактов модели с диска. Вызывается один раз при старте сервиса (lifespan).

Сохранённые Pipeline содержат MinMaxScaler и BinaryStratifiedModel с двумя
sklearn LogisticRegression. После проверки структуры из них извлекаются параметры расчёта.
"""

from pathlib import Path
from typing import cast

import joblib
import numpy as np
import pandas as pd
from numpy.typing import NDArray
from scipy.interpolate import interp1d
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler

from src.calc.domain.consts import CVD_FEATURES, PERIOD_ARTIFACTS
from src.calc.domain.exceptions import CvdBaseError
from src.calc.domain.inference import GROUP_FEATURES, CvdInference, LoadedModel
from src.logger import logger
from utils.modeling import BinaryStratifiedModel


class ModelArtifactError(CvdBaseError):
    """Артефакты модели не найдены или не прошли проверку при загрузке — сервис не стартует.

    Ошибка старта, а не расчёта: в HTTP-ответ (`CalculationError` → 422) она не переводится.
    `check` — код причины: сорвавшаяся проверка или `not_found`.
    """

    def __init__(self, check: str) -> None:
        super().__init__(f"CVD model artifacts rejected: {check}")
        self.check = check


def load_models(models_dir: Path, data_dir: Path) -> dict[str, LoadedModel]:
    """Загрузить все периоды, для которых есть и файл модели, и таблица заболеваемости.

    Период без артефактов пропускается (например, окружение только с Y5). Если не нашлось
    ни одного — это ошибка конфигурации: `ModelArtifactError("not_found")`. Сорвавшаяся проверка
    артефакта пишется в лог с периодом и кодом и поднимается как есть. Ошибки библиотек при чтении
    файлов (распаковка pkl, разбор CSV) не перехватываются: старт завершается с их traceback.
    """
    loaded: dict[str, LoadedModel] = {}
    for period, (model_file, incidence_file) in PERIOD_ARTIFACTS.items():
        model_path = models_dir / model_file
        incidence_path = data_dir / incidence_file
        if not model_path.exists() or not incidence_path.exists():
            continue
        try:
            loaded[period] = _load_period(model_path, incidence_path)
        except ModelArtifactError as exc:
            # Артефакты вшиты в образ, данных пациента в них нет — traceback пишется целиком.
            logger.error(
                "model load failed",
                extra={
                    "log_context": {
                        "period": period,
                        "check": exc.check,
                        "model_file": model_file,
                        "incidence_file": incidence_file,
                    }
                },
                exc_info=exc,
            )
            raise

    if not loaded:
        logger.error(
            "model load failed",
            extra={"log_context": {"check": "not_found", "models_dir": str(models_dir), "data_dir": str(data_dir)}},
        )
        raise ModelArtifactError("not_found")
    return loaded


def _load_period(model_path: Path, incidence_path: Path) -> LoadedModel:
    """Модель и интерполяция score → риск % одного периода."""
    model = prepare_inference(joblib.load(model_path))
    # Заголовок и округление таблицы сохраняют семантику baseline.
    incidence = pd.read_csv(incidence_path, index_col=0, header=[0, 1]).round(2)
    y = np.array([0.0, *incidence.iloc[:, 2]], dtype=np.float64)
    if y.shape != (7,) or not np.isfinite(y).all():
        raise ModelArtifactError("incidence_table")
    risk_curve = interp1d(
        [0, 8.5, 26.5, 44.5, 63.5, 80.5, 95],
        y,
        kind="cubic",
        bounds_error=False,
        fill_value="extrapolate",
    )
    return LoadedModel(model=model, risk_curve=risk_curve)


def prepare_inference(model: object) -> CvdInference:
    """Проверить артефакт и сверить численный расчёт с исходным Pipeline при старте.

    Сорвавшаяся проверка поднимает `ModelArtifactError` со своим кодом. Ошибки библиотек при разборе
    артефакта (например, нет ожидаемого атрибута) уходят как есть.
    """
    if type(model) is not Pipeline:
        raise ModelArtifactError("pipeline_type")
    pipeline = cast(Pipeline, model)
    if len(pipeline.steps) != 2:
        raise ModelArtifactError("pipeline_steps")
    scaler, classifier = (step for _, step in pipeline.steps)
    if type(scaler) is not MinMaxScaler or type(classifier) is not BinaryStratifiedModel:
        raise ModelArtifactError("pipeline_step_types")
    if scaler.n_features_in_ != len(CVD_FEATURES) or tuple(scaler.feature_names_in_) != CVD_FEATURES:
        raise ModelArtifactError("scaler_features")
    if (
        scaler.clip
        or scaler.feature_range != (0, 1)
        or getattr(scaler, "_sklearn_output_config", {}).get("transform", "default") != "default"
    ):
        raise ModelArtifactError("scaler_settings")
    if tuple(classifier.features) != CVD_FEATURES or classifier.binary_feature != "SEX":
        raise ModelArtifactError("classifier_features")
    if set(classifier.models) != {0.0, 1.0} or not np.array_equal(classifier.classes_, [0, 1]):
        raise ModelArtifactError("classifier_groups")

    scale = _finite_array(scaler.scale_, (len(CVD_FEATURES),), "scaler_scale")
    offset = _finite_array(scaler.min_, (len(CVD_FEATURES),), "scaler_min")
    coefficients = []
    intercepts = []
    for group in (0.0, 1.0):
        estimator = classifier.models[group]
        if (
            type(estimator) is not LogisticRegression
            or estimator.n_features_in_ != len(GROUP_FEATURES)
            or tuple(estimator.feature_names_in_) != GROUP_FEATURES
            or not np.array_equal(estimator.classes_, [0, 1])
            or estimator.multi_class not in ("ovr", "warn", "auto", "deprecated")
        ):
            raise ModelArtifactError(f"group_{group:.0f}_estimator")
        coefficients.append(_finite_array(estimator.coef_, (1, len(GROUP_FEATURES)), f"group_{group:.0f}_coef"))
        intercepts.append(_finite_array(estimator.intercept_, (1,), f"group_{group:.0f}_intercept"))

    inference = CvdInference(
        scale=scale,
        offset=offset,
        # Отдельные массивы сохраняют выравнивание coef_: объединение групп может
        # изменить суммирование NumPy и округление на десятичной границе.
        coefficients=(coefficients[0], coefficients[1]),
        intercepts=(intercepts[0], intercepts[1]),
    )
    # Синтетические строки обеих групп. Умеренные профили дают вероятность вдали от 0 и 1 и вместе
    # задействуют все признаки, включая флаги: на них видно и малое отклонение расчёта. Крайние
    # значения за пределами обучения проверяют, что MinMaxScaler не обрезает признаки к [0, 1].
    rows = np.array(
        [
            [45, 0, 26, 110, 10, 1.5, 2.0, 0, 0, 0, 0, 0],
            [45, 1, 26, 110, 10, 1.5, 2.0, 0, 0, 0, 0, 0],
            [25, 0, 20, 100, 5, 1.8, 1.5, 1, 1, 0, 1, 1],
            [25, 1, 20, 100, 5, 1.8, 1.5, 1, 1, 0, 1, 1],
            [30, 0, 22, 100, 5, 1.8, 1.5, 0, 0, 1, 0, 0],
            [30, 1, 22, 100, 5, 1.8, 1.5, 0, 0, 1, 0, 0],
            [0, 0, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0],
            [120, 0, 100, 300, 1000, 20, 30, 1, 1, 1, 1, 1],
            [120, 1, 100, 300, 1000, 20, 30, 1, 1, 1, 1, 1],
        ],
        dtype=np.float64,
    )
    reference = pipeline.predict_proba(pd.DataFrame(rows, columns=CVD_FEATURES))[:, 1]
    actual = np.array([inference.predict_probability(row) for row in rows])
    # Допуск много больше расхождений из-за порядка суммирования (BLAS/CPU) и много меньше шага
    # округления результата: отказ запуска означает другой расчёт, а не другой процессор.
    if not np.allclose(actual, reference, rtol=0.0, atol=1e-12):
        raise ModelArtifactError("reference_mismatch")
    return inference


def _finite_array(value: object, shape: tuple[int, ...], check: str) -> NDArray[np.float64]:
    """Копия параметра модели только для чтения: float-массив заданной формы без NaN/inf."""
    if not isinstance(value, np.ndarray) or value.dtype.kind != "f":
        raise ModelArtifactError(check)
    result = np.array(value, dtype=np.float64, copy=True)
    if result.shape != shape or not np.isfinite(result).all():
        raise ModelArtifactError(check)
    result.flags.writeable = False
    return result
