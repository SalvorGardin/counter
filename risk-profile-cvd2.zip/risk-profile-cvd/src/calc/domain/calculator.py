"""Доменный сервис расчёта риска ССЗ.

Модель резидентна в памяти (загружена при старте) — на каждый запрос с диска ничего не читаем.
Расчёт одной строки выполняется численно по проверенным при старте коэффициентам модели.
"""

import numpy as np

from src.calc.domain.consts import CVD_FEATURES
from src.calc.domain.exceptions import CalculationError
from src.calc.domain.inference import LoadedModel
from src.calc.domain.models import CvdResult
from src.logger import exception_without_message, logger


class CvdCalculator:
    def __init__(self, models: dict[str, LoadedModel]) -> None:
        self._models = models

    def supported_periods(self) -> list[str]:
        return sorted(self._models)

    def calculate_row(self, period: str, features: tuple[float, ...]) -> CvdResult:
        """Рассчитать риск по одной строке строго в порядке CVD_FEATURES."""
        loaded = self._models.get(period)
        if loaded is None:
            raise CalculationError("unsupported period")

        try:
            row = np.asarray(features, dtype=np.float64)
            if row.shape != (len(CVD_FEATURES),) or not np.isfinite(row).all():
                raise CalculationError("invalid model row")
            score = loaded.model.predict_probability(row) * 100.0
            risk = float(np.clip(loaded.risk_curve(score), 0, 100))
            if not np.isfinite(score) or not np.isfinite(risk):
                raise CalculationError("non-finite model result")
        except (ValueError, ArithmeticError) as exc:
            # Численная ошибка NumPy/SciPy на этой строке. Текст исключения библиотек может содержать
            # значения признаков, поэтому в лог идут тип и стек без текста, а CalculationError не
            # связывается с исходным исключением. Остальные исключения — ошибки кода: они уходят как
            # есть и дают 500 с traceback.
            logger.error(
                "model inference failed",
                extra={"log_context": {"period": period}},
                exc_info=exception_without_message(exc),
            )
            raise CalculationError("model inference failed") from None

        return CvdResult(period=period, score=round(score, 1), risk_percentage=round(risk, 1))
