"""Константы CVD-модели.

`CVD_FEATURES` — точный набор и **порядок** фич, на которых обучена модель. Порядок критичен:
вложенные оценщики (`ClinicalLogisticRegression`) обучались по позиционному массиву признаков,
поэтому строку для инференса собираем строго в этом порядке. Имена чувствительны к регистру.
"""

from typing import Literal

Period = Literal["Y5", "Y2"]
SUPPORTED_PERIODS: tuple[Period, ...] = ("Y5", "Y2")

CVD_FEATURES: tuple[str, ...] = (
    "AGE",
    "SEX",
    "BMI",
    "SBP",
    "LPA",
    "HDL_CHOL",
    "LDL_CHOL",
    "LIPID_DRUGS",
    "AS",
    "DM",
    "FAM_IHD_CVA",
    "FAM_HYPCHOL",
)

# period → (файл модели, файл таблицы заболеваемости) в каталогах settings.models_dir / settings.data_dir
PERIOD_ARTIFACTS: dict[str, tuple[str, str]] = {
    "Y5": ("Y5_model.pkl", "Y5_incidence.csv"),
    "Y2": ("Y2_model.pkl", "Y2_incidence.csv"),
}
