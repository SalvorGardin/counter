"""Доменные модели результата расчёта."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CvdResult:
    """Результат расчёта риска ССЗ для одного периода."""

    period: str
    # Сырой выход классификатора в процентах (predict_proba * 100).
    score: float
    # Итоговый риск ССЗ в процентах (score → таблица заболеваемости).
    risk_percentage: float
