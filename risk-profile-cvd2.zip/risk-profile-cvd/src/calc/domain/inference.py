"""Расчёт одной строки для структуры сохранённых CVD-моделей.

Здесь только численное ядро. Разбор и проверка артефакта модели — в
`src/calc/infra/model_loader.py` (`prepare_inference`), сюда приходит готовый `LoadedModel`.
"""

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from scipy.special import expit

from src.calc.domain.consts import CVD_FEATURES
from src.calc.domain.exceptions import CalculationError

_SEX_INDEX = CVD_FEATURES.index("SEX")
# Признаки подмоделей пола: строка без SEX в порядке CVD_FEATURES — в таком виде их получает
# predict_probability. Загрузчик сверяет с ними признаки сохранённых регрессий.
GROUP_FEATURES = tuple(name for name in CVD_FEATURES if name != "SEX")


@dataclass(frozen=True, slots=True)
class CvdInference:
    """MinMaxScaler и бинарная LogisticRegression без построения DataFrame на запросе."""

    scale: NDArray[np.float64]
    offset: NDArray[np.float64]
    coefficients: tuple[NDArray[np.float64], NDArray[np.float64]]
    intercepts: tuple[NDArray[np.float64], NDArray[np.float64]]

    def predict_probability(self, row: NDArray[np.float64]) -> float:
        # Сохраняем порядок операций MinMaxScaler: умножение, затем сложение.
        scaled = row * self.scale
        scaled += self.offset
        if not np.isfinite(scaled).all():
            raise CalculationError("non-finite model input")
        group = scaled[_SEX_INDEX]
        if group not in (0.0, 1.0):
            raise CalculationError("unsupported model group")
        index = int(group)
        predictors: NDArray[np.float64] = np.delete(scaled, _SEX_INDEX).reshape(1, -1)
        # sklearn использует сохранённый intercept_ и при fit_intercept=False.
        decision = predictors @ self.coefficients[index].T + self.intercepts[index]
        return float(expit(decision)[0, 0])


@dataclass(frozen=True, slots=True)
class LoadedModel:
    """Модель периода и готовая интерполяция score → риск %, резидентно в памяти."""

    model: CvdInference
    risk_curve: Callable[[float], NDArray[np.float64]]
