import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.preprocessing import StandardScaler
from sklearn.utils.multiclass import unique_labels
from scipy.interpolate import interp1d

class BinaryStratifiedModel(BaseEstimator, ClassifierMixin):
    """
    A pipeline-compatible model that trains separate models for binary feature groups.
    
    Parameters:
    - model_class: The scikit-learn model class (e.g., RandomForestClassifier)
    - binary_feature: Name of the binary column to stratify by (e.g., 'gender')
    - feature_index: Position of binary feature in the array (alternative to name)
    - model_kwargs: Keyword arguments for the underlying models
    """
    def __init__(self, model_class, binary_feature, features, **model_kwargs):
        self.model_class = model_class
        self.binary_feature = binary_feature
        self.features = features
        self.model_kwargs = model_kwargs
        self.models = {}
        self.classes_ = None

    def fit(self, X, y):
        # Convert to DataFrame if not already (preserve feature names)
        if not isinstance(X, pd.DataFrame):
            # If we have feature names from a previous pipeline step
            if hasattr(X, 'columns'):
                X = pd.DataFrame(X, columns=X.columns)
            else:
                # Create generic column names if none exist
                X = pd.DataFrame(X, columns=self.features)
        
        # Determine the binary feature column
        if self.binary_feature is None and self.feature_index is None:
            raise ValueError("Either binary_feature or feature_index must be specified")
        
        if self.binary_feature is not None:
            if self.binary_feature not in X.columns:
                raise ValueError(f"Binary feature '{self.binary_feature}' not found in X")
            binary_col = self.binary_feature
        else:
            binary_col = X.columns[self.feature_index]
        
        # Store classes for sklearn compatibility
        self.classes_ = np.unique(y)
        
        # Train separate models for each group
        for group in X[binary_col].unique():
            mask = (X[binary_col] == group).values
            X_group = X[mask].drop(columns=[binary_col])
            y_group = y[mask]
            
            model = self.model_class(**self.model_kwargs)
            model.fit(X_group, y_group)
            self.models[group] = model
        
        return self

    def predict(self, X):
        # Convert to DataFrame if not already
        if not isinstance(X, pd.DataFrame):
            if hasattr(X, 'columns'):
                X = pd.DataFrame(X, columns=X.columns)
            else:
                X = pd.DataFrame(X, columns=self.features)
        
        # Determine the binary feature column
        if self.binary_feature is not None:
            binary_col = self.binary_feature
        else:
            binary_col = X.columns[self.binary_feature]
        
        # Get unique groups present in prediction data
        groups = X[binary_col].unique()
        
        # Initialize result array with correct shape
        predictions = np.empty(X.shape[0], dtype=object)
        
        # Process each group in bulk
        for group in groups:
            if group not in self.models:
                raise ValueError(f"No model trained for group '{group}'")
                
            # Create mask for current group
            mask = (X[binary_col] == group).values
            
            # Get features for this group (excluding binary column)
            X_group = X.loc[mask].drop(columns=[binary_col])
            
            # Predict in bulk if any samples exist for this group
            if len(X_group) > 0:
                predictions[mask] = self.models[group].predict(X_group)
        
        return predictions.astype(bool)

    def predict_proba(self, X):
        """For classifiers that support probability predictions"""
        if not isinstance(X, pd.DataFrame):
            if hasattr(X, 'columns'):
                X = pd.DataFrame(X, columns=X.columns)
            else:
                X = pd.DataFrame(X, columns=self.features)
        
        # Determine the binary feature column
        if self.binary_feature is not None:
            binary_col = self.binary_feature
        else:
            binary_col = X.columns[self.feature_index]
        
        # Get unique groups present in prediction data
        groups = X[binary_col].unique()
        
        # Initialize result array with correct shape
        n_classes = len(self.classes_)
        probas = np.zeros((X.shape[0], n_classes))
        
        # Process each group in bulk
        for group in groups:
            if group not in self.models:
                raise ValueError(f"No model trained for group '{group}'")
                
            # Create mask for current group
            mask = (X[binary_col] == group).values
            
            # Get features for this group (excluding binary column)
            X_group = X.loc[mask].drop(columns=[binary_col])
            
            # Predict probabilities in bulk if any samples exist
            if len(X_group) > 0:
                if not hasattr(self.models[group], 'predict_proba'):
                    raise NotImplementedError("Underlying model doesn't support predict_proba")
                probas[mask] = self.models[group].predict_proba(X_group)
        
        return probas.astype(float)


class ClinicalLogisticRegression(BaseEstimator, ClassifierMixin):
    """
    Custom implementation of Logistic Regression with threshold-based regularization.
    
    Parameters
    ----------
    learning_rate : float, default=0.01
        Learning rate for gradient descent optimization.
    max_iter : int, default=1000
        Maximum number of iterations for gradient descent.
    tol : float, default=1e-4
        Tolerance for stopping criterion.
    fit_intercept : bool, default=True
        Whether to calculate the intercept for this model.
    random_state : int, default=None
        Seed for random initialization of coefficients.
    scale : bool, default=True
        Whether to scale features before fitting.
    reg_strength : float, default=1.0
        Strength of the directional regularization.
    p : array-like, shape (n_features,), default=None
        Threshold regularization vector.
        - If p_i > 0: penalize when θ_i < p_i
        - If p_i < 0: penalize when θ_i > p_i
        - If p_i = 0: no regularization
    """
    
    def __init__(self, learning_rate=0.01, max_iter=1000, tol=1e-4, 
                 fit_intercept=True, random_state=None, scale=True,
                 reg_strength=1.0, p=None):
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.tol = tol
        self.fit_intercept = fit_intercept
        self.random_state = random_state
        self.scale = scale
        self.reg_strength = reg_strength
        self.p = p
        
    def _sigmoid(self, z):
        """Sigmoid function."""
        return 1 / (1 + np.exp(-z))
    
    def _add_intercept(self, X):
        """Add intercept term to X."""
        intercept = np.ones((X.shape[0], 1))
        return np.concatenate((intercept, X), axis=1)
    
    def _loss(self, h, y, theta):
        """Compute logistic regression loss with threshold regularization."""
        # Standard logistic loss
        log_loss = (-y * np.log(h) - (1 - y) * np.log(1 - h)).mean()
        
        # Add threshold regularization if p is provided
        if self.p is not None:
            reg_terms = np.zeros_like(theta)
            if self.fit_intercept:
                # Don't regularize the intercept term
                reg_terms[1:] = self._threshold_regularization(theta[1:])
            else:
                reg_terms = self._threshold_regularization(theta)
            
            threshold_loss = self.reg_strength * reg_terms.sum()
            return log_loss + threshold_loss
        return log_loss
    
    def _threshold_regularization(self, theta):
        """
        Compute threshold regularization terms for each coefficient.
        
        Parameters
        ----------
        theta : array-like
            Model coefficients (excluding intercept if fit_intercept=True)
            
        Returns
        -------
        reg_terms : array-like
            Regularization terms for each coefficient
        """
        reg_terms = np.zeros_like(theta)
        for i, (t, p_val) in enumerate(zip(theta, self.p)):
            if p_val > 0 and t < p_val:
                # Penalize when coefficient is below positive threshold
                reg_terms[i] = (t - p_val)**2
            elif p_val < 0 and t > p_val:
                # Penalize when coefficient is above negative threshold
                reg_terms[i] = (t - p_val)**2
            # p_val = 0: no regularization
        return reg_terms
    
    def _threshold_gradient(self, theta):
        """
        Compute gradient of threshold regularization terms.
        
        Parameters
        ----------
        theta : array-like
            Model coefficients (excluding intercept if fit_intercept=True)
            
        Returns
        -------
        grad_terms : array-like
            Gradient of regularization terms for each coefficient
        """
        grad_terms = np.zeros_like(theta)
        for i, (t, p_val) in enumerate(zip(theta, self.p)):
            if p_val > 0 and t < p_val:
                # Gradient when coefficient is below positive threshold
                grad_terms[i] = 2 * (t - p_val)
            elif p_val < 0 and t > p_val:
                # Gradient when coefficient is above negative threshold
                grad_terms[i] = 2 * (t - p_val)
            # p_val = 0: no gradient contribution
        return grad_terms
    
    def fit(self, X, y):
        """
        Fit logistic regression model to training data with threshold regularization.
        """        
        # Store feature names if available
        if hasattr(X, 'columns'):
            self.feature_names_in_ = np.array(X.columns)
        else:
            self.feature_names_in_ = None
        
        # Check that X and y have correct shape
        X, y = check_X_y(X, y)
        
        # Validate p vector if provided
        if self.p is not None:
            self.p = np.asarray(self.p)
            if len(self.p) != X.shape[1]:
                raise ValueError(f"p should have length {X.shape[1]} (number of features)")
        
        # Store classes
        self.classes_ = unique_labels(y)
        
        # For binary classification, convert y to 0/1
        if len(self.classes_) == 2:
            y = np.where(y == self.classes_[1], 1, 0)
        else:
            raise ValueError("This implementation currently supports only binary classification")
        
        # Scale features if requested
        if self.scale:
            self.scaler_ = StandardScaler()
            X = self.scaler_.fit_transform(X)
        
        # Add intercept term if requested
        if self.fit_intercept:
            X = self._add_intercept(X)
        
        # Initialize coefficients
        if self.random_state is not None:
            np.random.seed(self.random_state)
        self.coef_ = np.random.rand(X.shape[1])
        
        # Gradient descent
        prev_loss = float('inf')
        for i in range(self.max_iter):
            # Calculate predictions
            z = np.dot(X, self.coef_)
            h = self._sigmoid(z)
            
            # Calculate standard gradient
            gradient = np.dot(X.T, (h - y)) / y.size
            
            # Add threshold regularization gradient if p is provided
            if self.p is not None:
                if self.fit_intercept:
                    # Don't regularize the intercept term
                    reg_gradient = np.zeros_like(self.coef_)
                    reg_gradient[1:] = self._threshold_gradient(self.coef_[1:])
                else:
                    reg_gradient = self._threshold_gradient(self.coef_)
                
                gradient += self.reg_strength * reg_gradient
            
            # Update coefficients
            self.coef_ -= self.learning_rate * gradient
            
            # Calculate loss for convergence check
            loss = self._loss(h, y, self.coef_)
            
            # Check for convergence
            if abs(prev_loss - loss) < self.tol:
                break
            prev_loss = loss
        
        # Separate intercept from coefficients if needed
        if self.fit_intercept:
            self.intercept_ = self.coef_[0]
            self.coef_ = self.coef_[1:]
        else:
            self.intercept_ = 0.0
        
        return self
    
    # The predict_proba, predict, and score methods remain unchanged
    def predict_proba(self, X):
        """Probability estimates."""
        check_is_fitted(self, ['coef_', 'intercept_'])
        X = check_array(X)
        
        if hasattr(self, 'scaler_'):
            X = self.scaler_.transform(X)
        
        # Add intercept if needed
        if self.fit_intercept:
            z = np.dot(X, self.coef_) + self.intercept_
        else:
            z = np.dot(X, self.coef_)
        
        prob_positive = self._sigmoid(z)
        prob_negative = 1 - prob_positive
        
        return np.vstack((prob_negative, prob_positive)).T
    
    def predict(self, X):
        """Predict class labels for samples in X."""
        probs = self.predict_proba(X)
        return self.classes_[np.argmax(probs, axis=1)]
    
    def score(self, X, y):
        """Returns the mean accuracy on the given test data and labels."""
        return super().score(X, y)

def table_to_risk_AIRI(x_star, incidence_table):
    y = [0] + incidence_table.iloc[:, 2].values.tolist()
    x = np.array([0, 8.5, 26.5, 44.5, 63.5, 80.5, 95])
    func = interp1d(x, y, kind='cubic', bounds_error=False, fill_value='extrapolate')
    return np.clip(func(x_star), 0, 100)