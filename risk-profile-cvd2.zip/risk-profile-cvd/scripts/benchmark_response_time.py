"""Воспроизводимые TCP/HTTP-замеры /calculate в отдельном Docker-контейнере.

Пример (сначала собрать образ текущего checkout):
  python scripts/benchmark_response_time.py --image cvd:baseline \
      --write-reference /tmp/cvd-reference.json --output /tmp/cvd-baseline.json
  python scripts/benchmark_response_time.py --image cvd:optimized \
      --reference /tmp/cvd-reference.json --output /tmp/cvd-optimized.json

Только синтетические данные; нагрузка направляется на автоматически созданный локальный
контейнер. Closed loop измеряет насыщение при заданной конкуренции, fixed arrivals —
задержку от запланированной отправки, включая очередь клиента (без coordinated omission).
Частоты fixed arrivals являются параметрами эксперимента, а не оценкой production RPS.
"""

import argparse
import concurrent.futures
import hashlib
import http.client
import json
import math
import os
import platform
import random
import shutil

# Локальный оператор задаёт Docker CLI; shell не используется.
import subprocess  # nosec B404
import threading
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path


def docker_binary() -> str:
    binary = shutil.which("docker")
    if binary is None:
        raise RuntimeError("Docker CLI не найден")
    return binary


def docker(*arguments: str) -> str:
    # Только локальные аргументы оператора, shell=False и абсолютный путь к Docker.
    return subprocess.check_output(  # nosec B603
        [docker_binary(), *arguments], text=True, stderr=subprocess.PIPE
    ).strip()


def corpus(seed: int, size: int) -> list[dict]:
    # Воспроизводимые синтетические данные; генератор не используется для секретов.
    rng = random.Random(seed)  # nosec B311
    result = []
    for index in range(size):
        result.append(
            {
                "period": ("Y2", "Y5")[index % 2],
                "riskFactors": {
                    "age": round(rng.uniform(30, 85), 3),
                    "sex": (index // 2) % 2,
                    "bmi": round(rng.uniform(19, 42), 3),
                    "systolicBp": round(rng.uniform(100, 185), 3),
                    "lipoproteinA": round(rng.uniform(0, 130), 3),
                    "hdlChol": round(rng.uniform(0.7, 2.4), 3),
                    "ldlChol": round(rng.uniform(1, 6), 3),
                    "lipidDrugs": rng.randrange(2),
                    "atherosclerosis": rng.randrange(2),
                    "diabetes": rng.randrange(2),
                    "famIhdCva": rng.randrange(2),
                    "famHypchol": rng.randrange(2),
                },
            }
        )
    return result


def quantiles(values: list[float]) -> dict:
    if not values:
        return {}
    ordered = sorted(values)

    def percentile(q: float) -> float:
        position = (len(ordered) - 1) * q
        lower = math.floor(position)
        upper = math.ceil(position)
        return round(ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower), 4)

    return {"p50": percentile(0.5), "p95": percentile(0.95), "p99": percentile(0.99)}


class HttpClient:
    def __init__(self, port: int, inputs: list[dict], expected: list[dict] | None):
        self.port = port
        self.inputs = inputs
        self.encoded = [json.dumps(value, separators=(",", ":")).encode() for value in inputs]
        self.expected = expected
        self.local = threading.local()

    def request(self, index: int, request_id: str, scheduled: float | None = None) -> dict:
        started = time.perf_counter()
        record = {
            "request_id": request_id,
            "input_index": index,
            "status": None,
            "error": None,
            "started": started,
        }
        try:
            connection = getattr(self.local, "connection", None)
            if connection is None:
                connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=30)
                self.local.connection = connection
            connection.request(
                "POST",
                "/api/v1/calculate",
                body=self.encoded[index],
                headers={"Content-Type": "application/json", "X-Request-ID": request_id},
            )
            response = connection.getresponse()
            body = response.read()
            record["status"] = response.status
            if response.status != 200:
                raise ValueError(f"HTTP {response.status}: {body[:200]!r}")
            if response.getheader("X-Request-ID") != request_id:
                raise ValueError("X-Request-ID не совпадает")
            payload = json.loads(body)
            if payload.get("isSuccess") is not True or payload.get("period") != self.inputs[index]["period"]:
                raise ValueError("Ответ не соответствует контракту")
            for name in ("score", "riskPercentage"):
                if not isinstance(payload.get(name), (float, int)) or not math.isfinite(payload[name]):
                    raise ValueError(f"Некорректное значение {name}")
            if not 0 <= payload["score"] <= 100:
                raise ValueError("score вне диапазона [0, 100]")
            if datetime.fromisoformat(payload["calculatedAt"].replace("Z", "+00:00")).tzinfo is None:
                raise ValueError("calculatedAt без часового пояса")
            actual = {name: payload[name] for name in ("period", "score", "riskPercentage")}
            if self.expected is not None and actual != self.expected[index]:
                raise ValueError(f"Результат отличается от baseline: {actual} != {self.expected[index]}")
            record["result"] = actual
        except Exception as error:
            record["error"] = f"{type(error).__name__}: {error}"
            connection = getattr(self.local, "connection", None)
            if connection is not None:
                connection.close()
                self.local.connection = None
        finished = time.perf_counter()
        record["finished"] = finished
        record["client_ms"] = (finished - started) * 1000
        record["arrival_ms"] = (finished - (scheduled or started)) * 1000
        record["scheduler_wait_ms"] = max(0, started - (scheduled or started)) * 1000
        return record


def cpu_snapshot(container: str) -> dict[str, int]:
    # CPU по процессам сервиса: точка входа `python -m src` (CMD образа; при одном worker это и есть
    # сервер), CLI `uvicorn` (образы, где CMD запускает uvicorn напрямую, например исходная версия для
    # сравнения) и воркеры uvicorn (`spawn_main`).
    code = (
        "import json, os; from pathlib import Path; "
        "lines=Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines(); "
        "result={k:int(v) for k,v in (line.split() for line in lines)}; "
        "ticks=os.sysconf('SC_CLK_TCK'); "
        "\nfor path in Path('/proc').glob('[0-9]*/stat'):"
        "\n try:"
        "\n  if path.parent.name == str(os.getpid()): continue"
        "\n  arguments=(path.parent/'cmdline').read_bytes().split(bytes(1));"
        "\n  entrypoint=arguments[1:3]==[b'-m',b'src'];"
        "\n  if not entrypoint and not any(b'uvicorn' in a or b'spawn_main' in a for a in arguments): continue"
        "\n  fields=path.read_text().rsplit(')',1)[1].split();"
        "\n  result['pid_'+path.parent.name+'_usage_usec']=int((int(fields[11])+int(fields[12]))*1e6/ticks)"
        "\n except (FileNotFoundError, ProcessLookupError): pass"
        "\nprint(json.dumps(result))"
    )
    return json.loads(docker("exec", container, "python", "-c", code))


def closed_loop(client: HttpClient, concurrency: int, duration: float, prefix: str) -> tuple[list[dict], float]:
    barrier = threading.Barrier(concurrency + 1)
    deadline = [0.0]

    def worker(number: int) -> list[dict]:
        records = []
        barrier.wait()
        sequence = 0
        while time.perf_counter() < deadline[0]:
            index = (sequence * concurrency + number) % len(client.inputs)
            records.append(client.request(index, f"{prefix}-{number}-{sequence}"))
            sequence += 1
        return records

    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(worker, number) for number in range(concurrency)]
        started = time.perf_counter()
        deadline[0] = started + duration
        barrier.wait()
        records = [record for future in futures for record in future.result()]
    return records, time.perf_counter() - started


def fixed_arrivals(client: HttpClient, rate: float, duration: float, prefix: str) -> tuple[list[dict], float]:
    with concurrent.futures.ThreadPoolExecutor(max_workers=256) as executor:
        started = time.perf_counter()
        futures = []
        for sequence in range(math.floor(rate * duration)):
            scheduled = started + sequence / rate
            wait = scheduled - time.perf_counter()
            if wait > 0:
                time.sleep(wait)
            futures.append(
                executor.submit(client.request, sequence % len(client.inputs), f"{prefix}-{sequence}", scheduled)
            )
        records = [future.result() for future in futures]
        remaining = started + duration - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)
    return records, time.perf_counter() - started


def summary(records: list[dict], elapsed: float, duration: float, cpu_before: dict, cpu_after: dict) -> dict:
    successful = [record for record in records if record["error"] is None]
    cpu = {key: cpu_after[key] - cpu_before.get(key, 0) for key in cpu_after}
    result = {
        "requests": len(records),
        "errors": len(records) - len(successful),
        "elapsed_seconds": round(elapsed, 4),
        "send_window_seconds": duration,
        "successful_rps": round(len(successful) / elapsed, 3),
        "cpu_delta": cpu,
        "mean_cpu_cores": round(cpu.get("usage_usec", 0) / 1e6 / elapsed, 3),
        "error_examples": [record["error"] for record in records if record["error"]][:5],
    }
    for name in ("client_ms", "arrival_ms", "scheduler_wait_ms"):
        result[name] = quantiles([record[name] for record in successful])
    return result


def attach_logs(report: dict, content: str) -> None:
    by_request_id = {}
    for scenario in report["scenarios"]:
        for record in scenario["raw"]:
            by_request_id[record["request_id"]] = record
    for line in content.splitlines():
        try:
            entry = json.loads(line)
        except (ValueError, TypeError):
            continue
        record = by_request_id.get(entry.get("extra", {}).get("requestId"))
        if record is None:
            continue
        timings = {
            key: value
            for key, value in entry.get("context", {}).items()
            if key.endswith("_ms") and isinstance(value, (int, float))
        }
        if timings:
            record.setdefault("server_ms", {}).update(timings)
    for scenario in report["scenarios"]:
        names = {key for record in scenario["raw"] for key in record.get("server_ms", {})}
        scenario["summary"]["server_ms"] = {
            name: quantiles(
                [record["server_ms"][name] for record in scenario["raw"] if name in record.get("server_ms", {})]
            )
            for name in sorted(names)
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--write-reference", type=Path)
    parser.add_argument("--duration", type=float, default=8)
    parser.add_argument("--warmup", type=float, default=2)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--concurrency", default="1,8,32")
    parser.add_argument("--arrival-rates", default="")
    parser.add_argument("--cpus", type=float, default=2)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--cap", type=int, default=5)
    parser.add_argument("--blas", choices=("default", "1"), default="default")
    parser.add_argument("--log-level", choices=("NOTICE", "WARNING"), default="NOTICE")
    parser.add_argument("--seed", type=int, default=310)
    parser.add_argument("--corpus-size", type=int, default=128)
    args = parser.parse_args()
    if (
        not all(math.isfinite(value) for value in (args.duration, args.warmup, args.cpus))
        or args.duration < 1
        or args.warmup < 0
        or min(args.cpus, args.workers, args.cap, args.repeats, args.corpus_size) <= 0
    ):
        parser.error("Некорректная длительность или конфигурация")
    try:
        modes = [("closed", int(value)) for value in args.concurrency.split(",") if value]
        modes.extend(("arrival", float(value)) for value in args.arrival_rates.split(",") if value)
    except ValueError:
        parser.error("Конкуренция и частоты должны быть числами")
    if not modes or any(not math.isfinite(value) or value <= 0 for _, value in modes):
        parser.error("Нужен хотя бы один сценарий с положительной конкуренцией или частотой")
    if any(mode == "arrival" and math.floor(value * args.duration) < 1 for mode, value in modes):
        parser.error("Частота и длительность должны давать хотя бы один HTTP-запрос")
    inputs = corpus(args.seed, args.corpus_size)
    fingerprint = hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest()
    expected = None
    if args.reference:
        reference = json.loads(args.reference.read_text())
        if reference["corpus_sha256"] != fingerprint:
            parser.error("Корпус отличается от корпуса baseline")
        expected = reference["expected"]
    container = f"cvd310-benchmark-{uuid.uuid4().hex[:12]}"
    arguments = [
        "run",
        "--detach",
        "--name",
        container,
        f"--cpus={args.cpus}",
        "--publish",
        "127.0.0.1::8000",
        "--env",
        f"CVD_WORKERS={args.workers}",
        "--env",
        f"CVD_MAX_CONCURRENCY={args.cap}",
        "--env",
        f"LOG_LEVEL={args.log_level}",
    ]
    if args.blas == "1":
        for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            arguments.extend(("--env", f"{name}=1"))
    arguments.append(args.image)
    docker(*arguments)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    log_path = args.output.with_suffix(".log")
    log_file = log_path.open("w")
    # Потоковое сохранение защищает замеры этапов от ротации Docker-журнала.
    log_process = subprocess.Popen(  # nosec B603
        [docker_binary(), "logs", "--follow", container], stdout=log_file, stderr=subprocess.STDOUT
    )
    report = {
        "started_at_utc": datetime.now(UTC).isoformat(),
        "config": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
        "host": {"platform": platform.platform(), "python": platform.python_version(), "cpus": os.cpu_count()},
        "client": {"keep_alive": True, "fixed_arrival_executor_workers": 256, "http_timeout_seconds": 30},
        "image_id": docker("image", "inspect", args.image, "--format", "{{.Id}}"),
        "container": container,
        "corpus_sha256": fingerprint,
        "corpus": inputs,
        "reference_checked": expected is not None,
        "scenarios": [],
    }
    try:
        port = int(docker("port", container, "8000/tcp").rsplit(":", 1)[1])
        deadline = time.perf_counter() + 120
        while True:
            try:
                probe = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
                probe.request("GET", "/readiness")
                response = probe.getresponse()
                response.read()
                probe.close()
                if response.status == 200:
                    break
            except (OSError, http.client.HTTPException):
                pass
            if time.perf_counter() > deadline:
                raise RuntimeError("Контейнер не готов за 120 секунд")
            time.sleep(0.1)
        runtime_code = (
            "import json, importlib.metadata as m; import numpy, scipy; "
            "from threadpoolctl import threadpool_info; "
            "print(json.dumps({'versions':{p:m.version(p) for p in "
            "['fastapi','starlette','uvicorn','pandas','numpy','scipy','scikit-learn']},"
            "'threadpools':threadpool_info()}))"
        )
        report["runtime"] = json.loads(docker("exec", container, "python", "-c", runtime_code))
        client = HttpClient(port, inputs, expected)
        if args.write_reference:
            oracle = [client.request(index, f"oracle-{container}-{index}") for index in range(len(inputs))]
            if any(record["error"] for record in oracle):
                raise RuntimeError(f"Baseline oracle: {[record['error'] for record in oracle if record['error']][:5]}")
            expected = [record["result"] for record in oracle]
            args.write_reference.write_text(json.dumps({"corpus_sha256": fingerprint, "expected": expected}, indent=2))
            client.expected = expected
            report["reference_checked"] = True
        closed_loop(client, max(4, args.workers), args.warmup, "warmup")
        for repeat in range(args.repeats):
            for mode, value in modes:
                name = f"{mode}-{value}-repeat-{repeat + 1}"
                before = cpu_snapshot(container)
                if mode == "closed":
                    records, elapsed = closed_loop(client, int(value), args.duration, name)
                else:
                    records, elapsed = fixed_arrivals(client, value, args.duration, name)
                after = cpu_snapshot(container)
                scenario = {
                    "mode": mode,
                    "concurrency" if mode == "closed" else "offered_rps": value,
                    "repeat": repeat + 1,
                    "summary": summary(records, elapsed, args.duration, before, after),
                    "raw": records,
                }
                report["scenarios"].append(scenario)
                print(json.dumps({"scenario": name, **scenario["summary"]}), flush=True)
        report["memory_peak_bytes"] = int(docker("exec", container, "cat", "/sys/fs/cgroup/memory.peak"))
        report["memory_current_bytes"] = int(docker("exec", container, "cat", "/sys/fs/cgroup/memory.current"))
    finally:
        docker("stop", "--time", "1", container)
        try:
            log_process.wait(timeout=15)
            report["log_capture_complete"] = log_process.returncode == 0
        except subprocess.TimeoutExpired:
            log_process.terminate()
            log_process.wait(timeout=5)
            report["log_capture_complete"] = False
        log_file.close()
        content = log_path.read_text()
        attach_logs(report, content)
        report["finished_at_utc"] = datetime.now(UTC).isoformat()
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
        docker("rm", "--force", container)
    if any(scenario["summary"]["errors"] for scenario in report["scenarios"]):
        raise SystemExit("Эксперимент завершён с ошибками; см. JSON")


if __name__ == "__main__":
    main()
