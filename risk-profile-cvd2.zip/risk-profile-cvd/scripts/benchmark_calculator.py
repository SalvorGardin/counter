"""Сравнение CVD Pipeline, прямого вызова группы и численного расчёта одной строки.

Запуск из корня: PYTHONPATH=. python scripts/benchmark_calculator.py
Вывод содержит только синтетические примеры, статистику и параметры воспроизведения.
"""

import argparse
import hashlib
import json
import platform
import tempfile
import timeit
from collections.abc import Callable
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
import scipy
import sklearn
from numpy.typing import NDArray
from scipy.optimize import brentq
from scipy.special import expit

from src.calc.domain.calculator import CvdCalculator
from src.calc.domain.consts import CVD_FEATURES
from src.calc.domain.inference import LoadedModel
from src.calc.infra.model_loader import load_models
from utils.modeling import table_to_risk_AIRI

_ROOT = Path(__file__).resolve().parents[1]
_BASE = np.array([63, 1, 27.4, 145, 30, 1.1, 3.6, 0, 0, 0, 1, 0], dtype=np.float64)
Row = NDArray[np.float64]


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("Значение должно быть положительным")
    return parsed


def compare_period(period: str, args: argparse.Namespace, loaded: dict[str, LoadedModel]) -> dict[str, Any]:
    model = joblib.load(_ROOT / f"src/models/{period}_model.pkl")
    scaler, groups = model[0], model[1]
    incidence = pd.read_csv(_ROOT / f"src/data/{period}_incidence.csv", index_col=0, header=[0, 1]).round(2)
    fast = loaded[period]
    calculator = CvdCalculator(loaded)
    flat_parameters = {}
    for sex in (0.0, 1.0):
        sub = groups.models[sex]
        coefficient = np.insert(sub.coef_[0], 1, 0.0)
        flat_parameters[sex] = (
            (coefficient * scaler.scale_).reshape(1, -1),
            sub.intercept_[0] + np.dot(coefficient, scaler.min_),
        )

    def reference_probability(row: Row) -> float:
        return float(model.predict_proba(pd.DataFrame([row], columns=CVD_FEATURES))[0, 1])

    def flat_probability(row: Row) -> float:
        coefficient, intercept = flat_parameters[row[1]]
        return float(expit(row.reshape(1, -1) @ coefficient.T + intercept)[0, 0])

    def rounded(probability: float, cached: bool) -> tuple[float, float]:
        score = probability * 100.0
        risk = np.clip(fast.risk_curve(score), 0, 100) if cached else table_to_risk_AIRI(score, incidence)
        return round(score, 1), round(float(risk), 1)

    def empty_stats() -> dict[str, Any]:
        return {
            "rows": 0,
            "staged_max_probability_error": 0.0,
            "flat_max_probability_error": 0.0,
            "staged_rounding_mismatches": 0,
            "flat_rounding_mismatches": 0,
        }

    def observe(stats: dict[str, Any], row: Row, threshold: str | None = None) -> None:
        reference = reference_probability(row)
        staged = fast.model.predict_probability(row)
        flat = flat_probability(row)
        original_result = rounded(reference, False)
        staged_result, flat_result = rounded(staged, True), rounded(flat, True)
        stats["rows"] += 1
        stats["staged_max_probability_error"] = max(stats["staged_max_probability_error"], abs(reference - staged))
        stats["flat_max_probability_error"] = max(stats["flat_max_probability_error"], abs(reference - flat))
        stats["staged_rounding_mismatches"] += original_result != staged_result
        stats["flat_rounding_mismatches"] += original_result != flat_result
        if threshold and original_result != flat_result and stats["first_flat_mismatch"] is None:
            stats["first_flat_mismatch"] = {
                "sex": float(row[1]),
                "age": float(row[0]),
                "threshold": threshold,
                "reference_probability": reference,
                "flat_probability": flat,
                "reference_result": original_result,
                "flat_result": flat_result,
            }

    random_stats = empty_stats()
    rng = np.random.default_rng(args.seed)
    for i in range(args.count):
        row = rng.uniform(size=12) * [120, 0, 90, 250, 1000, 20, 30, 1, 1, 1, 1, 1]
        row += [0, i % 2, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0]
        observe(random_stats, row)

    boundary_stats = {**empty_stats(), "score_thresholds": 0, "risk_thresholds": 0, "first_flat_mismatch": None}
    for sex in (0.0, 1.0):

        def row_at(age: float, group: float = sex) -> Row:
            return np.array([age, group, *_BASE[2:]], dtype=np.float64)

        def score_at(age: float) -> float:
            return reference_probability(row_at(age)) * 100.0

        def risk_at(age: float) -> float:
            return float(table_to_risk_AIRI(score_at(age), incidence))

        for key, function in (("score", score_at), ("risk", risk_at)):
            low, high = function(0), function(120)
            targets = np.arange(np.floor(low * 10) / 10 + 0.05, high, 0.1)[:: args.boundary_stride]
            for target in targets:
                if not low <= target <= high:
                    continue
                age = brentq(lambda value, fn=function, goal=target: fn(value) - goal, 0, 120, xtol=5e-15, rtol=1e-15)
                boundary_stats[key + "_thresholds"] += 1
                observe(boundary_stats, row_at(age), key)
                for direction in (-np.inf, np.inf):
                    neighbor = age
                    for _ in range(args.neighbors):
                        neighbor = np.nextafter(neighbor, direction)
                        observe(boundary_stats, row_at(neighbor), key)

    def direct(cached: bool) -> tuple[float, float]:
        scaled = _BASE * scaler.scale_
        scaled += scaler.min_
        sub = groups.models[scaled[1]]
        frame = pd.DataFrame([np.delete(scaled, 1)], columns=[name for name in CVD_FEATURES if name != "SEX"])
        return rounded(float(sub.predict_proba(frame)[0, 1]), cached)

    variants: dict[str, Callable[[], object]] = {
        "baseline_pipeline_and_interp": lambda: rounded(reference_probability(_BASE), False),
        "direct_sex_model_and_interp": lambda: direct(False),
        "direct_sex_model_cached_interp": lambda: direct(True),
        "staged_coeff_rebuilt_interp": lambda: rounded(fast.model.predict_probability(_BASE), False),
        "staged_coeff_cached_interp": lambda: calculator.calculate_row(period, tuple(_BASE)),
        "flat_coeff_cached_interp": lambda: rounded(flat_probability(_BASE), True),
    }
    timings = {}
    for name, function in variants.items():
        for _ in range(50):
            function()
        samples = np.array(timeit.repeat(function, repeat=args.repeats, number=args.calls)) * 1e6 / args.calls
        timings[name] = {
            "median_us": float(np.median(samples)),
            "min_us": float(samples.min()),
            "max_us": float(samples.max()),
            "repeats": args.repeats,
            "calls_per_repeat": args.calls,
        }
    return {
        "structure": (
            "Pipeline(MinMaxScaler[float32, clip=False], BinaryStratifiedModel[SEX: LogisticRegression binary OvR])"
        ),
        "random": random_stats,
        "boundaries": boundary_stats,
        "timing": timings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=310)
    parser.add_argument("--count", type=positive_int, default=2000, help="Случайных строк на период")
    parser.add_argument("--boundary-stride", type=positive_int, default=5, help="Шаг по десятичным границам округления")
    parser.add_argument("--neighbors", type=positive_int, default=8, help="Соседей float64 в каждую сторону")
    parser.add_argument("--repeats", type=positive_int, default=5)
    parser.add_argument("--calls", type=positive_int, default=1000)
    parser.add_argument("--output", type=Path, default=Path(tempfile.gettempdir()) / "cvd310-model-experiments.json")
    args = parser.parse_args()
    loaded = load_models(_ROOT / "src/models", _ROOT / "src/data")
    result = {
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "sklearn": sklearn.__version__,
        },
        "options": {key: value for key, value in vars(args).items() if key != "output"},
        "artifacts_sha256": {
            str(path.relative_to(_ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for directory, pattern in (("src/models", "*.pkl"), ("src/data", "*_incidence.csv"))
            for path in sorted((_ROOT / directory).glob(pattern))
        },
        "periods": {period: compare_period(period, args, loaded) for period in ("Y2", "Y5")},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Результат сохранён: {args.output}")


if __name__ == "__main__":
    main()
