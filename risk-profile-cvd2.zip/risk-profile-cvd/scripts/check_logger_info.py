#!/usr/bin/env python3
"""Запрещает прямые INFO-логи: `logger.info(`, `logging.info(`, `logger.log(logging.INFO`.

Единственный легальный INFO-канал в проде — `channel="business"` через хелпер
`src.logger.business(...)`. Любой другой INFO либо съест fingers-crossed (если не было ERROR
в запросе — лог потеряется), либо обойдёт его и засрёт поток в обход контракта. Эта проверка —
структурная страховка: если кто-то регрессирует business → logger.info, CI красный.

Запускается из `make lint-logger` (рядом с `ruff check`).

Допустимые исключения:
- `src/logger.py` — собственно реализация (`business()` использует `logger.log(logging.INFO, ...)`).
- `tests/` — игнорируем, тесты создают LogRecord'ы для проверки фильтров/хендлеров.
- `scripts/check_logger_info.py` — этот файл (содержит сами паттерны).
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

# Каталоги, в которых ищем. tests/ намеренно не включаем.
SEARCH_DIRS: tuple[str, ...] = ("src", "scripts")

# Файлы (rel-path от repo root), которым разрешено содержать INFO-вызовы.
ALLOWED_FILES: frozenset[str] = frozenset(
    {
        "src/logger.py",
        "scripts/check_logger_info.py",
    }
)

# Паттерны: `logger.info(`, `logging.info(`, `logger.log(logging.INFO`, `logger.log(20`,
# и варианты с whitespace.
_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\blogger\s*\.\s*info\s*\("),
    re.compile(r"\blogging\s*\.\s*info\s*\("),
    re.compile(r"\blogger\s*\.\s*log\s*\(\s*logging\s*\.\s*INFO\b"),
    re.compile(r"\blogger\s*\.\s*log\s*\(\s*20\b"),
)


def _iter_python_files(repo_root: Path) -> list[Path]:
    files: list[Path] = []
    for d in SEARCH_DIRS:
        root = repo_root / d
        if not root.exists():
            continue
        files.extend(p for p in root.rglob("*.py") if "__pycache__" not in p.parts)
    return files


def _is_allowed(path: Path, repo_root: Path) -> bool:
    try:
        rel = path.relative_to(repo_root).as_posix()
    except ValueError:
        return False
    return rel in ALLOWED_FILES


def _scan_file(path: Path) -> list[tuple[int, str]]:
    """Возвращает список (lineno, line) для строк с нарушениями.

    Не-UTF8 файлы скипаем с warn — альтернатива «крашить линтер UnicodeDecodeError» дала бы
    CI-красное без осмысленного сообщения, неотличимое от настоящего нарушения."""
    violations: list[tuple[int, str]] = []
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        print(f"WARN: skipping {path} (non-UTF-8 content)", file=sys.stderr)
        return violations
    for idx, line in enumerate(text.splitlines(), start=1):
        # Игнорируем строки-комментарии целиком (но не inline-комментарии — паттерн внутри
        # кода всё равно подозрителен).
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        if any(p.search(line) for p in _PATTERNS):
            violations.append((idx, line.rstrip()))
    return violations


def scan(repo_root: Path) -> list[str]:
    """Сканирует репозиторий, возвращает отформатированный список нарушений (пустой = ok)."""
    findings: list[str] = []
    for path in _iter_python_files(repo_root):
        if _is_allowed(path, repo_root):
            continue
        for lineno, line in _scan_file(path):
            rel = path.relative_to(repo_root).as_posix()
            findings.append(f"  {rel}:{lineno}: {line.strip()}")
    return findings


def main() -> int:
    findings = scan(REPO_ROOT)
    if findings:
        print("FAIL: forbidden INFO-level logger usage found.")
        print("Use business(...) for always-on INFO or notice(...) for production-visible logs.")
        print("See src/logger.py for helpers.\n")
        print("\n".join(findings))
        return 1

    print("OK: no direct INFO-level logger calls outside src/logger.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
