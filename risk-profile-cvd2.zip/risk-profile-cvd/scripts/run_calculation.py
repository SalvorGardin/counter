import json
import argparse
from pathlib import Path

from src.calculator import UniversalBiomarkerCalculator


def main():
    parser = argparse.ArgumentParser(
        description='Biomarker Calculator - расчет биомаркеров здоровья'
    )
    parser.add_argument(
        '--input', 
        type=str, 
        help='Путь к входному JSON файлу'
    )
    parser.add_argument(
        '--output', 
        type=str, 
        help='Путь к выходному JSON файлу'
    )
    parser.add_argument(
        '--input-dir', 
        type=str, 
        default='tests/test_data',
        help='Директория с входными JSON файлами (по умолчанию: tests/test_data)'
    )
    parser.add_argument(
        '--output-dir', 
        type=str, 
        default='tests/output',
        help='Директория для результатов (по умолчанию: tests/output)'
    )
    
    args = parser.parse_args()
    
    calculator = UniversalBiomarkerCalculator()
    
    if args.input and args.output:
        print(f"📄 Обработка {args.input}...")
        
        with open(args.input, "r", encoding="utf-8") as f:
            input_data = json.load(f)
        
        result = calculator.process(input_data)

        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Результат сохранен в {args.output}")

    else:
        input_dir = Path(args.input_dir)
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        json_files = list(input_dir.glob("*.json"))
        
        if not json_files:
            print(f"⚠️  JSON файлы не найдены в {input_dir}")
            return
        
        print(f"📁 Найдено {len(json_files)} JSON файлов")
        print("=" * 60)
        
        success_count = 0
        error_count = 0
        
        for input_file in json_files:
            print(f"\n📄 Обработка {input_file.name}...")
            
            try:
                with open(input_file, "r", encoding="utf-8") as f:
                    input_data = json.load(f)
                
                result = calculator.process(input_data)
                
                output_file = output_dir / f"{input_file.stem}_output.json"
                
                with open(output_file, "w", encoding="utf-8") as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                
                print(f"✅ Результат сохранен в {output_file}")
                success_count += 1
                
            except Exception as e:
                print(f"❌ Ошибка при обработке {input_file.name}: {e}")
                error_count += 1
        
        print("\n" + "=" * 60)
        print(f"✅ Успешно обработано: {success_count}")
        if error_count > 0:
            print(f"❌ Ошибок: {error_count}")
        print("=" * 60)


if __name__ == "__main__":
    main()