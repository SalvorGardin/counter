"""Изолированный benchmark middleware и DI; без сети, реальной модели и записи stdout.

Пример после установки dev-зависимостей и подготовки baseline checkout:
    python scripts/benchmark_http_overhead.py \
        --baseline-main /path/to/baseline/src/main.py --output /path/to/http-overhead.json

Исходный main.py загружается как локальный Python-модуль, поэтому используйте доверенный
baseline checkout. Его lifespan не запускается. Замер использует отдельный синтетический
маршрут, две зависимости и один threadpool no-op; JSON formatter и fingers-crossed работают,
но stream заменён sink. Результаты показывают накладные расходы ASGI/DI, а не production RPS
или полную задержку расчёта. Текущий RequestContextMiddleware импортируется из этого checkout.
"""

import argparse
import asyncio
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import logging
import platform
import statistics
import sys
import time
from collections.abc import Awaitable, Callable, Iterator
from contextlib import contextmanager
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_REPO_ROOT))

import httpx2 as httpx  # noqa: E402
from fastapi import Depends, FastAPI, Request, Response  # noqa: E402
from starlette.concurrency import run_in_threadpool  # noqa: E402

from src import logger as logmod  # noqa: E402
from src.api.request_context import RequestContextMiddleware  # noqa: E402
from src.config import settings  # noqa: E402

HttpMiddleware = Callable[[Request, Callable[[Request], Awaitable[Response]]], Awaitable[Response]]
_PROBE_PATHS = {"/health", "/readiness", "/liveness", "/"}


class Sink(io.TextIOBase):
    """Принимает отформатированные строки без stdout I/O и накопления данных."""

    def write(self, value: str) -> int:
        return len(value)

    def flush(self) -> None:
        pass


@contextmanager
def sink_logging() -> Iterator[None]:
    original_handlers = logmod.logger.handlers
    original_level = settings.log_level
    stream = logging.StreamHandler(Sink())
    stream.setFormatter(logmod.MonologFormatter())
    handler = logmod.FingersCrossedHandler(stream)
    handler.addFilter(logmod.MonologFilter())
    logmod.logger.handlers = [handler]
    settings.log_level = "NOTICE"
    try:
        yield
    finally:
        logmod.logger.handlers = original_handlers
        settings.log_level = original_level
        handler.close()
        stream.close()


def baseline_middleware(path: Path) -> HttpMiddleware:
    """Получить исходную middleware, сохранив её helpers и константы из baseline."""
    spec = importlib.util.spec_from_file_location("cvd_http_overhead_baseline", path)
    if spec is None or spec.loader is None:
        raise ValueError("Не удалось загрузить baseline main.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    middleware = getattr(module, "request_middleware", None)
    if not callable(middleware):
        raise ValueError("В baseline main.py отсутствует request_middleware")
    return middleware


def make_app(kind: str, dependencies: str, original: HttpMiddleware) -> FastAPI:
    app = FastAPI()

    def synchronous_dependency() -> int:
        return 1

    async def asynchronous_dependency() -> int:
        return 1

    dependency = synchronous_dependency if dependencies == "sync" else asynchronous_dependency

    def synthetic_inference() -> None:
        pass

    @app.post("/api/v1/calculate")
    async def calculate(
        _first: int = Depends(dependency),
        _second: int = Depends(dependency, use_cache=False),
    ) -> dict[str, bool | float]:
        await run_in_threadpool(synthetic_inference)
        logmod.business("cvd.calculate: completed", {"period": "Y5"})
        return {"isSuccess": True, "score": 12.3, "riskPercentage": 45.6}

    if kind == "base":
        app.middleware("http")(original)
    else:
        app.add_middleware(RequestContextMiddleware, probe_paths=_PROBE_PATHS)
    return app


async def measure(
    kind: str,
    dependencies: str,
    original: HttpMiddleware,
    parallel: int,
    requests: int,
    warmup: int,
) -> dict[str, float]:
    app = make_app(kind, dependencies, original)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://benchmark") as client:

        async def request() -> float:
            started = time.perf_counter()
            response = await client.post(
                "/api/v1/calculate", content=b"{}", headers={"X-Request-ID": "synthetic-benchmark"}
            )
            if response.status_code != 200:
                raise RuntimeError(f"Синтетический маршрут вернул HTTP {response.status_code}")
            return (time.perf_counter() - started) * 1e6

        for _ in range(warmup):
            await request()
        started = time.perf_counter()
        latencies = []
        while len(latencies) < requests:
            batch = min(parallel, requests - len(latencies))
            latencies.extend(await asyncio.gather(*(request() for _ in range(batch))))
        elapsed = time.perf_counter() - started

    ordered = sorted(latencies)
    return {
        "us_mean": round(statistics.mean(latencies), 1),
        "us_p50": round(statistics.median(latencies), 1),
        "us_p95": round(ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))], 1),
        "us_p99": round(ordered[min(len(ordered) - 1, int(len(ordered) * 0.99))], 1),
        "rps": round(len(latencies) / elapsed),
    }


async def benchmark(arguments: argparse.Namespace) -> dict:
    original = baseline_middleware(arguments.baseline_main)
    measurements = []
    with sink_logging():
        for parallel in arguments.parallel:
            for dependencies in ("sync", "async"):
                for kind in ("base", "asgi"):
                    repeats = [
                        await measure(kind, dependencies, original, parallel, arguments.requests, arguments.warmup)
                        for _ in range(arguments.repeats)
                    ]
                    measurements.append(
                        {
                            "parallel": parallel,
                            "threadpool_calc": True,
                            "deps": dependencies,
                            "middleware": kind,
                            **{
                                key: round(statistics.median(repeat[key] for repeat in repeats), 1)
                                for key in repeats[0]
                            },
                            "repeats": repeats,
                        }
                    )
    return {
        "metadata": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "fastapi": importlib.metadata.version("fastapi"),
            "starlette": importlib.metadata.version("starlette"),
            "httpx2": importlib.metadata.version("httpx2"),
            "baseline_main_sha256": hashlib.sha256(arguments.baseline_main.read_bytes()).hexdigest(),
            "requests_per_repeat": arguments.requests,
            "warmup_requests": arguments.warmup,
            "repeats": arguments.repeats,
            "method": "ASGITransport, synthetic threadpool no-op, JSON formatting active, stdout sink",
            "aggregation": "median across repeats for each reported metric",
        },
        "measurements": measurements,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--baseline-main", type=Path, required=True)
    parser.add_argument("--output", type=Path, help="JSON-файл; без параметра отчёт выводится в stdout")
    parser.add_argument("--requests", type=int, default=1024)
    parser.add_argument("--warmup", type=int, default=100)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--parallel", type=int, nargs="+", default=[1, 16])
    arguments = parser.parse_args()
    if not arguments.baseline_main.is_file():
        parser.error("--baseline-main должен указывать на существующий main.py baseline checkout")
    if arguments.requests < 1 or arguments.repeats < 1 or arguments.warmup < 0:
        parser.error("requests/repeats должны быть положительными, warmup — неотрицательным")
    if any(parallel < 1 for parallel in arguments.parallel):
        parser.error("parallel должен содержать положительные числа")
    report = json.dumps(asyncio.run(benchmark(arguments)), indent=2, ensure_ascii=False) + "\n"
    if arguments.output is None:
        print(report, end="")
    else:
        arguments.output.write_text(report, encoding="utf-8")


if __name__ == "__main__":
    main()
