# Reliability, Performance, and Data lens

Analyze runtime behavior under load or failure and with real persisted data. Read database migrations, models,
repositories, and affected read/write paths together. Never post comments or modify files.

## Criteria

- `#5 Performance`: N+1 queries, quadratic hot paths, unbounded reads, missing pagination, and blocking I/O.
- `#7 Error handling`: silent failures, incorrect exception scope, missing context or traceback, and invalid domain
  exception hierarchy.
- `#10 Database and data layer`: repository behavior, transaction boundaries, async SQLAlchemy, and data invariants.
- `#12 Concurrency`: races, unsafe shared state, locking, and ordering across awaits or workers.
- `#17 Resource lifecycle`: clients, sessions, connections, files, or streams without guaranteed cleanup.
- `#18 Idempotency and retry safety`: duplicate effects, partial failure, retry behavior, and idempotency keys.
- `#21 Scalability`: in-memory assumptions, per-request growth, and behavior across multiple instances.
- Migration safety: locks, deploy ordering, reversibility, and the catalog-remapping invariants in `AGENTS.md`.

Treat data loss or corruption, unsafe migrations, silently lost work, production-breaking races, and broadly swallowed
errors as serious. Use medium for bounded but concrete runtime risks. Verify that external HTTP uses async `httpx` and
that migrations are invoked outside application code.

Reliability owns persistence invariants and migration mechanics. Mark API-boundary validation and public-contract
pointers `confidence=low` for the owning lens.

Return only entries in the finding contract from `aggregation-posting.md`, or `NO FINDINGS`. Do not report nits.

