# Security and Privacy lens

Review trust boundaries and attack surface. Inspect the full head-version context around changed inputs and trace
untrusted data to privileged operations, persistence, outbound requests, and logs.

## Criteria

- `#1 Security`: injection, authorization bypass, insecure defaults, unsafe deserialization, SSRF, and path traversal.
- `#19 Authorization versus authentication`: including server-to-server versus client-to-server mechanisms.
- `#20 Boundary validation`: Pydantic validation at API edges and normalization before privileged use.
- `#13 Configuration and secrets`: environment-backed settings and `SecretStr` where applicable.
- `#24 Privacy`: personal or sensitive data exposed through logs, errors, request/response bodies, or traces.

Treat hardcoded real credentials, exploitable injection, authorization bypass, and unmasked sensitive-data disclosure
as serious. Do not report a credential-like test value without verifying it is a real secret rather than generated
fixture data.

Security owns external-boundary validation and configuration secrets. Return persistence-integrity or log-diagnostics
overlaps as low-confidence pointers so the owning lens can decide.

Return only entries in the finding contract from `aggregation-posting.md`, or `NO FINDINGS`. Do not report nits.
