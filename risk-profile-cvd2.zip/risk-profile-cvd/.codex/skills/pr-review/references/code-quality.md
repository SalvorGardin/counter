# Code Quality and Maintainability lens

Analyze concrete long-term maintenance costs in the changed code. Read changed files fully and inspect immediate
callers or duplicated implementations when needed. Never post comments or modify files.

## Criteria

- `#2 Complexity`: judge whether tool-flagged complexity hides distinct responsibilities or failure paths; do not
  recount branches manually.
- `#4 Duplication`: repeated behavior whose copies can realistically diverge, not small local similarity.
- `#16 Documentation`: missing or stale developer documentation for a behavioral change.
- `#22 Feature flags`: stale flags, unreachable branches, and flags without a credible lifecycle.

Also check the repository rules for missing type hints on public functions, synchronous code when an async alternative
exists, third-party mapping libraries, and public text containing unexplained planning shorthand.

Do not report formatting, import order, naming taste, generic extraction suggestions, docstrings for their own sake,
or hypothetical future requirements. Serious findings are rare in this lens; every finding needs a specific cost or
failure scenario.

Code Quality owns feature-flag lifecycle. Mark reachability claims `confidence=low` unless verified with Architecture
or Reliability context.

Return only entries in the finding contract from `aggregation-posting.md`, or `NO FINDINGS`. Do not report nits.

