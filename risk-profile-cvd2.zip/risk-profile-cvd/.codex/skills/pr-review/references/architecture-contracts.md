# Architecture and Contracts lens

Review structural integrity, dependency direction, public contracts, compatibility, and blast radius. Map callers and
consumers before claiming a contract break.

## Criteria

- `#3 Architecture conformance`: `router -> handler -> domain service -> repository/client`, inward dependencies,
  domain independence, and repository abstractions that keep SQLAlchemy out of the domain.
- `#6 Application architecture`: domain-oriented modules, isolated integrations, manual FastAPI DI through
  `Depends()`, and business logic outside routers and repositories.
- `#11 API contract stability`: changed requests, responses, routes, status codes, events, and schemas.
- `#15 Backward compatibility`: versioning and migration paths for consumers.
- `#23 Change scope`: unexpected coupling, blast radius, and unrelated scope expansion.

Trace imports and all discoverable consumers. A consumer-breaking change or major dependency inversion can be serious;
an enforceable layer or API-convention violation is medium. Do not report preferred abstractions without a concrete
failure or maintenance cost.

Architecture owns interface compatibility. Return database-migration mechanics as low-confidence pointers for the
Reliability lens.

Return only entries in the finding contract from `aggregation-posting.md`, or `NO FINDINGS`. Do not report nits.
