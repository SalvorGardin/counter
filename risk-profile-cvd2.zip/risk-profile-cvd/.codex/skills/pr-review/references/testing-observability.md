# Testing and Observability lens

Analyze whether the changed behavior can be trusted and diagnosed. Read production code and its tests together. Judge
assertions and failure coverage, not raw coverage percentage. Never post comments or modify files.

## Criteria

- `#9 Test quality`: critical paths and edge cases, assertions that pin intended behavior, redundant tests, tests
  without effective assertions, correct unit/integration placement, and fixtures at the correct level.
- `#8 Observability`: actionable logging, metrics, or tracing on new failure paths, including operation context and
  traceback through `exc_info`.
- `#25 Correctness traps`: timezone-aware datetimes, decimals and money, rounding, encoding, locale, and units.

Dependency substitution in FastAPI tests must use `app.dependency_overrides`. Do not demand tests generically: report
a gap only when a changed failure scenario or invariant is both material and plausibly regressible. Combine a
production defect and its missing regression test when they have one root cause.

Testing and Observability owns log diagnostics and sensitive log content. Mark configuration-secret pointers
`confidence=low` for Security.

Return only entries in the finding contract from `aggregation-posting.md`, or `NO FINDINGS`. Do not report nits.

