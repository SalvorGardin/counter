# Aggregation and GitLab posting

## Finding contract

Require each specialist to return only entries in this form, or `NO FINDINGS`:

```text
[serious|medium] criterion=#<number> file=<repository-relative path> line=<diff line> confidence=<high|low>
<specific failure scenario and evidence> -> <smallest concrete fix>
```

The line must be present in the MR diff. `confidence=low` is only for a valid cross-lens pointer; it is not a license
for speculation.

## Reconciliation

For every candidate:

1. Verify it against the MR head, surrounding code, callers, tests, and applicable repository instruction. Discard
   claims that rely on stale local files or behavior already handled elsewhere.
2. Collapse findings with the same root cause. Preserve the clearest failure scenario and smallest viable fix.
3. On justified severity disagreement, keep the higher severity. Do not inflate severity merely because multiple
   agents reported the issue.
4. Resolve overlaps by ownership:

   - Security owns validation at an external trust boundary; Reliability owns persistence invariants.
   - Architecture owns public/API contract compatibility; Reliability owns migration mechanics.
   - Security owns secrets in configuration; Testing and Observability owns sensitive data in logs.
   - Architecture or Reliability establishes reachability; Code Quality judges feature-flag lifecycle.

5. Check that the referenced line is an added, changed, deleted, or valid context line in the patch. Move a finding to
   the nearest causative diff line when necessary; discard it if no honest inline location exists and it does not
   justify a concise MR-level finding.
6. Rank serious findings before medium findings. Do not include suggestions or style nits.

## User-facing finding text

Write comments in Russian, one short paragraph per finding. Start with `🔴` for serious or `⚠️` for medium. State
the concrete problem and give the smallest useful remedy. Cite `AGENTS.md`, `docs/`, or a wiki page when the finding
depends on that source and only after checking it.

Before returning or publishing findings, remove internal metadata: lens names, confidence, orchestration details, and
planning terminology. The text must make sense to a reader who has only the MR, repository documentation, and linked
issue. Do not expose criteria numbers or mention another reviewer.

## Posting authorization and procedure

Publishing is an external write. Do it only when the user's current request explicitly asks to post, publish, or leave
comments. Otherwise show the reconciled findings in chat.

For authorized posting, call the GitLab discussions API once per finding. Send a real nested JSON body through
`glab api --input` with `Content-Type: application/json`; bracketed or dotted `-f` keys are flat fields and can silently
create a contextless general note.

The JSON body must contain `body` plus a `position` object with `position_type: "text"`, all three diff SHAs, the old
and new paths, and the appropriate line fields. Verify every response before sending the next comment:

- `notes[0].type` must equal `DiffNote`.
- `notes[0].position` must be non-null.
- If either check fails, delete the malformed note immediately and stop.

- Added or changed line: `--side new --line <new line>`.
- Deleted line: `--side old --line <old line>`.
- Unchanged context line: `--side context --line <line>` only when old and new line numbers are identical; otherwise
  prefer the causative changed line.
- Renamed file: pass both `--old-path` and `--new-path`.

Stop on the first failed post. Report whether a malformed note was removed. Never continue posting after an
unverified response.
