---
name: pr-review
description: Review GitLab MRs with specialist agents, deduplicate serious or medium findings, and optionally post.
---

# PR Review

Review a GitLab merge request using Codex collaboration agents. Keep the user's worktree unchanged and treat the
GitLab diff and MR head SHA as the source of truth.

## Input and authorization

- Accept an MR IID or URL. If neither is supplied, resolve the MR for the current branch with `glab mr view`.
- Use GitLab project `risk-profile/risk-profile-cvd` and pass `-R risk-profile/risk-profile-cvd` to `glab mr`
  commands.
- A request to review authorizes read-only analysis only. Post GitLab comments only when the user explicitly asks to
  post, publish, or leave comments on the MR.
- Never checkout, pull, reset, clean, or otherwise change the worktree for a review. Do not modify repository files.
- If MR data cannot be read, report the precise authentication or connectivity problem. Do not substitute a stale
  local diff silently.

## Workflow

1. Read the applicable `AGENTS.md` files and [aggregation and posting rules](references/aggregation-posting.md).
2. Resolve the MR and collect its title, description, URL, changed paths, patch, and `diff_refs` (`base_sha`,
   `start_sha`, `head_sha`) using read-only `glab` commands. Use `mktemp -d` for a shared patch file when the diff is
   too large to place in agent prompts.
3. Triage the changed behavior and select only relevant lenses:

   - [Security and privacy](references/security-privacy.md): trust boundaries, authentication, authorization,
     secrets, or personal data.
   - [Architecture and contracts](references/architecture-contracts.md): module boundaries, API/schema contracts,
     dependency direction, or broad refactors.
   - [Reliability and data](references/reliability-data.md): runtime behavior, databases, migrations, async I/O,
     concurrency, retries, resources, or performance.
   - [Testing and observability](references/testing-observability.md): changed behavior or failure paths whose tests
     and diagnostics need review.
   - [Code quality](references/code-quality.md): substantial control-flow changes, duplication, feature flags, or
     developer documentation.

   Skip irrelevant lenses. Ordinary production-code changes usually warrant Reliability and Testing; do not run all
   lenses mechanically.
4. Read every selected lens reference completely. Spawn one collaboration agent per selected lens. Give each agent:

   - the MR IID, URL, head SHA, changed paths, and patch or shared patch path;
   - its lens reference and all applicable repository instructions;
   - permission for read-only inspection only;
   - an explicit prohibition on posting, editing files, spawning agents, and reporting style-only nits.

   Dispatch as many selected agents concurrently as available slots allow, then dispatch the remainder when slots
   become free. The root agent remains the orchestrator and is the only agent allowed to publish.
5. For full-file context, first use a local file only when its blob matches the MR head. Otherwise read the file at
   `head_sha` through the GitLab repository-files API. Never judge head code from a different local revision.
6. Run narrow, relevant deterministic checks when they can validate changed code without changing the worktree.
   Treat their output as evidence, not as a reason to skip semantic review. Avoid full-repository scans unrelated to
   the diff.
7. Reconcile and verify all returned findings against the MR head and patch. Follow the aggregation reference.
8. If posting was explicitly requested, publish each verified serious or medium finding as a GitLab diff note using
   the nested-JSON procedure in the aggregation reference. Otherwise return the findings in chat with file and line
   locations.
9. End with a compact overview: counts, MR URL, selected/skipped lenses, checks run, and up to three main themes.

## Review threshold

Surface only issues that can cause incorrect behavior, security/privacy exposure, data loss or corruption,
availability or operational failure, broken contracts, or a concrete maintainability burden. Do not report formatting,
import order, naming taste, speculative future needs, or generic requests for more tests.

Use only two severities:

- `serious`: likely production failure, data loss, security/privacy breach, or consumer-breaking contract.
- `medium`: concrete bug, rule violation, test gap on changed risky behavior, or material maintainability/operability
  problem that should be fixed before merge.

No finding is preferable to a weak finding.
