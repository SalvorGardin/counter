# Метрики Prometheus — risk-profile-cvd

Сервис отдаёт метрики входящих HTTP-запросов: по ним строятся латентность, число запросов и доля
ошибок. Контракт метрики тот же, что у `risk-profile-core` (`docs/metrics.md` в его репозитории):
гистограмма со стандартными бакетами `prometheus_client` и лейблами `method`, `path`, `status`, `host`.

## Ручка

`GET /metrics` — текстовый формат Prometheus, заголовок
`Content-Type: text/plain; version=1.0.0; charset=utf-8`.

**Без авторизации**, как и пробы `/health`, `/readiness`, `/liveness`: в выдаче только агрегаты и
шаблоны маршрутов, данных запросов (тел, URL, заголовков) в ней нет. Доступ ограничивается сетью:
и собственный `docker-compose.yml` cvd, и compose ядра на дев-стенде публикуют порт сервиса только на
`127.0.0.1` (см. «Как проверить на дев-стенде»).

Рекомендуемый `scrape_interval` — **15 с**.

## Метрика

| Метрика | Тип | Лейблы | Что показывает |
|---|---|---|---|
| `risk_profile_cvd_http_request_duration_seconds` | Histogram | `method`, `path`, `status`, `host` | Время обработки входящего HTTP-запроса сервисом, секунды. `_count` — число запросов, `_sum` — суммарное время, `_bucket` — распределение по корзинам. Доля ошибок — по `status`. |

Корзины (`le`) — стандартные `prometheus_client`: `0.005, 0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5,
0.75, 1, 2.5, 5, 7.5, 10` секунд и `+Inf`. Запросы дольше 10 с попадают только в `+Inf`, но учтены в
`_count` и `_sum`. Отдельного счётчика запросов нет: его роль играет `_count`.

Значения суммируются по всем uvicorn-воркерам сервиса (`CVD_WORKERS`): один ряд на набор лейблов,
лейбла `pid` нет.

### Значения лейблов

- **`method`** — `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, `OPTIONS`; любой другой метод — `other`.
- **`path`** — шаблон маршрута, а не фактический URL. Сейчас это `/api/v1/calculate`, а также:
  - `unmatched` — запрос не попал ни в один маршрут (неизвестный путь, в том числе путь
    `/api/v1/calculate/` с лишним слешем, на который сервис отвечает редиректом);
  - `other` — маршрут, скрытый из схемы API: служебные страницы документации `/docs`, `/redoc`,
    `/openapi.json`.
- **`status`** — HTTP-код ответа строкой: `"200"`, `"400"`, `"404"`. Запрос, обработка которого
  завершилась необработанной ошибкой до начала ответа, учитывается как `"500"`. Коды сервиса:
  - `400` — тело запроса не прошло валидацию (`riskFactors`), ошибка вызывающей стороны;
  - `404` / `405` — неизвестный путь или неподдерживаемый метод;
  - `422` — `CALCULATION_FAILED`: модель не смогла посчитать риск. Это сбой расчёта на стороне
    сервиса, а не ошибка клиента — в доле ошибок его стоит считать отдельно (см. PromQL ниже);
  - `500` — внутренняя ошибка сервиса.
- **`host`** — имя хоста контейнера сервиса (в Docker — короткий ID контейнера), а не заголовок
  `Host` запроса. Меняется, когда контейнер пересоздаётся (например, при деплое); при рестарте того
  же контейнера не меняется.

### Что учитывается и что нет

Наблюдения пишет `MetricsMiddleware` (`src/api/middleware.py`) — внешний слой приложения, снаружи
`RequestContextMiddleware`. Отсчёт начинается, когда запрос входит в приложение, и заканчивается,
когда приложение закончило его обработку: ответ целиком передан HTTP-серверу и запись `request completed`
выведена в лог. Учитываются ожидание свободного слота расчёта (`CVD_MAX_CONCURRENCY`), сам расчёт модели,
отправка ответа и логирование запроса.

Поля записи `request completed` измеряют более короткие отрезки того же запроса: `duration_ms` — до
заголовков ответа, `http_duration_ms` — до последнего фрагмента тела. Наблюдение гистограммы не меньше
обоих и больше `http_duration_ms` в основном на время вывода самой записи.

Не учитываются:

- пробы `/`, `/health`, `/readiness`, `/liveness` и сам `/metrics` — и в логах скрейп не пишется как
  `request completed`;
- сеть между вызывающим сервисом и CVD и ожидание соединения до того, как сервис его принял;
- запросы, которые HTTP-сервер отклонил до приложения (некорректный HTTP);
- ошибки соединения и таймауты на стороне вызывающего сервиса: если он перестал ждать ответа, а CVD
  запрос всё же обработал, запрос учтён с фактическим статусом.

## Настройки

| Переменная | По умолчанию | Назначение |
|---|---|---|
| `CVD_METRICS__ENABLED` | `true` | `false` — `GET /metrics` отвечает 404 в формате ошибок сервиса (`{"isSuccess": false, "error": {"code": "HTTP_404", ...}}`). Сбор наблюдений при этом не останавливается. Читается при старте процесса. |
| `PROMETHEUS_MULTIPROC_DIR` | `/tmp/prometheus-multiproc` (задаётся образом) | Директория, в которой каждый воркер хранит свои значения метрик; `/metrics` суммирует их. Очищается при старте сервиса. Менять не нужно. |
| `CVD_WORKERS` | `1` | Число uvicorn-воркеров. Метрики корректны при любом значении. |

Сервис в контейнере запускается командой `python -m src` (`CMD` образа). Точка входа очищает
директорию значений до запуска воркеров, поэтому данные прежнего запуска в выдачу не попадают.

## Скрейп

- Из сети compose ядра (сервис `cvd`): `http://cvd:8000/metrics`.
- На хосте дев-стенда: `http://127.0.0.1:8000/metrics` — порт привязан к `127.0.0.1`, снаружи ручка
  недоступна. Единый доступ к метрикам сервисов стенда — задача risk-profile/risk-profile-core#313.

Пример конфигурации для Prometheus, запущенного в той же сети compose:

```yaml
scrape_configs:
  - job_name: risk-profile-cvd
    scrape_interval: 15s
    metrics_path: /metrics
    static_configs:
      - targets: ["cvd:8000"]
```

## Примеры PromQL

**Запросов в секунду — всего и по маршрутам:**

```promql
sum(rate(risk_profile_cvd_http_request_duration_seconds_count[5m]))
sum by (path) (rate(risk_profile_cvd_http_request_duration_seconds_count[5m]))
```

**Латентность расчёта — p95, p99 и среднее:**

```promql
histogram_quantile(0.95, sum by (le) (rate(risk_profile_cvd_http_request_duration_seconds_bucket{path="/api/v1/calculate"}[5m])))
histogram_quantile(0.99, sum by (le) (rate(risk_profile_cvd_http_request_duration_seconds_bucket{path="/api/v1/calculate"}[5m])))
sum(rate(risk_profile_cvd_http_request_duration_seconds_sum{path="/api/v1/calculate"}[5m]))
  / sum(rate(risk_profile_cvd_http_request_duration_seconds_count{path="/api/v1/calculate"}[5m]))
```

**Доля ответов 5xx:**

```promql
sum(rate(risk_profile_cvd_http_request_duration_seconds_count{status=~"5.."}[5m]))
  / sum(rate(risk_profile_cvd_http_request_duration_seconds_count[5m]))
```

**Доля ответов 4xx, кроме 422 (ошибки вызывающей стороны):**

```promql
sum(rate(risk_profile_cvd_http_request_duration_seconds_count{status=~"4..", status!="422"}[5m]))
  / sum(rate(risk_profile_cvd_http_request_duration_seconds_count[5m]))
```

**Доля сбоев расчёта (422 `CALCULATION_FAILED`) среди запросов расчёта:**

```promql
sum(rate(risk_profile_cvd_http_request_duration_seconds_count{path="/api/v1/calculate", status="422"}[5m]))
  / sum(rate(risk_profile_cvd_http_request_duration_seconds_count{path="/api/v1/calculate"}[5m]))
```

Лейбл `host` при агрегации лучше не использовать: после пересоздания контейнера появляются ряды с
новым `host`, а `sum` по остальным лейблам их объединяет.

## Пример выдачи

Фрагмент выдачи контейнера с `CVD_WORKERS=2` после 12 расчётов, одного невалидного запроса, запроса
на неизвестный путь и открытия `/docs`. Полностью приведён ряд успешных расчётов:

```text
# HELP risk_profile_cvd_http_request_duration_seconds Латентность входящих HTTP-запросов
# TYPE risk_profile_cvd_http_request_duration_seconds histogram
risk_profile_cvd_http_request_duration_seconds_sum{host="bc01b39f1308",method="POST",path="/api/v1/calculate",status="200"} 0.0639692020486109
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.005",method="POST",path="/api/v1/calculate",status="200"} 3.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.01",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.025",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.05",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.075",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.1",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.25",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.5",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="0.75",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="1.0",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="2.5",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="5.0",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="7.5",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="10.0",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_bucket{host="bc01b39f1308",le="+Inf",method="POST",path="/api/v1/calculate",status="200"} 12.0
risk_profile_cvd_http_request_duration_seconds_count{host="bc01b39f1308",method="POST",path="/api/v1/calculate",status="200"} 12.0
```

Строки `_count` остальных рядов той же выдачи:

```text
risk_profile_cvd_http_request_duration_seconds_count{host="bc01b39f1308",method="GET",path="unmatched",status="404"} 1.0
risk_profile_cvd_http_request_duration_seconds_count{host="bc01b39f1308",method="POST",path="/api/v1/calculate",status="400"} 1.0
risk_profile_cvd_http_request_duration_seconds_count{host="bc01b39f1308",method="GET",path="other",status="200"} 1.0
```

Пока контейнер не получил ни одного учитываемого запроса (например, сразу после старта), выдача
пустая — ряды появляются с первым запросом. При локальном запуске без `PROMETHEUS_MULTIPROC_DIR` в
этом случае выдаются только строки `# HELP` и `# TYPE`.

## Как проверить на дев-стенде

На стенде контейнер `risk-profile-core-cvd-1` поднимается compose ядра (профиль `cvd`), его порт
привязан к `127.0.0.1` хоста стенда `5.42.105.101`. Пока не сделан единый доступ к метрикам
(risk-profile/risk-profile-core#313), выдачу смотрят на самом хосте стенда — по SSH, с теми же
параметрами подключения, что у деплоя в `.gitlab-ci.yml`.

1. **Получить выдачу.** На хосте стенда:

   ```bash
   curl -s http://127.0.0.1:8000/metrics
   ```

   Ответ 200 и строки `# HELP` / `# TYPE` гистограммы. Пустой ответ с кодом 200 — сервис с момента
   старта ещё не получил ни одного учитываемого запроса. Ответ 404 с `"code": "HTTP_404"` —
   экспозиция выключена (`CVD_METRICS__ENABLED=false`).

2. **Увидеть рост `_count` после расчёта.** Запомнить значение ряда успешных расчётов:

   ```bash
   curl -s http://127.0.0.1:8000/metrics | grep '_count{.*path="/api/v1/calculate",status="200"'
   ```

   Выполнить расчёт — через сценарий ядра, который вызывает CVD, или напрямую:

   ```bash
   curl -s -X POST http://127.0.0.1:8000/api/v1/calculate -H 'Content-Type: application/json' \
     -d '{"period":"Y5","riskFactors":{"age":63,"sex":1,"bmi":27.4,"systolicBp":145,"lipoproteinA":30,"hdlChol":1.1,"ldlChol":3.6,"lipidDrugs":0,"atherosclerosis":0,"diabetes":0,"famIhdCva":1,"famHypchol":0}}'
   ```

   Повторить первую команду: `_count` вырос на число выполненных расчётов. Запросы к `/health` и к
   самому `/metrics` счётчик не меняют.

3. **Убедиться, что после рестарта счётчики начались с нуля.**

   ```bash
   docker restart risk-profile-core-cvd-1
   curl -s http://127.0.0.1:8000/health   # повторять, пока не ответит {"status":"ok"}
   curl -s http://127.0.0.1:8000/metrics  # пусто: прежних значений нет
   ```

   После одного расчёта `_count` ряда равен `1.0`, а не прежнему значению плюс один. Метка `host` не
   изменилась: контейнер тот же.

4. **Как понимать сброс.** Счётчики живут, пока работает процесс сервиса, и при каждом рестарте или
   пересоздании контейнера начинаются с нуля — так задумано. Prometheus распознаёт сброс
   счётчика сам: `rate()` и `increase()` дают правильные значения через сброс. Мгновенные значения
   `_count` между запусками сравнивать нельзя. Если `_count` уменьшился без рестарта контейнера —
   это не ожидаемое поведение, его стоит зафиксировать.

## Эксплуатационные заметки

- **Сброс счётчиков при рестарте** — штатный counter reset Prometheus, см. выше.
- **Очистка директории значений при старте.** Файловая система контейнера переживает рестарт, а
  процессы в новом запуске получают те же PID; без очистки prometheus_client продолжил бы прежние
  значения. Если воркер упал и uvicorn запустил новый, файл прежнего процесса остаётся до рестарта
  контейнера и его вклад в сумму сохраняется — для счётчиков это корректно.
- **Запуск в обход точки входа** (например, `uvicorn src.main:app` вместо `python -m src` при заданной
  `PROMETHEUS_MULTIPROC_DIR`) директорию не очищает — в контейнере используйте `CMD` образа.
- **Сбой записи метрики** (например, директорию значений удалили во время работы) на запрос не влияет:
  клиент получает обычный ответ, наблюдение теряется, а в лог пишется ERROR `metrics observation failed`
  с traceback. Запись делается после сброса контекста запроса, поэтому её `requestId` — общий
  идентификатор процесса, а не запроса.
- **Сетевое ограничение.** Ручка без авторизации, поэтому оба compose-файла публикуют порт сервиса только
  на `127.0.0.1`. Открывать его на внешних интерфейсах можно только с ограничением источника (firewall,
  доступ только для Prometheus).
- **Выключатель на стенде.** Compose ядра задаёт окружение сервиса `cvd` явным списком, поэтому
  `CVD_METRICS__ENABLED` на стенде начнёт действовать только после добавления переменной в этот
  список. В собственном `docker-compose.yml` cvd переменная уже передаётся.

## Локальный запуск

`python -m src` из корня репозитория запускает сервис так же, как в контейнере. Без
`PROMETHEUS_MULTIPROC_DIR` сервис работает в однопроцессном режиме: при `CVD_WORKERS=1` выдача
корректна, а при нескольких воркерах `/metrics` показывает значения только того воркера, который
обслужил скрейп. Чтобы проверить суммирование локально, задайте директорию для значений — точка
входа создаст и очистит её сама:

```bash
PROMETHEUS_MULTIPROC_DIR=/tmp/cvd-metrics CVD_WORKERS=2 python -m src
```
