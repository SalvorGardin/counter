# AI-сервисы: REST-контракты единого AI-бэкенда

> Статус: проект контрактов для разработки и согласования с AI-командой. Сохранение черновика и отдельная активация уже согласованы. URL, конкретные поля транспортного конверта и коды ошибок ниже — предлагаемая спецификация, а не описание развёрнутого API. Рабочие схемы результатов `REASONING` и `RECOMMENDATION` зафиксированы; продуктовый вход reasoning, пределы текста и правила частичного успеха ещё требуют согласования.

Краткое содержание комплекта: [AI-сервисы: навигация по проектной документации](ИИ-сервисы-навигация-по-документам.md).

## 1. Назначение и общие правила

Вызывающая сторона — отдельный AI-оркестратор; принимающая — единый AI-бэкенд со своей БД. Этот API не предназначен для прямого вызова СберЗдоровьем. Доступа к БД риск-профиля у AI-бэкенда нет.

Источники: [архитектура](ИИ-сервисы-архитектура-и-границы-ответственности.md), [модель оркестратора](ИИ-сервисы-хранение-состояния-и-жизненный-цикл-генераций.md), [AI-БД](ИИ-сервисы-модель-AI-БД-и-пакетная-обработка.md), [состав контекста](ИИ-сервисы-состав-контекста.md), [продуктовые условия](ИИ-сервисы-бизнес-триггеры-и-условия-генерации.md).

| Метод | Назначение | Вызывает LLM |
|---|---|---|
| `POST /v1/generation-applicability` | Проверка одного продукта по контексту | Нет |
| `POST /v1/generation-batches` | Сохранение неизменяемого черновика | Нет |
| `POST /v1/generation-batches/{batchId}/activation` | Разрешение выполнения пакета | Делает задания доступными исполнителю |
| `GET /v1/generation-batches/{batchId}` | Метаданные и состояния всех заданий | Нет |
| `GET /v1/generations/{generationId}/result` | Сохранённый успешный результат | Нет |
| `PUT /v1/generations/{generationId}/acknowledgement` | Подтверждение решения оркестратора | Нет |

Предоставленный `POST /v1/recommendations` сохраняется как исходный интерфейс рекомендательного модуля. Пакетный API требует его доработки: общий контекст и конкретная цель должны обрабатываться раздельно. Новые маршруты не считаются автоматически реализованными поверх старого метода.

### 1.1. Типы, форматы и общий ответ

- JSON, UTF-8; запросы с телом — `Content-Type: application/json`.
- Идентификаторы пакета, задания и проверки — UUID, каноническая строка в нижнем регистре. Создаёт оркестратор; повтор не получает новый ID.
- `clientId` — непустая строка, совпадающая с `context.patient.patient_id`. В продуктовой структуре сохраняется её исходное имя `patient_id`.
- Редакции передаются строками десятичных цифр от `1` до `9223372036854775807` без ведущих нулей; в БД преобразуются в Bigint. Строки исключают потерю точности при JSON-обработке больших целых.
- `productType`: `RECOMMENDATION` или `REASONING`.
- `recommendationSections`: `LIFESTYLE` и/или `MODIFIABLE_FACTORS` без повторов. Для рекомендаций требуется непустой массив; для reasoning поле отсутствует.
- Все поля `*DateTime` передаются в формате `YYYY-MM-DDThh:mm:ss` без суффикса зоны, в UTC; БД хранит timestamp with time zone. Зона фиксируется этим проектом, локальное время серверов не используется.
- Поля без значения возвращаются явно как `null`. У непустых пакетов `tasks` всегда непустой массив. В ответе проверки `systems = null` означает отсутствие систем для проверки.
- Неизвестные поля нового транспортного конверта отклоняются. Правила полей `context` определяются версией продуктовой схемы; старые алиасы в новом конверте не поддерживаются.
- Общий успешный ответ содержит `isSuccess: true`, `error: null`. Ошибка — `isSuccess: false` и `error`; отдельные примеры приведены в разделе 8.
- Размер тела, максимум систем/заданий и пределы параллельности задаются конфигурацией. Численные значения обязательны до запуска, но здесь не выдумываются.
- Межсервисная аутентификация и права описываются эксплуатационным контрактом. Знание UUID не является авторизацией.

### 1.2. Хэш запроса

`requestHash` = SHA-256, 64 символа lower-case hex. Перед вычислением массив `tasks` сортируется по `generationId`; повторяющиеся ID отклоняются. Затем весь JSON запроса сохранения канонизируется по [JCS, RFC 8785](https://www.rfc-editor.org/rfc/rfc8785) и кодируется в UTF-8. Имена объектов сортируются по правилам JCS, порядок остальных массивов сохраняется; повторяющиеся имена свойств, недопустимый Unicode и нечисловые значения отклоняются.

Хэш охватывает все поля тела, включая `batchId`, `clientId`, версию схемы, редакцию параметров, `context` и задания. Самого `requestHash` в исходном теле нет. Он не включает HTTP-заголовки, конфигурацию модели и серверные даты. Обе стороны вычисляют его одинаково; оркестратор сохраняет хэш до первой отправки. При активации возвращает его как `expectedRequestHash`.

`payload_hash` в `ai_context_payloads` вычисляется только по `context` с той же канонизацией. Это хэш полного входа, а не fingerprint бизнес-актуальности. Порядок массивов или значение параметра может изменить хэш без изменения значимой редакции.

### 1.3. Состояния

| Поле ответа | Значения и смысл |
|---|---|
| `activationStatus` | `DRAFT`, `ACTIVE`, `EXPIRED` — разрешение выполнения пакета |
| Пакетный `executionStatus` | `null` до активации/после истечения черновика; для `ACTIVE` вычисляется по заданиям: `QUEUED`, `RUNNING`, `SUCCEEDED`, `FAILED`, `CANCELLED`, `PARTIALLY_SUCCEEDED` |
| Задание `executionStatus` | `BLOCKED`, `QUEUED`, `RUNNING`, `RETRY_WAIT`, `SUCCEEDED`, `FAILED`, `CANCELLED` |
| `resultDeliveryStatus` | `NOT_READY`, `WAITING_ACK`, `APPLIED`, `REJECTED` |
| `resultAvailability` | `NOT_READY` у нетерминального задания; `AVAILABLE` / `RELEASED` при успехе; `NOT_PRODUCED` при ошибке/отмене |

Технические ретраи внутри задания не меняют `generationId`. Терминальное задание не возвращается в очередь при повторном POST. Статусы применения принадлежат оркестратору; AI-бэкенд их только сохраняет.

## 2. Проверка применимости продукта

### Описание и URL

`POST /v1/generation-applicability` выполняет `CHECK_APPLICABILITY`: детерминированную продуктовую проверку без LLM, без сохранения контекста и без чтения результатов/попыток из БД. Один запрос относится к одному продукту.

### Параметры запроса

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>requestId</td><td></td><td>string UUID</td><td>Да</td><td>Из ai_generation_check_products.applicability_request_id</td></tr>
<tr><td>clientId</td><td></td><td>string</td><td>Да</td><td>Пациент проверки</td></tr>
<tr><td>productType</td><td></td><td>string enum</td><td>Да</td><td>Проверяемый продукт</td></tr>
<tr><td>contextSchemaVersion</td><td></td><td>string</td><td>Да</td><td>Версия поддерживаемой структуры входа</td></tr>
<tr><td>context</td><td></td><td>object</td><td>Да</td><td>Пациент и доступные системы; источники описаны в странице состава контекста</td></tr>
</table>

### Валидации запроса

Нарушение обязательности или формата любого поля — `400 INVALID_REQUEST`. Несовпадение идентификаторов пациента — тот же код. Несовместимая версия контекста/продукт — `422 UNSUPPORTED_CONTEXT_SCHEMA`. Превышение лимита — `413 PAYLOAD_TOO_LARGE`.

`contextSchemaVersion = recommendation-context-v1` обозначает проект общего входа рекомендаций: предоставленный JSON без `systems[].recommendation_type`. Пока схема reasoning не получена и не реализована, её нельзя подменять этой версией.

### Пример запроса

```json
{
  "requestId": "33333333-3333-4333-8333-333333333333",
  "clientId": "demo-001",
  "productType": "RECOMMENDATION",
  "contextSchemaVersion": "recommendation-context-v1",
  "context": {
    "patient": {
      "patient_id": "demo-001",
      "age": 31,
      "gender": "Мужской"
    },
    "systems": [
      {
        "code": "ENDO",
        "name": "Обмен веществ и гормоны",
        "risk_level": "low",
        "diseases": [],
        "risk_factors": []
      }
    ]
  }
}
```

### Бизнес-логика

1. Валидировать запрос по разделам 1 и 2.
2. Проверить продуктовые условия каждой переданной системы по странице бизнес-триггеров.
3. Вернуть применимость и доступные разделы. Не проверять актуальность прежних генераций, не создавать задания.
4. Оркестратор самостоятельно решает `NO_GENERATION` / `WAITING_GENERATION` / `START_GENERATION`.

`requestId` служит корреляции повторов, а не ключом сохранённого ответа: операция stateless. При смене конфигурации проверка может дать другой ответ, поэтому применение ответа требует обычной повторной проверки контекста; сервер не обещает хранение предыдущего результата проверки.

### Параметры ответа и ограничения

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>requestId</td><td></td><td>string UUID</td><td>Да</td><td>Эхо requestId</td></tr>
<tr><td>productType</td><td></td><td>string enum</td><td>Да</td><td>Эхо продукта</td></tr>
<tr><td>systems</td><td></td><td>array или null</td><td>Да</td><td>Один элемент для каждой проверенной системы; null, если систем нет</td></tr>
<tr><td></td><td>systemCode</td><td>string</td><td>Да</td><td>Код из context.systems</td></tr>
<tr><td></td><td>applicable</td><td>boolean</td><td>Да</td><td>Продуктовая применимость</td></tr>
<tr><td></td><td>recommendationSections</td><td>array или null</td><td>Да</td><td>Для рекомендаций — доступные разделы; для reasoning или неприменимой цели — null</td></tr>
</table>

Для рекомендаций `applicable = true` требует непустых разделов. Ответ не может добавить неизвестную входу систему или повторить код. Он не содержит предыдущих результатов или команд на безусловный запуск.

### Коды ответов и примеры

`200` — проверка выполнена, включая отсутствие применимых целей. Ошибки: `400`, `413`, `422`, `500`, `503` по разделу 8.

```json
{
  "isSuccess": true,
  "error": null,
  "requestId": "33333333-3333-4333-8333-333333333333",
  "productType": "RECOMMENDATION",
  "systems": [
    {
      "systemCode": "ENDO",
      "applicable": true,
      "recommendationSections": [
        "LIFESTYLE"
      ]
    }
  ]
}
```

Примеры неуспешных ответов: `INVALID_REQUEST`, `UNSUPPORTED_CONTEXT_SCHEMA` и общие ошибки в разделе 8.

## 3. Сохранение черновика пакета

### Описание и URL

`POST /v1/generation-batches` сохраняет общий контекст и заблокированные задания в AI-БД. Ни одна генерация не запускается.

### Параметры запроса

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>batchId</td><td></td><td>string UUID</td><td>Да</td><td>ai_generation_batches.batch_id основной БД</td></tr>
<tr><td>clientId</td><td></td><td>string</td><td>Да</td><td>Пациент пакета</td></tr>
<tr><td>contextSchemaVersion</td><td></td><td>string</td><td>Да</td><td>Версия общего входа</td></tr>
<tr><td>parametersRevision</td><td></td><td>string decimal</td><td>Да</td><td>Редакция параметров при сборке; метаданные готовности, не критерий инвалидации</td></tr>
<tr><td>context</td><td></td><td>object</td><td>Да</td><td>Полный общий вход одного пациента</td></tr>
<tr><td>tasks</td><td></td><td>array</td><td>Да</td><td>Непустой список целевых заданий; остальные системы остаются только контекстом</td></tr>
<tr><td></td><td>generationId</td><td>string UUID</td><td>Да</td><td>ID цели из target_manifest оркестратора</td></tr>
<tr><td></td><td>productType</td><td>string enum</td><td>Да</td><td>Продукт задания</td></tr>
<tr><td></td><td>targetSystemCode</td><td>string</td><td>Да</td><td>Система из context.systems</td></tr>
<tr><td></td><td>sourceContextRevision</td><td>string decimal</td><td>Да</td><td>Общая значимая редакция для RECOMMENDATION, редакция целевой системы для REASONING</td></tr>
<tr><td></td><td>recommendationSections</td><td>array</td><td>Условно</td><td>Обязательны для RECOMMENDATION; отсутствуют для REASONING</td></tr>
</table>

### Валидации запроса

Все обязательные и условные поля проверяются по разделу 1: `400 INVALID_REQUEST`. Тем же кодом отклоняются пустой пакет, повтор цели `productType + targetSystemCode`, повтор generationId, чужой пациент, цель вне контекста, неизвестные разделы и попытка задать `context.systems[].recommendation_type`.

Полный вход и все продукты должны поддерживать одну `contextSchemaVersion` (`422`). Пока вход reasoning неизвестен, смешанный пакет не принимается как якобы совместимый. Лимит тела/заданий — `413`.

Для нового пакета модуль проверяет, что запрошенные разделы применимы к принятому контексту, без LLM и БД риск-профиля. Неприменимая цель или раздел — `400 INVALID_REQUEST` с полем задания; сервер не расширяет/не сокращает список молча. Общий допуск по беременности остаётся обязанностью оркестратора.

### Пример запроса

```json
{
  "batchId": "11111111-1111-4111-8111-111111111111",
  "clientId": "demo-001",
  "contextSchemaVersion": "recommendation-context-v1",
  "parametersRevision": "42",
  "context": {
    "patient": {
      "patient_id": "demo-001",
      "age": 31,
      "gender": "Мужской"
    },
    "systems": [
      {
        "code": "ENDO",
        "name": "Обмен веществ и гормоны",
        "risk_level": "low",
        "diseases": [],
        "risk_factors": []
      }
    ]
  },
  "tasks": [
    {
      "generationId": "22222222-2222-4222-8222-222222222222",
      "productType": "RECOMMENDATION",
      "targetSystemCode": "ENDO",
      "sourceContextRevision": "7",
      "recommendationSections": [
        "LIFESTYLE"
      ]
    }
  ]
}
```

### Бизнес-логика и запись в БД

1. Проверить JSON, форматы и уникальность идентификаторов. Вычислить `requestHash` до изменения данных.
2. При существующем `batchId`: другой хэш → `409 BATCH_CONTENT_CONFLICT`; тот же хэш → вернуть сохранённое состояние без записи нового контекста, без продления срока и без LLM. Если пакет уже `EXPIRED` — `410 DRAFT_EXPIRED`. Существующий совпадающий запрос не переоценивается по новой конфигурации продуктовых правил.
3. Для нового пакета проверить поддерживаемую схему и применимость целей. `generationId` другого пакета → `409 GENERATION_ID_CONFLICT`.
4. В одной транзакции создать/найти контекст, создать пакет и все задания. Конкурирующие POST разрешаются уникальными ключами и повторным чтением; частичного приёма нет.
5. Вернуть метаданные. После потери ответа те же метаданные доступны через GET по ID.

Основные поля записываются так:

- `ai_context_payloads.patient_id` → `clientId`.
- `ai_context_payloads.payload_schema_version` → `contextSchemaVersion`.
- `ai_context_payloads.payload` → `context`.
- `ai_context_payloads.payload_hash` → хэш `context`.
- `ai_batches.batch_id` → `batchId`.
- `ai_batches.patient_id` → `clientId`.
- `ai_batches.context_id` → найденный/созданный контекст.
- `ai_batches.parameters_revision` → `parametersRevision`, преобразованная в Bigint.
- `ai_batches.request_hash` → вычисленный хэш всего запроса.
- `ai_batches.activation_status` → `DRAFT`.
- `ai_batches.draft_expires_at` → время приёма + настроенный срок.
- `ai_batch_tasks.generation_id` → `tasks[].generationId`.
- `ai_batch_tasks.batch_id` → `batchId`.
- `ai_batch_tasks.patient_id` → `clientId`.
- `ai_batch_tasks.product_type` → `tasks[].productType`.
- `ai_batch_tasks.target_system_code` → `tasks[].targetSystemCode`.
- `ai_batch_tasks.source_context_revision` → `tasks[].sourceContextRevision`.
- `ai_batch_tasks.generation_options` → разделы из задания, без добавления значений по умолчанию.
- `ai_batch_tasks.execution_status` → `BLOCKED`.
- Остальные даты, конфигурация модели и начальные счётчики → правила модели AI-БД.

### Параметры ответа, ограничения и коды

Ответ — объект состояния из раздела 5, без полного контекста. `201` при первом сохранении, `200` для уже существующего совпадающего пакета. Повтор после активации может вернуть `ACTIVE` и любые текущие состояния заданий.

Ошибки: `400`, `413`, `422`, `409 BATCH_CONTENT_CONFLICT / GENERATION_ID_CONFLICT`, `410 DRAFT_EXPIRED`, `500`, `503`. Примеры — раздел 8.

### Пример успешного ответа

Для приведённого запроса вычислен следующий хэш; пример проверяется повторным вычислением.

```json
{
  "isSuccess": true,
  "error": null,
  "batchId": "11111111-1111-4111-8111-111111111111",
  "clientId": "demo-001",
  "requestHash": "2f3fd4f741ceca04fc2ac6f56ba3da623febb5c260a1238df0c31aec6618835b",
  "parametersRevision": "42",
  "activationStatus": "DRAFT",
  "executionStatus": null,
  "draftExpiresDateTime": "2026-10-06T00:00:00",
  "activatedDateTime": null,
  "tasks": [
    {
      "generationId": "22222222-2222-4222-8222-222222222222",
      "productType": "RECOMMENDATION",
      "targetSystemCode": "ENDO",
      "sourceContextRevision": "7",
      "recommendationSections": [
        "LIFESTYLE"
      ],
      "executionStatus": "BLOCKED",
      "startedDateTime": null,
      "completedDateTime": null,
      "cancellationReason": null,
      "resultDeliveryStatus": "NOT_READY",
      "rejectionReason": null,
      "resultAvailability": "NOT_READY",
      "errorCode": null
    }
  ]
}
```

## 4. Активация пакета

### Описание и URL

`POST /v1/generation-batches/{batchId}/activation` разрешает выполнение ранее сохранённого пакета. Вызывается только после фиксации попыток и `ACTIVATION_PENDING` в основной БД.

### Параметры запроса

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>batchId (path)</td><td></td><td>string UUID</td><td>Да</td><td>Сохранённый ID пакета</td></tr>
<tr><td>expectedRequestHash</td><td></td><td>string hex</td><td>Да</td><td>Хэш исходного запроса, сохранённый оркестратором</td></tr>
</table>

### Валидации и пример запроса

Неверный/отсутствующий ID или хэш — `400 INVALID_REQUEST`. Другой сохранённый хэш — `409 REQUEST_HASH_MISMATCH`. JSON контекста и новый состав заданий в этой операции запрещены.

`POST /v1/generation-batches/11111111-1111-4111-8111-111111111111/activation`

```json
{
  "expectedRequestHash": "2f3fd4f741ceca04fc2ac6f56ba3da623febb5c260a1238df0c31aec6618835b"
}
```

### Бизнес-логика

1. Валидировать вход. Найти пакет по ID; отсутствие — `404 NOT_FOUND`.
2. Заблокировать пакет и сверить хэш. Для `ACTIVE` сразу вернуть состояние, не проверяя повторно истёкший срок прежнего черновика.
3. Для `EXPIRED` вернуть `410`. Для `DRAFT` с истёкшим сроком атомарно записать `EXPIRED` и `CANCELLED` у blocked-заданий, затем вернуть `410` после commit.
4. Для действующего `DRAFT` одной транзакцией проверить конфликты активных целей, перевести все задания `BLOCKED → QUEUED`, пакет `DRAFT → ACTIVE`, записать `activated_at`.
5. Если хотя бы одна цель занята, откатить всю активацию и вернуть `409 ACTIVE_TARGET_CONFLICT`. Пакет остаётся черновиком; частичной активации нет.
6. После commit воркеры могут начать выполнение. Повтор этой команды не создаёт новых заданий и не возвращает завершённые в очередь.

### Ответ, ограничения и коды

`200` — активация сохранена либо была сохранена ранее. Возвращается состояние из раздела 5; `activationStatus = ACTIVE`. Из-за скорости обработки задания уже могут быть завершены. `404`/таймаут после неизвестного исхода не разрешают оркестратору немедленно создать конкурирующий пакет.

Ошибки: `400`, `404`, `409 REQUEST_HASH_MISMATCH / ACTIVE_TARGET_CONFLICT`, `410 DRAFT_EXPIRED`, `500`, `503`; примеры — раздел 8.

### Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "batchId": "11111111-1111-4111-8111-111111111111",
  "clientId": "demo-001",
  "requestHash": "2f3fd4f741ceca04fc2ac6f56ba3da623febb5c260a1238df0c31aec6618835b",
  "parametersRevision": "42",
  "activationStatus": "ACTIVE",
  "executionStatus": "QUEUED",
  "draftExpiresDateTime": "2026-10-06T00:00:00",
  "activatedDateTime": "2026-10-05T23:00:00",
  "tasks": [
    {
      "generationId": "22222222-2222-4222-8222-222222222222",
      "productType": "RECOMMENDATION",
      "targetSystemCode": "ENDO",
      "sourceContextRevision": "7",
      "recommendationSections": [
        "LIFESTYLE"
      ],
      "executionStatus": "QUEUED",
      "startedDateTime": null,
      "completedDateTime": null,
      "cancellationReason": null,
      "resultDeliveryStatus": "NOT_READY",
      "rejectionReason": null,
      "resultAvailability": "NOT_READY",
      "errorCode": null
    }
  ]
}
```

## 5. Чтение состояния пакета

### Описание и URL

`GET /v1/generation-batches/{batchId}` возвращает метаданные и состояния всех заданий. Не содержит полный вход и тексты генераций. Истечение черновиков обрабатывается активацией и сборщиком; даже если GET ещё показывает `DRAFT`, истёкший срок не позволяет активировать его.

### Параметры запроса и валидации

Единственный параметр `batchId` в пути обязателен и должен быть UUID (`400 INVALID_REQUEST`). Тело отсутствует. Неизвестный ID — `404 NOT_FOUND`.

Пример: `GET /v1/generation-batches/11111111-1111-4111-8111-111111111111`.

### Бизнес-логика

1. Валидировать ID.
2. Прочитать пакет и все его задания в одном согласованном снимке БД.
3. Вернуть метаданные, вычисленный общий статус и состояния целей без изменения очереди. Ни одна генерация не запускается.
4. При наличии сохранённого ключа после очистки вернуть метаданные и `resultAvailability = RELEASED` у удалённых успешных результатов.

### Параметры ответа

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>batchId</td><td></td><td>string UUID</td><td>Да</td><td>ai_batches.batch_id</td></tr>
<tr><td>clientId</td><td></td><td>string</td><td>Да</td><td>ai_batches.patient_id</td></tr>
<tr><td>requestHash</td><td></td><td>string hex</td><td>Да</td><td>ai_batches.request_hash</td></tr>
<tr><td>parametersRevision</td><td></td><td>string decimal</td><td>Да</td><td>Редакция параметров сохранённого входа</td></tr>
<tr><td>activationStatus</td><td></td><td>string enum</td><td>Да</td><td>ai_batches.activation_status</td></tr>
<tr><td>executionStatus</td><td></td><td>string или null</td><td>Да</td><td>Агрегированный статус; правила раздела 1.3</td></tr>
<tr><td>draftExpiresDateTime</td><td></td><td>string DateTime</td><td>Да</td><td>ai_batches.draft_expires_at</td></tr>
<tr><td>activatedDateTime</td><td></td><td>string DateTime или null</td><td>Да</td><td>ai_batches.activated_at</td></tr>
<tr><td>tasks</td><td></td><td>array</td><td>Да</td><td>Все сохранённые задания; непустой, порядок по generationId</td></tr>
<tr><td></td><td>generationId</td><td>string UUID</td><td>Да</td><td>ai_batch_tasks.generation_id</td></tr>
<tr><td></td><td>productType</td><td>string enum</td><td>Да</td><td>Продукт задания</td></tr>
<tr><td></td><td>targetSystemCode</td><td>string</td><td>Да</td><td>Целевая система</td></tr>
<tr><td></td><td>sourceContextRevision</td><td>string decimal</td><td>Да</td><td>Сохранённая значимая редакция</td></tr>
<tr><td></td><td>recommendationSections</td><td>array или null</td><td>Да</td><td>Разделы задания; null для reasoning</td></tr>
<tr><td></td><td>executionStatus</td><td>string enum</td><td>Да</td><td>ai_batch_tasks.execution_status</td></tr>
<tr><td></td><td>startedDateTime</td><td>string DateTime или null</td><td>Да</td><td>Первое фактическое начало выполнения; не время создания/активации</td></tr>
<tr><td></td><td>completedDateTime</td><td>string DateTime или null</td><td>Да</td><td>Терминальное завершение задания</td></tr>
<tr><td></td><td>cancellationReason</td><td>string enum или null</td><td>Да</td><td>CONTEXT_CHANGED или DRAFT_EXPIRED для CANCELLED; иначе null</td></tr>
<tr><td></td><td>resultDeliveryStatus</td><td>string enum</td><td>Да</td><td>Сохранённое подтверждение результата</td></tr>
<tr><td></td><td>rejectionReason</td><td>string enum или null</td><td>Да</td><td>CONTEXT_CHANGED или ELIGIBILITY_LOST только при resultDeliveryStatus = REJECTED; иначе null</td></tr>
<tr><td></td><td>resultAvailability</td><td>string enum</td><td>Да</td><td>Производится из состояния задания и наличия payload</td></tr>
<tr><td></td><td>errorCode</td><td>string или null</td><td>Да</td><td>Технический код ошибки задания; может быть заполнен при RETRY_WAIT</td></tr>
</table>

### Ограничения ответа, коды и пример

У `DRAFT` все задания `BLOCKED`; у `EXPIRED` задания `CANCELLED` без времени начала. Для `ACTIVE` состояние может быть любым разрешённым после очереди. Идентификаторы, состав, редакции и хэш не меняются при технических повторах.

`200` — пакет найден; `400`, `404`, `500`, `503` — ошибки раздела 8. Успешный ответ `DRAFT` совпадает с примером раздела 3, `ACTIVE` — с примером раздела 4. GET не требует терминального статуса всего пакета.

## 6. Получение результата одной генерации

### Описание и URL

`GET /v1/generations/{generationId}/result` возвращает уже сохранённый успешный ответ. Обычно оркестратор вызывает метод после внутреннего события `AI_TASK_TERMINATED` со статусом `SUCCEEDED`. Если восстановительная сверка зависшей попытки обнаружила `SUCCEEDED`, она использует тот же метод. Постоянный REST-опрос активных заданий не выполняется. Чтение не подтверждает приём и не изменяет `WAITING_ACK`.

### Параметры, валидации и пример запроса

`generationId` в пути — обязательный UUID; `400 INVALID_REQUEST` при нарушении формата. Тело отсутствует.

Пример: `GET /v1/generations/22222222-2222-4222-8222-222222222222/result`.

### Бизнес-логика

1. Валидировать ID, найти задание; если не найдено — `404 NOT_FOUND`.
2. Для нетерминального задания вернуть `409 RESULT_NOT_READY`; для `FAILED`/`CANCELLED` — `409 GENERATION_NOT_SUCCEEDED`.
3. Для `SUCCEEDED` прочитать неизменяемый результат согласованно с его метаданными. Если payload удалён по сроку — `410 RESULT_RELEASED`.
4. Вернуть сохранённый продуктовый ответ без повторного вызова LLM и без чтения основной БД.

### Параметры ответа

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>generationId</td><td></td><td>string UUID</td><td>Да</td><td>ID результата</td></tr>
<tr><td>batchId</td><td></td><td>string UUID</td><td>Да</td><td>Пакет задания</td></tr>
<tr><td>clientId</td><td></td><td>string</td><td>Да</td><td>Пациент задания</td></tr>
<tr><td>productType</td><td></td><td>string enum</td><td>Да</td><td>Продукт</td></tr>
<tr><td>targetSystemCode</td><td></td><td>string</td><td>Да</td><td>Целевая система</td></tr>
<tr><td>sourceContextRevision</td><td></td><td>string decimal</td><td>Да</td><td>Редакция из задания</td></tr>
<tr><td>completedDateTime</td><td></td><td>string DateTime</td><td>Да</td><td>Терминальное завершение</td></tr>
<tr><td>result</td><td></td><td>JSON</td><td>Да</td><td>Неизменяемый ai_generation_results.result_payload; точная схема зависит от продукта</td></tr>
</table>

### Ограничения ответа и коды

`200` возвращается только для сохранённого успешного результата. ID, пациент, цель и редакция совпадают с заданием. Оркестратор проверяет их до применения; ответ с чужими метаданными не сохраняется. Результат валидируется по согласованной продуктовой схеме ещё до `SUCCEEDED`.

После получения `AI_TASK_TERMINATED / SUCCEEDED` таймаут и HTTP `500` / `503` приводят только к повтору этого GET с backoff. `404`, `409 RESULT_NOT_READY`, `410`, отсутствие payload или несовпадение метаданных являются нарушением целостности доставки: оркестратор сохраняет `SUCCEEDED / NOT_RECEIVED`, поднимает алерт, не изменяет предыдущий результат и не запускает LLM повторно. До получения и проверки результата ACK не отправляется, поэтому AI-бэкенд не формирует внешнее `AI_GENERATION_COMPLETED`.

Ошибки: `400`, `404`, `409 RESULT_NOT_READY / GENERATION_NOT_SUCCEEDED`, `410 RESULT_RELEASED`, `500`, `503`. Примеры — раздел 8.

### Пример успешного ответа

Для `REASONING` поле `result` содержит `title` и `description`:

```json
{
  "generationId": "22222222-2222-4222-8222-222222222222",
  "batchId": "11111111-1111-4111-8111-111111111111",
  "clientId": "demo-001",
  "productType": "REASONING",
  "targetSystemCode": "ENDO",
  "sourceContextRevision": "17",
  "completedDateTime": "2026-10-06T02:15:00",
  "result": {
    "title": "Почему повышен риск",
    "description": "Персонализированный текст объяснения..."
  }
}
```

Для `RECOMMENDATION` поле `result` сохраняет ответ продуктового модуля:

```json
{
  "generationId": "33333333-3333-4333-8333-333333333333",
  "batchId": "11111111-1111-4111-8111-111111111111",
  "clientId": "demo-001",
  "productType": "RECOMMENDATION",
  "targetSystemCode": "ENDO",
  "sourceContextRevision": "42",
  "completedDateTime": "2026-10-06T02:16:00",
  "result": {
    "patient_id": "demo-001",
    "system_recommendations": [
      {
        "system_code": "ENDO",
        "recommendations": {
          "physical_activity": {
            "title": "Добавьте регулярную активность",
            "description": "Текст рекомендации..."
          },
          "nutrition": {
            "title": "Сбалансируйте рацион",
            "description": "Текст рекомендации..."
          },
          "sleep": {
            "title": "Поддерживайте режим сна",
            "description": "Текст рекомендации..."
          },
          "stress_management": {
            "title": "Снижайте ежедневное напряжение",
            "description": "Текст рекомендации..."
          }
        },
        "generation_errors": [],
        "risk_factor_recommendations": [
          {
            "risk_factors_code": "fr_smoking",
            "type": "risk_factors",
            "title": "Сократите употребление табака",
            "description": "Текст карточки фактора риска..."
          }
        ],
        "risk_factor_generation_errors": []
      }
    ]
  }
}
```

Для обоих продуктов содержимое `result` проходит валидацию до перехода задания в `SUCCEEDED`. Для `RECOMMENDATION` `patient_id` должен совпадать с `clientId`, а единственный `system_code` — с `targetSystemCode`. Пределы длин и допустимость непустых массивов ошибок ещё не согласованы. Внешняя адаптация описана в [risk-profile v3](ИИ-сервисы-REST-контракт-risk-profile-v3.md).

## 6.1. Отмена генерации

### Описание и URL

`PUT /v1/generations/{generationId}/cancellation` идемпотентно запрещает дальнейшее выполнение устаревшего задания после изменения значимого контекста. Метод не гарантирует, что внешний LLM-провайдер успел прекратить уже начатый запрос или не начислил токены.

### Параметры запроса

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>generationId (path)</td><td></td><td>string UUID</td><td>Да</td><td>Идентификатор отменяемого задания</td></tr>
<tr><td>cancellationReason</td><td></td><td>string enum</td><td>Да</td><td>CONTEXT_CHANGED; из сохранённого намерения отмены основной БД</td></tr>
</table>

### Валидации и пример запроса

Неверный UUID, отсутствие причины или неизвестное значение — `400 INVALID_REQUEST`. Неизвестное задание — `404 NOT_FOUND`.

`PUT /v1/generations/22222222-2222-4222-8222-222222222222/cancellation`

```json
{
  "cancellationReason": "CONTEXT_CHANGED"
}
```

### Бизнес-логика

1. Валидировать запрос, найти и заблокировать `ai_batch_tasks` по `generationId`.
2. Если задание уже `CANCELLED` с той же причиной, вернуть сохранённый успешный ответ без изменения дат.
3. Если статус `QUEUED` или `RETRY_WAIT`, атомарно установить `CANCELLED`, `cancellation_reason = CONTEXT_CHANGED`, заполнить `completed_at` и исключить задание из очереди.
4. Если статус `RUNNING`, в той же транзакции установить `CANCELLED`, сохранить причину, заполнить `completed_at` и аннулировать аренду. После commit выполнить best-effort отмену запроса у провайдера, если она поддерживается.
5. Если статус `BLOCKED`, `SUCCEEDED` или `FAILED`, вернуть `409 GENERATION_NOT_CANCELLABLE`; состояние не изменять. Для `BLOCKED` оркестратор не активирует пакет, сохраняет намерение отмены до подтверждения исхода активации либо истечения черновика.
6. Ответ старого воркера после отмены не сохраняется, поскольку статус и `lease_token` больше не соответствуют работающей попытке.
7. Метод не создаёт новую генерацию и не публикует внешнее событие. Терминальный переход создаёт внутреннее событие `AI_TASK_TERMINATED`; при его длительной задержке оркестратор может обнаружить `CANCELLED` восстановительной сверкой зависшей попытки.

### Параметры ответа, ограничения и коды

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>generationId</td><td></td><td>string UUID</td><td>Да</td><td>Идентификатор задания</td></tr>
<tr><td>executionStatus</td><td></td><td>string enum</td><td>Да</td><td>CANCELLED</td></tr>
<tr><td>cancellationReason</td><td></td><td>string enum</td><td>Да</td><td>CONTEXT_CHANGED</td></tr>
<tr><td>completedDateTime</td><td></td><td>string DateTime</td><td>Да</td><td>Время локальной отмены в AI-БД</td></tr>
</table>

`200` означает, что AI-бэкенд больше не примет результат задания. Он не подтверждает отмену тарификации у LLM-провайдера. Ошибки: `400`, `404`, `409 GENERATION_NOT_CANCELLABLE`, `500`, `503`; примеры — раздел 8.

### Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "generationId": "22222222-2222-4222-8222-222222222222",
  "executionStatus": "CANCELLED",
  "cancellationReason": "CONTEXT_CHANGED",
  "completedDateTime": "2026-10-05T23:00:30"
}
```

## 7. Подтверждение приёма результата

### Описание и URL

`PUT /v1/generations/{generationId}/acknowledgement` сохраняет решение оркестратора. Вызывается после commit основной БД, где результат принят или отклонён. Для ACK `APPLIED` AI-бэкенд создаёт внешнее `AI_GENERATION_COMPLETED` в той же транзакции. Поведение внешнего уведомления после `REJECTED` не согласовано.

### Параметры запроса

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>generationId (path)</td><td></td><td>string UUID</td><td>Да</td><td>ID обработанного результата</td></tr>
<tr><td>resultAcceptanceStatus</td><td></td><td>string enum</td><td>Да</td><td>APPLIED или REJECTED; из сохранённого решения основной БД</td></tr>
<tr><td>rejectionReason</td><td></td><td>string enum</td><td>Условно</td><td>Для REJECTED обязательно: CONTEXT_CHANGED или ELIGIBILITY_LOST; для APPLIED не передаётся</td></tr>
</table>

### Валидации и пример запроса

Неверный ID, отсутствие статуса, неизвестное значение, REJECTED без `rejectionReason` или APPLIED с заполненной причиной — `400 INVALID_REQUEST`. Подтверждать можно только `SUCCEEDED`. Для pending — `409 RESULT_NOT_READY`; для ошибки/отмены — `409 GENERATION_NOT_SUCCEEDED`.

`PUT /v1/generations/22222222-2222-4222-8222-222222222222/acknowledgement`

```json
{
  "resultAcceptanceStatus": "APPLIED"
}
```

Пример отклонения:

```json
{
  "resultAcceptanceStatus": "REJECTED",
  "rejectionReason": "CONTEXT_CHANGED"
}
```

### Бизнес-логика

1. Валидировать запрос и найти задание; отсутствие — `404 NOT_FOUND`.
2. Заблокировать задание. При сохранённой одинаковой паре `resultAcceptanceStatus + rejectionReason` вернуть успешный ответ без изменения дат.
3. При сохранённом другом решении или другой причине — `409 ACKNOWLEDGEMENT_CONFLICT`.
4. При `SUCCEEDED` и `WAITING_ACK` одной транзакцией записать `result_delivery_status`, условную `result_rejection_reason` и `acknowledged_at`.
5. Для `APPLIED` в той же транзакции создать `AI_GENERATION_COMPLETED` в `ai_outbox_events`.
6. Для `REJECTED` сохранить ACK без создания внешнего события завершения до отдельного решения.
7. Не менять результат, цель, вход, текущую генерацию или очередь выполнения. `UNIQUE (event_type, aggregate_id)` исключает повторное событие завершения при повторном ACK `APPLIED`.
8. Повтор после очистки payload обслуживается по сохранённым метаданным, пока действует окно идемпотентности.

> ⚠️ Не согласовано, должен ли ACK `REJECTED` приводить к публикации `AI_GENERATION_COMPLETED`. До принятия решения endpoint сохраняет отрицательный ACK, но не создаёт для него внешнее событие.

### Ответ, ограничения и коды

`200` — решение записано либо ранее была записана такая же пара «решение + причина». Ответ содержит обязательные `generationId`, `resultAcceptanceStatus`, `acknowledgedDateTime` и условный `rejectionReason` из AI-БД плюс общие поля. Повтор сохраняет исходное время подтверждения.

Ошибки: `400`, `404`, `409 RESULT_NOT_READY / GENERATION_NOT_SUCCEEDED / ACKNOWLEDGEMENT_CONFLICT`, `500`, `503`; примеры — раздел 8.

### Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "generationId": "22222222-2222-4222-8222-222222222222",
  "resultAcceptanceStatus": "APPLIED",
  "rejectionReason": null,
  "acknowledgedDateTime": "2026-10-05T23:01:00"
}
```

`APPLIED` не гарантирует, что результат актуален сейчас: последующая инвалидация живёт в основной БД. Старое подтверждение не меняется на отрицательное после инвалидации. Publisher отправляет созданное для `APPLIED` `AI_GENERATION_COMPLETED` только после подтверждённой публикации существующего `AI_GENERATION_STARTED` той же генерации.

## 8. Единые ошибки и примеры

Ошибки HTTP-запроса отделены от `tasks[].errorCode` — ошибки конкретной генерации. Техническая ошибка задания не превращает чтение найденного пакета в HTTP 500.

<table>
<tr><td><strong>Поле</strong></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Содержание / источник</strong></td></tr>
<tr><td>isSuccess</td><td></td><td>boolean</td><td>Да</td><td>false</td></tr>
<tr><td>error</td><td></td><td>object</td><td>Да</td><td>Описание ошибки</td></tr>
<tr><td></td><td>code</td><td>string</td><td>Да</td><td>Код из таблицы ниже</td></tr>
<tr><td></td><td>message</td><td>string</td><td>Да</td><td>Краткое описание без контекста пациента и текста генерации</td></tr>
<tr><td></td><td>field</td><td>string или null</td><td>Да</td><td>Путь некорректного поля; null для ошибки ресурса/сервиса</td></tr>
</table>

| Код | HTTP | Условие |
|---|---|---|
| `INVALID_REQUEST` | 400 | Некорректный JSON, обязательное поле отсутствует, неверный тип/UUID/enum/диапазон или нарушено соответствие полей |
| `UNSUPPORTED_CONTEXT_SCHEMA` | 422 | Версия контекста не поддерживается запрошенным продуктом |
| `PAYLOAD_TOO_LARGE` | 413 | Превышен настроенный предел размера запроса или количества заданий |
| `BATCH_CONTENT_CONFLICT` | 409 | Этот batchId уже связан с другим запросом |
| `GENERATION_ID_CONFLICT` | 409 | generationId уже принадлежит другому пакету |
| `REQUEST_HASH_MISMATCH` | 409 | Ожидаемый хэш не совпал с сохранённым |
| `ACTIVE_TARGET_CONFLICT` | 409 | Хотя бы одна цель уже имеет другое активное задание |
| `DRAFT_EXPIRED` | 410 | Срок неактивированного черновика истёк |
| `NOT_FOUND` | 404 | Пакет или задание не найдено |
| `RESULT_NOT_READY` | 409 | Генерация ещё не завершена |
| `GENERATION_NOT_SUCCEEDED` | 409 | Задание завершилось без успешного результата |
| `GENERATION_NOT_CANCELLABLE` | 409 | Задание `BLOCKED`, `SUCCEEDED` или `FAILED` и не может быть переведено методом в `CANCELLED` |
| `RESULT_RELEASED` | 410 | Успешный результат больше не хранится |
| `ACKNOWLEDGEMENT_CONFLICT` | 409 | Для генерации уже сохранено другое решение о применении |
| `INTERNAL_ERROR` | 500 | Внутренняя ошибка сервиса; исход записи необходимо сверить |
| `SERVICE_UNAVAILABLE` | 503 | Сервис временно недоступен; исход записи необходимо сверить |

Каждый пример соответствует отдельному коду. Проверка перечисленных в методе обязательных и условных полей возвращает `INVALID_REQUEST` с соответствующим путём; формат тела не меняется.

### INVALID_REQUEST — HTTP 400

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Некорректный JSON, обязательное поле отсутствует, неверный тип/UUID/enum/диапазон или нарушено соответствие полей",
    "field": "tasks[0].generationId"
  }
}
```

### UNSUPPORTED_CONTEXT_SCHEMA — HTTP 422

```json
{
  "isSuccess": false,
  "error": {
    "code": "UNSUPPORTED_CONTEXT_SCHEMA",
    "message": "Версия контекста не поддерживается запрошенным продуктом",
    "field": "contextSchemaVersion"
  }
}
```

### PAYLOAD_TOO_LARGE — HTTP 413

```json
{
  "isSuccess": false,
  "error": {
    "code": "PAYLOAD_TOO_LARGE",
    "message": "Превышен настроенный предел размера запроса или количества заданий",
    "field": null
  }
}
```

### BATCH_CONTENT_CONFLICT — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "BATCH_CONTENT_CONFLICT",
    "message": "Этот batchId уже связан с другим запросом",
    "field": "batchId"
  }
}
```

### GENERATION_ID_CONFLICT — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "GENERATION_ID_CONFLICT",
    "message": "generationId уже принадлежит другому пакету",
    "field": "tasks[0].generationId"
  }
}
```

### REQUEST_HASH_MISMATCH — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "REQUEST_HASH_MISMATCH",
    "message": "Ожидаемый хэш не совпал с сохранённым",
    "field": "expectedRequestHash"
  }
}
```

### ACTIVE_TARGET_CONFLICT — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "ACTIVE_TARGET_CONFLICT",
    "message": "Хотя бы одна цель уже имеет другое активное задание",
    "field": null
  }
}
```

### DRAFT_EXPIRED — HTTP 410

```json
{
  "isSuccess": false,
  "error": {
    "code": "DRAFT_EXPIRED",
    "message": "Срок неактивированного черновика истёк",
    "field": null
  }
}
```

### NOT_FOUND — HTTP 404

```json
{
  "isSuccess": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Пакет или задание не найдено",
    "field": null
  }
}
```

### RESULT_NOT_READY — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "RESULT_NOT_READY",
    "message": "Генерация ещё не завершена",
    "field": null
  }
}
```

### GENERATION_NOT_SUCCEEDED — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "GENERATION_NOT_SUCCEEDED",
    "message": "Задание завершилось без успешного результата",
    "field": null
  }
}
```

### RESULT_RELEASED — HTTP 410

```json
{
  "isSuccess": false,
  "error": {
    "code": "RESULT_RELEASED",
    "message": "Успешный результат больше не хранится",
    "field": null
  }
}
```

### GENERATION_NOT_CANCELLABLE — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "GENERATION_NOT_CANCELLABLE",
    "message": "Текущее состояние генерации не допускает отмену",
    "field": null
  }
}
```

### ACKNOWLEDGEMENT_CONFLICT — HTTP 409

```json
{
  "isSuccess": false,
  "error": {
    "code": "ACKNOWLEDGEMENT_CONFLICT",
    "message": "Для генерации уже сохранено другое решение о применении",
    "field": "resultAcceptanceStatus"
  }
}
```

### INTERNAL_ERROR — HTTP 500

```json
{
  "isSuccess": false,
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "Внутренняя ошибка сервиса; исход записи необходимо сверить",
    "field": null
  }
}
```

### SERVICE_UNAVAILABLE — HTTP 503

```json
{
  "isSuccess": false,
  "error": {
    "code": "SERVICE_UNAVAILABLE",
    "message": "Сервис временно недоступен; исход записи необходимо сверить",
    "field": null
  }
}
```

## 9. Повторы, гонки и порядок применения

1. Сохранение: повтор того же ID и точного содержания безопасен. Если JSON утрачен, сначала GET. До намерения активации допускается отказ от старой подготовки и новый ID; поздний старый запрос создаст только неисполняемый черновик.
2. Активация: повтор прежнего ID/хэша безопасен. После неопределённого исхода не создаётся новый пакет для тех же целей. Сетевой таймаут, HTTP 500/503 и один ответ 404 не доказывают, что старое исполнение невозможно.
3. GET: не изменяет выполнение. `AI_TASK_TERMINATED` является основным сигналом для чтения результата. REST-сверка запускается только для попыток, зависших дольше настроенного таймаута, либо вручную при восстановлении; постоянного polling нет. Ответы могут прийти не по порядку; оркестратор не откатывает терминальные состояния.
4. Подтверждение: повторяет только первоначальное решение из основной БД; не запускает LLM и не перезаписывает результат.
5. AI возвращает `EXPIRED` только для неактивированного пакета; активированный пакет не становится expired из-за времени прежнего черновика.
6. Потеря ответа на запись не откатывает commit. У каждого сервиса своя транзакция; согласованность достигается сохранёнными состояниями и повторами.
7. Истёкшие ключи удаляются только после общего окна доставки/восстановления. До его завершения поздняя команда не должна пересоздать удалённый ресурс.
8. Состояния и текст принадлежат конкретной генерации. Сначала сохраняется решение в основной БД, затем ACK в AI. Удаление неподтверждённого результата обычным TTL запрещено.
9. Повторная доставка запроса не гарантирует ровно один LLM-вызов при сбое воркера после ответа провайдера и до записи, но гарантирует отсутствие повторной постановки завершённого задания командой активации.
10. Неприменимость/ошибка в одной цели не должна молча менять состав уже сохранённого пакета. Новый состав требует новой подготовки после безопасного завершения старой.

## 10. Что остаётся согласовать

- Полный вход reasoning и совместимость форматов входа двух продуктов.
- Пределы длин текстов и правила частичного успеха `RECOMMENDATION` при непустых `generation_errors` или `risk_factor_generation_errors`.
- Непустой `diseases`, связь фактора с несколькими параметрами, единицы биомаркеров, `agent_action` и восстановление ответов анкеты.
- Доработку рекомендательного модуля для целевой генерации при сохранении общего контекста.
- Точные URL/имена конверта, строковое представление Bigint и применение UTC без суффикса в межсервисном API — предложения этой страницы, требующие технического ревью.
- Численные лимиты тела/пакета, срок черновика, интервалы опроса, время сетевых операций, число повторов и окно идемпотентности.
- Межсервисную аутентификацию и судьбу результатов при удалении пациента.
- Семантику внешнего старта и отдельный код отказа из-за утраты общего допуска; поля событий вынесены в [Kafka-контракты AI-сервисов](ИИ-сервисы-Kafka-контракты.md).
