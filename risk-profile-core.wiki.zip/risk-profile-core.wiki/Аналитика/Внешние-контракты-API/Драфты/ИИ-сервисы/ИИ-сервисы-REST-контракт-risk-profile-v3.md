# AI-сервисы: REST-контракт risk-profile v3

> Статус: рабочий проект. Зафиксировано согласованное размещение AI-ризонинга и AI-рекомендаций в ответе `medical-risk` v3. Полный базовый контракт v2 с `calculationMethod` пока не описан в wiki; до его получения эта страница фиксирует дельту v3.

Краткое описание всего решения: [AI-сервисы](../ИИ-сервисы.md). Детальная карта документов: [навигатор](ИИ-сервисы-навигация-по-документам.md).

## 1. Описание метода

Метод возвращает риск-профиль клиента. Версия v3 расширяет объект каждой системы двумя независимыми AI-результатами:

- `aiReasoning` — заголовок и персонализированный текст объяснения риска;
- `aiRecommendations` — четыре карточки ЗОЖ и карточки рекомендаций по модифицируемым факторам риска.

Существующие `topRecommendations`, `risk.description` и `risk.recommendations` не заменяются и не переименовываются. `calculationMethod` является частью базовой v2-структуры, а не AI-результатом.

## 2. URL и параметры

```http
GET /v3/clients/{clientId}/medical-risk?systemCode={systemCode}
```

## 3. Параметры запроса

<table>
<tr><td><strong>Параметр</strong></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Описание</strong></td></tr>
<tr><td>clientId (path-параметр)</td><td>string</td><td>Да</td><td>Идентификатор клиента</td></tr>
<tr><td>systemCode (query-параметр)</td><td>string</td><td>Нет</td><td>Код системы организма. Если не передан, возвращаются все системы</td></tr>
</table>

## 4. Валидации и ограничения запроса

- `clientId`: длина от 5 до 36 символов, только буквы, цифры, дефисы и подчёркивания;
- `systemCode`: длина от 2 до 36 символов.

При нарушении формата `clientId` возвращается HTTP `400` с кодом `INVALID_CLIENT_ID`. Код ошибки для невалидного `systemCode` нужно уточнить в базовом контракте v2.

## 5. Пример запроса

```http
GET /v3/clients/demo-001/medical-risk?systemCode=ENDO
```

## 6. Бизнес-логика

1. Валидировать `clientId` и `systemCode` по разделу 4.
2. Собрать базовый ответ risk-profile v2, включая `calculationMethod`.
3. Для каждого `systemInterpretationResults[].systemCode` прочитать из `ai_current_results` текущие результаты этого клиента и системы отдельно для `REASONING` и `RECOMMENDATION`.
4. Во внешний ответ включать только строку с `actuality_status = ACTUAL`. Если такой строки нет, продукт ещё не сгенерирован, отклонён или устарел, соответствующее поле возвращается как `null`.
5. Для `REASONING` заполнить `aiReasoning.title` и `aiReasoning.description` из одноимённых полей принятого `result_payload`.
6. Для `RECOMMENDATION` взять единственный элемент `system_recommendations`, соответствующий текущей целевой системе, и заполнить `aiRecommendations`:
   - `recommendations.physical_activity` → `physicalActivity`;
   - `recommendations.nutrition` → `nutrition`;
   - `recommendations.sleep` → `sleep`;
   - `recommendations.stress_management` → `stressManagement`;
   - `risk_factor_recommendations` → `riskFactorRecommendations`;
   - `risk_factor_recommendations[].risk_factors_code` → `riskFactorRecommendations[].riskFactorCode`.
7. `patient_id`, `system_code`, `type`, `generation_errors` и `risk_factor_generation_errors` во внешний ответ не переносить. `clientId` уже задан в URL, `systemCode` — в объекте системы, а технические ошибки AI-генерации не являются клиентскими данными.
8. Если `patients.is_pregnant = true`, оба поля во всех возвращаемых системах равны `null`, как и остальные рисковые данные.

## 7. Параметры ответа — расширение v3

Ниже описаны новые поля. Остальная часть ответа берётся из базового контракта v2 с `calculationMethod`.

<table>
<tr><td><strong>Параметр</strong></td><td></td><td></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Описание</strong></td></tr>
<tr><td>systemInterpretationResults</td><td></td><td></td><td>array[object]</td><td>Да</td><td>Массив систем организма</td></tr>
<tr><td></td><td>aiReasoning</td><td></td><td>object или null</td><td>Да</td><td>Текущий актуальный AI-ризонинг системы. <code>null</code>, если актуального результата нет</td></tr>
<tr><td></td><td></td><td>title</td><td>string</td><td>Да</td><td>Заголовок объяснения</td></tr>
<tr><td></td><td></td><td>description</td><td>string</td><td>Да</td><td>Текст объяснения</td></tr>
<tr><td></td><td>aiRecommendations</td><td></td><td>object или null</td><td>Да</td><td>Текущие актуальные AI-рекомендации системы. <code>null</code>, если актуального результата нет</td></tr>
<tr><td></td><td></td><td>physicalActivity</td><td>object</td><td>Да</td><td>Карточка физической активности</td></tr>
<tr><td></td><td></td><td>nutrition</td><td>object</td><td>Да</td><td>Карточка питания</td></tr>
<tr><td></td><td></td><td>sleep</td><td>object</td><td>Да</td><td>Карточка сна</td></tr>
<tr><td></td><td></td><td>stressManagement</td><td>object</td><td>Да</td><td>Карточка управления стрессом</td></tr>
<tr><td></td><td></td><td>riskFactorRecommendations</td><td>array[object] или null</td><td>Да</td><td>Карточки по модифицируемым факторам риска</td></tr>
<tr><td></td><td></td><td>riskFactorCode</td><td>string</td><td>Да</td><td>Код фактора риска</td></tr>
<tr><td></td><td></td><td>title</td><td>string</td><td>Да</td><td>Заголовок карточки фактора</td></tr>
<tr><td></td><td></td><td>description</td><td>string</td><td>Да</td><td>Текст карточки фактора</td></tr>
</table>

Объекты `physicalActivity`, `nutrition`, `sleep` и `stressManagement` имеют одинаковую структуру:

<table>
<tr><td><strong>Параметр</strong></td><td><strong>Тип</strong></td><td><strong>Обязательность</strong></td><td><strong>Описание</strong></td></tr>
<tr><td>title</td><td>string</td><td>Да</td><td>Заголовок карточки</td></tr>
<tr><td>description</td><td>string</td><td>Да</td><td>Текст карточки</td></tr>
</table>

## 8. Валидации и ограничения ответа

- `aiReasoning` и `aiRecommendations` всегда присутствуют в объекте системы; при отсутствии актуального результата их значение равно `null`;
- во внешний ответ не попадают результаты с `actuality_status = OUTDATED`;
- `riskFactorRecommendations` возвращается как `null`, если карточек факторов нет;
- `generation_errors` и `risk_factor_generation_errors` не входят во внешнюю схему;
- пределы длины `title` и `description` требуют отдельного согласования с владельцами AI-продуктов;
- полные ограничения базового ответа должны быть перенесены из контракта v2 после его публикации.

## 9. Коды ответов

- `200 OK` — запрос выполнен; отсутствие AI-результата не является ошибкой;
- `400 Bad Request` — некорректные параметры;
- `404 Not Found` — клиент не найден;
- `500 Internal Server Error` — внутренняя ошибка сборки ответа.

## 10. Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 62,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": [
    {
      "title": "Консультация эндокринолога",
      "details": null
    }
  ],
  "systemInterpretationResults": [
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:00:00",
      "systemCompletionPercentage": 90,
      "systemPriority": 3,
      "doctorSpecializations": [
        {
          "name": "Эндокринолог",
          "code": "24"
        }
      ],
      "diseaseRisks": [
        {
          "name": "Сахарный диабет"
        }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:00:00",
        "riskLevel": "high",
        "description": "Повышенный риск эндокринных нарушений",
        "riskFactors": [
          {
            "title": "Повышенный уровень глюкозы",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Консультация эндокринолога",
            "details": null
          }
        ]
      },
      "calculationMethod": [
        {
          "instrumentType": "biomarker_kr",
          "code": "biomarker_kr",
          "riskLevel": "high",
          "value": null,
          "unitMeasurement": null,
          "evidence": [
            {
              "riskFactorCode": "fr_elevated_glucose",
              "riskFactorName": "Повышение уровня глюкозы",
              "diseaseCode": "diabetes_mellitus",
              "diseaseName": "Сахарный диабет"
            }
          ]
        }
      ],
      "aiReasoning": {
        "title": "Почему повышен риск",
        "description": "Повышенный уровень глюкозы вместе с другими выявленными факторами может указывать на нарушение углеводного обмена."
      },
      "aiRecommendations": {
        "physicalActivity": {
          "title": "Добавьте регулярную активность",
          "description": "Старайтесь уделять умеренной физической активности не менее 150 минут в неделю."
        },
        "nutrition": {
          "title": "Сбалансируйте рацион",
          "description": "Сократите количество продуктов с добавленным сахаром и увеличьте долю овощей."
        },
        "sleep": {
          "title": "Поддерживайте режим сна",
          "description": "Старайтесь спать 7–9 часов и ложиться в одно и то же время."
        },
        "stressManagement": {
          "title": "Снижайте ежедневное напряжение",
          "description": "Используйте регулярные прогулки и дыхательные практики."
        },
        "riskFactorRecommendations": [
          {
            "riskFactorCode": "fr_elevated_glucose",
            "title": "Контролируйте уровень глюкозы",
            "description": "Обсудите с врачом повторное исследование уровня глюкозы."
          }
        ]
      }
    }
  ]
}
```

## 11. Пример успешного ответа без AI-результатов

```json
{
  "systemInterpretationResults": [
    {
      "systemCode": "ENDO",
      "aiReasoning": null,
      "aiRecommendations": null
    }
  ]
}
```

В финальном ответе остальные поля системы возвращаются по базовой v2-схеме; в примере они опущены только для краткости.

## 12. Примеры неуспешных ответов

### 12.1. Невалидный `clientId`

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```

### 12.2. Клиент не найден

```json
{
  "isSuccess": false,
  "error": {
    "code": "CLIENT_NOT_FOUND",
    "message": "Клиент не найден."
  }
}
```

### 12.3. Внутренняя ошибка

```json
{
  "isSuccess": false,
  "error": {
    "code": "INTERNAL_SERVER_ERROR",
    "message": "Не удалось получить риск-профиль клиента."
  }
}
```

## 13. Открытые вопросы

> ⚠️ Полный контракт v2 с `calculationMethod` нужно получить и перенести в v3, чтобы эта страница стала полным автономным контрактом.

> ⚠️ Нужно согласовать максимальные длины `title` и `description`, а также допустимость частичного результата при непустых `generation_errors` или `risk_factor_generation_errors`.
