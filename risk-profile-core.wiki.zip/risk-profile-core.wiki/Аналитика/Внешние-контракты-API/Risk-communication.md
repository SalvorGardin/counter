---
title: Risk-communication
---

## Описание метода

Метод предназначен для получения вопросов для клиента и сохранения ответов на них. При первом вызове передаётся только `clientId` — метод возвращает первый вопрос. В последующих вызовах передаётся `questionCode` текущего вопроса и ответ на него; метод сохраняет ответ и возвращает следующий вопрос. Поддерживаются три формата ответа: выбор варианта(-ов) из списка, ввод числового значения или пропуск вопроса. Когда вопросы заканчиваются, метод возвращает `isSuccess: true`, а поля `question`, `systemCode` и `systemName` содержат `null`.

## URL и параметры

```http
POST /v1/clients/{clientId}/questions/answers?questionCode={questionCode}&systemCode={systemCode}
POST /v2/clients/{clientId}/questions/answers?questionCode={questionCode}&systemCode={systemCode}
```

> ⚠️ **Версионирование метода (баг [#132](https://gitlab.tywys.ru/risk-profile/risk-profile-core/-/work_items/132)).** Бизнес-логика, описанная в этом документе, относится к обеим версиям метода, за одним исключением — завершение опроса по системе при переданном `systemCode` (шаги 5 и 12). В этой части документ соответствует методу `v2`, а метод `v1` содержит известное расхождение: при ответе на последний вопрос переданной системы вместо завершения (`question: null`, `systemCompletionPercentage: 100`) возвращается вопрос следующей системы. Остальные правила шага 5, включая особый случай системы `MENTAL`, расхождением не затронуты и действуют одинаково в `v1` и `v2`. Так как `v1` уже используется мобильным приложением, договорились со СберЗдоровьем исправленную логику выпустить отдельным URL `v2`, а `v1` оставить в эксплуатации с прежним поведением до отдельного согласования вывода из эксплуатации со СберЗдоровьем. Запрос и ответ (структура параметров) идентичны для обеих версий.

<table>
<tr>
<td>

**Параметр**
</td>
<td>

**Тип**
</td>
<td>

**Обязательность**
</td>
<td>

**Описание**
</td>
</tr>
<tr>
<td>clientId (path-параметр)</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>questionCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>

Код вопроса. Семантическая строка, например `cq_030` или `cq_010`
</td>
</tr>
<tr>
<td>systemCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма</td>
</tr>
<tr>
<td>optionCodes</td>
<td>

array\[string\]
</td>
<td>Нет</td>
<td>Массив с идентификаторами выбранных варианта ответа</td>
</tr>
<tr>
<td>answer</td>
<td>string</td>
<td>Нет</td>
<td>

Числовое значение ответа на вопрос типа `numeric`. Допустимо использование `,` в качестве десятичного разделителя
</td>
</tr>
<tr>
<td>isSkipped</td>
<td>boolean</td>
<td>Нет</td>
<td>Признак пропуска вопроса</td>
</tr>
</table>

## Валидации и ограничения

- clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- systemCode: длина от 2 до 36 символов. Если параметр передан — должен соответствовать коду существующей системы организма в таблице `systems`; если код не найден — возвращается ошибка 404 (`SYSTEM_CODE_NOT_FOUND`). Если параметр не передан, возвращается следующий вопрос без фильтрации по системе организма
- questionCode: длина от 3 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- optionCodes: длина каждого элемента от 1 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания); допустимо только для вопросов типа `select`, `boolean` и `multi`; для вопросов типа `multi` все переданные коды должны принадлежать вопросу с переданным `questionCode`
- answer: допустимо только для вопросов типа `numeric`; должно являться допустимым числом (целым или дробным); разрешено использование `,` в качестве десятичного разделителя вместо `.`
- Если questionCode передан, в теле запроса должен быть указан ровно один из параметров: массив optionCodes, answer или isSkipped. Если questionCode не передан, тело запроса должно быть пустым

## Пример запроса (первый вызов)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers
```

## Пример запроса (выбор варианта)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=cq_060
```

```json
{
  "optionCodes": ["cq_060_01", "cq_060_03"]
}
```

## Пример запроса (числовой ответ)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=cq_050
```

```json
{
  "answer": "75.5"
}
```

## Пример запроса (boolean — ответ «да»)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sq_0150&systemCode=CVD
```

```json
{
  "optionCodes": ["sq_0150_01"]
}
```

## Пример запроса (boolean — ответ «нет»)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sq_0150&systemCode=CVD
```

```json
{
  "optionCodes": ["sq_0150_02"]
}
```

## Пример запроса (пропуск вопроса)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sq_0130&systemCode=CVD
```

```json
{
  "isSkipped": true
}
```

## Пример запроса с ошибкой (answer для select-вопроса)

### Вариант 1: передан код варианта ответа в поле answer

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=BDI1&systemCode=MENTAL
```

```json
{
  "answer": "BDI1_02"
}
```

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_ANSWER_TYPE",
    "message": "Вопрос типа select не поддерживает поле answer. Используйте optionCodes."
  }
}
```

### Вариант 2: передано числовое значение в поле answer для select-вопроса

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=BDI1&systemCode=MENTAL
```

```json
{
  "answer": "2"
}
```

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_ANSWER_TYPE",
    "message": "Вопрос типа select не поддерживает поле answer. Используйте optionCodes."
  }
}
```

## Пример запроса с ошибкой (optionCodes для numeric-вопроса)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=cq_050
```

```json
{
  "optionCodes": ["cq_050_01"]
}
```

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_ANSWER_TYPE",
    "message": "Вопрос типа numeric не поддерживает поле optionCodes. Используйте answer."
  }
}
```

## Бизнес-логика

### Сохранение ответа

1. **Поиск пациента.** Если `clientId` не соответствует формату — возвращается ошибка 400 (`INVALID_CLIENT_ID`). По `clientId` из запроса выполняется поиск записи в таблице `patients`. Если запись не найдена — возвращается ошибка 404 (`CLIENT_NOT_FOUND`).
2. **Проверка systemCode.** Если `systemCode` передан в запросе — выполняется поиск записи в таблице `systems`. Если запись не найдена — возвращается ошибка 404 (`SYSTEM_CODE_NOT_FOUND`), ответ не сохраняется.
3. **Сохранение ответа на текущий вопрос.** Выполняется только если `questionCode` передан в запросе:
   - Если `questionCode` передан, но ни один из параметров `optionCodes`, `answer`, `isSkipped` не указан — возвращается ошибка 400 (`INVALID_ANSWER_TYPE`), ответ не сохраняется.
   - По переданному `questionCode` выполняется поиск записи в таблице `questions`. Если запись не найдена — возвращается ошибка 404 (`QUESTION_NOT_FOUND`), ответ не сохраняется.
   - Если передан `optionCodes` и `questions.type = 'numeric'` — возвращается ошибка 400 (`INVALID_ANSWER_TYPE`), ответ не сохраняется.
   - Если передан `answer` и `questions.type` принимает одно из значений `'select'`, `'boolean'`, `'multi'` — возвращается ошибка 400 (`INVALID_ANSWER_TYPE`), ответ не сохраняется.
   - Если передан `optionCodes`:
     - **Если `questions.type = 'multi'`:** из таблицы `options` отбираем **все** записи, у которых `question_code = questionCode`.
       - Проверяем, что каждый код из переданных `optionCodes` присутствует в отобранных записях. Если хотя бы один код не найден — возвращается ошибка 400 (`INVALID_OPTION_CODE`), ответ не сохраняется.
       - Для опций, `code` которых совпадает с переданными `optionCodes`, создаём или обновляем запись в `patients_parameters` с `value = 'Да'` и `parameter_code = options.parameter_code`.
       - Для опций, `code` которых не входит в переданные `optionCodes`, создаём или обновляем запись в `patients_parameters` с `value = 'Нет'` и `parameter_code = options.parameter_code`.
     - **Иначе** (`questions.type = 'select'` или `'boolean'`): из таблицы `options` отбираем записи, у которых `question_code = questionCode` и `options.code` совпадает с переданными `optionCodes`; для каждой найденной опции создаём или обновляем запись в `patients_parameters` с `value = options.value` и `parameter_code = options.parameter_code`. Записывается именно `options.value`, а не показанная пациенту родовая форма (`options.value_male` / `options.value_female`).
   - Если передан `answer` и `questions.type = 'numeric'` — заменяем символ `,` на `.` в строке `answer`; приводим строку `answer` к формату `Numeric(precision=12, scale=6)` без дополнения лидирующими или замыкающими нулями до полной длины; по `question_code = questionCode` находим запись в таблице `options`; создаём или обновляем запись в `patients_parameters` с `value` = приведённому значению и `parameter_code = options.parameter_code`.
   - Если передан `isSkipped = true` — по `question_code = questionCode` находим запись в таблице `options`; создаём или обновляем запись в `patients_parameters` с `value = ''` (пустая строка) и `parameter_code = options.parameter_code`.

   Во всех случаях поле `expiration_date` устанавливается равным текущей дате и времени, увеличенной на `parameters.validity_period` для соответствующего `parameter_code`, поле `source` — `FORM`, поле `date_time` — текущей дате и времени.

   **Особый случай — вопрос о беременности.** Если `questionCode = cq_030` — вместо сохранения в `patients_parameters` обновляется поле `is_pregnant` непосредственно в таблице `patients`: `true`, если выбран положительный вариант, `false` — если отрицательный.

   **Особый случай — вопрос о менопаузе (sq_0360).** Если `questionCode = sq_0360` — сверх основной логики сохранения выполняется одно из двух действий:
   - Если в переданных `optionCodes` содержится `sq_0360_04` — дополнительно создаётся или обновляется запись в `patients_parameters` с `parameter_code = regular_menses`, `value = 'none'`, `expiration_date = текущая дата и время + parameters.validity_period` для `regular_menses`, `source = FORM`, `date_time = текущая дата и время`.
   - Иначе (передан любой другой код из sq_0360_01–sq_0360_03) — дополнительно создаются или обновляются две записи в `patients_parameters`:
     - `parameter_code = regular_menses_menopause`, `value = 'none'`, `expiration_date = текущая дата и время + parameters.validity_period` для `regular_menses_menopause`, `source = FORM`, `date_time = текущая дата и время`.
     - `parameter_code = menopause_onset`, `value = 'none'`, `expiration_date = текущая дата и время + parameters.validity_period` для `menopause_onset`, `source = FORM`, `date_time = текущая дата и время`.

   **Особый случай — вопрос о хронических заболеваниях (cq_060).** Если `questionCode = cq_060` — сверх основной логики сохранения выполняется действие:
   * Если в переданных `optionCodes` НЕ содержится `cq_060_05` — дополнительно создаётся или обновляется запись в `patients_parameters` с `parameter_code = hodgkins_lymphoma` и `breast_cancer`, `value = 'none'`, `expiration_date = текущая дата и время + parameters.validity_period` для `hodgkins_lymphoma`, `source = FORM`, `date_time = текущая дата и время`.
4. **Проверка беременности.** Если у пациента поле `is_pregnant = true` — возвращается ответ с `isSuccess: true`, `systemCompletionPercentage: 100`, `question: null`, `systemCode: null`, `systemName: null`. Выполнение метода прекращается.

### Выбор следующего вопроса

 5. **Определение системы.**
    - **Особый случай — система `MENTAL`** (действует в обеих версиях метода — `v1` и `v2`). Если в запросе явно передан `systemCode = MENTAL` — проверка неотвеченных вопросов системы `COMMON` (см. ниже) **не выполняется**: сразу используем `MENTAL` как `system_code` при фильтрации инструментов на шаге 7. Вопросы группы `COMMON` при явно запрошенной системе `MENTAL` не показываются, даже если ещё не отвечены. Возраст, пол и дата рождения, необходимые калькуляторам `bdi` и `stai`, поступают на этапе инициализации клиента (`Risk-init`: параметры `age`, `gender`, `birthdate` обязательны для нового клиента) и не зависят от вопросов `COMMON`.
    - Иначе — сначала проверяем, есть ли у пациента неотвеченные вопросы системы `COMMON`:
      - По `system_code = COMMON` находим связанные инструменты в `systems_instruments`.
      - По `instrument_code` находим параметры в `instruments_parameters`.
      - По полученным `parameter_code` ищем записи пациента в `patients_parameters`. Параметр считается неотвеченным, если для него отсутствует запись, удовлетворяющая одновременно всем условиям:
        - `patient_id` равен идентификатору пациента;
        - `value` не равен `NULL`;
        - `expiration_date` не меньше текущей даты.
      - Если хотя бы один параметр системы `COMMON` является неотвеченным — используем `COMMON` как `system_code` (независимо от переданного в запросе `systemCode`).
    - Если все параметры системы `COMMON` отвечены:
      - Если `systemCode` передан — используем его напрямую при фильтрации инструментов на шаге 7.
      - Если `systemCode` не передан — выбираем `system_code` из таблицы `systems` с наименьшим значением `rang`.
 6. **Получение параметров системы.** Строим цепочку:
    - По `system_code` находим связанные инструменты в `systems_instruments`.
    - По `instrument_code` находим параметры в `instruments_parameters`.
 7. **Отбор параметров без актуального значения у пациента.** По `parameter_code` из `instruments_parameters` ищем записи пациента в `patients_parameters`. Оставляем только те параметры, для которых отсутствует запись, удовлетворяющая одновременно всем условиям:
    - `patient_id` равен идентификатору пациента
    - `value` не равен `NULL` (пустая строка засчитывается как ответ)
    - `expiration_date` не меньше текущей даты

    Именно по этим параметрам будем искать следующий вопрос.

    **Особый случай — параметры вопроса о беременности (`cq_030`).** Ответ на этот вопрос хранится не в `patients_parameters`, а в поле `is_pregnant` таблицы `patients`. Поэтому если `patients.is_pregnant IS NOT NULL` — параметры, связанные с вопросом `cq_030` через таблицу `options`, считаются отвеченными и не включаются в набор параметров для поиска следующего вопроса.
 8. **Получение вопросов для отобранных параметров.** По `parameter_code` параметров из шага 7 находим связанные записи в таблице `options`; по `options.question_code` извлекаем вопросы из таблицы `questions`.
 9. **Выбор вопроса.** Из полученного множества выбираем вопрос с наименьшим значением `questions.group_code`. Если несколько вопросов имеют одинаковый `group_code` — среди них выбираем запись с наименьшим `id`.
10. **Проверка связанных с вопросом условий.** По полю `conditions.question_code` ищем в таблице `conditions` все записи для выбранного вопроса:

- **Если условий нет** — возвращаем вопрос в ответе.
- **Если условия есть** — проверяем каждое из них. Для каждого условия:
  - **Если `type = 'except'`:**
    - Читаем из `conditions` поля `parameter_code` и `value`.
    - По `conditions.parameter_code` находим актуальную запись пациента в `patients_parameters`.
    - Сравниваем `conditions.value` с `patients_parameters.value`:
      - Если значения совпадают — исключаем вопрос; переходим к шагу 9 для следующего вопроса из множества.
      - Если значения не совпадают — переходим к проверке следующего условия.
  - **Если `type = 'age'`:**
    - Считываем из `conditions` значения `min_age` и `max_age`.
    - По `parameter_code = birthdate` находим актуальную запись в `patients_parameters` и вычисляем возраст пациента на текущую дату.
    - Проверяем, что вычисленный возраст находится в диапазоне от `min_age` до `max_age` включительно:
      - Если условие не выполнено — исключаем вопрос; переходим к шагу 9 для следующего вопроса из множества.
      - Если условие выполнено — переходим к проверке следующего условия.
- Если все условия проверены и ни одно не исключило вопрос — возвращаем вопрос в ответе.

11. **Подсчёт заполненности расчётной системы.** Параллельно с поиском следующего вопроса для расчёта `systemCompletionPercentage` строятся два множества вопросов — `applicable_questions` и `progressed_questions` — по тем же правилам, что и в методе `medical-risk` (Risk-profile, шаг 4):

- Определяем расчётную систему: если `systemCode` передан в запросе — используем его; иначе — `system_code` из шага 5.
- Запись в `patients_parameters` считается актуальной, если `value` не равен `NULL`, `expiration_date` не равен `NULL` и не меньше текущей даты.
- Вопрос относится к расчётной системе, если хотя бы у одного его варианта из `options` значение `parameter_code` относится к инструменту этой системы (`options.parameter_code` → `instruments_parameters` → `systems_instruments`). Система `COMMON` отдельно не добавляется — её вопросы попадают в системы через свои варианты.
- **applicable_questions** — вопросы, относящиеся к расчётной системе и применимые пациенту по полу и возрасту. Из числа относящихся к системе вопросов исключается вопрос, для которого по `conditions.question_code` найдено срабатывающее условие пола или возраста:
  - **Если `type = 'except'` и `parameter_code = 'gender'`:** по `parameter_code = gender` находим актуальную запись пациента в `patients_parameters`; если `conditions.value` совпадает с её значением — вопрос исключается.
  - **Если `type = 'age'`:** по `parameter_code = birthdate` находим актуальную запись в `patients_parameters` и вычисляем возраст пациента на текущую дату; если возраст не входит в диапазон от `min_age` до `max_age` включительно — вопрос исключается.
  - Условия `type = 'except'` с `parameter_code`, отличным от `gender`, на состав `applicable_questions` не влияют.
- **progressed_questions** — вопросы из `applicable_questions`, для которых выполнено хотя бы одно из условий:
  - все значения `parameter_code`, которые вопрос записывает через свои `options`, имеют актуальную запись в `patients_parameters`. Для вопроса `cq_030` условие считается выполненным, если `patients.is_pregnant` не равно `NULL`.
  - по `conditions.question_code` найдено условие `type = 'except'` с `parameter_code`, отличным от `gender`, у которого `conditions.value` совпадает со значением актуальной записи пациента по `conditions.parameter_code` (вопрос не будет показан).

12. **Формирование ответа.**

- Если вопрос найден — заполняем поля ответа из модели данных:
  - `systemCode` — из поля `systems.system_code`.
  - `systemName` — из поля `systems.name`.
  - `systemCompletionPercentage = floor(progressed / applicable × 100)`, где `applicable` и `progressed` — количества вопросов в множествах из шага 11. Если `applicable = 0` — `systemCompletionPercentage = 100`.
  - `question.questionCode` — из поля `questions.question_code`.
  - `question.type` — из поля `questions.type`.
  - `question.text` — текст вопроса по полу пациента (см. «Выбор формы текста по полу пациента» ниже): из `questions.question_female` / `questions.question_male`, иначе из `questions.question`.
  - `question.isSkippable` — из поля `questions.is_skippable`.
  - `question.options` — зависит от типа вопроса:
    - Если `questions.type` = `boolean`, `select` или `multi`: заполняется из таблицы `options` по `question_code`; `question.options[].optionCode` — из `options.code`, `question.options[].text` — текст опции по полу пациента: из `options.value_female` / `options.value_male`, иначе из `options.value`.
    - Если `questions.type` = `numeric`: возвращается `null` (записи в таблице `options` для данного вопроса существуют, но в ответ не включаются).
    - **Исключение опции для вопроса sq_0380.** Если `questions.question_code = sq_0380` и у пациента есть актуальная запись в `patients_parameters` с `parameter_code = regular_menses_menopause` (value не равен NULL и expiration_date не меньше текущей даты) — из сформированного списка `question.options` исключается элемент с `options.code = sq_0380_03`.
- Если ни один вопрос не прошёл проверку условий — `question`, `systemCode`, `systemName` возвращаются как `null`; `systemCompletionPercentage = 100`.

### Выбор формы текста по полу пациента

Тексты части вопросов и вариантов ответа зависят от пола пациента (опросники `bdi` и `stai` системы `MENTAL`). Для них в справочниках заведены родовые формы: `questions.question_male` / `questions.question_female` и `options.value_male` / `options.value_female`.

По `parameter_code = gender` берём актуальную запись пациента в `patients_parameters` (см. шаг 11):

| Значение `gender` | `question.text` | `question.options[].text` |
|---|---|---|
| `Женский` | `questions.question_female`, если заполнено, иначе `questions.question` | `options.value_female`, если заполнено, иначе `options.value` |
| `Мужской` | `questions.question_male`, если заполнено, иначе `questions.question` | `options.value_male`, если заполнено, иначе `options.value` |
| записи нет, запись истекла или иное значение | `questions.question` | `options.value` |

Родовые формы используются только для отображения. При сохранении ответа в `patients_parameters.value` по-прежнему записывается `options.value` — независимо от показанной формы (см. «Сохранение ответа»).

## Параметры ответа

<table>
<tr>
<td>

**Параметр**
</td>
<td></td>
<td></td>
<td>

**Тип**
</td>
<td>

**Обязательность**
</td>
<td>

**Описание**
</td>
</tr>
<tr>
<td>isSuccess</td>
<td></td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак успешности выполнения запроса</td>
</tr>
<tr>
<td>error</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект со сведениями об ошибке</td>
</tr>
<tr>
<td></td>
<td>code</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код ошибки</td>
</tr>
<tr>
<td></td>
<td>message</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Описание ошибки</td>
</tr>
<tr>
<td>systemCode</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма. Отсутствует, если вопросы закончились</td>
</tr>
<tr>
<td>systemName</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Название системы организма. Отсутствует, если вопросы закончились</td>
</tr>
<tr>
<td>systemCompletionPercentage</td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Процент прохождения опросника по текущей системе организма</td>
</tr>
<tr>
<td>question</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект с вопросом</td>
</tr>
<tr>
<td></td>
<td>questionCode</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>

Код вопроса. Семантическая строка, например `cq_010` или `BDI1`
</td>
</tr>
<tr>
<td></td>
<td>type</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Тип вопроса. Возможны следующие значения: boolean, select, multi, numeric</td>
</tr>
<tr>
<td></td>
<td>text</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Текст вопроса</td>
</tr>
<tr>
<td></td>
<td>isSkippable</td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак возможности пропуска вопроса</td>
</tr>
<tr>
<td></td>
<td>options</td>
<td></td>
<td>

array\[object\]
</td>
<td>Нет</td>
<td>Варианты ответа на вопрос</td>
</tr>
<tr>
<td></td>
<td></td>
<td>optionCode</td>
<td>string</td>
<td>Да</td>
<td>Код варианта ответа</td>
</tr>
<tr>
<td></td>
<td></td>
<td>text</td>
<td>string</td>
<td>Да</td>
<td>Текст варианта ответа</td>
</tr>
</table>

## Валидации и ограничения

- error.code: не более 100 символов
- error.message: не более 255 символов
- systemCode: от 2 до 36 символов
- systemName: не более 100 символов
- systemCompletionPercentage: целое число от 0 до 100
- question.questionCode: длина от 3 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- question.type: допустимы только следующие значения - boolean, select, multi, numeric
- question.text: не более 500 символов
- question.isSkippable: обязательное булево поле
- question.options: присутствует для типов boolean, select и multi; для numeric возвращается `null`
- option.optionCode: длина от 1 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- option.text: не более 255 символов

## Коды ответов

- 200 OK — запрос выполнен успешно: ответ сохранён (если передан) и возвращён следующий вопрос (если есть).
- 400 Bad Request — некорректные параметры или нарушение ограничений по длине/формату.
- 404 Not Found — клиент или вопрос не найдены.
- 500 Internal Server Error — внутренняя ошибка сервера.

## Пример успешного ответа

### Есть следующий вопрос — тип select

Пример для пациента с `gender = Мужской`. Для пациента с `gender = Женский` те же опции отдаются в женском роде («Я расстроена.»), при неизвестном поле — в нейтральной форме со скобками («Я расстроен(а)»).

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "MENTAL",
  "systemName": "Ментальное здоровье",
  "systemCompletionPercentage": 45,
  "question": {
    "questionCode": "BDI1",
    "type": "select",
    "text": "Что лучше описывает ваше состояние за прошедшую неделю и сегодня?",
    "isSkippable": false,
    "options": [
      {
        "optionCode": "BDI1_01",
        "text": "Я не чувствую себя расстроенным, печальным."
      },
      {
        "optionCode": "BDI1_02",
        "text": "Я расстроен."
      },
      {
        "optionCode": "BDI1_03",
        "text": "Я все время расстроен и не могу от этого отключиться."
      },
      {
        "optionCode": "BDI1_04",
        "text": "Я настолько расстроен и несчастлив, что не могу это выдержать."
      }
    ]
  }
}
```

### Есть следующий вопрос — тип multi

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "COMMON",
  "systemName": "Общие вопросы",
  "systemCompletionPercentage": 50,
  "question": {
    "questionCode": "cq_060",
    "type": "multi",
    "text": "Какие хронические заболевания у вас имеются? (можно выбрать несколько вариантов)",
    "isSkippable": false,
    "options": [
      {
        "optionCode": "cq_060_01",
        "text": "Артериальная гипертензия"
      },
      {
        "optionCode": "cq_060_02",
        "text": "Атеросклероз"
      },
      {
        "optionCode": "cq_060_03",
        "text": "Сахарный диабет 1 или 2 типа"
      },
      {
        "optionCode": "cq_060_04",
        "text": "Бронхиальная астма или ХОБЛ"
      },
      {
        "optionCode": "cq_060_05",
        "text": "Злокачественные новообразования"
      },
      {
        "optionCode": "cq_060_06",
        "text": "Нарушения свертываемости крови (склонность к тромбозам)"
      },
      {
        "optionCode": "cq_060_07",
        "text": "Ревматоидный артрит"
      },
      {
        "optionCode": "cq_060_08",
        "text": "Ничего из перечисленного"
      }
    ]
  }
}
```

### Есть следующий вопрос — тип boolean

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "CVD",
  "systemName": "Сердце и сосуды",
  "systemCompletionPercentage": 60,
  "question": {
    "questionCode": "sq_0150",
    "type": "boolean",
    "text": "Бывали ли у вас эпизоды боли или сдавления в груди при физической нагрузке?",
    "isSkippable": false,
    "options": [
      {
        "optionCode": "sq_0150_01",
        "text": "Да"
      },
      {
        "optionCode": "sq_0150_02",
        "text": "Нет"
      }
    ]
  }
}
```

### Есть следующий вопрос — тип numeric

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "CVD",
  "systemName": "Сердце и сосуды",
  "systemCompletionPercentage": 75,
  "question": {
    "questionCode": "sq_0130",
    "type": "numeric",
    "text": "Какое систолическое (\"верхнее\") артериальное давление для вас характерно?",
    "isSkippable": true,
    "options": null
  }
}
```

### Вопросы закончились

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": null,
  "systemName": null,
  "systemCompletionPercentage": 100,
  "question": null
}
```

## Пример ошибки

Клиент не найден:

```json
{
  "isSuccess": false,
  "error": {
    "code": "CLIENT_NOT_FOUND",
    "message": "Клиент с указанным clientId не найден."
  }
}
```

Некорректный clientId:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```

questionCode передан без типа ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_ANSWER_TYPE",
    "message": "При передаче questionCode необходимо указать один из параметров: optionCodes, answer или isSkipped."
  }
}
```

Передан код варианта ответа, не относящийся к вопросу:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_OPTION_CODE",
    "message": "Один или несколько переданных кодов вариантов ответа не относятся к указанному вопросу."
  }
}
```

Передан несуществующий код системы организма:

```json
{
  "isSuccess": false,
  "error": {
    "code": "SYSTEM_CODE_NOT_FOUND",
    "message": "Система организма с указанным кодом не найдена."
  }
}
```