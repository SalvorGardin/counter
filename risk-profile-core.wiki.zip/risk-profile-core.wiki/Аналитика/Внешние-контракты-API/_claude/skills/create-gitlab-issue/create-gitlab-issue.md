---
name: Создание задачи в GitLab
description: Процедура создания GitLab issue — составить, получить данные проекта, уточнить тип/лейблы/исполнителя/спринт, показать превью, дождаться подтверждения, создать через API
---

## Параметры по умолчанию

- `issue_type`: `task`
- Лейблы: `DEV`, `Backend`, `Task`
- Исполнитель: не назначен
- Спринт (milestone): не задан — опционально, только для `issue_type = task` (к `issue`/фиче не применяется)
- Инстанс: `gitlab.tywys.ru`
- Проект: `risk-profile/risk-profile-core`
- Токен: `$GITLAB_TOKEN` (переменная окружения)
- Временный каталог (`$WORK`): scratchpad сессии либо системный temp

Если пользователь явно указал другие значения — использовать его.

## Шаги

### 1. Составить задачу

Сформировать заголовок и описание на основе запроса пользователя.

Если в описании упоминаются страницы вики — оформлять их как кликабельные markdown-ссылки с анкором к конкретному разделу:

```markdown
[Risk-communication.md → Бизнес-логика, шаг 2](https://gitlab.tywys.ru/risk-profile/risk-profile-core/-/wikis/Аналитика/Внешние-контракты-API/Risk-communication#бизнес-логика)
```

### 2. Получить доступные данные из GitLab

Выполнить **параллельно** три запроса (для `issue_type = issue` / фичи — только первые два: спринт не запрашивается):

```bash
# Лейблы проекта
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/labels?per_page=100"
```

```bash
# Участники проекта
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/members/all?per_page=100"
```

```bash
# Спринты (milestones) — активные, с наследованием от группы
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/milestones?state=active&include_ancestors=true&per_page=100"
```

Из ответов извлечь:
- Лейблы: поле `name` каждого объекта
- Участники: поля `id`, `username`, `name` каждого объекта (нужен `id` для `assignee_ids` при создании задачи)
- Спринты: поля `id`, `title` каждого объекта (нужен `id` для `milestone_id` при создании задачи)

### 3. Уточнить тип, лейблы, исполнителя, спринт

> ⚠️ Для лейблов, участников и спринтов **не использовать** инструмент `AskUserQuestion` с опциями — он показывает максимум 4 варианта и скрывает остальные. Вместо этого вывести весь список в тексте обычного сообщения и ждать ответа пользователя как свободного текста.

Если пользователь не указал значения явно — показать доступные варианты и спросить **одним сообщением**:

```
Уточните параметры задачи:

**Тип** (выберите один):
• task — задача (по умолчанию)
• issue — баг/улучшение
• incident — инцидент

**Лейблы** (все доступные в проекте):
• LabelA
• LabelB
• LabelC
• ... (полный список из API, каждый лейбл с новой строки)
Текущий выбор: DEV, Backend, Task — оставить или указать другие?

**Исполнитель** (все участники проекта):
• @username1 (Имя Фамилия)
• @username2 (Имя Фамилия)
• ... (полный список из API)
Указать исполнителя или оставить без назначения?

**Спринт** (активные milestones проекта):
• <title> (id <id>)
• ... (полный список из API, каждый с новой строки)
Проставить спринт или создать без него?
```

Если пользователь уже указал какое-либо из значений — пропустить соответствующий блок вопроса.

Блок «Спринт» не показывать, если `issue_type = issue` (фича) — к фичам спринт не применяется.

### 4. Показать превью

Вывести в чат и ждать явного подтверждения («ок», «создавай», «да» или аналог). Не создавать задачу без подтверждения.

```
**Тип:** task
**Лейблы:** DEV, Backend, Task
**Исполнитель:** @username (Имя Фамилия) / не назначен
**Спринт:** <title> / не задан

**Заголовок:**
```
Текст заголовка
```

**Описание:**

---

<полный текст описания в markdown>

---
```

### 5. Создать задачу

**Инварианты — верны в любом окружении:**

- Тело запроса — **JSON** с заголовком `Content-Type: application/json`. Form-encoded (`curl --data-urlencode` / `-F`) может отклоняться инстансом с `400 Bad Request` даже на минимальном наборе полей — не использовать.
- Описание — многострочный markdown с кавычками, обратными кавычками и переводами строк. **Не вписывать его в JSON-литерал вручную.** Описание пишется в отдельный файл, оттуда попадает в JSON инструментом.
- Текст описания записывать в файл heredoc'ом с **закавыченным** разделителем (`<<'EOF'`) — тогда содержимое ложится дословно, без подстановок и потери экранирования.
- Тело отправлять из файла: `--data-binary "@файл"`. Не `--data @-` со строкой в команде.
- Успех создания — `HTTP 201`. Любой `4xx`/`5xx` означает, что задача **не создана**; повторять запрос только после исправления тела.

**5.1. Записать описание в файл**

```bash
cat > "$WORK/desc.md" <<'EOF'
## Что нужно сделать
...
EOF
```

`$WORK` — временный каталог (scratchpad сессии либо системный temp). Обращаться по абсолютным путям: в некоторых окружениях рабочий каталог между командами сбрасывается, и `cd` в него не держится.

**5.2. Собрать JSON**

Выбрать первый доступный способ — проверить наличие инструмента, а не предполагать его.

**а) `jq` есть** (`command -v jq`) — предпочтительный путь:

```bash
jq -n \
  --arg title "Заголовок задачи" \
  --arg labels "Backend,Task,Major,Backlog" \
  --arg issue_type "task" \
  --rawfile description "$WORK/desc.md" \
  '{title:$title, issue_type:$issue_type, labels:$labels, description:$description}' \
  > "$WORK/issue.json"
```

Опциональные поля добавлять только когда значение выбрано: `--argjson assignee_ids '[63]'`, `--argjson milestone_id 8`.

**б) `jq` нет** — экранировать описание скриптом. Скрипт **записать в файл**, не передавать инлайном: в ряде окружений однострочники `sed -e '...'` / `perl -e '...'` доезжают до интерпретатора с потерянными бэкслешами (`s/\/\\/g` превращается в `s/\/\/g`) и падают с синтаксической ошибкой. В самом скрипте использовать байтовые коды вместо литеральных `\` и `"` — он тогда переживает любой слой обработки команды.

```bash
cat > "$WORK/mkjson.pl" <<'PERLEOF'
my ($descfile, $metafile, $out) = @ARGV;
open(my $fh, "<:raw", $descfile) or die $!; local $/; my $d = <$fh>; close $fh;
open(my $mh, "<:raw", $metafile) or die $!; my $meta = <$mh>; close $mh;
$d =~ s/\x5C/\x5C\x5C/g;
$d =~ s/\x22/\x5C\x22/g;
$d =~ s/\x0D//g;
$d =~ s/\x0A/\x5C\x6E/g;
chomp $meta; $meta =~ s/\s+$//;
open(my $o, ">:raw", $out) or die $!;
print $o substr($meta, 0, length($meta)-1) . ",\x22description\x22:\x22" . $d . "\x22}";
close $o;
PERLEOF
```

Мета-поля — отдельным файлом, одной строкой, без `description`:

```bash
cat > "$WORK/meta.json" <<'METAEOF'
{"title":"Заголовок задачи","issue_type":"task","labels":"Backend,Task,Major,Backlog"}
METAEOF

perl "$WORK/mkjson.pl" "$WORK/desc.md" "$WORK/meta.json" "$WORK/issue.json"
```

**в) ни `jq`, ни `perl`** — собрать JSON любым доступным интерпретатором, соблюдая те же инварианты: описание читается из файла, результат пишется в файл. Ручное экранирование многострочного описания — крайний случай, и только для коротких описаний без кавычек.

**5.3. Отправить**

```bash
curl -s -w "\nHTTP:%{http_code}\n" --request POST \
  --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  --header "Content-Type: application/json" \
  --url "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/issues" \
  --data-binary "@$WORK/issue.json"
```

Поля `assignee_ids` и `milestone_id` включать только когда значение выбрано; `milestone_id` — не включать при `issue_type = issue`.

### 6. Проверить результат

Получить `iid` из ответа и проверить задачу:

```bash
curl -s "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/issues/{iid}" \
  --header "PRIVATE-TOKEN: $GITLAB_TOKEN"
```

Сообщить пользователю ссылку на созданную задачу.

---

## Запасной способ (если Bash недоступен)

PowerShell + `curl.exe` + UTF-8 файл (`Invoke-RestMethod` искажает кириллицу).

Перед формированием JSON выполнить те же запросы через `curl.exe` для получения лейблов, участников и спринтов (спринты — только для `issue_type = task`). Затем:

```powershell
$token = $env:GITLAB_TOKEN
$jsonFile = "$env:TEMP\gitlab_issue.json"
# "milestone_id":12 — опционально, включать только когда спринт выбран и issue_type = task
$content = '{"title":"Заголовок","description":"Описание","issue_type":"task","labels":"DEV,Backend,Task","assignee_ids":[123],"milestone_id":12}'
[System.IO.File]::WriteAllText($jsonFile, $content, [System.Text.Encoding]::UTF8)

curl.exe -s -X POST "https://gitlab.tywys.ru/api/v4/projects/risk-profile%2Frisk-profile-core/issues" `
    -H "PRIVATE-TOKEN: $token" -H "Content-Type: application/json" --data-binary "@$jsonFile"
```

---

## Приложение: привязка задачи к родительской фиче

Применять **только если** пользователь явно попросил создать задачу дочерней к существующей фиче. В основной поток создания задачи не входит.

REST API GitLab поля «родитель» не имеет — связь выставляется через GraphQL. Нужны внутренние `id` (не `iid`) обеих задач: поле `id` в ответе на создание.

```bash
cat > "$WORK/gql.json" <<GQLEOF
{"query":"mutation { workItemUpdate(input: {id: \"gid://gitlab/WorkItem/$CHILD_ID\", hierarchyWidget: {parentId: \"gid://gitlab/WorkItem/$PARENT_ID\"}}) { workItem { id iid } errors } }"}
GQLEOF

curl -s --request POST \
  --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  --header "Content-Type: application/json" \
  --url "https://gitlab.tywys.ru/api/graphql" \
  --data-binary "@$WORK/gql.json"
```

Успех — `"errors":[]` в ответе. Разделитель heredoc здесь не закавычен (`<<GQLEOF`), чтобы подставились переменные с id.
