# Эталонные примеры описания REST API методов

Этот файл содержит эталонные описания методов для проекта **Риск-профиль**. Используется как образец стиля и структуры для описания новых методов.

---

## Метод сохранения ответа клиента на вопрос

### Описание метода

Метод предназначен для получения вопросов для клиента и сохранения ответов на них. При первом вызове передаётся только `clientId` — метод возвращает первый вопрос. В последующих вызовах передаётся `questionCode` текущего вопроса и ответ на него; метод сохраняет ответ и возвращает следующий вопрос. Поддерживаются три формата ответа: выбор варианта(-ов) из списка, ввод свободного текста или пропуск вопроса. Когда вопросы заканчиваются, метод возвращает `isSuccess: true`, а поля `question`, `systemCode` и `systemName` содержат `null`.

### URL и параметры

```http
POST /v1/clients/{clientId}/questions/answers?questionCode={questionCode}&systemCode={systemCode}
```

<table>
<tr>
<td><strong>Параметр</strong></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>clientId (path-параметр)</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>questionCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>Код вопроса. Семантическая строка, например <code>cq_030</code> или <code>cq_010</code></td>
</tr>
<tr>
<td>systemCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма</td>
</tr>
<tr>
<td>optionCodes</td>
<td>array[string]</td>
<td>Нет</td>
<td>Массив с кодами выбранных вариантов ответа</td>
</tr>
<tr>
<td>answer</td>
<td>string</td>
<td>Нет</td>
<td>Ответ, введённый пользователем</td>
</tr>
<tr>
<td>isSkipped</td>
<td>boolean</td>
<td>Нет</td>
<td>Признак пропуска вопроса</td>
</tr>
</table>

### Валидации и ограничения

- clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- systemCode: длина от 2 до 36 символов. Если параметр не передан, возвращается следующий вопрос без фильтрации по системе организма
- questionCode: длина от 3 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- optionCodes: длина каждого элемента от 1 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- answer: длина до 255 символов
- Если questionCode передан, в теле запроса должен быть указан ровно один из параметров: массив optionCodes, answer или isSkipped. Если questionCode не передан, тело запроса должно быть пустым

### Пример запроса (первый вызов)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers
```

### Пример запроса (выбор варианта)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=anxiety-freq&systemCode=MENTAL
```

```json
{
  "optionCodes": ["a2", "a3"]
}
```

### Пример запроса (свободный текст)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=self-assessment
```

```json
{
  "answer": "Я чувствую себя хорошо."
}
```

### Пример запроса (boolean — ответ «да»)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sleep-issues
```

```json
{
  "optionCodes": ["true"]
}
```

### Пример запроса (boolean — ответ «нет»)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sleep-issues
```

```json
{
  "optionCodes": ["false"]
}
```

### Пример запроса (пропуск вопроса)

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/questions/answers?questionCode=sleep-issues
```

```json
{
  "isSkipped": true
}
```

### Параметры ответа

<table>
<tr>
<td><strong>Параметр</strong></td>
<td></td>
<td></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>isSuccess</td>
<td></td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак успешности выполнения запроса</td>
</tr>
<tr>
<td>error</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект со сведениями об ошибке</td>
</tr>
<tr>
<td></td>
<td>code</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код ошибки</td>
</tr>
<tr>
<td></td>
<td>message</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Описание ошибки</td>
</tr>
<tr>
<td>systemCode</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма. null, если вопросы закончились</td>
</tr>
<tr>
<td>systemName</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Название системы организма. null, если вопросы закончились</td>
</tr>
<tr>
<td>systemCompletionPercentage</td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Процент прохождения опросника по текущей системе организма</td>
</tr>
<tr>
<td>question</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект с вопросом. null, если вопросы закончились</td>
</tr>
<tr>
<td></td>
<td>questionCode</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Код вопроса. Семантическая строка, например <code>cq_030</code> или <code>cq_010</code></td>
</tr>
<tr>
<td></td>
<td>type</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Тип вопроса. Возможны следующие значения: boolean, select, multi, numeric</td>
</tr>
<tr>
<td></td>
<td>text</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Текст вопроса</td>
</tr>
<tr>
<td></td>
<td>isSkippable</td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак возможности пропуска вопроса</td>
</tr>
<tr>
<td></td>
<td>options</td>
<td></td>
<td>array[object]</td>
<td>Нет</td>
<td>Варианты ответа на вопрос</td>
</tr>
<tr>
<td></td>
<td></td>
<td>optionCode</td>
<td>string</td>
<td>Да</td>
<td>Код варианта ответа</td>
</tr>
<tr>
<td></td>
<td></td>
<td>text</td>
<td>string</td>
<td>Да</td>
<td>Текст варианта ответа</td>
</tr>
</table>

### Валидации и ограничения

- error.code: не более 100 символов
- error.message: не более 255 символов
- systemCode: от 2 до 36 символов
- systemName: не более 100 символов
- systemCompletionPercentage: целое число от 0 до 100
- question.questionCode: длина от 3 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- question.type: допустимы только следующие значения — boolean, select, multi, numeric
- question.text: не более 500 символов
- question.isSkippable: обязательное булево поле
- question.options: присутствует для типов boolean, select и multi; для numeric возвращается null
- option.optionCode: длина от 1 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания)
- option.text: не более 255 символов

### Коды ответов

- 200 OK — запрос выполнен успешно: ответ сохранён (если передан) и возвращён следующий вопрос (если есть).
- 400 Bad Request — некорректные параметры или нарушение ограничений по длине/формату.
- 404 Not Found — клиент или вопрос не найдены.
- 500 Internal Server Error — внутренняя ошибка сервера.

### Пример успешного ответа

#### Есть следующий вопрос — тип select

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "MENTAL",
  "systemName": "Ментальное здоровье",
  "systemCompletionPercentage": 45,
  "question": {
    "questionCode": "anxiety-freq",
    "type": "select",
    "text": "Как часто вы испытываете тревогу?",
    "isSkippable": true,
    "options": [
      {
        "optionCode": "a1",
        "text": "Редко"
      },
      {
        "optionCode": "a2",
        "text": "Иногда"
      },
      {
        "optionCode": "a3",
        "text": "Часто"
      }
    ]
  }
}
```

#### Есть следующий вопрос — тип multi

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "MENTAL",
  "systemName": "Ментальное здоровье",
  "systemCompletionPercentage": 50,
  "question": {
    "questionCode": "week-symptoms",
    "type": "multi",
    "text": "Какие симптомы вы испытывали на прошлой неделе?",
    "isSkippable": true,
    "options": [
      {
        "optionCode": "a1",
        "text": "Усталость"
      },
      {
        "optionCode": "a2",
        "text": "Головная боль"
      },
      {
        "optionCode": "a3",
        "text": "Нарушение сна"
      }
    ]
  }
}
```

#### Есть следующий вопрос — тип boolean

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "MENTAL",
  "systemName": "Ментальное здоровье",
  "systemCompletionPercentage": 60,
  "question": {
    "questionCode": "sleep-issues",
    "type": "boolean",
    "text": "Испытываете ли вы трудности со сном?",
    "isSkippable": false,
    "options": [
      {
        "optionCode": "true",
        "text": "Да"
      },
      {
        "optionCode": "false",
        "text": "Нет"
      }
    ]
  }
}
```

#### Есть следующий вопрос — тип numeric

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": "MENTAL",
  "systemName": "Ментальное здоровье",
  "systemCompletionPercentage": 75,
  "question": {
    "questionCode": "self-assessment",
    "type": "numeric",
    "text": "Введите значение показателя.",
    "isSkippable": true,
    "options": null
  }
}
```

#### Вопросы закончились

```json
{
  "isSuccess": true,
  "error": null,
  "systemCode": null,
  "systemName": null,
  "systemCompletionPercentage": 100,
  "question": null
}
```

### Пример ошибки

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_ANSWER_TYPE",
    "message": "Для типа ответа 'option' обязательно должен быть указан optionCode."
  }
}
```

---

## Метод получения оценки медицинских рисков

### Описание метода

Метод предназначен для получения оценки медицинских рисков по идентификатору клиента. В ответе возвращается признак успешности операции и массив с деталями по каждому выявленному риску.

### URL и параметры

```http
GET /v1/clients/{clientId}/medical-risk?systemCode={systemCode}
```

### Параметры запроса

<table>
<tr>
<td><strong>Параметр</strong></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>clientId (path-параметр)</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>systemCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма</td>
</tr>
</table>

### Валидации и ограничения

* clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания).
* systemCode: длина от 2 до 36 символов. Если параметр не передан, возвращаются риски по всем системам организма.

### Пример запроса

```http
GET /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk?systemCode=MENTAL
```

### Бизнес-логика

1. **Валидация входных параметров.** Проверяется формат `clientId` и, если передан, формат `systemCode`. При нарушении возвращается 400.
2. **Поиск пациента.** По `clientId` ищется запись в таблице `patients`. Если не найдена — возвращается 404 (`CLIENT_NOT_FOUND`). Из записи извлекается `is_pregnant` → `isPregnant`. Если `is_pregnant = true` — возвращается ответ с `isPregnant: true`, `completionPercentage: 100`, `lastCalculationDateTime: null`, `lastInterpretationDateTime: null`, `topRecommendations: null`. В `systemInterpretationResults` — все системы кроме `COMMON` (или только переданная), для каждой: `systemCode`, `systemName`, `systemPriority` из `systems`; `systemCompletionPercentage: 100`; `interpretationStatus`, `interpretationDateTime`, `risk`, `doctorSpecializations`, `diseaseRisks` — `null`. Дальнейшая логика не выполняется.
3. **Определение перечня систем организма.**
   - Если `systemCode` не передан — загружаются все системы из `systems`, упорядоченные по `rang`.
   - Если `systemCode` передан — загружается только система с соответствующим кодом.
   - Из каждой системы берётся `code → systemCode`, `description → systemName`, `rang → systemPriority`.
   - Система `COMMON` в список не включается. Её параметры используются на шаге 4, но запись в `systemInterpretationResults` для неё не формируется.
4. **Расчёт процента заполненности опросника по каждой системе.**
   - Запись в `patients_parameters` считается актуальной, если `value` не равен `NULL`, `expiration_date` не равен `NULL` и не меньше текущей даты.
   - Через `systems_instruments` → `instruments_parameters` собираются `parameter_code` системы. Аналогично добавляются параметры системы `COMMON`.
   - **answered_params_set** — множество уникальных `parameter_code` из этого набора с актуальным значением в `patients_parameters`. Накапливается в единое глобальное множество `global_answered_params_set` (используется на шаге 6).
   - **answered_params** — размер `answered_params_set`.
   - **remaining_applicable_set** — множество вопросов из `questions` для параметров без актуального значения, прошедших проверку условий из `conditions`. Накапливается в глобальное множество `global_remaining_set` (используется на шаге 6). По полю `conditions.question_code` ищем записи в таблице `conditions` для каждого вопроса:
     - **Если условий нет** — вопрос включается в множество.
     - **Если `type = 'except'`:**
       - По `conditions.parameter_code` находим актуальную запись пациента в `patients_parameters`.
       - Сравниваем `conditions.value` с `patients_parameters.value`:
         - Если значения совпадают — вопрос исключается из множества.
         - Если значения не совпадают — вопрос включается.
     - **Если `type = 'age'`:**
       - Считываем из `conditions` значения `min_age` и `max_age`.
       - По `parameter_code = birthdate` находим актуальную запись в `patients_parameters` и вычисляем возраст пациента на текущую дату.
       - Если возраст входит в диапазон от `min_age` до `max_age` включительно — вопрос включается; иначе — исключается.
   - **remaining_applicable** = |`remaining_applicable_set`|.
   - `systemCompletionPercentage = floor(answered_params / (answered_params + remaining_applicable) × 100)`.
5. **Определение статуса интерпретации и данных риска по каждой системе.**
   - Из `interpretations` ищется запись для данного пациента (`patient_id`) и данной системы (`system_code`).
   - Если запись не найдена:
     - `interpretationStatus = "not enough data"`.
     - `interpretationDateTime = null`, `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`.
   - Если запись найдена:
     - `interpretationStatus = "completed"`.
     - `interpretationDateTime = interpretations.date_time`.
     - Если `interpretations.risk_level = null`:
       - `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`.
     - Если `interpretations.risk_level` задан (`low`, `medium`, `high`):
       - **Риск.** Из найденной записи `interpretations` извлекается: `risk_level → risk.riskLevel`, `text → risk.description` (если `interpretations.text = null` — `risk.description = ""`), `date_time → risk.interpretationDateTime`.
       - **Факторы риска.** Алгоритм интерпретации не сохраняет `risk_factors_code` при уровне риска `low` (поле равно `null`). Поэтому:
         - Если `risk_level = low`: `riskFactors = null`.
         - Если `risk_level = medium` или `high`: из `interpretations.risk_factors_code` берётся упорядоченный массив кодов факторов. По каждому коду ищется запись в `risk_factors` (совпадение по `risk_factors.code`). Из отобранных включать в ответ только те, где `risk_factors.modifiability = 'modifiable'`. Из каждого подходящего фактора: `description → riskFactors[].title`; поле `details` возвращается пустым (согласованное поведение). Порядок факторов соответствует порядку кодов в `interpretations.risk_factors_code`.
       - **Рекомендации.** Из `recommendations` берутся записи двух групп, объединяемые в единый список:
         - `recommendations_group = 'risk_factor_group'`: записи, связанные с выявленными факторами риска (`risk_factor_code`) и данной системой (`system_code`).
         - `recommendations_group = 'common_group'`: записи, связанные только с данной системой (`system_code`). Включаются всегда, независимо от наличия риск-факторов.
         `name → recommendations[].title`, `text → recommendations[].details`.
       - **Заболевания.** `interpretations.diseases[]` → `diseaseRisks[].name`.
       - **Специализации врачей.** Из `interpretations.doctors_code` берётся массив кодов врачей. По каждому коду ищется запись в `doctors`: `description → doctorSpecializations[].name`, `code → doctorSpecializations[].code`.

   В ходе обхода систем параллельно накапливаются:
   - `global_max_interpretation_dt` — максимальный `interpretations.date_time` среди всех систем, для которых найдена запись.
   - `global_max_calculation_dt` — максимальный `results.date_time` по инструментам системы пациента среди записей с непустым `value` (отдельный запрос к `results`).
   - `global_recommendations` — список всех пар (рекомендация, система), отобранных по шагу 5.
6. **Расчёт общего процента заполненности (`completionPercentage`).** Переиспользует данные, накопленные на шаге 4, без дополнительных обращений к БД:
   - **total_answered** = |`global_answered_params_set`| — мощность объединённого множества параметров с актуальными значениями по всем системам + `COMMON`.
   - **total_remaining** = |`global_remaining_set`| — мощность объединённого множества применимых вопросов без актуальных значений по всем системам + `COMMON`.
   - `completionPercentage = floor(total_answered / (total_answered + total_remaining) × 100)`.
7. **Определение дат и топ-рекомендаций.** Переиспользует данные, накопленные на шаге 5:
   - `lastCalculationDateTime` = `global_max_calculation_dt`. Если актуальных результатов не было ни по одной системе — `null`.
   - `lastInterpretationDateTime` = `global_max_interpretation_dt`. Если интерпретаций нет — `null`.
   - `topRecommendations`: из `global_recommendations` упорядочиваются по убыванию `interpretations.risk_level` системы (high → medium → low), затем по `systems.rang` (по возрастанию). Дедуплицируются по полю `name`. Возвращаются первые 5. Если список пуст — `null`.
8. **Сборка ответа.** Все поля собраны на предыдущих шагах. Системы в `systemInterpretationResults` сохраняют порядок, заданный на шаге 3 (по возрастанию `rang`).

### Параметры ответа

<table>
<tr>
<td><strong>Параметр</strong></td>
<td></td>
<td></td>
<td></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>isSuccess</td>
<td></td>
<td></td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак успешности выполнения запроса</td>
</tr>
<tr>
<td>error</td>
<td></td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект со сведениями об ошибке</td>
</tr>
<tr>
<td></td>
<td>code</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код ошибки</td>
</tr>
<tr>
<td></td>
<td>message</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Описание ошибки</td>
</tr>
<tr>
<td>isPregnant</td>
<td></td>
<td></td>
<td></td>
<td>boolean</td>
<td>Нет</td>
<td>Признак беременности пользователя</td>
</tr>
<tr>
<td>completionPercentage</td>
<td></td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Общий процент прохождения опросника</td>
</tr>
<tr>
<td>lastCalculationDateTime</td>
<td></td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время последней калькуляции риск-профиля</td>
</tr>
<tr>
<td>lastInterpretationDateTime</td>
<td></td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время последней интерпретации риск-профиля</td>
</tr>
<tr>
<td>topRecommendations</td>
<td></td>
<td></td>
<td></td>
<td>array[object]</td>
<td>Нет</td>
<td>Массив топ-рекомендаций по всем рискам</td>
</tr>
<tr>
<td></td>
<td>title</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Заголовок рекомендации</td>
</tr>
<tr>
<td></td>
<td>details</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Развёрнутый текст рекомендации</td>
</tr>
<tr>
<td>systemInterpretationResults</td>
<td></td>
<td></td>
<td></td>
<td>array[object]</td>
<td>Да</td>
<td>Массив с результатами интерпретации по системам организма</td>
</tr>
<tr>
<td></td>
<td>systemCode</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Код системы организма</td>
</tr>
<tr>
<td></td>
<td>systemName</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Название системы организма</td>
</tr>
<tr>
<td></td>
<td>interpretationStatus</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Статус интерпретации по системе организма. Возможные значения: completed, not enough data</td>
</tr>
<tr>
<td></td>
<td>interpretationDateTime</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время интерпретации по системе организма</td>
</tr>
<tr>
<td></td>
<td>systemCompletionPercentage</td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Процент прохождения опросника по переданной в запросе системе</td>
</tr>
<tr>
<td></td>
<td>systemPriority</td>
<td></td>
<td></td>
<td>integer</td>
<td>Нет</td>
<td>Критичность системы организма. Целое число в диапазоне 1–13, уникальное среди всех систем</td>
</tr>
<tr>
<td></td>
<td>doctorSpecializations</td>
<td></td>
<td></td>
<td>array[object]</td>
<td>Нет</td>
<td>Специализации врачей, к которым рекомендуется обратиться</td>
</tr>
<tr>
<td></td>
<td></td>
<td>name</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Название специализации врача</td>
</tr>
<tr>
<td></td>
<td></td>
<td>code</td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Код специализации врача</td>
</tr>
<tr>
<td></td>
<td>diseaseRisks</td>
<td></td>
<td></td>
<td>array[object]</td>
<td>Нет</td>
<td>Массив рисков заболеваний</td>
</tr>
<tr>
<td></td>
<td></td>
<td>name</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Наименование заболевания</td>
</tr>
<tr>
<td></td>
<td>risk</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект с информацией по риску</td>
</tr>
<tr>
<td></td>
<td></td>
<td>interpretationDateTime</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время интерпретации риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td>riskLevel</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Вероятность наступления риска. Возможные значения: low, medium, high</td>
</tr>
<tr>
<td></td>
<td></td>
<td>description</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Описание риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td>riskFactors</td>
<td></td>
<td>array[object]</td>
<td>Да</td>
<td>Массив с информацией по факторам риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>title</td>
<td>string</td>
<td>Да</td>
<td>Заголовок фактора риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>details</td>
<td>string</td>
<td>Да</td>
<td>Развёрнутый текст фактора риска. Всегда возвращается пустым (null)</td>
</tr>
<tr>
<td></td>
<td></td>
<td>recommendations</td>
<td></td>
<td>array[object]</td>
<td>Да</td>
<td>Массив рекомендаций к риску</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>title</td>
<td>string</td>
<td>Да</td>
<td>Заголовок рекомендации</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>details</td>
<td>string</td>
<td>Нет</td>
<td>Развёрнутый текст рекомендации</td>
</tr>
</table>

### Валидации и ограничения

* systemCode: от 2 до 36 символов
* systemName: не более 100 символов
* interpretationStatus: только значения из списка (completed, not enough data)
* interpretationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* completionPercentage: целое число в диапазоне 0–100
* lastCalculationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* lastInterpretationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* systemCompletionPercentage: целое число в диапазоне 0–100
* systemPriority: целое число в диапазоне 1–13, значения не повторяются между системами
* diseaseRisks.name: не более 255 символов
* riskLevel: только значения из списка (low, medium, high)
* description: не более 2000 символов
* doctorSpecializations.name: не более 100 символов
* riskFactors.title: не более 100 символов
* riskFactors.details: не более 2000 символов
* recommendations.title: не более 100 символов
* recommendations.details: не более 2000 символов
* topRecommendations.title: не более 100 символов
* topRecommendations.details: не более 2000 символов
* error.code: не более 100 символов
* error.message: не более 255 символов

### Коды ответов

- 200 OK — успешное выполнение, данные по рискам возвращены.
- 400 Bad Request — некорректный clientId или нарушение ограничений по длине/формату.
- 404 Not Found — клиент с указанным clientId не найден.
- 500 Internal Server Error — внутренняя ошибка сервера.

### Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 62,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": [
    {
      "title": "Консультация кардиолога",
      "details": null
    },
    {
      "title": "Консультация психотерапевта",
      "details": null
    }
  ],
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:00:00",
      "systemCompletionPercentage": 90,
      "systemPriority": 1,
      "doctorSpecializations": [
        {
          "name": "Кардиолог",
          "code": 23
        }
      ],
      "diseaseRisks": [
        { "name": "Ишемическая болезнь сердца" },
        { "name": "Артериальная гипертензия" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:00:00",
        "riskLevel": "high",
        "description": "Высокий риск развития сердечно-сосудистых заболеваний на основании выявленных факторов",
        "riskFactors": [
          {
            "title": "Повышенное артериальное давление",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Консультация кардиолога",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:10:00",
      "systemCompletionPercentage": 80,
      "systemPriority": 5,
      "doctorSpecializations": [
        {
          "name": "Психолог",
          "code": 47
        }
      ],
      "diseaseRisks": [
        { "name": "Тревожное расстройство" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:10:00",
        "riskLevel": "high",
        "description": "Повышенный риск развития тревожного расстройства на основе выявленных факторов",
        "riskFactors": [
          {
            "title": "Хронический стресс",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Консультация психотерапевта",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 40,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

### Пример успешного ответа — ни одна система не посчитана

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 0,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

### Пример успешного ответа — интерпретация без уровня риска

Система прошла интерпретацию, но среди применимых результатов не оказалось ни одного с заданным `risk_level` (все `applicability = false`). Статус интерпретации — `completed`, все данные по риску — `null`.

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 70,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": null,
  "systemInterpretationResults": [
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-26T09:10:00",
      "systemCompletionPercentage": 85,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

### Пример успешного ответа — пациент беременен

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": true,
  "completionPercentage": 100,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 5,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

### Пример неуспешного ответа

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```

---

## Метод сохранения антропометрических данных клиента

### Описание метода

Метод предназначен для сохранения или обновления основных антропометрических данных клиента: рост, вес, возраст и пол. В теле запроса передаются значения этих параметров, а в пути — идентификатор клиента.

### URL

```http
POST /v1/clients/{clientId}/anthropometry
```

### Параметры запроса

<table>
<tr>
<td><strong>Параметр</strong></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>clientId (path-параметр)</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>heightCm</td>
<td>number</td>
<td>Нет</td>
<td>Рост клиента в сантиметрах</td>
</tr>
<tr>
<td>weightKg</td>
<td>number</td>
<td>Нет</td>
<td>Вес клиента в килограммах</td>
</tr>
<tr>
<td>birthDate</td>
<td>string</td>
<td>Нет</td>
<td>Дата рождения клиента</td>
</tr>
<tr>
<td>gender</td>
<td>string</td>
<td>Нет</td>
<td>Пол клиента. Возможные значения "male" | "female"</td>
</tr>
</table>

### Валидации и ограничения

* clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания).
* heightCm: число, диапазон 50–250.
* weightKg: число, диапазон 10–300.
* birthDate: строка в формате YYYY-MM-DD.
* gender: допустимы только значения `male` или `female`.
* Должен быть передан хотя бы один из параметров heightCm, weightKg, birthDate, gender.

### Пример запроса

```http
POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/anthropometry
```

```json
{
  "heightCm": 175,
  "weightKg": 72,
  "birthDate": "1990-03-15",
  "gender": "male"
}
```

### Параметры ответа

<table>
<tr>
<td><strong>Параметр</strong></td>
<td></td>
<td><strong>Тип</strong></td>
<td><strong>Обязательность</strong></td>
<td><strong>Описание</strong></td>
</tr>
<tr>
<td>isSuccess</td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак успешности выполнения запроса</td>
</tr>
<tr>
<td>error</td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект со сведениями об ошибке</td>
</tr>
<tr>
<td></td>
<td>code</td>
<td>string</td>
<td>Нет</td>
<td>Код ошибки</td>
</tr>
<tr>
<td></td>
<td>message</td>
<td>string</td>
<td>Нет</td>
<td>Описание ошибки</td>
</tr>
</table>

### Валидации и ограничения

* error.code: не более 100 символов.
* error.message: не более 255 символов.

### Коды ответов

* 201 Created — данные успешно сохранены или обновлены.
* 400 Bad Request — некорректные параметры или нарушение ограничений по диапазону/формату.
* 404 Not Found — клиент с указанным clientId не найден.
* 500 Internal Server Error — внутренняя ошибка сервера.

### Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null
}
```

### Пример ошибки

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_HEIGHT",
    "message": "Рост должен быть в диапазоне от 50 до 250 см."
  }
}
```
