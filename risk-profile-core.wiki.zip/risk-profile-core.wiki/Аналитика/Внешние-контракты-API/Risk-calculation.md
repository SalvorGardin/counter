---
title: Risk-calculation
---

## Описание

Сообщение публикуется в очередь по завершении расчёта риск-профиля клиента. Потребитель получает идентификатор клиента и список кодов систем организма, по которым расчёт завершился. В одном сообщении может быть передана одна или несколько систем организма.

## Топик

```
risk-calculation
```

## Параметры сообщения

<table>
<tr>
<td>

**Параметр**
</td>
<td>

**Тип**
</td>
<td>

**Обязательность**
</td>
<td>

**Описание**
</td>
</tr>
<tr>
<td>clientId</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>systemCodes</td>
<td>

array\[string\]
</td>
<td>Нет</td>
<td>Коды систем организма, по которым завершился расчёт</td>
</tr>
<tr>
<td>messageType</td>
<td>string</td>
<td>Да</td>
<td>Тип сообщения. Возможные значения: calculation, interpretation</td>
</tr>
</table>

## Валидации и ограничения

* clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания).
* systemCodes: если передан, массив содержит не менее одного элемента; длина каждого элемента от 2 до 36 символов.
* messageType: только значения из списка (calculation, interpretation).

> **Примечание:** Значение `messageType` определяет контекст расчёта:
> - `calculation` — событие отправляется в рамках расчётов калькуляторов, см. [Калькуляторы и опросники](https://gitlab.tywys.ru/risk-profile/risk-profile-core/-/wikis/%D0%90%D0%BD%D0%B0%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%B0/%D0%9A%D0%B0%D0%BB%D1%8C%D0%BA%D1%83%D0%BB%D1%8F%D1%82%D0%BE%D1%80%D1%8B-%D0%B8-%D0%BE%D0%BF%D1%80%D0%BE%D1%81%D0%BD%D0%B8%D0%BA%D0%B8)
> - `interpretation` — событие отправляется в рамках процесса интерпретации, см. [Интерпретация](https://gitlab.tywys.ru/risk-profile/risk-profile-core/-/wikis/%D0%90%D0%BD%D0%B0%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%B0/%D0%98%D0%BD%D1%82%D0%B5%D1%80%D0%BF%D1%80%D0%B5%D1%82%D0%B0%D1%86%D0%B8%D1%8F)

## Пример сообщения

```json
{
  "clientId": "123e4567-e89b-12d3-a456-426614174000",
  "messageType": "calculation",
  "systemCodes": ["MENTAL", "CVD"]
}
```