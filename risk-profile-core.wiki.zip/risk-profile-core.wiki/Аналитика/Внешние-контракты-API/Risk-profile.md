## Описание метода

Метод предназначен для получения оценки медицинских рисков по идентификатору клиента. В ответе возвращается признак успешности операции и массив с деталями по каждому выявленному риску.

## URL и параметры

```http
GET /v1/clients/{clientId}/medical-risk?systemCode={systemCode}
```

## Параметры запроса

<table>
<tr>
<td>

**Параметр**
</td>
<td>

**Тип**
</td>
<td>

**Обязательность**
</td>
<td>

**Описание**
</td>
</tr>
<tr>
<td>clientId (path-параметр)</td>
<td>string</td>
<td>Да</td>
<td>Идентификатор клиента</td>
</tr>
<tr>
<td>systemCode (query-параметр)</td>
<td>string</td>
<td>Нет</td>
<td>Код системы организма</td>
</tr>
</table>

## Валидации и ограничения

* clientId: длина от 5 до 36 символов, только допустимые символы (буквы, цифры, дефисы, подчёркивания).
* systemCode: длина от 2 до 36 символов. Если параметр не передан, возвращаются риски по всем системам организма.

## Пример запроса

```http
GET /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk?systemCode=MENTAL
```

## Бизнес-логика

> Шаг 5 в части выборки факторов риска и обоснования описывает целевую схему справочника (`risk_factors` + `risk_factor_systems`) по [#185](https://gitlab.tywys.ru/risk-profile/risk-profile-core/-/work_items/185) и вступает в силу с миграцией. До неё действует прежняя структура `risk_factors`.

1. **Валидация входных параметров.** Проверяется формат `clientId` и, если передан, формат `systemCode`. При нарушении возвращается 400 (`INVALID_CLIENT_ID`).
2. **Поиск пациента.** По `clientId` ищется запись в таблице `patients`. Если не найдена — возвращается 404 (`CLIENT_NOT_FOUND`). Из записи извлекается `is_pregnant` → `isPregnant`. Если `is_pregnant = true` — возвращается ответ с `isPregnant: true`, `completionPercentage: 100`, `lastCalculationDateTime: null`, `lastInterpretationDateTime: null`, `topRecommendations: null`. В `systemInterpretationResults` — все системы кроме `COMMON` (или только переданная), для каждой: `systemCode`, `systemName`, `systemPriority` из `systems`; `systemCompletionPercentage: 100`; `interpretationStatus`, `interpretationDateTime`, `risk`, `doctorSpecializations`, `diseaseRisks` — `null`. Дальнейшая логика не выполняется.
3. **Определение перечня систем организма.**
   - Если `systemCode` не передан — загружаются все системы из `systems`, упорядоченные по `rang`.
   - Если `systemCode` передан — загружается только система с соответствующим кодом.
   - Из каждой системы берётся `code → systemCode`, `description → systemName`, `rang → systemPriority`.
   - Система `COMMON` в список не включается и в расчёте заполненности отдельно не участвует (её вопросы попадают в системы через свои варианты); запись в `systemInterpretationResults` для неё не формируется.
4. **Расчёт процента заполненности опросника по каждой системе.** Заполненность считается в целых вопросах. Для каждой системы строятся два множества вопросов — `applicable_questions` (знаменатель) и `progressed_questions` (числитель).
   - Запись в `patients_parameters` считается актуальной, если `value` не равен `NULL`, `expiration_date` не равен `NULL` и не меньше текущей даты.
   - Вопрос относится к системе, если хотя бы у одного его варианта из `options` значение `parameter_code` относится к инструменту этой системы (`options.parameter_code` → `instruments_parameters` → `systems_instruments` с `system_code` системы). Система `COMMON` отдельно не добавляется — её вопросы попадают в системы через свои варианты.
   - **applicable_questions** — вопросы, относящиеся к системе и применимые пациенту по полу и возрасту. Из числа относящихся к системе вопросов исключается вопрос, для которого по `conditions.question_code` найдено срабатывающее условие пола или возраста:
     - **Если `type = 'except'` и `parameter_code = 'gender'`:** по `parameter_code = gender` находим актуальную запись пациента в `patients_parameters`; если `conditions.value` совпадает с её значением — вопрос исключается.
     - **Если `type = 'age'`:** по `parameter_code = birthdate` находим актуальную запись в `patients_parameters` и вычисляем возраст пациента на текущую дату; если возраст не входит в диапазон от `min_age` до `max_age` включительно — вопрос исключается.
     - Условия `type = 'except'` с `parameter_code`, отличным от `gender`, на состав `applicable_questions` не влияют.
   - **progressed_questions** — вопросы из `applicable_questions`, для которых выполнено хотя бы одно из условий:
     - все значения `parameter_code`, которые вопрос записывает через свои `options`, имеют актуальную запись в `patients_parameters`. Для вопроса `cq_030` условие считается выполненным, если `patients.is_pregnant` не равно `NULL`.
     - по `conditions.question_code` найдено условие `type = 'except'` с `parameter_code`, отличным от `gender`, у которого `conditions.value` совпадает со значением актуальной записи пациента по `conditions.parameter_code` (вопрос не будет показан).
   - Множества `applicable_questions` и `progressed_questions` накапливаются в глобальные множества `global_applicable` и `global_progressed` (по `question_code`, без повторов; используются на шаге 6).
   - **applicable** — количество вопросов в `applicable_questions`; **progressed** — количество вопросов в `progressed_questions`.
   - `systemCompletionPercentage = floor(progressed / applicable × 100)`. Если `applicable = 0` — `systemCompletionPercentage = 100`.
5. **Определение статуса интерпретации и данных риска по каждой системе.**
   - Из `interpretations` ищется запись для данного пациента (`patient_id`) и данной системы (`system_code`).
   - Если запись не найдена:
     - `interpretationStatus = "not enough data"`.
     - `interpretationDateTime = null`, `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`.
   - Если запись найдена:
     - `interpretationStatus = "completed"`.
     - `interpretationDateTime = interpretations.date_time`.
     - Если `interpretations.risk_level = null`:
       - `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`.
     - Если `interpretations.risk_level` задан (`low`, `medium`, `high`):
       - **Риск.** Из найденной записи `interpretations` извлекается: `risk_level → risk.riskLevel`, `text → risk.description` (если `interpretations.text = null` — `risk.description = ""`), `date_time → risk.interpretationDateTime`.
       - **Факторы риска.** Алгоритм интерпретации не сохраняет `risk_factors_code` при уровне риска `low` (поле равно `null`). Поэтому:
         - Если `risk_level = low`: `riskFactors = null`.
         - Если `risk_level = medium` или `high`: из `interpretations.risk_factors_code` берётся упорядоченный массив кодов факторов. По каждому коду ищется запись в `risk_factor_systems` (совпадение по `risk_factor_systems.risk_factor_code` **и** `risk_factor_systems.system_code = system_code` текущей системы); название берётся из связанной записи `risk_factors` по `risk_factors.code`. Из найденной пары: `risk_factors.description → riskFactors[].title`; `risk_factor_systems.reasoning → riskFactors[].details` (если `risk_factor_systems.reasoning = null` — `riskFactors[].details = null`). Порядок факторов соответствует порядку кодов в `interpretations.risk_factors_code`.
       - **Рекомендации.** Из `recommendations` берутся записи двух групп, объединяемые в единый список:
         - `recommendations_group = 'risk_factor_group'`: записи, связанные с выявленными **модифицируемыми** факторами риска (`risk_factors.modifiability = 'modifiable'`, `risk_factor_code`) и данной системой (`system_code`).
         - `recommendations_group = 'common_group'`: записи, связанные только с данной системой (`system_code`). Включаются всегда, независимо от наличия риск-факторов.
         Объединённый список дедуплицируется по полю `name`: при совпадении остаётся первое вхождение (сначала идут записи `risk_factor_group`, затем `common_group`).
         `name → recommendations[].title`, `text → recommendations[].details`.
       - **Заболевания.** `interpretations.diseases[]` хранит коды групп заболеваний. По каждому коду ищется запись в `diseases`: `description → diseaseRisks[].name`. Код, которого нет в справочнике, в ответ не попадает и пишется в лог — иначе в поле названия пользователь увидел бы внутренний идентификатор; если не разрешился ни один код, `diseaseRisks = null`.
       - **Специализации врачей.** Из `interpretations.doctors_code` берётся массив кодов врачей. По каждому коду ищется запись в `doctors`: `description → doctorSpecializations[].name`, `code → doctorSpecializations[].code`.

   В ходе обхода систем параллельно накапливаются:
   - `global_max_interpretation_dt` — максимальный `interpretations.date_time` среди всех систем, для которых найдена запись.
   - `global_max_calculation_dt` — максимальный `results.date_time` по инструментам системы пациента среди записей с непустым `value` (отдельный запрос к `results`).
   - `global_recommendations` — список кандидатов, накопленных по шагу 5. Каждый кандидат хранит: рекомендацию (`title`, `details`), `group` (`risk_factor_group` / `common_group`), `risk_level` системы, `system_rang` (`systems.rang`).
6. **Расчёт общего процента заполненности (`completionPercentage`).** Переиспользует множества, накопленные на шаге 4, без дополнительных обращений к БД:
   - **total_applicable** — количество вопросов в объединённом множестве `global_applicable` (по всем системам, без повторов по `question_code`).
   - **total_progressed** — количество вопросов в объединённом множестве `global_progressed`.
   - `completionPercentage = floor(total_progressed / total_applicable × 100)`. Если `total_applicable = 0` — `completionPercentage = 100`.
7. **Определение дат и топ-рекомендаций.** Переиспользует данные, накопленные на шаге 5:
   - `lastCalculationDateTime` = `global_max_calculation_dt`. Если актуальных результатов не было ни по одной системе — `null`.
   - `lastInterpretationDateTime` = `global_max_interpretation_dt`. Если интерпретаций нет — `null`.
   - `topRecommendations`: строится из `global_recommendations` по следующей логике:
     1. **Основная выборка.** Берутся кандидаты с `group = 'risk_factor_group'` и `risk_level` системы = `high` или `medium`. Сортируются: сначала по убыванию `risk_level` (high → medium), затем по возрастанию `system_rang`, затем в порядке следования кода фактора в `interpretations.risk_factors_code`.
     2. **Дополнение.** Если в основной выборке менее 5 позиций, список дополняется кандидатами с `group = 'common_group'` (сортировка: по возрастанию `system_rang`), пока не наберётся 5 или не закончатся кандидаты.
     3. **Финализация.** Дедуплицируются по полю `title` (при совпадении остаётся первый по порядку сортировки). Возвращаются первые 5. Если список пуст — `null`.
8. **Сборка ответа.** Все поля собраны на предыдущих шагах. Системы в `systemInterpretationResults` сохраняют порядок, заданный на шаге 3 (по возрастанию `rang`).

## Параметры ответа

<table>
<tr>
<td>

**Параметр**
</td>
<td></td>
<td></td>
<td></td>
<td>

**Тип**
</td>
<td>

**Обязательность**
</td>
<td>

**Описание**
</td>
</tr>
<tr>
<td>isSuccess</td>
<td></td>
<td></td>
<td></td>
<td>boolean</td>
<td>Да</td>
<td>Признак успешности выполнения запроса</td>
</tr>
<tr>
<td>error</td>
<td></td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Массив со сведениями об ошибке</td>
</tr>
<tr>
<td></td>
<td>code</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Код ошибки</td>
</tr>
<tr>
<td></td>
<td>message</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Описание ошибки</td>
</tr>
<tr>
<td>isPregnant</td>
<td></td>
<td></td>
<td></td>
<td>boolean</td>
<td>Нет</td>
<td>Признак беременности пользователя</td>
</tr>
<tr>
<td>completionPercentage</td>
<td></td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Общий процент прохождения опросника</td>
</tr>
<tr>
<td>lastCalculationDateTime</td>
<td></td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время последней калькуляции риск-профиля</td>
</tr>
<tr>
<td>lastInterpretationDateTime</td>
<td></td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время последней интерпретации риск-профиля</td>
</tr>
<tr>
<td>topRecommendations</td>
<td></td>
<td></td>
<td></td>
<td>

array\[object\]
</td>
<td>Нет</td>
<td>Массив топ-рекомендаций по всем рискам</td>
</tr>
<tr>
<td></td>
<td>title</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Заголовок рекомендации</td>
</tr>
<tr>
<td></td>
<td>details</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Развёрнутый текст рекомендации</td>
</tr>
<tr>
<td>systemInterpretationResults</td>
<td></td>
<td></td>
<td></td>
<td>

array\[object\]
</td>
<td>Да</td>
<td>Массив с результатами интерпретации по системам организма</td>
</tr>
<tr>
<td></td>
<td>systemCode</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Код системы организма</td>
</tr>
<tr>
<td></td>
<td>systemName</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Название системы организма</td>
</tr>
<tr>
<td></td>
<td>interpretationStatus</td>
<td></td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Статус интерпретации по системе организма. Возможные значения: completed, not enough data</td>
</tr>
<tr>
<td></td>
<td>interpretationDateTime</td>
<td></td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время интерпретации по системе организма</td>
</tr>
<tr>
<td></td>
<td>systemCompletionPercentage</td>
<td></td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Процент прохождения опросника по переданной в запросе системе</td>
</tr>
<tr>
<td></td>
<td>systemPriority</td>
<td></td>
<td></td>
<td>integer</td>
<td>Нет</td>
<td>Критичность системы организма. Целое число в диапазоне 1–13, уникальное среди всех систем</td>
</tr>
<tr>
<td></td>
<td>doctorSpecializations</td>
<td></td>
<td></td>
<td>

array\[object\]
</td>
<td>Нет</td>
<td>Специализации врачей, к которым рекомендуется обратиться</td>
</tr>
<tr>
<td></td>
<td></td>
<td>name</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Название специализации врача</td>
</tr>
<tr>
<td></td>
<td></td>
<td>code</td>
<td></td>
<td>integer</td>
<td>Да</td>
<td>Код специализации врача</td>
</tr>
<tr>
<td></td>
<td>diseaseRisks</td>
<td></td>
<td></td>
<td>

array\[object\]
</td>
<td>Нет</td>
<td>Массив рисков заболеваний</td>
</tr>
<tr>
<td></td>
<td></td>
<td>name</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Наименование заболевания</td>
</tr>
<tr>
<td></td>
<td>risk</td>
<td></td>
<td></td>
<td>object</td>
<td>Нет</td>
<td>Объект с информацией по риску</td>
</tr>
<tr>
<td></td>
<td></td>
<td>interpretationDateTime</td>
<td></td>
<td>string</td>
<td>Нет</td>
<td>Дата и время интерпретации риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td>riskLevel</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Вероятность наступления риска. Возможные значения: low, medium, high</td>
</tr>
<tr>
<td></td>
<td></td>
<td>description</td>
<td></td>
<td>string</td>
<td>Да</td>
<td>Описание риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td>riskFactors</td>
<td></td>
<td>

array\[object\]
</td>
<td>Да</td>
<td>Массив с информацией по факторам риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>title</td>
<td>string</td>
<td>Да</td>
<td>Заголовок фактора риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>details</td>
<td>string</td>
<td>Нет</td>
<td>Развёрнутый текст фактора риска</td>
</tr>
<tr>
<td></td>
<td></td>
<td>recommendations</td>
<td></td>
<td>

array\[object\]
</td>
<td>Да</td>
<td>Массив рекомендаций к риску</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>title</td>
<td>string</td>
<td>Да</td>
<td>Заголовок рекомендации</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>details</td>
<td>string</td>
<td>Нет</td>
<td>Развёрнутый текст рекомендации</td>
</tr>
</table>

## Валидации и ограничения

* systemCode: от 2 до 36 символов
* systemName: не более 100 символов
* interpretationStatus: только значения из списка (completed, not enough data)
* interpretationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* completionPercentage: целое число в диапазоне 0–100
* lastCalculationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* lastInterpretationDateTime: дата и время в формате ISO 8601 (YYYY-MM-DDThh:mm:ss)
* systemCompletionPercentage: целое число в диапазоне 0–100
* diseaseRisks.name: не более 255 символов
* riskLevel: только значения из списка (low, medium, high)
* description: не более 2000 символов
* doctorSpecializations.name: не более 100 символов
* riskFactors.title: не более 100 символов
* riskFactors.details: не более 2000 символов
* systemPriority: целое число в диапазоне 1–13, значения не повторяются между системами
* recommendations.title: не более 100 символов
* recommendations.details: не более 2000 символов
* topRecommendations.title: не более 100 символов
* topRecommendations.details: не более 2000 символов
* error.code: не более 100 символов
* error.message: не более 255 символов

## Коды ответов

- 200 OK — успешное выполнение, данные по рискам возвращены.
- 400 Bad Request — некорректный clientId или нарушение ограничений по длине/формату.
- 404 Not Found — клиент с указанным clientId не найден.
- 500 Internal Server Error — внутренняя ошибка сервера.

## Пример успешного ответа

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 62,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": [
    {
      "title": "Консультация кардиолога",
      "details": null
    },
    {
      "title": "Консультация психотерапевта",
      "details": null
    }
  ],
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:00:00",
      "systemCompletionPercentage": 90,
      "systemPriority": 1,
      "doctorSpecializations": [
        {
          "name": "Кардиолог",
          "code": 23
        }
      ],
      "diseaseRisks": [
        { "name": "Ишемическая болезнь сердца" },
        { "name": "Артериальная гипертензия" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:00:00",
        "riskLevel": "high",
        "description": "Высокий риск развития сердечно-сосудистых заболеваний на основании выявленных факторов",
        "riskFactors": [
          {
            "title": "Повышенное артериальное давление",
            "details": "Артериальное давление выше нормы повышает нагрузку на сердце и сосуды, увеличивая риск инфаркта и инсульта."
          }
        ],
        "recommendations": [
          {
            "title": "Консультация кардиолога",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 40,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:05:00",
      "systemCompletionPercentage": 95,
      "systemPriority": 3,
      "doctorSpecializations": [
        {
          "name": "Эндокринолог",
          "code": 41
        }
      ],
      "diseaseRisks": [
        { "name": "Сахарный диабет 2 типа" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:05:00",
        "riskLevel": "medium",
        "description": "Умеренный риск развития эндокринных нарушений на основании выявленных факторов",
        "riskFactors": [
          {
            "title": "Избыточный вес",
            "details": "Избыточная масса тела способствует развитию инсулинорезистентности и нарушению углеводного обмена."
          }
        ],
        "recommendations": [
          {
            "title": "Контроль уровня глюкозы",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:15:00",
      "systemCompletionPercentage": 85,
      "systemPriority": 4,
      "doctorSpecializations": [
        {
          "name": "Пульмонолог",
          "code": 49
        }
      ],
      "diseaseRisks": [
        { "name": "Хроническая обструктивная болезнь лёгких" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:15:00",
        "riskLevel": "low",
        "description": "Низкий риск развития заболеваний дыхательной системы",
        "riskFactors": null,
        "recommendations": [
          {
            "title": "Ежегодная флюорография",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-25T10:10:00",
      "systemCompletionPercentage": 80,
      "systemPriority": 5,
      "doctorSpecializations": [
        {
          "name": "Психолог",
          "code": 47
        }
      ],
      "diseaseRisks": [
        { "name": "Тревожное расстройство" },
        { "name": "Депрессивный эпизод" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-25T10:10:00",
        "riskLevel": "high",
        "description": "Повышенный риск развития тревожного расстройства на основе выявленных факторов",
        "riskFactors": [
          {
            "title": "Хронический стресс",
            "details": "Длительное психоэмоциональное напряжение нарушает работу нервной системы и повышает уровень кортизола."
          }
        ],
        "recommendations": [
          {
            "title": "Консультация психотерапевта",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 10,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 35,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 50,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 20,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 30,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 45,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 25,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 15,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

## Пример успешного ответа — ни одна система не посчитана

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 0,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 4,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 5,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

## Пример успешного ответа — интерпретация без уровня риска

Система прошла интерпретацию, но среди применимых результатов не оказалось ни одного с заданным `risk_level` (все `applicability = false`). Статус интерпретации — `completed`, все данные по риску — `null`.

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 70,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": [
    {
      "title": "Консультация кардиолога",
      "details": null
    }
  ],
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-26T09:15:00",
      "systemCompletionPercentage": 90,
      "systemPriority": 1,
      "doctorSpecializations": [
        {
          "name": "Кардиолог",
          "code": 23
        }
      ],
      "diseaseRisks": [
        { "name": "Инфаркт и ишемический инсульт" }
      ],
      "risk": {
        "interpretationDateTime": "2024-03-26T09:15:00",
        "riskLevel": "high",
        "description": "Высокий риск развития сердечно-сосудистых заболеваний",
        "riskFactors": [
          {
            "title": "Повышенное артериальное давление",
            "details": "Артериальное давление выше нормы повышает нагрузку на сердце и сосуды, увеличивая риск инфаркта и инсульта."
          }
        ],
        "recommendations": [
          {
            "title": "Консультация кардиолога",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": "completed",
      "interpretationDateTime": "2024-03-26T09:10:00",
      "systemCompletionPercentage": 85,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "interpretationStatus": "not enough data",
      "interpretationDateTime": null,
      "systemCompletionPercentage": 40,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

## Пример успешного ответа — пациент беременен

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": true,
  "completionPercentage": 100,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemInterpretationResults": [
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 4,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 5,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "interpretationStatus": null,
      "interpretationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```

## Пример неуспешного ответа

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```