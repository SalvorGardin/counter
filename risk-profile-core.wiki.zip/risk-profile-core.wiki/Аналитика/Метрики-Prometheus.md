---
title: Метрики Prometheus
---
# 1. Описание

Сервис `risk-profile-core` отдаёт метрики мониторинга в формате Prometheus text. Метрики описывают входящий HTTP-трафик, ошибки, лаг очереди пересчёта, потребление CPU и памяти и версию сервиса. В выдаче нет персональных данных — только агрегаты и шаблоны роутов.

Все метрики имеют префикс `risk_profile_core_`. В разделах 5 и 8 метрики упоминаются без префикса.

# 2. Область охвата

В текущей реализации метрики отдаёт только процесс `app` (FastAPI, uvicorn, 4 воркера).

Процесс `consumer` собственной ручки `/metrics` не имеет. Поэтому в выдаче отсутствуют:

* время расчётов;
* разрез по калькуляторам;
* запросы во внешний сервис `risk-profile-cvd`;
* ошибки модулей процесса `consumer` (например, `cvd_client`).

Лаг очереди пересчёта в выдаче есть: он опрашивается со стороны `app` через Kafka admin API.

# 3. Сбор метрик

## 3.1. Ручка

```http
GET /metrics
```

Ручка открыта на порту приложения, авторизация не требуется.

Рекомендуемый `scrape_interval` — 15 с.

## 3.2. Скрейп-конфиг Prometheus

```yaml
scrape_configs:
  - job_name: risk-profile-core
    scrape_interval: 15s
    static_configs:
      - targets: [ "<host>:<port>" ]
```

## 3.3. Агрегация по процессам

Метрики отдаются с позиции сервиса, без разбивки по внутренним процессам:

* счётчики всех uvicorn-воркеров суммируются в единые ряды (multiprocess-режим `prometheus_client`), лейбла `pid` нет;
* CPU и память — сумма по мастеру и всем воркерам.

Когда появятся метрики процесса `consumer`, таргеты будут различаться лейблом Prometheus `instance`.

## 3.4. Отключение ручки

Если настройка `RISK_MODEL_METRICS__ENABLED = false`, то `GET /metrics` возвращает `404 Not Found`. Сбор метрик при этом продолжается, поэтому после повторного включения в истории счётчиков нет разрыва.

# 4. Перечень метрик

| Метрика | Тип | Лейблы | Описание |
|---------|-----|--------|----------|
| `risk_profile_core_http_request_duration_seconds` | Histogram | `method`, `path`, `status`, `host` | Латентность входящих HTTP-запросов, секунды. Бакеты — дефолтные `prometheus_client` (0,005–10 с). `_count` — число запросов, `_sum` — суммарное время. Доля ошибок считается по лейблу `status` |
| `risk_profile_core_errors_total` | Counter | `level`, `component` | Число лог-записей уровня ERROR и выше. Учитывает и сбои после отданного ответа (например, ошибку фоновой отправки сообщения в Kafka при ответе `200 OK`) |
| `risk_profile_core_recalc_queue_lag` | Gauge | `topic`, `partition` | Лаг очереди пересчёта по партиции: `end_offset − committed_offset` группы `risk-recalc-workers` на топике `risk-profile.recalc-commands`. Значение на момент скрейпа, кэш 10 с. Присутствует только при включённой Kafka |
| `risk_profile_core_recalc_queue_lag_ok` | Gauge | — | Результат опроса лага: `1` — опрос успешен, `0` — ошибка или таймаут опроса. Присутствует только при включённой Kafka |
| `risk_profile_core_process_cpu_seconds_total` | Counter | — | Суммарное CPU-время (utime + stime) uvicorn-мастера и всех воркеров, секунды. Только Linux |
| `risk_profile_core_process_resident_memory_bytes` | Gauge | — | Суммарный RSS uvicorn-мастера и всех воркеров, байты. Только Linux |
| `risk_profile_core_process_count` | Gauge | — | Число процессов сервиса (мастер + воркеры). Снижение значения означает падение воркера. Только Linux |
| `risk_profile_core_build_info` | Gauge | `version` | Константа `1`. Лейбл `version` — версия сервиса из `version.json`. Используется для аннотаций деплоев в Grafana |

# 5. Значения лейблов

| Лейбл | Метрика | Значения |
|-------|---------|----------|
| `path` | `http_request_duration_seconds` | Шаблон роута, а не фактический URL: `/api/v1/testing/patients/{patient_id}`, а не `/api/v1/testing/patients/abc-123`.<br>Если путь не сопоставлен ни с одним роутом — `unmatched`.<br>Статика опросника (`/questionnaire/*`) — `/questionnaire`.<br>Скрытые служебные роуты — `other` |
| `method` | `http_request_duration_seconds` | `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, `OPTIONS`. Любой другой метод — `other` |
| `status` | `http_request_duration_seconds` | HTTP-код строкой: `"200"`, `"401"`, `"404"`. Если запрос завершился необработанным исключением — `"500"` |
| `host` | `http_request_duration_seconds` | Hostname контейнера сервиса. Не заголовок `Host` запроса |
| `level` | `errors_total` | `error`, `critical`, `alert`, `emergency` |
| `component` | `errors_total` | Имя модуля процесса `app`, записавшего лог-запись (например, `producer`, `main`) |
| `topic` | `recalc_queue_lag` | Имя топика очереди пересчёта |
| `partition` | `recalc_queue_lag` | Номер партиции строкой |
| `version` | `build_info` | Версия сервиса |

За счёт шаблонов в `path` число рядов гистограммы ограничено числом роутов сервиса и не зависит от URL, по которым обращаются клиенты.

В гистограмму `http_request_duration_seconds` не попадают запросы к пробам (`/`, `/health`, `/readiness`, `/liveness`) и к самой ручке `/metrics`.

# 6. Примеры PromQL

## 6.1. RPS

Общий:

```promql
sum(rate(risk_profile_core_http_request_duration_seconds_count[5m]))
```

По роуту:

```promql
sum by (path) (rate(risk_profile_core_http_request_duration_seconds_count[5m]))
```

## 6.2. Латентность p95

```promql
histogram_quantile(0.95, sum by (le) (rate(risk_profile_core_http_request_duration_seconds_bucket[5m])))
```

## 6.3. Ошибки

Доля ответов 5xx:

```promql
sum(rate(risk_profile_core_http_request_duration_seconds_count{status=~"5.."}[5m]))
  / sum(rate(risk_profile_core_http_request_duration_seconds_count[5m]))
```

Интенсивность лог-записей уровня ERROR и выше, в том числе сбоев после отданного ответа:

```promql
sum(rate(risk_profile_core_errors_total[5m]))
```

## 6.4. Очередь пересчёта

```promql
sum(risk_profile_core_recalc_queue_lag)                 # общий лаг очереди
max(risk_profile_core_recalc_queue_lag)                 # максимальный лаг по партиции
count(risk_profile_core_recalc_queue_lag > 0)           # число отстающих партиций
min(risk_profile_core_recalc_queue_lag_ok)              # 0 — опрос лага не удаётся
```

## 6.5. CPU и память

```promql
rate(risk_profile_core_process_cpu_seconds_total[5m])   # потребление CPU, ядер, в среднем за окно
risk_profile_core_process_resident_memory_bytes         # суммарный RSS сервиса
risk_profile_core_process_count                         # ожидается число воркеров + 1 (мастер)
```

# 7. Пример выдачи

Фрагмент ответа `GET /metrics`:

```text
# TYPE risk_profile_core_http_request_duration_seconds histogram
risk_profile_core_http_request_duration_seconds_count{host="app-7c9d",method="GET",path="/api/v1/testing/patients/{patient_id}",status="200"} 42.0
risk_profile_core_http_request_duration_seconds_count{host="app-7c9d",method="GET",path="unmatched",status="404"} 3.0
# TYPE risk_profile_core_errors_total counter
risk_profile_core_errors_total{component="producer",level="error"} 2.0
# TYPE risk_profile_core_recalc_queue_lag gauge
risk_profile_core_recalc_queue_lag{partition="0",topic="risk-profile.recalc-commands"} 12.0
risk_profile_core_recalc_queue_lag_ok 1.0
# TYPE risk_profile_core_process_cpu_seconds_total counter
risk_profile_core_process_cpu_seconds_total 137.4
risk_profile_core_process_resident_memory_bytes 5.28482304e+08
risk_profile_core_process_count 5.0
# TYPE risk_profile_core_build_info gauge
risk_profile_core_build_info{version="0.7.0"} 1.0
```

# 8. Эксплуатационные заметки

## 8.1. Рестарт контейнера

Счётчики обнуляются при рестарте контейнера. Это штатный counter reset: функции `rate()` и `increase()` его обрабатывают.

## 8.2. Падение воркера

`process_cpu_seconds_total` — сумма по живым процессам. Если воркер падает, его накопленное CPU-время выпадает из суммы, и Prometheus фиксирует counter reset в тот же момент, когда снижается `process_count`. `rate()` сглаживает сброс, но на графике возможен артефакт-всплеск.

## 8.3. Multiprocess-директория

Multiprocess-режим хранит данные в директории `/tmp/prometheus-multiproc` (задаётся сервису `app` в `docker-compose.yml`). Директория очищается при старте контейнера. Если воркер уходит в крашлуп, директория растёт в пределах единиц МБ и очищается при следующем рестарте; сам крашлуп виден по `process_count`.

## 8.4. Опрос лага очереди

Лаг опрашивается при скрейпе `/metrics`: одновременно выполняется не более одного опроса, результат кэшируется на 10 с, таймаут опроса — 2 с.

Если Kafka недоступна:

* `recalc_queue_lag_ok = 0`;
* ряды `recalc_queue_lag` отсутствуют;
* `errors_total` не растёт — ошибка опроса логируется с уровнем WARNING.

## 8.5. Ограничение доступа к ручке

Ручка `/metrics` открыта без авторизации (см. раздел 3.1). В качестве компенсирующей меры рекомендуется ограничить доступ к ней на уровне сети: firewall или bind на внутренний интерфейс с доступом только с IP Prometheus.

Скрейпы не оставляют записей в логах `app`: ручка `/metrics` исключена из логирования наравне с пробами.
