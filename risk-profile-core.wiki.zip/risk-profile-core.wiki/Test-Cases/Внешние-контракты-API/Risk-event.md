---
title: Risk-event API
---
# API Risk-event

## Краткое описание

Проверка API `POST /v1/clients/{clientId}/medical-risk/events/{eventType}` на валидацию path/query параметров, успешное принятие событий по примерам со страницы и корректные коды ответов `202`, `400`, `404`, `409`, `500`.

## Тестовые данные

| Поле | Значение |
|------|----------|
| Endpoint | `/v1/clients/{clientId}/medical-risk/events/{eventType}` |
| Method | `POST` |
| Headers | `Authorization`, `Content-Type: application/json` |
| Path params | `clientId`, `eventType` |
| Query params | `systemCode` |
| Request body | отсутствует |

## Тест-кейсы

<table>
<tr>
<th>Номер тест-кейса</th>
<th>Название тест-кейса</th>
<th>Предусловие</th>
<th>Шаги</th>
<th>Ожидаемый результат</th>
<th>Результат тест-прогона</th>
</tr>
<tr>
<td>API-01</td>
<td>Позитивный. Пример события risk-calculation</td>
<td>Клиент существует</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/risk-calculation`
</td>
<td>

Получен ответ `202 Accepted`.<br>`isSuccess = true`, `error = null`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-02</td>
<td>Позитивный. Пример события pregnancy-end</td>
<td>Клиент существует</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/pregnancy-end`
</td>
<td>

Получен ответ `202 Accepted`.<br>`isSuccess = true`, `error = null`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-03</td>
<td>Позитивный. Пример события answers-reset</td>
<td>

Клиент существует, передан хотя бы один `systemCode`
</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/answers-reset?systemCode=MENTAL&systemCode=CVD`
</td>
<td>

Получен ответ `202 Accepted`.<br>`isSuccess = true`, `error = null`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-04</td>
<td>Позитивный. clientId: минимальное количество символов</td>
<td>

Используются допустимые значения `clientId`
</td>
<td>

Вызвать метод с `clientId` длиной 5 символов;<br>`clientId` содержит только допустимые символы: буквы, цифры, дефис, подчёркивание.
</td>
<td>

Получен ответ `202 Accepted`.<br>`clientId` принимается на минимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-05</td>
<td>Позитивный. clientId: максимальное количество символов</td>
<td>

Используются допустимые значения `clientId`
</td>
<td>

Вызвать метод с `clientId` длиной 36 символов;<br>`clientId` содержит только допустимые символы: буквы, цифры, дефис, подчёркивание.
</td>
<td>

Получен ответ `202 Accepted`.<br>`clientId` принимается на максимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-06</td>
<td>Позитивный. eventType = risk-calculation</td>
<td>Клиент существует</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/risk-calculation`
</td>
<td>

Получен ответ `202 Accepted`.<br>`eventType` принимается успешно.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-07</td>
<td>Позитивный. eventType = pregnancy-end</td>
<td>Клиент существует</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/pregnancy-end`
</td>
<td>

Получен ответ `202 Accepted`.<br>`eventType` принимается успешно.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-08</td>
<td>Позитивный. eventType = answers-reset</td>
<td>

Клиент существует, передан хотя бы один `systemCode`
</td>
<td>

Вызвать `POST /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk/events/answers-reset?systemCode=MENTAL&systemCode=CVD`
</td>
<td>

Получен ответ `202 Accepted`.<br>`eventType` принимается успешно.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-09</td>
<td>Позитивный. systemCode: минимальное количество символов</td>
<td>

Используется событие `answers-reset`
</td>
<td>

Вызвать метод с `systemCode` длиной 3 символа;<br>`systemCode` содержит только допустимые символы: буквы, цифры, дефис, подчёркивание.
</td>
<td>

Получен ответ `202 Accepted`.<br>`systemCode` принимается на минимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-10</td>
<td>Позитивный. systemCode: максимальное количество символов</td>
<td>

Используется событие `answers-reset`
</td>
<td>

Вызвать метод с `systemCode` длиной 36 символов;<br>`systemCode` содержит только допустимые символы: буквы, цифры, дефис, подчёркивание.
</td>
<td>

Получен ответ `202 Accepted`.<br>`systemCode` принимается на максимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-11</td>
<td>Позитивный. Отсутствует body</td>
<td>Метод вызван для любого допустимого события</td>
<td>Вызвать метод без body</td>
<td>

Получен ответ `202 Accepted`.<br>Запрос успешно принят без body.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-12</td>
<td>Негативный. clientId короче минимальной длины</td>
<td>

В запрос передан `clientId` длиной меньше 5 символов
</td>
<td>

Вызвать метод с `clientId` длиной 4 символа
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за нарушения минимальной длины `clientId`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-13</td>
<td>Негативный. clientId длиннее максимальной длины</td>
<td>

В запрос передан `clientId` длиной больше 36 символов
</td>
<td>

Вызвать метод с `clientId` длиной 37 символов
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за превышения максимальной длины `clientId`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-14</td>
<td>Негативный. clientId содержит недопустимый символ</td>
<td>

В запрос передан `clientId` с недопустимым символом
</td>
<td>

Вызвать метод с `clientId`, содержащим пробел и спецсимвол
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого символа в `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-15</td>
<td>Негативный. Ошибка в параметре clientId</td>
<td>

Указать `clientId` с ошибкой
</td>
<td>

Вызвать метод в запросе, где в path указан `clientId` с ошибкой в названии
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за ошибки в параметре `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-16</td>
<td>Негативный. Недопустимый eventType</td>
<td>

В запрос передан неизвестный `eventType`
</td>
<td>

Вызвать метод с `eventType`, не входящим в набор допустимых значений
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого `eventType`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_EVENT_TYPE",
    "message": "Недопустимый тип события. Допустимые значения: risk-calculation, pregnancy-end, answers-reset."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-17</td>
<td>Негативный. eventType содержит недопустимый символ</td>
<td>

В запрос передан `eventType` с недопустимым символом
</td>
<td>

Вызвать метод с `eventType`, содержащим пробел и спецсимвол
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого символа в `eventType`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-18</td>
<td>Негативный. answers-reset без systemCode</td>
<td>

Вызвано событие `answers-reset`
</td>
<td>

Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset` без query-параметра `systemCode`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за отсутствия обязательного `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-19</td>
<td>Негативный. systemCode короче минимальной длины</td>
<td>

В запросе `answers-reset` передан `systemCode` длиной меньше 3 символов
</td>
<td>

Вызвать метод с `systemCode` длиной 2 символа
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за нарушения минимальной длины `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-20</td>
<td>Негативный. systemCode длиннее максимальной длины</td>
<td>

В запросе `answers-reset` передан `systemCode` длиной больше 36 символов
</td>
<td>

Вызвать метод с `systemCode` длиной 37 символов
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за превышения максимальной длины `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-21</td>
<td>Негативный. systemCode содержит недопустимый символ</td>
<td>

В запросе `answers-reset` передан `systemCode` с недопустимым символом
</td>
<td>

Вызвать метод с `systemCode`, содержащим пробел и спецсимвол
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого символа в `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-22</td>
<td>Негативный. Ошибка в параметре systemCode</td>
<td>

Указать `systemCode` с ошибкой
</td>
<td>

Вызвать метод в запросе, где query-параметр указан как `systemCod`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за ошибки в параметре `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-23</td>
<td>Негативный. clientId передан с не корректным типом данных</td>
<td>

Указать числовое значение вместо строки в `clientId`
</td>
<td>

Вызвать метод с `clientId = 12345`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не корректного типа данных в `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-24</td>
<td>Негативный. eventType передан с не корректным типом данных</td>
<td>

Указать числовое значение вместо строки в `eventType`
</td>
<td>

Вызвать метод с `eventType = 123`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не корректного типа данных в `eventType`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-25</td>
<td>Негативный. systemCode передан с не корректным типом данных</td>
<td>

Указать числовое значение вместо строки в `systemCode`
</td>
<td>

Вызвать метод с `systemCode = 123`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не корректного типа данных в `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-26</td>
<td>Негативный. NULL в clientId</td>
<td>

Указать `NULL` в `clientId`
</td>
<td>

Вызвать метод с `clientId = NULL`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за `NULL` в `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-27</td>
<td>Негативный. NULL в eventType</td>
<td>

Указать `NULL` в `eventType`
</td>
<td>

Вызвать метод с `eventType = NULL`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за `NULL` в `eventType`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-28</td>
<td>Негативный. NULL в systemCode</td>
<td>

Указать `NULL` в `systemCode`
</td>
<td>

Вызвать метод с `systemCode = NULL`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за `NULL` в `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-29</td>
<td>Негативный. Ошибка в методе</td>
<td>

Указать метод `GET` вместо `POST`
</td>
<td>Вызвать метод с корректно заполненными данными</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не валидного метода.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-30</td>
<td>Негативный. Клиент не найден</td>
<td>

Клиент с указанным `clientId` отсутствует в БД
</td>
<td>

Вызвать метод с несуществующим `clientId`
</td>
<td>

Получен ответ `404 Not Found`.<br>Возвращён код ошибки клиента не найден.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "CLIENT_NOT_FOUND",
    "message": "Клиент с указанным идентификатором не найден."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-31</td>
<td>Негативный. Код системы организма не найден</td>
<td>

Вызвано событие `answers-reset`, один из `systemCode` отсутствует в справочнике
</td>
<td>

Вызвать метод с несуществующим `systemCode`
</td>
<td>

Получен ответ `404 Not Found`.<br>Возвращён код ошибки `SYSTEM_CODE_NOT_FOUND`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "SYSTEM_CODE_NOT_FOUND",
    "message": "Система организма с указанным кодом не найдена."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-32</td>
<td>Негативный. Конфликт активной обработки</td>
<td>Для клиента уже выполняется асинхронная обработка события</td>
<td>Повторно вызвать метод с валидным запросом, пока предыдущая обработка не завершена</td>
<td>

Получен ответ `409 Conflict`.<br>Запрос отклонён из-за активной обработки.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-33</td>
<td>Негативный. Внутренняя ошибка сервера</td>
<td>Эмулирована внутренняя ошибка на стороне сервиса</td>
<td>Вызвать метод с валидным запросом в условиях внутреннего сбоя</td>
<td>

Получен ответ `500 Internal Server Error`.<br>Возвращён корректный код ошибки сервера.
</td>
<td>pass</td>
</tr>
</table>

## Тест-кейсы по бизнес-логике Risk-event

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-01 | Позитивный | Принятие события `risk-calculation` для существующего пациента | В таблице `patients` есть запись с переданным `clientId`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/risk-calculation`. | Возвращается `202 Accepted`, `isSuccess = true`, `error = null`. Событие принято без изменения параметров пациента, так как пересчет риск-профиля инициируется автоматически при изменении параметров в БД. | pass |
| API-BL-02 | Позитивный | `pregnancy-end` снимает признак беременности | В таблице `patients` есть запись с переданным `clientId`, `patients.is_pregnant = true`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/pregnancy-end`. Проверить запись пациента в БД. | Возвращается `202 Accepted`, `isSuccess = true`, `error = null`. В таблице `patients` для пациента устанавливается `is_pregnant = false`. | pass |
| API-BL-03 | Позитивный | `pregnancy-end` архивирует и инвалидирует параметры систем CVD и ENDO | Пациент существует. В `patients_parameters` есть актуальные записи пациента с `parameter_code`, входящими в дедуплицированное множество параметров систем CVD и ENDO через связи `systems_instruments` -\> `instruments_parameters`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/pregnancy-end`. Проверить `patients_parameters` и `patients_parameters_history`. | Каждая отобранная запись скопирована в `patients_parameters_history`. В исходных записях `patients_parameters` установлено `expiration_date = CURRENT_DATE - 1`. Физического удаления записей не происходит. | pass |
| API-BL-04 | Позитивный | `pregnancy-end` дополнительно сбрасывает рост, вес и ИМТ | Пациент существует. В `patients_parameters` есть актуальные записи пациента с `parameter_code = height`, `weight`, `bmi`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/pregnancy-end`. Проверить `patients_parameters` и `patients_parameters_history` для `height`, `weight`, `bmi`. | Записи с `parameter_code = height`, `weight`, `bmi` скопированы в `patients_parameters_history`. В исходных записях установлено `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-05 | Позитивный | `answers-reset` сбрасывает параметры одной системы | Пациент существует. В справочнике `systems` есть переданный `systemCode`. В `patients_parameters` есть актуальные записи пациента с `parameter_code`, связанными с этой системой через `systems_instruments` -\> `instruments_parameters`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=<systemCode>`. Проверить `patients_parameters` и `patients_parameters_history`. | Возвращается `202 Accepted`, `isSuccess = true`, `error = null`. Все найденные параметры системы скопированы в `patients_parameters_history`, в `patients_parameters` для них установлено `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-06 | Позитивный | `answers-reset` объединяет и дедуплицирует параметры нескольких систем | Пациент существует. В справочнике `systems` есть все переданные `systemCode`. Несколько систем имеют пересекающиеся `parameter_code` через связанные инструменты. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=<systemCode1>&systemCode=<systemCode2>`. Проверить архивирование и инвалидацию пересекающихся параметров. | Множества `parameter_code` по всем переданным системам объединены и дедуплицированы. Для каждого уникального параметра пациента создается одна архивная запись в `patients_parameters_history`, исходная запись инвалидируется через `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-07 | Позитивный | `answers-reset` для CVD или ENDO дополнительно сбрасывает рост, вес и ИМТ | Пациент существует. В запросе `answers-reset` среди `systemCode` передан `CVD` и/или `ENDO`. В `patients_parameters` есть актуальные записи `height`, `weight`, `bmi`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=CVD` или `systemCode=ENDO`. Проверить `patients_parameters` и `patients_parameters_history` для `height`, `weight`, `bmi`. | Помимо параметров выбранной системы, записи `height`, `weight`, `bmi` скопированы в `patients_parameters_history`, а в `patients_parameters` для них установлено `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-08 | Позитивный | `answers-reset` снимает признак беременности у беременного пациента | Пациент существует. `patients.is_pregnant = true`. В справочнике `systems` есть переданный `systemCode`. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=<systemCode>`. Проверить запись пациента в БД. | Возвращается `202 Accepted`, `isSuccess = true`, `error = null`. В таблице `patients` устанавливается `is_pregnant = false`. | pass |
| API-BL-09 | Позитивный | `answers-reset` успешно выполняется, если по системе нет актуальных параметров пациента | Пациент существует. В справочнике `systems` есть переданный `systemCode`. По найденному множеству `parameter_code` в `patients_parameters` нет актуальных записей пациента. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=<systemCode>`. | Возвращается `202 Accepted`, `isSuccess = true`, `error = null`. Новые записи в `patients_parameters_history` не создаются, в `patients_parameters` нечего инвалидировать. | избыточно сейчас |

## Дополнительные тест-кейсы

> Добавлено по результатам сверки с актуальной аналитикой. Существующие тест-кейсы выше сохранены без изменений.

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-ADD-01 | Позитивный | `systemCode` длиной 2 символа принимается | Клиент существует. В справочнике `systems` есть код длиной 2 символа. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=<код_из_2_символов>`. | Получен `202 Accepted`, `isSuccess = true`, `error = null`. Значение принято на минимальной границе, указанной в аналитике. | pass |
| API-ADD-02 | Негативный | `systemCode` короче минимальной длины | Клиент существует. | Вызвать `answers-reset` с `systemCode` длиной 1 символ. | Получен `400 Bad Request`, `isSuccess = false`. Запрос отклонен из-за ограничения длины `systemCode` от 2 до 36 символов; изменения данных пациента отсутствуют. | pass |
| API-ADD-03 | Негативный | Пустое значение `systemCode` | Клиент существует. | Вызвать `POST /v1/clients/{clientId}/medical-risk/events/answers-reset?systemCode=`. | Получен `400 Bad Request`, `isSuccess = false`; пустое значение не считается переданным допустимым кодом, данные пациента не изменены. | pass |
| API-ADD-04 | Негативный | Точный ответ при отсутствии `systemCode` | Клиент существует. | Вызвать `answers-reset` без параметра `systemCode`. | Получен `400 Bad Request`; `isSuccess = false`, `error.code = SYSTEM_CODE_REQUIRED`, сообщение объясняет необходимость передать хотя бы один `systemCode`. | pass |
| API-ADD-05 | Позитивный | Повтор одного `systemCode` в query | Клиент существует. Код системы есть в справочнике, у пациента есть связанные параметры. | Вызвать `answers-reset?systemCode=CVD&systemCode=CVD`. Проверить историю и исходные параметры. | Получен `202 Accepted`. Результирующее множество параметров дедуплицировано: каждая отобранная запись архивирована и инвалидирована один раз. | pass |
| API-ADD-06 | Негативный | Один несуществующий код среди нескольких `systemCode` | Клиент существует. Первый код есть в `systems`, второй отсутствует. До запроса зафиксированы данные пациента. | Вызвать `answers-reset?systemCode=<существующий>&systemCode=<несуществующий>`. Сравнить данные до и после запроса. | Получен `404 Not Found`, `isSuccess = false`, `error.code = SYSTEM_CODE_NOT_FOUND`. Поскольку проверяются все коды до сброса, частичная архивация, инвалидация параметров и изменение `is_pregnant` не выполняются. | pass |
| API-ADD-07 | Негативный | Ограничения полей объекта ошибки | Подготовлены запросы, вызывающие ошибки `INVALID_EVENT_TYPE`, `INVALID_CLIENT_ID`, `CLIENT_NOT_FOUND`, `SYSTEM_CODE_REQUIRED`, `SYSTEM_CODE_NOT_FOUND`. | Выполнить каждый запрос и измерить длину `error.code` и `error.message`. | Для каждого ответа `isSuccess = false`; длина `error.code` не превышает 100 символов, `error.message` — 255 символов. | pass |
| API-BL-ADD-01 | Позитивный | `pregnancy-end` сохраняет все поля архивируемых записей | Пациент существует. Для CVD/ENDO и `height`, `weight`, `bmi` есть записи с заполненными полями и известным `date_time`. | Сохранить снимок записей, вызвать `pregnancy-end`, сравнить их с записями в `patients_parameters_history`. | Для каждой отобранной записи создана архивная копия со значениями всех полей исходной записи, включая неизменный `date_time`; в исходной записи `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-ADD-02 | Позитивный | `answers-reset` сохраняет все поля архивируемых записей | Пациент и система существуют. Связанные параметры имеют заполненные поля и известный `date_time`. | Сохранить снимок записей, вызвать `answers-reset`, сравнить их с записями в `patients_parameters_history`. | Архивные копии сохраняют все поля исходных записей, включая `date_time`; исходные записи не удалены и имеют `expiration_date = CURRENT_DATE - 1`. | pass |
| API-BL-ADD-03 | Позитивный | `pregnancy-end` дедуплицирует общие параметры CVD и ENDO | Пациент существует. CVD и ENDO через разные инструменты содержат общий `parameter_code`. | Вызвать `pregnancy-end`. Проверить историю по общему параметру. | Объединенное множество `parameter_code` дедуплицировано: исходная запись общего параметра инвалидирована один раз и для нее создана одна архивная копия. | pass |
| API-BL-ADD-04 | Позитивный | Параметры вне выбранных систем не изменяются | Пациент существует. Есть параметры выбранной для сброса системы и параметры другой системы, не связанные общими инструментами. | Вызвать `answers-reset` для выбранной системы. Проверить обе группы параметров. | Архивированы и инвалидированы только параметры результирующего множества выбранной системы. Параметры другой системы не изменены и не добавлены в историю. | pass |
| API-BL-ADD-05 | Позитивный | Данные другого пациента не изменяются | В БД есть два пациента с одинаковыми `parameter_code`; запрос отправляется для первого пациента. | Вызвать `pregnancy-end` или `answers-reset` для первого пациента и проверить записи второго. | Архивация и инвалидация ограничены найденным `patient_id`; записи второго пациента и его `is_pregnant` не изменены. | pass |
| API-BL-ADD-06 | Позитивный | Сброс системы, отличной от CVD и ENDO, не затрагивает рост, вес и ИМТ | Пациент существует. Передан валидный код системы, отличный от CVD и ENDO. Есть актуальные `height`, `weight`, `bmi`. | Вызвать `answers-reset` для этой системы. Проверить `height`, `weight`, `bmi` и историю. | Параметры выбранной системы сброшены. `height`, `weight`, `bmi` не архивированы и их `expiration_date` не изменена. | pass |
| API-BL-ADD-07 | Позитивный | После `answers-reset` вопросы по сброшенным параметрам задаются повторно | Пациент существует и ранее ответил на вопросы выбранной системы. | Вызвать `answers-reset`, затем обратиться к методу `risk-communication` для пациента. | Инвалидированные параметры квалифицированы как неотвеченные; `risk-communication` повторно возвращает соответствующие вопросы. | pass |
| API-BL-ADD-08 | Негативный | Несуществующий клиент не вызывает изменений в БД | Клиент с переданным `clientId` отсутствует. Зафиксировано состояние таблиц `patients_parameters` и `patients_parameters_history`. | Вызвать любое допустимое событие с несуществующим `clientId`, затем сравнить состояние таблиц. | Получен `404 Not Found`, `isSuccess = false`, `error.code = CLIENT_NOT_FOUND`; записи параметров, история и признаки беременности не изменены. | pass |

Вот тест-кейсы по задаче (Risk-communication, шаг 5 «Определение системы», MENTAL/COMMON) для v1 и v2.

## Позитивные сценарии

**TC-01. v1: systemCode=MENTAL, COMMON не отвечен → сразу bdi/stai** Предусловие: клиент прошёл Risk-init (birthDate указан), вопросы группы COMMON не отвечены. Шаги: `POST /v1/clients/{clientId}/questions/answers?questionCode=&systemCode=MENTAL` Ожидаемый результат: в ответе первым отдаётся вопрос из набора bdi/stai; вопросы cq_0xx (COMMON) не возвращаются и не блокируют выдачу. - pass

**TC-02. v2: systemCode=MENTAL, COMMON не отвечен → сразу bdi/stai** Аналогично TC-01, но `POST /v2/...`. Ожидаемый результат тот же: первый вопрос — bdi/stai, cq_0xx пропущены. - pass

**TC-03. v2: полное прохождение MENTAL завершается корректно** Предусловие: systemCode=MENTAL, COMMON не отвечен (пропущен по новой логике). Шаги: последовательно отвечать на все вопросы bdi/stai до конца опроса. Ожидаемый результат: в финальном ответе `question: null`, `systemCompletionPercentage: 100`. - pass

**TC-04. Калькуляторы bdi/stai считаются корректно для MENTAL-first клиента (v1)** Предусловие: birthDate передан на Risk-init, COMMON пропущен (не отвечен). Шаги: пройти MENTAL полностью через v1. Ожидаемый результат: расчёт по bdi/stai выполняется успешно, age берётся из Risk-init/birthDate; ошибок расчёта нет. - pass

**TC-05. Калькуляторы bdi/stai считаются корректно для MENTAL-first клиента (v2)** То же самое, но через v2. Ожидаемый результат аналогичен TC-04. - pass

**TC-06. v1: systemCode=MENTAL, но COMMON уже отвечен ранее** Предусловие: клиент ранее ответил на COMMON, затем обращается с systemCode=MENTAL. Ожидаемый результат: поведение не хуже текущего — сразу выдаются вопросы MENTAL (регресса нет, COMMON повторно не запрашивается). - pass

**TC-07. v2: systemCode=MENTAL, COMMON уже отвечен ранее** Аналогично TC-06 для v2. - pass

## Негативные / регрессионные сценарии

**TC-08. v1: systemCode не передан, COMMON не отвечен → как и раньше выдаётся COMMON** Шаги: `POST /v1/clients/{clientId}/questions/answers?questionCode=` (без systemCode). Ожидаемый результат: первым отдаётся вопрос cq_0xx (COMMON), а не bdi/stai. Регресс не допущен. - pass

**TC-09. v2: systemCode не передан, COMMON не отвечен → как и раньше выдаётся COMMON** Аналогично TC-08 для v2. - pass

**TC-10. v1: systemCode=CVD, COMMON не отвечен → выдаётся COMMON** Шаги: `POST /v1/...?systemCode=CVD`. Ожидаемый результат: первым по-прежнему cq_0xx (COMMON), логика для не-MENTAL систем не изменилась. - pass

**TC-11. v2: systemCode=CVD, COMMON не отвечен → выдаётся COMMON** Аналогично TC-10 для v2. - pass

**TC-12. v1: завершение опроса MENTAL — поведение не меняется (баг #132)** Предусловие: systemCode=MENTAL передан явно, опрос завершён. Ожидаемый результат: воспроизводится прежнее (известное, "багованное") поведение завершения — как до правки; новых регрессий сверх известного бага #132 не появилось. Это не является дефектом в рамках текущей задачи. - pass

**TC-15. systemCode=MENTAL, но birthDate не был передан на Risk-init** Предусловие: клиент не прошёл Risk-init с обязательным birthDate (граничный/аномальный случай, если такое вообще возможно по системе). Ожидаемый результат: либо запрос на Risk-init блокируется раньше (birthDate обязателен), либо, если это состояние достижимо, — корректная обработка ошибки при расчёте age для bdi/stai (без падения сервиса). Нужно проверить, что MENTAL-логика не пытается расчитать age из отсутствующих данных без валидации.

**TC-16. v1 и v2 — сравнение первого вопроса при одинаковых входных данных (MENTAL)** Шаги: для одного и того же клиента (или двух идентичных по состоянию клиентов) вызвать v1 и v2 с systemCode=MENTAL. Ожидаемый результат: логика выбора первого вопроса идентична — в обеих версиях первым отдаётся bdi/stai, COMMON пропущен одинаково в обеих версиях. - pass

**TC-17. Повторный вызов с systemCode=MENTAL после ответа на один из вопросов bdi/stai** Шаги: ответить на первый вопрос bdi/stai, затем снова вызвать с тем же systemCode=MENTAL. Ожидаемый результат: выдаётся следующий неотвеченный вопрос bdi/stai, COMMON по-прежнему не появляется, `systemCompletionPercentage` увеличивается корректно. - pass

---

:warning: Так как приложенный файл контрактов был пустым, у меня нет точных схем ответа API (структура question, полей systemCompletionPercentage и т.д.), поэтому в TC-01–TC-05, TC-16 проверки строятся на уровне бизнес-логики, а не точного JSON-контракта. Если пришлёте файл контрактов, добавлю точные проверки полей и кодов ответа (200/400 и т.п.).