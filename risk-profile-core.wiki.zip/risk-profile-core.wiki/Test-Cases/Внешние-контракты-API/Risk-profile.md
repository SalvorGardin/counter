---
title: Risk-profile API
---
# API Risk-profile

## Краткое описание

Проверка API `GET /v1/clients/{clientId}/medical-risk` на валидацию path/query параметров, успешное получение ответа по примерам со страницы и корректные коды ответов `200`, `400`, `404`, `500`.

## Тестовые данные

| Поле | Значение |
|------|----------|
| Endpoint | `/v1/clients/{clientId}/medical-risk` |
| Method | `GET` |
| Headers | `Authorization` |
| Path params | `clientId` |
| Query params | `systemCode` |
| Request body | отсутствует |

## Тест-кейсы

<table>
<tr>
<th>Номер тест-кейса</th>
<th>Название тест-кейса</th>
<th>Предусловие</th>
<th>Шаги</th>
<th>Ожидаемый результат</th>
<th>Результат тестового прогона</th>
</tr>
<tr>
<td>API-01</td>
<td>Позитивный. Пример запроса со страницы с systemCode</td>
<td>Клиент существует</td>
<td>

Вызвать `GET /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk?systemCode=MENTAL`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.<br>Возвращён корректный JSON-ответ со списком рисков по переданной системе.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-02</td>
<td>Позитивный. Пример запроса без systemCode</td>
<td>Клиент существует</td>
<td>

Вызвать `GET /v1/clients/123e4567-e89b-12d3-a456-426614174000/medical-risk`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.<br>Возвращён корректный JSON-ответ со списком рисков по всем системам.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-03</td>
<td>Позитивный. clientId минимальной длины</td>
<td>

Используется допустимое значение `clientId`
</td>
<td>

Вызвать метод с `clientId` длиной 5 символов
</td>
<td>

Получен ответ `200 OK`.<br>`clientId` принимается на минимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-04</td>
<td>Позитивный. clientId максимальной длины</td>
<td>

Используется допустимое значение `clientId`
</td>
<td>

Вызвать метод с `clientId` длиной 36 символов
</td>
<td>

Получен ответ `200 OK`.<br>`clientId` принимается на максимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-05</td>
<td>Позитивный. Допустимые символы clientId</td>
<td>

Используется допустимое значение `clientId`
</td>
<td>

Вызвать метод с `clientId`, содержащим только буквы, цифры, дефис и подчёркивание
</td>
<td>

Получен ответ `200 OK`.<br>`clientId` принимается с допустимыми символами.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-06</td>
<td>Позитивный. systemCode минимальной длины</td>
<td>

В запрос передан `systemCode`
</td>
<td>

Вызвать метод с `systemCode` длиной 3 символа
</td>
<td>

Получен ответ `200 OK`.<br>`systemCode` принимается на минимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-07</td>
<td>Позитивный. systemCode максимальной длины</td>
<td>

В запрос передан `systemCode`
</td>
<td>

Вызвать метод с `systemCode` длиной 36 символов
</td>
<td>

Получен ответ `200 OK`.<br>`systemCode` принимается на максимальной границе допустимой длины.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-08</td>
<td>Позитивный. Допустимые символы systemCode</td>
<td>

В запрос передан `systemCode`
</td>
<td>

Вызвать метод с `systemCode`, содержащим только буквы, цифры, дефис и подчёркивание
</td>
<td>

Получен ответ `200 OK`.<br>`systemCode` принимается с допустимыми символами.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-09</td>
<td>Позитивный. Структура успешного ответа</td>
<td>Клиент существует, запрос валиден</td>
<td>

Вызвать метод с валидным `clientId` и, при необходимости, `systemCode`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.<br>В ответе присутствуют поля `completionPercentage`, `topRecommendations` и `systemCalculationResults`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-10</td>
<td>Позитивный. Структура успешного ответа с просчитанными системами</td>
<td>Клиент существует, запрос валиден</td>
<td>

Вызвать метод с валидным `clientId` и, при необходимости, `systemCode`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.

Структура ответа следующая:

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 62,
  "lastCalculationDateTime": "2024-03-25T10:30:00",
  "lastInterpretationDateTime": "2024-03-26T09:15:00",
  "topRecommendations": [
    {
      "title": "Консультация кардиолога",
      "details": null
    },
    {
      "title": "Консультация психотерапевта",
      "details": null
    }
  ],
  "systemCalculationResults": [
    {
      "systemCode": "COMMON",
      "systemName": "Общие вопросы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 75,
      "systemPriority": 0,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "calculationStatus": "completed",
      "calculationDateTime": "2024-03-25T10:00:00",
      "systemCompletionPercentage": 90,
      "systemPriority": 1,
      "doctorSpecializations": [
        {
          "name": "Кардиолог",
          "code": "cardiology"
        }
      ],
      "diseaseRisks": [
        { "name": "Ишемическая болезнь сердца" },
        { "name": "Артериальная гипертензия" }
      ],
      "risk": {
        "calculationDateTime": "2024-03-25T10:00:00",
        "riskLevel": "high",
        "description": "Высокий риск развития сердечно-сосудистых заболеваний на основании выявленных факторов",
        "riskFactors": [
          {
            "title": "Повышенное артериальное давление",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Консультация кардиолога",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 40,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "calculationStatus": "completed",
      "calculationDateTime": "2024-03-25T10:05:00",
      "systemCompletionPercentage": 95,
      "systemPriority": 3,
      "doctorSpecializations": [
        {
          "name": "Эндокринолог",
          "code": "endocrinology"
        }
      ],
      "diseaseRisks": [
        { "name": "Сахарный диабет 2 типа" }
      ],
      "risk": {
        "calculationDateTime": "2024-03-25T10:05:00",
        "riskLevel": "medium",
        "description": "Умеренный риск развития эндокринных нарушений на основании выявленных факторов",
        "riskFactors": [
          {
            "title": "Избыточный вес",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Контроль уровня глюкозы",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "calculationStatus": "completed",
      "calculationDateTime": "2024-03-25T10:15:00",
      "systemCompletionPercentage": 85,
      "systemPriority": 4,
      "doctorSpecializations": [
        {
          "name": "Пульмонолог",
          "code": "pulmonology"
        }
      ],
      "diseaseRisks": [
        { "name": "Хроническая обструктивная болезнь лёгких" }
      ],
      "risk": {
        "calculationDateTime": "2024-03-25T10:15:00",
        "riskLevel": "low",
        "description": "Низкий риск развития заболеваний дыхательной системы",
        "riskFactors": [
          {
            "title": "Курение в анамнезе",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Ежегодная флюорография",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "calculationStatus": "completed",
      "calculationDateTime": "2024-03-25T10:10:00",
      "systemCompletionPercentage": 80,
      "systemPriority": 5,
      "doctorSpecializations": [
        {
          "name": "Психотерапевт",
          "code": "psychiatry"
        }
      ],
      "diseaseRisks": [
        { "name": "Тревожное расстройство" },
        { "name": "Депрессивный эпизод" }
      ],
      "risk": {
        "calculationDateTime": "2024-03-25T10:10:00",
        "riskLevel": "high",
        "description": "Повышенный риск развития тревожного расстройства на основе выявленных факторов",
        "riskFactors": [
          {
            "title": "Хронический стресс",
            "details": null
          }
        ],
        "recommendations": [
          {
            "title": "Консультация психотерапевта",
            "details": null
          }
        ]
      }
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 10,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 35,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 50,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 20,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 30,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 45,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 25,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 15,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-11</td>
<td>Позитивный. Структура успешного ответа с не просчитанными системами</td>
<td>Клиент существует, запрос валиден</td>
<td>

Вызвать метод с валидным `clientId` и, при необходимости, `systemCode`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.

Структура ответа следующая:

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": false,
  "completionPercentage": 0,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemCalculationResults": [
    {
      "systemCode": "COMMON",
      "systemName": "Общие вопросы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 0,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 4,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 5,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "calculationStatus": "not enough data",
      "calculationDateTime": null,
      "systemCompletionPercentage": 0,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-12</td>
<td>Позитивный. Структура успешного ответа, когда пациентка беременна</td>
<td>Клиент существует, запрос валиден</td>
<td>

Вызвать метод с валидным `clientId` и, при необходимости, `systemCode`
</td>
<td>

Получен ответ `200 OK`.<br>`isSuccess = true`, `error = null`.

Структура ответа следующая:

```json
{
  "isSuccess": true,
  "error": null,
  "isPregnant": true,
  "completionPercentage": 100,
  "lastCalculationDateTime": null,
  "lastInterpretationDateTime": null,
  "topRecommendations": null,
  "systemCalculationResults": [
    {
      "systemCode": "COMMON",
      "systemName": "Общие вопросы",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 0,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "CVD",
      "systemName": "Сердце и сосуды",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 1,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ONCO",
      "systemName": "Онкориски",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 2,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "ENDO",
      "systemName": "Обмен веществ и гормоны",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 3,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "RESP",
      "systemName": "Дыхание",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 4,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "MENTAL",
      "systemName": "Ментальное здоровье",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 5,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "REPROD",
      "systemName": "Женское/Мужское здоровье",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 6,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "GI",
      "systemName": "Пищеварение",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 7,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "NEURO",
      "systemName": "Головной мозг и нервы",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 8,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "URO",
      "systemName": "Почки и выделительная система",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 9,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "TRAUMA",
      "systemName": "Спина, мышцы и суставы",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 10,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "BLOOD",
      "systemName": "Кровь и иммунитет",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 11,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SENSE",
      "systemName": "Зрение и слух",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 12,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    },
    {
      "systemCode": "SKIN",
      "systemName": "Кожа",
      "calculationStatus": null,
      "calculationDateTime": null,
      "systemCompletionPercentage": 100,
      "systemPriority": 13,
      "doctorSpecializations": null,
      "diseaseRisks": null,
      "risk": null
    }
  ]
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-13</td>
<td>Негативный. clientId короче минимальной длины</td>
<td>

В запрос передан `clientId` длиной меньше 5 символов
</td>
<td>

Вызвать метод с `clientId` длиной 4 символа
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за нарушения минимальной длины `clientId`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-14</td>
<td>Негативный. clientId длиннее максимальной длины</td>
<td>

В запрос передан `clientId` длиной больше 36 символов
</td>
<td>

Вызвать метод с `clientId` длиной 37 символов
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за превышения максимальной длины `clientId`.

Пример ответа:

```json
{
  "isSuccess": false,
  "error": {
    "code": "INVALID_CLIENT_ID",
    "message": "Идентификатор клиента должен содержать от 5 до 36 символов."
  }
}
```
</td>
<td>pass</td>
</tr>
<tr>
<td>API-15</td>
<td>Негативный. clientId содержит недопустимый символ</td>
<td>

В запрос передан `clientId` с недопустимым символом
</td>
<td>

Вызвать метод с `clientId`, содержащим пробел или спецсимвол
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого символа в `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-16</td>
<td>Негативный. Ошибка в параметре clientId</td>
<td>

Указать `clientId` с ошибкой
</td>
<td>

Вызвать метод в запросе, где в path указан `clientId` с ошибкой в названии
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за ошибки в параметре `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-17</td>
<td>Негативный. systemCode короче минимальной длины</td>
<td>

В запрос передан `systemCode` длиной меньше 3 символов
</td>
<td>

Вызвать метод с `systemCode` длиной 2 символа
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за нарушения минимальной длины `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-18</td>
<td>Негативный. systemCode длиннее максимальной длины</td>
<td>

В запрос передан `systemCode` длиной больше 36 символов
</td>
<td>

Вызвать метод с `systemCode` длиной 37 символов
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за превышения максимальной длины `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-19</td>
<td>Негативный. systemCode содержит недопустимый символ</td>
<td>

В запрос передан `systemCode` с недопустимым символом
</td>
<td>

Вызвать метод с `systemCode`, содержащим пробел и спецсимвол
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за недопустимого символа в `systemCode`.
</td>
<td>not pass, bug</td>
</tr>
<tr>
<td>API-20</td>
<td>Негативный. Ошибка в параметре systemCode</td>
<td>

Указать `systemCode` с ошибкой
</td>
<td>

Вызвать метод в запросе, где query-параметр указан как `systemCod`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за ошибки в параметре `systemCode`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-21</td>
<td>Негативный. clientId передан с не корректным типом данных</td>
<td>

Указать числовое значение вместо строки в `clientId`
</td>
<td>

Вызвать метод с `clientId = 12345`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не корректного типа данных в `clientId`.
</td>
<td>избыточно</td>
</tr>
<tr>
<td>API-22</td>
<td>Негативный. systemCode передан с не корректным типом данных</td>
<td>

Указать числовое значение вместо строки в `systemCode`
</td>
<td>

Вызвать метод с `systemCode = 123`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не корректного типа данных в `systemCode`.
</td>
<td>not pass, bug</td>
</tr>
<tr>
<td>API-23</td>
<td>Негативный. NULL в clientId</td>
<td>

Указать `NULL` в `clientId`
</td>
<td>

Вызвать метод с `clientId = NULL`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за `NULL` в `clientId`.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-24</td>
<td>Негативный. NULL в systemCode</td>
<td>

Указать `NULL` в `systemCode`
</td>
<td>

Вызвать метод с `systemCode = NULL`
</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за `NULL` в `systemCode`.
</td>
<td>not pass, bug</td>
</tr>
<tr>
<td>API-25</td>
<td>Негативный. Ошибка в методе</td>
<td>

Указать метод `POST` вместо `GET`
</td>
<td>Вызвать метод с корректно заполненными данными</td>
<td>

Получен ответ `400 Bad Request`.<br>Запрос отклонён из-за не валидного метода.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-26</td>
<td>Негативный. Клиент не найден</td>
<td>

Клиент с указанным `clientId` отсутствует в БД
</td>
<td>

Вызвать метод с несуществующим `clientId`
</td>
<td>

Получен ответ `404 Not Found`.<br>Возвращён код ошибки клиента не найден.
</td>
<td>pass</td>
</tr>
<tr>
<td>API-27</td>
<td>Негативный. Внутренняя ошибка сервера</td>
<td>Эмулирована внутренняя ошибка на стороне сервиса</td>
<td>Вызвать метод с валидным запросом в условиях внутреннего сбоя</td>
<td>

Получен ответ `500 Internal Server Error`.<br>Возвращён корректный код ошибки сервера.
</td>
<td>не могу пока воспроизвести</td>
</tr>
</table>

## Тест-кейсы по бизнес-логике Risk-profile

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-01 | Позитивный | Получение риск-профиля по всем системам без `systemCode` | Пациент существует, `patients.is_pregnant = false`. В справочнике `systems` есть системы с разными `rang`, включая `COMMON`. | Вызвать `GET /v1/clients/{clientId}/medical-risk` без `systemCode`. | Возвращается `200 OK`, `isSuccess = true`, `error = null`. В `systemInterpretationResults` возвращаются все системы, кроме `COMMON`, в порядке возрастания `systems.rang`. Для каждой системы заполнены `systemCode`, `systemName`, `systemPriority`. | pass |
| API-BL-02 | Позитивный | Получение риск-профиля по одной системе | Пациент существует, `patients.is_pregnant = false`. В справочнике `systems` есть система с переданным `systemCode`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Возвращается `200 OK`, `isSuccess = true`, `error = null`. В `systemInterpretationResults` возвращается только система с переданным `systemCode`, если это не `COMMON`. | pass |
| API-BL-03 | Позитивный | Пациентка беременна: дальнейшая логика интерпретации не выполняется | Пациент существует, `patients.is_pregnant = true`. В справочнике `systems` есть несколько систем. | Вызвать `GET /v1/clients/{clientId}/medical-risk`. | Возвращается `isPregnant = true`, `completionPercentage = 100`, `lastCalculationDateTime = null`, `lastInterpretationDateTime = null`, `topRecommendations = null`. В `systemInterpretationResults` возвращаются все системы, кроме `COMMON`, с `systemCompletionPercentage = 100`; поля `interpretationStatus`, `interpretationDateTime`, `risk`, `doctorSpecializations`, `diseaseRisks` равны `null`. | pass |
| API-BL-04 | Позитивный | Пациентка беременна: фильтрация по `systemCode` | Пациент существует, `patients.is_pregnant = true`. В справочнике `systems` есть система с переданным `systemCode`, отличным от `COMMON`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Возвращается `isPregnant = true`, `completionPercentage = 100`. В `systemInterpretationResults` возвращается только переданная система с `systemCompletionPercentage = 100` и `null` в полях интерпретации и риска. | pass |
| API-BL-05 | Позитивный | Расчет процента заполненности системы | Пациент существует, `patients.is_pregnant = false`. Для системы и `COMMON` есть набор параметров через `systems_instruments` -\> `instruments_parameters`; часть параметров имеет актуальные записи в `patients_parameters`, часть связана с применимыми неотвеченными вопросами. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | `systemCompletionPercentage` рассчитывается как `floor(answered_params / (answered_params + remaining_applicable) * 100)`, где учитываются уникальные актуально отвеченные параметры системы и `COMMON`, а также применимые неотвеченные вопросы. | pass |
| API-BL-06 | Позитивный | Вопрос без условий учитывается как применимый | Пациент существует. Для параметра системы нет актуального значения в `patients_parameters`. Для связанного вопроса в `conditions` нет записей. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Вопрос включается в `remaining_applicable_set` и влияет на расчет `systemCompletionPercentage` и общего `completionPercentage`. | pass |
| API-BL-07 | Позитивный | Условие `except` исключает вопрос из применимых | Пациент существует. Для вопроса есть `conditions.type = except`. По `previous_option_code` найдена опция, и актуальное значение пациента по `options.parameter_code` совпадает с `options.value`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Вопрос исключается из `remaining_applicable_set` и не уменьшает `systemCompletionPercentage`. | pass |
| API-BL-08 | Позитивный | Условие `except` не исключает вопрос при несовпадении значения | Пациент существует. Для вопроса есть `conditions.type = except`. Актуальное значение пациента по `options.parameter_code` не совпадает с `options.value`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Вопрос включается в `remaining_applicable_set` и учитывается при расчете заполненности. | pass |
| API-BL-09 | Позитивный | Условие `age` включает вопрос на границах диапазона | Пациент существует. Для вопроса есть `conditions.type = age` с `min_age` и `max_age`. По актуальному `birthdate` возраст пациента равен `min_age` или `max_age`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Вопрос включается в `remaining_applicable_set`, так как границы возрастного диапазона считаются включительно. | pass |
| API-BL-10 | Позитивный | Система без интерпретации возвращается со статусом `not enough data` | Пациент существует. Для выбранной системы в `interpretations` нет записи по `patient_id` и `system_code`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Для системы возвращается `interpretationStatus = "not enough data"`, `interpretationDateTime = null`, `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`. | pass |
| API-BL-11 | Позитивный | Система с интерпретацией без уровня риска | Пациент существует. Для системы есть запись в `interpretations`, но `interpretations.risk_level = null`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Для системы возвращается `interpretationStatus = "completed"`, `interpretationDateTime = interpretations.date_time`, при этом `risk = null`, `doctorSpecializations = null`, `diseaseRisks = null`. | pass |
| API-BL-12 | Позитивный | Система с низким уровнем риска | Пациент существует. Для системы есть запись в `interpretations` с `risk_level = low`, заполнены `text`, `date_time`, `diseases`, `doctors_code`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Возвращается `interpretationStatus = "completed"`. В `risk` заполнены `riskLevel = low`, `description`, `interpretationDateTime`; `risk.riskFactors = null`. `diseaseRisks` формируется из `interpretations.diseases`, `doctorSpecializations` — из `doctors` по `interpretations.doctors_code`. | pass |
| API-BL-13 | Позитивный | Система со средним или высоким уровнем риска возвращает все связанные факторы | Пациент существует. Для системы есть интерпретация с `risk_level = medium` или `high`. В `interpretations.risk_factors_code` есть коды модифицируемого и немодифицируемого факторов; оба фактора существуют в `risk_factors` и связаны с текущей системой через `risk_factor_systems`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | В `risk.riskFactors` возвращаются оба фактора независимо от `modifiability`. `title = risk_factors.description`, `details = risk_factor_systems.reasoning`; порядок соответствует `interpretations.risk_factors_code`. `modifiability` влияет только на отбор рекомендаций `risk_factor_group`. | not run |
| API-BL-14 | Позитивный | Рекомендации риска формируются из двух групп после нормализации факторов | Пациент существует. Для системы есть интерпретация с `risk_level = medium` или `high`; `interpretations.risk_factors_code` содержит код модифицируемого фактора. Фактор существует в `risk_factors` и связан с текущей системой через `risk_factor_systems`. В `recommendations` есть применимая запись `risk_factor_group` и запись `common_group` этой системы. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | В `risk.recommendations` возвращаются рекомендации обеих групп: связанная с выявленным модифицируемым фактором и общая по системе. `title = recommendations.name`, `details = recommendations.text`; нормализация справочника не изменила прежнюю логику отбора. | not run |
| API-BL-15 | Позитивный | Расчет общего процента заполненности | Пациент существует. По нескольким системам и `COMMON` есть пересекающиеся параметры с актуальными значениями и применимые неотвеченные вопросы. | Вызвать `GET /v1/clients/{clientId}/medical-risk` без `systemCode`. | `completionPercentage` рассчитывается по глобальным дедуплицированным множествам: `floor(total_answered / (total_answered + total_remaining) * 100)`. Повторяющиеся параметры и вопросы между системами учитываются один раз. | pass |
| API-BL-16 | Позитивный | Даты последних расчета и интерпретации берутся как максимум по системам | Пациент существует. По нескольким системам есть записи в `results` с непустым `value` и записи в `interpretations` с разными `date_time`. | Вызвать `GET /v1/clients/{clientId}/medical-risk` без `systemCode`. | `lastCalculationDateTime` равен максимальному `results.date_time` по инструментам систем пациента с непустым `value`. `lastInterpretationDateTime` равен максимальному `interpretations.date_time` среди найденных интерпретаций. | pass |
| API-BL-17 | Позитивный | Топ-рекомендации сохраняют сортировку, дополнение и дедупликацию | Пациент существует. По нескольким системам есть интерпретации `high`, `medium`, `low`; в `risk_factors` и `risk_factor_systems` настроены выявленные модифицируемые факторы. Подготовлено больше пяти кандидатов `risk_factor_group`/`common_group`, включая одинаковые `name`. | Вызвать `GET /v1/clients/{clientId}/medical-risk` без `systemCode`. | Сначала идут кандидаты `risk_factor_group` систем `high`, затем `medium`; внутри уровня — по возрастанию `systems.rang`, внутри системы — по позиции фактора в `interpretations.risk_factors_code`. Если их меньше пяти, хвост дополняется `common_group` по `systems.rang`. Результат дедуплицирован по `name` и ограничен пятью элементами; рекомендации факторов системы `low` в основную выборку не входят. Пустая выборка даёт `topRecommendations = null`. | not run |

### Дополнительные тест-кейсы по непокрытой бизнес-логике

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-18 | Позитивный | systemCode минимальной допустимой длины | Пациент существует. В справочнике есть система с кодом длиной 2 символа. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<код из 2 символов>`. | Запрос проходит валидацию длины `systemCode` и возвращает `200 OK`; в `systemInterpretationResults` присутствует только запрошенная система. | pass |
| API-BL-19 | Негативный | Просроченное значение параметра не считается актуальным | У параметра пациента заполнены `value` и `expiration_date`, но `expiration_date` меньше текущей даты. Параметр связан с вопросом выбранной системы. | Вызвать метод по выбранной системе. | Просроченный параметр не попадает в `answered_params_set`; применимый вопрос учитывается в `remaining_applicable_set`, проценты заполненности не завышаются. | pass |
| API-BL-20 | Негативный | Значение параметра без expiration_date не считается актуальным | У параметра пациента заполнено `value`, но `expiration_date = null`. | Вызвать метод по выбранной системе. | Параметр не считается отвеченным и не попадает в `answered_params_set`; применимый вопрос остается неотвеченным. | too much |
| API-BL-21 | Негативный | Параметр с null в value не считается актуальным | У параметра пациента `value = null`, а `expiration_date` не меньше текущей даты. | Вызвать метод по выбранной системе. | Параметр не считается отвеченным и не увеличивает `systemCompletionPercentage` и `completionPercentage`. | pass |
| API-BL-22 | Негативный | Условие age исключает вопрос вне возрастного диапазона | Для вопроса задано `conditions.type = age`; актуальный `birthdate` дает возраст меньше `min_age` или больше `max_age`. | Вызвать метод по выбранной системе. | Вопрос исключается из `remaining_applicable_set` и не уменьшает проценты заполненности. | pass |
| API-BL-23 | Позитивный | Условие except при отсутствии актуального предыдущего ответа | Для вопроса задано `conditions.type = except`; опция по `previous_option_code` существует, но актуального значения пациента для `options.parameter_code` нет. | Вызвать метод по выбранной системе. | Совпадение с `options.value` не найдено, поэтому вопрос включается в `remaining_applicable_set`. | pass |
| API-BL-24 | Позитивный | Факторы риска собираются из `risk_factors` и `risk_factor_systems` без межсистемного смешивания | Интерпретация имеет `risk_level = medium` или `high` и упорядоченный `risk_factors_code`. Один код связан через `risk_factor_systems` с двумя системами с разным `reasoning`; также подготовлен немодифицируемый фактор, связанный с текущей системой. | Вызвать метод по одной выбранной системе. | В `risk.riskFactors` включаются все коды из `interpretations.risk_factors_code`, имеющие связь с текущей системой, независимо от `modifiability`; `title = risk_factors.description`, `details = risk_factor_systems.reasoning` текущей системы. Обоснование другой системы не возвращается; порядок соответствует `risk_factors_code`. `modifiability` влияет только на отбор рекомендаций `risk_factor_group`. | not run |
| API-BL-25 | Позитивный | Низкий риск всегда возвращается без факторов риска | Для системы есть интерпретация с `risk_level = low`; в справочнике существуют связанные факторы. | Вызвать метод по выбранной системе. | `risk.riskLevel = low`, а `risk.riskFactors = null`; наличие записей в справочнике факторов не меняет ответ. | pass |
| API-BL-26 | Позитивный | Общие рекомендации возвращаются без выявленных факторов | Для системы есть интерпретация с заданным уровнем риска; связанных `risk_factor_group` рекомендаций нет, но есть `common_group` для этой системы. | Вызвать метод по выбранной системе. | В `risk.recommendations` присутствуют рекомендации `common_group`; они включаются независимо от наличия факторов риска. | pass |
| API-BL-27 | Позитивный | Маппинг заболеваний и специализаций врачей | В интерпретации заполнены `diseases[]` и упорядоченный `doctors_code`; соответствующие врачи есть в справочнике `doctors`. | Вызвать метод по выбранной системе. | `diseaseRisks[].name` соответствует элементам `interpretations.diseases`; `doctorSpecializations[].name = doctors.description`, `doctorSpecializations[].code = doctors.code`, порядок врачей соответствует `doctors_code`. | pass |
| API-BL-28 | Позитивный | Даты последних операций равны null при отсутствии данных | Для пациента нет интерпретаций и нет результатов по инструментам систем с непустым `value`. | Вызвать метод без `systemCode`. | `lastCalculationDateTime = null` и `lastInterpretationDateTime = null`. | pass |
| API-BL-29 | Негативный | Результат с пустым value не влияет на дату последнего расчета | Есть более новая запись `results` с `value = null` и более старая запись с непустым `value`. | Вызвать метод без `systemCode`. | `lastCalculationDateTime` равен дате более старой записи с непустым `value`; запись с пустым значением игнорируется. | pass |
| API-BL-30 | Позитивный | Запрос системы COMMON не формирует элемент результата | Пациент существует; в справочнике есть система `COMMON`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=COMMON`. | Запрос обрабатывается успешно, но элемент с `systemCode = COMMON` отсутствует в `systemInterpretationResults`, поскольку COMMON используется только для расчета параметров. | pass |
| API-BL-31 | Позитивный | Порядок систем и уникальность приоритетов в ответе | Запрашиваются все системы; в справочнике заданы разные значения `rang` от 1 до 13. | Вызвать метод без `systemCode`. | Системы отсортированы по возрастанию `rang`; `systemPriority` находится в диапазоне 1-13 и не повторяется; `COMMON` отсутствует. | pass |
| API-BL-32 | Позитивный | Контракт и ограничения полей успешного ответа | Подготовлены данные с интерпретациями, врачами, заболеваниями, факторами и рекомендациями. | Вызвать метод и провалидировать ответ по контракту. | Обязательные поля присутствуют и имеют заявленные типы; проценты лежат в диапазоне 0-100; даты соответствуют ISO 8601 `YYYY-MM-DDThh:mm:ss`; строковые поля не превышают ограничения аналитики; enum-поля содержат только допустимые значения. | pass |
| API-BL-33 | Негативный | Контракт ошибки 400 при невалидном clientId | Передан `clientId`, нарушающий длину или допустимый формат. | Вызвать метод. | Возвращается `400 Bad Request`, `isSuccess = false`, объект `error` содержит `code = INVALID_CLIENT_ID` и непустой `message`; длины `error.code` и `error.message` не превышают 100 и 255 символов. | pass |
| API-BL-34 | Негативный | Контракт ошибки 404 для отсутствующего клиента | Валидный по формату `clientId` отсутствует в таблице `patients`. | Вызвать метод. | Возвращается `404 Not Found`, `isSuccess = false`, объект `error` содержит `code = CLIENT_NOT_FOUND` и непустой `message`. | pass |

### Тест-кейсы по задачам #118 и #203 — регрессия `risk.recommendations` после нормализации факторов риска

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-35 | Позитивный | Дедупликация рекомендаций разных факторов риска по `name` | Для пациента в системе CVD есть интерпретация `medium/high`; несколько кодов из `interpretations.risk_factors_code` существуют в `risk_factors`, имеют `modifiability = 'modifiable'` и связи с CVD в `risk_factor_systems`. В `recommendations` этим кодам соответствуют записи `risk_factor_group` с одинаковым `name = Контроль артериального давления`, но разным `text`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=CVD`. | Ответ `200 OK`. В `risk.recommendations` присутствует ровно одна рекомендация с этим `title`; её `details` взят из первого вхождения в сформированном списке. | not run |
| API-BL-36 | Позитивный | Дедупликация повторных строк одной пары фактор–система | Фактор указан в `interpretations.risk_factors_code`, существует в `risk_factors` и связан с текущей системой через `risk_factor_systems`. В `recommendations` есть несколько строк `risk_factor_group` для пары `(risk_factor_code, system_code)` с одинаковым `name`. | Вызвать метод по выбранной системе. | Ответ `200 OK`. Повторяющиеся строки дают один элемент в `risk.recommendations`; `title` и `details` соответствуют первому вхождению. | not run |
| API-BL-37 | Позитивный | Приоритет `risk_factor_group` при совпадении `name` между группами | Для системы есть рекомендации `risk_factor_group` и `common_group` с одинаковым `name`, но разным `text`; фактор выявлен, модифицируем и связан с системой через `risk_factor_systems`. | Вызвать метод по выбранной системе. | Возвращается один элемент с данным `title`; его `details` взят из `risk_factor_group`. Запись `common_group` с тем же `name` не возвращается. | not run |
| API-BL-38 | Позитивный | Сохранение порядка уникальных рекомендаций после дедупликации | Для нескольких выявленных модифицируемых факторов текущей системы подготовлены уникальные рекомендации `risk_factor_group`, затем `common_group`; между группами есть повтор по `name`. Все факторы связаны с системой через `risk_factor_systems`. | Вызвать метод по выбранной системе. | Сначала расположены уникальные `risk_factor_group` в порядке кодов факторов из `interpretations.risk_factors_code`, затем уникальные `common_group`; повторное `name` исключено, порядок остальных элементов не изменён. | not run |
| API-BL-39 | Негативный | Рекомендации с разными `name` не дедуплицируются по одинаковому `text` | Для выявленных модифицируемых факторов текущей системы есть две применимые рекомендации с разными `name`, но одинаковым `text`. | Вызвать метод по выбранной системе. | Обе рекомендации присутствуют в `risk.recommendations`; одинаковый `text` не является основанием для дедупликации. | not run |
| API-BL-40 | Негативный | Дедупликация `risk.recommendations` не выполняется глобально между системами | Для двух систем есть выявленные модифицируемые факторы, корректные связи в `risk_factor_systems` и применимые рекомендации с одинаковым `name`. | Вызвать метод без `systemCode`. | Рекомендация присутствует в `risk.recommendations` каждой системы; локальная дедупликация одной системы не удаляет рекомендацию другой. В `topRecommendations` одинаковый `title`, напротив, дедуплицируется глобально. | not run |
| API-BL-41 | Негативный | Фактор и его рекомендация не переходят из другой системы | В `interpretations.risk_factors_code` текущей системы указан код фактора, но запись `risk_factor_systems` и рекомендация `risk_factor_group` для этого кода существуют только у другой системы; общая рекомендация текущей системы существует. | Вызвать метод по текущей системе. | Ответ `200 OK`; чужие `riskFactors[].details`, фактор и `risk_factor_group` рекомендация не возвращаются. В `risk.recommendations` остаётся применимая `common_group`; межсистемного смешивания и ошибки обращения к удалённым `risk_factors.system_code/reasoning` нет. | not run |
| API-BL-42 | Негативный | `common_group` не перезаписывает детали первого совпавшего `risk_factor_group` | У применимой рекомендации выявленного модифицируемого фактора и последующей `common_group` одинаковый `name`, но разные `text`. Фактор связан с текущей системой через `risk_factor_systems`. | Вызвать метод по выбранной системе. | В единственном элементе с данным `title` сохранён `details` первой записи `risk_factor_group`; текст `common_group` его не перезаписывает. | not run |

### Тест-кейсы по задаче #162 — расчёт заполненности цельными вопросами

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-43 | Позитивный | `systemCompletionPercentage` считается по цельным вопросам, а не по параметрам | Пациент существует, `patients.is_pregnant = false`. Для выбранной системы есть 4 применимых вопроса. Один вопрос записывает несколько `parameter_code`, и по всем этим параметрам есть актуальные записи в `patients_parameters`; второй вопрос имеет актуальный ответ; два вопроса применимы, но не отвечены. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | В знаменатель попадают 4 вопроса, в числитель попадают 2 вопроса. `systemCompletionPercentage = floor(2 / 4 * 100) = 50`. Вопрос с несколькими параметрами учитывается как один progressed-вопрос, а не как несколько отвеченных параметров. | pass |
| API-BL-44 | Позитивный | Вопрос относится к системе через любой вариант ответа | В справочнике есть вопрос, у которого хотя бы один `options.parameter_code` связан с инструментом выбранной системы через `instruments_parameters` и `systems_instruments`. У пациента нет актуального значения по этому `parameter_code`. | Вызвать метод по выбранной системе. | Вопрос включается в `applicable_questions` выбранной системы и влияет на знаменатель `systemCompletionPercentage`, даже если другие варианты вопроса относятся к другим системам. | pass |
| API-BL-45 | Позитивный | Полностью отвеченный вопрос попадает в `progressed_questions` | Вопрос применим пациенту. Все `parameter_code`, которые вопрос записывает через свои `options`, имеют актуальные записи в `patients_parameters`: `value` не `NULL`, `expiration_date` не `NULL` и не меньше текущей даты. | Вызвать метод по выбранной системе. | Вопрос включается в `applicable_questions` и в `progressed_questions`; числитель и знаменатель увеличиваются на 1. | pass |
| API-BL-46 | Негативный | Частично отвеченный мультипараметрический вопрос не считается progressed | Вопрос применим пациенту и записывает несколько `parameter_code`. Только часть этих параметров имеет актуальные записи в `patients_parameters`; по минимум одному параметру актуальной записи нет. | Вызвать метод по выбранной системе. | Вопрос включается в `applicable_questions`, но не включается в `progressed_questions`; `systemCompletionPercentage` не завышается частичным ответом. | too much |
| API-BL-47 | Негативный | Неактуальное значение параметра не засчитывает вопрос | Вопрос применим пациенту. Для одного из `parameter_code`, записываемых вопросом, есть запись в `patients_parameters`, но `value = NULL`, или `expiration_date = NULL`, или `expiration_date` меньше текущей даты. | Вызвать метод по выбранной системе. | Такое значение не считается актуальным. Если из-за него не выполнено условие «все parameter_code вопроса имеют актуальную запись», вопрос не попадает в `progressed_questions`. | pass |
| API-BL-48 | Позитивный | `except` по `gender` исключает вопрос из знаменателя | Для вопроса выбранной системы есть `conditions.type = except`, `conditions.parameter_code = gender`. У пациента есть актуальный `gender`, совпадающий с `conditions.value`. | Вызвать метод по выбранной системе. | Вопрос исключается из `applicable_questions`; он не увеличивает знаменатель и не уменьшает `systemCompletionPercentage`. | pass |
| API-BL-49 | Негативный | `except` по `gender` не срабатывает без актуального значения пола | Для вопроса есть `conditions.type = except`, `conditions.parameter_code = gender`. У пациента нет актуальной записи `gender`, либо запись неактуальна по `value`/`expiration_date`. | Вызвать метод по выбранной системе. | Условие исключения по полу не срабатывает. Если других исключающих условий нет, вопрос остаётся в `applicable_questions`. | pass |
| API-BL-50 | Позитивный | `age` включает вопрос на границах диапазона | Для вопроса есть `conditions.type = age`. У пациента есть актуальный `birthdate`, и возраст на текущую дату равен `min_age` или `max_age`. | Вызвать метод по выбранной системе. | Возрастные границы считаются включительно; вопрос остаётся в `applicable_questions`. | pass |
| API-BL-51 | Негативный | `age` исключает вопрос вне диапазона | Для вопроса есть `conditions.type = age`. У пациента есть актуальный `birthdate`, и возраст на текущую дату меньше `min_age` или больше `max_age`. | Вызвать метод по выбранной системе. | Вопрос исключается из `applicable_questions`; он не влияет на знаменатель и не уменьшает процент заполненности. | pass |
| API-BL-52 | Негативный | `age` не исключает вопрос без актуальной даты рождения | Для вопроса есть `conditions.type = age`, но у пациента нет актуальной записи `birthdate`, либо `birthdate.value = NULL`, либо `birthdate.expiration_date = NULL`/просрочен. | Вызвать метод по выбранной системе. | Возраст пациента не может быть рассчитан по актуальному значению, поэтому условие `age` не исключает вопрос из `applicable_questions`. | pass |
| API-BL-53 | Позитивный | `except` не по `gender` засчитывает скрытый вопрос в числителе | Вопрос применим пациенту по полу и возрасту. Для вопроса есть `conditions.type = except` с `parameter_code`, отличным от `gender`; у пациента есть актуальная запись по `conditions.parameter_code`, и её значение совпадает с `conditions.value`. | Вызвать метод по выбранной системе. | Вопрос остаётся в `applicable_questions` и попадает в `progressed_questions` как скрытый условием показа. `systemCompletionPercentage` увеличивается без сохранённого ответа на сам вопрос. | pass |
| API-BL-54 | Негативный | `except` не по `gender` не засчитывает вопрос при несовпадении значения | Вопрос применим пациенту. Для вопроса есть `conditions.type = except` с `parameter_code`, отличным от `gender`; актуальное значение пациента по этому параметру отсутствует или не совпадает с `conditions.value`. Ответы на параметры самого вопроса отсутствуют. | Вызвать метод по выбранной системе. | Вопрос остаётся в `applicable_questions`, но не попадает в `progressed_questions`; процент заполненности не завышается. | pass |
| API-BL-55 | Позитивный | Вопрос `cq_030` считается progressed по `patients.is_pregnant` | Вопрос `cq_030` относится к выбранной системе и применим пациентке. В `patients.is_pregnant` записано `true` или `false`, при этом ответ по `cq_030` не сохранён в `patients_parameters`. | Вызвать метод по выбранной системе. | Для `cq_030` условие progressed считается выполненным по полю `patients.is_pregnant`; вопрос попадает в `progressed_questions`. | not pass |
| API-BL-56 | Негативный | Вопрос `cq_030` не считается progressed при `is_pregnant = NULL` | Вопрос `cq_030` относится к выбранной системе и применим пациентке. В `patients.is_pregnant = NULL`, актуального ответа в `patients_parameters` нет. | Вызвать метод по выбранной системе. | `cq_030` остаётся в `applicable_questions`, но не попадает в `progressed_questions`; процент заполненности не завышается. | not pass |
| API-BL-57 | Позитивный | Пустой знаменатель даёт 100% по системе | Для выбранной системы все вопросы исключены условиями пола/возраста либо в справочнике нет вопросов, относящихся к системе через `options.parameter_code` → `instruments_parameters` → `systems_instruments`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | `applicable_questions` пустой, `systemCompletionPercentage = 100`. Ответ остаётся успешным. | pass |
| API-BL-58 | Позитивный | Процент округляется вниз до целого числа | Для выбранной системы есть 3 применимых вопроса, из них 2 попадают в `progressed_questions`. | Вызвать метод по выбранной системе. | `systemCompletionPercentage = floor(2 / 3 * 100) = 66`, без округления до 67. | too much |
| API-BL-59 | Позитивный | `COMMON` отдельно не добавляется в расчёт системы | В справочнике есть вопросы, относящиеся только к системе `COMMON`, и вопросы, относящиеся к выбранной системе через свои варианты. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | В расчёте выбранной системы учитываются только вопросы, которые относятся к ней через `options.parameter_code` → `instruments_parameters` → `systems_instruments`. Вопросы, относящиеся только к `COMMON`, не добавляются отдельным набором. | pass |
| API-BL-60 | Позитивный | Один вопрос не дублируется внутри расчёта системы | Один `question_code` имеет несколько вариантов, которые через разные параметры относятся к одной и той же системе. | Вызвать метод по выбранной системе. | Вопрос учитывается в `applicable_questions` один раз по `question_code`; при выполнении условий progressed он также учитывается в `progressed_questions` один раз. | pass |

### Дополнительные тест-кейсы по задаче #203 — шаг 5: факторы риска и рекомендации

| Номер тест-кейса | Тип | Название тест-кейса | Предусловие | Шаги | Ожидаемый результат | Результат тест-прогона |
|------------------|-----|---------------------|-------------|------|---------------------|------------------------|
| API-BL-61 | Позитивный | Несколько триггеров одного фактора не размножают фактор в ответе | Для системы есть интерпретация `medium/high`; в `interpretations.risk_factors_code` указан код фактора. Фактор существует в `risk_factors`, имеет одну связь с текущей системой в `risk_factor_systems` и несколько строк в `risk_factor_triggers`. | Вызвать `GET /v1/clients/{clientId}/medical-risk?systemCode=<systemCode>`. | Ответ `200 OK`. В `risk.riskFactors` возвращается ровно один элемент для этого кода; количество триггеров не создаёт дубли. `title` взят из `risk_factors.description`, `details` — из единственной связи `risk_factor_systems` текущей системы. | pass |
| API-BL-62 | Позитивный | Фактор без обоснования возвращается с `details = null` | Для системы есть интерпретация `medium/high`; код фактора присутствует в `interpretations.risk_factors_code`, фактор существует в `risk_factors`, а у связи с текущей системой `risk_factor_systems.reasoning = null`. | Вызвать метод по выбранной системе. | Фактор не отбрасывается: в `risk.riskFactors` присутствует элемент с `title = risk_factors.description` и `details = null`. Ответ соответствует публичному контракту. | not run |
| API-BL-63 | Негативный | Неизвестный код из интерпретации не создаёт фиктивный фактор | В `interpretations.risk_factors_code` системы `medium/high` сначала указан код существующего связанного фактора, затем код, отсутствующий в `risk_factors`. | Вызвать метод по выбранной системе. | Ответ `200 OK`. В `risk.riskFactors` возвращается только существующий фактор; для неизвестного кода не создаётся пустой элемент, порядок оставшихся факторов сохраняется. Обработка профиля не завершается ошибкой `500`. | not run |
| API-BL-64 | Негативный | Немодифицируемый фактор не даёт рекомендацию `risk_factor_group` | В интерпретации `medium/high` указан немодифицируемый фактор, существующий в `risk_factors` и связанный с текущей системой через `risk_factor_systems`. В `recommendations` для него есть запись `risk_factor_group`; также есть применимая `common_group` текущей системы. | Вызвать метод по выбранной системе. | Немодифицируемый фактор присутствует в `risk.riskFactors`, но связанная с ним рекомендация `risk_factor_group` отсутствует в `risk.recommendations` и `topRecommendations`. Рекомендация `common_group` возвращается. | not run |
| API-BL-65 | Негативный | Неподдерживаемая группа рекомендаций не попадает в ответ | Для текущей системы подготовлены применимые записи `risk_factor_group`, `common_group` и запись с иным значением `recommendations_group`. Выявленный фактор модифицируем и связан с системой. | Вызвать метод по выбранной системе. | В `risk.recommendations` и `topRecommendations` участвуют только `risk_factor_group` и `common_group`. Запись неподдерживаемой группы отсутствует; ответ остаётся успешным. | incorrect |

