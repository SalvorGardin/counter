Краткое описание:

Что именно проверяем и зачем

Тестовые данные:

| Поле | Значение |
|------|----------|
| Endpoint | .../api/... |
| Method | GET/POST/PUT/DELETE/PATCH/TRACE/CONNECT |
| Headers | Authorization, Content-Type |
| Path params | ... |
| Request body | ... |

Тест-кейсы:

<table>
<tr>
<th>Номер тест-кейса</th>
<th>Название тест-кейса</th>
<th>Предусловие</th>
<th>Шаги</th>
<th>Ожидаемый результат</th>
</tr>
<tr>
<td>API-01</td>
<td>Позитивный. Получение ответа</td>
<td>Пользователь не авторизован</td>
<td>

Вызвать метод POST ../api/login

c Request Body:

```
"username":"Райан",
"password":"Гослинг"
```
</td>
<td>

Получен успешный ответ 200/201

В теле ответа:

```
{"success":"true",
"message": "user logged in successfully"}
```
</td>
</tr>
<tr>
<td>API-02</td>
<td>Негативный. Получение ошибки</td>
<td>Указан неверный логин/пароль</td>
<td>

| Вызвать метод POST ../api/login 

c Request Body:

```
"username":"Рикардо",
"password":"Милос"
```
</td>
<td>

Получен не успешный ответ 400/500

В теле ответа:

```
{"success":"false",
"message": "incorrect username or password"}
```
</td>
</tr>
</table>

